import { FormSubmission } from './db.js';

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
  data: Omit<FormSubmission, 'id' | 'created_at'>;
}

export function validateFormData(formData: Record<string, unknown>): ValidationResult {
  const errors: Record<string, string> = {};
  const data: Omit<FormSubmission, 'id' | 'created_at'> = {
    first_name: '',
    last_name: '',
    street_address: '',
    city: '',
    state_province_region: '',
    postal_code: '',
    country: '',
    email: '',
    phone_number: ''
  };
  
  // Helper function to get and trim value
  const getValue = (key: keyof typeof data) => {
    const value = formData[key];
    return typeof value === 'string' ? value.trim() : '';
  };
  
  // Validate required fields
  const requiredFields: (keyof typeof data)[] = [
    'first_name',
    'last_name', 
    'street_address',
    'city',
    'state_province_region',
    'postal_code',
    'country',
    'email',
    'phone_number'
  ];
  
  for (const field of requiredFields) {
    const value = getValue(field);
    data[field] = value;
    
    if (!value) {
      errors[field] = `${field.replace('_', ' ')} is required`;
    }
  }
  
  // Validate email format
  if (data.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }
  
  // Validate phone number (allow digits, spaces, parentheses, dashes, and leading +)
  if (data.phone_number) {
    const phoneRegex = /^[+]?[0-9\s\-()]{7,}$/;
    if (!phoneRegex.test(data.phone_number)) {
      errors.phone_number = 'Please enter a valid phone number';
    }
  }
  
  // Postal codes should accept alphanumeric strings
  if (data.postal_code) {
    const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
    if (!postalRegex.test(data.postal_code)) {
      errors.postal_code = 'Please enter a valid postal code';
    }
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    data
  };
}