import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { initDatabase, closeDatabase, insertSubmission } from './db.js';
import { validateFormData, ValidationResult } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Make form data and errors available to all templates
app.use((req: Request, res: Response, next: NextFunction) => {
  res.locals.formData = req.method === 'POST' ? req.body : {};
  res.locals.errors = {};
  next();
});

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    title: 'Contact Form',
    errors: {},
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const validation: ValidationResult = validateFormData(req.body);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      title: 'Contact Form',
      errors: validation.errors,
      formData: validation.data
    });
  }
  
  try {
    const submissionId = insertSubmission(validation.data);
    res.redirect(302, `/thank-you?id=${submissionId}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      title: 'Contact Form',
      errors: { submit: 'An error occurred while saving your submission. Please try again.' },
      formData: validation.data
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const submissionId = req.query.id;
  res.render('thank-you', { 
    title: 'Thank You',
    submissionId 
  });
});

// Export app for testing
export default app;

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  closeDatabase();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down gracefully...');
  closeDatabase();
  process.exit(0);
});

// Initialize database and start server (only if not in test mode)
async function startServer() {
  try {
    await initDatabase();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

if (process.env.NODE_ENV !== 'test') {
  startServer();
}
