import fs from 'fs';
import path from 'path';
import type { Database } from 'sql.js';

export interface FormSubmission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone_number: string;
  created_at?: string;
}

let db: Database | null = null;

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

export async function initDatabase(): Promise<void> {
  if (db) return;
  
  // Dynamic import of sql.js
  const initSqlJs = (await import('sql.js')).default;
  const SQL = await initSqlJs({
    locateFile: () => {
      return new URL(`../node_modules/sql.js/dist/sql-wasm.wasm`, import.meta.url).pathname;
    }
  });
  
  // Create data directory if it doesn't exist
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const dbFile = fs.readFileSync(DB_PATH);
    db = new SQL.Database(dbFile);
  } else {
    db = new SQL.Database();
    
    // Load and execute schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    db.exec(schema);
    saveDatabase();
  }
}

export function saveDatabase(): void {
  if (!db) throw new Error('Database not initialized');
  
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

export function insertSubmission(submission: Omit<FormSubmission, 'id' | 'created_at'>): number {
  if (!db) throw new Error('Database not initialized');
  
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province_region, postal_code, country, email, phone_number)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    submission.first_name,
    submission.last_name,
    submission.street_address,
    submission.city,
    submission.state_province_region,
    submission.postal_code,
    submission.country,
    submission.email,
    submission.phone_number
  ]);
  
  stmt.free();
  saveDatabase();
  
  // Get the last insert ID
  const result = db.exec('SELECT last_insert_rowid() as id');
  return result[0].values[0][0] as number;
}

export function getSubmission(id: number): FormSubmission | null {
  if (!db) throw new Error('Database not initialized');
  
  const stmt = db.prepare('SELECT * FROM submissions WHERE id = ?');
  stmt.bind([id]);
  
  if (stmt.step()) {
    const row = stmt.getAsObject();
    stmt.free();
    return {
      id: row.id as number,
      first_name: row.first_name as string,
      last_name: row.last_name as string,
      street_address: row.street_address as string,
      city: row.city as string,
      state_province_region: row.state_province_region as string,
      postal_code: row.postal_code as string,
      country: row.country as string,
      email: row.email as string,
      phone_number: row.phone_number as string,
      created_at: row.created_at as string
    };
  }
  
  stmt.free();
  return null;
}