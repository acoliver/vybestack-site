import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import app from '../../src/server.js';
import { initDatabase, closeDatabase } from '../../src/db.js';

let server: ReturnType<typeof app.listen>;
const dbPath = path.resolve('data', 'submissions.sqlite');

// Dynamic import for cheerio to handle module loading issues
let cheerio: typeof import('cheerio');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Initialize database
  await initDatabase();
  
  // Start server for testing
  server = app.listen(0); // Use random port
  
  // Import cheerio dynamically
  const cheerioModule = await import('cheerio');
  cheerio = cheerioModule.default || cheerioModule;
});

afterAll(async () => {
  // Close server
  if (server) {
    await new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
  }
  
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Close database connection
  await closeDatabase();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('#first_name').length).toBe(1);
    expect($('#last_name').length).toBe(1);
    expect($('#street_address').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#state_province_region').length).toBe(1);
    expect($('#postal_code').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone_number').length).toBe(1);
    
    // Check that form has proper attributes
    expect($('form[action="/submit"][method="POST"]').length).toBe(1);
    
    // Check labels are associated with inputs
    expect($('label[for="first_name"]').length).toBe(1);
    expect($('label[for="last_name"]').length).toBe(1);
    expect($('label[for="email"]').length).toBe(1);
    expect($('label[for="phone_number"]').length).toBe(1);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({})
      .expect(400);
    
    const $ = cheerio.load(response.text);
    
    // Check that error messages are displayed
    expect($('.error-message').length).toBeGreaterThan(0);
    
    // Check for specific error fields
    expect($('#first_name.error').length).toBe(1);
    expect($('#email.error').length).toBe(1);
  });

  it('validates email format', async () => {
    const invalidData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province_region: 'State',
      postal_code: '12345',
      country: 'USA',
      email: 'invalid-email',
      phone_number: '+1234567890'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(invalidData)
      .expect(400);
    
    const $ = cheerio.load(response.text);
    expect($('#email.error').length).toBe(1);
  });

  it('validates phone number format', async () => {
    const invalidData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province_region: 'State',
      postal_code: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone_number: 'invalid-phone'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(invalidData)
      .expect(400);
    
    const $ = cheerio.load(response.text);
    expect($('#phone_number.error').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const validData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province_region: 'State',
      postal_code: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone_number: '+1 (555) 123-4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(validData)
      .expect(302);
    
    // Check redirect to thank you page
    expect(response.headers.location).toMatch(/\/thank-you\?id=\d+/);
  });

  it('accepts international phone numbers', async () => {
    const validData = {
      first_name: 'Juan',
      last_name: 'Pérez',
      street_address: 'Calle 123',
      city: 'Buenos Aires',
      state_province_region: 'CABA',
      postal_code: 'C1000',
      country: 'Argentina',
      email: 'juan@example.com',
      phone_number: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(validData)
      .expect(302);
    
    expect(response.headers.location).toMatch(/\/thank-you\?id=\d+/);
  });

  it('accepts international postal codes', async () => {
    const validData = {
      first_name: 'Jane',
      last_name: 'Smith',
      street_address: '10 Downing Street',
      city: 'London',
      state_province_region: 'England',
      postal_code: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane@example.com',
      phone_number: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(validData)
      .expect(302);
    
    expect(response.headers.location).toMatch(/\/thank-you\?id=\d+/);
  });

  it('renders thank you page with humor', async () => {
    const response = await request(app)
      .get('/thank-you')
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for thank you content
    expect($('.thank-you-title').length).toBe(1);
    expect($('.thank-you-title').text()).toContain('Thank');
    
    // Check for the humorous "why did you give your info" content
    expect($('.warning-box').length).toBe(1);
    expect($('.warning-box').text()).toMatch(/why did you.*give.*information.*stranger.*internet/i);
    
    // Check for spam/identity theft humor
    expect($('.warning-box').text()).toMatch(/spam.*email|identity.*theft/i);
    
    // Check for link back to form
    expect($('a[href="/"]').length).toBe(1);
  });

  it('serves CSS stylesheet', async () => {
    const response = await request(app)
      .get('/styles.css')
      .expect(200);
    
    expect(response.headers['content-type']).toMatch(/text\/css/);
    expect(response.text.length).toBeGreaterThan(100); // Should have meaningful CSS content
  });
});
