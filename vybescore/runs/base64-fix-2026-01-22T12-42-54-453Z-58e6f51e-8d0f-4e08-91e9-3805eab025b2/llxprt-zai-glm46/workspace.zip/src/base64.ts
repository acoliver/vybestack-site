const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate if a string is valid Base64 format.
 * Throws an error if the input contains characters outside the Base64 alphabet.
 */
function validateBase64(input: string): void {
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
  }

  // Check for invalid padding (only allowed at the end and max 2 characters)
  const paddingMatch = input.match(/=/g);
  if (paddingMatch) {
    const paddingIndex = input.indexOf('=');
    if (paddingIndex !== -1 && paddingIndex < input.length - paddingMatch.length) {
      throw new Error('Invalid Base64 input: padding characters must be at the end');
    }
    if (paddingMatch.length > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
  }
}

/**
 * Add padding to Base64 string if needed.
 * Base64 padding length must be a multiple of 4.
 */
function addPadding(input: string): string {
  while (input.length % 4 !== 0) {
    input += '=';
  }
  return input;
}

/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate input format first
  validateBase64(input);

  // Add padding if needed for proper decoding
  const normalized = addPadding(input);

  try {
    const buffer = Buffer.from(normalized, 'base64');
    
    // Check if decoding was successful (Buffer should not be empty for valid non-empty input)
    if (input.length > 0 && buffer.length === 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
