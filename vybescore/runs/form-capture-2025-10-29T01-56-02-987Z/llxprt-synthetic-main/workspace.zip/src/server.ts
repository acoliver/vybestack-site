import express, { Request, Response } from "express";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
// @ts-expect-error: sql.js types are not available
import initSqlJs from "sql.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.resolve(__dirname, "..", "data", "submissions.sqlite");

// Form submission interface
interface FormSubmission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

// Validation errors interface
interface ValidationError {
  [key: string]: string; // field name -> error message
}

// Form field names type
type FormField = keyof FormSubmission;

// SQL Database instance
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: unknown;

// Create SQLite directory if it doesn't exist
const dataDir = path.dirname(dbPath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize database
const initDatabase = async (): Promise<unknown> => {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SQL = await initSqlJs({
      locateFile: () => path.resolve(__dirname, "..", "node_modules", "sql.js", "dist", "sql-wasm.wasm"),
    });
    
    let dbContent: Uint8Array | null = null;
    
    // Load existing database file if it exists
    if (fs.existsSync(dbPath)) {
      const fileContent = fs.readFileSync(dbPath);
      dbContent = new Uint8Array(fileContent);
    }
    
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const database = new SQL.Database(dbContent);
    
    // Create table if it doesn't exist
    const schema = fs.readFileSync(path.resolve(__dirname, "..", "db", "schema.sql"), "utf8");
    database.run(schema);
    
    return database;
  } catch (error) {
    console.error("Error initializing database:", error);
    process.exit(1);
  }
};

// Save database to disk
const saveDatabase = (): void => {
  if (db) {
    // @ts-expect-error: Database methods are not typed
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
};

// Validate form input
const validateForm = (formData: Partial<FormSubmission>): ValidationError => {
  const errors: ValidationError = {};
  
  // Required fields validation
  const requiredFields: FormField[] = [
    "first_name", "last_name", "street_address", "city", 
    "state_province", "postal_code", "country", "email", "phone"
  ];
  
  for (const field of requiredFields) {
    if (!formData[field] || formData[field]!.trim() === "") {
      errors[field] = `${field.replace(/_/g, " ")} is required`;
    }
  }
  
  // Email validation
  if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.email = "Please enter a valid email address";
  }
  
  // Phone validation - allow digits, spaces, parentheses, dashes, and leading +. More permissive for international formats.
  if (formData.phone && !/^\s*[+]?\d[\d\s\-()]{3,20}\d\s*$/.test(formData.phone)) {
    errors.phone = "Please enter a valid phone number";
  }
  
  // Postal code validation - alphanumeric
  if (formData.postal_code && !/^[a-zA-Z0-9\s-]+$/.test(formData.postal_code)) {
    errors.postal_code = "Postal code can only contain letters, numbers, spaces and dashes";
  }
  
  return errors;
};

// Express app setup
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use("/public", express.static(path.resolve(__dirname, "..", "public")));

// Set view engine
app.set("view engine", "ejs");
app.set("views", path.resolve(__dirname, "templates"));

// Routes
app.get("/", (req: Request, res: Response) => {
  res.render("form", { errors: {}, formData: {} });
});

app.post("/submit", (req: Request, res: Response) => {
  const formData = req.body as Partial<FormSubmission>;
  const errors = validateForm(formData);
  
  if (Object.keys(errors).length > 0) {
    return res.render("form", { errors, formData });
  }
  
  try {
    // Insert into database
    // @ts-expect-error: Database methods are not typed
    db.run(
      `INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.first_name,
        formData.last_name,
        formData.street_address,
        formData.city,
        formData.state_province,
        formData.postal_code,
        formData.country,
        formData.email,
        formData.phone
      ]
    );
    
    // Save database
    saveDatabase();
    
    // Store first name in session (query param is fine for this simple app)
    const firstName = formData.first_name || "friend";
    res.redirect(`/thank-you?name=${encodeURIComponent(firstName)}`);
  } catch (error) {
    console.error("Error saving submission:", error);
    errors.server = "An error occurred while saving your submission. Please try again.";
    return res.render("form", { errors, formData });
  }
});

app.get("/thank-you", (req: Request, res: Response) => {
  const name = req.query.name as string || "friend";
  res.render("thank-you", { name });
});

// Start server and initialize database
const startServer = async (): Promise<void> => {
  try {
    // Initialize database
    db = await initDatabase();
    
    // Start server
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    // Handle graceful shutdown
    const gracefulShutdown = (): void => {
      console.log("Shutting down gracefully...");
      if (db) {
        // @ts-expect-error: Database methods are not typed
        db.close();
      }
      server.close(() => {
        console.log("Server closed");
        process.exit(0);
      });
    };
    
    // Process signals
    process.on("SIGTERM", gracefulShutdown);
    process.on("SIGINT", gracefulShutdown);
    
    return;
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
};

// Export for testing
export const serverForTesting = async (): Promise<{ app: express.Express, close: () => void }> => {
  db = await initDatabase();
  
  // Create a close function for the test to call
  const close = (): void => {
    if (db) {
      // @ts-expect-error: Database methods are not typed
      db.close();
    }
  };
  
  return { app, close };
};

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}