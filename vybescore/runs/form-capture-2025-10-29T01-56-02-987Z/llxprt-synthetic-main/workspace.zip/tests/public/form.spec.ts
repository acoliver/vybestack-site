import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

let server: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import and start server for testing
  const { serverForTesting } = await import('../../src/server.js');
  const { app } = await serverForTesting();
  // Start a test server
  server = app.listen(0);
});

afterAll(() => {
  // @ts-expect-error: server is typed as unknown but we know it has close method
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    // @ts-expect-error: server is typed as unknown but we know it has address
    const response = await fetch(`http://localhost:${server.address().port}`);
    expect(response.ok).toBeTruthy();
    
    const text = await response.text();
    // Check that form contains all required fields
    expect(text).toContain('first_name');
    expect(text).toContain('last_name');
    expect(text).toContain('street_address');
    expect(text).toContain('city');
    expect(text).toContain('state_province');
    expect(text).toContain('postal_code');
    expect(text).toContain('country');
    expect(text).toContain('email');
    expect(text).toContain('phone');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    let responseText = '';
    try {
      // Submit form data
      const formData = 'first_name=Test&last_name=User&street_address=123 Test St&city=Test City&state_province=Test State&postal_code=12345&country=Test Country&email=test@example.com&phone=15551234567';
      
      // @ts-expect-error: server is typed as unknown but we know it has address
      const response = await fetch(`http://localhost:${server.address().port}/submit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        redirect: 'manual', // Don't follow redirects automatically
        body: formData,
      });
      
      // Get response data for debugging
      responseText = await response.text();
      
      // Log response details for debugging
      console.log('Response status:', response.status);
      console.log('Response headers:', Object.fromEntries(response.headers.entries()));
      console.log('Response text:', responseText);
      
      // Should redirect to thank-you page (status 302)
      expect(response.status).toBe(302);
      expect(response.headers.get('location')).toContain('/thank-you');
    } catch (error) {
      console.error('Error during test:', error);
      console.error('Response text:', responseText);
      throw error;
    }
    
    // Check that database file was created and contains our submission
    expect(fs.existsSync(dbPath)).toBeTruthy();
  });
});
