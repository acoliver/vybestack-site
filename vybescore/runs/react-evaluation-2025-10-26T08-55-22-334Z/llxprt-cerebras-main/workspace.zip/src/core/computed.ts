/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle the equal parameter - if it's a boolean, we should use Object.is for comparison
  const equalFn = typeof equal === 'function' 
    ? equal 
    : equal === true 
      ? Object.is 
      : undefined;
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Run the update function initially to compute the value
  updateObserver(observer)
  
  // Return a getter function with additional properties to support dependency tracking
  const getter = (): T => {
    return observer.value as T;
  };
  
  // Add the equalFn to the getter for use in dependency tracking
  (getter as any).equalFn = equalFn;
  
  return getter;
}