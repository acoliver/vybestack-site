export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();

  // Check for obvious invalid patterns
  if (!trimmed || trimmed.includes('..') || trimmed.endsWith('.') || 
      trimmed.startsWith('.') || trimmed.includes('@.@') ||
      !trimmed.includes('@')) {
    return false;
  }

  // Validate email format with regex
  // Allows typical addresses including name+tag@example.co.uk format
  // Rejects domains with underscores and other invalid patterns
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;

  return emailRegex.test(trimmed);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.trim().replace(/[^\d+]/g, '');

  // Must start with +1 or digits only
  let digitsOnly = cleaned;
  if (cleaned.startsWith('+1')) {
    digitsOnly = cleaned.substring(2);
  } else if (cleaned.startsWith('+')) {
    return false; // Non-US international codes not supported
  }

  // Must have 10 digits (US format)
  if (digitsOnly.length !== 10) {
    return false;
  }

  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }

  // Valid format: optional +1, area code (2-9 for first digit), 7 digits total
  // Matches: +1 212-555-7890, (212) 555-7890, 212-555-7890, 2125557890
  const phoneRegex = /^\+?1?[2-9]\d{2}[-.]?(\d{3}[-.]?\d{4}|\d{3}\d{4})$/;

  return phoneRegex.test(value.trim());
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and punctuation for validation
  const cleaned = value.replace(/[\s\-().]/g, '');

  // Pattern requirements:
  // - Optional country code (+54)
  // - Optional trunk prefix (0) before area code  
  // - Optional mobile indicator (9) between country/trunk and area code
  // - Area code: 2-4 digits (first digit 1-9)
  // - Subscriber number: 6-8 digits total
  // - When country code omitted, must begin with trunk prefix 0

  let regex: RegExp | null = null;

  if (cleaned.startsWith('+549')) {
    // International mobile: +54 9 [area] [subscriber]
    // Area code: 2-4 digits, Subscriber: 6-8 digits (total 8-12 digits after +549)
    regex = /^\+549[1-9]\d{6,8}$/;
  } else if (cleaned.startsWith('+54')) {
    // International landline: +54 [area] [subscriber]  
    // Area code: 2-4 digits, Subscriber: 6-8 digits (total 7-11 digits after +54)
    regex = /^\+54[1-9]\d{7,11}$/;
  } else if (cleaned.startsWith('09')) {
    // National mobile: 0 9 [area] [subscriber]
    regex = /^09[1-9]\d{6,8}$/;
  } else if (cleaned.startsWith('0')) {
    // National landline: 0[area] [subscriber]
    regex = /^0[1-9]\d{7,11}$/;
  } else if (cleaned.length >= 7 && cleaned.length <= 11) {
    // Could be mobile without trunk prefix (9 first) or landline area code
    const firstChar = cleaned.charAt(0);
    if (firstChar === '9') {
      // Mobile: 9[area] [subscriber]  
      regex = /^[1-9]\d{6,8}$/;
    } else if (firstChar >= '1' && firstChar <= '9') {
      // Area code: [area] [subscriber]
      regex = /^[1-9]\d{7,11}$/;
    }
  }

  return regex ? regex.test(cleaned) : false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const trimmed = value.trim();

  // Must not be empty
  if (!trimmed) return false;

  // Must contain at least one letter
  const hasLetter = /[a-zA-Z\u00C0-\u024F]/.test(trimmed);
  if (!hasLetter) return false;

  // Check for obviously invalid patterns
  // Reject digits
  if (/\d/.test(trimmed)) return false;

  // Reject symbols that are not allowed (apostrophes, hyphens, spaces are allowed)
  // This regex allows unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}\s'\-]+$/u;

  if (!nameRegex.test(trimmed)) return false;

  // Additional validation: reject weird patterns like "X Æ A-12"
  // Check for sequences that look like code/gibberish
  if (/[0-9A-F]{2,}/i.test(trimmed)) return false;

  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
// Helper function for Luhn checksum validation
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');

  // Must have reasonable length (13-19 digits for major cards)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }

  // Check card type prefixes and lengths
  // Visa: starts with 4, length 13, 16, 19
  if (digits.startsWith('4')) {
    if (digits.length !== 13 && digits.length !== 16 && digits.length !== 19) {
      return false;
    }
  }
  // Mastercard: starts with 51-55, or 2221-2720
  else if (digits.startsWith('51') || digits.startsWith('52') || 
           digits.startsWith('53') || digits.startsWith('54') || 
           digits.startsWith('55') || (digits.startsWith('222') && parseInt(digits.substring(0, 4)) <= 2720)) {
    if (digits.length !== 16) {
      return false;
    }
  }
  // American Express: starts with 34 or 37, length 15
  else if ((digits.startsWith('34') || digits.startsWith('37')) && 
           digits.length === 15) {
    // Valid AmEx
  }
  else {
    // Other card types not specifically handled but plausible length
    if (digits.length < 13 || digits.length > 19) {
      return false;
    }
  }

  // Run Luhn checksum
  return runLuhnCheck(digits);
}
