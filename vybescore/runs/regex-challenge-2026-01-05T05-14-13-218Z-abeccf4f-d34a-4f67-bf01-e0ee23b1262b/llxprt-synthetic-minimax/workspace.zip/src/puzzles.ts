/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with the prefix
  // \\b ensures we match word boundaries
  const prefixRegex = new RegExp(`\\b${prefix}\\w*`, 'gi');
  
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const normalizedExceptions = exceptions.map(ex => ex.toLowerCase());
  
  return matches.filter(match => {
    const normalizedMatch = match.toLowerCase();
    return !normalizedExceptions.includes(normalizedMatch);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use lookbehind to ensure token comes after a digit
  // Use negative lookahead to ensure it's not at the start of the string
  const embeddedRegex = new RegExp(`(?<!^)\\d+${token}`, 'gi');
  
  const matches = text.match(embeddedRegex) || [];
  
  // Return the full matches including the digit
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) return false;
  
  // Must not contain whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol
  if (!/[!@#$%^&*()_+=[\\]{};':"\\|,.<>?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like "abab")
  // Look for patterns that repeat immediately (length 2 or more)
  const patternRegex = /(..+)\1/;
  if (patternRegex.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if this looks like an IPv4 address to exclude it
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // IPv6 patterns to match:
  // 1. Full IPv6 (8 groups of 4 hex digits): 2001:0db8:0000:0000:0000:ff00:0042:7879
  // 2. Shorthand IPv6 with ::: 2001:db8::ff00:42:7879, ::1, ::
  // 3. IPv6 with embedded IPv4: ::ffff:192.0.2.1
  
  // Pattern for IPv6 addresses
  const ipv6Patterns = [
    // Full IPv6 with 8 groups
    /\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b/i,

    // IPv6 with shorthand :: (allowing various positions)
    /\b(?:[a-fA-F0-9]{0,4}:){1,7}:/i,

    // IPv6 ending with :: followed by groups
    /:[a-fA-F0-9]{1,4}(?::[a-fA-F0-9]{1,4}){1,7}\b/i,

    // IPv6 with double colon anywhere
    /\b[a-fA-F0-9]{0,4}::(?:[a-fA-F0-9]{0,4}:){0,7}[a-fA-F0-9]{0,4}\b/i,

    // Shorthand patterns like ::1, ::, etc.
    /::(?:[a-fA-F0-9]{1,4})?/i
  ];
  
  // Test each IPv6 pattern
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
