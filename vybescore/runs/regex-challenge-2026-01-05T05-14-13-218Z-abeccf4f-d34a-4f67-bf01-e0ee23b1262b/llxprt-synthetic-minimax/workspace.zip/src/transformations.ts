/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ').trim();

  // Capitalize the first character of the text
  if (normalized.length > 0) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }

  // Find sentence boundaries (after . ? !) and capitalize following character
  // This regex looks for sentence endings followed by lowercase letters
  normalized = normalized.replace(/([.!?]\s*)([a-z\u00C0-\u024F])/g, 
    (match, sentenceEnd, nextChar) => {
      return sentenceEnd + nextChar.toUpperCase();
    }
  );

  return normalized;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that captures typical web URLs
  // Match http:// or https:// followed by domain/path until whitespace or end
  const urlRegex = /https?:\/\/[^\s"'<>]+/gi;

  const matches = text.match(urlRegex) || [];

  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation while preserving the URL
    return url.replace(/[.,!?]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave existing https:// untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  const httpUrlRegex = /http:\/\/([^\/\s]+)([^\s"'<>]*)/gi;

  return text.replace(httpUrlRegex, (match, host, path) => {
    let rewrittenUrl = 'https://' + host + path;
    
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    const hasDynamicHints = /[?&]|\.(?:jsp|php|asp|aspx|do|cgi|pl|py)(?=$|\?)/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host to docs.example.com for docs paths
      rewrittenUrl = 'https://docs.example.com' + path;
    }
    
    return rewrittenUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format with basic validation
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 2024 has 29 days in Feb
  
  // Check February leap year rule
  if (month === 2 && day === 29) {
    // Check if it's a leap year
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear) {
      return 'N/A';
    }
  } else if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // If all validations pass, return the year
  return year.toString();
}
