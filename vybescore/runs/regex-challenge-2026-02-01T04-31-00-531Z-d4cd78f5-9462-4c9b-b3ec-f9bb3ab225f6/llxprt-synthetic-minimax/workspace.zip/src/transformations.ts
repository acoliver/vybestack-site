/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Capitalize first character of each sentence
  // Pattern matches sentence endings and proper spacing
  return text.replace(/(^|[.!?]\s*)([a-zа-яё])/g, (match, separator, letter) => {
    return separator + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs, capturing common URL patterns
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"{}|\\^`[\]]+[^\s<>"{}|.,!?;:'"\)]*/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation and punctuation
  return matches.map(url => {
    // Remove trailing punctuation
    let cleaned = url.replace(/[.,!?;:'")\]]+$/, '');
    
    // Ensure protocol for www URLs
    if (cleaned.startsWith('www.')) {
      cleaned = 'http://' + cleaned;
    }
    
    return cleaned;
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch existing https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const httpUrlRegex = /http:\/\/([^\/\s]+)([^\s<>"{}|\\^`[\]]*)/gi;
  
  return text.replace(httpUrlRegex, (match, host, path) => {
    // Check for dynamic hints or legacy extensions that should skip host rewrite
    const hasDynamicHints = /(cgi-bin|\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
    
    // Always upgrade to https
    let newUrl = 'https://';
    
    if (hasDynamicHints) {
      // Skip host rewrite, just upgrade scheme
      newUrl += host + path;
    } else if (path.startsWith('/docs/')) {
      // Rewrite host to docs.hostname and preserve the original host structure
      const parts = host.split('.');
      if (parts.length >= 2) {
        newUrl += 'docs.' + parts.join('.') + path;
      } else {
        newUrl += host + path;
      }
    } else {
      // Regular URL, just upgrade scheme
      newUrl += host + path;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Check for mm/dd/yyyy format with validation
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';
  
  return year;
}
