export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that handles typical formats
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks to reject obviously invalid forms
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots in local part
  if (value.includes('..')) return false;
  
  // Reject trailing dots in domain
  if (value.match(/@.*\.$/)) return false;
  
  // Reject domains with underscores
  if (value.match(/@.*_.*\./)) return false;
  
  // Reject empty local or domain parts
  const parts = value.split('@');
  if (parts.length !== 2 || parts[0].length === 0 || parts[1].length === 0) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Must have 10-11 digits total
  const digitCount = value.replace(/\D/g, '').length;
  if (digitCount < 10 || digitCount > 11) return false;
  
  // Handle optional +1 prefix
  const phoneRegex = /^(?:\+?1)?[\s-.]?\(?([2-9][0-9]{2})\)?[\s-.]?[2-9][0-9]{2}[\s-.]?[0-9]{4}$/;
  
  if (!phoneRegex.test(value)) return false;
  
  // Extract area code to validate it's not 0 or 1
  const areaCodeMatch = value.match(/\(?([2-9][0-9]{2})\)?/);
  if (areaCodeMatch) {
    const areaCode = areaCodeMatch[1];
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input - remove spaces, hyphens, parentheses
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Handle optional country code +54
  let remaining = cleaned;
  if (remaining.startsWith('+54')) {
    remaining = remaining.slice(3);
  }
  
  // Handle optional trunk prefix 0
  let trunkPrefix = '';
  if (remaining.startsWith('0')) {
    trunkPrefix = '0';
    remaining = remaining.slice(1);
  }
  
  // Handle optional mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Now we should have area code + subscriber number
  const match = remaining.match(/^([1-9]\d{1,3})(\d{6,8})$/);
  
  if (!match) return false;
  
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits, leading digit 1-9 (already validated by regex)
  // Subscriber number must be 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // When country code is omitted, must begin with trunk prefix
  if (!value.includes('+54') && !trunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value.trim()) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and weird names like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}\p{Nd}\s'\-]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject if it contains digits
  if (/\d/.test(value)) return false;
  
  // Reject if it contains unusual symbols (we already filtered most with regex)
  // Additional check for weird patterns like "X Æ A-12"
  if (value.match(/[^\p{L}\p{M}\s'\-]/gu)) return false;
  
  // Must have at least 2 characters after trimming
  if (value.trim().length < 2) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits
  if (!/^\d{13,19}$/.test(cleaned)) return false;
  
  // Check card type based on prefix and length
  let isValidType = false;
  
  // Visa: starts with 4, 13-19 digits
  if (cleaned.startsWith('4') && cleaned.length >= 13 && cleaned.length <= 19) {
    isValidType = true;
  }
  // Mastercard: starts with 51-55, 16 digits
  else if (cleaned.match(/^5[1-5]/) && cleaned.length === 16) {
    isValidType = true;
  }
  // AmEx: starts with 34 or 37, 15 digits
  else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
