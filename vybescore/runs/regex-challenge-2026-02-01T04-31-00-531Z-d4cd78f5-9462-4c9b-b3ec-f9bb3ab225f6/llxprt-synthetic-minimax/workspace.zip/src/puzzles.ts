/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary pattern to match full words starting with prefix
  const prefixPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case insensitive)
  const result: string[] = [];
  const lowerExceptions = exceptions.map(e => e.toLowerCase());
  
  for (const match of matches) {
    const lowerMatch = match.toLowerCase();
    if (!lowerExceptions.includes(lowerMatch)) {
      result.push(match);
    }
  }
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token after a digit but not at string start
  // Negative lookbehind to ensure it's not at the beginning
  const pattern = new RegExp(`(?<!^)\\d${token}`, 'g');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) return false;
  
  // Must not contain whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) return false;
  
  // Must not have immediate repeated sequences (like "abab")
  if (/(..).*\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that handles various formats including shorthand ::
  // This pattern matches IPv6 addresses and ensures they're not IPv4
  const ipv6Regex = new RegExp(String.raw`\b(?:[a-f0-9]{1,4}:){1,7}[a-f0-9]{1,4}\b|\b(?:[a-f0-9]{1,4}:){0,7}::(?:[a-f0-9]{1,4}:){0,7}[a-f0-9]{1,4}\b|\b::(?:[a-f0-9]{1,4}:){0,7}[a-f0-9]{1,4}\b`, 'gi');
  
  // First check if there's an IPv6 pattern
  if (!ipv6Regex.test(value)) return false;
  
  // Now ensure it's not an IPv4 address (which could match if we include numbers)
  // IPv4 pattern to exclude
  const ipv4Regex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g;
  
  // If the text contains what looks like IPv4, don't consider it IPv6
  if (ipv4Regex.test(value)) return false;
  
  // Re-test with original pattern since regex.test modifies lastIndex
  ipv6Regex.lastIndex = 0;
  return ipv6Regex.test(value);
}
