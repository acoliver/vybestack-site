/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  beginTracking,
  endTracking,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  let isInitialized = false

  const getter: GetterFn<T> = () => {
    beginTracking()
    
    let newValue: T
    if (!isInitialized && value === undefined) {
      // First call without initial value - use updateFn with undefined to trigger defaults
      newValue = o.updateFn(undefined)
    } else {
      // Subsequent calls or with initial value
      newValue = o.updateFn(o.value)
    }
    
    endTracking()
    
    // Update stored value if changed
    if (newValue !== o.value) {
      o.value = newValue
    }
    
    isInitialized = true
    return o.value!
  }

  return getter
}
