/**
 * Encode plain text to Base64 using the canonical alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  // Validate that the input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for improper padding (padding characters in the middle)
  if (input.indexOf('=') !== -1 && !/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: improper padding');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
}
