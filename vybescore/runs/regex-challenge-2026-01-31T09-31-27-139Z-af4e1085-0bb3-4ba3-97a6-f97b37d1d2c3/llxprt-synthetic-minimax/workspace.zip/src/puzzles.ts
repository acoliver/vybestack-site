/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words starting with prefix
  // Use word boundary to match whole words
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(word => {
    return !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token that:
  // 1. Appears after a digit (use positive lookbehind)
  // 2. Not at the beginning (lookbehind automatically prevents start-of-string matches)
  // 3. Use token as literal string (escape special regex chars)
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Need to capture the digit as well since the test expects '1foo'
  const digitPattern = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = [];
  let match;
  
  while ((match = digitPattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Requirements:
  // - At least 10 characters
  // - One uppercase letter
  // - One lowercase letter
  // - One digit
  // - One symbol
  // - No whitespace
  // - No immediate repeated sequences (e.g., abab should fail)
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_\-+={[}\]|:;"'<>,.?/~`]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1231, etc.)
  // Pattern to find 2-character sequences that repeat immediately
  const repeatedPattern = /(..)\1/g;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  // Also check for longer patterns like ababab, 123123, etc.
  const longerPattern1 = /(...)\1/g;
  const longerPattern2 = /(....)\1/g;
  const longerPattern3 = /(.....)\1/g;
  
  if (longerPattern1.test(value) || longerPattern2.test(value) || longerPattern3.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern to detect IPv6 addresses
  // IPv6 addresses can be in full form or shorthand form using ::
  // Full form: 8 groups of 4 hex digits separated by colons
  // Shorthand form: :: for consecutive zeros
  
  // First, check for IPv4 patterns and exclude them
  const ipv4Pattern = /\b(\d{1,3}\.){3}\d{1,3}\b/g;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns:
  // 1. Full IPv6: groups of hex digits separated by colons
  const fullIPv6Pattern = /\b(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}\b/gi;
  
  // 2. Shorthand IPv6 with :: (allows zero compression)
  // This pattern matches :: followed by hex groups, or hex groups followed by ::, or middle ::
  const shorthandIPv6Pattern = /\b(?:[a-f0-9]{0,4}:?)*::(?:[a-f0-9]{0,4}:?)*\b/gi;
  
  // 3. Shorthand IPv6 with leading/trailing ::
  const leadingTrailingIPv6Pattern = /\b::[a-f0-9]*\b|\b[a-f0-9]*::\b/gi;
  
  // Check if any IPv6 pattern matches
  return fullIPv6Pattern.test(value) || shorthandIPv6Pattern.test(value) || leadingTrailingIPv6Pattern.test(value);
}
