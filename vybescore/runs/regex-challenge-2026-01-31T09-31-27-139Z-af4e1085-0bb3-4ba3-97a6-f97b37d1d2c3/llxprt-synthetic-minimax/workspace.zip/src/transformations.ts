/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, capitalize the first letter of the entire string if it starts with a letter
  let result = text;
  
  // Check if the string starts with a lowercase letter
  if (result.length > 0 && /^[a-z]/.test(result[0])) {
    result = result[0].toUpperCase() + result.substring(1);
  }
  
  // Then, capitalize letters that come after sentence endings
  const sentencePattern = /([.!?])\s*([a-z])/g;
  
  // Replace sentence endings with properly spaced and capitalized sentences
  result = result.replace(sentencePattern, (match, sentenceEnd, nextLetter) => {
    return sentenceEnd + ' ' + nextLetter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs without trailing punctuation
  // This pattern matches common URL formats including http/https and common TLDs
  const urlPattern = /\b(?:https?:\/\/)?(?:www\.)?(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s.,;:!?()]*)?/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Filter out trailing punctuation and clean URLs
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;:!?()]+$/, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Pattern to match http:// URLs (not https://)
  const httpPattern = /http:\/\/([^\s<>"]*)/g;
  
  // Replace http:// with https://
  return text.replace(httpPattern, 'https://$1');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // Group 1: host, Group 2: path
  const docsPattern = /http:\/\/([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(\/[^\s<>"]*)/g;
  
  return text.replace(docsPattern, (match, host, path) => {
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const hasDynamicHints = /(\?|=|&)|(\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
      
      if (hasDynamicHints) {
        // Only upgrade scheme, keep original host
        return 'https://' + match.substring(7); // Replace http:// with https://
      } else {
        // Upgrade scheme AND rewrite host to docs.domain
        return 'https://docs.' + host + path;
      }
    } else {
      // Not a docs path, just upgrade scheme
      return 'https://' + match.substring(7);
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format with valid month/day ranges
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Return the year as string
  return year.toString();
}
