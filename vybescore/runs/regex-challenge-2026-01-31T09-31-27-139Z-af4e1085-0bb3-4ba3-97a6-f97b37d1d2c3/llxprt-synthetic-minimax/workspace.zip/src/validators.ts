export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern for valid email addresses
  // - Local part: alphanumeric with possible +tags, no double dots, no trailing dots
  // - Domain: proper structure with no underscores
  const emailPattern = /^[a-zA-Z0-9]([a-zA-Z0-9._+~-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  return emailPattern.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, /* eslint-disable-line @typescript-eslint/no-unused-vars */ _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except the leading +
  const cleanValue = value.trim();
  
  // Check if there's a leading +
  const hasCountryCode = cleanValue.startsWith('+1');
  const phoneNumber = hasCountryCode ? cleanValue.substring(2) : cleanValue;
  
  // Remove all non-digit characters
  const digitsOnly = phoneNumber.replace(/\D/g, '');
  
  // Must have 10 digits total
  if (digitsOnly.length !== 10) {
    return false;
  }
  
  // Check area code doesn't start with 0 or 1
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check format matches one of the acceptable patterns
  if (hasCountryCode) {
    // Format: +1 212-555-7890, +12125557890
    return /^\+1\d{10}$/.test(value.replace(/\s/g, ''));
  } else {
    // Check if it matches any of these patterns:
    // 1. (212) 555-7890
    // 2. 212-555-7890
    // 3. 2125557890
    const digitFormat = digitsOnly;
    return /^[2-9]\d{2}[2-9]\d{6}$/.test(digitFormat);
  }
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input: remove spaces, parentheses, and common separators for validation
  const cleanValue = value.trim().replace(/[\s()-]/g, '');
  
  // Check if value has country code
  const hasCountryCode = cleanValue.startsWith('+54');
  
  if (hasCountryCode) {
    // With country code: +54[optional mobile 9][optional trunk 0][area code][subscriber]
    // - Country code: +54
    // - Optional mobile indicator: 9 (for mobile numbers)
    // - Optional trunk prefix: 0 (but if no mobile indicator, directly after country code)
    // - Area code: 2-4 digits, first digit 1-9
    // - Subscriber: 6-8 digits
    
    const withoutCountry = cleanValue.substring(3); // Remove +54
    
    // Check for mobile indicator
    if (withoutCountry.startsWith('9')) {
      // Mobile format: +549[optional trunk 0][area code][subscriber]
      const mobilePattern = /^\+549[01]?[1-9]\d{1,3}\d{6,8}$/;
      return mobilePattern.test(value.replace(/\s/g, ''));
    } else {
      // Landline format: +540[area code][subscriber] OR +54[area code][subscriber]
      const landlinePattern1 = /^\+540[1-9]\d{1,3}\d{6,8}$/;
      const landlinePattern2 = /^\+54[1-9]\d{1,3}\d{6,8}$/;
      return landlinePattern1.test(value.replace(/\s/g, '')) || 
             landlinePattern2.test(value.replace(/\s/g, ''));
    }
  } else {
    // Without country code: must start with trunk prefix 0
    // Format: 0[area code][subscriber]
    // - Trunk prefix: 0
    // - Area code: 2-4 digits, first digit 1-9  
    // - Subscriber: 6-8 digits
    return /^(?![+])0[1-9]\d{1,3}\d{6,8}$/.test(cleanValue);
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern for valid names:
  // - Unicode letters (including accents)
  // - Spaces, apostrophes, hyphens
  // - Must contain at least one letter
  // - No digits, no special symbols except apostrophe and hyphen
  
  // Remove leading/trailing spaces for validation
  const trimmedValue = value.trim();
  
  if (trimmedValue.length === 0) {
    return false;
  }
  
  // Pattern: Allow unicode letters, spaces, apostrophes, and hyphens
  // Must start and end with a letter
  const namePattern = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  
  if (!namePattern.test(trimmedValue)) {
    return false;
  }
  
  // Reject if it contains digits or symbols other than space, apostrophe, hyphen
  const forbiddenPattern = /[\d\u0030-\u0039]/;
  if (forbiddenPattern.test(trimmedValue)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check card type and valid prefixes/lengths
  let validPattern = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (cleanValue.startsWith('4')) {
    if (cleanValue.length === 13 || cleanValue.length === 16 || cleanValue.length === 19) {
      validPattern = true;
    }
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if (cleanValue.length === 16) {
    const firstTwo = cleanValue.substring(0, 2);
    const firstFour = cleanValue.substring(0, 4);
    
    if ((firstTwo >= '51' && firstTwo <= '55') || 
        (firstFour >= '2221' && firstFour <= '2720')) {
      validPattern = true;
    }
  }
  
  // AmEx: starts with 34 or 37, length 15
  if (cleanValue.length === 15 && (cleanValue.startsWith('34') || cleanValue.startsWith('37'))) {
    validPattern = true;
  }
  
  if (!validPattern) {
    return false;
  }
  
  // Run Luhn algorithm
  return luhnCheck(cleanValue);
}

// Luhn checksum algorithm
function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
