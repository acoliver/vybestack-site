// Validates that input is valid Base64 (RFC 4648)
function isValidBase64(input: string): boolean {
  // Empty string is considered valid Base64
  if (input.length === 0) {
    return true;
  }
  
  // Check for valid Base64 characters: A-Z, a-z, 0-9, +, /, and optional padding =
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  // Check for invalid characters
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check for valid padding placement and count
  const actualPaddingLength = input.split('').filter(char => char === '=').length;
  
  // Valid padding can be 0, 1, or 2 characters and must be at the end
  if (actualPaddingLength > 0) {
    const hasPaddingInMiddle = input.slice(0, -actualPaddingLength).includes('=');
    if (hasPaddingInMiddle) {
      return false;
    }
  }
  
  // Check length divisibility by 4 (considering padding)
  const lengthWithoutPadding = input.replace(/=/g, '').length;
  return lengthWithoutPadding % 4 !== 1; // Valid lengths: 0, 2, 3 mod 4
}

/**
 * Encode plain text to Base64 using canonical RFC 4648 Base64 encoding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates that the input is valid Base64 (RFC 4648).
 */
export function decode(input: string): string {
  // Validate input first
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
