const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Check if padding is valid.
 * @throws {Error} If padding structure is invalid.
 */
function validatePadding(input: string, paddingMatch: RegExpMatchArray | null): void {
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
  }

  // Check for incorrect padding placement (padding not at the end)
  const nonEndPadding = input.indexOf('=');
  if (nonEndPadding !== -1 && nonEndPadding !== input.length - (paddingMatch?.[0].length || 0)) {
    throw new Error('Invalid Base64 input: padding not at the end');
  }

  // Additional validation: check for invalid Base64 sequences when padding is present
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    const dataLength = input.length - paddingLength;
    
    // After removing padding, we must have at least 2 characters
    if (dataLength < 2) {
      throw new Error('Invalid Base64 input: insufficient data');
    }
    
    // With 2 padding chars (==), we need exactly 2 base64 chars before padding
    // This represents a single byte (12 bits, with only 8 used)
    if (paddingLength === 2 && dataLength % 4 !== 2) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }
}

/**
 * Validate Base64 input.
 * @throws {Error} If the input contains characters outside the Base64 alphabet or has structural issues.
 */
function validateBase64(input: string): void {
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  const paddingMatch = input.match(/=+$/);
  validatePadding(input, paddingMatch);
}

/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * @throws {Error} If the input is not valid Base64.
 */
export function decode(input: string): string {
  // Validate input before attempting to decode
  validateBase64(input);

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if decoding produced valid output
    // If the input was invalid, Buffer.from may return an empty buffer
    if (input.length > 0 && buffer.length === 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
