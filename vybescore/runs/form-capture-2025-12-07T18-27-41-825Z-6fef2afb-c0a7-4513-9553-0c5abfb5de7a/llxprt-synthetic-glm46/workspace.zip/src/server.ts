import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { promises as fs } from 'fs';
// @ts-expect-error - sql.js doesn't provide TypeScript definitions
import initSqlJs from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

interface Database {
  prepare(sql: string): {
    run(...args: unknown[]): void;
    get(...args: unknown[]): unknown;
    all(): unknown[];
    free(): void;
  };
  run(sql: string, ...params: unknown[]): { changes: number; lastInsertRowid: number };
  export(): Uint8Array;
  close(): void;
}

interface SqlJsStatic {
  Database: new (data?: Uint8Array | null) => Database;
}

// Get the current directory name for ES modules
const currentDir = path.dirname(fileURLToPath(import.meta.url));

const PORT = process.env.PORT || 3535;
const DB_PATH = path.join(currentDir, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(currentDir, '..', 'db', 'schema.sql');
const PUBLIC_DIR = path.join(currentDir, '..', 'public');
const VIEWS_DIR = path.join(currentDir, '..', 'src', 'templates');

let SQLite: SqlJsStatic | null = null;
let db: Database | null = null;
const isShuttingDown = false; // Constant, as the app uses process-level shutdown

async function initializeDatabase(): Promise<void> {
  try {
    SQLite = await initSqlJs();
    
    let dbData = null;
    try {
      const dbFile = await fs.readFile(DB_PATH);
      dbData = dbFile;
    } catch (error) {
      // Database file doesn't exist, will be created
      console.log('Database file not found, creating new database...');
    }
    
    if (SQLite) {
      db = new SQLite.Database(dbData);
    }
    
    // Ensure table exists
    const schemaContent = await fs.readFile(SCHEMA_PATH, 'utf8');
    if (db) {
      db.run(schemaContent);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

async function saveDatabase(): Promise<void> {
  if (!db || isShuttingDown) return;
  
  try {
    const data = db.export();
    await fs.writeFile(DB_PATH, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province is required' });
  }
  
  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  } else if (!/^[A-Za-z0-9-]+$/.test(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, numbers, spaces, and hyphens' });
  }
  
  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^\+?[0-9\-\\s()]+$/.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number must contain only digits, spaces, parentheses, hyphens, and an optional leading +' });
  }
  
  return errors;
}

function createApp(): express.Express {
  const app = express();
  
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(PUBLIC_DIR));
  app.set('view engine', 'ejs');
  app.set('views', VIEWS_DIR);
  
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      errors: [], 
      formData: {} as FormData,
      submitted: false
    });
  });
  
  app.post('/submit', (req: Request, res: Response, next: NextFunction) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };
    
    const errors = validateFormData(formData);
    
    if (errors.length > 0) {
      res.status(400).render('form', { 
        errors, 
        formData,
        submitted: false
      });
      return;
    }
    
    try {
      if (!db) {
        throw new Error('Database not initialized');
      }
      
      const stmt = db.prepare(`
        INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      
      saveDatabase().then(() => {
        res.redirect('/thank-you');
      }).catch(next);
      
    } catch (error) {
      console.error('Database error:', error);
      errors.push({ field: 'general', message: 'Failed to save your submission. Please try again.' });
      res.status(500).render('form', { 
        errors, 
        formData,
        submitted: false
      });
    }
  });
  
  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you');
  });
  
  app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
    console.error('Unhandled error:', err);
    next(err);
  });
  
  return app;
}

async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    const server = createApp();
    server.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();