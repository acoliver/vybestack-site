export interface Database {
  prepare(sql: string): {
    run(...args: unknown[]): void;
    get(...args: unknown[]): unknown;
    all(): unknown[];
    free(): void;
  };
  run(sql: string, ...params: unknown[]): { changes: number; lastInsertRowid: number };
  export(): Uint8Array;
  close(): void;
}

export interface SqlJsStatic {
  Database: new (data?: Uint8Array | null) => Database;
}

declare module 'sql.js' {
  export default function initSqlJs(): Promise<SqlJsStatic>;
}