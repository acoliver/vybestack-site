import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export async function startTestServer() {
  try {
    // Build the server
    await execAsync('npm run build');
    
    // Import and start the server
    process.env.PORT = '3536'; // Use a different port for tests
    await import('../../dist/server.js');
    
    // Wait for server to start
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    return true;
  } catch (error) {
    console.error('Failed to start test server:', error);
    return false;
  }
}

export async function stopTestServer() {
  process.kill(parseInt(process.pid), 'SIGTERM');
  await new Promise(resolve => setTimeout(resolve, 1000));
}