/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  notifyDependents,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = 
    typeof equal === 'function' ? equal : 
    equal === false ? undefined : 
    equal === true ? ((a: T, b: T) => a === b) : 
    undefined

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !equalFn || !equalFn(s.value, nextValue)
    if (shouldUpdate) {
      s.value = nextValue
      // Create a copy to avoid issues with observers being modified during iteration
      const observersCopy = Array.from(s.observers)
      observersCopy.forEach(observer => {
        updateObserver(observer as Observer<unknown>)
        notifyDependents(observer as Observer<unknown>)
      })
    }
    return s.value
  }

  return [read, write]
}
