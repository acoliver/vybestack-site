/**
 * Encode plain text to Base64 using RFC 4648 standard.
 * Uses the canonical Base64 alphabet with required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and throws errors for invalid input.
 */
export function decode(input: string): string {
  // Basic validation for Base64 format
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Check for valid Base64 characters (ignoring whitespace)
  const cleanedInput = input.replace(/\s/g, '');
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Regex.test(cleanedInput)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for correct padding length
  const paddingLength = cleanedInput.length % 4;
  if (paddingLength === 1) {
    throw new Error('Invalid Base64 input: incorrect padding length');
  }

  // Validate padding format
  const paddingIndex = cleanedInput.indexOf('=');
  if (paddingIndex !== -1) {
    // If there's padding, ensure it's only at the end
    const paddingSection = cleanedInput.substring(paddingIndex);
    if (!/^=+$/.test(paddingSection)) {
      throw new Error('Invalid Base64 input: padding must be at the end');
    }
    // Ensure no non-padding characters after padding starts
    if (paddingIndex + paddingSection.length !== cleanedInput.length) {
      throw new Error('Invalid Base64 input: characters after padding');
    }
  }

  try {
    // Buffer will handle padding automatically for valid inputs
    return Buffer.from(cleanedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
