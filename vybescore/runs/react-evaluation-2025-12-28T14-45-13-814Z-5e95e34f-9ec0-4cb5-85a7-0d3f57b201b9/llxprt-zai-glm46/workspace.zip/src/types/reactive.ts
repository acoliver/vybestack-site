/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  onInvalidate?: () => void
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Set<ReactiveNode>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<ObserverNode>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Type erasure for storage in Sets
export type ObserverNode = {
  name?: string
  value?: unknown
  updateFn: UpdateFn<unknown>
  dependencies?: Set<ReactiveNode>
  onInvalidate?: () => void
}

export type ReactiveNode = {
  name?: string
  value?: unknown
  updateFn?: UpdateFn<unknown>
  observers?: Set<ObserverNode>
}

let activeObserver: ObserverNode | undefined

export function getActiveObserver(): ObserverNode | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverNode): void {
  activeObserver = observer
}

export function clearActiveObserver(): void {
  activeObserver = undefined
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as ObserverNode
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (subject.observers) {
    // Create a copy to avoid issues if the set is modified during iteration
    const observers = Array.from(subject.observers)
    for (const observer of observers) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}
