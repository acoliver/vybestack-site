/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  ObserverNode,
  getActiveObserver,
  setActiveObserver,
  clearActiveObserver,
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const observer: ObserverNode = {
    name: options?.name,
    value,
    updateFn: updateFn as UpdateFn<unknown>,
    dependencies: new Set(),
  }
  
  // Create the subject for this computed value
  const subject = {
    name: options?.name,
    observers: new Set<ObserverNode>(),
    value: value as unknown,
  }
  
  const getter = (): T => {
    const active = getActiveObserver()
    if (active) {
      // Register this computed as a dependency of the active observer
      if (active.dependencies === undefined) {
        active.dependencies = new Set()
      }
      active.dependencies.add(subject)
    }
    return subject.value as T
  }
  
  // Function to update this computed value
  const compute = () => {
    // Clear old dependencies - but we need to preserve this subject's observers
    const oldDependencies = observer.dependencies
    observer.dependencies = new Set()
    
    // Set this as active observer to track dependencies
    setActiveObserver(observer)
    
    try {
      // Recompute value
      subject.value = (updateFn as (prev?: T) => T)(subject.value as T)
      
      // Remove from old dependencies' observers
      if (oldDependencies) {
        for (const dep of oldDependencies) {
          if (dep.observers) {
            dep.observers.delete(observer)
          }
        }
      }
      
      // Add to new dependencies' observers
      if (observer.dependencies) {
        for (const dep of observer.dependencies) {
          if (!dep.observers) {
            dep.observers = new Set()
          }
          dep.observers.add(observer)
        }
      }
      
      // Notify all observers of this computed
      if (subject.observers) {
        const observers = Array.from(subject.observers)
        for (const obs of observers) {
          updateObserver(obs)
        }
      }
    } finally {
      clearActiveObserver()
    }
  }
  
  // Store compute function on observer for notification
  observer.updateFn = (() => {
    compute()
    return subject.value
  }) as UpdateFn<unknown>
  
  // Initial computation
  compute()
  
  return getter
}
