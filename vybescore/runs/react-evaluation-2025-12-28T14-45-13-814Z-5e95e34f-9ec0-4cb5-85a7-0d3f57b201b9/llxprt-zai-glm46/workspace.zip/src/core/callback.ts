/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  ObserverNode,
  setActiveObserver,
  clearActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  // Function to run the callback and track dependencies
  const run = () => {
    // Clear old dependencies
    const oldDependencies = observer.dependencies
    observer.dependencies = new Set()
    
    // Set this as active observer to track dependencies
    setActiveObserver(observer as ObserverNode)
    
    try {
      // Execute the callback
      observer.value = observer.updateFn(observer.value)
      
      // Remove from old dependencies' observers
      if (oldDependencies) {
        for (const dep of oldDependencies) {
          if (dep.observers) {
            dep.observers.delete(observer as ObserverNode)
          }
        }
      }
      
      // Add to new dependencies' observers
      if (observer.dependencies) {
        for (const dep of observer.dependencies) {
          if (!dep.observers) {
            dep.observers = new Set()
          }
          dep.observers.add(observer as ObserverNode)
        }
      }
    } finally {
      clearActiveObserver()
    }
  }
  
  // Initial call to track dependencies and execute callback
  run()
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear dependencies to stop further updates
    if (observer.dependencies) {
      for (const dep of observer.dependencies) {
        if (dep.observers) {
          dep.observers.delete(observer as ObserverNode)
        }
      }
      observer.dependencies.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
