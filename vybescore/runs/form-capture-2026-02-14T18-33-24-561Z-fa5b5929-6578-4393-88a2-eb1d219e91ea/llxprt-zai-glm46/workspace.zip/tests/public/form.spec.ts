import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';

let server: { close: () => void } | null = null;
let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  const { app: expressApp, dbManager, start } = await import('../../src/server');
  app = expressApp;

  // Initialize database
  await dbManager.initialize();

  // Start the server
  const serverInstance = await start();
  server = serverInstance as { close: () => void };
});

afterAll(async () => {
  if (server && server.close) {
    server.close();
  }
  // Close database connection
  const { dbManager } = await import('../../src/server');
  dbManager.close();
});

describe('friendly form (public smoke)', () => {
  it('renders form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Get in Touch');

    const cheerio = await import('cheerio');
    const $ = cheerio.load(response.text);
    expect($('input[name="first_name"]')).toHaveLength(1);
    expect($('input[name="last_name"]')).toHaveLength(1);
    expect($('input[name="street_address"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="state_province"]')).toHaveLength(1);
    expect($('input[name="postal_code"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    expect($('label[for="first_name"]').text()).toBe('First Name');
    expect($('label[for="email"]').text()).toBe('Email');
  });

  it('persists submission and redirects', async () => {
    const formData = {
      first_name: 'Jane',
      last_name: 'Doe',
      street_address: '123 Baker Street',
      city: 'London',
      state_province: 'England',
      postal_code: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.doe@example.com',
      phone: '@44 20 7946 0958',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid input', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        first_name: '',
        last_name: '',
        email: 'not-an-email',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
    expect(response.text).toContain('valid email');
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank You');
  });
});
