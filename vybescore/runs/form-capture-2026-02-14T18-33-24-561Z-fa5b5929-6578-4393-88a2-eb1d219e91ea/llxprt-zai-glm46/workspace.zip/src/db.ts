import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

export interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private SQL: SqlJsStatic | null = null;
  private dbPath: string;
  private schema: string;

  constructor(dbPath: string, schemaPath: string) {
    this.dbPath = dbPath;
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    this.schema = schema;
  }

  async initialize(): Promise<void> {
    // If already initialized, do nothing
    if (this.db) {
      return;
    }

    this.SQL = await initSqlJs();

    const dbDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }

    if (fs.existsSync(this.dbPath)) {
      const buffer = fs.readFileSync(this.dbPath);
      const arrayBuffer = buffer.buffer.slice(
        buffer.byteOffset,
        buffer.byteOffset + buffer.byteLength
      ) as ArrayBuffer;
      this.db = new this.SQL.Database(arrayBuffer);
    } else {
      this.db = new this.SQL.Database();
      // Execute the schema to create tables - use exec() for multiple statements
      this.db.exec(this.schema);
      await this.save();
    }
  }

  async save(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    const data = this.db.export();
    // Convert Uint8Array to Buffer properly
    const buffer = Buffer.from(data);
    fs.writeFileSync(this.dbPath, buffer);
  }

  insertSubmission(data: SubmissionData): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city,
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone,
    ]);

    stmt.free();
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}
