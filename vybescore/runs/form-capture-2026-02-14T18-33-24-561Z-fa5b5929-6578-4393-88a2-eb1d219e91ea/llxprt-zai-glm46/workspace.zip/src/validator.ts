export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

export interface FormInput {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export function validateForm(input: FormInput): ValidationResult {
  const errors: Record<string, string> = {};

  if (!input.first_name || input.first_name.trim() === '') {
    errors.first_name = 'First name is required';
  }

  if (!input.last_name || input.last_name.trim() === '') {
    errors.last_name = 'Last name is required';
  }

  if (!input.street_address || input.street_address.trim() === '') {
    errors.street_address = 'Street address is required';
  }

  if (!input.city || input.city.trim() === '') {
    errors.city = 'City is required';
  }

  if (!input.state_province || input.state_province.trim() === '') {
    errors.state_province = 'State/Province/Region is required';
  }

  if (!input.postal_code || input.postal_code.trim() === '') {
    errors.postal_code = 'Postal/Zip code is required';
  } else if (!/^[A-Za-z0-9\s-]+$/.test(input.postal_code.trim())) {
    errors.postal_code = 'Postal code must contain only letters, digits, spaces, and hyphens';
  }

  if (!input.country || input.country.trim() === '') {
    errors.country = 'Country is required';
  }

  if (!input.email || input.email.trim() === '') {
    errors.email = 'Email is required';
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(input.email.trim())) {
      errors.email = 'Please enter a valid email address';
    }
  }

  if (!input.phone || input.phone.trim() === '') {
    errors.phone = 'Phone number is required';
  } else {
    const phoneRegex = /^@?[\d\s()-]+$/;
    if (!phoneRegex.test(input.phone.trim())) {
      errors.phone = 'Phone number may contain digits, spaces, parentheses, dashes, and a leading @';
    }
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}
