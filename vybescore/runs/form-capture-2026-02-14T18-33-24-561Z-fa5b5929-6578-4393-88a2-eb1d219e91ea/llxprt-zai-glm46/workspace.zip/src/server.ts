import express, { Request, Response } from 'express';
import path from 'node:path';
import { DatabaseManager, type SubmissionData } from './db.js';
import { validateForm, type FormInput } from './validator.js';

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

const app = express();
const dbManager = new DatabaseManager(DB_PATH, SCHEMA_PATH);

app.set('view engine', 'ejs');
// Always use src/views since templates don't need compilation
app.set('views', path.join(process.cwd(), 'src', 'views'));
app.use(express.static(path.join(process.cwd(), 'public')));
app.use(express.urlencoded({ extended: true }));

interface TypedRequest extends Request {
  body: FormInput;
}

app.get('/', (_req: Request, res: Response) => {
  res.render('form.ejs');
});

app.post('/submit', async (req: TypedRequest, res: Response) => {
  const validation = validateForm(req.body);

  if (!validation.valid) {
    return res.status(400).render('form.ejs', {
      errors: validation.errors,
      formData: req.body,
    });
  }

  const submission: SubmissionData = {
    first_name: req.body.first_name!.trim(),
    last_name: req.body.last_name!.trim(),
    street_address: req.body.street_address!.trim(),
    city: req.body.city!.trim(),
    state_province: req.body.state_province!.trim(),
    postal_code: req.body.postal_code!.trim(),
    country: req.body.country!.trim(),
    email: req.body.email!.trim(),
    phone: req.body.phone!.trim(),
  };

  dbManager.insertSubmission(submission);
  await dbManager.save();

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you.ejs');
});

async function start() {
  await dbManager.initialize();

  const server = app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  const shutdown = async (signal: string) => {
    console.log(`Received ${signal}, shutting down gracefully...`);
    server.close(() => {
      dbManager.close();
      process.exit(0);
    });

    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000).unref();
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  return server;
}

// Only start the server if this file is run directly (not when imported)
const isMainModule = import.meta.url === `file://${process.argv[1]}`;

if (isMainModule) {
  start().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { app, dbManager, start };
