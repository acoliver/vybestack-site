#!/usr/bin/env node

import * as fs from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportOptions, FormatType } from '../types.js';
import { readJsonFile, parseCliArgs } from '../utils.js';

try {
  const args = parseCliArgs(process.argv);
  
  // Validate format
  const supportedFormats: FormatType[] = ['markdown', 'text'];
  if (!supportedFormats.includes(args.format as FormatType)) {
    throw new Error(`Unsupported format: ${args.format}. Supported formats: ${supportedFormats.join(', ')}`);
  }
  
  // Read and parse the JSON data
  const data = readJsonFile(args.dataPath);
  
  // Render the report based on format
  const options: ReportOptions = { includeTotals: args.includeTotals };
  let output: string;
  
  switch (args.format as FormatType) {
    case 'markdown':
      output = renderMarkdown(data, options);
      break;
    case 'text':
      output = renderText(data, options);
      break;
    default:
      // This should never happen due to the validation above
      throw new Error(`Unsupported format: ${args.format}`);
  }
  
  // Output the report
  if (args.outputPath) {
    fs.writeFileSync(args.outputPath, output, 'utf8');
    console.error(`Report written to: ${args.outputPath}`);
  } else {
    console.log(output);
  }
} catch (error) {
  console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
  process.exit(1);
}