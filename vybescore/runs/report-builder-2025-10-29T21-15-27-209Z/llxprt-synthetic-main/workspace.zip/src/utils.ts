import type { ReportData } from './types.js';

import * as fs from 'fs';
import * as path from 'path';

export function readJsonFile(filePath: string): ReportData {
  try {
    // Using Node's built-in modules only
    
    if (!fs.existsSync(filePath)) {
      throw new Error(`File not found: ${path.resolve(filePath)}`);
    }
    
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent);
    
    // Validate the data structure
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: Expected an object');
    }
    
    if (typeof data.title !== 'string') {
      throw new Error('Invalid data: Missing or invalid "title" property (expected string)');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Invalid data: Missing or invalid "summary" property (expected string)');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: Missing or invalid "entries" property (expected array)');
    }
    
    for (const entry of data.entries) {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error('Invalid entry: Each entry must be an object');
      }
      
      if (typeof entry.label !== 'string') {
        throw new Error('Invalid entry: Each entry must have a "label" property (string)');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Invalid entry: Each entry must have an "amount" property (number)');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${filePath}. Error: ${error.message}`);
    }
    throw error;
  }
}

export function parseCliArgs(argv: string[]): {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (argv.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const args = argv.slice(2); // Skip node and script path
  const result = {
    dataPath: '',
    format: '',
    outputPath: undefined as string | undefined,
    includeTotals: false,
  };
  
  // First argument should be the data path
  result.dataPath = args[0];
  
  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (++i >= args.length) {
          throw new Error('--format argument requires a value');
        }
        result.format = args[i];
        break;
      case '--output':
        if (++i >= args.length) {
          throw new Error('--output argument requires a value');
        }
        result.outputPath = args[i];
        break;
      case '--includeTotals':
        result.includeTotals = true;
        break;
      default:
        throw new Error(`Unknown argument: ${args[i]}`);
    }
  }
  
  if (!result.dataPath) {
    throw new Error('Data file path is required');
  }
  
  if (!result.format) {
    throw new Error('--format argument is required');
  }
  
  return result;
}