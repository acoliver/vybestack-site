import type { ReportData, ReportOptions } from '../types.js';

export function renderText(data: ReportData, options: ReportOptions): string {
  const output: string[] = [];
  
  // Add title
  output.push(data.title);
  output.push('');
  
  // Add summary
  output.push(data.summary);
  output.push('');
  
  // Add entries section
  output.push('Entries:');
  
  // Add each entry as a bullet point
  for (const entry of data.entries) {
    output.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }
  
  // Add total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output.push('');
    output.push(`Total: $${total.toFixed(2)}`);
  }
  
  return output.join('\n');
}