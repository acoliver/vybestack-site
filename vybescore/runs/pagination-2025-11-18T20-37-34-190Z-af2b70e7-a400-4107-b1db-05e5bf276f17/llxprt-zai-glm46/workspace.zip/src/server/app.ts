import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Input validation for page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (isNaN(pageNum) || pageNum <= 0 || !Number.isInteger(pageNum)) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer.' });
      }
      page = pageNum;
    }

    // Input validation for limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (isNaN(limitNum) || limitNum <= 0 || !Number.isInteger(limitNum) || limitNum > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer not exceeding 100.' });
      }
      limit = limitNum;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
