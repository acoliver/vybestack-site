export interface Database {
  prepare(sql: string): Statement;
  run(sql: string): void;
  export(): Uint8Array;
  close(): void;
}

export interface Statement {
  run(params: Array<unknown>): void;
  free(): void;
}

export default function initSqlJs(config?: { locateFile: (file: string) => string }): Promise<{ Database: new (data?: Uint8Array) => Database }>;