import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

// Get directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import sql.js
import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';

// Initialize Express app
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates'));

// Initialize database
let db: Database;
const dbPath = path.resolve(__dirname, '../data', 'submissions.sqlite');

// Export app for tests
(global as unknown as { app: unknown }).app = app;

async function initDb() {
  const SQL = await initSqlJs({
    locateFile: (file: string) => path.join(__dirname, '../node_modules/sql.js/dist', file)
  });
  
  // Ensure data directory exists
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  try {
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(path.resolve(__dirname, '../db', 'schema.sql'), 'utf8');
      db.run(schema);
    }
  } catch (error) {
    console.error('Database initialization error:', error);
    process.exit(1);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accepts international formats with digits, spaces, parentheses, dashes and leading +
  const phoneRegex = /^[+\d\s()-]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accepts alphanumeric postal codes with spaces and dashes (for international formats)
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  } = req.body;

  const errors: string[] = [];
  const values = req.body;

  console.log('Received form data:', req.body);

  // Validation
  if (!firstName || firstName.trim() === '') errors.push('First name is required');
  if (!lastName || lastName.trim() === '') errors.push('Last name is required');
  if (!streetAddress || streetAddress.trim() === '') errors.push('Street address is required');
  if (!city || city.trim() === '') errors.push('City is required');
  if (!stateProvince || stateProvince.trim() === '') errors.push('State/Province is required');
  if (!postalCode || postalCode.trim() === '') {
    errors.push('Postal code is required');
  } else if (!validatePostalCode(postalCode)) {
    errors.push('Postal code format is invalid');
  }
  if (!country || country.trim() === '') errors.push('Country is required');
  if (!email || email.trim() === '') {
    errors.push('Email is required');
  } else if (!validateEmail(email)) {
    errors.push('Please enter a valid email address');
  }
  if (!phone || phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!validatePhone(phone)) {
    errors.push('Phone number format is invalid');
  }

  // If validation fails, re-render form with errors and values
  if (errors.length > 0) {
    console.log('Validation errors:', errors);
    return res.status(400).render('form', { errors, values });
  }

  // Insert submission into database
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run([
      firstName,
      lastName,
      streetAddress,
      city,
      stateProvince,
      postalCode,
      country,
      email,
      phone
    ]);
    stmt.free();

    // Export database to file
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);

    // Redirect to thank-you page
    res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(firstName));
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', { 
      errors: ['An error occurred while processing your submission'], 
      values 
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = (req.query.firstName as string) || 'Friend';
  res.render('thank-you', { firstName });
});

// Initialize database
initDb().then(() => {
  // Only start server if this file is run directly (not imported)
  if (import.meta.url === `file://${process.argv[1]}`) {
    const server = app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
    
    // Graceful shutdown on SIGTERM
    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully...');
      server.close(() => {
        console.log('Server closed');
        if (db) {
          // Export database before closing
          const data = db.export();
          const buffer = Buffer.from(data);
          fs.writeFileSync(dbPath, buffer);
          db.close();
        }
        console.log('Database closed');
        process.exit(0);
      });
    });
    
    // Export server for tests
    (global as unknown as { server: unknown }).server = server;
  }
}).catch(error => {
  console.error('Failed to initialize database:', error);
  process.exit(1);
});

export default app;