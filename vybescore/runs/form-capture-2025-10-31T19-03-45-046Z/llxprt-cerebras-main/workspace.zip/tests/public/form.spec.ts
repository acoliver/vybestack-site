import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: unknown;
let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Ensure data directory exists
  const dataDir = path.resolve('data');
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Dynamically import the server
  await import('../../dist/server.js');
  app = (global as unknown as { app: unknown }).app;
});

afterAll(() => {
  if (server && typeof server.close === 'function') {
    server.close();
  }
  
  // Clean up database file after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = load(response.text);
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'Anystate',
        postalCode: '12345',
        country: 'USA',
        email: 'john@example.com',
        phone: '+1-555-123-4567'
      });
      
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you?firstName=John');
  });
  
  it('shows validation errors for invalid email', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'Anystate',
        postalCode: '12345',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1-555-123-4567'
      });
      
    expect(response.status).toBe(400);
    const $ = load(response.text);
    expect($('.error-list')).toHaveLength(1);
    const errorTexts = $('.error-list li').map((i, el) => load(el).text()).get();
    expect(errorTexts).toContain('Please enter a valid email address');
  });
  
  it('shows validation errors for invalid phone', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'Anystate',
        postalCode: '12345',
        country: 'USA',
        email: 'john@example.com',
        phone: 'invalid-phone'
      });
      
    expect(response.status).toBe(400);
    const $ = load(response.text);
    expect($('.error-list')).toHaveLength(1);
    const errorTexts = $('.error-list li').map((i, el) => load(el).text()).get();
    expect(errorTexts).toContain('Phone number format is invalid');
  });
  
  it('shows validation errors for invalid postal code', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'Anystate',
        postalCode: 'invalid@code',
        country: 'USA',
        email: 'john@example.com',
        phone: '+1-555-123-4567'
      });
      
    expect(response.status).toBe(400);
    const $ = load(response.text);
    expect($('.error-list')).toHaveLength(1);
    const errorTexts = $('.error-list li').map((i, el) => load(el).text()).get();
    expect(errorTexts).toContain('Postal code format is invalid');
  });
  
  it('shows validation errors for missing required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({});
      
    expect(response.status).toBe(400);
    const $ = load(response.text);
    expect($('.error-list')).toHaveLength(1);
    expect($('.error-list li')).toHaveLength(9); // All required fields missing
  });
  
  it('handles international postal codes and phone numbers', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // UK postal code
    let response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Park Lane',
        city: 'London',
        stateProvince: 'Greater London',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'jane@example.com',
        phone: '+44 20 7946 0958'
      });
      
    expect(response.status).toBe(302);
    
    // Argentine postal code
    response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Juan',
        lastName: 'Perez',
        streetAddress: '789 Calle Falsa',
        city: 'Buenos Aires',
        stateProvince: 'Buenos Aires',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'juan@example.com',
        phone: '+54 9 11 1234-5678'
      });
      
    expect(response.status).toBe(302);
  });
  
  it('renders thank-you page with first name', async () => {
    const response = await request(app).get('/thank-you?firstName=Alice');
    expect(response.status).toBe(200);
    
    const $ = load(response.text);
    const h1Text = $('h1').text();
    expect(h1Text).toContain('Thank you, Alice!');
    const pText = $('p').first().text();
    expect(pText).toContain('We\'ll keep your details somewhere safe(ish)');
  });
});