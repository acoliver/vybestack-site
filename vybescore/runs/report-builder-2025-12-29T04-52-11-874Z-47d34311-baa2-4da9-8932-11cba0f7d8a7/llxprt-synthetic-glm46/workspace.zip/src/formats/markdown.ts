import type { ReportData, RenderOptions } from '../types.js';
import { sumAmounts, formatAmount } from '../utils.js';

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines = [
    `# ${data.title}`,
    '',
    data.summary,
    '',
    '## Entries',
  ];

  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  if (options.includeTotals) {
    lines.push('')
    lines.push(`**Total:** ${formatAmount(sumAmounts(data.entries))}`);
  }

  return lines.join('\n');
}