#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import process from 'node:process';

import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const SUPPORTED_FORMATS = ['markdown', 'text'] as const;
type Format = typeof SUPPORTED_FORMATS[number];

interface CliArgs {
  dataPath: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const result: Partial<CliArgs> = {
    dataPath: args[0],
    includeTotals: false
  };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    switch (arg) {
      case '--format': {
        const format = args[++i] as Format;
        if (!SUPPORTED_FORMATS.includes(format)) {
          console.error(`Unsupported format: ${format}`);
          process.exit(1);
        }
        result.format = format;
        break;
      }
      case '--output':
        result.outputPath = args[++i];
        break;
      case '--includeTotals':
        result.includeTotals = true;
        break;
      default:
        console.error(`Unknown argument: ${arg}`);
        process.exit(1);
    }
  }

  if (!result.dataPath || !result.format) {
    console.error('Missing required arguments: data path and format are required');
    process.exit(1);
  }

  return result as CliArgs;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries field');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }

    if (typeof entry.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid label field`);
    }

    if (typeof entry.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid amount field`);
    }
  }

  return data as ReportData;
}

function loadJsonFile(path: string): ReportData {
  try {
    const content = readFileSync(path, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Failed to parse JSON file: ${error.message}`);
    }
    if (error instanceof Error && error.message.startsWith('ENOENT')) {
      throw new Error(`File not found: ${path}`);
    }
    throw error;
  }
}

async function main() {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArguments();
    const data = loadJsonFile(dataPath);
    const options: RenderOptions = { includeTotals };

    let result: string;
    switch (format) {
      case 'markdown':
        result = renderMarkdown(data, options);
        break;
      case 'text':
        result = renderText(data, options);
        break;
      default:
        console.error(`Unsupported format: ${format}`);
        process.exit(1);
    }

    if (outputPath) {
      const { writeFileSync } = await import('node:fs');
      writeFileSync(outputPath, result);
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(result);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
