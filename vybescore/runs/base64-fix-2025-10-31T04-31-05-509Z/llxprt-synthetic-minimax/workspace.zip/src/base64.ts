/**
 * Encode plain text to Base64 using RFC 4648 canonical Base64 encoding.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 Base64.
 * Accepts valid Base64 input (with or without padding) and rejects invalid input.
 */
export function decode(input: string): string {
  const normalized = input.replace(/\s+/g, '');

  // Validate Base64 format
  if (normalized.length === 0) {
    throw new Error('Empty input');
  }

  // Check for invalid characters (only allow Base64 chars + padding)
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(normalized)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check if input length is valid (must be multiple of 4 or have valid padding)
  if (normalized.length % 4 !== 0 && !normalized.endsWith('=')) {
    throw new Error('Invalid Base64 input: length must be multiple of 4 or have valid padding');
  }

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
