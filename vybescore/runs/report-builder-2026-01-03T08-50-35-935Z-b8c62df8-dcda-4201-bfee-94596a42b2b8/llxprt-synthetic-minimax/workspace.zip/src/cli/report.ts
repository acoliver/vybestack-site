import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(args: string[]): CLIOptions {
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[2];
  let format: 'markdown' | 'text' | null = null;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments from position 3 onwards
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[++i] as 'markdown' | 'text';
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function loadAndValidateData(dataPath: string): ReportData {
  try {
    const rawData = readFileSync(dataPath, 'utf-8');
    const parsed = JSON.parse(rawData);
    
    // Validate required fields
    if (!parsed.title || typeof parsed.title !== 'string') {
      throw new Error('Invalid or missing field: title (string required)');
    }
    
    if (!parsed.summary || typeof parsed.summary !== 'string') {
      throw new Error('Invalid or missing field: summary (string required)');
    }
    
    if (!parsed.entries || !Array.isArray(parsed.entries) || parsed.entries.length === 0) {
      throw new Error('Invalid or missing field: entries (non-empty array required)');
    }

    // Validate entries
    for (let i = 0; i < parsed.entries.length; i++) {
      const entry = parsed.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: label (string required)`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid entry at index ${i}: amount (number required)`);
      }
    }

    return parsed as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${dataPath}: ${error.message}`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, includeTotals);
    case 'text':
      return renderText(data, includeTotals);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const options = parseArguments(process.argv);
    const data = loadAndValidateData(options.dataPath);
    const output = renderReport(data, options.format, options.includeTotals);

    if (options.outputPath) {
      writeFileSync(options.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
}

main();
