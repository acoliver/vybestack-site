#!/usr/bin/env node

import { validateAndParseJson } from '../validators.js';
import { formatters } from '../formatters.js';
import { writeFileSync } from 'node:fs';

interface CliArgs {
  inputFilePath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  const positional: string[] = [];
  const options: { format?: string; output?: string; includeTotals: boolean } = {
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      options.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      options.output = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      positional.push(arg);
    }
  }

  if (positional.length !== 1) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFilePath = positional[0];

  if (!options.format) {
    throw new Error('--format is required');
  }

  return {
    inputFilePath,
    format: options.format,
    outputPath: options.output,
    includeTotals: options.includeTotals,
  };
}

function main(): void {
  try {
    const args = parseArguments(process.argv.slice(2));

    const data = validateAndParseJson(args.inputFilePath);

    const formatter = formatters[args.format];
    if (!formatter) {
      console.error(`Unsupported format: ${args.format}`);
      process.exit(1);
    }

    const output = formatter(data, { includeTotals: args.includeTotals });

    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
