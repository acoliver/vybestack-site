import type { Formatter } from './types.js';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';

export const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getSupportedFormats(): string[] {
  return Object.keys(formatters);
}
