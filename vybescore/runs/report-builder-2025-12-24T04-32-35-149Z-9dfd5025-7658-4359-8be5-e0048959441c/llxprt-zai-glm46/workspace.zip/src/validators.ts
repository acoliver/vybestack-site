import type { ReportData } from './types.js';
import { readFileSync } from 'node:fs';

export function validateAndParseJson(filePath: string): ReportData {
  let content: string;
  try {
    content = readFileSync(filePath, 'utf-8');
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Failed to read file: ${error.message}`);
    }
    throw new Error('Failed to read file: unknown error');
  }

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    throw new Error('Failed to parse JSON: unknown error');
  }

  return validateReportData(data);
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid report data: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(
        `Invalid report data: entry at index ${i} is not an object`
      );
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid report data: entry at index ${i} has missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid report data: entry at index ${i} has missing or invalid "amount" field (expected number)`
      );
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries as Array<{ label: string; amount: number }>,
  };
}
