#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(argv: string[]): { dataFile: string; options: CLIOptions } {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  if (args[1] !== '--format') {
    console.error('Error: --format parameter is required');
    process.exit(1);
  }
  
  if (args.length < 3) {
    console.error('Error: format value is required');
    process.exit(1);
  }
  
  const format = args[2] as 'markdown' | 'text';
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  const options: CLIOptions = {
    format,
    includeTotals: false
  };
  
  // Parse remaining arguments
  for (let i = 3; i < args.length; i++) {
    if (args[i] === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path value');
        process.exit(1);
      }
      options.output = args[i + 1];
      i++; // Skip the next argument (the path)
    } else if (args[i] === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${args[i]}`);
      process.exit(1);
    }
  }
  
  return { dataFile, options };
}

function loadData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Invalid data: title must be a string');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary must be a string');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }
    
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}].label must be a string`);
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entries[${i}].amount must be a number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON file');
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
}

function render(data: ReportData, options: CLIOptions): string {
  if (options.format === 'markdown') {
    return renderMarkdown(data, options.includeTotals);
  } else {
    return renderText(data, options.includeTotals);
  }
}

function main(): void {
  const { dataFile, options } = parseArguments(process.argv);
  const data = loadData(dataFile);
  const output = render(data, options);
  
  if (options.output) {
    try {
      writeFileSync(options.output, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();
