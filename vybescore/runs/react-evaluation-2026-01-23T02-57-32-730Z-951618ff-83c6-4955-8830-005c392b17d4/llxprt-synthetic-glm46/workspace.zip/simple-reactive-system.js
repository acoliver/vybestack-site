// Simpler reactive system based on Vue's reactivity approach
class Subject {
  constructor(value) {
    this.value = value
    this.observers = new Set()
  }
  
  get() {
    const activeObserver = Dep.target
    if (activeObserver) {
      this.observers.add(activeObserver)
      activeObserver.addDep(this)
    }
    return this.value
  }
  
  set(newValue) {
    if (newValue === this.value) return
    this.value = newValue
    
    this.notify()
  }
  
  notify() {
    const copy = [...this.observers]
    copy.forEach(observer => observer.update())
  }
}

class Observer {
  constructor(updateFn) {
    this.updateFn = updateFn
    this.deps = new Set()
    this.activated = false
  }
  
  addDep(dep) {
    if (this.activated) {
      this.deps.add(dep)
    }
  }
  
  update() {
    Dep.pushTarget(this)
    try {
      this.updateFn()
    } finally {
      Dep.popTarget()
    }
  }
  
  cleanup() {
    this.deps.forEach(dep => dep.observers.delete(this))
    this.deps.clear()
  }
}

class Dep {
  static target = null
  static stack = []
  
  static pushTarget(observer) {
    Dep.stack.push(Dep.target)
    Dep.target = observer
    observer.activated = true
  }
  
  static popTarget() {
    Dep.target = Dep.stack.pop()
  }
}

function createInput(value) {
  const subject = new Subject(value)
  
  const getter = () => subject.get()
  const setter = (newValue) => subject.set(newValue)
  
  return [getter, setter]
}

function createComputed(updateFn) {
  const observer = new Observer(updateFn)
  let value
  
  const getter = () => {
    Dep.pushTarget(observer)
    try {
      value = updateFn()
    } finally {
      Dep.popTarget()
      observer.activated = true
    }
    return value
  }
  
  // Initial computation to establish dependencies
  observer.update = () => {
    Dep.pushTarget(observer)
    try {
      value = updateFn()
    } finally {
      Dep.popTarget()
    }
  }
  
  getter()
  return getter
}

function createCallback(updateFn) {
  const observer = new Observer(updateFn)
  
  observer.update = () => {
    Dep.pushTarget(observer)
    try {
      updateFn()
    } finally {
      Dep.popTarget()
    }
  }
  
  // Initial execution to track dependencies
  observer.update()
  
  return () => {
    observer.cleanup()
  }
}

export { createInput, createComputed, createCallback }

// Test with our debug script
if (typeof window === 'undefined') {
  console.log("=== Testing simple reactive system ===")
  
  // Test 1
  const [input, setInput] = createInput(1)
  const timesTwo = createComputed(() => input() * 2)
  const timesThirty = createComputed(() => input() * 30)
  const sum = createComputed(() => timesTwo() + timesThirty())
  
  console.log("sum() =", sum())
  setInput(3)
  console.log("After setInput(3), sum() =", sum())
  
  // Test 2
  const [input2, setInput2] = createInput(1)
  const output = createComputed(() => input2() + 1)
  let value = 0
  const unsub = createCallback(() => value = output())
  
  console.log("Before setInput2(3), value =", value)
  setInput2(3)
  console.log("After setInput2(3), value =", value)
  
  // Test 3
  const [input3, setInput3] = createInput(11)
  const output3 = createComputed(() => input3() + 1)
  
  const values1 = []
  const unsubscribe1 = createCallback(() => values1.push(output3()))
  const values2 = []
  const unsubscribe2 = createCallback(() => values2.push(output3()))
  
  setInput3(31)
  unsubscribe1()
  setInput3(41)
  
  console.log("values1 =", values1)
  console.log("values2 =", values2)
}