import { createInput, createComputed, createCallback } from './src/index.ts'

console.log("=== Debugging reactive system ===")

// Test 1: compute cells can depend on other compute cells
console.log("\n--- Test 1: Computed dependencies ---")
const [input, setInput] = createInput(1)
console.log("input() =", input())

const timesTwo = createComputed(() => {
  console.log("timesTwo computing, input =", input())
  return input() * 2
})

const timesThirty = createComputed(() => {
  console.log("timesThirty computing, input =", input())
  return input() * 30
})

const sum = createComputed(() => {
  console.log("sum computing, timesTwo =", timesTwo(), "timesThirty =", timesThirty())
  return timesTwo() + timesThirty()
})

console.log("sum() = " + sum())
console.log("Expected: 32")

setInput(3)
console.log("After setInput(3), sum() = " + sum())
console.log("Expected: 96")

// Test 2: compute cells fire callbacks
console.log("\n--- Test 2: Callback firing ---")
const [input2, setInput2] = createInput(1)
const output = createComputed(() => {
  console.log("output computing, input2 =", input2())
  return input2() + 1
})

let value = 0
createCallback(() => {
  console.log("callback executing, output =", output())
  value = output()
})

console.log("Before setInput2(3), value =", value)
setInput2(3)
console.log("After setInput2(3), value =", value)
console.log("Expected: 4")

// Test 3: callbacks can be added and removed
console.log("\n--- Test 3: Callback add/remove ---")
const [input3, setInput3] = createInput(11)
const output3 = createComputed(() => input3() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => {
  console.log("callback1 executing, output3 =", output3())
  values1.push(output3())
})

const values2 = []
createCallback(() => {
  console.log("callback2 executing, output3 =", output3())
  values2.push(output3())
})

setInput3(31)
console.log("After setInput3(31), values1 =", values1, "values2 =", values2)

unsubscribe1()
console.log("Unsubscribed callback1")

setInput3(41)
console.log("After setInput3(41), values1 =", values1, "values2 =", values2)
console.log("Expected: values2 should have more entries than values1")