/**
 * Type definitions for the reactive programming system.
 */
let activeObserver;
export function getActiveObserver() {
    return activeObserver;
}
export function updateObserver(observer) {
    const previous = activeObserver;
    activeObserver = observer;
    try {
        const newValue = observer.updateFn(observer.value);
        observer.value = newValue;
    }
    finally {
        activeObserver = previous;
    }
}
