/**
 * Input closure implementation for reactive primitives.
 */
import { getActiveObserver, updateObserver } from '../types/reactive.js';
/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput(value, _equal, options) {
    const s = {
        name: options?.name,
        observer: undefined,
        observers: new Set(),
        value,
        equalFn: undefined,
    };
    const read = () => {
        const observer = getActiveObserver();
        if (observer) {
            s.observer = observer;
            s.observers.add(observer);
        }
        return s.value;
    };
    const write = (nextValue) => {
        const prevValue = s.value;
        // Check if value actually changed
        if (s.equalFn ? s.equalFn(prevValue, nextValue) : prevValue === nextValue) {
            return s.value;
        }
        s.value = nextValue;
        // Update all dependent observers
        const observers = Array.from(s.observers);
        for (const obs of observers) {
            updateObserver(obs);
        }
        return s.value;
    };
    return [read, write];
}
