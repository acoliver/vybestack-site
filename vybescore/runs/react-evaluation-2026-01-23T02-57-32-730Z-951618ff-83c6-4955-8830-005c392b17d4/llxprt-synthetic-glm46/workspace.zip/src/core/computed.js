/**
 * Computed closure implementation for derived values.
 */
import { updateObserver, getActiveObserver } from '../types/reactive.js';
/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed(updateFn, value, _equal, options) {
    const o = {
        name: options?.name,
        value,
        updateFn,
    };
    const getter = () => {
        const observer = getActiveObserver();
        if (observer && observer !== o) {
            // If the observer has an observers set (i.e., it's from a Subject)
            if ('observers' in observer) {
                observer.observers.add(o);
            }
        }
        return o.value;
    };
    // Initial computation
    updateObserver(o);
    return getter;
}
