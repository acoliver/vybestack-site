import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing basic reactive system...')

// Set up basic input
const [input, setInput] = createInput(1)
console.log('Input initial value:', input())

// Create computed values
const timesTwo = createComputed(() => input() * 2)
console.log('TimesTwo computed:', timesTwo())

const timesThirty = createComputed(() => input() * 30)
console.log('TimesThirty computed:', timesThirty())

const sum = createComputed(() => timesTwo() + timesThirty())
console.log('Sum computed:', sum())

// Test change
setInput(3)
console.log('After setInput(3):')
console.log('Input value:', input())
console.log('TimesTwo computed:', timesTwo())
console.log('TimesThirty computed:', timesThirty())
console.log('Sum computed:', sum())

// Test callback
console.log('\nTesting callback...')
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0
createCallback(() => {
  console.log('Callback triggered, output =', output())
  value = output()
})
console.log('Initial value:', value)
setInput2(3)
console.log('After setInput2(3), value =', value)