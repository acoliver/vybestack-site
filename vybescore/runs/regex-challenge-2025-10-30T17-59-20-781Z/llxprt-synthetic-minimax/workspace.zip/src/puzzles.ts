/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a word boundary pattern that matches words starting with prefix
  // Using word boundaries to ensure we match complete words
  const pattern = new RegExp(`\\b${escapedPrefix}[\\w-]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const lowercaseExceptions = exceptions.map(e => e.toLowerCase());
  
  return matches.filter(match => {
    const lowercaseMatch = match.toLowerCase();
    return !lowercaseExceptions.includes(lowercaseMatch);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences where the token appears after a digit
  const results: string[] = [];
  const regex = new RegExp(`(\\d)${escapedToken}`, 'gi');
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    // Return the full match including the digit
    results.push(match[0]);
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab"
  // Pattern: any 2+ character sequence repeated consecutively
  // e.g., "abab", "123123", "xyzxyz", but not "aaaa" (that's 3+ repeats of single char)
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if there's an IPv4 address - if so, return false
  // IPv4 pattern: 4 numbers separated by dots, each 0-255
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 address pattern (simplified but comprehensive)
  // Handles:
  // - Standard 8 groups of 4 hex digits: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed with :: : 2001:db8::8a2e:370:7334
  // - Various formats including ::1 for loopback
  const ipv6Pattern = /\b(?:[A-Fa-f0-9]{1,4}:){7}[A-Fa-f0-9]{1,4}\b|\b::1\b|\b::\b|(?:[A-Fa-f0-9]{1,4}:){1,7}:|(?::[A-Fa-f0-9]{1,4}){1,7}/;
  
  return ipv6Pattern.test(value);
}