export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove surrounding whitespace
  const email = value.trim();

  // Email pattern:
  // - Local part: letters, numbers, and these special chars: .!#$%&'*+/=?^_`{|}~-
  // - Cannot start or end with dot, no consecutive dots
  // - Domain: letters, numbers, hyphens, dots, must have TLD
  // - No underscores in domain
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/;

  return emailRegex.test(email);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove common separators and spaces
  const cleaned = value.replace(/[\s().-]/g, '');

  // Check for extension
  const hasExtension = /\b(ext|x)\s*\d+/i.test(value);
  if (hasExtension && !options?.allowExtensions) {
    return false;
  }

  // Remove extension part
  const phonePart = cleaned.replace(/\b(ext|x)\s*\d+/i, '');

  // Must be 10 or 11 digits (with +1)
  if (phonePart.length === 11 && phonePart.startsWith('1')) {
    // 11 digits starting with 1
    const areaCode = phonePart.substring(1, 4);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    return true;
  } else if (phonePart.length === 10) {
    // 10 digits
    const areaCode = phonePart.substring(0, 3);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    return true;
  }

  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters for processing
  const digits = value.replace(/\D/g, '');
  
  // Various format checks:
  // Format 1: +54 9 XX XXXX XXXX (14 digits total with country code, mobile)
  // Format 2: 0XX XXXX XXXX (10 digits, landline)
  // Format 3: +54 XX XXXX XXXX (13 digits with country code, landline)
  // Format 4: +54 9 XXXX XXXX (12 digits with country code, mobile short)
  
  // Pattern breakdown:
  // - Optional country code +54
  // - Optional trunk prefix 0 (when no country code)
  // - Optional mobile indicator 9 (between country/trunk and area code)
  // - Area code: 2-4 digits starting with 1-9
  // - Subscriber number: 6-8 digits total after area code
  
  // Check for the patterns
  const patterns = [
    // With +54 country code (numeric: 54)
    /^54(9)?(0)?([1-9]\d{1,3})\d{6,8}$/, // 54, optional 9, optional 0, area code 2-4 digits (1-9), rest is subscriber
    
    // Without country code (must start with 0)
    /^0([1-9]\d{1,3})\d{6,8}$/, // Must start with 0, area code 2-4 digits (1-9), rest is subscriber
  ];

  // Also check with spaces and hyphens as separators
  const spacedPatterns = [
    /^\+54\s*(9)?\s*(0)?\s*([1-9]\d{1,3})\s*\d{6,8}$/,
    /^0\s*([1-9]\d{1,3})\s*\d{6,8}$/,
  ];

  if (patterns.some(p => p.test(digits)) || spacedPatterns.some(p => p.test(value))) {
    // Additional validation: check total length after removing all separators
    // Should be 10-14 digits depending on format
    const totalDigits = digits.length;
    
    return totalDigits >= 10 && totalDigits <= 14;
  }

  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must start with a letter
  // Can contain letters (including unicode), spaces, hyphens, apostrophes
  // Cannot contain digits or special symbols
  // Cannot be just symbols like "X Æ A-12"
  
  // Pattern: starts with letter, then letters/spaces/hyphens/apostrophes
  // Using Unicode property escapes for letters
  const nameRegex = /^(?=.{1,100}$)[A-Za-zÀ-ÖØ-öø-ÿ](?:[\s'\-]*[A-Za-zÀ-ÖØ-öø-ÿ])*$/;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that are clearly not real names
  // No purely numeric or symbol patterns
  if (/[\d]/.test(value)) {
    return false;
  }
  
  // Check for the "X Æ A-12" style names
  if (/Æ/.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  if (!/[A-Za-zÀ-ÖØ-öø-ÿ]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (13-19 digits is typical for most cards)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check card type by prefix
  // Visa: starts with 4, length 13, 16, or 19
  const isVisa = /^4\d{12}(\d{3})?(\d{3})?$/.test(digits);
  // MasterCard: starts with 51-55, or 2221-2720, length 16
  const isMasterCard = /^5[1-5]\d{14}$/.test(digits) || /^2(2[2-9]\d|[3-6]\d{2}|7[01]\d|720)\d{12}$/.test(digits);
  // AmEx: starts with 34 or 37, length 15
  const isAmEx = /^3[47]\d{13}$/.test(digits);
  
  // If none of the common types match, still allow if it passes Luhn
  const isValidCardType = isVisa || isMasterCard || isAmEx;
  
  // Always run Luhn check
  if (!runLuhnCheck(digits)) {
    return false;
  }
  
  // Must be one of the accepted card types AND pass Luhn
  return isValidCardType || runLuhnCheck(digits);
}