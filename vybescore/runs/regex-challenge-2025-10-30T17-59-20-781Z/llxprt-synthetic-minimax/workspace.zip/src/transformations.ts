/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Handle edge cases
  if (!text) {
    return text;
  }

  let result = text;
  
  // Step 1: Ensure there's a single space after sentence terminators (but not at the end)
  // Replace .!? followed by any whitespace with . + single space (but preserve trailing whitespace pattern)
  result = result.replace(/([.!?])(\s+)/g, '$1 ');
  
  // Step 2: Find sentences and capitalize the first letter after punctuation
  result = result.replace(/([.!?]\s+)([A-Za-zÀ-ÖØ-öø-ÿ])/g, (match, prefix, firstChar) => {
    return prefix + firstChar.toUpperCase();
  });
  
  // Step 3: Capitalize the very first character if it's a letter
  result = result.replace(/^([A-Za-zÀ-ÖØ-öø-ÿ])/, (match, firstChar) => {
    return firstChar.toUpperCase();
  });
  
  // Step 4: Handle multiple consecutive spaces between words
  result = result.replace(/\s{2,}/g, ' ');
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs
  // Matches: http://, https://, and www.
  // Captures the full URL including dots in domain
  
  const urlPattern = /\b(?:(?:https?:\/\/)|(?:www\.))[^\s"'<>()\[\]{}]*[^\s"'<>()\[\]{}(),!?;:]+/gi;
  
  const urls = text.match(urlPattern) || [];
  
  // Clean up URLs - remove trailing punctuation that was captured
  return urls.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?;:]+\s*$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  // Use word boundary to avoid matching in the middle of a word
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Match http:// URLs with a capturing group
  // Pattern matches: http://, optional www., domain, path
  const urlPattern = /\b(http:\/\/[^\/\s]+)((?:\/[^\s]*)?)/gi;
  
  return text.replace(urlPattern, (match, protocolAndHost, path) => {
    // Remove http:// from protocolAndHost
    const host = protocolAndHost.replace(/^http:\/\//, '');
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(\?|=|&|cgi-bin)/i.test(path);
    const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)\b/i.test(path);
    
    // Check if path begins with /docs/
    const isDocsPath = /^\/docs\//i.test(path);
    
    if (isDocsPath && !hasDynamicHints && !hasLegacyExtensions) {
      // Extract domain from www.example.com
      const domainMatch = host.match(/^(?:www\.)?(.+)$/);
      const domain = domainMatch ? domainMatch[1] : host;
      
      // Build new URL: https://docs.domain/path
      return `https://docs.${domain}${path}`;
    } else {
      // Just upgrade the protocol
      return `https://${host}${path}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, checking basic rules)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Check for invalid dates (e.g., 02/30)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Validate year (reasonable range, e.g., 1900-2100)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1900 || yearNum > 2100) {
    return 'N/A';
  }
  
  return year;
}