/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Legacy exports for compatibility
export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Observer pattern types
export type ReactiveObserver = {
  update(): void
  dispose(): void
}

// Reactive nodes
export type ReactiveNode<T = unknown> = {
  type: 'input' | 'computed' | 'callback'
  value: T
  isDirty: boolean
  dependencies: Set<ReactiveNode>
  dependents: Set<ReactiveObserver>
  
  // Input specific
  setValue?(value: T): void
  
  // Computed specific
  computeUpdate?(): T
  
  // Callback specific
  callback?(): void
  
  // Getter function (for computed nodes)
  getter?(...args: unknown[]): T
  
  // Computed specific - store getter function
  _getter?(): T
}

// Global execution context
let currentObserver: ReactiveObserver | null = null
let currentNode: ReactiveNode | null = null
const computingStack: Set<ReactiveNode> = new Set()
const notificationStack: Set<ReactiveNode> = new Set()

export function getCurrentObserver(): ReactiveObserver | null {
  return currentObserver
}

export function getCurrentNode(): ReactiveNode | null {
  return currentNode
}

export function setCurrentNode(node: ReactiveNode | null): void {
  currentNode = node
}

export function setCurrentObserver(observer: ReactiveObserver | null): void {
  currentObserver = observer
}

export function createNode<T>(
  type: 'input' | 'computed' | 'callback',
  initialValue: T
): ReactiveNode<T> {
  return {
    type,
    value: initialValue,
    isDirty: false,
    dependencies: new Set(),
    dependents: new Set(),
  }
}

export function addDependency<T>(node: ReactiveNode<T>, dependency: ReactiveNode): void {
  if (!node.dependencies.has(dependency)) {
    node.dependencies.add(dependency)
    
    // Get the current observer from the global context
    const currentObserver = getCurrentObserver()
    
    if (currentObserver) {
      // If we're in an observer context (callback), add observer as dependent
      dependency.dependents.add(currentObserver)
    } else if (node.type === 'computed') {
      // For computed nodes, create an observer that will mark this node as dirty when dependency changes
      const observer: ReactiveObserver = {
        update() {
          // Mark this computed as dirty and notify its dependents
          node.isDirty = true
          notifyNode(node)
        },
        dispose() {
          node.dependencies.delete(dependency)
          dependency.dependents.delete(observer)
        }
      }
      
      dependency.dependents.add(observer)
      // Store observer reference on node for cleanup
      node.dependents.add(observer)
    }
  }
}

export function notifyNode<T>(node: ReactiveNode<T>): void {
  // Prevent infinite notification loops
  if (notificationStack.has(node)) {
    return
  }
  
  notificationStack.add(node)
  
  try {
    // Create a copy to avoid issues with collection modification during iteration
    const observers = Array.from(node.dependents)
    
    observers.forEach(observer => {
      // For callback type nodes, check if they're disposed before updating
      if (observer.update) {
        observer.update()
      }
    })
  } finally {
    notificationStack.delete(node)
  }
}

export function computeNode<T>(node: ReactiveNode<T>): T {
  if (node.type === 'computed' && node.isDirty && node._getter) {
    // Prevent infinite recursion with computing stack
    if (computingStack.has(node)) {
      throw new Error('Circular dependency detected in computed values')
    }
    
    const previousNode = currentNode
    currentNode = node
    
    try {
      computingStack.add(node)
      node.value = node._getter()
      node.isDirty = false
    } catch (error) {
      // Let circular dependency errors propagate
      if (error instanceof Error && error.message !== 'Circular dependency detected in computed values') {
        throw error
      }
    } finally {
      computingStack.delete(node)
      currentNode = previousNode
    }
  }
  
  return node.value
}
