/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  GetterFn,
  SetterFn,
  Options,
  createNode,
  addDependency,
  notifyNode,
  getCurrentNode
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  _options?: Options
): InputPair<T> {
  const node = createNode('input', value)
  
  const read: GetterFn<T> = () => {
    const currentNode = getCurrentNode()
    
    if (currentNode && node !== currentNode) {
      addDependency(currentNode, node)
    }
    
    return node.value
  }

  const write: SetterFn<T> = (nextValue) => {
    node.value = nextValue
    notifyNode(node)
    return nextValue
  }
  
  // Store setter on node for direct access
  node.setValue = write

  return [read, write]
}
