/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, UpdateFn, createNode, getCurrentNode, setCurrentNode, setCurrentObserver, ReactiveObserver } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let currentValue = value
  let disposed = false
  let activeObserver: ReactiveObserver | null = null
  
  // Create a reactive node to track dependencies
  const node = createNode('callback', value)
  
  // Create observer that re-executes when dependencies change
  activeObserver = {
    update() {
      if (disposed) return
      
      const previousNode = getCurrentNode()
      setCurrentNode(node)
      setCurrentObserver(activeObserver)
      
      try {
        // Clear dependencies on each update
        node.dependencies.clear()
        currentValue = updateFn(currentValue)
      } finally {
        setCurrentNode(previousNode)
        setCurrentObserver(null)
      }
    },
    dispose() {
      disposed = true
      // Clean up all dependencies
      node.dependencies.forEach(dependency => {
        if (activeObserver) {
          dependency.dependents.delete(activeObserver)
        }
      })
    }
  }
  
  // Set the observer as the current node's observer
  node.callback = () => {
    if (activeObserver) {
      activeObserver.update()
    }
  }
  
  // Initial execution
  activeObserver.update()
  
  // Return unsubscribe function
  const unsubscribe = () => {
    if (!disposed) {
      disposed = true
      // Remove this observer from all its dependencies' dependent sets
      node.dependencies.forEach(dependency => {
        dependency.dependents.delete(activeObserver!)
      })
      node.dependents.delete(activeObserver!)
      // Clear node dependencies
      node.dependencies.clear()
    }
  }
  
  return unsubscribe
}
