/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  createNode,
  addDependency,
  getCurrentNode,
  setCurrentNode
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  _options?: { name?: string }
): GetterFn<T> {
  const node = createNode('computed', value as T)
  node.computeUpdate = updateFn
  node.isDirty = true // Mark as dirty to compute on first access
  
  function getter(): T {
    const previousNode = getCurrentNode()
    
    // Register this computed as a dependency
    if (previousNode && node !== previousNode) {
      addDependency(previousNode, node)
    }
    
    setCurrentNode(node)
    
    try {
      // Execute the computation function if dirty
      if (node.isDirty && node.computeUpdate) {
        const result = node.computeUpdate()
        node.value = result
        node.isDirty = false
      }
      return node.value
    } finally {
      setCurrentNode(previousNode)
    }
  }
  
  // Store getter on node for proper computation
  node._getter = getter
  
  return getter
}
