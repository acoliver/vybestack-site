#!/usr/bin/env node

import * as fs from 'fs';
import * as path from 'path';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments manually
const args = process.argv.slice(2);
let dataFile: string | null = null;
let format: string | null = null;
let outputFile: string | null = null;
let includeTotals = false;

for (let i = 0; i < args.length; i++) {
  const arg = args[i];
  
  if (arg === '--format') {
    format = args[++i];
  } else if (arg === '--output') {
    outputFile = args[++i];
  } else if (arg === '--includeTotals') {
    includeTotals = true;
  } else if (!dataFile) {
    dataFile = arg;
  }
}

// Validate required arguments
if (!dataFile) {
  console.error('Error: Data file path is required');
  process.exit(1);
}

if (!format) {
  console.error('Error: Format option is required');
  process.exit(1);
}

// Validate format
if (format !== 'markdown' && format !== 'text') {
  console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
  process.exit(1);
}

// Check if data file exists
if (!fs.existsSync(dataFile)) {
  console.error(`Error: Data file '${dataFile}' not found`);
  process.exit(1);
}

try {
  // Read and parse JSON data
  const jsonString = fs.readFileSync(dataFile, 'utf-8');
  const data: ReportData = JSON.parse(jsonString);
  
  // Validate data structure
  if (!data.title || !data.summary || !Array.isArray(data.entries)) {
    throw new Error('Invalid data structure');
  }
  
  for (const entry of data.entries) {
    if (!entry.label || typeof entry.amount !== 'number') {
      throw new Error('Invalid entry structure');
    }
  }
  
  // Render report based on format
  let output: string;
  if (format === 'markdown') {
    output = renderMarkdown(data, { includeTotals });
  } else {
    output = renderText(data, { includeTotals });
  }
  
  // Write to output file or stdout
  if (outputFile) {
    fs.writeFileSync(outputFile, output);
    console.log(`Report written to ${outputFile}`);
  } else {
    console.log(output);
  }
} catch (error) {
  if (error instanceof SyntaxError) {
    console.error(`Error: Invalid JSON in file '${dataFile}'`);
  } else {
    console.error(`Error: ${error.message}`);
  }
  process.exit(1);
}