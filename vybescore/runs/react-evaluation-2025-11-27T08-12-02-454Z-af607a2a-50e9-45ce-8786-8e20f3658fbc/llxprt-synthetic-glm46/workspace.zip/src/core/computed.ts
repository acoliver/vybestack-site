/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Observer management for reactive updates
  const observers: Set<Observer<T>> = new Set()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (_prevValue?: T) => {
      const prevActive = getActiveObserver()
      setActiveObserver(o)
      
      try {
        // Execute the update function to compute new value
        const newValue = updateFn(value)
        
        // Only update if value changed
        if (o.value !== newValue) {
          o.value = newValue
          
          // Notify all registered observers
          observers.forEach(observer => {
            if ('updateFn' in observer) {
              updateObserver(observer as Observer<T>)
            }
          })
        }
        
        return o.value!
      } finally {
        // Restore previous observer context
        setActiveObserver(prevActive)
      }
    },
  }
  
  // Compute initial value
  const prevActive = getActiveObserver()
  setActiveObserver(o)
  try {
    o.value = updateFn(value)
  } finally {
    setActiveObserver(prevActive)
  }
  
  return (): T => {
    // Register this computed as a dependency when accessed
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      observers.add(activeObserver as Observer<T>)
    }
    
    // Trigger computation when accessed
    o.updateFn()
    
    return o.value!
  }
}