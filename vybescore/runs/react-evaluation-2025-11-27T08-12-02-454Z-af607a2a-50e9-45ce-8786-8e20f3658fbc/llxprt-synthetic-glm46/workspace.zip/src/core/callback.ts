/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      try {
        // Execute the callback function
        observer.value = updateFn(prevValue)
        return observer.value!
      } finally {
        // Restore previous active observer
      }
    },
  }
  
  // Execute callback once to track initial dependencies
  const prevActiveObserver = getActiveObserver()
  setActiveObserver(observer)
  try {
    observer.updateFn()
  } finally {
    setActiveObserver(prevActiveObserver)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}