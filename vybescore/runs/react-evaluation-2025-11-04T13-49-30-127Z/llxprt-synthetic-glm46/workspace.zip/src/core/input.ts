/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  registerDependency,
  notifyDependencies,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Create equality function if needed
  const equalFn: EqualFn<T> | undefined = 
    typeof _equal === 'function' ? _equal : 
    _equal === true ? (a, b) => a === b : 
    undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      registerDependency(s, observer as Observer<any>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !equalFn || !equalFn(s.value, nextValue)
    if (shouldUpdate) {
      s.value = nextValue
      
      // Notify all dependent observers
      notifyDependencies(s)
    }
    return s.value
  }

  return [read, write]
}