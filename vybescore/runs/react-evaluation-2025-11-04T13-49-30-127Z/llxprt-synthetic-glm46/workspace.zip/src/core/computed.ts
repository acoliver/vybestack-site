/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  registerDependency,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create equality function if needed
  const equalFn: EqualFn<T> | undefined = 
    typeof _equal === 'function' ? _equal : 
    _equal === true ? (a, b) => a === b : 
    undefined

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Run initial computation to establish dependencies
  updateObserver(o)
  
  return (): T => {
    // Register this computed value as a dependency of any active observer
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      registerDependency(o, currentObserver as Observer<any>)
    }
    
    return o.value!
  }
}