/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 with validation.
 */
export function decode(input: string): string {
  let normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  
  // Basic validation: only allow Base64 characters and optional padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  // Add missing padding to make length divisible by 4
  const paddingNeeded = (4 - (normalized.length % 4)) % 4;
  if (paddingNeeded > 0) {
    normalized += '='.repeat(paddingNeeded);
  }

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input: malformed or corrupted data');
  }
}
