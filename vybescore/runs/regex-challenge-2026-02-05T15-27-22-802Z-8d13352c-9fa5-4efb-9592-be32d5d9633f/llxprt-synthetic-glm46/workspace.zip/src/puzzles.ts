/**
 * Find words beginning with the prefix according to requirements:
 * - Find words beginning with the prefix
 * - Excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words that start with the prefix
  // \b ensures we're matching whole words, \w* matches the rest of the word
  // Use case-insensitive matching to be more flexible
  // Use a simpler approach that's more robust
  const words = text.split(/\s+/);
  
  // Filter words that start with prefix but aren't exceptions
  return words.filter(word => {
    // Check if word starts with prefix (case-insensitive)
    if (!word.toLowerCase().startsWith(prefix.toLowerCase())) return false;
    
    // Check if word is not in exceptions (case-insensitive)
    if (exceptions.some(exc => exc.toLowerCase() === word.toLowerCase())) return false;
    
    // Accept the word
    return true;
  });
}



/**
 * Find occurrences of a token according to requirements:
 * - Return occurrences where the token appears after a digit and not at the start of the string
 * - Use lookaheads/lookbehinds
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use a simplified approach without lookbehinds
  const results: string[] = [];
  const words = text.split(/\s+/);
  
  // Check each word for the pattern
  for (const word of words) {
    // Check if word starts with a digit and contains the token
    if (/^\d/.test(word) && word.includes(token)) {
      results.push(word);
    }
  }
  
  return results;
}

/**
 * Validate passwords according to requirements:
 * - At least 10 characters
 * - One uppercase
 * - One lowercase
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  let hasUppercase = false;
  let hasLowercase = false;
  let hasDigit = false;
  let hasSymbol = false;
  
  for (const char of value) {
    if (/[A-Z]/.test(char)) hasUppercase = true;
    if (/[a-z]/.test(char)) hasLowercase = true;
    if (/[0-9]/.test(char)) hasDigit = true;
    if (!/[A-Za-z0-9]/.test(char)) hasSymbol = true;
  }
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (2-4 character patterns repeated immediately)
  // We'll check for patterns of length 2-4 that appear twice in a row
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const pattern = value.substr(i, len);
      const nextPattern = value.substr(i + len, len);
      if (pattern === nextPattern) return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses according to requirements:
 * - Detect IPv6 addresses (including shorthand ::)
 * - Ensure IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern - this is complex but covers most valid cases
  // Including full notation, shorthand with ::, and compressed notation
  // We need to be careful not to match IPv4 addresses
  
  // First, let's exclude IPv4 addresses explicitly
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) return false;
  
  // IPv6 patterns:
  // 1. Full notation: 8 groups of 1-4 hex digits separated by colons
  // 2. Shorthand with :: (can appear in various positions)
  // 3. Combination with IPv4 at the end (IPv4-mapped IPv6)
  
  // Pattern 1: Full IPv6 notation (8 groups, each 1-4 hex digits, separated by :)
  const fullIpv6Pattern = /(?<![0-9.])([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?![0-9a-fA-F:])/;
  
  // Pattern 2: Shorthand with :: (compressed notation)
  // This pattern is more complex as :: can replace one or more groups
  const shorthandIpv6Pattern = /(?<![0-9.])(([0-9a-fA-F]{1,4}:){0,7}:|:(:[0-9a-fA-F]{1,4}){1,7}|([0-9a-fA-F]{1,4}:){1,7}:[0-9a-fA-F]{0,4}|[0-9a-fA-F]{1,4}::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4})(?![0-9a-fA-F:])/;
  
  // Pattern 3: IPv4-mapped IPv6 addresses (IPv4 at the end)
  const ipv4MappedPattern = /(?<![0-9])([0-9a-fA-F]{1,4}:){1,5}:(?:\d{1,3}\.){3}\d{1,3}(?!\.)/;
  
  // Test each pattern
  return fullIpv6Pattern.test(value) || 
         shorthandIpv6Pattern.test(value) || 
         ipv4MappedPattern.test(value);
}
