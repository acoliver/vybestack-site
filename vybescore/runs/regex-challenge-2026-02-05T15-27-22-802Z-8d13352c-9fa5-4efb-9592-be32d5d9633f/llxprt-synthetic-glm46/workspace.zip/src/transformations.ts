/**
 * Capitalize the first character of each sentence according to requirements:
 * - Capitalize the first character of each sentence (after .?!)
 * - Insert exactly one space between sentences even if the input omitted it
 * - Collapse extra spaces sensibly while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // Simple approach: split on sentence delimiters and then rebuild
  // Make sure to include spaces in the captured text
  const sentences = text.split(/([.!?]\s*)/);
  
  let result = '';
  let capitalizeNext = true; // First character should be capitalized
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    if (i % 2 === 0) {
      // This is the text part
      if (segment.length > 0) {
        if (capitalizeNext) {
          result += segment.charAt(0).toUpperCase() + segment.slice(1);
        } else {
          result += segment;
        }
        capitalizeNext = false; // Reset until we hit the next punctuation
      }
    } else {
      // This is the punctuation part
      result += segment;
      capitalizeNext = true; // Next text part should be capitalized
    }
  }
  
  return result;
}

/**
 * Find URLs in the text according to requirements:
 * - Return all URLs detected in the text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // This regex matches most common URL formats
  // It's designed to be relatively broad but not too aggressive
  const urlRegex = /https?:\/\/[^\s]+/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation like .,?!:;)" etc.
  return matches.map(url => url.replace(/[.,!?;:'")\]]+$/g, ''));
}

/**
 * Force all http URLs to https according to requirements:
 * - Replace http:// schemes with https:// while leaving existing secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite URLs according to requirements:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com 
 * - Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings, or legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http:// to https://
  let result = text.replace(/http:\/\/example\.com(\/docs\/)/g, 'https://docs.example.com$1');
  
  // Then handle remaining http to https conversions for example.com
  result = result.replace(/http:\/\/example\.com/g, 'https://example.com');
  
  return result;
}

/**
 * Extract the year according to requirements:
 * - Return the four-digit year for mm/dd/yyyy
 * - If the string doesn't match that format or month/day are invalid, return 'N/A'
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(value);
  
  if (!dateMatch) return 'N/A';
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate month
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month and year (including leap year logic)
  const daysInMonth = [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}

/**
 * Helper function to check if a year is a leap year
 */
function isLeapYear(year: string): boolean {
  const yearNum = parseInt(year, 10);
  return (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
}
