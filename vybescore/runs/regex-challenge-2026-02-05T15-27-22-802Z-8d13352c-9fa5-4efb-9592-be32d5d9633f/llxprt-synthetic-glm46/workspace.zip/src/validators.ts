export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses according to requirements:
 * - Accept typical addresses such as name@tag@example.co.uk
 * - Reject double dots, trailing dots, domains with underscores
 * - Reject other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Email regex that:
  // - Allows letters, numbers, dots, hyphens, and plus in local part
  // - Rejects consecutive dots and trailing dots
  // - Allows subdomains and TLDs
  // - Rejects underscores in domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*$/;
  
  // Check for consecutive dots anywhere
  if (value.includes('..')) return false;
  
  // Check for dots at start or end of local part
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) return false;
  
  // Local part cannot start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Domain cannot contain underscores
  if (domain.includes('_')) return false;
  
  // Domain cannot start or end with dot or hyphen
  if (domain.startsWith('.') || domain.startsWith('-') || domain.endsWith('.') || domain.endsWith('-')) return false;
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers according to requirements:
 * - Support (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Disallow impossible area codes (leading 0/1)
 * - Disallow too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all whitespace and common separators
  const cleanNumber = value.replace(/[\s\-.()]/g, '');
  
  // Check for optional +1 prefix
  const hasPrefix = cleanNumber.startsWith('+1');
  const phoneNumber = hasPrefix ? cleanNumber.substring(2) : cleanNumber;
  
  // Must be exactly 10 digits after removing +1 prefix
  if (!/^\d{10}$/.test(phoneNumber)) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers according to requirements:
 * - Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number (after the area code) must contain 6-8 digits in total
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Start with optional +54 country code
  const countryCodeRegex = /^\+?54/;
  
  // Check for country code
  let remaining = cleanNumber;
  if (countryCodeRegex.test(cleanNumber)) {
    remaining = cleanNumber.replace(/^\+?54/, '');
  } else {
    // If no country code, must start with 0 (trunk prefix)
    if (!remaining.startsWith('0')) return false;
    remaining = remaining.substring(1);
  }
  
  // Next part might be 9 (mobile indicator)
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // Area code must be 2-4 digits, leading digit 1-9
  const areaCodeMatch = remaining.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[1];
  remaining = remaining.substring(areaCode.length);
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(remaining)) return false;
  
  return true;
}

/**
 * Validate personal names according to requirements:
 * - Permit unicode letters, accents, apostrophes, hyphens, spaces
 * - Reject digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow:
  // - Unicode letters from any language (\p{L})
  // - Apostrophes, hyphens, spaces
  // - Accents (covered by \p{L})
  // Reject:
  // - Digits
  // - Other symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check if it's the forbidden format X Æ A-12 (or similar)
  const hasNumberAndSymbol = /\p{L}[\s]+Æ[\s]+A-?\d+/u;
  
  return nameRegex.test(value) && !hasNumberAndSymbol.test(value);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value.charAt(i), 10);
    let transformed = digit;
    
    if (isEven) {
      transformed = digit * 2;
      if (transformed > 9) transformed -= 9;
    }
    
    sum += transformed;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers according to requirements:
 * - Accept Visa/Mastercard/AmEx prefixes and lengths
 * - Run a Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must contain only digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-9]\d|[45]\d\d|6\d\d|7[01]\d|720)\d{12})$/;
  
  // Amex: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the card number matches any of the supported card types
  if (!visaRegex.test(cleanNumber) && !mastercardRegex.test(cleanNumber) && !amexRegex.test(cleanNumber)) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleanNumber);
}
