import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';

let server: any;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import and start the actual server
  const serverModule = await import('../../src/server.ts');
  server = serverModule.default;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(server).get('/');
    expect(res.status).toBe(200);
    expect(res.text).toContain('First name');
    expect(res.text).toContain('Last name');
    expect(res.text).toContain('Street address');
    expect(res.text).toContain('City');
    expect(res.text).toContain('State / Province / Region');
    expect(res.text).toContain('Postal / Zip code');
    expect(res.text).toContain('Country');
    expect(res.text).toContain('Email');
    expect(res.text).toContain('Phone number');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const res = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'Anystate',
        postalCode: '12345',
        country: 'USA',
        email: 'john.doe@example.com',
        phone: '+1 555 123 4567'
      });
    
    expect(res.status).toBe(302);
    expect(res.header.location).toBe('/thank-you?firstName=John');
  });
});
