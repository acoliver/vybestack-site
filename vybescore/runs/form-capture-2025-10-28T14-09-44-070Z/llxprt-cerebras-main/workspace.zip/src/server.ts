import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs from 'sql.js';

// Get __dirname in ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Database setup
const dbPath = path.join(__dirname, '../data/submissions.sqlite');
let db: initSqlJs.Database;

// Initialize database
async function initializeDatabase() {
  const SQL = await initSqlJs({
    locateFile: (file: string) => `https://sql.js.org/dist/${file}`
  });
  
  // Load existing database or create new one
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept international formats with +, digits, spaces, parentheses, dashes
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric postal codes (handles UK, Argentine, etc.)
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  } = req.body;
  
  // Validation
  const errors: string[] = [];
  
  if (!firstName || firstName.trim() === '') {
    errors.push('First name is required');
  }
  
  if (!lastName || lastName.trim() === '') {
    errors.push('Last name is required');
  }
  
  if (!streetAddress || streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  
  if (!city || city.trim() === '') {
    errors.push('City is required');
  }
  
  if (!stateProvince || stateProvince.trim() === '') {
    errors.push('State/Province is required');
  }
  
  if (!postalCode || postalCode.trim() === '') {
    errors.push('Postal code is required');
  } else if (!validatePostalCode(postalCode)) {
    errors.push('Postal code format is invalid');
  }
  
  if (!country || country.trim() === '') {
    errors.push('Country is required');
  }
  
  if (!email || email.trim() === '') {
    errors.push('Email is required');
  } else if (!validateEmail(email)) {
    errors.push('Email format is invalid');
  }
  
  if (!phone || phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!validatePhone(phone)) {
    errors.push('Phone number format is invalid');
  }
  
  // If validation errors, re-render form with errors and previous values
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      values: req.body
    });
  }
  
  // Insert into database
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  ]);
  
  // Write database to file
  const data = db.export();
  fs.writeFileSync(dbPath, data);
  
  // Redirect to thank you page
  res.redirect('/thank-you?firstName=' + encodeURIComponent(firstName));
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Initialize and start server
async function startServer() {
  await initializeDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
  
  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM signal received: closing HTTP server and database');
    server.close(() => {
      console.log('HTTP server closed');
    });
    
    // Write database to file before closing
    if (db) {
      const data = db.export();
      fs.writeFileSync(dbPath, data);
      db.close();
    }
  });
  
  return server;
}

// Start server
const server = await startServer();

export default server;