/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, registerObserver, unregisterObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false

  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      // Track active observer for dependency tracking
      const active = getActiveObserver()
      if (active && active !== observer) {
        observer.name = active.name
      }
      
      // Execute the side effect
      if (!disposed) {
        try {
          updateFn(currentValue)
        } catch (error) {
          console.error('Callback error:', error)
        }
      }
      
      return currentValue ?? value as T
    }
  }
  
  // Register this observer to be notified of dependency changes
  registerObserver(observer as Observer<unknown>)
  
  // Execute initial callback to establish dependency tracking
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Unregister to prevent further notifications
    unregisterObserver(observer as Observer<unknown>)
    
    // Clear references to prevent memory leaks
    observer.value = value
    observer.updateFn = () => value as T
  }
}
