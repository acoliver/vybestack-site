/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  registerObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  let computedValue: T | undefined = value

  const observer: Observer<T> = {
    name: options?.name,
    value: computedValue,
    updateFn: () => {
      // Recompute when dependencies change
      const previous = getActiveObserver()
      setActiveObserver(observer)
      try {
        computedValue = updateFn(computedValue)
      } finally {
        setActiveObserver(previous)
      }
      return computedValue
    }
  }

  // Register this observer to be notified of dependency changes
  registerObserver(observer as Observer<unknown>)

  // Initial computation
  updateObserver(observer as Observer<T>)

  return (): T => {
    // Track active observer for dependency registration
    const active = getActiveObserver()
    if (active && active !== observer) {
      observer.name = active.name
    }
    return computedValue!
  }
}
