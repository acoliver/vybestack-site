/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Global registry for tracking dependencies
const observers: Set<Observer<unknown>> = new Set()

export function registerObserver<T>(observer: Observer<T>): void {
  observers.add(observer as Observer<unknown>)
}

export function unregisterObserver<T>(observer: Observer<T>): void {
  observers.delete(observer as Observer<unknown>)
}

export function notifyObserver<T>(observer: Observer<T>): void {
  try {
    updateObserver(observer as Observer<T>)
  } catch (error) {
    console.error('Observer notification error:', error)
  }
}

export function notifyAllObservers(): void {
  // Create a copy to avoid issues during iteration
  const observerList = Array.from(observers)
  for (const observer of observerList) {
    try {
      updateObserver(observer as Observer<unknown>)
    } catch (error) {
      // Silently handle errors to prevent breaking the chain
      console.error('Observer notification error:', error)
    }
  }
}
