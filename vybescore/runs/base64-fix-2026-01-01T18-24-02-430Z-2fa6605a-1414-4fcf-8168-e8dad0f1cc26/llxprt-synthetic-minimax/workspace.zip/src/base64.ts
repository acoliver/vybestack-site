/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with optional padding.
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Add padding if missing (Base64 requires padding for proper decoding)
  let normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  
  // Handle missing padding
  const remainder = normalized.length % 4;
  if (remainder === 2) {
    normalized += '==';
  } else if (remainder === 3) {
    normalized += '=';
  } else if (remainder !== 0) {
    throw new Error('Invalid Base64 input: incorrect padding');
  }

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
