import type { ReportData } from '../types/index.js';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Input must be a valid JSON object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid "entries" field (must be an array)');
  }

  const entries = obj.entries as unknown[];
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Entry at index ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Entry at index ${i} missing or invalid "label" field (must be a string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Entry at index ${i} missing or invalid "amount" field (must be a number)`);
    }
  }

  return data as ReportData;
}
