import type { ReportFormat } from '../types/index.js';

export interface CliArgs {
  dataFile: string;
  format: ReportFormat;
  outputFile?: string;
  includeTotals: boolean;
}

function parseArgv(): string[] {
  return process.argv.slice(2);
}

function hasFlag(args: string[], flag: string): boolean {
  return args.includes(flag);
}

function getValueAfterFlag(args: string[], flag: string): string | undefined {
  const index = args.indexOf(flag);
  if (index === -1 || index + 1 >= args.length) {
    return undefined;
  }
  return args[index + 1];
}

export function parseCliArgs(): CliArgs {
  const args = parseArgv();

  if (args.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  
  const formatValue = getValueAfterFlag(args, '--format');
  if (!formatValue) {
    throw new Error('Missing required --format flag');
  }

  if (formatValue !== 'markdown' && formatValue !== 'text') {
    throw new Error(`Unsupported format: ${formatValue}`);
  }

  const outputFile = getValueAfterFlag(args, '--output');
  const includeTotals = hasFlag(args, '--includeTotals');

  return {
    dataFile,
    format: formatValue as ReportFormat,
    outputFile,
    includeTotals,
  };
}
