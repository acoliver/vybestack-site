import type { ReportData, ReportOptions, ReportRenderer } from '../types/index.js';

export function renderText(data: ReportData, options: ReportOptions): string {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  
  // Summary
  lines.push(data.summary);
  
  // Entries section
  lines.push('Entries:');
  
  // Entries
  for (const entry of data.entries) {
    const amount = entry.amount.toFixed(2);
    lines.push(`- ${entry.label}: $${amount}`);
  }
  
  // Total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}

export const textRenderer: ReportRenderer = {
  render: renderText,
};
