import type { ReportFormat, ReportRenderer } from '../types/index.js';
import { markdownRenderer } from './markdown.js';
import { textRenderer } from './text.js';

export const formatters: Record<ReportFormat, ReportRenderer> = {
  markdown: markdownRenderer,
  text: textRenderer,
};

export function getFormatter(format: ReportFormat): ReportRenderer {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}
