#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportOptions } from '../types/index.js';
import { parseCliArgs } from '../utils/args.js';
import { validateReportData } from '../utils/validation.js';
import { getFormatter } from '../formats/index.js';

function readJsonFile(filePath: string): unknown {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${filePath}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw new Error(`Error reading file: ${filePath} - ${error instanceof Error ? error.message : String(error)}`);
  }
}

function writeOutput(content: string, filePath?: string): void {
  if (filePath) {
    try {
      fs.writeFileSync(filePath, content, 'utf-8');
    } catch (error) {
      throw new Error(`Error writing to file: ${filePath} - ${error instanceof Error ? error.message : String(error)}`);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  try {
    const args = parseCliArgs();
    
    const rawData = readJsonFile(args.dataFile);
    const data = validateReportData(rawData);
    
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };
    
    const formatter = getFormatter(args.format);
    const output = formatter.render(data, options);
    
    writeOutput(output, args.outputFile);
    
    process.exit(0);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}