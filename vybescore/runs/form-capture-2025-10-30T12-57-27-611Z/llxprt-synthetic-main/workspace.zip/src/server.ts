import express, { Request, Response } from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { promises as fsPromises } from 'fs';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dbPath = join(__dirname, '..', 'data', 'submissions.sqlite');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use(express.static(join(__dirname, '..', 'public')));

// Set the view engine to EJS
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'templates'));

let db: Database | null = null;

// Initialize the database
async function initDatabase(): Promise<void> {
  try {
    // Create the data directory if it doesn't exist
    await fsPromises.mkdir(dirname(dbPath), { recursive: true });
    
    // Load sql.js WASM module
    // @ts-expect-error - sql.js doesn't have proper TypeScript definitions
    const SqlJs = await initSqlJs({
      locateFile: (file: string) => join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });
    
    let databaseBuffer: Buffer | Uint8Array = new Uint8Array();
    try {
      // Try to load an existing database
      databaseBuffer = await fsPromises.readFile(dbPath);
    } catch (err) {
      // If the database doesn't exist, create an empty one
      databaseBuffer = new Uint8Array();
    }
    
    // Create or open the database
    db = new SqlJs.Database(databaseBuffer);
    
    // Create the table if it doesn't exist
    const schema = await fsPromises.readFile(join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
    if (db) {
      db.run(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save the database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    fsPromises.writeFile(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Close the database
function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
    console.log('Database connection closed');
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhoneNumber(phone: string): boolean {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Validate required fields are not empty
  const requiredFields: Array<keyof FormData> = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`
      });
    }
  }
  
  // Validate email format
  if (formData.email && !validateEmail(formData.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }
  
  // Validate phone number format
  if (formData.phone && !validatePhoneNumber(formData.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number with digits, spaces, parentheses, dashes, and an optional leading +'
    });
  }
  
  // Validate postal code format
  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code (letters, numbers, spaces, and dashes are allowed)'
    });
  }
  
  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.first_name || '',
    lastName: req.body.last_name || '',
    streetAddress: req.body.street_address || '',
    city: req.body.city || '',
    stateProvince: req.body.state_province || '',
    postalCode: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      formData: req.body
    });
  }
  
  if (!db) {
    return res.status(500).render('form', {
      errors: [{ field: 'all', message: 'Database error. Please try again.' }],
      formData: req.body
    });
  }
  
  try {
    // Insert submission into database
    db.run(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    // Save the database to disk
    saveDatabase();
    
    // Redirect to thank-you page with the first name as a query parameter
    return res.redirect(302, `/thank-you?name=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Error saving submission:', error);
    return res.status(500).render('form', {
      errors: [{ field: 'all', message: 'Failed to save submission. Please try again.' }],
      formData: req.body
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.name as string || 'friend';
  res.render('thank-you', { firstName });
});

// Start the server
async function startServer(): Promise<void> {
  await initDatabase();
  
  const port = process.env.PORT || 3000;
  const server = app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
  
  // Handle graceful shutdown
  process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down gracefully');
    server.close(() => {
      console.log('HTTP server closed');
      closeDatabase();
      process.exit(0);
    });
  });
  
  process.on('SIGINT', () => {
    console.log('Received SIGINT, shutting down gracefully');
    server.close(() => {
      console.log('HTTP server closed');
      closeDatabase();
      process.exit(0);
    });
  });
  
  return;
}

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
