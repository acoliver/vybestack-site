import { readFile, writeFile } from 'fs/promises';
import { ReportData, FormatOptions } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Map of supported formats to their render functions
const formatRenderers: Record<string, (data: ReportData, options?: FormatOptions) => string> = {
  markdown: renderMarkdown,
  text: renderText
};

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  // Parse arguments
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1];
  
  if (!formatRenderers[format]) {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }
  
  const includeTotals = args.includes('--includeTotals');
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : null;
  
  try {
    // Read and parse JSON data
    const dataContent = await readFile(dataPath, 'utf-8');
    const data: ReportData = JSON.parse(dataContent);
    
    // Validate required fields
    if (!data.title || !data.summary || !Array.isArray(data.entries)) {
      console.error('Error: Invalid data format. Missing required fields.');
      process.exit(1);
    }
    
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
        console.error('Error: Invalid entry format in data.');
        process.exit(1);
      }
    }
    
    // Render report
    const options: FormatOptions = { includeTotals };
    const report = formatRenderers[format](data, options);
    
    // Output report
    if (outputPath) {
      await writeFile(outputPath, report, 'utf-8');
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(report);
    }
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON in data file.');
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
}

// Run the CLI
main().catch(error => {
  console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  process.exit(1);
});