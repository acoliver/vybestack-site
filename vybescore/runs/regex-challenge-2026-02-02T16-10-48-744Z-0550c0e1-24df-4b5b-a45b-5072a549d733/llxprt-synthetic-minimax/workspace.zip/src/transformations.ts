/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize first character of each sentence
  // Insert exactly one space between sentences
  // Collapse extra spaces while preserving abbreviations
  
  if (!text) return text;
  
  // Process character by character
  let result = '';
  let shouldCapitalize = true;
  let lastChar = '';
  
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    
    if (shouldCapitalize && /[a-zA-Z"']/.test(char)) {
      result += char.toUpperCase();
      shouldCapitalize = false;
    } else {
      result += char;
    }
    
    // Check for sentence ending
    if (/[.!?]/.test(lastChar)) {
      // Skip if this might be an abbreviation (e.g., "Dr.")
      if (!/[A-Z]\./.test(result.slice(-3))) {
        // Capitalize next alphabetic character
        shouldCapitalize = true;
      }
    }
    
    lastChar = char;
  }
  
  // Clean up extra spaces between words
  result = result.replace(/[ \t]+/g, ' ').trim();
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Find all URLs in the text
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"']+/gi;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove common trailing punctuation
    return url.replace(/[.,!?;:]*$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// schemes with https:// while leaving existing secure URLs untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Rewrite http://example.com/... to https://...
  // Move docs paths to https://docs.example.com/...
  // Skip host rewrite for dynamic hints or legacy extensions
  
  return text.replace(
    /(http:\/\/)([^\s/]+)(\/[^\s]*)?/gi,
    (match, scheme, host, path = '') => {
      // Always upgrade to https
      let newUrl = `https://${host}`;
      
      // If path begins with /docs/, rewrite host to docs.example.com
      if (path.startsWith('/docs/')) {
        // Check for dynamic hints or legacy extensions
        const hasDynamicHints = /(\?|=|&|cgi-bin)/.test(path);
        const hasLegacyExtensions = /(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)$/i.test(path);
        
        if (!hasDynamicHints && !hasLegacyExtensions) {
          // Rewrite host to docs.domain.com
          newUrl = `https://docs.${host}`;
        }
      }
      
      newUrl += path;
      return newUrl;
    }
  );
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Extract year from mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, accounting for different month lengths)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic month validation
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 29 for February (leap year check omitted for simplicity)
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // All validations passed, return year
  return year;
}
