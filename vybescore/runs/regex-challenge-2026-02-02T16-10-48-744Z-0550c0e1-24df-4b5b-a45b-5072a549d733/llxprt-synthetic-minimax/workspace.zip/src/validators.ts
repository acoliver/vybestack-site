export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation using regex
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^(?!.*\.\.)(?!.*\.$)[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non\-digit characters except the leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for leading +1
  let phoneNumber = cleaned;
  
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2);
  } else if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must be 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // All parts must be digits
  if (!/^\d{10}$/.test(phoneNumber)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non\-digit, non+ characters
  const cleaned = value.replace(/[^\d+]/g, '');
  
  let phoneNumber = cleaned;
  
  // Check for optional country code +54
  if (phoneNumber.startsWith('+54')) {
    phoneNumber = phoneNumber.substring(3);
  }
  
  // Check for optional mobile indicator 9
  if (phoneNumber.startsWith('9')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Check for optional trunk prefix 0 (required when no country code)
  if (phoneNumber.startsWith('0')) {
    phoneNumber = phoneNumber.substring(1);
  } else if (!value.startsWith('+54')) {
    // If no country code, must start with 0
    return false;
  }
  
  // Validate area code: 2\-4 digits, first digit 1-9
  if (phoneNumber.length < 8 || phoneNumber.length > 12) {
    return false;
  }
  
  const areaCodeLength = Math.min(4, Math.max(2, phoneNumber.length - 6));
  const areaCode = phoneNumber.substring(0, areaCodeLength);
  const subscriberNumber = phoneNumber.substring(areaCodeLength);
  
  // Area code must start with 1-9 and be 2\-4 digits
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6\-8 digits total
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and symbols like X Æ A\-12
  const nameRegex = /^[\p{L}\p{M}\s'\\-]+$/u;
  
  // Must not be empty and should be a reasonable length
  if (!value || value.trim().length === 0 || value.length > 100) {
    return false;
  }
  
  // Must match the pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Should not contain only special characters
  const lettersAndMarks = value.match(/[\p{L}\p{M}]/gu) || [];
  
  if (lettersAndMarks.length === 0) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non\-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check for valid prefixes
  const visaRegex = /^4\d{12}(\d{3})?(\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const mastercard2Regex = /^2[2\-7]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  let isValidCard = false;
  
  if (visaRegex.test(cleaned)) {
    isValidCard = true;
  } else if (mastercardRegex.test(cleaned) || mastercard2Regex.test(cleaned)) {
    isValidCard = true;
  } else if (amexRegex.test(cleaned)) {
    isValidCard = true;
  }
  
  if (!isValidCard) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
