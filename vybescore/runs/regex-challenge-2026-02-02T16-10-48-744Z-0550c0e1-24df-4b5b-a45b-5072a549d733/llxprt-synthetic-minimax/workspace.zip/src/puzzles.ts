/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  // Use word boundary to match whole words only
  const regex = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out the exceptions
  const filteredMatches = matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exc => exc.toLowerCase() === lowerWord);
  });
  
  return [...new Set(filteredMatches)]; // Remove duplicates
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where token appears after a digit and not at the beginning of string
  // Use lookbehind to ensure there's a digit before and not at string start
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // Find token after a digit and return the full digit+token sequence
  const matches = text.match(new RegExp(`(?<!^)\\d${escapedToken}`, 'gi')) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol
  // No whitespace, no immediate repeated sequences
  
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  if (!/[!@#$%^&*()_+=[{};':"\\|,.<>?-]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab" pattern)
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger positive result
  
  // First, check if it looks like an IPv4 address - if so, reject immediately
  const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // IPv6 patterns (simplified but effective):
  // Full IPv6: x:x:x:x:x:x:x:x (8 groups of 1-4 hex digits)
  // Shorthand: x::x or :: (leading/trailing double colons)
  const fullIpv6Regex = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  const shorthandRegex = /^([0-9a-fA-F]{0,4}:+)*::([0-9a-fA-F]{0,4}:+)*[0-9a-fA-F]{0,4}$/;
  
  // Check for basic IPv6 format
  if (fullIpv6Regex.test(value) || shorthandRegex.test(value)) {
    return true;
  }
  
  // Additional patterns for mixed formats
  const mixedRegex = /^([0-9a-fA-F]{1,4}:){1,6}[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/;
  if (mixedRegex.test(value)) {
    return true;
  }
  
  // Check for standard IPv6 notation within the text
  if (/[0-9a-fA-F]*:[0-9a-fA-F]*::[0-9a-fA-F]*/.test(value)) {
    return true;
  }
  
  return false;
}
