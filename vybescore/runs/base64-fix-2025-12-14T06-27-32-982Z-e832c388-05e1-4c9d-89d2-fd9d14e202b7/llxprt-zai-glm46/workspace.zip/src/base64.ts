/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input format and structure.
 */
function validateBase64Input(input: string): void {
  // Check for empty input
  if (!input) {
    throw new Error('Failed to decode Base64 input: empty input');
  }

  // Check for too many padding characters
  const paddingCount = (input.match(/=/g) || []).length;
  if (paddingCount > 2) {
    throw new Error('Failed to decode Base64 input: too many padding characters');
  }

  // Basic Base64 validation - check for valid characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Failed to decode Base64 input: contains invalid characters');
  }
}

/**
 * Check if Base64 input has correct padding structure.
 */
function hasValidPaddingStructure(input: string): boolean {
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) {
    return true; // No padding is valid
  }

  const length = input.length;
  const paddingCount = length - paddingIndex;
  
  // Padding can only be 1 or 2 characters
  if (paddingCount > 2) {
    return false;
  }

  // If there's padding, check that the total length is valid
  return (length % 4 === 0);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and rejects invalid Base64 payloads.
 */
export function decode(input: string): string {
  validateBase64Input(input);

  if (!hasValidPaddingStructure(input)) {
    throw new Error('Failed to decode Base64 input: invalid padding structure');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}