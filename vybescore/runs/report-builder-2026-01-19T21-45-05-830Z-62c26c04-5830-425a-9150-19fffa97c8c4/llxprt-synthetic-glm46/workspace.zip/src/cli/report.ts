#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { exit } from 'node:process';
import type { ReportData, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArguments {
  dataFile: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArguments {
  const parsed: CliArguments = {
    dataFile: '',
    format: 'markdown',
    outputPath: undefined,
    includeTotals: false,
  };

  let dataFileFound = false;
  let formatFound = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg.startsWith('--')) {
      switch (arg) {
        case '--format':
          i++;
          if (i >= args.length) {
            console.error('Error: --format requires a value');
            exit(1);
          }
          {
            const formatValue = args[i];
            if (formatValue !== 'markdown' && formatValue !== 'text') {
              console.error('Error: Unsupported format');
              exit(1);
            }
            parsed.format = formatValue;
            formatFound = true;
          }
          break;
        case '--output':
          i++;
          if (i >= args.length) {
            console.error('Error: --output requires a value');
            exit(1);
          }
          {
            parsed.outputPath = args[i];
          }
          break;
        case '--includeTotals':
          parsed.includeTotals = true;
          break;
        default:
          console.error(`Error: Unknown option ${arg}`);
          exit(1);
      }
    } else {
      if (!dataFileFound) {
        parsed.dataFile = arg;
        dataFileFound = true;
      } else {
        console.error('Error: Too many positional arguments');
        exit(1);
      }
    }
  }

  if (!dataFileFound) {
    console.error('Error: Data file path is required');
    exit(1);
  }

  if (!formatFound) {
    console.error('Error: --format is required');
    exit(1);
  }

  return parsed;
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title field');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary field');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries field');
  }

  for (const entry of reportData.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid JSON: entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid JSON: entry missing or invalid label field');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid JSON: entry missing or invalid amount field');
    }
  }
}

function main() {
  try {
    const args = process.argv.slice(2);
    const parsedArgs = parseArguments(args);

    let dataString: string;
    
    try {
      dataString = readFileSync(parsedArgs.dataFile, { encoding: 'utf-8' });
    } catch (error) {
      console.error(`Error: Could not read file ${parsedArgs.dataFile}: ${(error as Error).message}`);
      exit(1);
    }

    let parsedData: unknown;
    
    try {
      parsedData = JSON.parse(dataString);
    } catch (error) {
      console.error(`Error: Invalid JSON in file ${parsedArgs.dataFile}: ${(error as Error).message}`);
      exit(1);
    }

    try {
      validateReportData(parsedData);
    } catch (error) {
      console.error(`Error: ${error}`);
      exit(1);
    }

    const formatRenderers = {
      markdown: renderMarkdown,
      text: renderText,
    };

    const renderer = formatRenderers[parsedArgs.format];
    const output = renderer.render(parsedData, { includeTotals: parsedArgs.includeTotals });

    if (parsedArgs.outputPath) {
      try {
        writeFileSync(parsedArgs.outputPath, output, { encoding: 'utf-8' });
        console.log(`Report written to ${parsedArgs.outputPath}`);
      } catch (error) {
        console.error(`Error: Could not write to file ${parsedArgs.outputPath}: ${(error as Error).message}`);
        exit(1);
      }
    } else {
      console.log(output);
    }

  } catch (error) {
    console.error('Error: An unexpected error occurred');
    exit(1);
  }
}

main();
