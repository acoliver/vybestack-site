import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Initialize sql.js
import initSqlJs from 'sql.js';
/// <reference path="./sqljs.d.ts" />

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const publicPath = path.resolve(__dirname, '..', 'public');
const templatesPath = path.resolve(__dirname, 'templates');

const app = express();
const port = process.env.PORT || 3535;

let server: { close: (callback?: () => void) => void } | null = null;
let db: null | { run(sql: string, ...params: unknown[]): void; prepare(sql: string): { run(...params: unknown[]): void; get(): { first_name?: string; [key: string]: unknown } | undefined }; export(): Uint8Array; close(): void } = null;

// Initialize SQLite database
// Initialize SQLite database
async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    let dbBuffer: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      const dbFile = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(dbFile);
      
      db = new SQL.Database(dbBuffer);
    } else {
      // Create the data directory if it doesn't exist
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      // Initialize with schema
      const schema = fs.readFileSync(
        path.resolve(__dirname, '..', 'db', 'schema.sql'),
        'utf8'
      );
      db = new SQL.Database();
      db.run(schema);
      dbBuffer = db.export();
      if (dbBuffer) {
        fs.writeFileSync(dbPath, Buffer.from(dbBuffer));
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(publicPath));

// Initialize database on startup
void initDatabase();

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', templatesPath);

// GET / route - render the contact form
app.get('/', (req, res) => {
  res.render('form', {
    values: {},
    errors: []
  });
});

// POST /submit route - handle form submission
app.post('/submit', async (req, res) => {
  const formData = req.body as {
    firstName?: string;
    lastName?: string;
    streetAddress?: string;
    city?: string;
    stateProvince?: string;
    postalCode?: string;
    country?: string;
    email?: string;
    phone?: string;
  };
  const errors: string[] = [];
  
  // Validation
  if (!formData.firstName || formData.firstName.trim() === '') {
    errors.push('First name is required');
  }
  
  if (!formData.lastName || formData.lastName.trim() === '') {
    errors.push('Last name is required');
  }
  
  if (!formData.streetAddress || formData.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  
  if (!formData.city || formData.city.trim() === '') {
    errors.push('City is required');
  }
  
  if (!formData.stateProvince || formData.stateProvince.trim() === '') {
    errors.push('State/Province is required');
  }
  
  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push('Postal code is required');
  }
  
  if (!formData.country || formData.country.trim() === '') {
    errors.push('Country is required');
  }
  
  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!formData.email || !emailRegex.test(formData.email)) {
    errors.push('A valid email is required');
  }
  
  // Phone number validation - allow digits, spaces, parentheses, dashes, and leading +
  // eslint-disable-next-line no-useless-escape
  const phoneRegex = /^\+?[0-9\s\(\)-]+$/;
  if (!formData.phone || !phoneRegex.test(formData.phone)) {
    errors.push('A valid phone number is required');
  }
  
  if (errors.length > 0) {
    // Re-render the form with errors
    return res.render('form', {
      values: formData,
      errors
    });
  }
  
  // Save to database
  try {
    if (!db) {
      // Try to initialize the database if it's not available
      await initDatabase();
    }
    
    if (!db) throw new Error('Database not initialized');
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    saveDatabase();
    
    // Redirect to thank you page
    return res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    errors.push('An error occurred while saving your submission. Please try again.');
    return res.render('form', {
      values: formData,
      errors
    });
  }
});

// GET /thank-you route
app.get('/thank-you', async (req, res) => {
  // Try to get the most recent submission to display the first name
  let firstName = 'friend';
  try {
    if (!db) {
      // Try to initialize the database if it's not available
      await initDatabase();
    }
    
    if (!db) throw new Error('Database not initialized');
    const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
    const result = stmt.get();
    if (result && result.first_name) {
      firstName = result.first_name;
    }
  } catch (error) {
    console.error('Error getting submission:', error);
  }
  
  res.render('thank-you', { firstName });
});

// Start server
async function startServer(): Promise<void> {
  try {
    await initDatabase();
    
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    // Handle graceful shutdown
    const gracefulShutdown = (): void => {
      if (server) {
        console.log('Shutting down gracefully...');
        server.close(() => {
          console.log('Server closed');
          if (db) {
            db.close();
            console.log('Database closed');
          }
          process.exit(0);
        });
      }
    };
    
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { app, startServer, initDatabase, saveDatabase };

// Start the server if this file is run directly
if (
  process.argv[1] === fileURLToPath(import.meta.url) ||
  (
    process.argv[1].endsWith('.ts') && 
    import.meta.url === `file://${process.argv[1].replace('.ts', '.js')}`
  )
) {
  void startServer();
}
