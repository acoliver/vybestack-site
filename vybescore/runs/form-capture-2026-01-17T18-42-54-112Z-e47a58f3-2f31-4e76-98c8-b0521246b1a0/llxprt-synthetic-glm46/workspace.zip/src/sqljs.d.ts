declare module 'sql.js' {
  interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  interface Statement {
    run(...params: unknown[]): void;
    get(): { first_name?: string; [key: string]: unknown } | undefined;
  }

  interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  function initSqlJs(): Promise<SqlJsStatic>;
  export = initSqlJs;
}