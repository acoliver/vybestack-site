import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { Application } from 'express';

let server: { close: (callback?: () => void) => void } | null = null;
let app: Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Set environment to use a different port for testing
  process.env.PORT = '0'; // Let the OS pick a random port
  
  // Import the server module
  const module = await import('../../src/server.js');
  app = module.app;
  
  // Initialize the database manually in the test
  await module.initDatabase();
  
  server = app.listen(0); // Let the OS pick a random port

  // Return a promise to indicate when the server is ready
  return new Promise<void>((resolve) => {
    if (server) {
      server.on('listening', () => {
        resolve();
      });
    } else {
      resolve();
    }
  });
});

afterAll(async () => {
  if (server) {
    await new Promise<void>((resolve) => {
      server.close(() => {
        resolve();
      });
    });
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
    expect(res.text).toContain('Tell us who you are');
    
    // Use regex patterns to check for HTML elements
    expect(res.text).toMatch(/<input[^>]*name=["']firstName["']/);
    expect(res.text).toMatch(/<input[^>]*name=["']lastName["']/);
    expect(res.text).toMatch(/<input[^>]*name=["']streetAddress["']/);
    expect(res.text).toMatch(/<input[^>]*name=["']city["']/);
    expect(res.text).toMatch(/<input[^>]*name=["']stateProvince["']/);
    expect(res.text).toMatch(/<input[^>]*name=["']postalCode["']/);
    expect(res.text).toMatch(/<input[^>]*name=["']country["']/);
    expect(res.text).toMatch(/<input[^>]*name=["']email["']/);
    expect(res.text).toMatch(/<input[^>]*name=["']phone["']/);
    
    // Check for submit button
    expect(res.text).toMatch(/<button[^>]*type=["']submit["']/);
  });

  it('persists submission and redirects', async () => {
    const submission = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'CA',
      postalCode: '12345',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit the form
    const res = await request(app)
      .post('/submit')
      .send(submission);
    
    // Should redirect to thank you page
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/thank-you');
    
    // Verify database was created and contains the submission
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Check thank you page
    const thanksRes = await request(app).get('/thank-you');
    expect(thanksRes.status).toBe(200);
    expect(thanksRes.text).toContain('Thank you, ');
    expect(thanksRes.text).toContain('wondering why you handed this information to a stranger on the internet');
  });

  it('validates form fields and shows errors', async () => {
    const invalidSubmission = {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: 'invalid-email',
      phone: ''
    };
    
    const res = await request(app)
      .post('/submit')
      .send(invalidSubmission);
    
    expect(res.status).toBe(200);
    expect(res.text).toContain('First name is required');
    expect(res.text).toContain('Last name is required');
    expect(res.text).toContain('Street address is required');
    expect(res.text).toContain('City is required');
    expect(res.text).toContain('State/Province is required');
    expect(res.text).toContain('Postal code is required');
    expect(res.text).toContain('Country is required');
    expect(res.text).toContain('A valid email is required');
    expect(res.text).toContain('A valid phone number is required');
  });
});
