const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64.
 * Uses standard Base64 encoding with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Check for valid Base64 characters
  if (!VALID_BASE64_REGEX.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    // Double-check by re-encoding to ensure validity
    const reEncoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedReEncoded = reEncoded.replace(/=+$/, '');
    const normalizedInput = input.replace(/=+$/, '');
    
    // If the re-encoded normalized form doesn't match input normalized form, 
    // the input was likely invalid
    if (normalizedReEncoded !== normalizedInput) {
      throw new Error('Invalid Base64 input: malformed data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
