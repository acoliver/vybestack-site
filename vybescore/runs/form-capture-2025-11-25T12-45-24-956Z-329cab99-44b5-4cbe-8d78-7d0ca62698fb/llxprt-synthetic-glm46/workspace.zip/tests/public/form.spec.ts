import { describe, expect, it } from 'vitest';

describe('Form Capture Application', () => {
  it('should be able to build successfully', () => {
    expect(true).toBe(true);
  });

  it('should have proper database schema', () => {
    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;
    
    expect(schema).toContain('submissions');
    expect(schema).toContain('first_name');
    expect(schema).toContain('email');
  });
});