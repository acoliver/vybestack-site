import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import ejs from 'ejs';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();

// Constants
const PORT = process.env.PORT || 3535;
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');

// Type definitions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: ImportedSqlJs.Database | null = null;

// Initialize SQLite database
async function initializeDatabase() {
  try {
    const SQL = await initSqlJs();
    
    // Load or create database file
    let dbBuffer: Uint8Array | undefined = undefined;
    if (fs.existsSync(DB_PATH)) {
      const dbFile = fs.readFileSync(DB_PATH);
      dbBuffer = new Uint8Array(dbFile);
    }
    
    db = new SQL.Database(dbBuffer);
    
    // Create tables if they don't exist
    const schema = fs.readFileSync(path.resolve(__dirname, '..', 'db', 'schema.sql'), 'utf8');
    if (db) {
      db.run(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase() {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    if (db) {
      const data = db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(DB_PATH, buffer);
      console.log('Database saved to disk');
    }
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/[^\d]/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required field validation
  Object.entries(data).forEach(([field, value]) => {
    if (!value || value.trim() === '') {
      errors.push({ field, message: `${field.replace(/([A-Z])/g, ' $1').trim()} is required` });
    }
  });
  
  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }
  
  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }
  
  return errors;
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Routes
app.get('/', (_req, res) => {
  const templatePath = path.resolve(__dirname, 'templates', 'form.ejs');
  const templateContent = fs.readFileSync(templatePath, 'utf8');
  const html = ejs.render(templateContent, { 
    errors: [], 
    values: {} 
  });
  res.send(html);
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateFormData(formData);
  
  if (errors.length > 0) {
    const templatePath = path.resolve(__dirname, 'templates', 'form.ejs');
    const templateContent = fs.readFileSync(templatePath, 'utf8');
    const html = ejs.render(templateContent, { 
      errors: errors.map(e => e.message),
      values: formData 
    });
    return res.status(400).send(html);
  }
  
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    // Insert data into database
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    const templatePath = path.resolve(__dirname, 'templates', 'form.ejs');
    const templateContent = fs.readFileSync(templatePath, 'utf8');
    const html = ejs.render(templateContent, {
      errors: ['Failed to save your submission. Please try again.'],
      values: formData
    });
    return res.status(500).send(html);
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName || 'friend';
  const templatePath = path.resolve(__dirname, 'templates', 'thank-you.ejs');
  const templateContent = fs.readFileSync(templatePath, 'utf8');
  const html = ejs.render(templateContent, { firstName });
  res.send(html);
});

// Graceful shutdown
function shutdown() {
  console.log('Shutting down server...');
  if (db) {
    db.close();
    console.log('Database connection closed');
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer() {
  await initializeDatabase();
  
  // Don't start listening if NODE_ENV is test
  let server: unknown = null;
  if (process.env.NODE_ENV !== 'test') {
    server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  }
  
  return { server, listener: app };
}

// Export server for testing
let exportedServer: { server: unknown; listener: unknown } | null = null;

// Start server only if not already started
async function getServer() {
  if (!exportedServer) {
    exportedServer = await startServer();
  }
  return exportedServer;
}

// Export a function that returns the server
export default getServer;

// Handle direct execution
if (import.meta.url === `file://${process.argv[1]}`) {
  getServer().catch(console.error);
}