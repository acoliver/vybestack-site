/**
 * Encode plain text to Base64 using the canonical Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Check for empty string (valid case)
 */
function isEmptyString(input: string): boolean {
  return input.length === 0;
}

/**
 * Check for invalid characters (should only be A-Z, a-z, 0-9, +, /, =)
 */
function hasValidCharacters(input: string): boolean {
  return /^[A-Za-z0-9+/]*={0,2}$/.test(input);
}

/**
 * Check padding rules
 */
function validatePadding(input: string): void {
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) return;

  const padding = input.substring(paddingIndex);
  
  // Padding must be at the end and only contain '='
  if (!/^=+$/.test(padding)) {
    throw new Error('Invalid Base64 input format: invalid padding characters');
  }
  
  // Too much padding
  if (padding.length > 2) {
    throw new Error('Invalid Base64 input format: too much padding');
  }
  
  // Length before padding
  const lengthBeforePadding = paddingIndex;
  if (padding.length === 1 && lengthBeforePadding % 4 !== 3) {
    throw new Error('Invalid Base64 input format: incorrect padding');
  }
  if (padding.length === 2 && lengthBeforePadding % 4 !== 2) {
    throw new Error('Invalid Base64 input format: incorrect padding');
  }
}

/**
 * Validate Base64 string format.
 * Rejects invalid Base64 characters and format.
 */
function validateBase64(input: string): void {
  // Check for empty string (valid case)
  if (isEmptyString(input)) return;

  // Check for invalid characters
  if (!hasValidCharacters(input)) {
    throw new Error('Invalid Base64 input format: contains invalid characters');
  }

  // Check padding rules
  validatePadding(input);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and rejects invalid Base64 strings.
 */
export function decode(input: string): string {
  validateBase64(input);

  try {
    const buffer = Buffer.from(input, 'base64');
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format or characters');
  }
}