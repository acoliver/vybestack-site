import { decode } from './src/base64.js';
try {
  console.log(decode(""));
} catch (e) {
  console.error(e.message);
}