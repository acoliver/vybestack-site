import { readFileSync, writeFileSync } from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData } from '../types/report.js';

function parseArguments(args: string[]): {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  let dataPath: string | undefined;
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    
    if (!arg.startsWith('--')) {
      dataPath = arg;
    } else if (arg === '--format') {
      format = args[++i];
    } else if (arg === '--output') {
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!dataPath) {
    throw new Error('Data file path is required');
  }

  if (!format) {
    throw new Error('Format is required');
  }

  return { dataPath, format, outputPath, includeTotals };
}

function loadReportData(dataPath: string): ReportData {
  try {
    const rawData = readFileSync(dataPath, 'utf-8');
    const jsonData = JSON.parse(rawData);
    
    // Validate required fields
    if (!jsonData.title || typeof jsonData.title !== 'string') {
      throw new Error('Invalid data: title is required and must be a string');
    }
    
    if (!jsonData.summary || typeof jsonData.summary !== 'string') {
      throw new Error('Invalid data: summary is required and must be a string');
    }
    
    if (!jsonData.entries || !Array.isArray(jsonData.entries)) {
      throw new Error('Invalid data: entries is required and must be an array');
    }
    
    // Validate entries structure
    for (let i = 0; i < jsonData.entries.length; i++) {
      const entry = jsonData.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}].label is required and must be a string`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entries[${i}].amount is required and must be a number`);
      }
    }
    
    return jsonData as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, format: string, includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, includeTotals);
    case 'text':
      return renderText(data, includeTotals);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content);
  } else {
    console.log(content);
  }
}

// Main execution
const args = process.argv;
try {
  const { dataPath, format, outputPath, includeTotals } = parseArguments(args);
  const reportData = loadReportData(dataPath);
  const report = renderReport(reportData, format, includeTotals);
  writeOutput(report, outputPath);
} catch (error) {
  console.error(`Error: ${error instanceof Error ? error.message : error}`);
  process.exit(1);
}
