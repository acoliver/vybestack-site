import { ReportData } from '../types/report.js';

export function renderText(data: ReportData, includeTotals: boolean): string {
  const entries = data.entries.map(entry => 
    `- ${entry.label}: $${entry.amount.toFixed(2)}`
  ).join('\n');

  let result = `${data.title}\n\n${data.summary}\n\nEntries:\n${entries}`;

  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    result += `\n\nTotal: $${total.toFixed(2)}`;
  }

  return result;
}