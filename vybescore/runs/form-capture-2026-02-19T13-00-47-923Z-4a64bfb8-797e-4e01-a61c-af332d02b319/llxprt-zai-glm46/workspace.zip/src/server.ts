import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  initializeDatabase,
  insertSubmission,
  saveDatabase,
  closeDatabase,
  type SubmissionData
} from './database.js';
import { validateForm } from './validation.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set EJS as templating engine
app.set('views', path.resolve(__dirname, '..', 'src', 'templates'));
app.set('view engine', 'ejs');

// Extend Request type to include validated data
interface ValidatedRequest extends Request {
  validatedData?: SubmissionData;
}

// GET / - Render the form
app.get('/', (req: Request, res: Response): void => {
  res.render('form', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

// POST /submit - Handle form submission
app.post(
  '/submit',
  (req: ValidatedRequest, res: Response, next: NextFunction): void => {
    const formData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateForm(formData);

    if (!validation.valid) {
      // Render form with errors
      res.status(400).render('form', {
        errors: validation.errorMessages,
        values: formData
      });
      return;
    }

    // Store validated data for next middleware
    req.validatedData = formData;
    next();
  },
  (req: ValidatedRequest, res: Response): void => {
    // Insert into database
    if (!req.validatedData) {
      res.status(400).send('Invalid submission');
      return;
    }

    insertSubmission(req.validatedData);
    saveDatabase();

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  }
);

// GET /thank-you - Render thank you page
app.get('/thank-you', (req: Request, res: Response): void => {
  // Get first name from query param or use a default
  const firstName = typeof req.query.firstName === 'string' 
    ? req.query.firstName 
    : 'friend';
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown handlers
let server: ReturnType<typeof app.listen> | null = null;

async function shutdown(signal: string): Promise<void> {
  console.log(`
${signal} received, shutting down gracefully...`);
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
    });
  }
  
  closeDatabase();
  console.log('Database closed');
  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Start server
async function start(): Promise<void> {
  try {
    await initializeDatabase();
    console.log('Database initialized');

    server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

start();

