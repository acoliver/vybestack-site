export interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: FormErrors;
  errorMessages: string[];
}

export function validateEmail(email: string): boolean {
  // Simple but effective email regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and leading +
  // Examples: +44 20 7946 0958, +54 9 11 1234-5678, (555) 123-4567
  const phoneRegex = /^[+]?[\d\s()\\-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

export function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (UK: SW1A 1AA, Argentina: C1000, B1675, US: 12345)
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

export function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

export function validateForm(formData: {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}): ValidationResult {
  const errors: FormErrors = {};
  const errorMessages: string[] = [];

  // First name
  if (!validateRequired(formData.firstName)) {
    errors.firstName = 'First name is required';
    errorMessages.push('First name is required');
  }

  // Last name
  if (!validateRequired(formData.lastName)) {
    errors.lastName = 'Last name is required';
    errorMessages.push('Last name is required');
  }

  // Street address
  if (!validateRequired(formData.streetAddress)) {
    errors.streetAddress = 'Street address is required';
    errorMessages.push('Street address is required');
  }

  // City
  if (!validateRequired(formData.city)) {
    errors.city = 'City is required';
    errorMessages.push('City is required');
  }

  // State/Province
  if (!validateRequired(formData.stateProvince)) {
    errors.stateProvince = 'State / Province / Region is required';
    errorMessages.push('State / Province / Region is required');
  }

  // Postal code
  if (!validateRequired(formData.postalCode)) {
    errors.postalCode = 'Postal / Zip code is required';
    errorMessages.push('Postal / Zip code is required');
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Postal code must contain only letters, numbers, spaces, and hyphens';
    errorMessages.push('Postal code format is invalid');
  }

  // Country
  if (!validateRequired(formData.country)) {
    errors.country = 'Country is required';
    errorMessages.push('Country is required');
  }

  // Email
  if (!validateRequired(formData.email)) {
    errors.email = 'Email is required';
    errorMessages.push('Email is required');
  } else if (!validateEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
    errorMessages.push('Please enter a valid email address');
  }

  // Phone
  if (!validateRequired(formData.phone)) {
    errors.phone = 'Phone number is required';
    errorMessages.push('Phone number is required');
  } else if (!validatePhone(formData.phone)) {
    errors.phone = 'Phone number may contain digits, spaces, parentheses, dashes, and a leading +';
    errorMessages.push('Phone number format is invalid');
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
    errorMessages
  };
}
