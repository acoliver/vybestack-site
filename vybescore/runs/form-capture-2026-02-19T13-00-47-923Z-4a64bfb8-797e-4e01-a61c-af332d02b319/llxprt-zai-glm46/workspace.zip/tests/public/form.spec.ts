import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express, { Request, Response } from 'express';

let server: ReturnType<express.Application['listen']> | null;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

function expressApplicationFactory() {
  const app = express();
  
  // Set up the same middleware and routes as the main server
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.resolve('public')));
  app.set('views', path.resolve('src', 'templates'));
  app.set('view engine', 'ejs');

  return app;
}

beforeAll(async () => {
  // Import the database and validation functions
  const { initializeDatabase, insertSubmission, saveDatabase } = await import('../../src/database.js');
  const { validateForm } = await import('../../src/validation.js');
  
  await initializeDatabase();

  app = expressApplicationFactory();

  // GET / - Render the form
  app.get('/', (req: Request, res: Response): void => {
    res.render('form', {
      errors: [],
      values: {
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      }
    });
  });

  // POST /submit - Handle form submission
  app.post('/submit', (req: Request, res: Response): void => {
    const formData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateForm(formData);

    if (!validation.valid) {
      res.status(400).render('form', {
        errors: validation.errorMessages,
        values: formData
      });
      return;
    }

    insertSubmission(formData);
    saveDatabase();
    res.redirect(302, '/thank-you');
  });

  // GET /thank-you
  app.get('/thank-you', (req: Request, res: Response): void => {
    const firstName = typeof req.query.firstName === 'string' 
      ? req.query.firstName 
      : 'friend';
    res.render('thank-you', { firstName });
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check all input fields exist with proper labels
    const fields = [
      { label: 'First name', id: 'firstName', name: 'firstName' },
      { label: 'Last name', id: 'lastName', name: 'lastName' },
      { label: 'Street address', id: 'streetAddress', name: 'streetAddress' },
      { label: 'City', id: 'city', name: 'city' },
      { label: 'State / Province / Region', id: 'stateProvince', name: 'stateProvince' },
      { label: 'Postal / Zip code', id: 'postalCode', name: 'postalCode' },
      { label: 'Country', id: 'country', name: 'country' },
      { label: 'Email', id: 'email', name: 'email' },
      { label: 'Phone number', id: 'phone', name: 'phone' }
    ];

    for (const field of fields) {
      const label = $(`label[for="${field.id}"]`);
      expect(label.length).toBeGreaterThan(0);
      expect(label.text().trim()).toBe(field.label);
      
      const input = $(`#${field.id}[name="${field.name}"]`);
      expect(input.length).toBeGreaterThan(0);
    }

    // Check form action and method
    const form = $('form[action="/submit"][method="post"]');
    expect(form.length).toBeGreaterThan(0);
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid input', async () => {
    const invalidData = {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: 'invalid-email',
      phone: ''
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(invalidData);

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorList = $('.error-list');
    expect(errorList.length).toBeGreaterThan(0);
    expect(errorList.text()).toContain('required');
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('h1').text()).toContain('Thank you');
    expect(response.text).toMatch(/stranger on the internet|identity|spam/i);
  });
});
