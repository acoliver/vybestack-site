/**
 * SQLite database management using sql.js (WASM)
 */

import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

export interface SubmissionRecord {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private SQL: SqlJsStatic | null = null;
  private initialized = false;

  /**
   * Initialize the database - loads from file or creates new one
   */
  async initialize(): Promise<void> {
    if (this.initialized) {
      return;
    }

    // Initialize sql.js WASM
    this.SQL = await initSqlJs({
      locateFile: (file: string): string => {
        // Locate the WASM file from node_modules/sql.js/dist
        return path.resolve(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
      }
    });

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const buffer = fs.readFileSync(DB_PATH);
      this.db = new this.SQL.Database(buffer);
      // Ensure schema exists even if loading existing file
      await this.ensureSchema();
    } else {
      this.db = new this.SQL.Database();
      await this.ensureSchema();
      // Ensure data directory exists
      const dataDir = path.dirname(DB_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      this.save();
    }

    this.initialized = true;
  }

  /**
   * Ensure the schema is created
   */
  private async ensureSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    if (fs.existsSync(SCHEMA_PATH)) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      this.db.run(schema);
    } else {
      // Fallback schema if file doesn't exist
      const fallbackSchema = `
        CREATE TABLE IF NOT EXISTS submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          street_address TEXT NOT NULL,
          city TEXT NOT NULL,
          state_province TEXT NOT NULL,
          postal_code TEXT NOT NULL,
          country TEXT NOT NULL,
          email TEXT NOT NULL,
          phone TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
      `;
      this.db.run(fallbackSchema);
    }
  }

  /**
   * Insert a submission into the database
   */
  insertSubmission(submission: SubmissionRecord): number {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city,
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.bind([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.step();
    stmt.free();

    // Get the last insert row id
    const result = this.db.exec('SELECT last_insert_rowid() as id');
    const lastId = result[0]?.values[0]?.[0] as number;

    // Save to disk after insert
    this.save();

    return lastId;
  }

  /**
   * Get all submissions
   */
  getAllSubmissions(): SubmissionRecord[] {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const result = this.db.exec('SELECT * FROM submissions ORDER BY created_at DESC');

    if (result.length === 0) {
      return [];
    }

    const columns = result[0].columns;
    const values = result[0].values;

    return values.map((row: unknown[]) => {
      const record: Record<string, unknown> = {};
      columns.forEach((col: string, index: number) => {
        record[col] = row[index];
      });
      return record as unknown as SubmissionRecord;
    });
  }

  /**
   * Save the database to disk
   */
  save(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const data = this.db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }

  /**
   * Close the database connection
   */
  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    this.initialized = false;
  }
}

// Singleton instance
let dbManager: DatabaseManager | null = null;

/**
 * Get the singleton database manager instance
 */
export function getDatabaseManager(): DatabaseManager {
  if (!dbManager) {
    dbManager = new DatabaseManager();
  }
  return dbManager;
}
