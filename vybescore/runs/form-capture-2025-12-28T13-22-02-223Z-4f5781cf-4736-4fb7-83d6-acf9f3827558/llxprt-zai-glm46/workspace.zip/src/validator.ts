/**
 * Validation utilities for form submissions
 */

export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
}

export interface FormInput {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

/**
 * Email validation regex - simple but effective for common cases
 */
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * Phone validation regex - allows international formats with +, digits, spaces, parentheses, dashes
 */
const PHONE_REGEX = /^\+?[\d\s\-()]+$/;

/**
 * Postal code validation - allows alphanumeric strings with spaces and dashes
 */
const POSTAL_CODE_REGEX = /^[\dA-Za-z\s-]+$/;

/**
 * Required field validator
 */
function validateRequired(value: string, fieldName: string): ValidationError | null {
  const trimmed = value?.trim() ?? '';
  if (!trimmed) {
    return { field: fieldName, message: `${fieldName} is required` };
  }
  return null;
}

/**
 * Email validator
 */
function validateEmail(value: string): ValidationError | null {
  const trimmed = value?.trim() ?? '';
  if (!trimmed) {
    return { field: 'email', message: 'email is required' };
  }
  if (!EMAIL_REGEX.test(trimmed)) {
    return { field: 'email', message: 'Please enter a valid email address' };
  }
  return null;
}

/**
 * Phone validator
 */
function validatePhone(value: string): ValidationError | null {
  const trimmed = value?.trim() ?? '';
  if (!trimmed) {
    return { field: 'phone', message: 'phone is required' };
  }
  if (!PHONE_REGEX.test(trimmed)) {
    return {
      field: 'phone',
      message: 'Please enter a valid phone number (may include +, digits, spaces, parentheses, and dashes)'
    };
  }
  return null;
}

/**
 * Postal code validator
 */
function validatePostalCode(value: string): ValidationError | null {
  const trimmed = value?.trim() ?? '';
  if (!trimmed) {
    return { field: 'postalCode', message: 'postal code is required' };
  }
  if (!POSTAL_CODE_REGEX.test(trimmed)) {
    return {
      field: 'postalCode',
      message: 'Please enter a valid postal code (letters, numbers, and spaces allowed)'
    };
  }
  return null;
}

/**
 * Validate form input
 */
export function validateForm(input: FormInput): ValidationResult {
  const errors: ValidationError[] = [];

  // Required fields
  const requiredFields: Array<keyof FormInput> = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];

  for (const field of requiredFields) {
    let error: ValidationError | null = null;

    if (field === 'email') {
      error = validateEmail(input.email || '');
    } else if (field === 'phone') {
      error = validatePhone(input.phone || '');
    } else if (field === 'postalCode') {
      error = validatePostalCode(input.postalCode || '');
    } else {
      error = validateRequired(input[field] || '', field);
    }

    if (error) {
      errors.push(error);
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Sanitize string input by trimming whitespace
 */
export function sanitizeString(value: string | undefined): string {
  return value?.trim() ?? '';
}
