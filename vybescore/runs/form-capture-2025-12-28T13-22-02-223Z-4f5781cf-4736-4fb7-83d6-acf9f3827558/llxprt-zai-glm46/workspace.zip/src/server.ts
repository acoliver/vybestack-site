/**
 * Express server with SQLite persistence
 */

import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getDatabaseManager, SubmissionRecord } from './database.js';
import { validateForm, sanitizeString, FormInput, ValidationResult } from './validator.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const db = getDatabaseManager();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from /public
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Extend Request type to include typed body
interface TypedRequestBody<T = Record<string, unknown>> extends Request {
  body: T;
}

/**
 * GET / - Render the contact form
 */
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

/**
 * POST /submit - Handle form submission
 */
app.post('/submit', (req: TypedRequestBody, res: Response) => {
  const input: FormInput = {
    firstName: sanitizeString(String(req.body.firstName ?? '')),
    lastName: sanitizeString(String(req.body.lastName ?? '')),
    streetAddress: sanitizeString(String(req.body.streetAddress ?? '')),
    city: sanitizeString(String(req.body.city ?? '')),
    stateProvince: sanitizeString(String(req.body.stateProvince ?? '')),
    postalCode: sanitizeString(String(req.body.postalCode ?? '')),
    country: sanitizeString(String(req.body.country ?? '')),
    email: sanitizeString(String(req.body.email ?? '')),
    phone: sanitizeString(String(req.body.phone ?? ''))
  };

  const validationResult: ValidationResult = validateForm(input);

  if (!validationResult.valid) {
    const errorMessages = validationResult.errors.map((e) => e.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: input
    });
    return;
  }

  // Save to database
  const submission: SubmissionRecord = {
    first_name: input.firstName!,
    last_name: input.lastName!,
    street_address: input.streetAddress!,
    city: input.city!,
    state_province: input.stateProvince!,
    postal_code: input.postalCode!,
    country: input.country!,
    email: input.email!,
    phone: input.phone!
  };

  try {
    db.insertSubmission(submission);
  } catch (error) {
    console.error('Database error:', error);
    throw error;
  }

  // Redirect to thank-you page
  res.redirect(302, '/thank-you');
});

/**
 * GET /thank-you - Render the thank you page
 */
app.get('/thank-you', (req: Request, res: Response) => {
  // Since we redirect after POST, we don't have the form data in session
  // Just render with a generic name - the humorous message is the point
  res.render('thank-you', {
    firstName: 'Friend'
  });
});

/**
 * Error handling middleware
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

/**
 * Start the server
 */
let server: ReturnType<typeof app.listen> | null = null;

export async function startServer(port: number = 3535): Promise<typeof server> {
  // Initialize database
  await db.initialize();

  return new Promise((resolve) => {
    server = app.listen(port, () => {
      console.log(`Server listening on port ${port}`);
      resolve(server);
    });
  });
}

/**
 * Gracefully shutdown the server
 */
export async function stopServer(): Promise<void> {
  if (server) {
    return new Promise((resolve) => {
      server!.close(() => {
        console.log('Server closed');
        db.close();
        resolve();
      });
    });
  }
}

// Handle SIGTERM for graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await stopServer();
  process.exit(0);
});

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  startServer(port).catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
