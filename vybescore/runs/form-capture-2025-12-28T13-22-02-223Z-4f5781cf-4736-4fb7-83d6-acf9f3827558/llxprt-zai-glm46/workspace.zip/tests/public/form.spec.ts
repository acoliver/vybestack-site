import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer, stopServer } from '../../src/server.js';

let server: Awaited<ReturnType<typeof startServer>>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const port = 3536; // Use different port for tests
  server = await startServer(port);
});

afterAll(async () => {
  if (server) {
    await stopServer();
  }
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');

    const $ = cheerio.load(response.text);

    // Check for all form fields with proper labels
    const fields = [
      { id: 'firstName', label: 'First name' },
      { id: 'lastName', label: 'Last name' },
      { id: 'streetAddress', label: 'Street address' },
      { id: 'city', label: 'City' },
      { id: 'stateProvince', label: 'State / Province / Region' },
      { id: 'postalCode', label: 'Postal / Zip code' },
      { id: 'country', label: 'Country' },
      { id: 'email', label: 'Email' },
      { id: 'phone', label: 'Phone number' }
    ];

    for (const field of fields) {
      const input = $(`#${field.id}`);
      expect(input.length).toBe(1);
      expect(input.attr('name')).toBe(field.id);
      const label = $(`label[for="${field.id}"]`);
      expect(label.length).toBe(1);
      expect(label.text().toLowerCase()).toContain(field.label.toLowerCase());
    }

    // Check form action
    const form = $('form[action="/submit"]');
    expect(form.length).toBe(1);
    expect(form.attr('method')?.toLowerCase()).toBe('post');
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(server).post('/submit').type('form').send({
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorList = $('.error-list');
    expect(errorList.length).toBe(1);
    expect(errorList.find('li').length).toBeGreaterThan(0);
  });

  it('validates email format', async () => {
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'invalid-email', // Invalid email
        phone: '+1 555-123-4567'
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errors = $('.error-list li');
    const errorTexts = errors.map((_, el) => $(el).text()).get();
    expect(errorTexts.some((text) => text.toLowerCase().includes('email'))).toBe(true);
  });

  it('validates phone format', async () => {
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'john@example.com',
        phone: 'invalid-phone!' // Contains invalid character
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errors = $('.error-list li');
    const errorTexts = errors.map((_, el) => $(el).text()).get();
    expect(errorTexts.some((text) => text.toLowerCase().includes('phone'))).toBe(true);
  });

  it('accepts international phone formats', async () => {
    const testPhones = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '+91 98765 43210'
    ];

    for (const phone of testPhones) {
      const response = await request(server)
        .post('/submit')
        .type('form')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'TC',
          postalCode: '12345',
          country: 'Test Country',
          email: `test${phone.replace(/\D/g, '')}@example.com`,
          phone: phone
        });

      // Should not fail on phone validation
      if (response.status === 400) {
        const $ = cheerio.load(response.text);
        const errorTexts = $('.error-list li')
          .map((_, el) => $(el).text())
          .get();
        expect(errorTexts.some((text) => text.toLowerCase().includes('phone'))).toBe(false);
      }
    }
  });

  it('accepts international postal code formats', async () => {
    const testPostalCodes = ['SW1A 1AA', 'C1000', 'B1675', '12345'];

    for (const postalCode of testPostalCodes) {
      const response = await request(server)
        .post('/submit')
        .type('form')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'TC',
          postalCode: postalCode,
          country: 'Test Country',
          email: `test${postalCode.replace(/\s/g, '')}@example.com`,
          phone: '+1 555-123-4567'
        });

      // Should not fail on postal code validation
      if (response.status === 400) {
        const $ = cheerio.load(response.text);
        const errorTexts = $('.error-list li')
          .map((_, el) => $(el).text())
          .get();
        expect(errorTexts.some((text) => text.toLowerCase().includes('postal'))).toBe(false);
      }
    }
  });

  it('persists submission and redirects to thank-you page', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Avenue',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request(server).post('/submit').type('form').send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank-you page with humorous message', async () => {
    const response = await request(server).get('/thank-you');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');

    const $ = cheerio.load(response.text);
    const bodyText = $('body').text().toLowerCase();

    // Check for humorous/scam warning content
    expect(bodyText).toMatch(/stranger|internet|spam|identity|messages|offers/);

    // Check for link back to form
    const backLink = $('a[href="/"]');
    expect(backLink.length).toBe(1);
  });

  it('preserves form values on validation error', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'IL',
      postalCode: '62701',
      country: 'USA',
      email: 'invalid-email-format', // Invalid
      phone: '+1 555-123-4567'
    };

    const response = await request(server).post('/submit').type('form').send(formData);

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);

    // Check that valid field values are preserved
    expect($('#firstName').attr('value')).toBe('John');
    expect($('#lastName').attr('value')).toBe('Doe');
    expect($('#city').attr('value')).toBe('Springfield');
    expect($('#email').attr('value')).toBe('invalid-email-format');
  });
});
