#!/usr/bin/env node

import * as fs from 'node:fs';
import { formatRenderers, type Format } from '../formats/index.js';
import { validateReportData } from '../validator.js';

interface CliArgs {
  inputPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputPath = args[0];
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: unknown argument "${arg}"`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputPath, format, outputPath, includeTotals };
}

function isSupportedFormat(format: string): format is Format {
  return format === 'markdown' || format === 'text';
}

function main(): void {
  const args = parseArgs(process.argv.slice(2));

  // Validate format
  if (!isSupportedFormat(args.format)) {
    console.error(`Error: Unsupported format "${args.format}"`);
    process.exit(1);
  }

  // Read and parse input file
  let inputData: unknown;
  try {
    const content = fs.readFileSync(args.inputPath, 'utf-8');
    inputData = JSON.parse(content);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: file not found: ${args.inputPath}`);
    } else if ((error as SyntaxError) instanceof SyntaxError) {
      console.error(`Error: invalid JSON in file ${args.inputPath}: ${(error as Error).message}`);
    } else {
      console.error(`Error: failed to read file ${args.inputPath}: ${(error as Error).message}`);
    }
    process.exit(1);
  }

  // Validate data structure
  let data;
  try {
    data = validateReportData(inputData);
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }

  // Render report
  const renderer = formatRenderers[args.format];
  const output = renderer(data, { includeTotals: args.includeTotals });

  // Write output
  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: failed to write output file: ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
