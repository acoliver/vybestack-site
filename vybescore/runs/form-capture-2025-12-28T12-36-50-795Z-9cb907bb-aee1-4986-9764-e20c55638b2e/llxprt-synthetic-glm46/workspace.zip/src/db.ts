import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';

let db: any = null;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function initDatabase(): Promise<any> {
  if (db) return db;

  const SQL = await import('sql.js');
  const dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
  
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    db = new (SQL as any).Database() as any;
    
    if (existsSync(dbPath)) {
      const file = readFileSync(dbPath);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      db.load(file.buffer as any);
    }
    
    // Create schema if this is a new database
    const schemaPath = join(process.cwd(), 'db', 'schema.sql');
    const schema = readFileSync(schemaPath, 'utf8');
    db.run(schema);
    
    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function getDatabase(): any {
  if (!db) {
    throw new Error('Database not initialized. Call initDatabase() first.');
  }
  return db;
}

export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized.');
  }
  
  const dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const data = db.export();
  writeFileSync(dbPath, Buffer.from(data));
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}