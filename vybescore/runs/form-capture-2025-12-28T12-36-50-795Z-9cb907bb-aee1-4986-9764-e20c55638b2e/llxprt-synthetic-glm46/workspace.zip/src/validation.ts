export interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

export function validateSubmission(data: Partial<SubmissionData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  if (!data.first_name?.trim()) {
    errors.push({ field: 'first_name', message: 'First name is required' });
  }
  
  if (!data.last_name?.trim()) {
    errors.push({ field: 'last_name', message: 'Last name is required' });
  }
  
  if (!data.street_address?.trim()) {
    errors.push({ field: 'street_address', message: 'Street address is required' });
  }
  
  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!data.state_province?.trim()) {
    errors.push({ field: 'state_province', message: 'State/Province/Region is required' });
  }
  
  if (!data.postal_code?.trim()) {
    errors.push({ field: 'postal_code', message: 'Postal/Zip code is required' });
  }
  
  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  }
  
  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  }

  // Email validation (simple regex)
  if (data.email && !isValidEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation (international formats)
  if (data.phone && !isValidPhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

// Postal code validation (alphanumeric)
  if (data.postal_code && !/^[a-zA-Z0-9\s]+$/.test(data.postal_code)) {
    errors.push({ field: 'postal_code', message: 'Please enter a valid postal code' });
  }

  return errors;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow international formats: digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone);
}

// function isValidPostalCode(): boolean {
//   // Allow alphanumeric strings (including spaces for formats like UK)
//   return /* placeholder */ true;
// }