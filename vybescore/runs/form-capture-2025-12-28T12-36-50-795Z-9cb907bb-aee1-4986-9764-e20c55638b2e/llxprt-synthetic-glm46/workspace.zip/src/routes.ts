import express from 'express';
import { initDatabase, saveDatabase } from './db.js';
import { validateSubmission, SubmissionData } from './validation.js';

export function setupRoutes(app: express.Express): void {
  const router = express.Router();

  // Serve static files
  app.use(express.static('public'));

  // Middleware for parsing form data
  router.use(express.urlencoded({ extended: true }));

  // Main form route
  router.get('/', (req, res) => {
    res.render('form', {
      title: 'International Contact Form',
      formData: {},
      errors: []
    });
  });

  // Form submission handler
  router.post('/submit', async (req, res) => {
    const formData = req.body as SubmissionData;
    const errors = validateSubmission(formData);

    if (errors.length > 0) {
      return res.status(400).render('form', {
        title: 'International Contact Form',
        formData,
        errors
      });
    }

    try {
      const db = await initDatabase();
      
      // Insert submission
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, 
          last_name, 
          street_address, 
          city, 
          state_province, 
          postal_code, 
          country, 
          email, 
          phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run(
        formData.first_name,
        formData.last_name,
        formData.street_address,
        formData.city,
        formData.state_province,
        formData.postal_code,
        formData.country,
        formData.email,
        formData.phone
      );
      
      stmt.free();
      saveDatabase();
      
      // Redirect to thank you page
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Error saving submission:', error);
      res.status(500).render('form', {
        title: 'International Contact Form',
        formData,
        errors: [{ field: 'general', message: 'An error occurred while submitting the form. Please try again.' }]
      });
    }
  });

  // Thank you page
  router.get('/thank-you', (req, res) => {
    res.render('thank-you', {
      title: 'Thank You!'
    });
  });

  app.use(router);
}