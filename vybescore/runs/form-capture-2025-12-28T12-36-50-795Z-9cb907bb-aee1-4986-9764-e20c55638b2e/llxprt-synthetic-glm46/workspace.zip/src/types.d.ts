declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): unknown;
    free(): void;
  }

  export interface SqlJsStatic {
    Database: new(buffer?: ArrayBuffer) => Database;
  }

  export default function initSqlJs(): Promise<SqlJsStatic>;
}