import express from 'express';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { closeDatabase } from './db.js';
import { setupRoutes } from './routes.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

async function startServer(): Promise<express.Express> {
  const app = express();
  const port = process.env.PORT || 3535;

  // Configure EJS
  app.set('view engine', 'ejs');
  app.set('views', join(__dirname, '../views'));

  // Setup routes
  setupRoutes(app);

  return new Promise((resolve) => {
    const httpServer = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
      resolve(app);
    });

    // Graceful shutdown handler
    const gracefulShutdown = () => {
      console.log('Shutting down gracefully...');
      httpServer.close(() => {
        closeDatabase();
        console.log('Server closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);

    // Handle uncaught exceptions
    process.on('uncaughtException', (error) => {
      console.error('Uncaught Exception:', error);
      gracefulShutdown();
    });

    process.on('unhandledRejection', (reason, promise) => {
      console.error('Unhandled Rejection at:', promise, 'reason:', reason);
      gracefulShutdown();
    });
  });
}

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default startServer;
