/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, getActiveObserver, setActiveObserver, UpdateFn } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false

  const observer: Observer<unknown> = {
    value,
    updateFn: (): unknown => {
      if (disposed) return value
      
      const oldObserver = getActiveObserver()
      setActiveObserver(observer)
      
      try {
        return updateFn(value)
      } finally {
        setActiveObserver(oldObserver)
      }
    },
  }
  
  // Execute the callback once to set up dependencies
  setActiveObserver(observer)
  observer.value = updateFn(value)
  setActiveObserver(undefined)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}