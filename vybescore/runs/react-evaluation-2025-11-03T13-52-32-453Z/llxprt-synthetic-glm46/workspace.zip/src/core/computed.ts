/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  getActiveObserver,
  setActiveObserver,
  EqualFn,
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observers = new Set<Observer<unknown>>()
  let isEqual: EqualFn<T> | undefined

  if (typeof equal === 'function') {
    isEqual = equal
  } else if (equal === true) {
    isEqual = (lhs: T, rhs: T) => lhs === rhs
  }

  // Track the computed value
  let currentValue: T | undefined = value

  const compute = (): T => {
    const oldObserver = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      const newValue = updateFn(currentValue)
      
      // Only update if value has changed or no equality check
      if (!isEqual || currentValue === undefined || !isEqual(currentValue, newValue)) {
        currentValue = newValue
      }
      
      return currentValue
    } finally {
      setActiveObserver(oldObserver)
    }
  }

  const observer: Observer<unknown> = {
    name: options?.name,
    value: currentValue,
    updateFn: (): unknown => {
      const newValue = compute()
      
      // Notify all dependent observers
      observers.forEach(obs => {
        setActiveObserver(obs)
        obs.value = obs.updateFn(obs.value)
        setActiveObserver(undefined)
      })
      
      return newValue
    },
  }

  // Initialize the computed value
  compute()

  return (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      observers.add(activeObserver)
      return compute()
    }
    return currentValue as T
  }
}