/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  setActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
} from '../types/reactive.js'

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options,
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: typeof equal === 'function'
      ? equal
      : equal === true
      ? (lhs: T, rhs: T) => lhs === rhs
      : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue: T) => {
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }

    s.value = nextValue

    // Notify all observers that this input has changed
    s.observers.forEach(observer => {
      setActiveObserver(observer)
      observer.value = observer.updateFn(observer.value)
      setActiveObserver(undefined)
    })

    return s.value
  }

  return [read, write]
}