/**
 * Encode plain text to standard Base64 with proper padding.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) and includes padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const VALID_ERROR_MSG = 'Invalid Base64 input: contains invalid characters or padding';

/**
 * Validates Base64 padding structure.
 * @param input The input string to validate
 * @throws {Error} If padding is invalid
 */
function validatePadding(input: string): void {
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) {
    return; // No padding
  }

  // Padding can only appear at the end
  const padding = input.substring(paddingIndex);
  
  // Padding must be 1 or 2 '=' characters
  if (padding.length > 2) {
    throw new Error(VALID_ERROR_MSG);
  }
  
  // If there's 1 padding char, the string length must be a multiple of 4
  if (padding.length === 1 && input.length % 4 !== 0) {
    throw new Error(VALID_ERROR_MSG);
  }
  
  // If there are 2 padding chars, the length must be a multiple of 4
  if (padding.length === 2 && input.length % 4 !== 0) {
    throw new Error(VALID_ERROR_MSG);
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Uses the standard Base64 alphabet and validates input.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: must be a non-empty string');
  }
  
  // Check for invalid characters (only canonical Base64 alphabet is allowed)
  if (!/^[A-Za-z0-9+/=]*$/.test(input)) {
    throw new Error(VALID_ERROR_MSG);
  }
  
  // Validate padding structure
  validatePadding(input);
  
  try {
    // Add padding for proper decoding if needed
    const paddedInput = input.padEnd(Math.ceil(input.length / 4) * 4, '=');
    const result = Buffer.from(paddedInput, 'base64').toString('utf8');
    
    // Check if the result contains invalid UTF-8 sequences (replacement chars)
    if (result.includes('\uFFFD')) {
      throw new Error(VALID_ERROR_MSG);
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message === VALID_ERROR_MSG) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
