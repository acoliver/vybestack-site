/**
 * Global observer tracking for dependency management.
 * Shared by all reactive primitives to enable proper dependency tracking.
 */

let activeObserver: (() => void) | undefined = undefined

export function getActiveObserver(): (() => void) | undefined {
  return activeObserver
}

export function setActiveObserver(observer: (() => void) | undefined) {
  activeObserver = observer
}