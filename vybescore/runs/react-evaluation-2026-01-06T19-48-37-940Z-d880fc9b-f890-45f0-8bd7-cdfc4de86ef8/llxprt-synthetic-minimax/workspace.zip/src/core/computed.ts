/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn
} from '../types/reactive.js'
import { getActiveObserver } from './observer.js'

interface ComputedImpl<T> {
  value: T | undefined
  computeFn: UpdateFn<T>
  observers: Set<() => void>
  isComputing: boolean
  reaction: () => void
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  _options?: { name?: string }
): GetterFn<T> {
  const impl: ComputedImpl<T> = {
    value,
    computeFn: updateFn,
    observers: new Set(),
    isComputing: false,
    reaction: () => {}
  }

  const reaction = () => {
    if (impl.isComputing) return
    
    impl.isComputing = true
    try {
      const oldValue = impl.value
      const newValue = impl.computeFn(impl.value)
      impl.value = newValue
      
      // If value changed, notify observers
      if (oldValue !== newValue) {
        for (const observer of impl.observers) {
          observer()
        }
      }
    } finally {
      impl.isComputing = false
    }
  }

  const getter: GetterFn<T> = () => {
    // Register any active observer for dependency tracking
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      impl.observers.add(activeObserver)
    }
    
    // Recalculate the value
    reaction()
    
    return impl.value!
  }

  impl.reaction = reaction

  return getter
}
