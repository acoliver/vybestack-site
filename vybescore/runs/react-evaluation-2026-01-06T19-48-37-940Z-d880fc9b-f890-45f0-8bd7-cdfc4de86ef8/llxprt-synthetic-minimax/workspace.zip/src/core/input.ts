/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'
import { getActiveObserver } from './observer.js'

interface InputImpl<T> {
  value: T
  dependents: Set<() => void>
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  _options?: Options
): InputPair<T> {
  const impl: InputImpl<T> = {
    value,
    dependents: new Set()
  }

  const read: GetterFn<T> = () => {
    // When an input is read, register any active observer as a dependent
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      impl.dependents.add(activeObserver)
    }
    return impl.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = impl.value
    impl.value = nextValue
    
    // Notify all dependents when value changes
    if (oldValue !== nextValue) {
      const dependents = Array.from(impl.dependents)
      for (const dependent of dependents) {
        dependent()
      }
    }
    return impl.value
  }

  return [read, write]
}
