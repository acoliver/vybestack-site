/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, UpdateFn } from '../types/reactive.js'
import { getActiveObserver, setActiveObserver } from './observer.js'

interface CallbackImpl<T> {
  updateFn: UpdateFn<T>
  value?: T
  disposed: boolean
  observer: (() => void) | undefined
}

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const impl: CallbackImpl<T> = {
    updateFn,
    value,
    disposed: false,
    observer: undefined
  }

  const observer = () => {
    if (impl.disposed) return
    impl.updateFn(impl.value)
  }

  const unsubscribe: UnsubscribeFn = () => {
    impl.disposed = true
  }

  // Set this callback as the active observer
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // Execute the update function to establish dependency relationships
    impl.updateFn(impl.value)
  } finally {
    // Restore the previous active observer
    setActiveObserver(previousObserver)
  }

  impl.observer = observer

  return unsubscribe
}
