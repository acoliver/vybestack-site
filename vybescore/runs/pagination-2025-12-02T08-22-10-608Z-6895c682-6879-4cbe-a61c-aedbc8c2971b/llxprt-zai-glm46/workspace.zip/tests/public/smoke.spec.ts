import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('supports pagination parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test page 1 with limit 3
    const response1 = await request(app).get('/inventory?page=1&limit=3');
    expect(response1.status).toBe(200);
    expect(response1.body.page).toBe(1);
    expect(response1.body.limit).toBe(3);
    expect(response1.body.items).toHaveLength(3);
    expect(response1.body.total).toBe(15);
    expect(response1.body.hasNext).toBe(true);

    // Test page 2 with limit 3 (should return items 4-6)
    const response2 = await request(app).get('/inventory?page=2&limit=3');
    expect(response2.status).toBe(200);
    expect(response2.body.page).toBe(2);
    expect(response2.body.limit).toBe(3);
    expect(response2.body.items).toHaveLength(3);
    expect(response2.body.items[0].id).toBe(4); // Should start with item id 4
    expect(response2.body.hasNext).toBe(true);

    // Test page 5 with limit 3 (should return items 13-15, no next)
    const response5 = await request(app).get('/inventory?page=5&limit=3');
    expect(response5.status).toBe(200);
    expect(response5.body.page).toBe(5);
    expect(response5.body.limit).toBe(3);
    expect(response5.body.items).toHaveLength(3);
    expect(response5.body.hasNext).toBe(false);

    // Test page beyond available data
    const response10 = await request(app).get('/inventory?page=10&limit=2');
    expect(response10.status).toBe(200);
    expect(response10.body.page).toBe(10);
    expect(response10.body.limit).toBe(2);
    expect(response10.body.items).toHaveLength(0);
    expect(response10.body.hasNext).toBe(false);
  });

  it('validates pagination parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test non-numeric page
    const responseAlphaPage = await request(app).get('/inventory?page=abc');
    expect(responseAlphaPage.status).toBe(400);
    expect(responseAlphaPage.body.error).toBe('Page must be a positive integer');

    // Test negative page
    const responseNegativePage = await request(app).get('/inventory?page=-1');
    expect(responseNegativePage.status).toBe(400);
    expect(responseNegativePage.body.error).toBe('Page must be a positive integer');

    // Test zero page
    const responseZeroPage = await request(app).get('/inventory?page=0');
    expect(responseZeroPage.status).toBe(400);
    expect(responseZeroPage.body.error).toBe('Page must be a positive integer');

    // Test non-numeric limit
    const responseAlphaLimit = await request(app).get('/inventory?limit=xyz');
    expect(responseAlphaLimit.status).toBe(400);
    expect(responseAlphaLimit.body.error).toBe('Limit must be a positive integer (max 100)');

    // Test negative limit
    const responseNegativeLimit = await request(app).get('/inventory?limit=-5');
    expect(responseNegativeLimit.status).toBe(400);
    expect(responseNegativeLimit.body.error).toBe('Limit must be a positive integer (max 100)');

    // Test limit exceeding maximum
    const responseMaxLimit = await request(app).get('/inventory?limit=101');
    expect(responseMaxLimit.status).toBe(400);
    expect(responseMaxLimit.body.error).toBe('Limit must be a positive integer (max 100)');
  });

  it('uses default values for missing parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5); // Default limit
    expect(response.body.items).toHaveLength(5);
  });
});