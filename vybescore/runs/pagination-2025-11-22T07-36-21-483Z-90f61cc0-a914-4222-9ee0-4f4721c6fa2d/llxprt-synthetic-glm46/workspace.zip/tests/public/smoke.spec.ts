import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('supports pagination with default parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBeGreaterThan(0);
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('supports pagination with custom page and limit', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBeLessThanOrEqual(3);
    expect(response.body.total).toBeGreaterThan(0);
  });

  it('validates pagination parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    // Non-numeric page
    const response1 = await request(app).get('/inventory?page=abc');
    expect(response1.status).toBe(400);
    expect(response1.body.error).toContain('page parameter must be a positive integer');

    // Negative page
    const response2 = await request(app).get('/inventory?page=-1');
    expect(response2.status).toBe(400);
    expect(response2.body.error).toContain('page parameter must be a positive integer');

    // Zero limit
    const response3 = await request(app).get('/inventory?limit=0');
    expect(response3.status).toBe(400);
    expect(response3.body.error).toContain('limit parameter must be greater than 0');

    // Excessive limit
    const response4 = await request(app).get('/inventory?limit=1000');
    expect(response4.status).toBe(400);
    expect(response4.body.error).toContain('limit parameter cannot exceed 100');
  });

  it('calculates hasNext correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    // First page with limit 5 should have next page if there are more than 5 items
    const response1 = await request(app).get('/inventory?page=1&limit=5');
    expect(response1.status).toBe(200);
    expect(response1.body.hasNext).toBe(response1.body.total > 5);

    // Last page should not have next
    if (response1.body.total) {
      const lastPage = Math.ceil(response1.body.total / 5);
      const response2 = await request(app).get(`/inventory?page=${lastPage}&limit=5`);
      expect(response2.status).toBe(200);
      expect(response2.body.hasNext).toBe(false);
    }
  });
});
