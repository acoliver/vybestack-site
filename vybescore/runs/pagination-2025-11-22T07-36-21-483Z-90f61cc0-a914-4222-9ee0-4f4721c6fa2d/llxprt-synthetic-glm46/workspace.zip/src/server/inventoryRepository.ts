import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100; // Prevent excessive queries

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function validatePaginationParams(
  pageParam?: string,
  limitParam?: string
): { isValid: boolean; page?: number; limit?: number; error?: string } {
  // Default values
  let page = 1;
  let limit = DEFAULT_LIMIT;

  // Validate page parameter
  if (pageParam !== undefined) {
    if (!/^\d+$/.test(pageParam)) {
      return { isValid: false, error: 'page parameter must be a positive integer' };
    }
    page = parseInt(pageParam, 10);
    if (page <= 0) {
      return { isValid: false, error: 'page parameter must be greater than 0' };
    }
  }

  // Validate limit parameter
  if (limitParam !== undefined) {
    if (!/^\d+$/.test(limitParam)) {
      return { isValid: false, error: 'limit parameter must be a positive integer' };
    }
    limit = parseInt(limitParam, 10);
    if (limit <= 0) {
      return { isValid: false, error: 'limit parameter must be greater than 0' };
    }
    if (limit > MAX_LIMIT) {
      return { isValid: false, error: `limit parameter cannot exceed ${MAX_LIMIT}` };
    }
  }

  return { isValid: true, page, limit };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;

  // FIXED: offset should now be (page - 1) * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents as priceCents, created_at as createdAt
     FROM inventory 
     ORDER BY id
     LIMIT ? OFFSET ?`
  );
  
  stmt.bind([limit, offset]);
  const items: InventoryItem[] = [];
  
  while (stmt.step()) {
    const row = stmt.getAsObject();
    items.push(mapRow(row));
  }
  
  stmt.free();

  // Calculate hasNext based on whether we'd have more results on the next page
  const hasNext = page * limit < total;

  return {
    items,
    page,
    limit,
    total,
    hasNext
  };
}