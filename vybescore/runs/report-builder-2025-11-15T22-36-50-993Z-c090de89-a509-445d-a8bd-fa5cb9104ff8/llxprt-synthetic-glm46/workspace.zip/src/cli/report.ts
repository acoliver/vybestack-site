#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, ReportOptions, FormatType } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

function parseArguments(): {
  dataPath: string;
  format: FormatType;
  outputPath: string | undefined;
  includeTotals: boolean;
  help: boolean;
} {
  const args = process.argv.slice(2);
  
  const result = {
    dataPath: '',
    format: 'markdown' as FormatType,
    outputPath: undefined as string | undefined,
    includeTotals: false,
    help: false
  };
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--help' || arg === '-h') {
      result.help = true;
      return result;
    }
    
    if (arg === '--format') {
      i++;
      if (i < args.length) {
        const formatValue = args[i];
        if (formatValue === 'markdown' || formatValue === 'text') {
          result.format = formatValue as FormatType;
        } else {
          throw new Error(`Unsupported format: ${formatValue}`);
        }
      } else {
        throw new Error('--format requires a value');
      }
    } else if (arg === '--output') {
      i++;
      if (i < args.length) {
        result.outputPath = args[i];
      } else {
        throw new Error('--output requires a value');
      }
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!result.dataPath) {
      result.dataPath = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }
  
  if (!result.dataPath && !result.help) {
    throw new Error('Data file path is required');
  }
  
  return result;
}

function loadData(path: string): ReportData {
  try {
    const content = readFileSync(path, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON structure');
    }
    
    const reportData = data as Record<string, unknown>;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Missing or invalid title');
    }
    
    if (typeof reportData.summary !== 'string') {
      throw new Error('Missing or invalid summary');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Missing or invalid entries');
    }
    
    const entries = reportData.entries as unknown[];
    const validEntries = entries.every(entry => {
      const entryObj = entry as Record<string, unknown>;
      return entryObj && 
             typeof entryObj.label === 'string' && 
             typeof entryObj.amount === 'number';
    });
    
    if (!validEntries) {
      throw new Error('Invalid entry structure in entries array');
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${path}: ${error.message}`);
    }
    if (error instanceof Error) {
      throw error;
    }
    throw new Error(`Failed to load file ${path}`);
  }
}

function renderReport(data: ReportData, format: FormatType, options: ReportOptions): string {
  switch (format) {
    case 'markdown':
      return markdownRenderer.render(data, options);
    case 'text':
      return textRenderer.render(data, options);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function showHelp(): void {
  console.log(`
Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]

Arguments:
  data.json    Path to JSON file containing report data

Options:
  --format     Output format (required): markdown, text
  --output     Path to output file (optional, defaults to stdout)
  --includeTotals  Include totals in the output
  --help, -h   Show this help message
`);
}

function main(): void {
  try {
    const args = parseArguments();
    
    if (args.help) {
      showHelp();
      return;
    }
    
    const data = loadData(args.dataPath);
    const options: ReportOptions = {
      includeTotals: args.includeTotals
    };
    
    const report = renderReport(data, args.format, options);
    
    if (args.outputPath) {
      writeFileSync(args.outputPath, report, 'utf-8');
      console.log(`Report written to ${args.outputPath}`);
    } else {
      console.log(report);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();