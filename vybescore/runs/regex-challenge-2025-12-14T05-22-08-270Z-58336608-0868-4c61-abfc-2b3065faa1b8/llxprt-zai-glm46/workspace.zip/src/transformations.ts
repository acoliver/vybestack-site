/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Attempts to leave abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First, normalize spacing around sentence endings
  // Replace multiple spaces with single space, but ensure proper spacing after sentence endings
  const normalized = text
    .replace(/\s+/g, ' ') // Collapse multiple spaces
    .replace(/([.!?])\s*/g, '$1 ') // Ensure exactly one space after sentence endings
    .trim(); // Remove leading/trailing spaces
  
  // Common abbreviations to help avoid incorrect sentence splitting
  // This is a heuristic approach - perfect abbreviation detection is complex
  const abbreviations = [
    'Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Mt', 'Jr', 'Sr', 'Gen', 'Col', 'Maj', 'Capt',
    'Lt', 'Gov', 'Pres', 'Sen', 'Rep', 'Atty', 'Pvt', 'Sgt', 'Adm', 'Rev', 'Rt', 'Hon',
    'etc', 'e.g', 'i.e', 'viz', 'vs', 'al', 'ca', 'cf', 'ed', 'eds', 'est', 'etal',
    'ff', 'ibid', 'id', 'n.b', 'op', 'cit', 'seq', 'sq', 'v', 'vol', 'vols',
    'no', 'nos', 'p', 'pp', 'pt', 'pts'
  ];
  
  const abbrevPattern = new RegExp(`\b(${abbreviations.join('|')})[.!?]`, 'i');
  
  // Split into sentences, but be careful about abbreviations
  // This regex splits on sentence endings that are likely sentence boundaries
  const sentences: string[] = [];
  let currentSentence = '';
  
  for (let i = 0; i < normalized.length; i++) {
    currentSentence += normalized[i];
    
    // Check if we have a sentence ending
    if (/[.!?]/.test(normalized[i])) {
      const context = currentSentence.slice(-50); // Look at recent context
      const beforeEnding = context.slice(0, -1);
      
      // Check if this looks like an abbreviation rather than sentence ending
      const wordsBefore = beforeEnding.trim().split(/\s+/);
      const lastWord = wordsBefore[wordsBefore.length - 1] || '';
      
      // If it's a common abbreviation, don't split here
      if (abbrevPattern.test(lastWord + normalized[i])) {
        continue;
      }
      
      // Otherwise, this is likely a sentence ending
      sentences.push(currentSentence.trim());
      currentSentence = '';
    }
  }
  
  // Add any remaining text
  if (currentSentence.trim()) {
    sentences.push(currentSentence.trim());
  }
  
  // Capitalize each sentence
  const capitalizedSentences = sentences.map(sentence => {
    if (!sentence) return '';
    
    // Find the first alphabetic character and capitalize it
    const firstCharIndex = sentence.search(/[a-zA-Z\u00C0-\u024F]/);
    if (firstCharIndex === -1) return sentence;
    
    return sentence.slice(0, firstCharIndex) + 
           sentence[firstCharIndex].toUpperCase() + 
           sentence.slice(firstCharIndex + 1);
  });
  
  // Join sentences back together with proper spacing
  return capitalizedSentences.join('. ').replace(/\.\s*\./g, '.');
}

/**
 * Extracts all URLs from the given text.
 * Returns an array of URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern - matches common URL formats
  // Protocol: http://, https://, ftp://, etc.
  // Domain: with optional www, subdomains, and TLD
  // Optional: port, path, query string, fragment
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"{}|\\^`[\]]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that's likely not part of the URL
    return url.replace(/[.,;:!?'"`)}\]]+$/g, '');
  });
  
  // Remove duplicates while preserving order
  const uniqueUrls: string[] = [];
  const seen = new Set<string>();
  
  for (const url of cleanedUrls) {
    if (!seen.has(url)) {
      seen.add(url);
      uniqueUrls.push(url);
    }
  }
  
  return uniqueUrls;
}

/**
 * Forces all HTTP URLs to use HTTPS while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://, but be careful not to double-convert
  // Negative lookahead to ensure we don't match https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * - Always upgrades http:// to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
// Pattern to match URLs in the text
  const urlRegex = /(https?:\/\/)([^\/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlRegex, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // Check if this is a docs URL that should be rewritten
    if (path.startsWith('/docs/')) {
      // Check for dynamic content indicators that should prevent host rewrite
      const dynamicIndicators = [
        'cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', 
        '.aspx', '.do', '.cgi', '.pl', '.py'
      ];
      
      const hasDynamicContent = dynamicIndicators.some(indicator => 
        path.includes(indicator)
      );
      
      if (!hasDynamicContent) {
        // Rewrite host to docs.example.com
        return secureProtocol + 'docs.example.com' + path;
      }
    }
    
    // Just upgrade the protocol
    return secureProtocol + host + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format dates.
 * Returns 'N/A' when the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = dateRegex.exec(value.trim());
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [
    31, // January
    28, // February (will handle leap year separately)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  // Check for leap year for February
  let maxDays = daysInMonth[month - 1];
  if (month === 2) {
    // Leap year: divisible by 4, not divisible by 100 unless also divisible by 400
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    maxDays = isLeapYear ? 29 : 28;
  }
  
  // Validate day (1-maxDays)
  if (day < 1 || day > maxDays) return 'N/A';
  
  // Validate year (reasonable range)
  if (year < 1900 || year > 2100) return 'N/A';
  
  return yearStr;
}
