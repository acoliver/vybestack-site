export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with typical patterns.
 * Accepts name+tag@example.co.uk style addresses.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email validation regex
  // Local part: letters, digits, + . _ % - but no consecutive dots or starting/ending with dot
  // Domain part: letters, digits, hyphens, dots but no underscores or consecutive dots
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for invalid patterns
  if (!emailRegex.test(value)) return false;
  
  // No consecutive dots in local part or domain
  if (value.includes('..')) return false;
  
  // No leading or trailing dots in local part
  const [local, domain] = value.split('@');
  if (!local || !domain) return false;
  
  if (local.startsWith('.') || local.endsWith('.')) return false;
  
  // Domain cannot start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) return false;
  
  // Domain cannot have consecutive dots
  if (domain.includes('..')) return false;
  
  // No underscores in domain
  if (domain.includes('_')) return false;
  
  // Domain must have at least one dot for TLD
  if (!domain.includes('.')) return false;
  
  // TLD should be at least 2 characters
  const tld = domain.split('.').pop();
  if (!tld || tld.length < 2) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number without country code)
  if (digits.length < 10) return false;
  
  // Check maximum reasonable length
  if (digits.length > 11) return false;
  
  // Handle optional +1 country code
  let phoneDigits = digits;
  if (digits.length === 11) {
    if (digits.startsWith('1')) {
      phoneDigits = digits.slice(1); // Remove the leading 1
    } else {
      return false; // 11 digits but doesn't start with 1
    }
  }
  
  // At this point we should have exactly 10 digits
  if (phoneDigits.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = phoneDigits.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate the original format using regex for more precise checking
  // Support: +1 (212) 555-7890, (212) 555-7890, 212-555-7890, 212.555.7890, 2125557890
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(\s*([2-9]\d{2})\s*\)|([2-9]\d{2}))[\s.-]?(\d{3})[\s.-]?(\d{4})$/;
  
  return phoneRegex.test(value.trim());
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * 
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code (required when country code is omitted)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits (leading digit 1-9)
 * - Subscriber number: 6-8 digits total after area code
 * - Separators: single spaces or hyphens
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation, but keep the structure
  const normalized = value.replace(/[ -]/g, '');
  
  // Pattern explanation:
  // ^(?:\+54|0)? - Optional +54 country code or 0 trunk prefix at start
  // (?:9)? - Optional mobile indicator 9
  // ([1-9]\d{1,3}) - Area code: 2-4 digits, leading digit 1-9 (captured)
  // (\d{6,8})$ - Subscriber number: 6-8 digits
  const basicPattern = /^(?:\+54|0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = basicPattern.exec(normalized);
  if (!match) return false;
  
  const [, areaCode, subscriberNumber] = match;
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // Additional structural validation using regex that maintains format
  // This is more precise and validates the exact format rules
// Additional structural validation using regex that maintains format
  // This is more precise and validates the exact format rules
  
  // Check if the original format matches one of our accepted patterns
  // We'll use a more comprehensive regex that handles all the format requirements
const comprehensivePattern = /^(?:\+54(?:[ -]9)?[ -]?|0(?:[ -]9)?)?([1-9]\d{1,3})(?:[ -]?)(\d{3,4})(?:[ -]?)(\d{4})$/;
  
  const formatMatch = comprehensivePattern.exec(value);
  if (!formatMatch) return false;
  
  // If we have a +54 country code, we don't require the leading 0
  // If we don't have +54, we must have the leading 0 trunk prefix
  const hasCountryCode = value.includes('+54');
  const hasTrunkPrefix = normalized.startsWith('0') && !normalized.startsWith('+54');
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Permits spaces between name parts. Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace and check if empty
  const trimmed = value.trim();
  if (!trimmed) return false;
  
  // Name validation regex:
  // ^\s* - Allow leading spaces
  // [\p{L}\p{M}]+ - Unicode letters and combining marks (accents)
  // (?:['\-\s][\p{L}\p{M}]+)* - Groups of apostrophe, hyphen, or space followed by letters
  // \s*$ - Allow trailing spaces
  // This allows: "John", "Mary-Jane", "O'Connor", "Jean Claude", "José María", "Åström"
  // But rejects: "John123", "X Æ A-12", "John@Doe", etc.
  const nameRegex = /^\s*[\p{L}\p{M}]+(?:['\-\s][\p{L}\p{M}]+)*\s*$/u;
  
  // Check if the name matches the basic pattern
  if (!nameRegex.test(trimmed)) return false;
  
  // Additional checks for obviously invalid patterns
  const cleanName = trimmed.replace(/\s+/g, ' '); // Normalize spaces
  
  // Reject names that look like codes (too many consecutive non-letter characters)
  if (/['\-\s]{2,}/.test(cleanName)) return false;
  
  // Reject names that contain digits or other symbols
  if (/[0-9@#$%^&*()_+=\[\]{}|:";<>,.?/~`]/.test(cleanName)) return false;
  
  // Check minimum length (at least 1 character after removing spaces and punctuation)
  const lettersOnly = cleanName.replace(/['\-\s]/g, '');
  if (lettersOnly.length < 1) return false;
  
  // Check maximum reasonable length
  if (cleanName.length > 100) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Performs Luhn checksum validation and checks valid prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check basic length requirements
  // Visa: 13 or 16 digits
  // Mastercard: 16 digits  
  // AmEx: 15 digits
  if (digits.length < 13 || digits.length > 16) return false;
  
  // Perform Luhn checksum validation
  if (!runLuhnCheck(digits)) return false;
  
  // Visa: starts with 4
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  
  // Mastercard: starts with 51-55, 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  
  // American Express: starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  return visaRegex.test(digits) || mastercardRegex.test(digits) || amexRegex.test(digits);
}
