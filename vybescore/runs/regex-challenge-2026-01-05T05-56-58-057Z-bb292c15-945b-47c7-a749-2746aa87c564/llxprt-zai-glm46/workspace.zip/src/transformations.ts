/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after `.!?`
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces
 * - Preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace - collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence-ending punctuation
  // Match ., !, or ? followed by optional space(s) and a letter
  result = result.replace(/([.!?])\s*([a-zA-Z])/g, '$1 $2');
  
  // Capitalize the first character of the string
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());
  
  // Capitalize after sentence-ending punctuation
  // But be careful with abbreviations (e.g., "Mr.", "Dr.", "etc.")
  const commonAbbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'No', 'etc', 'vs', 'eg', 'ie', 'St'];
  
  // Split into sentences, capitalize, and rejoin
  // This regex handles the sentence splitting while preserving delimiters
  const sentences = result.split(/(?<=[.!?])\s+/);
  
  const capitalized = sentences.map((sentence, index) => {
    if (sentence.length === 0) return sentence;
    
    // Check if it's an abbreviation (for context, look at the sentence)
    const lowerSentence = sentence.toLowerCase();
    const isAbbreviation = commonAbbreviations.some(abbr => 
      lowerSentence.startsWith(abbr.toLowerCase() + '.')
    );
    
    // If it's the first sentence or not an abbreviation, capitalize
    if (index === 0 || !isAbbreviation) {
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
    
    return sentence;
  });
  
  // Join sentences with single space
  return capitalized.join(' ');
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches http://, https://, www. with common TLDs
  // Excludes trailing punctuation (. , ! ? ; :)
  
  const urlRegex = /(https?:\/\/|www\.)[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*(\/[^\s"']*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Still upgrade scheme even when skipping host rewrite
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /http:\/\/example\.com([^\s"']*)/gi;
  
  return text.replace(urlPattern, (match, path) => {
    // Always upgrade scheme to https
    let newUrl = 'https://example.com' + path;
    
    // Check if we should rewrite the host (for /docs/ paths)
    const shouldRewriteHost = path.startsWith('/docs/');
    
    // Dynamic hints that indicate we should NOT rewrite the host
    const dynamicHints = [
      'cgi-bin',
      '?',
      '&',
      '=',
      '.jsp',
      '.php',
      '.asp',
      '.aspx',
      '.do',
      '.cgi',
      '.pl',
      '.py'
    ];
    
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    if (shouldRewriteHost && !hasDynamicHint) {
      // Rewrite to docs.example.com
      newUrl = 'https://docs.example.com' + path;
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [
    31, // January
    28, // February (non-leap year)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  const maxDays = daysInMonth[month - 1];
  
  // Handle February leap years
  if (month === 2) {
    // Check for leap year: divisible by 4, but not by 100 unless also by 400
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    const febMaxDays = isLeapYear ? 29 : 28;
    if (day < 1 || day > febMaxDays) return 'N/A';
  } else {
    // For other months
    if (day < 1 || day > maxDays) return 'N/A';
  }
  
  return yearStr;
}
