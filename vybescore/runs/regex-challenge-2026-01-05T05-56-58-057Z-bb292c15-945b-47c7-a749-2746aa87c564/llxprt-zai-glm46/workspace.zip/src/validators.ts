export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex: local-part@domain
  // Local part: alphanumeric, dots, hyphens, underscores, plus signs
  // But no consecutive dots, no leading/trailing dots
  // Domain: alphanumeric, hyphens, dots (but no underscores)
  // Must have at least 2-char TLD
  
  // First, basic structure check
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check for invalid patterns
  const hasDoubleDot = /\.\./.test(value);
  const hasTrailingDotLocal = /\.@/.test(value);
  const hasLeadingDotLocal = /^\./.test(value);
  const hasUnderscoreInDomain = /@.*_/.test(value);
  const hasTrailingDotDomain = /\.\.$/.test(value);
  
  // Must match regex and not have invalid patterns
  return emailRegex.test(value) && 
         !hasDoubleDot && 
         !hasTrailingDotLocal && 
         !hasLeadingDotLocal && 
         !hasUnderscoreInDomain &&
         !hasTrailingDotDomain;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have at least 10 digits (standard US number)
  if (digitsOnly.length < 10) return false;
  
  // Allow optional +1 country code (11 digits total with country code)
  const withCountryCode = digitsOnly.length === 11 && digitsOnly.startsWith('1');
  const withoutCountryCode = digitsOnly.length === 10;
  
  if (!withCountryCode && !withoutCountryCode) return false;
  
  // Extract the 10-digit phone number (without country code if present)
  const phoneNumber = withCountryCode ? digitsOnly.slice(1) : digitsOnly;
  
  // Validate area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate exchange code (next 3 digits) - cannot start with 0 or 1
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) return false;
  
  // Check that the format is reasonable (common separators)
  // Accept: (xxx) xxx-xxxx, xxx-xxx-xxxx, xxx xxx xxxx, xxxxxxxxx, +1xxxxxxxxxx
  const validFormats = [
    /^\+1\s?\(\d{3}\)\s?\d{3}[-.\s]?\d{4}$/,  // +1 (212) 555-7890
    /^\(\d{3}\)\s?\d{3}[-.\s]?\d{4}$/,         // (212) 555-7890
    /^\d{3}[-.\s]\d{3}[-.\s]\d{4}$/,            // 212-555-7890
    /^\+?\d{10,11}$/,                           // 2125557890, +12125557890
    /^\+1?\s?\d{3}\s\d{3}\s\d{4}$/,            // 212 555 7890
    /^\(\d{3}\)\d{3}-?\d{4}$/,                 // (212)555-7890
    /^\+1\s?\d{3}[-.\s]\d{3}[-.\s]\d{4}$/,     // +1 212-555-7890
  ];
  
  // If options allow extensions, that's a different story
  // For now, we focus on the main phone number validation
  return validFormats.some(format => format.test(value.trim()));
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code (required when country code omitted)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for digit extraction
  // Keep the plus sign for country code detection
  const normalized = value.replace(/[\s-]/g, '');
  
  // Main regex pattern for Argentine phone numbers
  // Must match: [optional +54] [optional 0 trunk] [optional 9 mobile] [area code 2-4 digits starting 1-9] [subscriber 6-8 digits]
  const argPhoneRegex = /^(\+?54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = normalized.match(argPhoneRegex);
  
  if (!match) return false;
  
  const [, , trunkPrefix] = match;
  
  // If no country code, trunk prefix is required
  const hasCountryCode = normalized.startsWith('+54') || normalized.startsWith('54');
  if (!hasCountryCode && !trunkPrefix) return false;
  
  // Area code must be 2-4 digits (already enforced by regex [1-9]\d{1,3})
  
  // Subscriber number must be 6-8 digits (already enforced by regex)
  
  // Validate the original format - allow only digits, plus, spaces, and hyphens
  const hasValidSeparators = /^[\d+\s-]+$/.test(value);
  
  return hasValidSeparators;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and tech-style names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (!value || value.trim().length === 0) return false;
  
  // Regex for valid name characters:
  // - Unicode letters (including accented characters)
  // - Apostrophes (')
  // - Hyphens (-)
  // - Spaces
  // Must contain at least one letter
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  // Check if it contains at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  
  // Check for digits
  const hasDigits = /\d/.test(value);
  
  // Check for invalid symbols (not apostrophe, hyphen, or space)
  
  // Reject "X Æ A-12" style names (has digits)
  if (hasDigits) return false;
  
  // Must match the name regex and have at least one letter
  return nameRegex.test(value) && hasLetter;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be numeric only
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check length and prefix for each card type
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  const validLength = visaRegex.test(cleaned) || 
                      mastercardRegex.test(cleaned) || 
                      amexRegex.test(cleaned);
  
  if (!validLength) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  // Remove any non-digit characters
  const digits = cardNumber.replace(/\D/g, '');
  
  // Double every second digit from right to left
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
