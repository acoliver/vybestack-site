/**
 * Match words starting with the prefix but excluding banned words.
 * Returns array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match words starting with prefix
  // Word boundary \b ensures we match whole words
  const pattern = new RegExp(String.raw`\b${escapedPrefix}[a-zA-Z]*\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches.filter(word => !exceptionsSet.has(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: token must be preceded by a digit (using lookbehind)
  // and must not be at the start of the string
  // Positive lookbehind for a digit, then match the token including the digit
  const pattern = new RegExp(String.raw`\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to policy.
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (/\d/.test(value) === false) return false;
  
  // Must contain at least one symbol (non-alphanumeric, non-whitespace)
  const symbolPattern = String.raw`[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]`;
  const symbolRegex = new RegExp(symbolPattern);
  if (!symbolRegex.test(value)) return false;
  
  // Must not contain whitespace
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // This checks for patterns of 2+ characters that repeat
  const repeatedSequencePattern = /(.{2,})\1/;
  if (repeatedSequencePattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::).
 * Excludes IPv4 addresses from triggering positive results.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern
  // Supports:
  // - Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed (shorthand): 2001:db8:85a3::8a2e:370:7334
  // Pattern for IPv6 - looking for colons and hex structure
  
  // Simpler approach: Look for the structure of IPv6
  // IPv6 contains colons separating hex groups
  // And has the characteristic :: shorthand
  
  const hasIPv6Structure = /([0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4}:){1,}:/;
  
  // Make sure it's not just an IPv4 address
  const isPureIPv4 = /^((25[0-5]|(2[0-4]|1?[0-9])?[0-9])\.){3}(25[0-5]|(2[0-4]|1?[0-9])?[0-9])$/.test(value.trim());
  
  return hasIPv6Structure.test(value) && !isPureIPv4;
}
