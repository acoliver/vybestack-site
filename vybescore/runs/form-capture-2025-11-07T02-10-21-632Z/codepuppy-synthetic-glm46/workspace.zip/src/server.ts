import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs/promises';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const initSqlJs = require('sql.js');

interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
  [key: string]: string | undefined;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

class FormServer {
  public app: express.Application;
  private server: ReturnType<express.Application['listen']> | null = null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private db: any; // sql.js Database type
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve('data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    
    // Serve static files from public directory
    this.app.use('/public', express.static(path.join(process.cwd(), 'public')));
    
    // Set up EJS as the view engine
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(process.cwd(), 'src', 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      await fs.mkdir(dataDir, { recursive: true });
      
      // Try to load existing database
      try {
        const dbFile = await fs.readFile(this.dbPath);
        this.db = new SQL.Database(dbFile);
        console.log('Loaded existing database');
      } catch (error) {
        // Database doesn't exist, create new one
        this.db = new SQL.Database();
        console.log('Created new database');
      }
      
      // Initialize schema
      const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      const schema = await fs.readFile(schemaPath, 'utf-8');
      this.db.run(schema);
      
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    try {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      fs.writeFile(this.dbPath, buffer);
      console.log('Database saved to disk');
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateEmail(email: string): boolean {
    // Simple email regex - not perfect but works for validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private validatePhone(phone: string): boolean {
    // Allow international formats: digits, spaces, parentheses, dashes, leading +
    const phoneRegex = /^[+]?[\d\s()\-—]+$/;
    return phoneRegex.test(phone) && phone.trim().length >= 7;
  }

  private validatePostalCode(postalCode: string): boolean {
    // Allow alphanumeric strings, spaces, dashes (international support)
    const postalRegex = /^[\w\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.trim().length >= 2;
  }

  private validateForm(values: FormValues): ValidationResult {
    const errors: string[] = [];

    // Required field validation
    const requiredFields = [
      { field: 'firstName', name: 'First name' },
      { field: 'lastName', name: 'Last name' },
      { field: 'streetAddress', name: 'Street address' },
      { field: 'city', name: 'City' },
      { field: 'stateProvince', name: 'State / Province / Region' },
      { field: 'postalCode', name: 'Postal / Zip code' },
      { field: 'country', name: 'Country' },
      { field: 'email', name: 'Email' },
      { field: 'phone', name: 'Phone number' }
    ];

    for (const { field, name } of requiredFields) {
      const value = values[field]?.trim();
      if (!value || value.length === 0) {
        errors.push(`${name} is required`);
      }
    }

    // Email validation
    if (values.email && !this.validateEmail(values.email.trim())) {
      errors.push('Please enter a valid email address');
    }

    // Phone validation
    if (values.phone && !this.validatePhone(values.phone.trim())) {
      errors.push('Please enter a valid phone number (international format allowed)');
    }

    // Postal code validation
    if (values.postalCode && !this.validatePostalCode(values.postalCode.trim())) {
      errors.push('Please enter a valid postal code');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private setupRoutes(): void {
    // GET / - render the form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // GET /thank-you - render thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = req.query.firstName as string || 'friend';
      res.render('thank-you', { firstName });
    });

    // POST /submit - handle form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      const formValues: FormValues = {
        firstName: req.body.firstName?.trim(),
        lastName: req.body.lastName?.trim(),
        streetAddress: req.body.streetAddress?.trim(),
        city: req.body.city?.trim(),
        stateProvince: req.body.stateProvince?.trim(),
        postalCode: req.body.postalCode?.trim(),
        country: req.body.country?.trim(),
        email: req.body.email?.trim(),
        phone: req.body.phone?.trim()
      };

      const validation = this.validateForm(formValues);

      if (!validation.isValid) {
        // Re-render form with errors
        return res.status(400).render('form', {
          errors: validation.errors,
          values: formValues
        });
      }

      try {
        // Insert into database
        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          formValues.firstName,
          formValues.lastName,
          formValues.streetAddress,
          formValues.city,
          formValues.stateProvince,
          formValues.postalCode,
          formValues.country,
          formValues.email,
          formValues.phone
        ]);

        stmt.free();

        // Save database to disk
        this.saveDatabase();

        // Redirect to thank you page
        res.redirect(303, `/thank-you?firstName=${encodeURIComponent(formValues.firstName!)}`);

      } catch (error) {
        console.error('Database error:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: formValues
        });
      }
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown
    const gracefulShutdown = (signal: string) => {
      console.log(`\nReceived ${signal}. Shutting down gracefully...`);
      
      if (this.server) {
        this.server.close(() => {
          console.log('HTTP server closed');
          if (this.db) {
            this.db.close();
            console.log('Database closed');
          }
        });
      }
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  }
}

export { FormServer };

// Only start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new FormServer();
  server.start().catch((error) => {
    console.error('Failed to start server:', error);
  });
}