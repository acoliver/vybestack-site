import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

const dbPath = path.resolve('data', 'submissions.sqlite');

// Mock server setup for testing
let testApp: express.Application;

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Set test port to avoid conflicts
  process.env.PORT = '3001';
  
  // Create a test app instance by importing and initializing the server logic
  const { FormServer } = await import('../../src/server.js');
  const server = new FormServer();
  await server.start();
  testApp = server.app;
  
  // Wait a moment for initialization
  await new Promise(resolve => setTimeout(resolve, 200));
});

afterAll(async () => {
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(testApp).get('/');
    expect(response.status).toBe(200);
    
    // Check if we have response.body instead of response.text
    const htmlContent = response.text || response.body;
    expect(htmlContent).toBeDefined();
    expect(typeof htmlContent).toBe('string');
    
    const $ = cheerio.load(htmlContent);
    
    // Check for all required form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    // Submit form
    const response = await request(testApp)
      .post('/submit')
      .send(formData);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(303);
    expect(response.headers.location).toContain('/thank-you?firstName=John');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
