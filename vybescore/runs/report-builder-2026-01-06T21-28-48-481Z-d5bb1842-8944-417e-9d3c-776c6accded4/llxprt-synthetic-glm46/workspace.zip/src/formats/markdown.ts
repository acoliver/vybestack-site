import type { ReportData, ReportRenderer } from '../types.js';

const formatAmount = (amount: number): string => {
  return `$${amount.toFixed(2)}`;
};

export const renderMarkdown: ReportRenderer = (data: ReportData, includeTotals: boolean): string => {
  const lines: string[] = [];
  
  lines.push(`# ${data.title}`);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('## Entries');
  
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }
  
  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push('');
    lines.push(`**Total:** ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
};