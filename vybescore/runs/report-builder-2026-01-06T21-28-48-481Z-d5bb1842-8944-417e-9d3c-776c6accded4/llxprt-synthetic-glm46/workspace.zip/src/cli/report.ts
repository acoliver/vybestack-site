#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { exit } from 'process';
import type { ReportData, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): { dataPath: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }
  
  const dataPath = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format is required and must specify a value');
    exit(1);
  }
  
  const format = args[formatIndex + 1];
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');
  
  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid report data: expected an object');
  }
  
  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid report data: title must be a string');
  }
  
  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid report data: summary must be a string');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }
  
  for (const entry of reportData.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid report data: each entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid report data: each entry must have a string label');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid report data: each entry must have a numeric amount');
    }
  }
  
  return reportData as unknown as ReportData;
}

function main(): void {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArguments();
    
    let fileContent: string;
    try {
      fileContent = readFileSync(dataPath, 'utf-8');
    } catch (error) {
      console.error(`Error reading file ${dataPath}: ${error instanceof Error ? error.message : String(error)}`);
      exit(1);
    }
    
    let data: unknown;
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error parsing JSON: ${error instanceof Error ? error.message : String(error)}`);
      exit(1);
    }
    
    const reportData = validateReportData(data);
    
    const renderers: Record<string, ReportRenderer> = {
      markdown: renderMarkdown,
      text: renderText,
    };
    
    const renderer = renderers[format];
    if (!renderer) {
      console.error(`Unsupported format: ${format}`);
      exit(1);
    }
    
    const output = renderer(reportData, includeTotals);
    
    if (outputPath) {
      try {
        writeFileSync(outputPath, output, 'utf-8');
        console.log(`Report written to ${outputPath}`);
      } catch (error) {
        console.error(`Error writing to file ${outputPath}: ${error instanceof Error ? error.message : String(error)}`);
        exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    exit(1);
  }
}

main();
