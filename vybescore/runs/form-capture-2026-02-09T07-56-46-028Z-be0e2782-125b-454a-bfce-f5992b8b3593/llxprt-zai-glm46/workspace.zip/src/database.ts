import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';
import type { FormData, SubmissionRecord } from './types.js';

const DATA_DIR = join(process.cwd(), 'data');
const DB_PATH = join(DATA_DIR, 'submissions.sqlite');
const SCHEMA_PATH = join(process.cwd(), 'db', 'schema.sql');

export class DatabaseManager {
  private db: Database | null = null;
  private SQL: SqlJsStatic | null = null;

  /**
   * Initialize the SQLite database with sql.js.
   * Loads existing database or creates a new one with schema.
   */
  async initialize(): Promise<void> {
    try {
      this.SQL = await initSqlJs();

      // Ensure data directory exists
      if (!existsSync(DATA_DIR)) {
        mkdirSync(DATA_DIR, { recursive: true });
      }

      // Load existing database or create new one
      if (existsSync(DB_PATH)) {
        const buffer = readFileSync(DB_PATH);
        this.db = new this.SQL.Database(buffer);
      } else {
        this.db = new this.SQL.Database();
        await this.loadSchema();
        this.save();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  /**
   * Load and execute the database schema from schema.sql
   */
  private async loadSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const schema = readFileSync(SCHEMA_PATH, 'utf-8');
      this.db.run(schema);
    } catch (error) {
      console.error('Failed to load schema:', error);
      throw error;
    }
  }

  /**
   * Insert a new submission into the database.
   * Returns the ID of the inserted record.
   */
  insertSubmission(data: FormData): number {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const stmt = this.db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city,
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.bind([
        data.firstName,
        data.lastName,
        data.streetAddress,
        data.city,
        data.stateProvince,
        data.postalCode,
        data.country,
        data.email,
        data.phone,
      ]);

      stmt.step();
      stmt.free();

      const result = this.db.exec('SELECT last_insert_rowid() as id');
      const lastId = result[0].values[0][0] as number;

      this.save();
      return lastId;
    } catch (error) {
      console.error('Failed to insert submission:', error);
      throw error;
    }
  }

  /**
   * Retrieve all submissions from the database.
   */
  getAllSubmissions(): SubmissionRecord[] {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const result = this.db.exec('SELECT * FROM submissions ORDER BY created_at DESC');
      
      if (result.length === 0) {
        return [];
      }

      const columns = result[0].columns;
      const values = result[0].values;

      return values.map((row: unknown[]) => {
        const record: Record<string, string | number> = {};
        columns.forEach((col: string, index: number) => {
          const camelCase = this.toCamelCase(col);
          record[camelCase] = row[index] as string | number;
        });
        return record as unknown as SubmissionRecord;
      });
    } catch (error) {
      console.error('Failed to retrieve submissions:', error);
      throw error;
    }
  }

  /**
   * Save the in-memory database to disk.
   */
  save(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      writeFileSync(DB_PATH, buffer);
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  /**
   * Close the database connection.
   */
  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  /**
   * Convert snake_case to camelCase.
   */
  private toCamelCase(str: string): string {
    return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
  }
}

// Singleton instance
let dbManager: DatabaseManager | null = null;

export function getDatabaseManager(): DatabaseManager {
  if (!dbManager) {
    dbManager = new DatabaseManager();
  }
  return dbManager;
}
