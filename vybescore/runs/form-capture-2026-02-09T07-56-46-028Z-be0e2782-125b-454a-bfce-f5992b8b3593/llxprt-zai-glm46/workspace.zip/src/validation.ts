import type { FormData, ValidationError } from './types.js';

/**
 * Validates email format using a simple regex pattern.
 * Accepts standard email formats with alphanumeric characters and common symbols.
 */
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Validates phone number format.
 * Accepts international formats with digits, spaces, parentheses, dashes, and optional leading +.
 * Examples: +44 20 7946 0958, +54 9 11 1234-5678, (555) 123-4567
 */
function isValidPhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s()-]+$/;
  return phoneRegex.test(phone);
}

/**
 * Validates postal code format.
 * Accepts alphanumeric strings with optional spaces.
 * Handles UK formats (SW1A 1AA), Argentine formats (C1000, B1675), and US ZIP codes.
 */
function isValidPostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode);
}

/**
 * Validates a single field to ensure it's not empty or just whitespace.
 */
function isNotEmpty(value: string): boolean {
  return value.trim().length > 0;
}

/**
 * Validates all form fields and returns an array of validation errors.
 * Returns empty array if all validations pass.
 */
export function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  if (!data.firstName || !isNotEmpty(data.firstName)) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName || !isNotEmpty(data.lastName)) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress || !isNotEmpty(data.streetAddress)) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city || !isNotEmpty(data.city)) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince || !isNotEmpty(data.stateProvince)) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }

  if (!data.postalCode || !isNotEmpty(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  } else if (!isValidPostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, digits, spaces, and dashes' });
  }

  if (!data.country || !isNotEmpty(data.country)) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email || !isNotEmpty(data.email)) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!isValidEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!data.phone || !isNotEmpty(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!isValidPhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number must contain only digits, spaces, parentheses, dashes, and optional leading +' });
  }

  return errors;
}
