import express, { Request, Response } from 'express';
import { getDatabaseManager } from './database.js';
import { validateFormData } from './validation.js';
import type { FormData } from './types.js';
import path from 'path';

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const app = express();
const db = getDatabaseManager();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from public directory
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Set EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

/**
 * GET / - Render the contact form
 */
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

/**
 * POST /submit - Process form submission
 * Validates input, stores in database, and redirects to thank-you page
 */
app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || '',
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    const errorMessages = errors.map((e) => e.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: formData,
    });
    return;
  }

  try {
    db.insertSubmission(formData as FormData);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    const errorMessages = ['An error occurred while saving your submission. Please try again.'];
    res.status(500).render('form', {
      errors: errorMessages,
      values: formData,
    });
  }
});

/**
 * GET /thank-you - Render the thank-you page
 */
app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

/**
 * Error handling middleware
 */
app.use((err: Error, req: Request, res: Response) => {
  console.error('Unhandled error:', err);
  res.status(500).render('form', {
    errors: ['An unexpected error occurred. Please try again.'],
    values: {},
  });
});

/**
 * Start the server and initialize the database
 */
async function startServer(): Promise<void> {
  try {
    await db.initialize();
    const server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });

    // Handle graceful shutdown
    setupGracefulShutdown(server);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

/**
 * Setup graceful shutdown handlers
 */
function setupGracefulShutdown(server: ReturnType<typeof app.listen>): void {
  const shutdown = (signal: string) => {
    console.log(`\n${signal} received. Closing server gracefully...`);
    
    server.close(() => {
      console.log('Server closed.');
      db.close();
      console.log('Database connection closed.');
      process.exit(0);
    });

    // Force shutdown after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout.');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

// Start the server
startServer();
