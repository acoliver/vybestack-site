export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to standard patterns
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email regex that prevents common invalid patterns
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots
  if (value.includes('..')) return false;
  
  // Reject trailing dot in domain
  if (value.endsWith('.')) return false;
  
  // Reject domain starts with dot
  if (value.includes('@.')) return false;
  
  // Reject underscores in domain (domain part after @)
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) return false;
  
  // Ensure we have at least one character before @ and valid domain structure
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats and optional +1 prefix
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Remove optional +1 prefix if present
  const usPhoneDigits = digitsOnly.startsWith('1') && digitsOnly.length > 10 
    ? digitsOnly.substring(1) 
    : digitsOnly;
  
  // Must be exactly 10 digits for standard US format
  if (usPhoneDigits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = usPhoneDigits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Exchange code (middle 3 digits) cannot start with 0 or 1
  const exchangeCode = usPhoneDigits.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles
 * Supports +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters to validate structure
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for different valid patterns:
  // +54 9 11 1234 5678 -> 5491112345678 (13 digits)
  // 011 1234 5678 -> 01112345678 (10 digits)
  // +54 341 123 4567 -> 543411234567 (12 digits)
  // 0341 4234567 -> 03414234567 (10 digits)
  
  // Pattern 1: +54 9 [area code] [subscriber] with mobile prefix
  const mobileWithCountryRegex = /^54(9[1-9]\d{1,3})(\d{6,8})$/;
  const mobileWithCountryMatch = digitsOnly.match(mobileWithCountryRegex);
  if (mobileWithCountryMatch) {
    const areaCode = mobileWithCountryMatch[1].substring(1); // Remove leading 9
    const subscriber = mobileWithCountryMatch[2];
    return areaCode.length >= 2 && areaCode.length <= 4 && 
           subscriber.length >= 6 && subscriber.length <= 8;
  }
  
  // Pattern 2: +54 [area code] [subscriber] without mobile prefix (landline)
  const landlineWithCountryRegex = /^54([1-9]\d{1,3})(\d{6,8})$/;
  const landlineWithCountryMatch = digitsOnly.match(landlineWithCountryRegex);
  if (landlineWithCountryMatch) {
    const areaCode = landlineWithCountryMatch[1];
    const subscriber = landlineWithCountryMatch[2];
    return areaCode.length >= 2 && areaCode.length <= 4 && 
           subscriber.length >= 6 && subscriber.length <= 8;
  }
  
  // Pattern 3: 0 [area code] [subscriber] without country code
  const withoutCountryRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  const withoutCountryMatch = digitsOnly.match(withoutCountryRegex);
  if (withoutCountryMatch) {
    const areaCode = withoutCountryMatch[1];
    const subscriber = withoutCountryMatch[2];
    return areaCode.length >= 2 && areaCode.length <= 4 && 
           subscriber.length >= 6 && subscriber.length <= 8;
  }
  
  return false;
}

/**
 * Validates person names allowing unicode letters, accents, apostrophes, hyphens, and spaces
 * Rejects digits, symbols, and invalid patterns like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Regex that matches unicode letters, accents, apostrophes, hyphens, and spaces
  // \p{L} matches any unicode letter
  // Letters with diacritics are included in \p{L}
  const nameRegex = /^[\p{L}'\- ]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject names that contain only spaces or punctuation
  const trimmedValue = value.trim();
  if (trimmedValue === '') return false;
  
  // Reject names that consist only of special characters (apostrophes, hyphens)
  const lettersOnly = trimmedValue.replace(/[\'\- ]/g, '');
  if (lettersOnly === '') return false;
  
  // Reject names with consecutive spaces
  if (trimmedValue.includes('  ')) return false;
  
  // Reject extremely short names (less than 2 characters after trimming)
  if (trimmedValue.length < 2) return false;
  
  // Reject names that look like "X Æ A-12". This checks for multiple 
  // non-letter characters (except apostrophes and hyphens) mixed with letters
  const validNameRegex = /^[\p{L}]+(?:[ '\-]+[\p{L}]+)*$/u;
  if (!validNameRegex.test(trimmedValue)) return false;
  
  return true;
}

/**
 * Helper function to run Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Loop through values starting from the rightmost digit
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx prefixes and lengths
 * Also runs a Luhn checksum check for basic validation
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length based on card type
  if (digitsOnly.length < 13 || digitsOnly.length > 19) return false;
  
  // Visa: starts with 4, length 13, 16, or 19
  const visaRegex = /^4(\d{12}|\d{15}|\d{18})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^((5[1-5]\d{14})|(2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d{12}|20\d{12}))))$/;
  
  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any of the card types
  const isValidCardType = visaRegex.test(digitsOnly) || 
                         mastercardRegex.test(digitsOnly) || 
                         amexRegex.test(digitsOnly);
  
  if (!isValidCardType) return false;
  
  // Run Luhn algorithm
  return runLuhnCheck(digitsOnly);
}