/**
 * Finds words that begin with the provided prefix but excludes any words in the exceptions list
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const exceptionsSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  // Word pattern: matches sequences of word characters (letters, numbers, underscores)
  const wordPattern = /\b\w+\b/g;
  
  // Track unique results
  const results = new Set<string>();
  let match;
  
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[0];
    
    // Check if word starts with prefix (case-insensitive)
    if (
      word.toLowerCase().startsWith(prefix.toLowerCase()) && 
      !exceptionsSet.has(word.toLowerCase())
    ) {
      results.add(word);
    }
  }
  
  return Array.from(results);
}

/**
 * Returns occurrences of a token that appear after a digit and not at the start of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];
  
  // Escape special RegExp characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Manual approach: find all occurrences and filter those preceded by a digit
  const pattern = new RegExp(escapedToken, 'g');
  let match;
  const results = [];
  
  while ((match = pattern.exec(text)) !== null) {
    const matchIndex = match.index;
    // Check if there's a character before the match and if it's a digit
    if (matchIndex > 0 && /\d/.test(text[matchIndex - 1])) {
      // Include the digit and the token for the result
      results.push(text[matchIndex - 1] + match[0]);
    }
  }
  
  return results;
}

/**
 * Validates password strength according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length requirement
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (/[^A-Za-z0-9]/.test(value) === false) return false;
  
  // Check for immediate repeated sequences (e.g., abab, abcabc, etc.)
// Pattern to detect any sequence of 2-4 characters repeated immediately
  const repeatedSequencePattern = /(.{1,4})\1/;
  if (repeatedSequencePattern.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand :: notation) while excluding IPv4 addresses
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 validation patterns:
  // 1. Full IPv6: eight groups of four hex digits (xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx)
  // 2. Shortened IPv6: groups of 1-4 hex digits separated by colons
  // 3. Shorthand with :: for consecutive zero groups
  // 4. IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  
  // More precise pattern specifically for IPv6:
  
  // More precise pattern specifically for IPv6:
  // Standard case: 8 groups of 1-4 hex digits
  const standardIPv6 = /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Compressed case with ::
  const compressedIPv6 = /([0-9a-fA-F]{1,4}:){0,7}:[0-9a-fA-F]{0,4}/;
  
  // IPv6 with embedded IPv4
  const ipv6WithIPv4 = /([0-9a-fA-F]{1,4}:){0,6}:(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)/;
  
  // Check for any IPv6 match that's NOT part of an IPv4 address
  const hasIPv6 = standardIPv6.test(value) || compressedIPv6.test(value) || ipv6WithIPv4.test(value);
  
  if (!hasIPv6) return false;
  
  // Also ensure we're not just matching an IPv4 address incorrectly
  // IPv4 pattern: four octets, each 0-255
  const ipv4Pattern = /(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)/;
  
  // If there's only an IPv4 pattern and no IPv6-specific pattern, return false
  if (ipv4Pattern.test(value) && !standardIPv6.test(value) && !compressedIPv6.test(value) && !ipv6WithIPv4.test(value)) {
    return false;
  }
  
  return true;
}
