/**
 * Capitalizes the first character of each sentence
 * Includes proper spacing between sentences and preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace multiple sentence ending punctuation with a single one
  let processedText = text.replace(/([.?!]){2,}/g, '$1');
  
  // Ensure sentences are properly spaced: Add space after sentence endings if not present
  processedText = processedText.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Collapse multiple spaces into a single space
  processedText = processedText.replace(/\s{2,}/g, ' ');
  
  // Capitalize first letter of text
  processedText = processedText.charAt(0).toUpperCase() + processedText.slice(1);
  
  // Find sentence boundaries and capitalize the first letter
  // This regex tries to preserve abbreviations like "Dr.", "Mr.", "Mrs.", "Ms.", "Prof.", "St.", "etc."
  const abbreviations = [
    'Dr', 'Mr', 'Mrs', 'Ms', 'Prof', 'St', 'vs', 'etc', 'i\.e', 'e\.g', 'al', 'Ed', 'Jan', 'Feb', 'Mar', 'Apr', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'mt', 'ft'
  ].join('|');
  
  const abbreviationPattern = new RegExp(`\\b(${abbreviations})\\.`, 'gi');
  
  // Split text into sentences, keeping the delimiters
  const sentences = processedText.split(/([.!?])/);
  
  for (let i = 0; i < sentences.length; i++) {
    if (i % 2 === 0) { // This is a sentence (even index)
      const sentence = sentences[i].trim();
      if (sentence.length > 0) {
        // Check if previous part contains an abbreviation
        const isAfterAbbreviation = i > 1 && abbreviationPattern.test(sentences[i-2] + sentences[i-1]);
        
        // Only capitalize if it's not part of an abbreviation
        if (!isAfterAbbreviation &&/[a-z]/.test(sentence[0])) {
          sentences[i] = sentence.charAt(0).toUpperCase() + sentence.slice(1);
        } else if (isAfterAbbreviation && i > 0) {
          // Reconstruct the abbreviation pattern for next iteration
          abbreviationPattern.lastIndex = 0;
        }
      }
    }
  }
  
  // Join sentences back together
  let result = sentences.join('');
  
  // Ensure there's always a space after sentence endings
  result = result.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Remove any space before sentence endings
  return result;
}

/**
 * Extracts URLs from text without trailing punctuation
 * Returns an array of matched URL strings
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex that matches common URL patterns
  const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&//=]*)/gi;
  
  const matches = text.match(urlRegex);
  if (!matches) return [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation: . , ; : ? ! ) ] } " '
    return url.replace(/[.,;:?!)\]\}"']+$/g, '');
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https:// but don't match https://
  // This uses a negative lookahead to avoid matching https://
  return text.replace(/http:\/\/(?!s)/g, 'https://');
}

/**
 * Rewrites URLs according to documentation requirements
 * - Always upgrades http:// to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite when path contains cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Pattern to match URLs with optional path
  const urlPattern = /(http:\/\/)(example\.com)(\/[^\s]*)/g;
  
  return text.replace(urlPattern, (match, protocol, domain, path) => {
    // Always upgrade scheme to https://
    const secureProtocol = 'https://';
    
    // Check if we should skip the host rewrite
    const shouldSkipHostRewrite = 
      path.includes('/cgi-bin') ||                     // cgi-bin paths
      path.includes('?') || path.includes('&') ||    // query parameters
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|\/|#|$)/i.test(path);  // legacy extensions
    
    // If /docs/ path and not skipping host rewrite, use docs.example.com
    if (path.startsWith('/docs/') && !shouldSkipHostRewrite) {
      return `${secureProtocol}docs.${domain}${path}`;
    }
    
    // Otherwise just upgrade the scheme
    return `${secureProtocol}${domain}${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format strings
 * Returns the four-digit year if valid, or 'N/A' if the format is invalid
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Try to match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!dateMatch) return 'N/A';
  
  const [, monthStr, dayStr, yearStr] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year for February
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  if (month === 2 && isLeapYear) {
    if (day < 1 || day > 29) return 'N/A';
  } else {
    if (day < 1 || day > maxDays[month - 1]) return 'N/A';
  }
  
  // If year seems unreasonable (e.g., before 1900 or after current year + 1), return N/A
  const currentYear = new Date().getFullYear();
  if (year < 1900 || year > currentYear + 1) return 'N/A';
  
  return yearStr;
}