/**
 * Capitalizes the first character of each sentence and ensures proper spacing.
 */
export function capitalizeSentences(text: string): string {
  return text
    .split(/([.?!])/)
    .filter(segment => segment.trim() !== '')
    .reduce((result, segment, index) => {
      if (index % 2 === 0) {
        const trimmedSegment = segment.trim();
        if (trimmedSegment === '') return result;
        
        const capitalized = trimmedSegment.charAt(0).toUpperCase() + trimmedSegment.slice(1);
        return result + (result && !result.match(/[.?!]\s*$/) ? ' ' : '') + capitalized;
      } else {
        return result + segment + ' ';
      }
    }, '')
    .trim();
}

/**
/**
 * Extracts all URLs from the given text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Simple URL regex that matches http/https followed by non-whitespace characters
  const urlRegex = /https?:\/\/[^\s<>()]+/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}
/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/]+)(\/docs\/[^\s]*|[^\s]*)/g, (match, host, path) => {
    // Check if we should rewrite the host (only for pure docs paths without dynamic content)
    const shouldRewriteHost = path.startsWith('/docs/') && 
      !path.match(/(cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/);
    
    if (shouldRewriteHost) {
      return `https://docs.${host}${path}`;
    } else {
      return `https://${host}${path}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const year = match[3];
  return year;
}