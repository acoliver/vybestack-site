/**
 * Find words starting with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  const matches = text.match(regex) || [];
  
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Match the token with the preceding digit included
  // Create a regex that finds digit+token combinations, but not tokens at string start
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(${escapedToken})`, 'g');
  const matches: string[] = [];
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    const tokenIndex = match.index;
    // Check if character before match is a digit and token is not at string start
    if (tokenIndex > 0 && /\d/.test(text[tokenIndex - 1])) {
      matches.push(text[tokenIndex - 1] + token);
    }
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace
  if (value.length < 10 || /\s/.test(value)) {
    return false;
  }
  
  // Check for required character classes
  if (!/[A-Z]/.test(value) || !/[a-z]/.test(value) || !/\d/.test(value) || !/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address regex that matches common formats including shorthand
  const ipv6Regex = /([0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}|::([0-9a-fA-F]{0,4}:?){0,6}[0-9a-fA-F]{0,4}/;
  
  return ipv6Regex.test(value);
}