export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation supporting typical addresses and rejecting invalid patterns.
 * Accepts: name+tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compatible email validation with constraints
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format validation
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional constraints
  // Check for consecutive dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for domain starting or ending with dot
  const [localPart, domain] = value.split('@');
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Check for local part starting or ending with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * US phone number validation supporting common formats and optional +1 prefix.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890
 * Disallows: impossible area codes (leading 0/1) and short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Strip spaces, parentheses, hyphens to get clean digits
  const digits = value.replace(/[^\d]/g, '');
  
  // Handle optional +1 country code
  if (digits.startsWith('1') && digits.length === 11) {
    const areaCode = digits.substring(1, 4);
    // Area code cannot start with 0 or 1
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    return true;
  }
  
  // Standard 10-digit US number
  if (digits.length === 10) {
    const areaCode = digits.substring(0, 3);
    // Area code cannot start with 0 or 1
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    return true;
  }
  
  // Handle numbers with extensions if allowed
  if (options?.allowExtensions &&
      digits.length > 10 && 
      (value.includes('ext') || value.includes('x') || value.includes('#'))) {
    // Extract the main 10 or 11 digits before the extension
    return isValidUSPhone(value.slice(0, value.search(/ext|x|#/i)), { allowExtensions: false });
  }
  
  return false;
}

/**
 * Argentine phone number validation covering mobile and landline formats.
 * Accepts: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, parentheses
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Pattern breakdown:
  // ^(?:\+54)? - Optional country code
  // 0? - Optional trunk prefix
  // 9? - Optional mobile indicator
  // (\d{2,4}) - Area code (2-4 digits, leading digit 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  
  const argentinePhoneRegex = /^(?:\+54)?0?9?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, areaCode] = match;
  
  // When no country code, must have trunk prefix (0)
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  // Validate area code (2-4 digits, leading digit 1-9)
  const areaCodeRegex = /^[1-9]\d{1,3}$/;
  if (!areaCodeRegex.test(areaCode)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // First check that it only contains allowed characters
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Should contain at least one letter
  const containsLetter = /[\p{L}]/u.test(value);
  if (!containsLetter) {
    return false;
  }
  
  // Reject if it contains digits (digits are not in our allowed regex, but double-check)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names that are too short or contain only punctuation
  if (value.trim().length < 1) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers using Luhn checksum with Visa/MasterCard/AmEx constraints.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces, hyphens, and other non-digit characters
  const digits = value.replace(/[^\d]/g, '');
  
  // Check basic lengths and prefixes
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/;  // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5][0-9]{14}$/;      // 16 digits, starts with 51-55
  const amexRegex = /^3[47][0-9]{13}$/;             // 15 digits, starts with 34 or 37
  
  // Check if it matches any known card pattern
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}

/**
 * Runs the Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isSecondDigit = false;
  
  // Process each digit from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isSecondDigit) {
      digit *= 2;
      if (digit > 9) {
        digit = digit % 10 + Math.floor(digit / 10);
      }
    }
    
    sum += digit;
    isSecondDigit = !isSecondDigit;
  }
  
  return sum % 10 === 0;
}