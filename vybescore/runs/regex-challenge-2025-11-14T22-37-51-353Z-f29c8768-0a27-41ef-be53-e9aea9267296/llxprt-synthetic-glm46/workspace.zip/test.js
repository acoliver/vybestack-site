import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/src/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/src/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './dist/src/puzzles.js';

console.log('=== Testing tricky inputs ===');

// Email tests
console.log('\nEmail validation:');
console.log('valid: name+tag@example.co.uk', isValidEmail('name+tag@example.co.uk'));
console.log('invalid: double dots', isValidEmail('user@@example..com'));
console.log('invalid: domain with underscore', isValidEmail('user@example_domain.com'));
console.log('invalid: trailing dot', isValidEmail('user@example.com.'));

// US Phone tests
console.log('\nUS Phone validation:');
console.log('valid: (212) 555-7890', isValidUSPhone('(212) 555-7890'));
console.log('valid: 212-555-7890', isValidUSPhone('212-555-7890'));
console.log('valid: 2125557890', isValidUSPhone('2125557890'));
console.log('valid: +1 212-555-7890', isValidUSPhone('+1 212-555-7890'));
console.log('invalid: area code starting with 0', isValidUSPhone('(012) 555-7890'));
console.log('invalid: area code starting with 1', isValidUSPhone('(112) 555-7890'));

// Argentine Phone tests
console.log('\nArgentine Phone validation:');
console.log('valid: +54 9 11 1234 5678', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('valid: 011 1234 5678', isValidArgentinePhone('011 1234 5678'));
console.log('valid: +54 341 123 4567', isValidArgentinePhone('+54 341 123 4567'));
console.log('valid: 0341 4234567', isValidArgentinePhone('0341 4234567'));
console.log('invalid: no country code, no trunk prefix', isValidArgentinePhone('11 1234 5678'));

// Name validation tests
console.log('\nName validation:');
console.log('valid: O\'Connor', isValidName("O'Connor"));
console.log('valid: María José', isValidName('María José'));
console.log('valid: Jean-Luc', isValidName('Jean-Luc'));
console.log('invalid: X Æ A-12', isValidName('X Æ A-12'));
console.log('invalid: John123', isValidName('John123'));

// Text transformation tests
console.log('\nText transformations:');
console.log('Capitalize sentences:', capitalizeSentences('hello world.how are you?i am fine!thanks.'));
console.log('Extract URLs:', extractUrls('Visit http://example.com and https://test.org/path?query=value.'));
console.log('Enforce HTTPS:', enforceHttps('Visit http://example.com and https://secure.com'));
console.log('Rewrite docs URLs:', rewriteDocsUrls('See http://example.com/docs/guide and http://example.com/test.cgi'));

console.log('All tests completed!');