/**
 * Capitalizes the first character of each sentence.
 * - Capitalizes first character after sentence-ending punctuation (. ? !)
 * - Ensures exactly one space between sentences
 * - Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // Capitalize first character of the string
  let result = text;
  if (result.length > 0) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  // Handle simple case: capitalize after sentence endings followed by space
  result = result.replace(/([.!?])\s+([a-z])/g, (_, punct, letter) => punct + ' ' + letter.toUpperCase());
  
  return result;
}

/**
 * Extracts all URLs from the given text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http://, https://, and www. domains
  // Excludes trailing punctuation
  const urlPattern = /https?:\/\/[^\s<>"{}|\\^`[\]]+|www\.[^\s<>"{}|\\^`[\]]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation: .,;:!? but not if it's part of the URL
    return url.replace(/[.,;:!?]+$/, '');
  });
}

/**
 * Replaces all http:// URLs with https://.
 * Leaves existing https:// URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when not followed by s://
  return text.replace(/http:\/\/(?!s)/gi, 'https://');
}

/**
 * Rewrites documentation URLs from http://example.com/docs/... to https://docs.example.com/...
 * - Always upgrades scheme to https://
 * - For /docs/ paths, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // We need to handle:
  // 1. Upgrade to https
  // 2. If path starts with /docs/, rewrite host to docs.example.com
  // 3. Skip host rewrite for cgi-bin, query strings, or legacy extensions
  
  const result = text.replace(
    /https?:\/\/example\.com(\/[^\s<>"{}|\\^`[\]]*)?/gi,
    (match, path = '') => {
      // Check if we should skip host rewrite
      // Skip if path contains cgi-bin, ?, &, =, or legacy extensions
      const skipRewrite = /\/cgi-bin\/|[?&=]|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(path);
      
      // Always upgrade to https
      let newUrl = 'https://';
      
      if (!skipRewrite && path.startsWith('/docs/')) {
        // Rewrite host for docs paths
        newUrl += 'docs.example.com' + path;
      } else if (!skipRewrite && /^\/docs\/?$/i.test(path)) {
        // Exact /docs or /docs/ match
        newUrl += 'docs.example.com' + path;
      } else {
        // Keep original host
        newUrl += 'example.com' + path;
      }
      
      return newUrl;
    }
  );
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns 'N/A' if the format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Special case for February
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  return year;
}
