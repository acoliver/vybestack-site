export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like user@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@(?!.*\.\.)[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // No trailing dots in local part or domain
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // No consecutive dots
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain labels must be valid
  const domainLabels = domain.split('.');
  for (const label of domainLabels) {
    if (label === '' || label.startsWith('-') || label.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix. Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles with optional country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex breakdown:
  // ^\+54? - Optional country code
  // 0? - Optional trunk prefix
  // (9)? - Optional mobile indicator
  // ([1-9]\d{1,3}) - Area code (2-4 digits, leading 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const regex = /^\+54?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(regex);
  
  if (!match) {
    return false;
  }
  
  const [, trunkPrefix, , areaCode, subscriber] = match;
  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = trunkPrefix === '0';
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Validate area code (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // Total validation: country code (54 if present) + trunk prefix (0 if present) + mobile (9 if present) + area code + subscriber
  // Must be 10-14 digits total
  const totalDigits = cleaned.replace(/\+/, '').length;
  if (totalDigits < 10 || totalDigits > 14) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and unusual patterns like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Must have at least one letter, no digits or symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Check for invalid patterns like "X Æ A-12" (contains digits)
  if (/\d/.test(value)) {
    return false;
  }
  
  // No consecutive hyphens or apostrophes
  if (/--|''/.test(value)) {
    return false;
  }
  
  // Cannot start or end with space, hyphen, or apostrophe
  if (/^[\s\-']|[\s\-']$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa (starts with 4, 13 or 16 digits), Mastercard (starts with 51-55, 16 digits),
 * AmEx (starts with 34 or 37, 15 digits).
 * Performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Check Mastercard: starts with 51-55, length 16
  const mastercardRegex = /^5[1-5]\d{14}$/;
  
  // Check AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
