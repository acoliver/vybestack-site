/**
 * Finds all words starting with the given prefix, excluding words in the exceptions list.
 * Words are defined as sequences of word characters (letters, digits, underscore).
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const uniqueMatches = new Set<string>();
  
  for (const match of matches) {
    const matchLower = match.toLowerCase();
    if (!exceptionsLower.includes(matchLower)) {
      uniqueMatches.add(match);
    }
  }
  
  return Array.from(uniqueMatches);
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds for the check.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token
  // Must not be at the start of the string
  const pattern = new RegExp(`\\d${escapedToken}`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validates password strength.
 * Requirements:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric, non-whitespace)
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab", "1212")
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., "abab", "1212", "xyzxyz")
  // Look for patterns of length 2-4 that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const pattern = value.substring(i, i + len);
      const nextPattern = value.substring(i + len, i + len * 2);
      if (pattern === nextPattern) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand :: notation).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // Check for IPv6 pattern in the string
  // IPv6 pattern: hex groups separated by colons, can have :: for compressed zeros
  
  // First, let's find potential IPv6 addresses in the string
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?::[0-9a-fA-F]{1,4}){1,7}|::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){2}(?::[0-9a-fA-F]{1,4}){0,2}|::(?:[fF]{4}:){0,1}(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/g;
  
  const matches = value.match(ipv6Pattern);
  
  if (!matches) {
    return false;
  }
  
  // Validate each match
  for (const match of matches) {
    // Exclude pure IPv4 with port (e.g., 192.168.1.1:8080)
    if (/^\d+\.\d+\.\d+\.\d+:\d+$/.test(match)) {
      continue;
    }
    
    // Must contain at least 2 colons for valid IPv6
    const colonCount = (match.match(/:/g) || []).length;
    if (colonCount < 2) {
      continue;
    }
    
    // Check for :: shorthand (can appear at most once)
    const doubleColonCount = (match.match(/::/g) || []).length;
    if (doubleColonCount > 1) {
      continue;
    }
    
    // Split by : and validate each group
    const groups = match.split(':');
    
    let validGroupCount = 0;
    for (const group of groups) {
      if (group === '') {
        continue; // Empty group from :: is valid
      }
      
      // Each group must be 1-4 hex digits (unless it's IPv4 at the end)
      if (/^[0-9a-fA-F]{1,4}$/.test(group) || /^\d+\.\d+\.\d+\.\d+$/.test(group)) {
        validGroupCount++;
      }
    }
    
    if (validGroupCount >= 2) {
      return true;
    }
  }
  
  return false;
}
