import type {
  UpdateFn,
  Observer,
  UnsubscribeFn
} from '../types/reactive.js'
import { updateObserver } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value: value as T,
    updateFn: (previousValue?: T) => {
      try {
        // Execute the user-provided callback
        return updateFn(previousValue)
      } catch (error) {
        console.error('Error in callback:', error)
        return (previousValue ?? value) as T
      }
    }
  }
  
  // Execute once to establish dependencies and run the callback
  try {
    updateObserver(observer)
  } catch (error) {
    console.error('Error in initial callback execution:', error)
  }
  
  const unsubscribe = (): void => {
    // Remove this observer from being tracked by clearing its update function
    observer.updateFn = () => observer.value!
  }
  
  return unsubscribe
}