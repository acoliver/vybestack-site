import type {
  EqualFn,
  GetterFn,
  UpdateFn,
  Options,
  Observer
} from '../types/reactive.js'
import { getActiveObserver, updateObserver } from '../types/reactive.js'

interface ComputedState<T> {
  value: T
  equalFn?: EqualFn<T>
  isComputing: boolean
  dependencies: Set<Observer<unknown>>
  observers: Set<Observer<unknown>>
}

export function createComputed<T>(
  updateFn: UpdateFn<T>, 
  value?: T, 
  equal?: EqualFn<T>, 
  options?: Options
): GetterFn<T> {
  const state: ComputedState<T> = {
    value: value as T,
    equalFn: equal,
    isComputing: false,
    dependencies: new Set(),
    observers: new Set()
  }
  
  const observer: Observer<T> = {
    name: options?.name,
    value: state.value,
    updateFn: (_previousValue?: T) => {
      // Prevent recursive computation
      if (state.isComputing) {
        return state.value
      }
      
      state.isComputing = true
      
      try {
        // Execute update function without arguments for initial computation
        const result = updateFn()
        return result
      } finally {
        state.isComputing = false
      }
    }
  }
  
  const getter: GetterFn<T> = () => {
    // Get current active observer to register as dependent
    const activeObserver = getActiveObserver()
    
    try {
      // Update the computed value
      const newValue = updateObserver(observer)
      
      // Check if value changed and notify observers
      const _oldValue = state.value
      state.value = newValue
      
      // Notify observers if the value changed
      if (_oldValue !== newValue) {
        state.observers.forEach(observer => {
          updateObserver(observer as Observer<unknown>)
        })
      }
      
      // Register as dependent if there's an active observer
      if (activeObserver) {
        state.dependencies.add(activeObserver as Observer<unknown>)
        state.observers.add(activeObserver as Observer<unknown>)
      }
      
      return state.value
    } catch (error) {
      console.error(`Error in computed value "${options?.name}":`, error)
      return state.value
    }
  }
  
  return getter
}