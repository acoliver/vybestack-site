import type { 
  EqualFn, 
  GetterFn, 
  SetterFn, 
  InputPair, 
  Options,
  Observer
} from '../types/reactive.js'
import { Subject, getActiveObserver, updateObserver } from '../types/reactive.js'

export function createInput<T>(
  value: T, 
  equal?: EqualFn<T>, 
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    value,
    equalFn: equal,
    name: options?.name,
    observers: new Set()
  }
  
  const getter: GetterFn<T> = () => {
    // Register this getter as an observer if there's an active observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      subject.observers.add(activeObserver)
    }
    return subject.value
  }
  
  const setter: SetterFn<T> = (newValue: T) => {
    // Only notify if value actually changed
    if (!subject.equalFn || !subject.equalFn(subject.value, newValue)) {
      subject.value = newValue
      
      // Notify observers by calling their update functions
      // This ensures computed values recalculate and their observers are triggered
      const observers = Array.from(subject.observers)
      observers.forEach(observer => {
        updateObserver(observer as Observer<unknown>)
      })
    }
    
    return subject.value
  }
  
  return [getter, setter]
}