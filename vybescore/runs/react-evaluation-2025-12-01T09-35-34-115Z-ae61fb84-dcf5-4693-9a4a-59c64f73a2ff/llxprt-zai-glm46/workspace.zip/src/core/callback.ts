/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue) => {
      const result = updateFn(currentValue)
      return result !== undefined ? result : currentValue
    },
  }
  
  const execute = () => {
    if (observer.disposed) return
    setActiveObserver(observer)
    try {
      const result = updateFn(observer.value)
      if (result !== undefined) {
        observer.value = result
      }
    } finally {
      setActiveObserver(undefined)
    }
  }
  
  // Initial execution
  execute()
  
  return () => {
    observer.disposed = true
  }
}
