/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    equalFn: typeof equal === 'function' ? equal : undefined,
  }
  
  return (): T => {
    if (o.disposed) {
      if (o.value === undefined) {
        throw new Error('Computed value is undefined and observer is disposed')
      }
      return o.value
    }
    
    // Register this computed as a dependency for any active observer
    const activeObserver = getActiveObserver()
    if (activeObserver && !activeObserver.disposed) {
      // Set up the observer relationship
      (o as Observer<T> & { observer: typeof activeObserver }).observer = activeObserver
    }
    
    const newValue = o.updateFn(o.value)
    
    const hasChanged = o.value === undefined || !o.equalFn || !o.equalFn(o.value, newValue)
    if (hasChanged) {
      o.value = newValue
    }
    
    return o.value!
  }
}
