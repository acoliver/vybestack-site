/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      // Execute update function to get new value
      const newValue = updateFn(prevValue)
      
      // Return the value
      return newValue
    },
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  // Store the dependencies this callback is tracking for cleanup
  const trackedInputs = Array.from(observer._inputs || [])
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all its tracked inputs' dependents
    trackedInputs.forEach((input: Observer<unknown> | Subject<unknown>) => {
      if ('_dependents' in input && input._dependents) {
        const index = input._dependents.indexOf(observer as Observer<unknown>)
        if (index >= 0) {
          input._dependents.splice(index, 1)
        }
      }
    })
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
