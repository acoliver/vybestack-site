/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Normalize equality function
  let equalFn: EqualFn<T> | undefined
  if (equal === false) {
    equalFn = undefined
  } else if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else {
    equalFn = (a: T, b: T) => a === b
  }

  let currentValue = value

  const o: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn: (prevValue?: T): T => {
// Clear previous inputs (dependency tracking)
      if (o._inputs) {
        o._inputs.clear()
      } else {
        o._inputs = new Set()
      }
      
      // Execute update function to get new value (this will establish dependencies)
      const newValue = updateFn(prevValue)
      
      // Check if value actually changed
      if (equalFn && currentValue !== undefined && equalFn(currentValue, newValue)) {
        return currentValue
      }
      
      currentValue = newValue
      return currentValue
    },
  }

  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
// Track this computed as a dependency for the observer
      if (observer._inputs) {
        observer._inputs.add(o as Observer<unknown> | Subject<unknown>)
      } else {
        observer._inputs = new Set([o as Observer<unknown> | Subject<unknown>])
      }
    }
    
    // If this is a direct call (not from another observer), ensure the value is up-to-date
    if (!observer) {
      // Make sure we get the latest value if dependencies have changed
      updateObserver(o)
    }
    
    return currentValue!
  }

  // Compute initial value using updateFn with passed initial value
  if (value !== undefined) {
    currentValue = updateFn(value)
  } else {
    // For computed with no initial value parameter, compute with undefined
    currentValue = updateFn()
  }
  
  // Establish dependencies by running updateObserver if there were dependencies
  if ((o as any)._inputs && (o as any)._inputs.size > 0) {
    updateObserver(o)
  }
  
  return getter
}

/**
 * Notifies all computed values that depend on given subjects
 */
export function notifyComputedDependents(subjects: unknown[]) {
  // Find all computed values that depend on these subjects and update them
  subjects.forEach(subject => {
    if (subject && typeof subject === 'object' && '_dependents' in subject) {
      const dependents = (subject as { _dependents?: Observer<unknown>[] })._dependents
      if (dependents) {
        dependents.forEach((computed: Observer<unknown>) => {
          updateObserver(computed)
        })
      }
    }
  })
}
