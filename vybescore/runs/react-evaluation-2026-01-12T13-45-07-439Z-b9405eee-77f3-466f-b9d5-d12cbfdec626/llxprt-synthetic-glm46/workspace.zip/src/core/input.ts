/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Normalize equality function
  let equalFn: EqualFn<T> | undefined
  if (equal === false) {
    equalFn = undefined
  } else if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else {
    equalFn = (a: T, b: T) => a === b
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Store the current observer to create dependency
      s.observer = observer
      
// Track dependencies for the current observer (which should be computed)
      if (observer._inputs) {
        observer._inputs.add(s as Observer<unknown> | Subject<unknown>)
      } else {
        observer._inputs = new Set([s as Observer<unknown> | Subject<unknown>])
      }
      
      // Add this observer to the list of dependents for this input
      if (!s._dependents) {
        s._dependents = []
      }
      if (!s._dependents.includes(observer as Observer<unknown>)) {
        s._dependents.push(observer as Observer<unknown>)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Update all dependent computed values and callbacks
    if (s._dependents) {
      // Create a copy of dependents array to avoid issues with removal during iteration
      const dependents = [...s._dependents]
      dependents.forEach((dependent: Observer<unknown>) => {
        updateObserver(dependent)
      })
    }
    
    return s.value
  }

  return [read, write]
}
