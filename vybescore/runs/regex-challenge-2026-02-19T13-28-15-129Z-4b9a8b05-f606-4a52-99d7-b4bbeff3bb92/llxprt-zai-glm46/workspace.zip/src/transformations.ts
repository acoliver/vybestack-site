/**
 * Capitalize the first character of each sentence.
 * - Capitalize after .!?
 * - Insert exactly one space between sentences
 * - Collapse extra spaces
 * - Preserve abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: collapse multiple spaces into one
  let normalized = text.replace(/\s+/g, ' ');
  
  // Insert space after sentence endings if missing (but not at end of string)
  normalized = normalized.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  // Capitalize first character of string
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Capitalize after sentence endings
  // Look for .!? followed by space and lowercase letter
  normalized = normalized.replace(/([.!?]\s+)([a-z])/g, (_, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Also handle cases where punctuation is followed directly by lowercase letter
  normalized = normalized.replace(/([.!?])([a-z])/g, (_, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
  
  return normalized.trim();
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http://, https://, and www. without protocol
  const urlPattern = /(?:https?:\/\/|www\.)[^\s<>"'()[\]{}|^`]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation: .,?!;: but keep it if it's part of the URL (like /path/)
    return url.replace(/[.,?!;:]+$/, '');
  });
}

/**
 * Force all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!s)/gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://...
 * When path begins with /docs/, rewrite host to docs.example.com
 * Skip host rewrite for dynamic hints: cgi-bin, query strings, legacy extensions
 * Always upgrade scheme to https
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s<>"']*)/gi;
  
  return text.replace(urlPattern, (match, protocol, host, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check if we should skip host rewrite
    // Skip if path contains: cgi-bin, ?, &, =, .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py
    const skipPatterns = [
      /\/cgi-bin/i,
      /[?&=]/,
      /\.jsp$/i,
      /\.php$/i,
      /\.asp$/i,
      /\.aspx$/i,
      /\.do$/i,
      /\.cgi$/i,
      /\.pl$/i,
      /\.py$/i
    ];
    
    const shouldSkip = skipPatterns.some(pattern => pattern.test(path));
    
    // Check if path starts with /docs/
    const isDocsPath = /^\/docs\//.test(path);
    
    if (isDocsPath && !shouldSkip) {
      // Rewrite host to docs.example.com
      return newProtocol + 'docs.example.com' + path;
    }
    
    // Just upgrade the scheme
    return newProtocol + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
