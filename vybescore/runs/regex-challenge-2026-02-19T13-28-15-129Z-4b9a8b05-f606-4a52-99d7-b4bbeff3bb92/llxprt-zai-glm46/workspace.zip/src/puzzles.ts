/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const specialChars = /[.*+?^${}()|[\]\\]/g;
  const escapedPrefix = prefix.replace(specialChars, '\\$&');
  
  // Find all words starting with prefix
  const wordPattern = new RegExp('\\b' + escapedPrefix + '\\w+', 'gi');
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  const uniqueWords = new Set(matches.map(m => m.toLowerCase()));
  
  return Array.from(uniqueWords).filter(word => !exceptionSet.has(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const specialChars = /[.*+?^${}()|[\]\\]/g;
  const escapedToken = token.replace(specialChars, '\\$&');
  
  // Match the digit + token pattern, but only return the full match
  // The token must be after a digit
  const pattern = new RegExp('\\d' + escapedToken, 'g');
  
  const matches = text.match(pattern) || [];
  return [...matches];
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  // This catches patterns like XYXY where X and Y are characters
  for (let i = 0; i < value.length - 3; i++) {
    const sequence = value.substring(i, i + 4);
    // Check for ABAB pattern (case-insensitive)
    if (sequence[0].toLowerCase() === sequence[2].toLowerCase() && 
        sequence[1].toLowerCase() === sequence[3].toLowerCase()) {
      return false;
    }
  }
  
  // Also check for longer repeated patterns like ABCABC (case-insensitive)
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const first = value.substring(i, i + len);
      const second = value.substring(i + len, i + len * 2);
      if (first.toLowerCase() === second.toLowerCase()) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern:
  // - 8 groups of 1-4 hex digits separated by colons
  // - Can use :: to replace one or more consecutive groups of zeros
  // - Can have IPv4 address at the end (e.g., ::ffff:192.168.1.1)
  
  // Extract potential IPv6 addresses from the text
  const ipv6Pattern = /[0-9a-fA-F:]+:+[0-9a-fA-F:]*/g;
  const matches = value.match(ipv6Pattern);
  
  if (!matches) {
    return false;
  }
  
  // Check each match
  for (const match of matches) {
    const candidate = match.trim();
    
    // First, let's exclude pure IPv4 addresses
    const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (ipv4Pattern.test(candidate)) {
      continue;
    }
    
    // IPv6 patterns
    // Full form: 8 groups of 1-4 hex digits
    const ipv6Full = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
    
    // Compressed with ::
    const ipv6Compressed = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/;
    
    // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
    const ipv6WithIPv4 = /^(?:[0-9a-fA-F]{1,4}:)*:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    
    // Check if any IPv6 pattern matches
    if (ipv6Full.test(candidate) ||
        ipv6Compressed.test(candidate) ||
        ipv6WithIPv4.test(candidate)) {
      return true;
    }
  }
  
  return false;
}
