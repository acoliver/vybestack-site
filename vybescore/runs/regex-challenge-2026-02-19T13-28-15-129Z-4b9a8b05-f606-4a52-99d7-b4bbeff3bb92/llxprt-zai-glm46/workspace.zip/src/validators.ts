export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Trim whitespace
  const email = value.trim();
  
  // Check for invalid patterns first
  // No consecutive dots
  if (email.includes('..')) {
    return false;
  }
  
  // Basic structure: local@domain
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(email)) {
    return false;
  }
  
  // No trailing dot in local part
  const [localPart, domain] = email.split('@');
  if (localPart.endsWith('.') || localPart.startsWith('.')) {
    return false;
  }
  
  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain cannot start or end with hyphen or dot
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1')) {
    if (phoneNumber.length < 11) {
      return false;
    }
    phoneNumber = phoneNumber.substring(1);
  }
  
  // After removing country code, should be exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) - cannot start with 0 or 1
  const exchangeCode = phoneNumber.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate format matches allowed patterns
  // Patterns: (212) 555-7890, 212-555-7890, 2125557890, 212 555 7890
  const formattedPatterns = [
    /^\(\d{3}\)\s*\d{3}[-.\s]?\d{4}$/, // (212) 555-7890
    /^\d{3}[-.\s]\d{3}[-.\s]\d{4}$/,    // 212-555-7890
    /^\d{10}$/,                          // 2125557890
    /^\+?1?\s*\(\d{3}\)\s*\d{3}[-.\s]?\d{4}$/, // +1 (212) 555-7890
    /^\+?1?\s*\d{3}[-.\s]\d{3}[-.\s]\d{4}$/,  // +1 212-555-7890
    /^\+?1?\s*\d{10}$/                  // +1 2125557890
  ];
  
  const normalizedValue = value.trim();
  
  // Allow extensions if option is enabled
  if (options?.allowExtensions) {
    formattedPatterns.push(/^\+?1?\s*\d{3}[-.\s]\d{3}[-.\s]\d{4}\s*x\d+$/i);
  }
  
  return formattedPatterns.some(pattern => pattern.test(normalizedValue));
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber: 6-8 digits total
 * - When country code omitted, must begin with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern with country code +54
  if (cleaned.startsWith('+54') || cleaned.startsWith('54')) {
    // Remove country code for further processing
    const withoutCountry = cleaned.replace(/^\+?54/, '');
    
    // Check for optional mobile indicator 9
    let areaCodeAndSubscriber = withoutCountry;
    if (areaCodeAndSubscriber.startsWith('9')) {
      areaCodeAndSubscriber = areaCodeAndSubscriber.substring(1);
    }
    
    // When country code is present, trunk prefix should NOT be used
    // So we check if area code starts with 0 (which would be invalid)
    
    // Now we should have area code + subscriber
    // Area code: 2-4 digits, subscriber: 6-8 digits
    const phonePattern = /^(\d{2,4})(\d{6,8})$/;
    const match = areaCodeAndSubscriber.match(phonePattern);
    
    if (!match) {
      return false;
    }
    
    const [, areaCode, subscriber] = match;
    
    // Area code leading digit must be 1-9 (not 0)
    if (areaCode[0] === '0') {
      return false;
    }
    
    // Subscriber: 6-8 digits
    if (subscriber.length < 6 || subscriber.length > 8) {
      return false;
    }
    
    return true;
  }
  
  // Without country code - must have trunk prefix 0
  if (!cleaned.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix
  let withoutTrunk = cleaned.substring(1);
  
  // Check for optional mobile indicator 9
  if (withoutTrunk.startsWith('9')) {
    withoutTrunk = withoutTrunk.substring(1);
  }
  
  // Now we should have area code + subscriber
  const phonePattern = /^(\d{2,4})(\d{6,8})$/;
  const match = withoutTrunk.match(phonePattern);
  
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriber] = match;
  
  // Area code leading digit must be 1-9 (not 0)
  if (areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber: 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Name must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and special symbols (except apostrophe and hyphen)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names with only symbols/spaces
  const trimmed = value.trim();
  if (trimmed.length === 0) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be numeric only
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length based on card type
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  const isValidLength = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!isValidLength) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
