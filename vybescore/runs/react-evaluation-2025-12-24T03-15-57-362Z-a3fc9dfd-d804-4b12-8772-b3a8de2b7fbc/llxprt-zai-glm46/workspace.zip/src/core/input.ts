/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = (typeof _equal === 'function') ? _equal : undefined
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
      // Also add the observer's dependents to track transitive dependencies
      if (observer.dependents) {
        for (const dep of observer.dependents) {
          s.observers.add(dep)
        }
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    s.value = nextValue
    // Notify all observers
    for (const observer of s.observers) {
      updateObserver(observer as Observer<unknown>)
    }
    return s.value
  }

  return [read, write]
}
