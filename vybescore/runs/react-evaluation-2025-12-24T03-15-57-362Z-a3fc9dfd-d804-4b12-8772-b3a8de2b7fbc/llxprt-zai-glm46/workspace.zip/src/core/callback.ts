/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, ObserverR, UpdateFn, updateObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependents: new Set<ObserverR>(),
  }
  
  // Execute the callback once to establish dependencies
  // The active observer should be set so that any reactive values
  // accessed during execution can register this observer
  const prevObserver = setActiveObserver(observer)
  try {
    updateObserver(observer)
  } finally {
    // Important: DON'T restore the previous observer yet
    // We want to remain as the active observer so that when 
    // the callback accesses reactive values (like computed), 
    // those values register THIS callback as their observer
    // But we DO need to restore after the initial setup
    setActiveObserver(prevObserver)
  }
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    observer.dependents?.clear()
  }
  
  return unsubscribe
}
