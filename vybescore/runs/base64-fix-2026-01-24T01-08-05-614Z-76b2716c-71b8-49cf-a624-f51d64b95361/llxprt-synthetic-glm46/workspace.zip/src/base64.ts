const BASE64_ALPHABET = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_LENGTH_ERROR = 'Invalid Base64 input length';
const INVALID_CHARS_ERROR = 'Invalid Base64 input: contains non-Base64 characters';

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode standard Base64 text back to plain UTF-8.
 * Validates that input contains only valid Base64 characters.
 * Accepts both padded and unpadded Base64 input.
 * Throws an error for invalid input.
 */
export function decode(input: string): string {
  // Check for valid Base64 characters (including padding)
  if (!BASE64_ALPHABET.test(input)) {
    throw new Error(INVALID_CHARS_ERROR);
  }
  
  try {
    // Buffer.from handles both padded and unpadded Base64 correctly
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Additional validation: ensure the result is decodable
    // If the input contains invalid Base64, Buffer.from will produce garbled output
    // We verify by re-encoding the result
    const reencoded = Buffer.from(result, 'utf8').toString('base64').replace(/=+$/, '');
    const normalizedInput = input.replace(/=+$/, '');
    
    // If re-encoding doesn't match the original (sans padding), reject
    if (reencoded !== normalizedInput) {
      throw new Error(INVALID_CHARS_ERROR);
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
