export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with strict rules.
 * Accepts: user@example.com, name+tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  if (!value || value.length > 254) return false;
  
  // Main email pattern
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?!.*\.\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  // Check for underscores in domain
  const hasUnderscoreInDomain = /@.*_/;
  
  // Check for consecutive dots
  const hasDoubleDots = /\.\./;
  
  // Check for trailing dot in local or domain part
  const hasTrailingDot = /\.$/;
  
  // Check for double dots in local part
  const localPart = value.split('@')[0];
  const hasDoubleDotsInLocal = localPart?.includes('..');
  
  if (!emailRegex.test(value)) return false;
  if (hasUnderscoreInDomain.test(value)) return false;
  if (hasDoubleDots.test(value)) return false;
  if (hasTrailingDot.test(value)) return false;
  if (hasDoubleDotsInLocal) return false;
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: impossible area codes (leading 0/1), too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  if (!value) return false;
  
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check minimum length (10 digits without country code)
  const digitsOnly = cleaned.replace(/\+/g, '');
  if (digitsOnly.length < 10) return false;
  
  // Extract country code and main number
  let mainNumber = digitsOnly;
  if (digitsOnly.startsWith('1') && digitsOnly.length === 11) {
    mainNumber = digitsOnly.substring(1);
  } else if (digitsOnly.length === 10) {
    mainNumber = digitsOnly;
  } else if (digitsOnly.length > 11) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = mainNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Full pattern match
  const pattern = /^\+?1?[-\s]?\(?\d{3}\)?[-\s]?\d{3}[-\s]?\d{4}$/;
  return pattern.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // ^\+54 - Optional country code
  // (9)? - Optional mobile indicator
  // \d{2,4} - Area code (2-4 digits, leading 1-9)
  // \d{6,8} - Subscriber number (6-8 digits)
  const argentinaPhoneRegex = /^(?:\+54)?(?:9)?\d{2,4}\d{6,8}$/;
  
  if (!argentinaPhoneRegex.test(cleaned)) return false;
  
  // Extract components
  const hasCountryCode = cleaned.startsWith('+54');
  let numberWithoutCountry = hasCountryCode ? cleaned.substring(3) : cleaned;
  
  // Check for mobile indicator
  const hasMobile = numberWithoutCountry.startsWith('9');
  if (hasMobile) {
    numberWithoutCountry = numberWithoutCountry.substring(1);
  }
  
  // Check for trunk prefix when no country code
  if (!hasCountryCode) {
    if (!numberWithoutCountry.startsWith('0')) return false;
    numberWithoutCountry = numberWithoutCountry.substring(1);
  }
  
  // Extract area code (first 2-4 digits, leading 1-9)
  const areaCodeMatch = numberWithoutCountry.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[1];
  const subscriberNumber = numberWithoutCountry.substring(areaCode.length);
  
  // Validate area code length (2-4 digits, already ensured by regex)
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects: digits, symbols, X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and invalid name patterns
  const nameRegex = /^[\p{L}'-]+(?:\s[\p{L}'-]+)*$/u;
  
  // Check for digits
  if (/\d/.test(value)) return false;
  
  // Check for invalid symbols (anything not in allowed set)
  const invalidSymbols = /[!"#$%&()*+,./:;<=>?@[\\]^_`{|}0-9]/;
  if (invalidSymbols.test(value)) return false;
  
  // Check for X Æ A-12 style names (contains digits or weird symbols)
  // The Æ is actually valid unicode, but A-12 pattern is not
  if (/\w*\d+\w*/.test(value)) return false;
  
  return nameRegex.test(value);
}

/**
 * Helper: Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts: Visa, Mastercard, AmEx
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Visa: 13-16 digits, starts with 4
  const visaPattern = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexPattern = /^3[47]\d{13}$/;
  
  const isValidFormat = visaPattern.test(cleaned) || 
                        mastercardPattern.test(cleaned) || 
                        amexPattern.test(cleaned);
  
  if (!isValidFormat) return false;
  
  return runLuhnCheck(cleaned);
}
