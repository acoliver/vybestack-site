/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * - Capitalize after .?!
 * - Insert exactly one space between sentences
 * - Collapse extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // First, normalize spacing around sentence boundaries
  // Replace multiple spaces with single space
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure space after sentence-ending punctuation if not already there
  result = result.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Capitalize first character of string
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Capitalize after sentence endings, but handle abbreviations
  // Common abbreviations to watch for
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'i.e', 'e.g', 'St', 'Ave', 'Blvd', 'Rd'];
  const abbrPattern = new RegExp(String.raw`\b(${abbreviations.join('|')})\.$`, 'i');
  
  // Split into sentences for careful processing
  const sentences = result.split(/(?<=[.!?])\s+/);
  
  const processed = sentences.map((sentence, index) => {
    if (index === 0) return sentence; // Already capitalized
    
    // Check if previous sentence ended with an abbreviation
    if (sentences[index - 1] && abbrPattern.test(sentences[index - 1])) {
      return sentence; // Don't capitalize after abbreviation
    }
    
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  return processed.join(' ');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 * Removes trailing punctuation (.,;!?) but preserves URLs with those characters internally.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL pattern - captures http/https/ftp schemes, www, and common TLDs
  // Negative lookbehind to avoid capturing trailing punctuation
  const urlPattern = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"{}|^`[\]]+[^\s.,;!?()<>"{}|^`[\]]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[.,;!?()]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace http:// with https:// globally
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  // Pattern to match example.com URLs
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check for dynamic hints that should prevent host rewrite
    const dynamicHints = /(?:\/cgi-bin\/|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i;
    
    // Check if path starts with /docs/ and has no dynamic hints
    if (path.startsWith('/docs/') && !dynamicHints.test(path)) {
      return newScheme + 'docs.example.com' + path;
    }
    
    // Just upgrade scheme
    return newScheme + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format exactly
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Validate month (01-12)
  const monthNum = parseInt(month, 10);
  if (monthNum < 1 || monthNum > 12) return 'N/A';
  
  // Validate day based on month
  const dayNum = parseInt(day, 10);
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (dayNum < 1 || dayNum > daysInMonth[monthNum - 1]) return 'N/A';
  
  return year;
}
