/**
 * Finds words beginning with the specified prefix, excluding the provided exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (typeof text !== 'string' || typeof prefix !== 'string' || !Array.isArray(exceptions)) {
    return [];
  }

  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to match words starting with the prefix
  // \b ensures we match whole words only
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out exceptions and remove duplicates
  const filteredMatches = matches
    .map(word => word)
    .filter(word => !lowerExceptions.includes(word.toLowerCase()))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
  
  return filteredMatches;
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a different approach since lookbehind might not be supported everywhere
  // Find the token preceded by a digit using a capturing group
  const tokenRegex = new RegExp(`(\\d)${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Return the digit + token combination
    matches.push(match[0]);
  }
  
  // Remove duplicates while preserving order
  const uniqueMatches = Array.from(new Set(matches));
  
  return uniqueMatches;
}

/**
 * Validates password strength: at least 10 characters, one uppercase, one lowercase, 
 * one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  // Minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Must contain at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (like abab, abcabc)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const pattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (pattern.test(value)) {
      return false;
    }
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  // IPv6 regex pattern that supports full and shorthand notation
  // Supports: ::, ::1, 2001:db8::1, 2001:0db8:85a3:0000:0000:8a2e:0370:7334, etc.
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|(?:[0-9a-fA-F]{1,4}){1,7}:|(?:(?:[0-9a-fA-F]{1,4}:){1,4}|[0-9a-fA-F]{1,4}:)(?:\d{1,3}\.){3}\d{1,3}/g;
  
  // Find all potential IPv6 matches
  const ipv6Matches = value.match(ipv6Regex);
  
  if (!ipv6Matches) {
    return false;
  }
  
  // Verify that at least one match is actually IPv6 (not IPv4 embedded in IPv6 format)
  for (const match of ipv6Matches) {
    // If the match contains dots, it might be IPv4 embedded in IPv6
    // We'll still consider this valid IPv6 since it's IPv6 format
    // The regex patterns above already exclude pure IPv4 addresses
    if (match.includes(':')) {
      return true;
    }
  }
  
  return false;
}