export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses supporting common formats with + tags,
 * rejecting double dots, trailing dots, and underscores in domains.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check
  if (typeof value !== 'string' || value.length === 0) {
    return false;
  }

  // Email regex: local@domain
  // Local part: letters, digits, +, ., -, _, but no consecutive dots or leading/trailing dots
  // Domain part: letters, digits, hyphens, dots, but no underscores, no consecutive dots, no leading/trailing dots
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Reject underscores in domain
  if (value.includes('_')) {
    const atIndex = value.lastIndexOf('@');
    if (atIndex > 0 && value.slice(atIndex).includes('_')) {
      return false;
    }
  }

  // Reject consecutive dots
  if (value.includes('..')) {
    return false;
  }

  // Reject dots at the beginning or end of local part or domain
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const [local, domain] = parts;
  if (local.startsWith('.') || local.endsWith('.') || domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }

  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting formats like (212) 555-7890, 212-555-7890, 2125557890,
 * with optional +1 prefix. Disallows impossible area codes (leading 0/1).
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (typeof value !== 'string' || value.length === 0) {
    return false;
  }

  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Must have 10 digits (standard US number) or 11 digits (with +1 country code)
  if (digits.length !== 10 && digits.length !== 11) {
    return false;
  }

  // If 11 digits, must start with 1 (US country code)
  if (digits.length === 11 && !digits.startsWith('1')) {
    return false;
  }

  // Extract the area code (first 3 digits of the 10-digit number)
  const areaCode = digits.length === 10 ? digits.slice(0, 3) : digits.slice(1, 4);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }

  // Check if the format matches common US phone patterns
  // Supports: (212) 555-7890, 212-555-7890, 2125557890, +1 212-555-7890, etc.
  const phoneRegex = /^(?:\+?1[\s-]?)?(?:\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers supporting landlines and mobiles.
 * Formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0) {
    return false;
  }

  // Remove all separators (spaces, hyphens) for validation
  const clean = value.replace(/[\s-]/g, '');
  
  // Regex pattern for Argentine phone numbers
  // Optional +54, optional 0 trunk prefix, optional 9 mobile indicator, area code (2-4 digits), subscriber (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  const match = clean.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }

  const [, areaCodeWithTrunk, subscriber] = match;
  
  // Extract area code (without trunk prefix)
  let areaCode = areaCodeWithTrunk;
  if (areaCodeWithTrunk.startsWith('0')) {
    areaCode = areaCodeWithTrunk.slice(1);
  }
  
  // Area code must be 2-4 digits and start with 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || !/^[1-9]/.test(areaCode)) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  // When country code is omitted, must start with trunk prefix 0
  if (!clean.startsWith('+54') && !clean.startsWith('0')) {
    return false;
  }

  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (typeof value !== 'string' || value.trim().length === 0) {
    return false;
  }

  // Remove leading/trailing whitespace for validation
  const trimmed = value.trim();
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Reject digits, symbols, and standalone punctuation
  const nameRegex = /^[\p{L}\p{M}'\-]+(?:[\s][\p{L}\p{M}'\-]+)*$/u;
  
  // Additional validation to reject names with too many special characters
  const specialCharCount = (trimmed.match(/['\-]/g) || []).length;
  const letterCount = (trimmed.match(/[\p{L}\p{M}]/gu) || []).length;
  
  // Reject names that are mostly special characters
  if (specialCharCount > letterCount / 2) {
    return false;
  }
  
  // Reject names that contain digits or other symbols
  if (/[0-9@\#$%^&*()_+=\[\]{}|\:";<>,.?/~`]/.test(trimmed)) {
    return false;
  }
  
  return nameRegex.test(trimmed);
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Checks length, prefix patterns, and performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (typeof value !== 'string' || value.trim().length === 0) {
    return false;
  }

  // Remove spaces and dashes
  const clean = value.replace(/[\s-]/g, '');
  
  // Must contain only digits
  if (!/^\d+$/.test(clean)) {
    return false;
  }

  // Check length and prefix for different card types
  const isValidLengthAndPrefix = 
    // Visa: 13 or 16 digits, starts with 4
    ((clean.length === 13 || clean.length === 16) && clean.startsWith('4')) ||
    // Mastercard: 16 digits, starts with 51-55 or 2221-2720
    (clean.length === 16 && (
      (clean.startsWith('5') && parseInt(clean.substring(1, 2)) >= 1 && parseInt(clean.substring(1, 2)) <= 5) ||
      (clean.startsWith('2') && parseInt(clean.substring(1, 4)) >= 221 && parseInt(clean.substring(1, 4)) <= 272)
    )) ||
    // American Express: 15 digits, starts with 34 or 37
    (clean.length === 15 && (clean.startsWith('34') || clean.startsWith('37')));

  if (!isValidLengthAndPrefix) {
    return false;
  }

  // Perform Luhn checksum validation
  return runLuhnCheck(clean);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;

  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled -= 9;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }

  return sum % 10 === 0;
}
