/**
 * Capitalizes the first character of each sentence after .?! punctuation.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }

  // Handle empty string
  if (text.trim().length === 0) {
    return text;
  }
  
  // Replace multiple spaces with single spaces first
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure proper spacing after sentence endings
  result = result.replace(/([.!?])(?!\s|$)/g, '$1 ');
  
  // Split into sentences
  const sentences = result.split(/([.!?]\s*)/);
  
  // Capitalize first letter of each sentence
  let capitalizeNext = true;
  const processedSentences = sentences.map((part, index) => {
    // Even indices are text, odd indices are punctuation
    if (index % 2 === 0) {
      // This is text
      if (capitalizeNext && part.length > 0) {
        capitalizeNext = false;
        return part.charAt(0).toUpperCase() + part.slice(1);
      }
      return part;
    } else {
      // This is punctuation, next part should be capitalized
      capitalizeNext = true;
      return part;
    }
  });
  
  return processedSentences.join('').replace(/\s+/g, ' ').trim();
}

/**
 * Extracts URLs from the given text, excluding trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (typeof text !== 'string' || text.trim().length === 0) {
    return [];
  }

  // URL regex pattern that matches http/https, www, and domain names
  // Includes support for subdomains, paths, query parameters, and fragments
  const urlRegex = /(https?:\/\/|www\.)[^\s<>"{}|\^`\[\]]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation marks that are not part of the URL
    return url.replace(/[.,;:!?'")\]}>]+$/g, '').trim();
  });
}

/**
 * Replaces http:// URLs with https:// while leaving existing https:// URLs unchanged.
 */
export function enforceHttps(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }

  // Replace http:// with https://, but don't touch existing https:// URLs
  // Use word boundary to ensure we don't match within other text
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs to use HTTPS and moves docs paths to docs.example.com.
 * Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }

  // Pattern to match URLs with http://example.com format
  const urlPattern = /\bhttp:\/\/([^\/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, host, path = '') => {
    // Always upgrade to HTTPS
    let newUrl = `https://${host}${path}`;
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const dynamicPatterns = [
        /\/cgi-bin\//i,
        /[?&=]/,           // Query parameters
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/i  // Legacy extensions
      ];
      
      const shouldSkipHostRewrite = dynamicPatterns.some(pattern => pattern.test(path));
      
      if (!shouldSkipHostRewrite) {
        // Rewrite host to docs.example.com
        newUrl = `https://docs.${host}${path}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (typeof value !== 'string') {
    return 'N/A';
  }

  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  let maxDays = daysInMonth[month - 1];
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    // Leap year: divisible by 4 and not by 100, or divisible by 400
    if ((yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0) {
      maxDays = 29;
    }
  }
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  return year;
}
