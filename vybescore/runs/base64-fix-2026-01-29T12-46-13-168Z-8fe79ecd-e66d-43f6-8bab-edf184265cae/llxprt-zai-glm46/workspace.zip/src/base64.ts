/**
 * Validate Base64 input string.
 * Checks for valid Base64 characters and proper structure.
 */
function validateBase64(input: string): void {
  // Base64 should only contain A-Z, a-z, 0-9, +, /, and padding =
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for proper padding placement
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding characters must only appear at the end
    const afterPadding = input.slice(paddingIndex);
    if (!/^=+$/.test(afterPadding)) {
      throw new Error('Invalid Base64 input: padding not at end');
    }
    
    // Maximum 2 padding characters
    if (afterPadding.length > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
  }
}

/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 with or without padding.
 * Throws error for invalid input.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  // Validate input before attempting decode
  validateBase64(trimmed);

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding resulted in empty buffer for non-empty input
    if (trimmed.length > 0 && buffer.length === 0) {
      throw new Error('Invalid Base64 input: decoding produced empty result');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
