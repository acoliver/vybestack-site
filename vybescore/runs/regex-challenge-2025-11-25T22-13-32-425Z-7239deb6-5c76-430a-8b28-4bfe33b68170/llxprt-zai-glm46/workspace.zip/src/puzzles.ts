/**
 * Finds words beginning with the specified prefix but excludes the listed exceptions.
 * Returns an array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Create regex to match words starting with the prefix
  // \b ensures we match whole words
  // \w* matches the rest of the word
  const regex = new RegExp(`\\b${prefix}\\w*`, 'gi');
  const matches = text.match(regex) || [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out exceptions and remove duplicates
  const uniqueMatches = [...new Set(matches.map(match => match.toLowerCase()))];
  
  return uniqueMatches.filter(word => 
    !lowerExceptions.includes(word) && 
    word.toLowerCase().startsWith(prefix.toLowerCase())
  );
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds as specified.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex that matches the token when preceded by a digit but not at string start
  // Use a simpler approach: find digit+token pattern that's not at the beginning
  const regex = new RegExp(`(?<!^\\d*)\\d${escapedToken}`, 'g');
  
  const matches = text.match(regex);
  
  return matches || [];
}

/**
 * Validates password strength according to specified policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter  
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // Minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123", "xyxy")
  // This regex looks for patterns of 2 or more characters that repeat immediately
  const repeatedPattern = /(..+?)\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 * Returns true if an IPv6 address is found, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // IPv6 regex pattern that matches various IPv6 formats including shorthand
  // This pattern matches:
  // - Standard IPv6 with 8 groups of 1-4 hex digits
  // - Compressed IPv6 with :: shorthand
  // - IPv6 with embedded IPv4 addresses
  // - Leading zeros can be omitted
  const ipv6Regex = /(?:^|(?<=\s))(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(?:ffff(?::0{1,4}){0,1}:){0,1}(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=\s|$)/;
  
  // First check if there's an IPv6 pattern
  if (!ipv6Regex.test(value)) {
    return false;
  }
  
  // IPv4 regex to check if this might be IPv4 instead
  const ipv4Regex = /(?:^|(?<=\s))(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?=\s|$)/;
  
  // Get all potential IPv6 matches
  const ipv6Matches = value.match(ipv6Regex) || [];
  
  // Check if any of the matches are not IPv4
  for (const match of ipv6Matches) {
    // If this match contains colons and is not a valid IPv4, it's likely IPv6
    if (match.includes(':') && !ipv4Regex.test(match)) {
      return true;
    }
  }
  
  return false;
}
