/**
 * Capitalizes the first character of each sentence after sentence terminators (.?!).
 * Inserts exactly one space between sentences if input omitted it.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // First, normalize spaces around sentence terminators
  // Ensure exactly one space after sentence terminators unless followed by a lowercase letter (suggesting abbreviation)
  let normalized = text.replace(/([.?!])(?=[a-zA-Z])(?![a-z])/g, '$1 ');
  
  // Collapse multiple spaces into single spaces
  normalized = normalized.replace(/\s+/g, ' ');
  
  // Trim leading and trailing spaces
  normalized = normalized.trim();
  
  // Split into sentences and capitalize the first letter of each
  // This regex handles sentence boundaries while being more careful about abbreviations
  const sentences = normalized.split(/([.?!]\s*)/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part.match(/^[.?!]\s*$/)) {
      // This is just punctuation followed by optional space
      result += part;
      capitalizeNext = true;
    } else if (capitalizeNext && part.length > 0) {
      // Capitalize first letter, keep the rest as is
      result += part.charAt(0).toUpperCase() + part.slice(1);
      capitalizeNext = false;
    } else {
      result += part;
    }
  }
  
  return result;
}

/**
 * Finds URLs in the text and returns them as an array.
 * Excludes trailing punctuation like periods, commas, etc.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  // URL regex pattern that matches common URL formats
  // This pattern matches:
  // - http:// or https:// protocols (optional)
  // - www. prefix (optional) 
  // - domain names with subdomains
  // - optional port numbers
  // - optional paths, query strings, and fragments
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s/$.?#].[^\s]*\b/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?'"()[\]{}]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * Forces all HTTP URLs to use HTTPS while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Replace http:// with https://, but be careful not to match https://
  return text.replace(/http:\/\/(?!(https:\/\/))/gi, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * - Always upgrade http:// to https://
 * - For http://example.com/..., upgrade to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for URLs with cgi-bin, query strings, or legacy extensions
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  return text.replace(/(https?:\/\/)([^\/\s]+)(\/[^\s]*)?/gi, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // Check if we should skip host rewrite
    const skipHostRewrite = /(?:cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py|[?&=])/i.test(path);
    
    // Check if path starts with /docs/ and we don't skip host rewrite
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      // Extract domain from host (remove subdomains if present)
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        const domain = domainParts.slice(-2).join('.'); // Get main domain
        return secureProtocol + 'docs.' + domain + path;
      }
    }
    
    // Default: just upgrade the protocol
    return secureProtocol + host + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format doesn't match or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month (including leap year for February)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  if (isLeapYear) {
    daysInMonth[1] = 29; // February has 29 days in leap year
  }
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return yearStr;
}
