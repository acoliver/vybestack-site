export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with strict rules.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Local part should not start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain should not contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain should not start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove common separators and spaces
  const cleaned = value.replace(/[().\s-]/g, '');
  
  // Check if it starts with +1 (country code)
  const withoutCountryCode = cleaned.startsWith('+1') ? cleaned.slice(2) : cleaned;
  
  // Should be exactly 10 digits for US numbers
  if (!/^\d{10}$/.test(withoutCountryCode)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = withoutCountryCode.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = withoutCountryCode.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Note: options parameter is not used in current implementation
  // but is kept for API compatibility as specified in requirements
  return true;
}

/**
 * Validates Argentine phone numbers supporting landlines and mobiles.
 * Accepts formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits after area code
 * - When country code omitted, must start with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // ^\+54? - Optional +54 country code
  // 0? - Optional trunk prefix 0
  // 9? - Optional mobile indicator 9
  // [2-9]\d{1,3} - Area code: 2-4 digits, leading digit 1-9 (but adjusted to exclude 1 for 2-4 digits)
  // \d{6,8}$ - Subscriber number: 6-8 digits
  
  const argentinePhoneRegex = /^\+54?(?:0|9)?[2-9]\d{1,3}\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Extract components for validation
  let remaining = cleaned;
  
  // Remove country code if present
  if (remaining.startsWith('+54')) {
    remaining = remaining.slice(3);
  }
  
  // When country code is omitted, must start with trunk prefix 0
  if (!cleaned.startsWith('+54') && !remaining.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix if present
  if (remaining.startsWith('0')) {
    remaining = remaining.slice(1);
  }
  
  // Remove mobile indicator if present
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Now remaining should be area code + subscriber number
  // Area code is 2-4 digits, leading digit should not be 0 or 1
  if (remaining.length < 8 || remaining.length > 12) { // min 2+6, max 4+8
    return false;
  }
  
  // Extract area code (first 2-4 digits where first digit is 2-9)
  const areaCodeMatch = remaining.match(/^([2-9]\d{1,3})(\d+)$/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const [, areaCode, subscriberNumber] = areaCodeMatch;
  
  // Area code: 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Should not be empty or just whitespace
  if (!value || !value.trim()) {
    return false;
  }
  
  // Reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Name validation regex:
  // ^\s* - Allow leading spaces
  // [\p{L}.'’-]+ - Unicode letters, dots, apostrophes (both types), and hyphens
  // (?:\s+[\p{L}.'’-]+)* - Subsequent words separated by spaces
  // \s*$ - Allow trailing spaces
  const nameRegex = /^\s*[\p{L}.'’-]+(?:\s+[\p{L}.'’-]+)*\s*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject problematic patterns like "X Æ A-12" style names
  // This checks for sequences with mixed special characters that look like artificial names
  const problematicPattern = /[^\p{L}\s.'’-]/u;
  if (problematicPattern.test(value)) {
    return false;
  }
  
  // Should have at least one actual letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  if (digits.length === 0) {
    return false;
  }
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx.
 * Accepts correct prefixes and lengths, and performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces, hyphens, and other common separators
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(?:\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any supported card format
  const isValidFormat = visaRegex.test(cleaned) || 
                        mastercardRegex.test(cleaned) || 
                        amexRegex.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleaned);
}
