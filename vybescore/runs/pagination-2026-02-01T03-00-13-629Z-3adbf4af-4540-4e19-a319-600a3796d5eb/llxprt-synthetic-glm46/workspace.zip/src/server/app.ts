import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validation function for pagination parameters
    const validatePaginationParam = (param: string | undefined, paramName: string): number | null => {
      if (!param) return null;
      
      // Check if param is numeric
      if (!/^\d+$/.test(param)) {
        res.status(400).json({ error: `${paramName} must be a positive integer` });
        return null;
      }
      
      const num = Number(param);
      
      // Check if param is zero or negative
      if (num <= 0) {
        res.status(400).json({ error: `${paramName} must be greater than 0` });
        return null;
      }
      
      // Check for excessive values
      if (num > 100) {
        res.status(400).json({ error: `${paramName} must be less than or equal to 100` });
        return null;
      }
      
      return num;
    };

    const page = validatePaginationParam(pageParam, 'page');
    const limit = validatePaginationParam(limitParam, 'limit');
    
    // If validation failed, response already sent
    if (page === null && limit === null && !pageParam && !limitParam) {
      // No parameters provided, use defaults
    } else if ((pageParam && page === null) || (limitParam && limit === null)) {
      // Validation error already sent
      return;
    }

    // Convert null to undefined for listInventory
    const payload = listInventory(db, { 
      page: page ?? undefined, 
      limit: limit ?? undefined 
    });
    res.json(payload);
  });

  return app;
}
