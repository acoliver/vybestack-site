/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // First, handle special cases - multiple spaces between sentences
  // Replace multiple spaces with single spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Add a space after sentence-ending punctuation if missing
  result = result.replace(/([.?!])(?=[A-Za-z])/g, '$1 ');
  
  // Remove extra spaces after sentence punctuation
  result = result.replace(/([.?!])\s+/g, '$1 ');
  
  // Now capitalize the first character of each sentence
  // Split on sentence boundaries (.?!)
  const sentences = result.split(/([.?!]\s*)/);
  
  // Process every other element (sentences) in the array
  for (let i = 0; i < sentences.length; i += 2) {
    if (sentences[i]) {
      const sentence = sentences[i].trim();
      if (sentence.length > 0) {
        // Capitalize the first letter
        sentences[i] = sentence.charAt(0).toUpperCase() + sentence.slice(1);
      }
    }
  }
  
  // Join back together
  result = sentences.join('');
  
  // Clean up any extra spaces
  result = result.trim().replace(/\s+/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Match URL patterns (http/https, www, domain names)
  const urlPattern = /(https?:\/\/(www\.)?|www\.)[^\s\]\)\}]+/gi;
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs (.,!?;:])
  return matches.map(url => url.replace(/[.,!?;:)\]\}]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace http:// with https:// but leave https:// unchanged
  const httpsText = text.replace(/http:\/\//g, 'https://');
  return httpsText;
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  // Upgrade all http URLs to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Regex to match URLs with docs path, excluding dynamic content
  // This matches patterns like https://example.com/docs/... but excludes those with
  // dynamic hints (cgi-bin, query strings, or legacy extensions)
  const docsUrlPattern = /(https?:\/\/example\.com\/docs\/[^\s\?\&\s]*(?!\.(jsp|php|asp|aspx|do|cgi|pl|py)\b))/g;
  
  // Replace docs.example.com URLs
  result = result.replace(docsUrlPattern, (match) => {
    return match.replace('https://example.com/', 'https://docs.example.com/');
  });
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const year = match[3];
  return year;
}
