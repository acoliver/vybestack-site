export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation supporting typical addresses including + tags
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check for invalid patterns
  const hasInvalidPatterns = /\.\.|^\.|\.$|_/;
  
  return emailRegex.test(value) && !hasInvalidPatterns.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Minimum valid length for US phone number is 10 digits
  if (digits.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let phoneNumber = digits;
  if (digits.length > 10) {
    // If more than 10 digits, must start with 1
    if (!digits.startsWith('1')) {
      return false;
    }
    // Remove the country code
    phoneNumber = digits.substring(1);
  }
  
  // Validate area code (should not start with 0 or 1)
  if (phoneNumber.length === 10 && (phoneNumber[0] === '0' || phoneNumber[0] === '1')) {
    return false;
  }
  
  // Check if the phone number matches valid formats
  const phoneRegex = /^(\+?1[\s-]?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s-]?[2-9]\d{2}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except +, -, and space to handle separators
  const cleaned = value.replace(/[^0-9+]/g, '');
  
  // Check for country code +54
  let hasCountryCode = false;
  let digits = cleaned;
  
  if (cleaned.startsWith('+54')) {
    hasCountryCode = true;
    digits = cleaned.substring(3);
  } else if (!cleaned.startsWith('0')) {
    // If no country code and doesn't start with 0 trunk prefix, it's invalid
    return false;
  }
  
  // Handle trunk prefix 0 before area code
  if (!hasCountryCode && digits.startsWith('0')) {
    digits = digits.substring(1);
  }
  
  // Extract area code and subscriber number
  // Argentine phone numbers should be: [9] + area code (2-4 digits) + subscriber number (6-8 digits)
  const mobilePrefix = digits.startsWith('9') ? 1 : 0;
  const remainingDigits = digits.substring(mobilePrefix);
  
  // Determine area code length (2-4 digits)
  let areaCodeLength = 0;
  for (let len = 2; len <= 4; len++) {
    if (remainingDigits.length >= len && remainingDigits.length - len <= 8 && remainingDigits.length - len >= 6) {
      areaCodeLength = len;
      break;
    }
  }
  
  if (areaCodeLength === 0) {
    return false;
  }
  
  const areaCode = remainingDigits.substring(0, areaCodeLength);
  const subscriberNumber = remainingDigits.substring(areaCodeLength);
  
  // Validate area code (leading digit must be 1-9)
  if (!/^[1-9]\d*$/.test(areaCode)) {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and names like "X Æ A-12" style names
  const nameRegex = /^[\p{L}'\-\p{M}]+(?:\s+[\p{L}'\-\p{M}]+)*$/u;
  
  // Check for digits or excessive special characters
  const hasDigits = /[0-9]/.test(value);
  const hasExcessiveSymbols = /[^\p{L}'\-\s\p{M}]/u.test(value);
  
  return nameRegex.test(value) && !hasDigits && !hasExcessiveSymbols;
}

/**
 * Helper function to run Luhn checksum algorithm
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit and process each digit
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check if the length is valid for credit cards (13-19 digits)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check for valid prefixes for Visa (4), Mastercard (51-55, 2221-2720), and Amex (34, 37)
  let isValidPrefix = false;
  
  // Visa
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16)) {
    isValidPrefix = true;
  }
  
  // Mastercard
  if (
    (digits.length === 16) &&
    (
      /^\d{2}$/.test(digits.substring(0, 2)) && 
      parseInt(digits.substring(0, 2)) >= 51 &&
      parseInt(digits.substring(0, 2)) <= 55
    ) || 
    (
      /^\d{4}$/.test(digits.substring(0, 4)) && 
      parseInt(digits.substring(0, 4)) >= 2221 &&
      parseInt(digits.substring(0, 4)) <= 2720
    )
  ) {
    isValidPrefix = true;
  }
  
  // American Express
  if (
    digits.length === 15 &&
    (digits.startsWith('34') || digits.startsWith('37'))
  ) {
    isValidPrefix = true;
  }
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
