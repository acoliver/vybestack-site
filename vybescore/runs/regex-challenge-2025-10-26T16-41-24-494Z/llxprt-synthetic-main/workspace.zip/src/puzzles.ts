/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in the prefix for use in regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with the prefix
  const prefixedWordsRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  // Find all matches in the text
  const matches = text.match(prefixedWordsRegex) || [];
  
  // Filter out exceptions
  const result = matches.filter(word => !exceptions.includes(word));
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in the token for use in regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match digit+token pattern
  // This ensures we capture the digit and token together as one unit
  const embeddedTokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches in the text
  const matches = text.match(embeddedTokenRegex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  const hasUppercase = /[A-Z]/.test(value);
  
  // Check for at least one lowercase letter
  const hasLowercase = /[a-z]/.test(value);
  
  // Check for at least one digit
  const hasDigit = /[0-9]/.test(value);
  
  // Check for at least one symbol
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  // Check for whitespace (should not contain whitespace)
  const hasWhitespace = /\s/.test(value);
  
  // Check for immediate repeated sequences (e.g., "abab" pattern)
  // This regex checks for a pattern where a character sequence of length 2+ is repeated immediately after itself
  const hasRepeatedSequence = /(..)\1/.test(value);
  
  return hasUppercase && hasLowercase && hasDigit && hasSymbol && !hasWhitespace && !hasRepeatedSequence;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 pattern that includes shorthand :: but excludes IPv4
  // Matches: standard IPv6, IPv6 with shorthand ::, mixed IPv6, etc.
  // Does NOT match IPv4 addresses
  const ipv6Pattern = /((?:[0-9a-fA-F]{1,4}:)+[0-9a-fA-F]{1,4})|(?:[0-9a-fA-F]{1,4}:?::[0-9a-fA-F]{0,4})|([0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4})*)/;
  
  // First exclude IPv4 patterns to avoid false positives
  const containsIPv4 = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/.test(value);
  
  if (containsIPv4) {
    return false;
  }
  
  // Check for IPv6
  return ipv6Pattern.test(value);
}