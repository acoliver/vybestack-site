import { describe, it, expect } from 'vitest'
import { createCallback } from '../../src/index.ts'

describe('createCallback', () => {
  it('returns unsubscribe function', () => {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    const unsubscribe = createCallback(() => {})
    expect(typeof unsubscribe).toBe('function')
  })

  it('unsubscribe function can be called without error', () => {
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    const unsubscribe = createCallback(() => {})
    expect(() => unsubscribe()).not.toThrow()
  })
})
