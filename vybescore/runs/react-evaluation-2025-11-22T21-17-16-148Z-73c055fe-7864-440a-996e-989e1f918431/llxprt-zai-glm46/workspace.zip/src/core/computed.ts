/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ExtendedObserver,
  getActiveObserver,
  updateObserver,
  EqualFn,
  createEqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: ExtendedObserver<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(), // Observers that depend on this computed value
  }

  // Define the getter function that tracks dependencies
  const computed: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      o.observers.add(observer)
    }
    
    // Recompute the value if no initial value was provided
    if (o.value === undefined) {
      updateObserver(o)
    }
    
    return o.value!
  }

  // Override the observer's updateFn to notify dependent observers
  const originalUpdateFn = o.updateFn
  const equalFn = createEqualFn(equal)
  
  o.updateFn = (prevValue?: T) => {
    const newValue = originalUpdateFn(prevValue)
    
    // Only notify if value actually changed (if equality function provided)
    if (equalFn && equalFn(o.value!, newValue)) {
      return o.value!
    }
    
    o.value = newValue
    
    // Notify all dependent observers
    for (const dependentObserver of o.observers) {
      updateObserver(dependentObserver as Observer<unknown>)
    }
    
    return newValue
  }

  // Compute initial value
  updateObserver(o)
  
  return computed
}