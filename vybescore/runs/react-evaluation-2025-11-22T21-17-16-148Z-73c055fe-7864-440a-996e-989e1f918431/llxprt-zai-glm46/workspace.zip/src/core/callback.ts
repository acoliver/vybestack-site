/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, ExtendedObserver, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: ExtendedObserver<T> = {
    value,
    updateFn,
    observers: new Set(),
    disposed: false,
  }
  
  // Override the updateFn to perform side effects and prevent circular notifications
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue?: T) => {
    if (observer.disposed) {
      return prevValue as T
    }
    
    return originalUpdateFn(prevValue)
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  // Return unsubscribe function
  return () => {
    if (observer.disposed) return
    observer.disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}