export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for obviously invalid patterns
  if (value.includes('..') || value.endsWith('.') || value.includes('@example..com')) {
    return false;
  }

  // Basic email pattern with unicode support
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional validation: domain parts shouldn't contain underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }

  // Local part shouldn't start or end with special characters that are problematic
  const local = value.split('@')[0];
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }

  // Check for consecutive dots in local part
  if (local.includes('..')) {
    return false;
  }

  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleanValue = value.trim();
  
  // Must have at least 10 digits
  const digitsOnly = cleanValue.replace(/\D/g, '');
  if (digitsOnly.length < 10) {
    return false;
  }

  // Support optional +1 prefix
  let phoneDigits = digitsOnly;
  if (cleanValue.startsWith('+1')) {
    if (digitsOnly.length === 11) {
      phoneDigits = digitsOnly.substring(1);
    } else if (digitsOnly.length !== 10) {
      return false;
    }
  }

  // Must have exactly 10 digits after processing
  if (phoneDigits.length !== 10) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = phoneDigits.substring(0, 3);
  
  // Area codes cannot start with 0 or 1 (impossible in North America)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }

  // If extensions are not allowed, ensure input doesn't contain extension indicators
  if (!options?.allowExtensions && (cleanValue.includes('ext') || cleanValue.includes('x'))) {
    return false;
  }

  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators
  const cleanValue = value.trim().replace(/[\s-]/g, '');
  
  // Check for obviously invalid patterns
  if (cleanValue.length < 8) {
    return false;
  }

  // With country code +54: +54[optionally 9][optionally 0][2-9]\d{1,3}\d{6,8}
  if (cleanValue.startsWith('+54')) {
    const pattern = /^\+54(?:9)?0?[2-9]\d{1,3}\d{6,8}$/;
    return pattern.test(cleanValue);
  }
  
  // Without country code: must start with trunk prefix 0
  // Mobile format: 09[2-9]\d{1,3}\d{6,8}
  // Landline format: 0[2-9]\d{1,3}\d{6,8}
  const pattern = /^09[2-9]\d{1,3}\d{6,8}$|^0[2-9]\d{1,3}\d{6,8}$/;
  return pattern.test(cleanValue);
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject if empty or contains only spaces
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Pattern to match valid names:
  // - Unicode letters (including accents)
  // - Spaces
  // - Apostrophes and hyphens
  // Reject digits and X Æ A-12 style names
  const namePattern = /^[\p{L}\s'-]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }

  // Reject if it contains obvious non-name patterns
  if (/\d/.test(value)) {
    return false;
  }

  // Reject X Æ A-12 style names
  if (/[Ææ]/.test(value) || /A-12/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Helper function to run Luhn checksum on credit card numbers
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have valid length for major card types
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for valid prefixes and lengths for major card types
  let isValidType = false;
  
  // Visa: starts with 4, length 13, 16, 19
  if (digitsOnly.startsWith('4') && (digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19)) {
    isValidType = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if ((digitsOnly.startsWith('51') || digitsOnly.startsWith('52') || digitsOnly.startsWith('53') || 
            digitsOnly.startsWith('54') || digitsOnly.startsWith('55') ||
            (digitsOnly.startsWith('222') && parseInt(digitsOnly.substring(0, 4), 10) >= 2221 && 
             parseInt(digitsOnly.substring(0, 4), 10) <= 2720)) && digitsOnly.length === 16) {
    isValidType = true;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((digitsOnly.startsWith('34') || digitsOnly.startsWith('37')) && digitsOnly.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}