/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    const lowercaseMatch = match.toLowerCase();
    return !exceptions.some(exception => lowercaseMatch === exception.toLowerCase());
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match digit followed by the token
  const pattern = new RegExp(`\\d${escapedToken}`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
// Check for immediate repeated sequences (like "abab", "123123", etc.)
  // This pattern looks for any 2+ character sequence that repeats immediately
  const repeatedSequencePattern = /(.+)\\1+/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  // Additional check for alternating patterns like "abab", "xyxy", etc.
  const alternatingPattern = /([a-zA-Z0-9]{2,})\1+/i;
  if (alternatingPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if this is an IPv4 address to exclude it
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // IPv6 patterns:
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6 = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;

  // IPv6 with :: (shortened)
  // This is more complex because :: can appear at the beginning, middle, or end
  // and represents one or more groups of zeros
  const shortenedIPv6 = /^((?:[0-9a-fA-F]{1,4}:)*)(?:::)(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}$/;

  // IPv6 with :: at the beginning
  const leadingDoubleColon = /^::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4})*$/;

  // IPv6 with :: at the end
  const trailingDoubleColon = /^(?:[0-9a-fA-F]{1,4}:)*::$/;

  // IPv6 with :: in the middle
  const middleDoubleColon = /^(?:[0-9a-fA-F]{1,4}:)+(?:::)(?::[0-9a-fA-F]{1,4})+$/;

  // Check for compressed IPv6 like "::1" (loopback)
  const loopback = /^::1$/;

  // Check for IPv4-mapped IPv6 addresses like ::ffff:192.168.1.1
  const ipv4MappedIPv6 = /^::ffff:((?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))$/;

  // More comprehensive IPv6 pattern for anywhere in string
  const ipv6Anywhere = /(?<![0-9a-fA-F])(?:[0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}(?![0-9a-fA-F])/;
  
  const trimmedValue = value.trim();

  // Test all IPv6 patterns - both anchored and anywhere patterns
  return fullIPv6.test(trimmedValue) ||
         shortenedIPv6.test(trimmedValue) ||
         leadingDoubleColon.test(trimmedValue) ||
         trailingDoubleColon.test(trimmedValue) ||
         middleDoubleColon.test(trimmedValue) ||
         loopback.test(trimmedValue) ||
         ipv4MappedIPv6.test(trimmedValue) ||
         ipv6Anywhere.test(trimmedValue);
}