/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // If empty or whitespace only, return as is
  if (!text || text.trim().length === 0) {
    return text;
  }

  // Capitalize the first character of the string
  let result = text.charAt(0).toUpperCase() + text.slice(1);
  
  // Find sentence endings and capitalize the first letter after them
  // Pattern to match sentence ending punctuation followed by optional whitespace and lowercase letter
  result = result.replace(/([.!?]+\s*)([a-z])/g, (match, sentenceEnd, firstLetter) => {
    return sentenceEnd + firstLetter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Extract all URLs from text, removing trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs (http/https schemes)
  const urlPattern = /https?:\/\/[^\s\\"')]+(?=[\s\\"')]|$)/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    return url.replace(/[.,!?;]+$/, '');
  });
}

/**
 * TODO: Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite URLs according to the rules described in problem.md.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const docsPattern = /http:\/\/([^/]+)(\/.*)?/g;
  
  return text.replace(docsPattern, (match, host, path) => {
    const fullPath = path || '';
    
    // Skip rewriting if path contains dynamic hints or legacy extensions
    if (fullPath.includes('?') || fullPath.includes('&') || fullPath.includes('=') ||
        fullPath.includes('cgi-bin') || fullPath.includes('.jsp') || 
        fullPath.includes('.php') || fullPath.includes('.asp') || 
        fullPath.includes('.aspx') || fullPath.includes('.do') || 
        fullPath.includes('.cgi') || fullPath.includes('.pl') || 
        fullPath.includes('.py')) {
      return 'https://' + host + fullPath;
    }
    
    // If path begins with /docs/, rewrite host
    if (fullPath.startsWith('/docs/')) {
      return 'https://docs.' + host + fullPath;
    }
    
    // Always upgrade to https
    return 'https://' + host + fullPath;
  });
}

/**
 * TODO: Extract four-digit year from mm/dd/yyyy format, return N/A if invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}