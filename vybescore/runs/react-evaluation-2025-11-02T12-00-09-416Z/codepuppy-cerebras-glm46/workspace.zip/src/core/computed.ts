/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Computed, 
  updateObserver,
  notifyObservers,
  addObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equality function parameter
  let equalFn: EqualFn<T> | undefined
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    // When false, always consider values different
    equalFn = () => false
  } else if (equal === true || equal === undefined) {
    // When true or undefined, use strict equality
    equalFn = (a, b) => a === b
  }

  // Create a computed value that is both observer and subject
  const computed: Computed<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    updateFn: (prevValue?: T) => {
      // Execute update function with this computed as active observer
      const newValue = updateFn(prevValue)
      
      // Check if value actually changed
      if (equalFn && computed.value !== undefined && equalFn(computed.value, newValue)) {
        return computed.value
      }
      
      // Update the value
      computed.value = newValue
      
      // Notify all observers of this computed value
      notifyObservers(computed)
      
      return newValue
    },
  }
  
  // Initialize the computed value by running once to track dependencies
  updateObserver(computed)
  
  const getter: GetterFn<T> = () => {
    // If there's an active observer, it should depend on this computed value
    const observer = getActiveObserver()
    if (observer) {
      addObserver(computed, observer)
    }
    
    return computed.value as T
  }
  
  return getter
}