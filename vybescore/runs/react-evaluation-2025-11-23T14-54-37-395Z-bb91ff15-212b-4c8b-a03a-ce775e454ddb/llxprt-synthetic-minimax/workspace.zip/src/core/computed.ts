/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  ComputedObserver,
  notifyDependents,
  getActiveObserver,
  setActiveObserver,
  EqualFn 
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: ComputedObserver<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }

  const getter: GetterFn<T> = () => {
    // Set this observer as active to track dependencies
    const previousActiveObserver = getActiveObserver()
    setActiveObserver(o)
    
    try {
      // Evaluate the computation without passing value to allow default parameters
      const newValue = updateFn()
      const valueChanged = newValue !== o.value
      
      // Only update and notify if the value actually changed
      if (valueChanged) {
        o.value = newValue
        // Notify dependents after value has been updated
        notifyDependents(o)
      }
      
      return o.value
    } finally {
      setActiveObserver(previousActiveObserver)
    }
  }

  return getter
}