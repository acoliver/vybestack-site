/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  ComputedObserver,
  registerDependency,
  getActiveObserver,
  setActiveObserver,
  updateObserver,
  UpdateFn
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    observers: new Set(), // Track computed values this callback depends on
  }
  
  // Execute the callback to establish dependencies
  const executeCallback = () => {
    const previousActiveObserver = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      const newValue = updateFn(value)
      value = newValue
      observer.value = newValue
      return newValue
    } finally {
      setActiveObserver(previousActiveObserver)
    }
  }
  
  // Execute once to establish dependency relationships
  executeCallback()
  
  // Register this observer as a dependent of any computed values it accessed
  const activeObserver = getActiveObserver()
  if (activeObserver && 'observers' in activeObserver) {
    registerDependency(activeObserver as ComputedObserver<unknown>, observer)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}