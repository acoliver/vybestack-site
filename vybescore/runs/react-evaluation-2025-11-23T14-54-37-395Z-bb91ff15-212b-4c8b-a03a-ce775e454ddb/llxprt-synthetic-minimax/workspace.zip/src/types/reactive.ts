/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  observers?: Set<ComputedObserver<unknown>> // Track computed values this observer depends on
}

// Add observers set to Observer type for computed values that need to notify others
export type ComputedObserver<T> = ObserverR & ObserverV<T> & {
  observers: Set<ObserverR>
}

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Add functions for managing computed observer dependencies
export function addDependency<T>(observer: ComputedObserver<T>, dependent: ObserverR): void {
  if (!observer.observers) {
    observer.observers = new Set()
  }
  observer.observers.add(dependent)
}

export function notifyDependents<T>(observer: ComputedObserver<T>): void {
  if (observer.observers) {
    // Create a copy to avoid issues if observers are modified during iteration
    const dependents = Array.from(observer.observers)
    dependents.forEach(dep => {
      updateObserver(dep as Observer<unknown>)
    })
  }
}

export function registerDependency(computedObserver: ComputedObserver<unknown>, observer: ObserverR): void {
  if (!computedObserver.observers) {
    computedObserver.observers = new Set()
  }
  computedObserver.observers.add(observer)
}

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}
