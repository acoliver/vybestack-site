#!/usr/bin/env node
import * as fs from 'node:fs';
import type { FormatType } from '../types.js';
import { validateReportData } from '../utils/validation.js';
import { getFormatter } from '../formatters/index.js';

interface CliArgs {
  dataFile: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: FormatType = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      const formatValue = args[i + 1];
      if (!formatValue) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Unsupported format: ${formatValue}. Supported formats: markdown, text`);
        process.exit(1);
      }
      format = formatValue as FormatType;
      i++;
    } else if (arg === '--output') {
      const outputPathValue = args[i + 1];
      if (!outputPathValue) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = outputPathValue;
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  return { dataFile, format, outputPath, includeTotals };
}

function main() {
  const args = parseArgs(process.argv.slice(2));

  let jsonData: unknown;
  try {
    const fileContent = fs.readFileSync(args.dataFile, 'utf-8');
    jsonData = JSON.parse(fileContent);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: file not found: ${args.dataFile}`);
      process.exit(1);
    }
    if (error instanceof SyntaxError) {
      console.error(`Error: invalid JSON in file ${args.dataFile}: ${error.message}`);
      process.exit(1);
    }
    console.error(`Error: failed to read file ${args.dataFile}: ${(error as Error).message}`);
    process.exit(1);
  }

  let reportData;
  try {
    reportData = validateReportData(jsonData);
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }

  const formatter = getFormatter(args.format);
  const output = formatter.render(reportData, { includeTotals: args.includeTotals });

  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: failed to write output file: ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
