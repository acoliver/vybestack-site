/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Global tracking of active observer for dependency tracking
let activeObserver: ObserverR | undefined

// Override mechanism for active observer
let activeObserverOverride: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserverOverride || activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function setActiveObserverOverride(observer: ObserverR | undefined): void {
  activeObserverOverride = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  const previousOverride = activeObserverOverride
  activeObserver = observer
  activeObserverOverride = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    activeObserverOverride = previousOverride
  }
}

// Helper function to create a default equality function
export function createDefaultEqualFn<T>(): EqualFn<T> {
  return (a: T, b: T) => a === b
}
