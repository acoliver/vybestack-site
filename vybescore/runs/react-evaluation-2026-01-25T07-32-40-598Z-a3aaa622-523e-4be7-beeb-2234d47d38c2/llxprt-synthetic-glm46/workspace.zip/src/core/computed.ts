/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Options
} from '../types/reactive.js'

import { notifyChange } from './notifier.js'

interface ComputedObserver<T> extends Observer<T> {
  dependencies?: Set<Observer<unknown>>
  dirty?: boolean
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const o: ComputedObserver<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue?: T) => {
      const newValue = updateFn(currentValue)
      
      if (equalFn && currentValue !== undefined && equalFn(currentValue, newValue)) {
        return currentValue
      }
      
      return newValue
    },
    dependencies: new Set(),
    dirty: true,
  }
  
  // Initialize the computed value - if no initial value provided, 
  // compute using default parameter (undefined)
  if (value !== undefined) {
    o.value = value
    o.dirty = false
  }
  
  return (): T => {
    // Re-evaluate when accessed to track dependencies
    if (o.dirty) {
      const prevValue = o.value
      updateObserver(o)
      o.dirty = false
      
      // Check if we need to refresh dependencies
      if (prevValue !== o.value) {
        // Value changed, notify all callbacks
        notifyChange()
      }
    } else {
      // Just track dependencies without re-computing
      updateObserver(o)
    }
    return o.value!
  }
}
