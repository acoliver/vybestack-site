/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  Options
} from '../types/reactive.js'

import { notifyChange } from './notifier.js'

type EqualFn<T> = (lhs: T, rhs: T) => boolean

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  return [read, write]
  
  function read(): T {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
    }
    return s.value
  }

  function write(nextValue: T): T {
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify the observer that this value has changed
    if (s.observer) {
      updateObserver(s.observer as Observer<unknown>)
    }
    
    // Notify all callbacks of the change
    notifyChange()
    
    return s.value
  }
}
