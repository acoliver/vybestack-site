/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, setActiveObserverOverride } from '../types/reactive.js'
import { registerCallback } from './notifier.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      if ((observer as Observer<T> & { disposed: boolean }).disposed) {
        return currentValue || value || (undefined as T)
      }
      return updateFn(currentValue)
    },
  }
  
  // Mark this observer as a callback for proper cleanup
  ;(observer as Observer<T> & { disposed: boolean }).disposed = false
  
  // Execute initial callback to establish dependencies
  const previousActiveObserver = getActiveObserver()
  
  // Set this observer as active so dependencies can be tracked
  setActiveObserverOverride(observer)
  
  // Execute initial evaluation to track dependencies
  updateObserver(observer)
  
  // Restore previous observer
  setActiveObserverOverride(previousActiveObserver)
  
  // Register callback to be notified of changes using the new notifier system
  const unregister = registerCallback(() => {
    if (!(observer as Observer<T> & { disposed: boolean }).disposed) {
      updateObserver(observer)
    }
  })
  
  return () => {
    if ((observer as Observer<T> & { disposed: boolean }).disposed) return
    ;(observer as Observer<T> & { disposed: boolean }).disposed = true
    
    // Remove from registry
    unregister()
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value || (undefined as T)
  }
}
