/**
 * Global notification system for reactive primitives
 */

// Global registry for all callbacks
const callbackRegistry = new Set<() => void>()

// Global registry for notifying observers of changes
let changeNotifier: (() => void) | undefined

export function registerCallback(callback: () => void): () => void {
  callbackRegistry.add(callback)
  return () => {
    callbackRegistry.delete(callback)
  }
}

export function setChangeNotifier(notifier: () => void): void {
  changeNotifier = notifier
}

export function notifyChange(): void {
  // Notify all callbacks
  callbackRegistry.forEach(callback => callback())
  
  // Also call the global change notifier if set
  if (changeNotifier) {
    changeNotifier()
  }
}