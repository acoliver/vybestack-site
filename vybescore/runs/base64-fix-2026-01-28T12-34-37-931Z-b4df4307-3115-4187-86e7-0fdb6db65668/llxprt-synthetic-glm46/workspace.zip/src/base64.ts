/**
 * Returns true if the string is valid Base64.
 */
function isValidBase64(input: string): boolean {
  // Check if the string contains only Base64 characters and optional padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) return false;
  
  // Check if the padded length is correct
  const paddingLength = input.length - input.replace(/=+$/, '').length;
  return paddingLength <= 2;
}

/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Handles standard Base64 input with or without padding.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
