/**
 * Encode plain text to Base64 using the canonical alphabet.
 * Returns proper Base64 with padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Check if the padding characters are properly placed.
 */
function hasValidPadding(input: string): boolean {
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) {
    // No padding: always valid (Node will add padding as needed)
    return true;
  }
  
  // If there's padding, it must be at the end
  const paddingOnly = input.substring(paddingIndex);
  // Padding can only be 1 or 2 '=' characters
  if (!/^(={1,2})$/.test(paddingOnly)) {
    return false;
  }
  
  // Check padding placement makes sense
  const paddingLength = input.length - paddingIndex;
  const remainder = paddingIndex % 4;
  
  // 1 padding character: must have remainder 3
  // 2 padding characters: must have remainder 2
  return !((paddingLength === 1 && remainder !== 3) || 
           (paddingLength === 2 && remainder !== 2));
}

/**
 * Validate if input contains only valid Base64 characters.
 * Enforces proper Base64 formatting rules.
 */
function isValidBase64(input: string): boolean {
  // Check for non-canonical Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check if padding is valid
  return hasValidPadding(input);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 with or without padding and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
