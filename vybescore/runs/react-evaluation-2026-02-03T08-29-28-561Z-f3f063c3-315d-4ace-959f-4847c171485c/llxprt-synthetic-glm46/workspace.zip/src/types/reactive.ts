/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observers?: (() => void)[]
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const subjectObservers = new Map<Subject<any>, ObserverR[]>()
const computedSubjects: Subject<any>[] = []
const globalCallbacks: ObserverR[] = []

export function registerCallback(observer: ObserverR): void {
  globalCallbacks.push(observer)
}

export function unregisterCallback(observer: ObserverR): void {
  const index = globalCallbacks.indexOf(observer)
  if (index > -1) {
    globalCallbacks.splice(index, 1)
  }
}

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  const observers = subjectObservers.get(subject)
  if (observers) {
    observers.forEach(obs => updateObserver(obs as Observer<unknown>))
  }
  
  // Also notify callbacks to check dependencies
  globalCallbacks.forEach(callback => {
    updateObserver(callback as Observer<unknown>)
  })
}

export function addObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  if (!subjectObservers.has(subject)) {
    subjectObservers.set(subject, [])
  }
  subjectObservers.get(subject)!.push(observer)
}

export function removeObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  const observers = subjectObservers.get(subject)
  if (observers) {
    const index = observers.indexOf(observer)
    if (index > -1) {
      observers.splice(index, 1)
    }
  }
}

export function markComputedSubject(subject: Subject<any>): void {
  if (!computedSubjects.includes(subject)) {
    computedSubjects.push(subject)
  }
}

export function notifyComputedSubjects(): void {
  computedSubjects.forEach(subject => {
    const observers = subjectObservers.get(subject)
    if (observers) {
      observers.forEach(obs => updateObserver(obs as Observer<unknown>))
    }
  })
}
