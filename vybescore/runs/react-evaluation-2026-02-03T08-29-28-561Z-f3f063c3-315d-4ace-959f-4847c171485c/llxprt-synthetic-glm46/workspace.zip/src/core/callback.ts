/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, registerCallback, unregisterCallback } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Register callback globally to be notified of changes
  registerCallback(observer)
  
  // Execute once to establish dependencies
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Unregister from global callbacks
    unregisterCallback(observer)
    
    // Clear the observer to stop further updates
    observer.value = value
    observer.updateFn = () => value!
  }
}


