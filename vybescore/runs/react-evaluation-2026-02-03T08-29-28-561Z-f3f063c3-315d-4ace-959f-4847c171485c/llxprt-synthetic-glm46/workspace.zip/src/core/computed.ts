/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  Subject,
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  addObserver,
  notifyObservers,
  markComputedSubject,
  notifyComputedSubjects,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Treat the observer itself as a subject for other observers to depend on
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value!,
  }
  
  // Mark this as a computed subject for cascading updates
  markComputedSubject(subject)
  
  // Create a function that recomputes when dependencies change
  const recompute = () => {
    const oldValue = o.value
    updateObserver(o)
    const hasChanged = oldValue !== o.value
    if (hasChanged) {
      subject.value = o.value!
      // Notify all observers that depend on this computed value
      notifyObservers(subject)
      // Trigger cascading updates for computed values
      notifyComputedSubjects()
    }
  }
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // When called from another observer, create a dependency
      addObserver(subject, observer)
    }
    return o.value!
  }
  
  // Initial computation
  recompute()
  
  return getter
}
