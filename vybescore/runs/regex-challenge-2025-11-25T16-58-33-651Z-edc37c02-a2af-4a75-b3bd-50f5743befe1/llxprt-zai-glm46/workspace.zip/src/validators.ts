export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive checks
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that handles most cases while rejecting obvious invalid ones
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validation rules
  // No consecutive dots
  if (value.includes('..')) {
    return false;
  }
  
  // No dots at the beginning or end of local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain shouldn't end with a dot
  if (domain.endsWith('.')) {
    return false;
  }
  
  // Local part shouldn't be empty
  if (localPart.length === 0) {
    return false;
  }
  
  // Should have at least one dot in domain
  if (!domain.includes('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers with comprehensive format support
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove common separators and spaces
  const cleaned = value.replace(/[\s-()]/g, '');
  
  // US phone regex with optional +1 country code
  const usPhoneRegex = /^(\+?1)?([2-9]\d{2})([2-9]\d{2})(\d{4})$/;
  
  const match = cleaned.match(usPhoneRegex);
  if (!match) {
    return false;
  }
  
  // Area code cannot start with 0 or 1 (already enforced by regex: [2-9])
  // Central office code cannot start with 0 or 1 (already enforced by regex: [2-9])
  
  // Ensure we have the right length
  if (cleaned.length < 10) {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but preserve structure
  const normalized = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex supporting all specified formats
  // Group 1: Optional +54 country code
  // Group 2: Optional 9 mobile indicator (when country code is present)
  // Group 3: Area code (2-4 digits, leading digit 1-9)
  // Group 4: Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = normalized.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, countryCode, mobileIndicator, areaCode] = match;
  
  // Area code must be 2-4 digits (already enforced by regex: [1-9]\d{1,3})
  // Subscriber number must be 6-8 digits (already enforced by regex)
  
  // If country code is omitted, must start with trunk prefix 0 in original value
  if (!countryCode && !value.startsWith('0')) {
    return false;
  }
  
  // If country code is present but mobile indicator is missing, area code must not start with 9
  // (since 9 is reserved for mobile numbers when country code is present)
  if (countryCode && !mobileIndicator && areaCode.startsWith('9')) {
    return false;
  }
  
  // If mobile indicator is present, area code should typically start with certain digits
  // This is a soft validation - the main validation is handled by the regex structure
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens
 * Permits unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Name regex that allows unicode letters, spaces, apostrophes, and hyphens
  // \p{L} matches any unicode letter
  const nameRegex = /^[\p{L}'\s-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional validation to reject names with consecutive special characters
  if (value.includes("''") || value.includes('--')) {
    return false;
  }
  
  // Should have at least one letter
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }
  
  // Should not be just whitespace
  if (value.trim().length === 0) {
    return false;
  }
  
  return true;
}

// Luhn algorithm helper function for credit card validation
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for major brands
 * Accepts Visa/Mastercard/AmEx prefixes and lengths, runs Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  const cardRegex = /^(?:4(?:\d{12}|\d{15})|5[1-5]\d{14}|3[47]\d{13}|2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12})$/;
  
  if (!cardRegex.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}