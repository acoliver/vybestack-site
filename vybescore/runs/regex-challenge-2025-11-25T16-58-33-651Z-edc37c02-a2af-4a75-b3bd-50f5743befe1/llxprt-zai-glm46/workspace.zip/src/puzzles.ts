/**
 * Find words starting with the prefix but excluding the listed exceptions
 * Returns an array of matched words that start with the given prefix but are not in the exceptions list
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex special characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to match whole words starting with the prefix
  // \b ensures we match whole words, \w* matches the rest of the word
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive) and remove duplicates
  const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
  
  return matches
    .map(word => word)
    .filter(word => !lowerExceptions.includes(word.toLowerCase()))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string
 * Uses lookaheads/lookbehinds to find embedded tokens following digits
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token preceded by a digit
  // We want to capture the digit + token as the full match
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    // Return the full match including the digit
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validate passwords according to strong password policy
 * Requirements: At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Character type requirements
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // Look for patterns where a sequence of 2+ characters is immediately repeated
  for (let seqLength = 2; seqLength <= 4; seqLength++) {
    for (let i = 0; i <= value.length - seqLength * 2; i++) {
      const sequence = value.slice(i, i + seqLength);
      const nextSequence = value.slice(i + seqLength, i + seqLength * 2);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) while excluding IPv4 addresses
 * Returns true if the text contains a valid IPv6 address, false otherwise
 */
export function containsIPv6(value: string): boolean {
  // IPv4 address pattern (to exclude)
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If it's definitely an IPv4 address, return false
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIpv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: compression (shorthand)
  const compressedIpv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with leading :: (like ::1)
  const leadingCompressedPattern = /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with trailing :: (like fe80::)
  const trailingCompressedPattern = /\b[0-9a-fA-F]{1,4}::\b/;
  
  // IPv6 embedded IPv4 (like ::ffff:192.168.1.1)
  const ipv4EmbeddedPattern = /\b(?:[0-9a-fA-F]{1,4}:)*:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Test for any IPv6 pattern
  return fullIpv6Pattern.test(value) ||
         compressedIpv6Pattern.test(value) ||
         leadingCompressedPattern.test(value) ||
         trailingCompressedPattern.test(value) ||
         ipv4EmbeddedPattern.test(value);
}