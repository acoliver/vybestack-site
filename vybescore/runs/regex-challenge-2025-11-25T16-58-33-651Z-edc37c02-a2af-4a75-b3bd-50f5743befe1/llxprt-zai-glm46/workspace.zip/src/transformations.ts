/**
 * Capitalize the first character of each sentence
 * Handles sentence boundaries (., !, ?), fixes spacing, preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return text;
  }
  
  // First, normalize spacing around sentence endings
  const normalized = text
    // Ensure proper spacing after sentence endings
    .replace(/([.?!])(?!\s|$)/g, '$1 ')
    // Collapse multiple spaces
    .replace(/\s+/g, ' ')
    .trim();
  
  // Handle abbreviation preservation - common abbreviations that shouldn't start new sentences
  const abbreviations = /\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Ave|Blvd|Rd|etc|e\.g|i\.e|vs|approx|no|vol|fig|tab|p|pp|ch|sec|al|et al)\.?$/i;
  
  // Split into sentences, taking abbreviations into account
  const sentences: string[] = [];
  let currentSentence = '';
  
  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    currentSentence += char;
    
    // Check if we've hit a sentence ending
    if (/[.?!]/.test(char)) {
      // Look ahead to see if this is an abbreviation
      const remainingText = normalized.substring(i + 1).trim();
      const prevWords = currentSentence.trim().split(/\s+/);
      const lastWord = prevWords[prevWords.length - 1];
      
      if (abbreviations.test(lastWord) && remainingText.length > 0 && !/^[A-Z]/.test(remainingText)) {
        // This is likely an abbreviation, continue building the sentence
        continue;
      }
      
      // This is a real sentence ending
      sentences.push(currentSentence.trim());
      currentSentence = '';
      
      // Skip any spaces after the punctuation
      while (i + 1 < normalized.length && /\s/.test(normalized[i + 1])) {
        i++;
      }
    }
  }
  
  // Add any remaining text
  if (currentSentence.trim()) {
    sentences.push(currentSentence.trim());
  }
  
  // Capitalize each sentence and rejoin
  return sentences
    .map(sentence => {
      if (!sentence) return sentence;
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    })
    .join(' ');
}

/**
 * Extract all URLs from the given text
 * Returns URLs without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex that matches most common URL patterns
  const urlRegex = /(?:https?:\/\/)?(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation and ensuring scheme
  return matches
    .map(url => {
      // Remove trailing punctuation like . , ; : ! ? ) ] } "
      url = url.replace(/[.,;:!?)}\]"']+$/g, '');
      
      // Add scheme if missing
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
      }
      
      return url;
    })
    .filter((url, index, arr) => arr.indexOf(url) === index); // Remove duplicates
}

/**
 * Replace http:// with https:// while leaving existing https:// URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's at the beginning or after whitespace/punctuation
  return text.replace(/(^|\s)(http:\/\/)/g, '$1https://');
}

/**
 * Rewrite documentation URLs to use docs.example.com host
 * Always upgrades to https:// and rewrites /docs/ paths to docs.example.com
 * Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Regex to match URLs with http scheme
  const urlRegex = /(http:\/\/)([a-zA-Z0-9.-]+)(\/[^\s]*)?/g;
  
  return text.replace(urlRegex, (match, scheme, host, path = '') => {
    const newScheme = 'https://';
    
    // If there's no path, just upgrade the scheme
    if (!path || path === '/') {
      return newScheme + host;
    }
    
    // Check if the path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic content indicators that should prevent host rewrite
      const dynamicIndicators = [
        /\/cgi-bin\//,
        /[?&=]/,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/
      ];
      
      const hasDynamicContent = dynamicIndicators.some(indicator => indicator.test(path));
      
      if (!hasDynamicContent) {
        // Rewrite to docs.example.com for documentation paths
        const newHost = host.includes('.') ? `docs.${host}` : 'docs.example.com';
        return newScheme + newHost + path;
      }
    }
    
    // Just upgrade the scheme for all other cases
    return newScheme + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings
 * Returns the four-digit year for valid mm/dd/yyyy format, or 'N/A' for invalid formats
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.trim().match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day ranges
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for days based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  const yearNum = parseInt(year, 10);
  
  // Check for leap year February
  if (month === 2) {
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}