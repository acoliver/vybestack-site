import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(() => {
  // Clean up before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(() => {
  // Clean up after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    const formTemplate = fs.readFileSync('src/templates/form.ejs', 'utf-8');
    
    // Test the form is rendered with all required fields
    expect(formTemplate).toContain('for="firstName"');
    expect(formTemplate).toContain('for="lastName"');
    expect(formTemplate).toContain('for="email"');
    expect(formTemplate).toContain('for="phone"');
    expect(formTemplate).toContain('First name');
    expect(formTemplate).toContain('Last name');
  });

  it('persists submission and redirects', () => {
    // Create directory and file for testing
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    fs.writeFileSync(dbPath, 'test-data');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Check the file content
    const fileContent = fs.readFileSync(dbPath, 'utf-8');
    expect(fileContent).toBe('test-data');
  });
});