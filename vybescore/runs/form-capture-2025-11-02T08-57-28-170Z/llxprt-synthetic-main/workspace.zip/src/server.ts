import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { initSqlJs } from './sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || '3000';

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database variables
let db: unknown | null = null;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, '../node_modules/sql.js/dist/', file)
    });
    
    let data: Uint8Array = new Uint8Array(0);
    
    // Check if database file exists
    if (fs.existsSync(dbPath)) {
      data = fs.readFileSync(dbPath);
    }
    
    // Create database
    db = new SQL.Database(data);
    
    // Create table if not exists
    if (db) {
      const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf-8');
      (db as { exec: (sql: string) => void }).exec(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) {
    console.error('Database not initialized');
    return;
  }
  
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    const data = (db as { export: () => Uint8Array }).export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[(]?\d{1,4}[)]?[-\s]?[(]?\d{1,4}[)]?[-\s]?\d{1,4}[-\s]?\d{1,9}$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[a-zA-Z0-9\s]{1,20}$/;
  return postalCodeRegex.test(postalCode);
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  } = req.body;
  
  const errors: string[] = [];
  const values = {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  };
  
  // Validate required fields
  if (!firstName || firstName.trim() === '') {
    errors.push('First name is required');
  }
  
  if (!lastName || lastName.trim() === '') {
    errors.push('Last name is required');
  }
  
  if (!streetAddress || streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  
  if (!city || city.trim() === '') {
    errors.push('City is required');
  }
  
  if (!stateProvince || stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }
  
  if (!postalCode || postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(postalCode.trim())) {
    errors.push('Postal / Zip code format is invalid');
  }
  
  if (!country || country.trim() === '') {
    errors.push('Country is required');
  }
  
  if (!email || email.trim() === '') {
    errors.push('Email is required');
  } else if (!validateEmail(email.trim())) {
    errors.push('Email address is invalid');
  }
  
  if (!phone || phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!validatePhone(phone.trim())) {
    errors.push('Phone number format is invalid');
  }
  
  // If there are errors, re-render the form with errors and values
  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values });
  }
  
  try {
    // Insert into database
    if (db) {
      const stmt = (db as { prepare: (sql: string) => unknown }).prepare(`
        INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `) as { run: (params: string[]) => void; free: () => void };
      
      stmt.run([
        firstName.trim(),
        lastName.trim(),
        streetAddress.trim(),
        city.trim(),
        stateProvince.trim(),
        postalCode.trim(),
        country.trim(),
        email.trim(),
        phone.trim()
      ]);
      
      stmt.free();
      
      // Save database
      saveDatabase();
    }
    
    // Redirect to thank-you page
    res.status(302).redirect(`/thank-you?firstName=${encodeURIComponent(firstName.trim())}`);
  } catch (error) {
    console.error('Error saving submission:', error);
    errors.push('An error occurred while saving your submission. Please try again.');
    res.status(500).render('form', { errors, values });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName || 'stranger';
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    (db as { close: () => void }).close();
    db = null;
  }
  
  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  try {
    await initDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Handle shutdown signals
    process.on('SIGTERM', async () => {
      server.close(async () => {
        await shutdown();
      });
    });
    
    process.on('SIGINT', async () => {
      server.close(async () => {
        await shutdown();
      });
    });
    
    // Suppress the TypeScript warning about return type
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const _server = server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export default app;