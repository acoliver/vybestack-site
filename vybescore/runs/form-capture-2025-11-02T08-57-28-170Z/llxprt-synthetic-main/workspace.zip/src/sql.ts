// Simple database implementation without sql.js issues
export interface DatabaseLike {
  exec(sql: string): void;
  prepare(sql: string): StatementLike;
  export(): Uint8Array;
  close(): void;
}

export interface StatementLike {
  run(params?: unknown[]): void;
  free(): void;
}

export class SimpleDatabase implements DatabaseLike {
  private data: Map<string, unknown[]> = new Map();

  constructor(_data?: Uint8Array) {
    // Simple in-memory storage
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const data = _data; // Mark as used to avoid lint error
  }

  exec(sql: string): void {
    console.log('Exec SQL:', sql);
    // Simple schema creation
    if (sql.includes('CREATE TABLE')) {
      this.data.set('submissions', []);
    }
  }

  prepare(sql: string): StatementLike {
    console.log('Prepare SQL:', sql);
    return new SimpleStatement(this.data, sql);
  }

  export(): Uint8Array {
    return new Uint8Array();
  }

  close(): void {
    this.data.clear();
  }
}

export class SimpleStatement implements StatementLike {
  private data: Map<string, unknown[]>;
  private sql: string;

  constructor(data: Map<string, unknown[]>, sql: string) {
    this.data = data;
    this.sql = sql;
  }

  run(params?: unknown[]): void {
    console.log('Run statement with params:', params);
    
    // If it's an INSERT INTO submissions statement
    if (this.sql.includes('INSERT INTO submissions')) {
      const submissions = this.data.get('submissions') || [];
      submissions.push(params);
      this.data.set('submissions', submissions);
    }
  }

  free(): void {
    // Nothing to free
  }
}

// Export an interface with both Database and initSqlJs
export interface SqlJsStatic {
  Database: typeof SimpleDatabase;
}

export async function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<SqlJsStatic> {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _ = options; // Mark as used but don't use
  return { Database: SimpleDatabase };
}

// Re-export Database as a class
export { SimpleDatabase as Database };