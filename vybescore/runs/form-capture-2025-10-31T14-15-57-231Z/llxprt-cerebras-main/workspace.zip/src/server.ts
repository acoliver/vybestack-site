import express, { Request, Response } from 'express';
import { Server } from 'http';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

// Get the directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

// Database setup
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
let db: Database | null = null;

async function initializeDatabase() {
  const SQL = await initSqlJs();
  let dbBuffer: Buffer | null = null;
  
  // Load existing database or create new one
  try {
    dbBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(dbBuffer);
  } catch (error) {
    db = new SQL.Database();
    // Create table from schema
    const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
    db.run(schema);
  }
}

// Form validation helper
function validateForm(data: Record<string, string>) {
  const errors: Record<string, string> = {};
  
  // Check required fields
  const requiredFields = ['firstName', 'lastName', 'streetAddress', 'city', 
                          'stateProvince', 'postalCode', 'country', 'email', 'phone'];
  
  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  }
  
  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (data.email && !emailRegex.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  // Phone validation (international format support)
  const phoneRegex = /^[\d\s()+-]+$/;
  if (data.phone && !phoneRegex.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  // Postal code validation (alphanumeric support)
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  if (data.postalCode && !postalCodeRegex.test(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }
  
  return errors;
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: {}, data: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(formData);
  
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, data: formData });
  }
  
  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Write database to file
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
  
  res.redirect('/thank-you');
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
let server: Server | null = null;
async function startServer() {
  await initializeDatabase();
  server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
  return server;
}

process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing server...');
  server?.close(() => {
    console.log('Server closed');
  });
  
  // Close database
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
    db.close();
  }
});

process.on('SIGINT', () => {
  console.log('SIGINT received, closing server...');
  server?.close(() => {
    console.log('Server closed');
  });
  
  // Close database
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
    db.close();
  }
  
  process.exit(0);
});

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});