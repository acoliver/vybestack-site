/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces into single spaces
  const processed = text.replace(/\s+/g, ' ');
  
  // Common abbreviations that should not trigger sentence capitalization
  const abbreviations = ['Mr.', 'Mrs.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'St.', 'vs.', 'etc.', 'e.g.', 'i.e.'];
  
  // Pattern to identify sentence boundaries
  // Look for punctuation marks followed by space and lowercase letter
  // But exclude common abbreviations
  let result = '';
  const words = processed.split(' ');
  
  let capitalizeNext = true;
  
  for (let i = 0; i < words.length; i++) {
    let word = words[i];
    
    // Check if this word is an abbreviation
    const isAbbrev = abbreviations.some(abbrev => 
      word.toLowerCase().endsWith(abbrev.toLowerCase())
    );
    
    if (capitalizeNext && word.length > 0) {
      // Capitalize first letter of word
      word = word.charAt(0).toUpperCase() + word.slice(1);
      capitalizeNext = false;
    } else if (!isAbbrev && word.match(/[.!?]$/)) {
      // End of sentence - next word should be capitalized
      capitalizeNext = true;
    }
    
    result += (i > 0 ? ' ' : '') + word;
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, and www URLs
  const urlPattern = /(?:https?:\/\/|www\.)[^\s]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation and normalize
  return matches.map(url => {
    // Remove trailing punctuation
    let cleanUrl = url.replace(/[.,!?;]+$/g, '');
    
    // Add https:// if URL starts with www
    if (cleanUrl.startsWith('www.')) {
      cleanUrl = 'https://' + cleanUrl;
    }
    
    return cleanUrl;
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave https:// untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs and capture host and path
  return text.replace(/http:\/\/([^/\s]+)(\/[^\s]*)?/g, (match, host, path = '') => {
    const hostPart = host.trim();
    const pathPart = path || '';
    
    // Check for dynamic hints in path
    const dynamicHints = /(cgi-bin|\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i;
    const hasDynamicHints = dynamicHints.test(pathPart);
    
    // Always upgrade scheme to https
    let result = 'https://';
    
    // Only rewrite host for docs paths without dynamic hints
    if (!hasDynamicHints && pathPart.startsWith('/docs/')) {
      // Rewrite host to docs.originalhost
      const docsHost = 'docs.' + hostPart;
      result += docsHost + pathPart;
    } else {
      // Keep original host
      result += hostPart + pathPart;
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Additional validation for days in month
  const daysInMonth = new Date(year, month, 0).getDate();
  
  if (day > daysInMonth) {
    return 'N/A';
  }
  
  return match[3]; // Return the year
}
