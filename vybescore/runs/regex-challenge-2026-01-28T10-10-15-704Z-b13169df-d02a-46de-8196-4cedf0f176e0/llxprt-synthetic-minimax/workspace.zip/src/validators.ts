export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Basic structure: local@domain.tld
  // Local part: letters, digits, +, -, ., _ (but not starting/ending with dot, no double dots)
  // Domain: letters, digits, hyphens, dots (but not starting/ending with hyphen/dot, no double dots)
  // TLD: letters only, 2+ characters
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9+._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  return emailRegex.test(trimmed);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digits except leading +
  const clean = value.trim().replace(/[^\d+]/g, '');
  
  // Optional +1 prefix, then area code (3 digits, not starting with 0/1), exchange code, line number
  // Supported formats:
  // +1 (212) 555-7890
  // (212) 555-7890
  // 212-555-7890
  // 2125557890
  // +12125557890
  
  const phoneRegex = /^\+?1?(?:\([2-9]\d{2}\)|[2-9]\d{2})[.\-\s]?[2-9]\d{2}[.\-\s]?\d{4}$/;
  
  if (!phoneRegex.test(clean)) {
    return false;
  }
  
  // Check length (10 digits for US numbers, 11 with country code)
  const digitsOnly = clean.replace(/\D/g, '');
  return digitsOnly.length >= 10 && digitsOnly.length <= 11;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // First handle the original format for validation
  const trimmed = value.trim();
  
  // Pattern explanation:
  // Optional country code +54
  // Optional trunk prefix 0 (must be before area code when country code is omitted)
  // Optional mobile indicator 9 (between country/trunk and area code)
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber: remaining digits to total 6-8 digits
  
  // Remove only separators for digit counting
  const digitsOnly = trimmed.replace(/[\s-]/g, '');
  
  // Check for country code format first
  if (digitsOnly.startsWith('+54')) {
    // +54 format: +54 [9] area_code subscriber (handle multiple digit groups)
    const arFormat = /^\+54\s*(?:9\s*)?([1-9]\d{1,3})\s*(\d{3,4})\s*(\d{3,4})$/;
    const match = trimmed.match(arFormat);
    if (match) {
      const areaCode = match[1];
      const subscriber1 = match[2];
      const subscriber2 = match[3];
      
      const subscriberCombined = subscriber1 + subscriber2;
      
      return areaCode.length >= 2 && areaCode.length <= 4 && 
             areaCode.length >= 2 && areaCode.length <= 4 &&
             subscriberCombined.length >= 6 && subscriberCombined.length <= 8;
    }
    return false;
  } else {
    // Local format: 0 area_code subscriber (trunk prefix required)
    const localFormat = /^0([1-9]\d{1,3})(\d{3,5})$/;
    const match = trimmed.match(localFormat);
    if (match) {
      const totalDigits = digitsOnly.length;
      return totalDigits >= 7 && totalDigits <= 8;
    }
    return false;
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Must not be empty
  if (trimmed.length === 0) {
    return false;
  }
  
  // Pattern: Allow unicode letters (with accents), spaces, apostrophes, hyphens
  // Reject any digits or symbols not allowed in names
  // Use Unicode property escapes for letters
  const nameRegex = /^[\p{L}\p{M}\s'’-]+$/u;
  
  return nameRegex.test(trimmed);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digits
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for valid length and format
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  
  const visaPattern = /^4(\d{12}|\d{15}|\d{18})$/;
  const mastercardPattern = /^(5[1-5]\d{14}|2(2[2-9]\d|[3-6]\d{2}|7[01]\d|720)\d{12})$/;
  const amexPattern = /^(34|37)\d{13}$/;
  
  if (visaPattern.test(digitsOnly)) {
    // Visa pattern matched
  } else if (amexPattern.test(digitsOnly)) {
    // AmEx pattern matched
  } else if (mastercardPattern.test(digitsOnly)) {
    // Mastercard pattern matched
  } else {
    return false; // No valid pattern matched
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
