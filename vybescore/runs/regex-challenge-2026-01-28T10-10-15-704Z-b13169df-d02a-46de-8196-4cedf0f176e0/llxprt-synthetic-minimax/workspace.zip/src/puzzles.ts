/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to find words starting with prefix (case insensitive)
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  
  return matches.filter(word => {
    const wordLower = word.toLowerCase();
    return !exceptionsLower.some(exception => exception === wordLower.replace(prefix.toLowerCase(), ''));
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find token that follows a digit but is not at the start
  // Capture the complete digit+token pattern
  const pattern = new RegExp(`(?<!^)\\d${token}`, 'g');
  
  return text.match(pattern) || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-={}[\]{};':"|,.<>/]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab"
  // Look for any 2-character pattern that repeats immediately
  for (let i = 0; i < value.length - 3; i++) {
    const pattern = value.substring(i, i + 2);
    const repeated = value.substring(i + 2, i + 4);
    if (pattern === repeated) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern to match IPv6 addresses including shorthand notation
  // IPv6 patterns: hex groups separated by colons, with :: shorthand support
  // Must NOT match IPv4 patterns (dotted decimal notation)
  
  // First, check if this is an IPv4 address - if so, return false
  const ipv4Pattern = /\d+\.\d+\.\d+\.\d+/;
  if (ipv4Pattern.test(value)) {
    // Check if IPv4 is part of IPv6-mapped address
    const ipv6MappedPattern = /:[0-9a-fA-F]{0,4}:[0-9a-fA-F]{0,4}:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
    if (!ipv6MappedPattern.test(value)) {
      return false; // Pure IPv4, not IPv6
    }
  }
  
  // IPv6 address patterns
  // Full notation: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: can use :: to represent multiple zero groups
  
  // Pattern for IPv6 detection
  
  // Check for any IPv6-like patterns in the string
  const textPattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}/;
  
  // Look for IPv6 address anywhere in the text
  // Must not be just IPv4
  if (textPattern.test(value)) {
    // Additional check: ensure it's not purely IPv4
    const pureIpv4 = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
    if (!pureIpv4.test(value.trim())) {
      return true;
    }
  }
  
  // Check specifically for :: shorthand which is characteristic of IPv6
  if (value.includes('::')) {
    return true;
  }
  
  return false;
}
