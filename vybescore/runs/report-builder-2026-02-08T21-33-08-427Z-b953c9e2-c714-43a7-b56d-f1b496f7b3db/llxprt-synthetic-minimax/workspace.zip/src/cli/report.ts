#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { formatters } from '../formats/index.js';
import { ReportData, CLIOptions } from '../types/report.js';

function parseArgs(args: string[]): CLIOptions {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: CLIOptions['format'] | undefined;
  let output: string | undefined;
  let includeTotals = false;

  // Parse named arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1] as CLIOptions['format'];
      i++; // Skip next arg since it's the value
    } else if (arg === '--output' && i + 1 < args.length) {
      output = args[i + 1];
      i++; // Skip next arg since it's the value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format flag is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }

  return { dataFile, format, output, includeTotals };
}

function loadAndValidateData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      console.error('Error: Missing or invalid "title" field in JSON data');
      process.exit(1);
    }

    if (!data.summary || typeof data.summary !== 'string') {
      console.error('Error: Missing or invalid "summary" field in JSON data');
      process.exit(1);
    }

    if (!data.entries || !Array.isArray(data.entries) || data.entries.length === 0) {
      console.error('Error: Missing or invalid "entries" field in JSON data');
      process.exit(1);
    }

    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        console.error(`Error: Invalid "label" field in entries[${i}]`);
        process.exit(1);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        console.error(`Error: Invalid "amount" field in entries[${i}]`);
        process.exit(1);
      }
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON file - syntax error');
      process.exit(1);
    } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File not found - ${filePath}`);
      process.exit(1);
    } else {
      console.error(`Error: Failed to read file - ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  }
}

function main() {
  const args = process.argv.slice(2);
  const options = parseArgs(args);
  const data = loadAndValidateData(options.dataFile);

  const formatter = formatters[options.format];
  if (!formatter) {
    console.error('Error: Unsupported format');
    process.exit(1);
  }

  const output = formatter.render(data, options.includeTotals);

  if (options.output) {
    try {
      writeFileSync(options.output, output, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write output file - ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();
