import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import { ReportData } from '../types/report.js';

export interface Formatter {
  render: (data: ReportData, includeTotals: boolean) => string;
}

export const formatters: Record<string, Formatter> = {
  markdown: {
    render: renderMarkdown
  },
  text: {
    render: renderText
  }
};