import { ReportData } from '../types/report.js';

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  let output = `# ${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `## Entries\n\n`;

  for (const entry of data.entries) {
    const amount = entry.amount.toFixed(2);
    output += `- **${entry.label}** — $${amount}\n`;
  }

  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const totalFormatted = total.toFixed(2);
    output += `\n**Total:** $${totalFormatted}`;
  }

  return output;
}