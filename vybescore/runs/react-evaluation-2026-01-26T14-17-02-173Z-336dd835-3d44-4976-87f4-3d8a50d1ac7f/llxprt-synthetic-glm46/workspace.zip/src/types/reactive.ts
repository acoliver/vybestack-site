/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Prevent infinite recursion
  if (updatingObservers.has(observer as Observer<unknown>)) {
    return
  }
  
  updatingObservers.add(observer as Observer<unknown>)
  try {
    const previous = activeObserver
    activeObserver = observer
    try {
      observer.value = observer.updateFn(observer.value)
    } finally {
      activeObserver = previous
    }
  } finally {
    updatingObservers.delete(observer as Observer<unknown>)
  }
}

// Global registry for all inputs to track dependencies
const inputRegistry = new Map<ObserverR, Set<Observer<unknown>>>()

// Track what inputs are currently being observed by which observers
const currentObservations = new Map<Observer<unknown>, Set<ObserverR>>()

export function registerDependency(input: ObserverR, dependent: Observer<unknown>): void {
  if (!inputRegistry.has(input)) {
    inputRegistry.set(input, new Set())
  }
  inputRegistry.get(input)!.add(dependent as Observer<unknown>)
  
  // Track this observation for cleanup later
  if (!currentObservations.has(dependent as Observer<unknown>)) {
    currentObservations.set(dependent as Observer<unknown>, new Set())
  }
  currentObservations.get(dependent as Observer<unknown>)!.add(input)
}

export function unregisterDependency(input: ObserverR, dependent: Observer<unknown>): void {
  const dependents = inputRegistry.get(input)
  if (dependents) {
    dependents.delete(dependent as Observer<unknown>)
    if (dependents.size === 0) {
      inputRegistry.delete(input)
    }
  }
  
  // Remove from current observations
  const observations = currentObservations.get(dependent as Observer<unknown>)
  if (observations) {
    observations.delete(input)
    if (observations.size === 0) {
      currentObservations.delete(dependent as Observer<unknown>)
    }
  }
}

export function notifyDependents(input: ObserverR): void {
  notifyObserversForInput(input)
}

// Helper function to track when an input is being read
export function trackInputRead(input: ObserverR): void {
  const activeObserver = getActiveObserver()
  if (activeObserver) {
    registerDependency(input, activeObserver as Observer<unknown>)
  }
}

// Simplified notification system with recursion protection
const updatingObservers = new Set<Observer<unknown>>()

export function notifyObserversForInput(input: ObserverR): void {
  const dependents = inputRegistry.get(input)
  if (dependents) {
    // Create a copy to avoid issues with modification during iteration
    const dependentsCopy = new Set(dependents)
    dependentsCopy.forEach(dependent => {
      updateObserver(dependent)
    })
  }
}

// Export currentObservations for use in other modules
export { currentObservations, inputRegistry }
