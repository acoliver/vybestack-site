/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver,
  registerDependency,
  unregisterDependency,
  notifyObserversForInput
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  

  const dependencies = new Set<ObserverR>()
  let dirty = true
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: updateFn,
  }

  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // This computed is being observed, remember this observer
      registerDependency(o, observer as Observer<unknown>)
    }
    
    // If dirty, recompute
    if (dirty) {
      dirty = false
      
      // Clear previous dependencies
      dependencies.forEach(dep => {
        unregisterDependency(dep, o as Observer<unknown>)
      })
      dependencies.clear()
      
      // Execute update with this computed as active observer
      o.value = updateFn(o.value)
    }
    
    return o.value!
  }

  // Override the observer's updateFn to handle dependency tracking
  o.updateFn = () => {
    // Mark as dirty and recompute
    dirty = true
    
    // Execute the getter to recompute and establish new dependencies
    const newValue = getter()
    
    // Notify all observers that depend on this computed value
    notifyObserversForInput(o as ObserverR)
    
    return newValue
  }

  // Initial computation
  if (value === undefined) {
    // Run the first computation to establish dependencies
    updateObserver(o)
  } else {
    dirty = false
  }

  return getter
}
