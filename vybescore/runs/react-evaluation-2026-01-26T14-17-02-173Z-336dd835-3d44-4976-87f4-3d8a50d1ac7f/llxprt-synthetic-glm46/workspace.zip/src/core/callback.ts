/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, ObserverR, UpdateFn, updateObserver, unregisterDependency } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  const dependencies = new Set<ObserverR>()

  // Simple wrapper for our callback that doesn't need complex dependency tracking
  const callbackFn = (prevValue?: T): T => {
    if (disposed) return prevValue as T
    
    // Execute the callback function
    const result = updateFn(prevValue)
    
    return result as T
  }

  const observer: Observer<T> = {
    value,
    updateFn: callbackFn,
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  // Return unsubscribe function
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    
    // Remove from all dependencies
    dependencies.forEach(input => {
      unregisterDependency(input, observer as Observer<unknown>)
    })
    dependencies.clear()
  }
}
