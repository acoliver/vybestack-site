#!/usr/bin/env node

import * as fs from 'node:fs';
import { validateReportData } from '../utils.js';
import { formatters } from '../formats/index.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  let inputFile = '';
  let format = '';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (!inputFile) {
      inputFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  if (!inputFile) {
    throw new Error('Input file path is required');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return {
    inputFile,
    format,
    outputPath,
    includeTotals,
  };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Read and parse input file
    let fileContent: string;
    try {
      fileContent = fs.readFileSync(args.inputFile, 'utf-8');
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        throw new Error(`Input file not found: ${args.inputFile}`);
      }
      throw error;
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      throw new Error(`Invalid JSON in input file: ${(error as Error).message}`);
    }

    // Validate report data
    const reportData = validateReportData(jsonData);

    // Get formatter
    const formatter = formatters[args.format];
    if (!formatter) {
      throw new Error(`Unsupported format: ${args.format}`);
    }

    // Render report
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const output = formatter(reportData, options);

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();

