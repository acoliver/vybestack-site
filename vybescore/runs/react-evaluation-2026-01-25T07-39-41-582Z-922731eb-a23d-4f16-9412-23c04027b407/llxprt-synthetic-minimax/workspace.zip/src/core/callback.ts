import {
  UnsubscribeFn,
  UpdateFn,
  Observer,
  getActiveObserver,
  setActiveObserver,
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    updateFn,
    value,
    subscribers: new Set(),
    dependencies: [],
    execute() {
      if (disposed) return
      
      const previous = getActiveObserver()
      setActiveObserver(this)
      try {
        // Clear old dependencies tracking
        this.dependencies = []
        
        // Execute the callback function to establish new dependencies
        this.value = this.updateFn(this.value)
        
        // Notify subscribers after execution
        for (const subscriber of this.subscribers) {
          subscriber()
        }
      } finally {
        setActiveObserver(previous)
      }
    },
    notify() {
      // Re-execute callback when dependencies change
      this.execute()
    }
  }
  
  // Execute immediately to establish dependencies and run callback
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear dependencies and disable updates
    observer.dependencies = []
    observer.updateFn = () => observer.value!
    observer.subscribers.clear()
  }
}
