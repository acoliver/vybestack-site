import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  Subject,
  createSubject
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let currentValue = value

  const read: GetterFn<T> = () => {
    return currentValue
  }

  const write: SetterFn<T> = (nextValue) => {
    currentValue = nextValue
    return currentValue
  }

  return [read, write]
}
