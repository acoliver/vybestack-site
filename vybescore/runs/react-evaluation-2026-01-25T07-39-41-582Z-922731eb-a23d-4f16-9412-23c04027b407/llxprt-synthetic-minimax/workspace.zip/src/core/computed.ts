import {
  GetterFn,
  UpdateFn,
  EqualFn,
  Subject,
  createSubject,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const subject = createSubject(value!)
  
  const getter: GetterFn<T> = () => {
    // Check if we're being called from within another reactive context
    const observer = getActiveObserver()
    
    // Evaluate the update function
    const result = updateFn(subject.value)
    
    // Update and notify if value changed
    if (subject.value !== result) {
      subject.value = result
      subject.notify()
    }
    
    return subject.value
  }
  
  return getter
}
