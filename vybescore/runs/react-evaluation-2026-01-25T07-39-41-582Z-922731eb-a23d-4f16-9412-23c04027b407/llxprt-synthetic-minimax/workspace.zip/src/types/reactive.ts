/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Core reactive system interfaces
export interface Subject<T> {
  value: T
  subscribers: Set<() => void>
  notify(): void
  subscribe(fn: () => void): () => void
  unsubscribe(fn: () => void): void
}

export interface Computed<T> {
  value: T
  updateFn: UpdateFn<T>
  subscribers: Set<() => void>
  evaluate(): T
  notify(): void
}

export interface Observer<T> {
  updateFn: UpdateFn<T>
  value?: T
  subscribers: Set<() => void>
  dependencies?: Array<() => unknown>
  execute(): void
  notify(): void
}

// Global reactive context for tracking dependencies
let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver<T>(observer: Observer<T> | undefined): void {
  activeObserver = observer as Observer<unknown> | undefined
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  try {
    activeObserver = observer as Observer<unknown>
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // Notify all subscribers after update
  if (observer.subscribers) {
    for (const subscriber of observer.subscribers) {
      subscriber()
    }
  }
}

// Utility functions for managing subjects
export function createSubject<T>(value: T): Subject<T> {
  const subject: Subject<T> = {
    value,
    subscribers: new Set(),
    notify() {
      for (const subscriber of this.subscribers) {
        subscriber()
      }
    },
    subscribe(fn: () => void) {
      this.subscribers.add(fn)
      return () => this.unsubscribe(fn)
    },
    unsubscribe(fn: () => void) {
      this.subscribers.delete(fn)
    }
  }
  return subject
}
