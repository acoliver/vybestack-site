#!/usr/bin/env node

import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { validateReportData } from '../utils.js';
import { getRenderer } from '../formats/index.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

/**
 * Parses command-line arguments
 */
function parseArgs(args: string[]): CliArgs {
  const inputFile = args[0];
  if (!inputFile) {
    console.error('Error: Missing input file argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

/**
 * Main CLI execution
 */
async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));

  try {
    // Read and parse input file
    const inputPath = path.resolve(args.inputFile);
    const fileContent = await fs.readFile(inputPath, 'utf-8');

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (parseError) {
      console.error(`Error: Failed to parse JSON from ${args.inputFile}`);
      if (parseError instanceof SyntaxError) {
        console.error(`JSON parse error: ${parseError.message}`);
      }
      process.exit(1);
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Get renderer and render report
    const renderOptions: RenderOptions = { includeTotals: args.includeTotals };
    const render = getRenderer(args.format);
    const output = render(reportData, renderOptions);

    // Write output
    if (args.outputPath) {
      await fs.writeFile(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
