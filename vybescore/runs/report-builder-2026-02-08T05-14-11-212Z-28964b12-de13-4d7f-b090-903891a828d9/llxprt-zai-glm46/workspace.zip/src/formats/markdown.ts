import { ReportData, RenderOptions } from '../types.js';
import { formatAmount, calculateTotal } from '../utils.js';

/**
 * Renders a report in Markdown format
 */
export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries heading
  lines.push('## Entries');

  // Entry list
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  // Total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push('');
    lines.push(`**Total:** ${formatAmount(total)}`);
  }

  return lines.join('\n');
}
