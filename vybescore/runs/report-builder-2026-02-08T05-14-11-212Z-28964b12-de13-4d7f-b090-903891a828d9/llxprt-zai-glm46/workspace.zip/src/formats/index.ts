import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Renderer function interface
 */
export type Renderer = (data: ReportData, options: RenderOptions) => string;

/**
 * Map of supported format names to renderer functions
 */
export const FORMAT_RENDERERS: Record<string, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * List of supported format names
 */
export const SUPPORTED_FORMATS = Object.keys(FORMAT_RENDERERS);

/**
 * Gets a renderer for the specified format
 * @throws Error if format is not supported
 */
export function getRenderer(format: string): Renderer {
  const renderer = FORMAT_RENDERERS[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer;
}
