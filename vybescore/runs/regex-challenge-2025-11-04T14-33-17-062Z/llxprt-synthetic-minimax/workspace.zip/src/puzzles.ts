/**
 * Finds words starting with the prefix but excluding listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with prefix
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Finds occurrences where the token appears after a digit and not at the start of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookahead to find token that appears after a digit
  const pattern = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  const matches = text.match(new RegExp(`\\d${escapedToken}`, 'g')) || [];
  
  // Extract just the token part
  return matches.map(match => match.substring(1));
}

/**
 * Validates passwords according to security policy
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // This checks for any 2-character sequence that repeats immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) while excluding IPv4 addresses
 */
export function containsIPv6(value: string): boolean {
  // First, reject if it contains IPv4 patterns
  // IPv4 pattern: 4 groups of 1-3 digits separated by dots
  if (/\b\d{1,3}(\.\d{1,3}){3}\b/.test(value)) {
    return false;
  }
  
  // IPv6 patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6 = /\b(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}\b/i;
  
  // IPv6 with :: shorthand
  // This is more complex, matching various forms of :: usage
  const shorthandIPv6 = /\b(?:[a-f0-9]{1,4}:)*(?::[a-f0-9]{1,4})*(?::)(?::[a-f0-9]{1,4})*(?::[a-f0-9]{1,4}:)*[a-f0-9]{1,4}\b/i;
  
  // IPv6 starting with ::
  const doubleColonStart = /\b::(?::[a-f0-9]{1,4}){0,7}[a-f0-9]{0,4}\b/i;
  
  // IPv6 ending with ::
  const doubleColonEnd = /\b[a-f0-9]{0,4}(?::[a-f0-9]{1,4}){0,7}::\b/i;
  
  return fullIPv6.test(value) || 
         shorthandIPv6.test(value) || 
         doubleColonStart.test(value) || 
         doubleColonEnd.test(value) ||
         /^::$/i.test(value); // All zeros case
}