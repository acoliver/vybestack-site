/**
 * Capitalizes the first character of each sentence.
 * Handles .?! as sentence endings, ensures proper spacing
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Capitalize after sentence endings (.?!)
  // Use lookbehind to ensure we capitalize after sentence delimiters
  result = result.replace(/(?<=[.!?]\s+)(.)/g, (match) => {
    return match.toUpperCase();
  });
  
  // Capitalize the first character of the text
  result = result.replace(/^(.)/g, (match) => {
    return match.toUpperCase();
  });
  
  return result;
}

/**
 * Extracts all URLs from the text.
 * Returns URLs without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  const urlPattern = /\bhttps?:\/\/[^\s)\]}>"']+(?=[)\]}>"']*[^\s)\]}>"'])/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation that might be attached
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;:!?]+$/, '');
  });
}

/**
 * Enforces HTTPS by converting http:// to https://
 * Leaves existing https URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites docs URLs by upgrading scheme and optionally changing host
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  const docsUrlPattern = /http:\/\/([^\/]+)\/(docs\/[^\s]*)/gi;
  
  return text.replace(docsUrlPattern, (match, host, path) => {
    // Check if path contains dynamic hints
    const hasDynamicHints = /[?&]|(\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path) ||
                            /cgi-bin/i.test(path);
    
    if (hasDynamicHints) {
      // Skip host rewrite, just upgrade to HTTPS
      return `https://${host}/${path}`;
    } else {
      // Rewrite host to docs.<originalhost>
      return `https://docs.${host}/${path}`;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid
 */
export function extractYear(value: string): string {
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, simple check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}