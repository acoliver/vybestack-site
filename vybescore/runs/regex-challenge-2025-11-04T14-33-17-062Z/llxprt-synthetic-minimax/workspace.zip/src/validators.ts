export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const email = value.trim();
  
  // Basic email regex pattern
  // Local part: allows letters, numbers, + tag, dots, underscores
  // Domain part: allows letters, numbers, dots, hyphens, but no underscores
  const emailPattern = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailPattern.test(email)) {
    return false;
  }
  
  // Additional checks
  // No consecutive dots
  if (email.includes('..')) {
    return false;
  }
  
  // No trailing dot in domain
  const domain = email.split('@')[1];
  if (domain.endsWith('.')) {
    return false;
  }
  
  // No underscore in domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  let phone = value.trim();
  const hadPlusOne = phone.startsWith('+1');
  phone = phone.replace(/^\+1/, ''); // Remove +1 if present
  phone = phone.replace(/[^\d]/g, ''); // Remove all non-digits
  
  // Check length (10 digits)
  if (phone.length !== 10) {
    return false;
  }
  
  // Check area code doesn't start with 0 or 1
  const areaCode = phone.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for easier processing
  const phone = value.replace(/[\s-]/g, '');
  
  // Pattern to match Argentine phone numbers
  // Optional +54, optional 9 (mobile), optional 0 (trunk), area code (2-4 digits, 1-9), subscriber (6-8 digits total)
  const phonePattern = /^(?:\+54)?(?:9)?(0)?([1-9]\d{1,3})\d{6,8}$/;
  
  const match = phone.match(phonePattern);
  if (!match) {
    return false;
  }
  
  const [full, plus54, trunkZero, areaCode] = match;
  
  // If no country code, must have trunk prefix 0
  if (!plus54 && !trunkZero) {
    return false;
  }
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Calculate total length
  const totalLength = full.length;
  
  // Validate subscriber number total (6-8 digits after area code in remaining)
  const subscriberPart = full.substring(match.index! + (plus54 ? 3 : 0) + (trunkZero ? 1 : 0) + areaCode.length);
  if (subscriberPart.length < 6 || subscriberPart.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const name = value.trim();
  
  // Must not be empty
  if (name.length === 0) {
    return false;
  }
  
  // Must contain at least one letter
  const hasLetter = /[a-zA-Z\u00C0-\u024F]/.test(name);
  if (!hasLetter) {
    return false;
  }
  
  // Must not contain digits
  if (/\d/.test(name)) {
    return false;
  }
  
  // Must not contain special symbols except apostrophes, hyphens, and spaces
  // Allow unicode letters (including accents), spaces, apostrophes, hyphens
  const validPattern = /^[\p{L}\p{M}\s'\-]+$/u;
  if (!validPattern.test(name)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function for Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths with Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cardNumber = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits
  if (!/^\d{13,19}$/.test(cardNumber)) {
    return false;
  }
  
  // Check card type and prefix
  // Visa: starts with 4, length 13, 16, 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const isVisa = /^4\d{12}(\d{3})?(\d{3})?$/.test(cardNumber);
  const isMastercard = /^(5[1-5]\d{14}|2(2[2-9]\d{2}|[3-6]\d{3}|7[01]\d{2}|720)\d{12})$/.test(cardNumber);
  const isAmEx = /^3[47]\d{13}$/.test(cardNumber);
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cardNumber);
}