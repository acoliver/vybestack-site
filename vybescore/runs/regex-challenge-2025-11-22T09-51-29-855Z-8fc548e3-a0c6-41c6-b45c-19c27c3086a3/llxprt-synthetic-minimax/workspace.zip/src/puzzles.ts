/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create word boundary pattern to match whole words starting with prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      lowerMatch === exception.toLowerCase()
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use negative lookbehind to ensure token is not at the beginning
  // Use positive lookbehind to ensure token follows a digit
  // Capture the digit followed by the token
  const pattern = new RegExp(`(?<!^)\\d+${escapedToken}`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Return the actual matched tokens
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, 1212, xyxy)
  // This regex looks for any 2+ character sequence that repeats immediately
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns:
  // 1. Full IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // 2. IPv6 with :: shorthand: xxxx:xxxx::xxxx or ::xxxx
  // 3. IPv6 with leading zeros compressed
  // Each group should be 1-4 hexadecimal digits
  
  // First, let's exclude common IPv4 patterns to avoid false positives
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 pattern that matches:
  // - Groups of 1-4 hex digits separated by colons
  // - Allows :: for zero compression
  // - Does not match IPv4 addresses
  
  // Pattern components:
  // ([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4} - Full format
  // ::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4} - Double colon at start
  // ([0-9a-fA-F]{1,4}:){1,7}: - Double colon at end
  // ([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4} - Double colon in middle
  // ([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2} - Double colon in middle
  // ([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3} - Double colon in middle
  // ([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4} - Double colon in middle
  // ([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5} - Double colon in middle
  // [0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6}) - Complex compression
  
  const ipv6Pattern = /(?<![0-9a-fA-F:])([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?<![0-9a-fA-F:])(:(:[0-9a-fA-F]{1,4}){1,7})|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})/;
  
  return ipv6Pattern.test(value);
}