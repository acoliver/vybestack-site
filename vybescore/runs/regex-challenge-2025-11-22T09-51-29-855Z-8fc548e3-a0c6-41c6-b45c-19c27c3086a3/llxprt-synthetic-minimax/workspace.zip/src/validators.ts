export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern: local@domain.tld
  // Local part: letters, numbers, dots, hyphens, underscores, plus signs
  // Domain: letters, numbers, dots, hyphens (no consecutive dots, no trailing dot)
  // TLD: at least 2 letters
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional validation: no consecutive dots, no trailing dot
  if (value.includes('..') || value.endsWith('.')) {
    return false;
  }
  
  // Check domain doesn't have underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + at the beginning
  const cleanValue = value.trim();
  
  // Check for optional +1 prefix
  const hasCountryCode = cleanValue.startsWith('+1');
  const phonePart = hasCountryCode ? cleanValue.substring(2) : cleanValue;
  
  // Extract digits
  const digits = phonePart.replace(/\D/g, '');
  
  // Check length: 10 digits for local, 11 digits with +1 prefix
  const expectedLength = hasCountryCode ? 11 : 10;
  if (digits.length !== expectedLength) {
    return false;
  }
  
  // Check if first digit is 0 or 1 (invalid area codes)
  if (digits[0] === '0' || digits[0] === '1') {
    return false;
  }
  
  // Format validation: check if it matches US phone patterns
  const phonePatterns = [
    // (212) 555-7890
    /^\(\d{3}\)\s*\d{3}-\d{4}$/,
    // 212-555-7890
    /^\d{3}-\d{3}-\d{4}$/,
    // 2125557890
    /^\d{10}$/,
    // 212 555 7890
    /^\d{3}\s+\d{3}\s+\d{4}$/
  ];
  
  const originalPattern = hasCountryCode ? cleanValue.substring(2) : cleanValue;
  return phonePatterns.some(pattern => pattern.test(originalPattern));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens, keep only digits and + sign
  const cleanValue = value.trim().replace(/[\s-]/g, '');
  
  // Pattern explanation:
  // ^(\+54)? - optional country code
  // (9)? - optional mobile indicator
  // (0)? - optional trunk prefix
  // ([1-9]\d{1,3}) - area code: first digit 1-9, total 2-4 digits
  // (\d{6,8})$ - subscriber number: 6-8 digits total
  
  // Check if it matches the strict pattern
  const pattern = /^(\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleanValue.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const hasCountryCode = !!match[1];
  const hasMobileIndicator = !!match[2];
  const hasTrunkPrefix = !!match[3];
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  // Validation rules:
  // 1. If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // 2. Mobile indicator (9) should only appear with country code or at the beginning
  if (hasMobileIndicator && !hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // 3. Area code validation: 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // 4. Subscriber number: 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, spaces, apostrophes, hyphens
  // Reject digits and symbols like X Æ A-12
  const namePattern = /^[\p{L}\s'-]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Additional validation: should not be too short
  if (value.trim().length < 2) {
    return false;
  }
  
  // Check for weird patterns like "X Æ A-12"
  // This regex looks for non-alphabetic unicode patterns
  const weirdPattern = /^[XÆA0-9\-\s]*$/i;
  if (weirdPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Basic length check (13-19 digits for most cards)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Card type validation patterns with their specific length requirements
  const cardTypes = {
    // Visa: starts with 4, length 13, 16, or 19
    visa: { pattern: /^4/, lengths: [13, 16, 19] },
    // Mastercard: starts with 51-55 or 2221-2720, length 16
    mastercard: { pattern: /^(5[1-5]|2[2-7])/, lengths: [16] },
    // American Express: starts with 34 or 37, length 15
    amex: { pattern: /^(34|37)/, lengths: [15] }
  };
  
  let isValidType = false;
  let isValidLength = false;
  
  for (const [, config] of Object.entries(cardTypes)) {
    if (config.pattern.test(digits) && config.lengths.includes(digits.length)) {
      isValidType = true;
      isValidLength = true;
      break;
    }
  }
  
  if (!isValidType || !isValidLength) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}