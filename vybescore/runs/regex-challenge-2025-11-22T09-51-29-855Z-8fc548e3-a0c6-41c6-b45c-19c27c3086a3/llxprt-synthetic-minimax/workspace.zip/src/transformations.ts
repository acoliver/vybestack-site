/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences using .?! as delimiters
  // This regex captures the punctuation as part of the sentence delimiter
  const sentences = text.split(/(?<=[.!?])\s*/);
  
  const capitalizedSentences = sentences.map(sentence => {
    const trimmed = sentence.trim();
    if (trimmed.length === 0) {
      return sentence; // Preserve empty segments
    }
    
    // Capitalize first letter, handle unicode
    const firstChar = trimmed.charAt(0);
    const restOfSentence = trimmed.slice(1);
    
    // Use unicode-aware capitalization
    const capitalizedFirstChar = firstChar.toLocaleUpperCase();
    
    return sentence.replace(trimmed, capitalizedFirstChar + restOfSentence);
  });
  
  // Join sentences with single space
  return capitalizedSentences.join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http(s):// URLs
  const urlPattern = /https?:\/\/[^\s<>"]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation that is not part of the URL
    return url.replace(/[.,!?;:]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
const httpUrlPattern = new RegExp("(http:\\/\\/([^\\/\\s<>]+))([^\\s<>]*)", "gi");

  
  return text.replace(httpUrlPattern, (fullMatch, schemeDomain, domain, pathAndRest) => {
    // Always upgrade to https
    let newUrl = `https://${domain}`;
    
    // Check if path starts with /docs/
    if (pathAndRest.startsWith('/docs/')) {
      // Extract path and query string
      const [pathPart, queryPart] = pathAndRest.split('?', 2);
      
      // Dynamic hints that should skip host rewrite
      const dynamicHints = [
        'cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'
      ];
      
      // Check if path contains dynamic hints or query parameters
      const hasDynamicHints = dynamicHints.some(hint => 
        pathPart.toLowerCase().includes(hint.toLowerCase())
      ) || !!queryPart; // also skip if has query parameters
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.domain.com
        const newDomain = `docs.${domain}`;
        newUrl = `https://${newDomain}${pathAndRest}`;
      } else {
        // Keep original domain, just upgrade to https
        newUrl = `https://${domain}${pathAndRest}`;
      }
    } else {
      // Not a docs URL, just upgrade to https
      newUrl = `https://${domain}${pathAndRest}`;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}