const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Database initialization
const db = new sqlite3.Database('./forms.db', (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
        process.exit(1);
    } else {
        console.log('Connected to SQLite database');
    }
});

// Create tables
db.serialize(() => {
    // Create forms table
    db.run(`CREATE TABLE IF NOT EXISTS forms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`, (err) => {
        if (err) console.error('Error creating forms table:', err.message);
    });

    // Create fields table
    db.run(`CREATE TABLE IF NOT EXISTS fields (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        form_id INTEGER,
        field_name TEXT NOT NULL,
        field_type TEXT NOT NULL,
        label TEXT,
        required BOOLEAN DEFAULT 0,
        options TEXT,
        FOREIGN KEY (form_id) REFERENCES forms (id) ON DELETE CASCADE
    )`, (err) => {
        if (err) console.error('Error creating fields table:', err.message);
    });

    // Create submissions table
    db.run(`CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        form_id INTEGER,
        submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        ip_address TEXT,
        FOREIGN KEY (form_id) REFERENCES forms (id) ON DELETE CASCADE
    )`, (err) => {
        if (err) console.error('Error creating submissions table:', err.message);
    });

    // Create submission_values table
    db.run(`CREATE TABLE IF NOT EXISTS submission_values (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        submission_id INTEGER,
        field_id INTEGER,
        field_value TEXT,
        FOREIGN KEY (submission_id) REFERENCES submissions (id) ON DELETE CASCADE,
        FOREIGN KEY (field_id) REFERENCES fields (id) ON DELETE CASCADE
    )`, (err) => {
        if (err) console.error('Error creating submission_values table:', err.message);
    });
});

// Routes

// Serve index.html for routes and root
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/app', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/create', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/form/:id', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API Routes

// Get all forms
app.get('/api/forms', (req, res) => {
    db.all('SELECT * FROM forms ORDER BY created_at DESC', (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Get a specific form with its fields
app.get('/api/forms/:id', (req, res) => {
    const formId = req.params.id;
    
    // Get form details
    db.get('SELECT * FROM forms WHERE id = ?', [formId], (err, form) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        if (!form) {
            res.status(404).json({ error: 'Form not found' });
            return;
        }
        
        // Get form fields
        db.all('SELECT * FROM fields WHERE form_id = ? ORDER BY id', [formId], (err, fields) => {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            
            res.json({
                ...form,
                fields: fields || []
            });
        });
    });
});

// Create a new form
app.post('/api/forms', (req, res) => {
    const { name, description } = req.body;
    
    if (!name) {
        return res.status(400).json({ error: 'Form name is required' });
    }
    
    db.run('INSERT INTO forms (name, description) VALUES (?, ?)', [name, description], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        res.status(201).json({
            id: this.lastID,
            name,
            description
        });
    });
});

// Add a field to a form
app.post('/api/forms/:id/fields', (req, res) => {
    const formId = req.params.id;
    const { fieldName, fieldType, label, required, options } = req.body;
    
    if (!fieldName || !fieldType) {
        return res.status(400).json({ error: 'Field name and type are required' });
    }
    
    db.run(
        'INSERT INTO fields (form_id, field_name, field_type, label, required, options) VALUES (?, ?, ?, ?, ?, ?)',
        [formId, fieldName, fieldType, label, required ? 1 : 0, JSON.stringify(options || [])],
        function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            
            res.status(201).json({
                id: this.lastID,
                formId,
                fieldName,
                fieldType,
                label,
                required,
                options
            });
        }
    );
});

// Delete a form
app.delete('/api/forms/:id', (req, res) => {
    const formId = req.params.id;
    
    db.run('DELETE FROM forms WHERE id = ?', [formId], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        if (this.changes === 0) {
            res.status(404).json({ error: 'Form not found' });
            return;
        }
        
        res.json({ message: 'Form deleted successfully' });
    });
});

// Submit a form
app.post('/api/forms/:id/submit', (req, res) => {
    const formId = req.params.id;
    const formData = req.body;
    const ipAddress = req.ip || req.connection.remoteAddress;
    
    // Get form fields to validate
    db.all('SELECT * FROM fields WHERE form_id = ?', [formId], (err, fields) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        if (!fields || fields.length === 0) {
            return res.status(404).json({ error: 'Form not found or has no fields' });
        }
        
        // Validate required fields
        const missingRequired = fields.filter(field => {
            return field.required === 1 && (!formData[field.field_name] || formData[field.field_name].trim() === '');
        });
        
        if (missingRequired.length > 0) {
            return res.status(400).json({ 
                error: 'Required fields are missing',
                missingFields: missingRequired.map(f => f.field_name)
            });
        }
        
        // Start a transaction
        db.serialize(() => {
            db.run('BEGIN TRANSACTION');
            
            // Create submission record
            db.run(
                'INSERT INTO submissions (form_id, ip_address) VALUES (?, ?)',
                [formId, ipAddress],
                function(err) {
                    if (err) {
                        db.run('ROLLBACK');
                        return res.status(500).json({ error: err.message });
                    }
                    
                    const submissionId = this.lastID;
                    
                    // Insert form data
                    const insertPromises = fields.map(field => {
                        return new Promise((resolve, reject) => {
                            db.run(
                                'INSERT INTO submission_values (submission_id, field_id, field_value) VALUES (?, ?, ?)',
                                [submissionId, field.id, formData[field.field_name] || ''],
                                function(err) {
                                    if (err) reject(err);
                                    else resolve();
                                }
                            );
                        });
                    });
                    
                    Promise.all(insertPromises)
                        .then(() => {
                            db.run('COMMIT', (err) => {
                                if (err) {
                                    return res.status(500).json({ error: err.message });
                                }
                                res.status(201).json({
                                    message: 'Form submitted successfully',
                                    submissionId
                                });
                            });
                        })
                        .catch(err => {
                            db.run('ROLLBACK');
                            res.status(500).json({ error: err.message });
                        });
                }
            );
        });
    });
});

// Get submissions for a form
app.get('/api/forms/:id/submissions', (req, res) => {
    const formId = req.params.id;
    
    const query = `
        SELECT s.*, sv.field_value, f.field_name, f.label
        FROM submissions s
        JOIN submission_values sv ON s.id = sv.submission_id
        JOIN fields f ON sv.field_id = f.id
        WHERE s.form_id = ?
        ORDER BY s.submitted_at DESC
    `;
    
    db.all(query, [formId], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        // Group by submission
        const submissions = {};
        rows.forEach(row => {
            if (!submissions[row.id]) {
                submissions[row.id] = {
                    id: row.id,
                    submitted_at: row.submitted_at,
                    ip_address: row.ip_address,
                    data: {}
                };
            }
            submissions[row.id].data[row.field_name] = row.field_value;
        });
        
        res.json(Object.values(submissions));
    });
});

// Handle 404
app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Something went wrong!' });
});

// Graceful shutdown
const gracefulShutdown = (signal) => {
    console.log(`\nReceived ${signal}. Closing HTTP server and database connection...`);
    
    server.close(() => {
        console.log('HTTP server closed.');
        
        db.close((err) => {
            if (err) {
                console.error('Error closing database:', err.message);
            } else {
                console.log('Database connection closed.');
            }
            process.exit(0);
        });
    });
};

// Start server
const server = app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

// Handle shutdown signals
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

module.exports = app;