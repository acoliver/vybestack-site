// Data structures for form testing scenarios

export interface FormDataEntry {
  id: string
  name: string
  value: any
  type: string
  required: boolean
}

export interface FormScenario {
  id: string
  name: string
  description: string
  fields: FormDataEntry[]
  validationRules?: ValidationRule[]
}

export interface ValidationRule {
  field: string
  rule: string
  message: string
}

export interface TestResult {
  scenario: string
  status: 'pass' | 'fail'
  message: string
  duration: number
  errors?: string[]
}

export interface TestSuite {
  id: string
  name: string
  scenarios: FormScenario[]
  testResults?: TestResult[]
}

// Common form scenarios
export const COMMON_FORM_SCENARIOS: FormScenario[] = [
  // Simple contact form
  {
    id: 'simple-contact',
    name: 'Simple Contact Form',
    description: 'Basic contact form with name, email, and message fields',
    fields: [
      { id: 'name', name: 'name', value: 'John Doe', type: 'text', required: true },
      { id: 'email', name: 'email', value: 'john@example.com', type: 'email', required: true },
      { id: 'message', name: 'message', value: 'This is a test message', type: 'textarea', required: false }
    ],
    validationRules: [
      { field: 'name', rule: 'required|min:2', message: 'Name must be at least 2 characters' },
      { field: 'email', rule: 'required|email', message: 'Valid email required' }
    ]
  },
  // User registration
  {
    id: 'user-registration',
    name: 'User Registration',
    description: 'User registration form with password confirmation',
    fields: [
      { id: 'username', name: 'username', value: 'johndoe123', type: 'text', required: true },
      { id: 'email', name: 'email', value: 'john@example.com', type: 'email', required: true },
      { id: 'password', name: 'password', value: 'SecurePass123!', type: 'password', required: true },
      { id: 'confirmPassword', name: 'confirmPassword', value: 'SecurePass123!', type: 'password', required: true },
      { id: 'terms', name: 'terms', value: true, type: 'checkbox', required: false }
    ],
    validationRules: [
      { field: 'username', rule: 'required|min:4', message: 'Username must be at least 4 characters' },
      { field: 'email', rule: 'required|email', message: 'Valid email required' },
      { field: 'password', rule: 'required|min:8', message: 'Password must be at least 8 characters' },
      { field: 'confirmPassword', rule: 'matched_with:password', message: 'Passwords must match' }
    ]
  },
  // Product checkout
  {
    id: 'product-checkout',
    name: 'Product Checkout',
    description: 'Checkout form with shipping and billing information',
    fields: [
      { id: 'firstName', name: 'firstName', value: 'John', type: 'text', required: true },
      { id: 'lastName', name: 'lastName', value: 'Doe', type: 'text', required: true },
      { id: 'email', name: 'email', value: 'john@example.com', type: 'email', required: true },
      { id: 'phone', name: 'phone', value: '(555) 123-4567', type: 'tel', required: true },
      { id: 'shippingAddress', name: 'shippingAddress', value: '123 Main St, Anytown, XX 12345', type: 'text', required: true },
      { id: 'billingAddress', name: 'billingAddress', value: '', type: 'text', required: false },
      { id: 'sameAsShipping', name: 'sameAsShipping', value: true, type: 'checkbox', required: false },
      { id: 'cardNumber', name: 'cardNumber', value: '4111111111111111', type: 'text', required: true },
      { id: 'cardName', name: 'cardName', value: 'John Doe', type: 'text', required: true },
      { id: 'expiry', name: 'expiry', value: '12/25', type: 'text', required: true },
      { id: 'cvv', name: 'cvv', value: '123', type: 'text', required: true }
    ],
    validationRules: [
      { field: 'firstName', rule: 'required', message: 'First name is required' },
      { field: 'lastName', rule: 'required', message: 'Last name is required' },
      { field: 'email', rule: 'required|email', message: 'Valid email required' },
      { field: 'phone', rule: 'required|phone', message: 'Valid phone number required' },
      { field: 'shippingAddress', rule: 'required', message: 'Shipping address is required' },
      { field: 'cardNumber', rule: 'required|credit_card', message: 'Valid card number required' },
      { field: 'expiry', rule: 'required|expiry', message: 'Valid expiry date required' },
      { field: 'cvv', rule: 'required|cvv', message: 'Valid CVV required' }
    ]
  },
  // Survey form
  {
    id: 'survey-form',
    name: 'Survey Form',
    description: 'Survey with multiple choice and rating questions',
    fields: [
      { id: 'satisfaction', name: 'satisfaction', value: '5', type: 'radio', required: true },
      { id: 'improvements', name: 'improvements', value: ['quality', 'price'], type: 'checkbox', required: false },
      { id: 'wouldRecommend', name: 'wouldRecommend', value: 'yes', type: 'select', required: true },
      { id: 'comments', name: 'comments', value: 'Overall great experience', type: 'textarea', required: false }
    ],
    validationRules: [
      { field: 'satisfaction', rule: 'required', message: 'Please rate your satisfaction' },
      { field: 'wouldRecommend', rule: 'required', message: 'Please select if you would recommend us' }
    ]
  },
  // Job application
  {
    id: 'job-application',
    name: 'Job Application',
    description: 'Job application with file upload',
    fields: [
      { id: 'firstName', name: 'firstName', value: 'Jane', type: 'text', required: true },
      { id: 'lastName', name: 'lastName', value: 'Smith', type: 'text', required: true },
      { id: 'email', name: 'email', value: 'jane.smith@example.com', type: 'email', required: true },
      { id: 'phone', name: 'phone', value: '(555) 987-6543', type: 'tel', required: true },
      { id: 'position', name: 'position', value: 'developer', type: 'select', required: true },
      { id: 'experience', name: 'experience', value: '5', type: 'number', required: true },
      { id: 'resume', name: 'resume', value: 'resume.pdf', type: 'file', required: true },
      { id: 'coverLetter', name: 'coverLetter', value: 'cover-letter.pdf', type: 'file', required: false },
      { id: 'portfolio', name: 'portfolio', value: 'https://janesmith.dev', type: 'url', required: false },
      { id: 'availableDate', name: 'availableDate', value: '2025-06-01', type: 'date', required: true }
    ],
    validationRules: [
      { field: 'firstName', rule: 'required', message: 'First name is required' },
      { field: 'lastName', rule: 'required', message: 'Last name is required' },
      { field: 'email', rule: 'required|email', message: 'Valid email required' },
      { field: 'phone', rule: 'required|phone', message: 'Valid phone number required' },
      { field: 'position', rule: 'required', message: 'Position is required' },
      { field: 'experience', rule: 'required|min:0', message: 'Valid experience level required' },
      { field: 'resume', rule: 'required|file:pdf,doc,docx', message: 'Resume (PDF, DOC, DOCX) is required' },
      { field: 'availableDate', rule: 'required|date', message: 'Availability date is required' }
    ]
  }
]

export function getAllScenarios(): FormScenario[] {
  return COMMON_FORM_SCENARIOS
}

export function getScenarioDetails(scenarioId: string): FormScenario | undefined {
  return COMMON_FORM_SCENARIOS.find(scenario => scenario.id === scenarioId)
}