// Core validation types and interfaces
export interface ValidationRule {
  name: string;
  validate: (value: any, field: string, data: any) => ValidationResult;
  message?: string;
  priority?: number;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  warnings?: ValidationWarning[];
}

export interface ValidationError {
  field: string;
  message: string;
  rule: string;
  value?: any;
}

export interface ValidationWarning {
  field: string;
  message: string;
  rule: string;
  value?: any;
}

export interface FieldConfig {
  name: string;
  type: string;
  label?: string;
  required?: boolean;
  rules?: ValidationRule[];
  placeholder?: string;
  dependsOn?: string[];
  defaultValue?: any;
}

export interface FormConfig {
  fields: FieldConfig[];
  formId: string;
  validateOnInit?: boolean;
  validateOnBlur?: boolean;
  validateOnChange?: boolean;
  showInlineErrors?: boolean;
}

export interface ValidationContext {
  data: Record<string, any>;
  errors: ValidationError[];
  warnings: ValidationWarning[];
  touched: Record<string, boolean>;
  isSubmitting?: boolean;
}

export interface FieldValidator {
  id: string;
  validate: (value: any, config: FieldConfig, context: ValidationContext) => ValidationResult;
}

export type ValidationEventsHandler = {
  onValidationStart?: (context: ValidationContext) => void;
  onValidationSuccess?: (context: ValidationContext) => void;
  onValidationError?: (errors: ValidationError[], context: ValidationContext) => void;
  onFieldChange?: (field: string, value: any, context: ValidationContext) => void;
  onFormSubmit?: (data: Record<string, any>, context: ValidationContext) => void;
  onFieldBlur?: (field: string, value: any, context: ValidationContext) => void;
};