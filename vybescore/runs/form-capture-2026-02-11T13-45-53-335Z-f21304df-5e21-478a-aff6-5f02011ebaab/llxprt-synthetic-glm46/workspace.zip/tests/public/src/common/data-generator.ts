import { FieldConfig, FIELD_TYPES } from './fields-config';
import { ValidationRules } from './validation-rules';

/**
 * Common data generator utilities for testing
 */

/**
 * Generate random valid data based on field configuration
 * @param fields Array of field configurations
 * @returns Object with field values
 */
export function generateValidFormData(fields: FieldConfig[]): Record<string, any> {
  const data: Record<string, any> = {};

  fields.forEach(field => {
    switch (field.type) {
      case FIELD_TYPES.TEXT:
      case FIELD_TYPES.EMAIL:
      case FIELD_TYPES.PASSWORD:
      case FIELD_TYPES.SEARCH:
      case FIELD_TYPES.TEL:
      case FIELD_TYPES.URL:
        data[field.name] = generateTextForField(field);
        break;

      case FIELD_TYPES.NUMBER:
      case FIELD_TYPES.RANGE:
        data[field.name] = generateNumericForField(field);
        break;

      case FIELD_TYPES.DATE:
      case FIELD_TYPES.DATETIME:
      case FIELD_TYPES.DATETIME_LOCAL:
      case FIELD_TYPES.TIME:
      case FIELD_TYPES.MONTH:
      case FIELD_TYPES.WEEK:
        data[field.name] = generateDateForField(field);
        break;

      case FIELD_TYPES.CHECKBOX:
        data[field.name] = field.required ? true : Math.random() > 0.5;
        break;

      case FIELD_TYPES.RADIO:
        data[field.name] = field.options?.[0] || '';
        break;

      case FIELD_TYPES.SELECT:
      case FIELD_TYPES.SELECT_MULTIPLE:
        data[field.name] = field.options?.[0] || '';
        break;

      // HTML5 fields
      case FIELD_TYPES.COLOR:
        data[field.name] = '#' + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0');
        break;

      default:
        data[field.name] = '';
    }
  });

  return data;
}

/**
 * Generate random invalid data based on field configuration
 * @param fields Array of field configurations
 * @returns Object with invalid field values
 */
export function generateInvalidFormData(fields: FieldConfig[]): Record<string, any> {
  const data: Record<string, any> = {};

  fields.forEach(field => {
    // Skip fields that don't have validation to generate invalid data for
    if (!hasValidation(field)) {
      data[field.name] = generateValidFieldValue(field);
      return;
    }

    // Generate a failing value for at least one validation rule
    if (field.validation?.required && Math.random() > 0.7) {
      data[field.name] = '';
      return;
    }

    if (field.validation?.minLength && Math.random() > 0.7) {
      data[field.name] = 'x'.repeat(Math.max(1, (field.validation.minLength || 0) - 1));
      return;
    }

    if (field.validation?.maxLength && Math.random() > 0.7) {
      data[field.name] = 'x'.repeat((field.validation.maxLength || 0) + 1);
      return;
    }

    if (field.type === FIELD_TYPES.EMAIL && Math.random() > 0.7) {
      data[field.name] = 'invalid-email';
      return;
    }

    if (field.validation?.pattern && Math.random() > 0.7) {
      data[field.name] = 'invalid';
      return;
    }

    if (field.type === FIELD_TYPES.NUMBER || field.type === FIELD_TYPES.RANGE) {
      if (field.validation?.min && Math.random() > 0.7) {
        data[field.name] = (field.validation.min || 0) - 1;
        return;
      }

      if (field.validation?.max && Math.random() > 0.7) {
        data[field.name] = (field.validation.max || 0) + 1;
        return;
      }
    }

    // Default to valid value if no invalid value was generated
    data[field.name] = generateValidFieldValue(field);
  });

  return data;
}

/**
 * Generate a field value that passes validation
 */
function generateValidFieldValue(field: FieldConfig): any {
  switch (field.type) {
    case FIELD_TYPES.TEXT:
    case FIELD_TYPES.EMAIL:
    case FIELD_TYPES.PASSWORD:
    case FIELD_TYPES.SEARCH:
    case FIELD_TYPES.TEL:
    case FIELD_TYPES.URL:
      return generateTextForField(field);

    case FIELD_TYPES.NUMBER:
    case FIELD_TYPES.RANGE:
      return generateNumericForField(field);

    case FIELD_TYPES.DATE:
    case FIELD_TYPES.DATETIME:
    case FIELD_TYPES.DATETIME_LOCAL:
    case FIELD_TYPES.TIME:
    case FIELD_TYPES.MONTH:
    case FIELD_TYPES.WEEK:
      return generateDateForField(field);

    case FIELD_TYPES.CHECKBOX:
      return field.required ? true : Math.random() > 0.5;

    case FIELD_TYPES.RADIO:
    case FIELD_TYPES.SELECT:
    case FIELD_TYPES.SELECT_MULTIPLE:
      return field.options?.[0] || '';

    case FIELD_TYPES.COLOR:
      return '#' + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0');

    default:
      return '';
  }
}

/**
 * Generate a text value for a field that respects validation
 */
function generateTextForField(field: FieldConfig): string {
  const minLength = field.validation?.minLength || 2;
  const maxLength = field.validation?.maxLength || 50;
  const targetLength = Math.max(minLength, Math.min(randomBetween(minLength, maxLength), maxLength));

  let text = '';
  
  // Generate specific patterns based on field type and validation
  if (field.type === FIELD_TYPES.EMAIL) {
    text = generateValidEmail();
  } else if (field.validation?.pattern) {
    // Try to generate text matching the pattern
    const patterns = [
      { regex: /^\\d{5}$/, generator: () => String(Math.floor(Math.random() * 90000) + 10000) }, // ZIP code
      { regex: /^\\d{3}-\\d{2}-\\d{4}$/, generator: () => generateSSN() }, // SSN
      { regex: /^(\\+?[0-9]{1,3}[-.\\s]?)?[0-9]{3}[-.\\s]?[0-9]{3}[-.\\s]?[0-9]{4}$/, generator: () => generatePhoneNumber() }, // Phone
      { regex: /^\d{4}$/, generator: () => String(Math.floor(Math.random() * 9000) + 1000) }, // 4-digit code
    ];

    const matchedPattern = patterns.find(p => field.validation?.pattern?.match(p.regex));
    text = matchedPattern ? matchedPattern.generator() : generateRandomText(10);
  } else {
    text = generateRandomText(targetLength);
  }

  // Ensure it meets length requirements
  if (text.length < minLength) {
    text = text.padEnd(minLength, 'x');
  } else if (text.length > maxLength) {
    text = text.substring(0, maxLength);
  }

  return text;
}

/**
 * Generate a numeric value for a field that respects validation
 */
function generateNumericForField(field: FieldConfig): number {
  const min = field.validation?.min || 0;
  const max = field.validation?.max || 100;
  const step = field.validation?.step || 1;

  // Generate a value that respects min, max, and step
  const validMin = Math.ceil(min / step) * step;
  const validMax = Math.floor(max / step) * step;
  
  return validMin + (Math.floor(Math.random() * ((validMax - validMin) / step)) * step);
}

/**
 * Generate a date value for a field that respects validation
 */
function generateDateForField(field: FieldConfig): string {
  const now = new Date();
  
  switch (field.type) {
    case FIELD_TYPES.DATE:
      // Generate YYYY-MM-DD
      const year = 2022 + Math.floor(Math.random() * 4);
      const month = Math.floor(Math.random() * 12) + 1;
      const day = Math.floor(Math.random() * 28) + 1;
      return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

    case FIELD_TYPES.TIME:
      // Generate HH:MM
      const hours = Math.floor(Math.random() * 24);
      const minutes = Math.floor(Math.random() * 60);
      return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;

    case FIELD_TYPES.DATETIME:
    case FIELD_TYPES.DATETIME_LOCAL:
      const dateTime = new Date(now.getTime() + Math.random() * 365 * 24 * 60 * 60 * 1000);
      return dateTime.toISOString().slice(0, 16);

    case FIELD_TYPES.MONTH:
      const monthYear = new Date(now.getTime() + Math.random() * 365 * 24 * 60 * 60 * 1000);
      return `${monthYear.getFullYear()}-${String(monthYear.getMonth() + 1).padStart(2, '0')}`;

    case FIELD_TYPES.WEEK:
      const weekDate = new Date(now.getTime() + Math.random() * 365 * 24 * 60 * 60 * 1000);
      const year = weekDate.getFullYear();
      const week = Math.floor(Math.random() * 52) + 1;
      return `${year}-W${String(week).padStart(2, '0')}`;

    default:
      return now.toISOString().split('T')[0];
  }
}

/**
 * Helper function to check if a field has validation rules
 */
function hasValidation(field: FieldConfig): boolean {
  if (!field.validation) return false;
  
  if (field.validation.required) return true;
  if (field.validation.minLength) return true;
  if (field.validation.maxLength) return true;
  if (field.validation.min !== undefined) return true;
  if (field.validation.max !== undefined) return true;
  if (field.validation.pattern) return true;
  
  return false;
}

/**
 * Helper function to generate a valid email
 */
function generateValidEmail(): string {
  const domains = ['example.com', 'test.org', 'demo.net', 'sample.io'];
  const username = generateRandomText(8);
  const domain = domains[Math.floor(Math.random() * domains.length)];
  return `${username}@${domain}`;
}

/**
 * Helper function to generate a valid SSN
 */
function generateSSN(): string {
  return `${randomBetween(100, 999)}-${randomBetween(10, 99)}-${randomBetween(1000, 9999)}`;
}

/**
 * Helper function to generate a valid phone number
 */
function generatePhoneNumber(): string {
  return `${randomBetween(100, 999)}-${randomBetween(100, 999)}-${randomBetween(1000, 9999)}`;
}

/**
 * Helper function to generate random text
 */
function generateRandomText(length: number): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * Helper function to generate a random integer between min and max (inclusive)
 */
function randomBetween(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}