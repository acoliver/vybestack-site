import { ValidationRule } from "./validation-types";

/**
 * Built-in form validation rules
 */
export constValidationRules = {
  /**
   * Validates that a field is not empty
   */
  required: (message?: string): ValidationRule => ({
    isValid: (value: string) => {
      if (typeof value !== 'string') return false;
      return value.trim().length > 0;
    },
    message: message || 'This field is required'
  }),

  /**
   * Validates minimum length
   */
  minLength: (min: number, message?: string): ValidationRule => ({
    isValid: (value: string) => {
      if (typeof value !== 'string') return false;
      return value.length >= min;
    },
    message: message || `Minimum length is ${min} characters`
  }),

  /**
   * Validates maximum length
   */
  maxLength: (max: number, message?: string): ValidationRule => ({
    isValid: (value: string) => {
      if (typeof value !== 'string') return false;
      return value.length <= max;
    },
    message: message || `Maximum length is ${max} characters`
  }),

  /**
   * Validates numeric input
   */
  numeric: (message?: string): ValidationRule => ({
    isValid: (value: string) => {
      if (typeof value !== 'string') return false;
      return /^[0-9]+$/.test(value);
    },
    message: message || 'Please enter numbers only'
  }),

  /**
   * Validates email format
   */
  email: (message?: string): ValidationRule => ({
    isValid: (value: string) => {
      if (typeof value !== 'string') return false;
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(value);
    },
    message: message || 'Please enter a valid email address'
  }),

  /**
   * Validates phone number format
   */
  phone: (message?: string): ValidationRule => ({
    isValid: (value: string) => {
      if (typeof value !== 'string') return false;
      const phoneRegex = /^\+?[0-9]{10,}$/;
      return phoneRegex.test(value.replace(/[\s\-\(\)]/g, ''));
    },
    message: message || 'Please enter a valid phone number'
  }),

  /**
   * Validates password strength
   */
  strongPassword: (message?: string): ValidationRule => ({
    isValid: (value: string) => {
      if (typeof value !== 'string') return false;
      // At least 8 characters, include uppercase, lowercase, number and special character
      const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
      return passwordRegex.test(value);
    },
    message: message || 'Password must be at least 8 characters with uppercase, lowercase, number and special character'
  }),

  /**
   * Custom regular expression validation
   */
  pattern: (pattern: RegExp, message?: string): ValidationRule => ({
    isValid: (value: string) => {
      if (typeof value !== 'string') return false;
      return pattern.test(value);
    },
    message: message || 'Please match the required format'
  }),

  /**
   * Validates that value matches another field
   */
  matches: (otherFieldName: string, getFieldValue: (fieldId: string) => string, message?: string): ValidationRule => ({
    isValid: (value: string) => {
      if (typeof value !== 'string') return false;
      const otherValue = getFieldValue(otherFieldName);
      return value === otherValue;
    },
    message: message || `Must match ${otherFieldName}`
  }),

  /**
   * Validates using a custom function
   */
  custom: (validator: (value: string) => boolean, message: string): ValidationRule => ({
    isValid: validator,
    message
  })
} as const;