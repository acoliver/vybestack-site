/**
 * DOM Utilities
 * Helper functions for DOM manipulation and event handling
 */

/**
 * Finds an element by various selector strategies
 */
export function elementFinder(selector: string, context?: Document | Element): Element | null {
  const root = context || document;
  return root.querySelector(selector);
}

/**
 * Gets element value with type handling
 */
export function getElementValue(element: Element): string {
  if (isInputElement(element)) {
    return element.value;
  }
  if (isTextAreaElement(element)) {
    return element.value;
  }
  if (isSelectElement(element)) {
    return element.value;
  }
  return element.getAttribute('value') || '';
}

/**
 * Sets element value with validation
 */
export function setElementValue(element: Element, value: string): void {
  if (isInputElement(element)) {
    element.value = value;
    dispatchInputEvent(element);
  } else if (isTextAreaElement(element)) {
    element.value = value;
    dispatchInputEvent(element);
  } else if (isSelectElement(element)) {
    element.value = value;
    dispatchChangeEvent(element);
  } else {
    element.setAttribute('value', value);
  }
}

/**
 * Checks if two elements are equal
 */
export function elementsEqual(el1: Element, el2: Element): boolean {
  return el1 === el2;
}

/**
 * Gets all matching elements
 */
export function elementFindAll(selector: string, context?: Document | Element): Element[] {
  const root = context || document;
  return Array.from(root.querySelectorAll(selector));
}

/**
 * Waits for an element to appear
 */
export function waitForElement(selector: string, timeout = 5000): Promise<Element | null> {
  return new Promise((resolve) => {
    const element = elementFinder(selector);
    if (element) {
      resolve(element);
      return;
    }

    const observer = new MutationObserver(() => {
      const element = elementFinder(selector);
      if (element) {
        observer.disconnect();
        resolve(element);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });

    setTimeout(() => {
      observer.disconnect();
      resolve(null);
    }, timeout);
  });
}

/**
 * Simulates user typing with realistic delays
 */
export function simulateTyping(element: Element, text: string, delay = 50): Promise<void> {
  return new Promise((resolve) => {
    if (!isInputElement(element) && !isTextAreaElement(element)) {
      resolve();
      return;
    }

    let index = 0;
    const interval = setInterval(() => {
      if (index < text.length) {
        element.value += text[index];
        dispatchInputEvent(element);
        index++;
      } else {
        clearInterval(interval);
        resolve();
      }
    }, delay);
  });
}

/**
 * Dispatches an input event on an element
 */
function dispatchInputEvent(element: Element): void {
  const event = new Event('input', { bubbles: true });
  element.dispatchEvent(event);
}

/**
 * Dispatches a change event on an element
 */
function dispatchChangeEvent(element: Element): void {
  const event = new Event('change', { bubbles: true });
  element.dispatchEvent(event);
}

/**
 * Type guards for form elements
 */
export function isInputElement(element: Element): element is HTMLInputElement {
  return element.tagName === 'INPUT';
}

export function isTextAreaElement(element: Element): element is HTMLTextAreaElement {
  return element.tagName === 'TEXTAREA';
}

export function isSelectElement(element: Element): element is HTMLSelectElement {
  return element.tagName === 'SELECT';
}

export function isButtonElement(element: Element): element is HTMLButtonElement {
  return element.tagName === 'BUTTON';
}

/**
 * Gets element type for input elements
 */
export function getElementType(element: Element): string {
  if (isInputElement(element)) {
    return element.type;
  }
  return element.tagName.toLowerCase();
}

/**
 * Checks if element is visible
 */
export function isElementVisible(element: Element): boolean {
  const style = window.getComputedStyle(element);
  return style.display !== 'none' && style.visibility !== 'hidden';
}

/**
 * Scrolls element into view
 */
export function scrollIntoView(element: Element, options?: ScrollIntoViewOptions): void {
  element.scrollIntoView(options);
}

/**
 * Creates a temporary element for testing
 */
export function createTemporaryElement(tagName: string, attributes: Record<string, string>): Element {
  const element = document.createElement(tagName);
  Object.entries(attributes).forEach(([key, value]) => {
    element.setAttribute(key, value);
  });
  return element;
}

/**
 * Removes temporary elements from the DOM
 */
export function removeTemporaryElements(selector = '[data-temp="true"]'): void {
  const elements = elementFindAll(selector);
  elements.forEach(element => {
    if (element.parentNode) {
      element.parentNode.removeChild(element);
    }
  });
}