import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, shutdown } from '../../src/server.js';
import { initializeDatabase } from '../../src/database.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Initialize database for tests
  await initializeDatabase();
}, 10000);

afterAll(() => {
  shutdown();
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    try {
      fs.unlinkSync(dbPath);
    } catch (e) {
      // Ignore
    }
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);

    const $ = cheerio.load(response.text);

    // Check for all required fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check labels are associated with inputs
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="lastName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
    expect($('label[for="phone"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    await initializeDatabase();

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid email', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Avenue',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'invalid-email', // Invalid email
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app).post('/submit').send(formData);

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toMatch(/email/i);
  });

  it('shows validation errors for empty required fields', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: '',
      email: 'test@example.com',
    });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toMatch(/first name/i);
    expect(errorText).toMatch(/last name/i);
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');

    expect(response.status).toBe(200);
    expect(response.text).toMatch(/thank you/i);
    expect(response.text).toMatch(/stranger on the internet/i);
  });
});
