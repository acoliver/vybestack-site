export interface FormInput {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  data: FormInput;
}

function isNotEmpty(value: string | undefined): boolean {
  return value !== undefined && value.trim().length > 0;
}

function isValidEmail(email: string): boolean {
  // Simple email regex - checks for basic pattern
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and optional leading +
  // eslint-disable-next-line no-useless-escape
  const phoneRegex = /^[+]?[0-9\s()\-]+$/;
  return phoneRegex.test(phone.trim()) && phone.trim().length > 0;
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces and hyphens
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode.trim()) && postalCode.trim().length > 0;
}

export function validateForm(input: FormInput): ValidationResult {
  const errors: string[] = [];
  const cleaned: FormInput = {};

  // Validate required fields
  if (!isNotEmpty(input.firstName)) {
    errors.push('First name is required');
  } else if (input.firstName !== undefined) {
    cleaned.firstName = input.firstName.trim();
  }

  if (!isNotEmpty(input.lastName)) {
    errors.push('Last name is required');
  } else if (input.lastName !== undefined) {
    cleaned.lastName = input.lastName.trim();
  }

  if (!isNotEmpty(input.streetAddress)) {
    errors.push('Street address is required');
  } else if (input.streetAddress !== undefined) {
    cleaned.streetAddress = input.streetAddress.trim();
  }

  if (!isNotEmpty(input.city)) {
    errors.push('City is required');
  } else if (input.city !== undefined) {
    cleaned.city = input.city.trim();
  }

  if (!isNotEmpty(input.stateProvince)) {
    errors.push('State / Province / Region is required');
  } else if (input.stateProvince !== undefined) {
    cleaned.stateProvince = input.stateProvince.trim();
  }

  if (!isNotEmpty(input.postalCode)) {
    errors.push('Postal / Zip code is required');
  } else if (input.postalCode === undefined || !isValidPostalCode(input.postalCode)) {
    errors.push('Postal code must contain only letters, numbers, spaces, and hyphens');
  } else if (input.postalCode !== undefined) {
    cleaned.postalCode = input.postalCode.trim();
  }

  if (!isNotEmpty(input.country)) {
    errors.push('Country is required');
  } else if (input.country !== undefined) {
    cleaned.country = input.country.trim();
  }

  if (!isNotEmpty(input.email)) {
    errors.push('Email is required');
  } else if (input.email === undefined || !isValidEmail(input.email)) {
    errors.push('Please enter a valid email address');
  } else if (input.email !== undefined) {
    cleaned.email = input.email.trim();
  }

  if (!isNotEmpty(input.phone)) {
    errors.push('Phone number is required');
  } else if (input.phone === undefined || !isValidPhone(input.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and optional leading +');
  } else if (input.phone !== undefined) {
    cleaned.phone = input.phone.trim();
  }

  return {
    valid: errors.length === 0,
    errors,
    data: cleaned,
  };
}
