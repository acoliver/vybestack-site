import express, { Request, Response, Express } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, insertSubmission, closeDatabase } from './database.js';
import { validateForm, FormInput } from './validation.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

const app: Express = express();
let server: ReturnType<Express['listen']> | null = null;
let isShuttingDown = false;

// Middleware
app.use(express.static(path.join(__dirname, '../public')));
app.use(express.urlencoded({ extended: true }));

// Set EJS views directory and engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form.ejs', {
    errors: [],
    formData: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormInput = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    res.status(400).render('form.ejs', {
      errors: validation.errors,
      formData: req.body,
    });
    return;
  }

  // Insert into database
  insertSubmission(validation.data as Required<FormInput>);

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you.ejs');
});

// Graceful shutdown
function shutdown(): void {
  if (isShuttingDown) {
    return;
  }

  isShuttingDown = true;

  if (server) {
    server.close(() => {
      closeDatabase();
    });
  } else {
    closeDatabase();
  }
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start(): Promise<void> {
  try {
    await initializeDatabase();

    server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    throw error;
  }
}

// Export for testing
export { app, start, shutdown };

// Only start if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  start();
}
