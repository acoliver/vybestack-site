import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app } from '../../src/server.js';
import { initializeDatabase, closeDatabase } from '../../src/db.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Initialize the database (without starting the server)
  await initializeDatabase();
});

afterAll(async () => {
  // Close the database
  closeDatabase();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all form fields
    expect($('input[name="first_name"]').length).toBe(1);
    expect($('input[name="last_name"]').length).toBe(1);
    expect($('input[name="street_address"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="state_province"]').length).toBe(1);
    expect($('input[name="postal_code"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check that labels are properly associated
    $('label').each((_, label) => {
      const labelFor = $(label).attr('for');
      if (labelFor) {
        expect($(`#${labelFor}`).length).toBeGreaterThan(0);
      }
    });
  });

  it('persists submission and redirects', async () => {
    // Clean up database if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        first_name: 'John',
        last_name: 'Doe',
        street_address: '123 Main St',
        city: 'London',
        state_province: 'England',
        postal_code: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john.doe@example.com',
        phone: '+44 20 7946 0958',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid input', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        first_name: '',
        last_name: '',
        street_address: '',
        city: '',
        state_province: '',
        postal_code: '',
        country: '',
        email: 'invalid-email',
        phone: '',
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    // Check that error messages are displayed
    expect($('.error-summary').length).toBe(1);
    expect($('.error-list').length).toBe(1);
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('.thankyou-card').length).toBe(1);
    expect($('body').text()).toContain('stranger on the internet');
  });
});
