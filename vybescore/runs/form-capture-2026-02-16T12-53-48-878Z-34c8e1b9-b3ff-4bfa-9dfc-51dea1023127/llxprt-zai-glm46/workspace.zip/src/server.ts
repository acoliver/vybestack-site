import express, { Request, Response } from 'express';
import path from 'node:path';
import { initializeDatabase, insertSubmission, closeDatabase, type Submission } from './db.js';
import { validateForm, type FormInput } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'views'));
app.use(express.static(path.resolve('public')));
app.use(express.urlencoded({ extended: true }));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form.ejs', {
    data: {},
    errors: []
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormInput = {
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    street_address: req.body.street_address,
    city: req.body.city,
    state_province: req.body.state_province,
    postal_code: req.body.postal_code,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    // Validation failed - re-render form with errors
    return res.status(400).render('form.ejs', {
      data: formData,
      errors
    });
  }

  // Validation succeeded - save to database
  const submission: Submission = {
    first_name: formData.first_name!,
    last_name: formData.last_name!,
    street_address: formData.street_address!,
    city: formData.city!,
    state_province: formData.state_province!,
    postal_code: formData.postal_code!,
    country: formData.country!,
    email: formData.email!,
    phone: formData.phone!,
  };

  insertSubmission(submission);

  // Redirect to thank-you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you.ejs');
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal Server Error');
});

// Graceful shutdown
let server: ReturnType<typeof app.listen> | null = null;

export async function startServer(): Promise<void> {
  await initializeDatabase();
  
  server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  // Handle SIGTERM for graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully...');
    shutdown();
  });

  process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully...');
    shutdown();
  });
}

function shutdown(): void {
  if (server) {
    server.close(() => {
      console.log('Server closed');
      closeDatabase();
      process.exit(0);
    });
  } else {
    closeDatabase();
    process.exit(0);
  }
}

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { app };
