export interface ValidationError {
  field: string;
  message: string;
}

export interface FormInput {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export function validateForm(input: FormInput): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  if (!input.first_name?.trim()) {
    errors.push({ field: 'first_name', message: 'First name is required' });
  }

  if (!input.last_name?.trim()) {
    errors.push({ field: 'last_name', message: 'Last name is required' });
  }

  if (!input.street_address?.trim()) {
    errors.push({ field: 'street_address', message: 'Street address is required' });
  }

  if (!input.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!input.state_province?.trim()) {
    errors.push({ field: 'state_province', message: 'State/Province/Region is required' });
  }

  if (!input.postal_code?.trim()) {
    errors.push({ field: 'postal_code', message: 'Postal/Zip code is required' });
  }

  if (!input.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  // Email validation (simple regex)
  if (!input.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(input.email.trim())) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }
  }

  // Phone validation (digits, spaces, parentheses, dashes, and leading +)
  if (!input.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else {
    const phoneRegex = /^[+]?[\d\s()/-]+$/;
    if (!phoneRegex.test(input.phone.trim())) {
      errors.push({
        field: 'phone',
        message: 'Phone number may contain digits, spaces, parentheses, dashes, and a leading +'
      });
    }
  }

  // Postal code validation (alphanumeric)
  if (input.postal_code?.trim()) {
    const postalCodeRegex = /^[\dA-Za-z\s-]+$/;
    if (!postalCodeRegex.test(input.postal_code.trim())) {
      errors.push({
        field: 'postal_code',
        message: 'Postal code may contain letters, digits, spaces, and dashes'
      });
    }
  }

  return errors;
}
