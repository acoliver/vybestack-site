/**
 * Format amount as currency with exactly two decimal places.
 * No thousands separators as per requirements.
 */
export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Validate report data structure and content.
 */
export function validateReportData(data: unknown): { valid: boolean; error?: string } {
  if (typeof data !== 'object' || data === null) {
    return { valid: false, error: 'Invalid JSON: expected object' };
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    return { valid: false, error: 'Missing or invalid title (expected string)' };
  }
  
  if (typeof obj.summary !== 'string') {
    return { valid: false, error: 'Missing or invalid summary (expected string)' };
  }
  
  if (!Array.isArray(obj.entries)) {
    return { valid: false, error: 'Missing or invalid entries (expected array)' };
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      return { valid: false, error: `Invalid entry at index ${i}: expected object` };
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      return { valid: false, error: `Invalid entry at index ${i}: missing or invalid label` };
    }
    
    if (typeof entryObj.amount !== 'number') {
      return { valid: false, error: `Invalid entry at index ${i}: missing or invalid amount` };
    }
  }
  
  return { valid: true };
}
