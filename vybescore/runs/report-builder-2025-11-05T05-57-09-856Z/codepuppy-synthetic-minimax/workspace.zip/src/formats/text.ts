import type { ReportData, RenderOptions, ReportFormatter } from './types.js';
import { formatAmount } from './utils.js';

export function renderText(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries heading
  lines.push('Entries:');
  
  // Entries
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }
  
  // Total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
}

export const textFormatter: ReportFormatter = {
  render: renderText,
};
