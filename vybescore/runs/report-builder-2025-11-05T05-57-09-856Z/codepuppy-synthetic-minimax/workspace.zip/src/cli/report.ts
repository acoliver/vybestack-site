#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions, ReportFormatter } from '../formats/types.js';
import { validateReportData } from '../formats/utils.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface CliOptions {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  const format = args[formatIndex + 1];
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function getFormatter(format: string): ReportFormatter {
  const formatters: Record<string, ReportFormatter> = {
    markdown: markdownFormatter,
    text: textFormatter,
  };
  
  const formatter = formatters[format];
  if (!formatter) {
    console.error(`Error: Unsupported format "${format}". Supported formats: ${Object.keys(formatters).join(', ')}`);
    process.exit(1);
  }
  
  return formatter;
}

function readJsonFile(filePath: string): unknown {
  try {
    const content = readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: File not found: ${filePath}`);
    } else if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file: ${filePath}`);
    } else {
      console.error(`Error: Failed to read file: ${filePath} - ${(error as Error).message}`);
    }
    process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  try {
    if (outputPath) {
      writeFileSync(outputPath, content, 'utf-8');
      console.log(`Report written to: ${outputPath}`);
    } else {
      console.log(content);
    }
  } catch (error) {
    console.error(`Error: Failed to write output: ${(error as Error).message}`);
    process.exit(1);
  }
}

function main(): void {
  const options = parseArgs();
  
  const rawData = readJsonFile(options.dataFile);
  
  const validation = validateReportData(rawData);
  if (!validation.valid) {
    console.error(`Error: Invalid report data - ${validation.error}`);
    process.exit(1);
  }
  
  const reportData = rawData as ReportData;
  const formatter = getFormatter(options.format);
  
  const renderOptions: RenderOptions = {
    includeTotals: options.includeTotals,
  };
  
  const reportContent = formatter.render(reportData, renderOptions);
  writeOutput(reportContent, options.outputPath);
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}