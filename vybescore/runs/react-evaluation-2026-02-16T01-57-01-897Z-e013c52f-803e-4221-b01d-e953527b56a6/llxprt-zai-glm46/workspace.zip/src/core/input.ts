/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observers.add(observer)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Notify all observers and collect their observers
    const toNotify = Array.from(s.observers)
    const notified = new Set<ObserverR>()
    
    while (toNotify.length > 0) {
      const observer = toNotify.shift()!
      if (notified.has(observer)) continue
      notified.add(observer)
      
      updateObserver(observer as Observer<unknown>)
      
      // Add this observer's observers to the queue
      const observerWithObservers = observer as Observer<unknown> & { observers: Set<ObserverR> }
      if (observerWithObservers.observers) {
        observerWithObservers.observers.forEach((obs: ObserverR) => {
          if (!notified.has(obs)) {
            toNotify.push(obs)
          }
        })
      }
    }
    
    return s.value
  }

  return [read, write]
}
