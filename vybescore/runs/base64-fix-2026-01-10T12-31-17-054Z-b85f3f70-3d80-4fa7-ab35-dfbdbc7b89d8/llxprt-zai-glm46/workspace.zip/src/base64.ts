const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const PADDING_REGEX = /^=+$/;
const ERROR_MESSAGE = 'Invalid Base64 input';

/**
 * Check if a string is valid Base64.
 * Uses the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with optional padding (=).
 */
function isValidBase64(input: string): boolean {
  // Base64 strings must have length divisible by 4 (when padded)
  // or can be unpadded but must still follow proper length constraints
  const normalized = input.trim();
  if (normalized.length === 0) {
    return false;
  }

  // Check for valid Base64 characters
  if (!VALID_BASE64_REGEX.test(normalized)) {
    return false;
  }

  // Check padding is only at the end
  const paddingIndex = normalized.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only be at the end
    const padding = normalized.slice(paddingIndex);
    if (!PADDING_REGEX.test(padding)) {
      return false;
    }
    // Only 1 or 2 padding characters are valid
    if (padding.length > 2) {
      return false;
    }
    // Total length must be multiple of 4 when padding is present
    if (normalized.length % 4 !== 0) {
      return false;
    }
  }

  return true;
}

/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding (=).
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  const normalized = input.trim();

  if (!isValidBase64(normalized)) {
    throw new Error(ERROR_MESSAGE);
  }

  try {
    const buffer = Buffer.from(normalized, 'base64');
    const decoded = buffer.toString('utf8');

    // Check for invalid UTF-8 sequences that might indicate corrupt data
    // (Buffer.from with 'base64' is lenient, so we validate the result)
    if (normalized.length > 0 && buffer.length === 0) {
      throw new Error(ERROR_MESSAGE);
    }

    return decoded;
  } catch (error) {
    throw new Error(ERROR_MESSAGE);
  }
}
