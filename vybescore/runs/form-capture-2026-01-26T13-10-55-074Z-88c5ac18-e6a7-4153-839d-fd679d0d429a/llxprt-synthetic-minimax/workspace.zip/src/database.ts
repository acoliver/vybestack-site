import initSqlJs from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';
import type { Database as SqlJsDatabase } from 'sql.js';
import type { SqlJsStatic } from 'sql.js';

export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: SqlJsDatabase | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;

  constructor(dbPath: string = 'data/submissions.sqlite') {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    // Initialize sql.js
    this.sqlJs = await initSqlJs({
      locateFile: (file: string) => {
        return require.resolve(`sql.js/dist/${file}`);
      }
    });

    if (!this.sqlJs) throw new Error('Failed to initialize sql.js');

    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const dbFile = fs.readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(dbFile);
    } else {
      this.db = new this.sqlJs.Database();
    }

    // Create schema if needed
    await this.createSchema();
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    try {
      // Use process.cwd() to resolve paths relative to project root
      const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      const schemaSql = fs.readFileSync(schemaPath, 'utf8');
      this.db.exec(schemaSql);
    } catch (error) {
      console.error('Error creating schema:', error);
      throw error;
    }
  }

  async saveSubmission(submission: FormSubmission): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_zip_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalZipCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    const result = stmt.getAsObject();
    stmt.free();

    // Persist to disk
    await this.persistToDisk();

    return result['lastInsertRowid'] as number;
  }

  private async persistToDisk(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const binaryData = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(binaryData));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  async onShutdown(): Promise<void> {
    await this.close();
  }
}

export default DatabaseManager;