import express, { Request, Response, NextFunction } from 'express';
import * as path from 'path';
import DatabaseManager, { FormSubmission } from './database';

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// Validation interfaces
interface ValidationErrors {
  [field: string]: string;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Remove common formatting characters
  const cleanPhone = phone.replace(/[\s\-+()@]/g, '');
  return cleanPhone.length >= 7 && /^\+?[\d\s\-+()]+$/.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric, spaces, hyphens
  const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
  return postalRegex.test(postalCode);
}

function validateForm(data: FormSubmission): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName.trim()) errors.firstName = 'First name is required';
  if (!data.lastName.trim()) errors.lastName = 'Last name is required';
  if (!data.streetAddress.trim()) errors.streetAddress = 'Street address is required';
  if (!data.city.trim()) errors.city = 'City is required';
  if (!data.stateProvinceRegion.trim()) errors.stateProvinceRegion = 'State/Province/Region is required';
  if (!data.postalZipCode.trim()) errors.postalZipCode = 'Postal/ZIP code is required';
  if (!data.country.trim()) errors.country = 'Country is required';
  if (!data.email.trim()) errors.email = 'Email is required';
  if (!data.phone.trim()) errors.phone = 'Phone number is required';

  // Field-specific validation
  if (data.email.trim() && !validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (data.phone.trim() && !validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  if (data.postalZipCode.trim() && !validatePostalCode(data.postalZipCode)) {
    errors.postalZipCode = 'Please enter a valid postal code';
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    data: { 
      errors: {},
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvinceRegion: '',
      postalZipCode: '',
      country: '',
      email: '',
      phone: ''
    } 
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormSubmission = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalZipCode: req.body.postalZipCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    // Validate form data
    const errors = validateForm(formData);

    if (Object.keys(errors).length > 0) {
      // Return form with errors
      res.status(400).render('form', { 
        data: { ...formData, errors }
      });
      return;
    }

    // Save to database
    const dbManager = new DatabaseManager();
    await dbManager.initialize();
    await dbManager.saveSubmission(formData);
    await dbManager.close();

    // Redirect to thank you page with form data
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName || 'friend';
  res.render('thank-you', { firstName });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

// Database manager for graceful shutdown
const dbManager = new DatabaseManager();

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await dbManager.onShutdown();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await dbManager.onShutdown();
  process.exit(0);
});

// Start server
async function startServer() {
  try {
    await dbManager.initialize();
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
