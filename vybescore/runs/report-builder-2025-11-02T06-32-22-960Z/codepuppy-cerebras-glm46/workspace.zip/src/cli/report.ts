#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { formatters } from '../formatters/index.js';
import type { ReportData, ReportOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: CliArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };
  
  // Parse positional argument (data file)
  const nonFlagArgs = args.filter(arg => !arg.startsWith('--'));
  if (nonFlagArgs.length === 0) {
    console.error('Error: Missing data file argument');
    process.exit(1);
  }
  result.dataFile = nonFlagArgs[0];
  
  // Parse flags
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const nextArg = args[i + 1];
      if (!nextArg || nextArg.startsWith('--')) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      result.format = nextArg;
      i++; // Skip next arg since we consumed it
    } else if (arg === '--output') {
      const nextArg = args[i + 1];
      if (!nextArg || nextArg.startsWith('--')) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      result.outputPath = nextArg;
      i++; // Skip next arg since we consumed it
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    }
  }
  
  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return result;
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: Expected object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: Missing or invalid title field (expected string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: Missing or invalid summary field (expected string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: Missing or invalid entries field (expected array)');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid data: Entry ${i} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid data: Entry ${i} missing or invalid label field (expected string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid data: Entry ${i} missing or invalid amount field (expected number)`);
    }
  }
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    validateReportData(data);
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${filePath}: ${error.message}`);
      process.exit(1);
    } else if (error instanceof Error && error.message.includes('ENOENT')) {
      console.error(`Error: File not found: ${filePath}`);
      process.exit(1);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error(`Error: Unknown error loading file ${filePath}`);
      process.exit(1);
    }
  }
}

function main(): void {
  try {
    const args = parseArgs();
    
    // Check if format is supported
    if (!(args.format in formatters)) {
      console.error(`Error: Unsupported format: ${args.format}`);
      process.exit(1);
    }
    
    // Load and validate data
    const data = loadReportData(args.dataFile);
    
    // Render report
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };
    
    const formatter = formatters[args.format];
    const output = formatter.render(data, options);
    
    // Output result
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Unknown error occurred');
    }
    process.exit(1);
  }
}

main();