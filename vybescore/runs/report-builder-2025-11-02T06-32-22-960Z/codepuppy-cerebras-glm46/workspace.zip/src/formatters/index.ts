import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';
import type { ReportFormatter } from '../types.js';

export const formatters: Record<string, ReportFormatter> = {
  markdown: markdownFormatter,
  text: textFormatter,
};

export type SupportedFormat = keyof typeof formatters;