/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependencies?: Set<ObserverR> // Observers this one depends on
  subscribers?: Set<ObserverR> // Observers that depend on this one
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer?: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function trackDependency(observer: ObserverR, dependency: ObserverR): void {
  // Add dependency to observer's dependencies set
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(dependency)
  
  // Add observer to dependency's subscribers set
  if (!dependency.subscribers) {
    dependency.subscribers = new Set()
  }
  dependency.subscribers.add(observer)
}

export function notifyDependents(observer: ObserverR): void {
  if (observer.subscribers) {
    // Create a copy of subscribers to avoid issues if the set is modified during iteration
    const subscribersCopy = new Set(observer.subscribers)
    subscribersCopy.forEach(subscriber => {
      // Check if the subscriber is still in the original set (it might have been removed)
      if (observer.subscribers?.has(subscriber)) {
        updateObserver(subscriber as Observer<unknown>)
      }
    })
  }
}

export function cleanupObserver(observer: ObserverR): void {
  // Remove this observer from all its dependencies' subscriber lists
  if (observer.dependencies) {
    for (const dependency of observer.dependencies) {
      dependency.subscribers?.delete(observer)
    }
  }
  
  // Clear the observer's dependencies and subscribers
  observer.dependencies?.clear()
  observer.subscribers?.clear()
}