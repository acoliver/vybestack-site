/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    name: 'callback',
    // Mark this as a callback observer type for proper handling
    _isCallback: true,
    // Store the original side-effect function for updates
    _effect: updateFn,
  }
  
  let disposed = false
  
  const runCallback = () => {
    if (disposed) return
    
    // Execute callback with this observer as the active observer
    const prevActive = getActiveObserver()
    setActiveObserver(observer)
    try {
      // Execute the original side-effect function
      observer._effect!(observer.value)
    } finally {
      setActiveObserver(prevActive)
    }
  }
  
  // Execute the callback to establish initial dependencies and run the side effect
  runCallback()
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Properly cleanup observer dependencies
    if (observer.dependencies) {
      for (const dependency of observer.dependencies) {
        dependency.subscribers?.delete(observer)
      }
      observer.dependencies.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
