/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn,
  Observer, 
  getActiveObserver,
  setActiveObserver,
  trackDependency,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const read: GetterFn<T> = () => {
    const active = getActiveObserver()
    
    if (active && active !== o) {
      // This computed value is being read by another observer
      // Track that active observer depends on this computed value
      trackDependency(active, o)
    }
    
    // Set this as the active observer and execute the update function
    // This will establish dependencies on any inputs this computed value reads
    const prevActive = getActiveObserver()
    setActiveObserver(o)
    try {
      // Recalculate the value by calling updateFn without arguments
      const newValue = o.updateFn(o.value)
      
      // Check if the value actually changed and notify subscribers if it did
      if (newValue !== o.value) {
        o.value = newValue
        // Notify subscribers that this computed value has changed
        notifyDependents(o)
      } else {
        o.value = newValue
      }
    } finally {
      setActiveObserver(prevActive)
    }
    
    return o.value!
  }

  return read
}