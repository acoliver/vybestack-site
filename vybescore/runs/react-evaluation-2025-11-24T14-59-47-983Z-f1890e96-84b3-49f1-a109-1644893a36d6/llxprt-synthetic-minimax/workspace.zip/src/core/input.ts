/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  ObserverR,
  getActiveObserver,
  trackDependency,
  notifyDependents,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const active = getActiveObserver()
    if (active) {
      // Track that active observer depends on this input
      trackDependency(active, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = typeof equal === 'function' 
      ? !equal(s.value, nextValue)
      : s.value !== nextValue
    
    if (shouldUpdate) {
      s.value = nextValue
      // Notify all observers that depend on this input by re-executing their update functions
      // Don't clear the active observer here - let the notification system handle it
      notifyDependents(s as unknown as ObserverR)
    }
    return s.value
  }

  return [read, write]
}
