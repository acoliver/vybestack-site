// Manual test script to verify pagination functionality
import fetch from 'cross-fetch';

async function testPagination() {
  const baseUrl = 'http://localhost:3000';
  
  console.log('Testing pagination functionality...\n');
  
  try {
    // Test 1: Default pagination (page 1, limit 5)
    console.log('1. Testing default pagination:');
    const response1 = await fetch(`${baseUrl}/inventory`);
    const data1 = await response1.json();
    console.log('Response:', JSON.stringify(data1, null, 2));
    console.log(`[OK] Status: ${response1.status}, Items: ${data1.items.length}, Page: ${data1.page}, HasNext: ${data1.hasNext}\n`);
    
    // Test 2: Custom pagination (page 2, limit 3)
    console.log('2. Testing custom pagination (page=2, limit=3):');
    const response2 = await fetch(`${baseUrl}/inventory?page=2&limit=3`);
    const data2 = await response2.json();
    console.log('Response:', JSON.stringify(data2, null, 2));
    console.log(`[OK] Status: ${response2.status}, Items: ${data2.items.length}, Page: ${data2.page}, HasNext: ${data2.hasNext}\n`);
    
    // Test 3: Invalid page parameter
    console.log('3. Testing invalid page parameter (page=0):');
    const response3 = await fetch(`${baseUrl}/inventory?page=0`);
    const data3 = await response3.json();
    console.log('Response:', JSON.stringify(data3, null, 2));
    console.log(`[OK] Status: ${response3.status}, Error: ${data3.error}\n`);
    
    // Test 4: Invalid limit parameter
    console.log('4. Testing invalid limit parameter (limit=-1):');
    const response4 = await fetch(`${baseUrl}/inventory?limit=-1`);
    const data4 = await response4.json();
    console.log('Response:', JSON.stringify(data4, null, 2));
    console.log(`[OK] Status: ${response4.status}, Error: ${data4.error}\n`);
    
    // Test 5: Non-numeric parameters
    console.log('5. Testing non-numeric parameters (page=abc):');
    const response5 = await fetch(`${baseUrl}/inventory?page=abc`);
    const data5 = await response5.json();
    console.log('Response:', JSON.stringify(data5, null, 2));
    console.log(`[OK] Status: ${response5.status}, Error: ${data5.error}\n`);
    
    // Test 6: Large page number (should return empty items)
    console.log('6. Testing large page number (page=100):');
    const response6 = await fetch(`${baseUrl}/inventory?page=100`);
    const data6 = await response6.json();
    console.log('Response:', JSON.stringify(data6, null, 2));
    console.log(`[OK] Status: ${response6.status}, Items: ${data6.items.length}, HasNext: ${data6.hasNext}\n`);
    
    console.log('All tests completed!');
    
  } catch (error) {
    console.error('Test failed:', error.message);
    console.log('Make sure the server is running on http://localhost:3000');
  }
}

testPagination();