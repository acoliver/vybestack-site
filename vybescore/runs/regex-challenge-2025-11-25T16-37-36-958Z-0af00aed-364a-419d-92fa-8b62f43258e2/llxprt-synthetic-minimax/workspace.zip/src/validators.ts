export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Trim and check basic format
  if (!value || typeof value !== 'string') return false;
  
  // Check for obviously invalid patterns first
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.') || 
      value.includes('@.') || value.includes('.@') || value.includes('@@')) {
    return false;
  }
  
  // Pattern for email validation
  const emailPattern = /^[a-zA-Z0-9]([a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  if (!emailPattern.test(value)) return false;
  
  // Split and validate local and domain parts
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const [localPart, domain] = parts;
  
  // Check local part length and format
  if (localPart.length > 64 || localPart.includes('..') || 
      localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check domain part for underscores and basic format
  if (domain.includes('_') || domain.startsWith('-') || domain.endsWith('-') ||
      domain.includes('.-') || domain.includes('-.')) {
    return false;
  }
  
  // Ensure TLD is at least 2 characters and doesn't start with a dot
  const domainParts = domain.split('.');
  if (domainParts.length < 2 || domainParts[domainParts.length - 1].length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length - should be 10 or 11 digits (with optional +1)
  if (digits.length === 11 && digits.startsWith('1')) {
    // 11 digits with country code 1
    const areaCode = parseInt(digits.substring(1, 4), 10);
    if (areaCode <= 1) return false; // Invalid area code (0 or 1)
  } else if (digits.length === 10) {
    // 10 digits without country code
    const areaCode = parseInt(digits.substring(0, 3), 10);
    if (areaCode <= 1) return false; // Invalid area code (0 or 1)
  } else {
    return false; // Wrong length
  }
  
  // Basic pattern check for common formats
  const phonePattern = /^\+?1?[-.\s]?\(?([2-9][0-8][0-9]|[2-9][0-9]{2})\)?[-.\s]?[2-9][0-9]{2}[-.\s]?[0-9]{4}$/;
  return phonePattern.test(value);
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Clean the input - remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phone numbers
  // Optional +54, optional 9 for mobile, area code 2-4 digits (1-9), subscriber number 6-8 digits total
  const argentinePhonePattern = /^(\+54)?(0)?(9)?([1-9][0-9]{1,3})([0-9]{6,8})$/;
  
  const match = cleaned.match(argentinePhonePattern);
  if (!match) return false;
  
  const countryCode = match[1];
  const trunkPrefix = match[2];
  const mobileIndicator = match[3];
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  // Validation rules:
  // 1. If country code is present, area code must be 2-4 digits starting with 1-9
  // 2. If country code is omitted, trunk prefix (0) must be present before area code
  // 3. For mobile numbers (9 indicator), total subscriber number should be appropriate
  
  const totalDigits = (countryCode?.replace('+', '')?.length || 0) + 
                     (trunkPrefix?.length || 0) + 
                     (mobileIndicator?.length || 0) + 
                     areaCode.length + 
                     subscriberNumber.length;
  
  // Basic length check - total should be reasonable for Argentine numbers
  if (totalDigits < 10 || totalDigits > 15) return false;
  
  // If no country code, must have trunk prefix
  if (!countryCode && !trunkPrefix) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check for obviously invalid patterns
  if (value.includes('X Æ A-12')) return false;
  
  // Allow unicode letters, spaces, apostrophes, hyphens, and common punctuation
  const namePattern = /^[\p{L}\p{M}\s'’-]+$/u;
  
  if (!namePattern.test(value)) return false;
  
  // Additional checks for reasonable name structure
  if (value.length < 2 || value.length > 100) return false;
  
  // Check that it doesn't start or end with punctuation
  if (/^[^\p{L}\p{M}]|[^\p{L}\p{M}]$/u.test(value)) return false;
  
  // Check for at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check for reasonable starting patterns (Visa, Mastercard, AmEx, etc.)
  const firstDigit = parseInt(digits.charAt(0), 10);
  const firstTwoDigits = parseInt(digits.substring(0, 2), 10);
  const firstThreeDigits = parseInt(digits.substring(0, 3), 10);
  const firstFourDigits = parseInt(digits.substring(0, 4), 10);
  
  let isValidPrefix = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (firstDigit === 4 && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    isValidPrefix = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if ((firstTwoDigits >= 51 && firstTwoDigits <= 55) || 
           (firstFourDigits >= 2221 && firstFourDigits <= 2720) && digits.length === 16) {
    isValidPrefix = true;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((firstTwoDigits === 34 || firstTwoDigits === 37) && digits.length === 15) {
    isValidPrefix = true;
  }
  // Discover: starts with 6011, 65, or 644-649, length 16
  else if ((digits.startsWith('6011') || firstTwoDigits === 65 || 
           (firstThreeDigits >= 644 && firstThreeDigits <= 649)) && 
           (digits.length === 16 || digits.length === 19)) {
    isValidPrefix = true;
  }
  // JCB: starts with 3528-3589, length 16
  else if (firstFourDigits >= 3528 && firstFourDigits <= 3589 && digits.length === 16) {
    isValidPrefix = true;
  }
  // Diners Club: starts with 300-305, 36, or 38-39, length 14
  else if (((firstThreeDigits >= 300 && firstThreeDigits <= 305) || 
           firstTwoDigits === 36 || (firstTwoDigits >= 38 && firstTwoDigits <= 39)) && 
           digits.length === 14) {
    isValidPrefix = true;
  }
  
  if (!isValidPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}