/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // First, capitalize the very first character if it's a letter
  const result = text.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  // Pattern to find sentence endings followed by spaces/newlines and the start of next sentence
  const sentencePattern = /([.!?])([\s\n]+)([a-z])/g;
  
  // Function to capitalize the first letter after sentence endings
  return result.replace(sentencePattern, (match, punctuation, whitespace, nextChar) => {
    return punctuation + whitespace + nextChar.toUpperCase();
  });
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL pattern that captures various schemes and common formats
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s<>"'(){}[\]\\|;`~]+[^\s<>"'(){}[\]\\|;`~.,!?)]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,!?;]+$/g, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // Replace http:// with https://, but only when not already https://
  const httpsPattern = /https?:\/\//gi;
  
  return text.replace(httpsPattern, (match) => {
    if (match.toLowerCase() === 'http://') {
      return 'https://';
    }
    return match; // Keep https:// as is
  });
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // Pattern to match http:// URLs
  const httpUrlPattern = /http:\/\/([a-zA-Z0-9.-]+)([^<>"'(){}[\]\\|;`~]*)/gi;
  
  return text.replace(httpUrlPattern, (match, domain, path) => {
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /cgi-bin|[?&]/i.test(path);
    const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?&]|$)/i.test(path);
    
    if (hasDynamicHints || hasLegacyExtensions) {
      // Keep original domain, just upgrade to https
      return `https://${domain}${path}`;
    }
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Convert to docs subdomain
      return `https://docs.${domain}${path}`;
    }
    
    // Default case - just upgrade to https
    return `https://${domain}${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for month and day ranges
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';
  
  // Check for realistic year range (1900-2100)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1900 || yearNum > 2100) return 'N/A';
  
  return year;
}