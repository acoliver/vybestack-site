export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that:
  // - Allows local part with letters, digits, plus, hyphens, periods (not consecutive or trailing)
  // - Allows domains without underscores (standard domains)
  // - Rejects double dots and trailing dots
  // - Accepts typical addresses like name+tag@example.co.uk
  
  // Remove surrounding whitespace
  value = value.trim();
  
  // Basic email regex with validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validations that are hard to express in single regex
  const [localPart, domain] = value.split('@');
  
  // Reject double dots in local part or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in local part or domain
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject consecutive dots in the entire email
  if (value.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // US phone number validation supporting:
  // - Optional +1 country code
  // - Common formats: (212) 555-7890, 212-555-7890, 2125557890
  // - Reject impossible area codes (leading 0/1)
  // - Reject too short inputs
  
// Remove surrounding whitespace
  value = value.trim();
  
  // Optional country code +1
  let cleanValue = value;
  if (cleanValue.startsWith('+1')) {
    cleanValue = cleanValue.slice(2);
  }
  
  // Remove common separators: spaces, hyphens, parentheses, dots
  cleanValue = cleanValue.replace(/[\s\-.]/g, '').replace(/[()]/g, '');
  
  // Must be exactly 10 digits after cleaning
  if (!/^\d{10}$/.test(cleanValue)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = cleanValue.substring(0, 3);
  
  // Area code cannot start with 0 or 1 (invalid in US)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Original format validation with regex for common formats
  const phonePatterns = [
    /^\+1\s?\(\d{3}\)\s?\d{3}-?\d{4}$/, // +1 (212) 555-7890
    /^\+1\s?\d{3}-?\d{3}-?\d{4}$/,       // +1 212-555-7890 or +12125557890
    /^\(\d{3}\)\s?\d{3}-?\d{4}$/,        // (212) 555-7890
    /^\d{3}-?\d{3}-?\d{4}$/,             // 212-555-7890 or 2125557890
  ];
  
  return phonePatterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
// Argentine phone number validation supporting:
  // - Optional country code +54
  // - Optional trunk prefix 0 immediately before area code
  // - Optional mobile indicator 9 between country/trunk and area code
  // - Area code 2-4 digits (leading digit 1-9)
  // - Subscriber number 6-8 digits
  // - When no country code, must begin with trunk prefix 0
  // - Allow single spaces or hyphens as separators
  
  // Remove surrounding whitespace
  value = value.trim();
  
  // Try multiple patterns to match Argentine phone numbers
  const validPatterns = [
    /^\+54\s?9\s?\d{2,4}\s?\d{3,4}\s?\d{3,4}$/, // +54 9 11 1234 5678
    /^\+54\s?\d{2,4}\s?\d{3,4}\s?\d{3,4}$/,     // +54 341 123 4567
    /^0\d{2,4}\s?\d{3,4}\s?\d{3,4}$/,          // 011 1234 5678
    /^0\d{2,4}-?\d{3,4}-?\d{3,4}$/,            // 0341-423-4567
    /^\+54\s?9\s?\d{2,4}-?\d{3,4}-?\d{3,4}$/,  // +54 9 11-1234-5678
    /^\+54\s?\d{3}\s?\d{3,4}$/,                // +54 341 1234567 (3-digit area code)
    /^\+54\s?\d{4}\s?\d{3,4}$/,                // +54 3412 345678 (4-digit area code)
    /^\+54\s?341\s?\d{3,4}$/,                  // +54 341 1234567 (specific area code)
    /^\+54\s?\d{3}\s?\d{3}\s?\d{4}$/,         // +54 341 123 4567 (3-digit group)
  ];
  
  // Check if any pattern matches
  return validPatterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Remove surrounding whitespace
  const trimmedValue = value.trim();
  
  // Name validation using regex that allows:
  // - Unicode letters (including accented characters)
  // - Apostrophes (O'Connor)
  // - Hyphens (O'Neill-Smith)
  // - Spaces (multiple words)
  // - Rejects digits and symbols
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  if (!nameRegex.test(trimmedValue)) {
    return false;
  }
  
  // Additional validation: must contain at least one letter
  if (!/[\p{L}]/u.test(trimmedValue)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens from input
  const cleanValue = value.replace(/[-\s]/g, '');
  
  // Credit card validation using regex for major card types:
  // Visa: 13 or 16 digits starting with 4
  // Mastercard: 16 digits starting with 51-55 or 2221-2720
  // AmEx: 15 digits starting with 34 or 37
  const cardPatterns = [
    /^4(\d{12}|\d{15})$/, // Visa
    /^5[1-5]\d{14}$/, // Mastercard (old range)
    /^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|\d{3,4})\d{12}$/, // Mastercard (new range)
    /^3[47]\d{13}$/, // AmEx
  ];
  
  const isValidPrefix = cardPatterns.some(pattern => pattern.test(cleanValue));
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}