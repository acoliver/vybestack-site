/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Remove leading/trailing whitespace and normalize multiple spaces
  let processedText = text.trim().replace(/\s+/g, ' ');
  
  // Capitalize first character of each sentence (.?! separators)
  processedText = processedText.replace(/([.?!]\s*)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Capitalize first character of the entire text
  processedText = processedText.replace(/^[a-z]/, (match) => match.toUpperCase());
  
  return processedText;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches:
  // - http:// or https:// protocols
  // - www. domains
  // - Domain names with TLDs
  // - Optional port numbers
  // - Optional paths, queries, fragments
  // - Captures URLs without trailing punctuation
  const urlRegex = /\b((?:https?:\/|www.)[^\s<>"']+|\b[^\s<>"']{2,}\.[^\s<>"']{2,})(?=\b|$)/gi;
  
  const matches = [];
  let match;
  
  // Using exec to find all matches and capture them properly
  const regex = new RegExp(urlRegex);
  
  while ((match = regex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation while preserving URLs ending with slashes
    url = url.replace(/[,.!?;:)]+$/, '');
    
    // Remove trailing quotes and brackets if they're not part of the URL
    url = url.replace(/["')}>\\\]]+$/, '');
    
    // Remove matching opening parentheses if we removed closing ones
    const openingParens = url.match(/\(/g)?.length || 0;
    const closingParens = url.match(/\)/g)?.length || 0;
    if (openingParens > closingParens) {
      const extraOpen = openingParens - closingParens;
      for (let i = 0; i < extraOpen; i++) {
        url = url.replace(/^\(/, '');
      }
    }
    
    // Add protocol if missing but URL starts with www.
    if (/^www\./i.test(url)) {
      url = 'https://' + url;
    }
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave https:// unchanged
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Rewrite URLs according to requirements:
  // 1. Always upgrade http:// to https://
  // 2. For URLs with path beginning with /docs/, rewrite host to docs.example.com
  // 3. Skip host rewrite for URLs containing dynamic hints like cgi-bin, query strings, or legacy extensions
  // 4. Preserve nested paths
  
  // Step 1: First replace all http:// with https://
  text = text.replace(/http:\/\//g, 'https://');
  
  // Step 2: Process URLs for docs.example.com rewriting using a different pattern
  return text.replace(/https:\/\/([^/\s]+)(\/[^\s]+)/g, (match, host, path) => {
    // Determine if we should rewrite the host
    // Skip host rewrite if path contains dynamic hints or query strings
    const shouldSkipHostRewrite = /\?(?:[^&]*&)*[^&]*=/.test(path) || 
                                  path.includes('cgi-bin') || 
                                  /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=\/|$)/i.test(path);
    
    if (!shouldSkipHostRewrite && path.match(/^\/docs\//)) {
      // Rewrite host to docs.{originalHost}
      host = 'docs.' + host;
    }
    
    return 'https://' + host + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.trim().match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [fullMatch, , , year] = match;
  
  // Additional validation for month/day combinations
  const month = parseInt(fullMatch.substring(0, 2), 10);
  const day = parseInt(fullMatch.substring(3, 5), 10);
  
  // Check if the month/day combination is valid
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Leap year check (simplified)
  const leapYear = (yearNum: string) => {
    const numYear = parseInt(yearNum, 10);
    return (numYear % 4 === 0 && numYear % 100 !== 0) || (numYear % 400 === 0);
  };
  
  // Update days in February for leap years
  daysInMonth[1] = leapYear(year) ? 29 : 28;
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}