/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex pattern for words starting with the prefix
  // - Word boundaries at start and end
  // - Followed by word characters
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  // Find all matches
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const result = matches.filter(word => {
    const lowerWord = word.toLowerCase();
    const lowerExceptions = exceptions.map(e => e.toLowerCase());
    return !lowerExceptions.includes(lowerWord);
  }).map(word => word.toLowerCase()); // Normalize to lowercase
  
  // Return unique words to avoid duplicates
  return [...new Set(result)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex to find token preceded by digit
  // Check each word boundary for the token preceded by a digit
  
  // Find token occurrences preceded by digits using regex with capture groups
  const regex = new RegExp(`(\\d+)${escapedToken}`, 'gi');
  const matches = [];
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    matches.push(match[0]); // Include the digit with the token
  }
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length requirement (minimum 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for required character classes
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^\p{L}\d]/u.test(value); // Any non-alphanumeric character
  
  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab should fail)
  // This looks for patterns where a 2-4 character sequence repeats immediately
  for (let i = 0; i < value.length - 4; i++) {
    for (let len = 2; len <= 4; len++) {
      const substring = value.substr(i, len);
      const repeatPosition = i + len;
      if (repeatPosition + len <= value.length && 
          value.substr(repeatPosition, len) === substring) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address pattern that handles:
  // - Full notation: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // - Shorthand with :: for consecutive zero groups
  // - Notation with fewer than 8 groups
  
  // IPv6 patterns (including abbreviated forms)
  const ipv6Patterns = [
    // Standard IPv6 with full 8 groups
    /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // Abbreviated form with ::
    /\b([0-9a-fA-F]{1,4}:){1,7}:[0-9a-fA-F]{1,4}\b/,
    /\b::[0-9a-fA-F]{1,4}\b/,
    /\b[0-9a-fA-F]{1,4}::\b/,
    /\b[0-9a-fA-F]{1,4}:([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/,
  ];
  
  // IPv4 address pattern to exclude
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if the value is exclusively an IPv4 address
  if (value.trim().match(ipv4Pattern) && !value.includes(':')) {
    return false;
  }
  
  // Check if the value contains any IPv6 pattern
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
