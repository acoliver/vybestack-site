import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs from 'sql.js';

// Get __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize express app
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup
const dbPath = path.resolve(__dirname, '../data/submissions.sqlite');
let db: any;

// Initialize database
async function initDatabase() {
  const SQL = await initSqlJs({
    locateFile: (file) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.0/${file}`
  });
  
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.resolve(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    saveDatabase();
  }
}

// Save database to file
function saveDatabase() {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

// Form data type
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Error messages type
interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Validation functions
function validateRequired(value: string): boolean {
  return value.trim() !== '';
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces and dashes
  const postalCodeRegex = /^[a-zA-Z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Validate form data
function validateFormData(data: FormData): FormErrors {
  const errors: FormErrors = {};
  
  if (!validateRequired(data.firstName)) {
    errors.firstName = 'First name is required';
  }
  
  if (!validateRequired(data.lastName)) {
    errors.lastName = 'Last name is required';
  }
  
  if (!validateRequired(data.streetAddress)) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!validateRequired(data.city)) {
    errors.city = 'City is required';
  }
  
  if (!validateRequired(data.stateProvince)) {
    errors.stateProvince = 'State/Province is required';
  }
  
  if (!validateRequired(data.postalCode)) {
    errors.postalCode = 'Postal code is required';
  } else if (!validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Postal code format is invalid';
  }
  
  if (!validateRequired(data.country)) {
    errors.country = 'Country is required';
  }
  
  if (!validateRequired(data.email)) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Email format is invalid';
  }
  
  if (!validateRequired(data.phone)) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Phone number format is invalid';
  }
  
  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const data: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateFormData(data);
  
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { 
      errors: Object.values(errors), 
      values: data 
    });
  }
  
  // Insert into database
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    data.firstName,
    data.lastName,
    data.streetAddress,
    data.city,
    data.stateProvince,
    data.postalCode,
    data.country,
    data.email,
    data.phone
  ]);
  
  stmt.free();
  saveDatabase();
  
  // Redirect to thank you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(data.firstName));
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Initialize database and start server
let server: any;
initDatabase().then(() => {
  server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
}).catch((err) => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

export default app;