/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  addDependency,
  observerDependencies,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      // Track this dependency for notifications (observer depends on this input)
      addDependency(observer, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Direct notify any dependents of this input
    const dependents = observerDependencies.get(s)
    if (dependents) {
      const depsToNotify = Array.from(dependents)
      depsToNotify.forEach((dependent) => {
        updateObserver(dependent as unknown as Observer<unknown>)
      })
    }
    
    // Also notify any dependent observer attached to this input
    if (s.observer) {
      updateObserver(s.observer as Observer<unknown>)
    }
    
    return s.value
  }

  return [read, write]
}
