/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  addDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Initialize observer with initial value if provided
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Return getter that computes value on each access
  return (): T => {
    // If this computed value is being accessed by another observer,
    // establish a dependency relationship
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // This computed value becomes a dependency 
      // for the currently active observer
      o.observer = activeObserver
      addDependency(activeObserver, o)
    }
    
    // Compute current value by executing updateFn
    // This will register all dependencies accessed during execution
    updateObserver(o)
    return o.value as T
  }
}
