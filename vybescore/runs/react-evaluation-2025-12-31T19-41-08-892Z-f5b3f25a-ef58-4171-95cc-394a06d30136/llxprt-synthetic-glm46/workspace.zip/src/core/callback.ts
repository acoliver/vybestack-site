/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver,
  removeDependency,
  getDependents
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const callbackObserver: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Execute once to establish dependencies
  updateObserver(callbackObserver)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up dependencies to prevent memory leaks
    const dependents = getDependents(callbackObserver)
    if (dependents) {
      dependents.forEach(dependent => {
        removeDependency(dependent, callbackObserver)
      })
    }
    
    // Clear the observer to stop further updates
    callbackObserver.value = undefined
    callbackObserver.updateFn = () => value!
    callbackObserver.observer = undefined  // Clean up references
  }
}
