/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  observer?: ObserverR
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

// Simple global dependencies map for tracking all observers
const observerDependencies = new Map<ObserverR, Set<ObserverR>>()

export function getDependents(observer: ObserverR): Set<ObserverR> | undefined {
  return observerDependencies.get(observer)
}

export function addDependency(dependent: ObserverR, dependency: ObserverR): void {
  // Create reverse mapping from dependency to dependent
  if (!observerDependencies.has(dependency)) {
    observerDependencies.set(dependency, new Set())
  }
  observerDependencies.get(dependency)!.add(dependent)
}

// Also export the observer dependencies map for direct access
export { observerDependencies }

export function removeDependency(dependent: ObserverR, dependency: ObserverR): void {
  const deps = observerDependencies.get(dependent)
  if (deps) {
    deps.delete(dependency)
    if (deps.size === 0) {
      observerDependencies.delete(dependent)
    }
  }
}

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Track observers currently being updated to prevent infinite recursion
const updatingObservers = new WeakSet<ObserverR>()

export function updateObserver<T>(observer: Observer<T>): void {
  // First ensure observer has an updateFn before proceeding
  if (!observer || typeof observer.updateFn !== 'function') {
    return
  }

  // Prevent recursive updates that can cause stack overflow
  if (updatingObservers.has(observer)) {
    return
  }
  
  const previous = activeObserver
  activeObserver = observer
  updatingObservers.add(observer)
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    updatingObservers.delete(observer)
  }
  
  // After updating, notify all dependents
  const dependents = getDependents(observer)
  if (dependents) {
    // Create a stable copy before notification
    const depsToNotify = Array.from(dependents)
    // Notify each dependent that a value changed
    for (const dependent of depsToNotify) {
      // Notify the dependent
      const obsv = dependent as unknown as Observer<unknown>
      updateObserver(obsv)
    }
  }
}
