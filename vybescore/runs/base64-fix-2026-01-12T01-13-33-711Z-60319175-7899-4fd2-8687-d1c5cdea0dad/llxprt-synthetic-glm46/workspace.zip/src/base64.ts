/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /, = padding)
  if (!/^[A-Za-z0-9+/=]*$/.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check for correct padding (only at the end and max 2 padding chars)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If there's padding, it should only appear at the end
    const padding = input.substring(paddingIndex);
    if (!/^={0,2}$/.test(padding)) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    
    // If there's padding, there should be at most 2 padding chars
    if (input.lastIndexOf('=') > paddingIndex + 1) {
      throw new Error('Invalid Base64 input: too much padding');
    }
  }
  
  // Check if the input would be valid when padded to the correct length
  // Base64 strings must have a length that is a multiple of 4, but padding can be omitted
  const paddedLength = Math.ceil(input.length / 4) * 4;
  const paddedInput = input.padEnd(paddedLength, '=');
  
  try {
    // Try to decode the padded version
    const result = Buffer.from(paddedInput, 'base64').toString('utf8');
    
    // Validate that the conversion is reversible by re-encoding and comparing
    // to a normalized version of the original input
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    
    // Remove padding for comparison
    const normalizedOriginal = input.replace(/=+$/, '');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    
    // The decoded content must round-trip correctly when normalized
    if (normalizedOriginal !== normalizedReencoded) {
      throw new Error('Invalid Base64 input: failed round-trip validation');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.startsWith('Invalid Base64 input')) {
      throw error; // Re-throw our custom errors
    }
    throw new Error('Failed to decode Base64 input');
  }
}
