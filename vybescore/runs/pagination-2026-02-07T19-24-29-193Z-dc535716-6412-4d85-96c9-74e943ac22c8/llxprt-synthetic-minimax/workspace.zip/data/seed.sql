-- Create inventory table
CREATE TABLE IF NOT EXISTS inventory (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  sku TEXT NOT NULL UNIQUE,
  price_cents INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Insert sample inventory data
INSERT INTO inventory (name, sku, price_cents) VALUES
  ('Wireless Mouse', 'WM-001', 2999),
  ('Mechanical Keyboard', 'MK-002', 8999),
  ('USB-C Cable', 'UC-003', 1299),
  ('Laptop Stand', 'LS-004', 4599),
  ('Webcam HD', 'WC-005', 7499),
  ('Headphones Pro', 'HP-006', 12999),
  ('Monitor 27"', 'MN-007', 29999),
  ('Desk Lamp', 'DL-008', 2499),
  ('Wireless Charger', 'WC-009', 1999),
  ('External SSD 1TB', 'SD-010', 8999),
  ('Graphics Tablet', 'GT-011', 15999),
  ('Smart Speaker', 'SS-012', 6999),
  ('Bluetooth Speaker', 'BS-013', 3999),
  ('Office Chair', 'OC-014', 19999),
  ('Desk Organizer', 'DO-015', 1599),
  ('LED Light Strip', 'LS-016', 3499),
  ('Power Bank 20K', 'PB-017', 4999),
  ('Smart Watch', 'SW-018', 24999),
  ('Fitness Tracker', 'FT-019', 9999),
  ('Portable Projector', 'PP-020', 39999);
