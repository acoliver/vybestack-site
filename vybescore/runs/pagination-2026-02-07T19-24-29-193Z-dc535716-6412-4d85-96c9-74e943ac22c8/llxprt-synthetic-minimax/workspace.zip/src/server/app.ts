import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate query parameters
    // Input validation: reject non-numeric, negative, zero, or excessive values
    const errors: string[] = [];
    let validatedPage = 1; // default
    let validatedLimit = 5; // default

    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (isNaN(pageNum) || !Number.isInteger(pageNum)) {
        errors.push('page must be a valid integer');
      } else if (pageNum <= 0) {
        errors.push('page must be greater than 0');
      } else if (pageNum > 1000000) {
        errors.push('page is excessive');
      } else {
        validatedPage = pageNum;
      }
    }

    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (isNaN(limitNum) || !Number.isInteger(limitNum)) {
        errors.push('limit must be a valid integer');
      } else if (limitNum <= 0) {
        errors.push('limit must be greater than 0');
      } else if (limitNum > 1000) {
        errors.push('limit is excessive (max 1000)');
      } else {
        validatedLimit = limitNum;
      }
    }

    if (errors.length > 0) {
      return res.status(400).json({ 
        error: 'Invalid query parameters',
        details: errors 
      });
    }

    const payload = listInventory(db, { page: validatedPage, limit: validatedLimit });
    res.json(payload);
  });

  return app;
}
