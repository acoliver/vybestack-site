interface PaginationControlsProps {
  currentPage: number;
  hasNext: boolean;
  onPrevious: () => void;
  onNext: () => void;
}

export function PaginationControls({
  currentPage,
  hasNext,
  onPrevious,
  onNext
}: PaginationControlsProps): JSX.Element {
  const isPreviousDisabled = currentPage <= 1;
  const isNextDisabled = !hasNext;

  return (
    <nav aria-label="Pagination controls" style={{ marginTop: '1rem' }}>
      <button
        type="button"
        onClick={onPrevious}
        disabled={isPreviousDisabled}
        aria-disabled={isPreviousDisabled}
      >
        Previous
      </button>
      <span style={{ margin: '0 0.5rem' }}>Page {currentPage}</span>
      <button
        type="button"
        onClick={onNext}
        disabled={isNextDisabled}
        aria-disabled={isNextDisabled}
      >
        Next
      </button>
    </nav>
  );
}