/**
 * Encode plain text to Base64 using the standard alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and throws an error for invalid Base64.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate Base64 format: only allow A-Z, a-z, 0-9, +, /, and padding
  // Padding (=) can only appear at the end, max 2 characters
  const hasInteriorPadding = /[^=]=[^=]/.test(trimmed);
  const hasInvalidPadding = /={3,}/.test(trimmed);
  const hasIllegalChars = /[^A-Za-z0-9+/=]/.test(trimmed);
  
  if (hasInteriorPadding || hasInvalidPadding || hasIllegalChars) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  const unpaddedLength = trimmed.replace(/=+$/, '').length;
  const normalized = addPaddingIfNeeded(trimmed);

  validatePadding(normalized);

  return decodeWithValidation(normalized, unpaddedLength);
}

/**
 * Add padding to Base64 string if needed to make length a multiple of 4.
 */
function addPaddingIfNeeded(input: string): string {
  if (input.length % 4 !== 0) {
    const paddingNeeded = (4 - (input.length % 4)) % 4;
    return input + '='.repeat(paddingNeeded);
  }
  return input;
}

/**
 * Validate that padding is at most 2 characters.
 */
function validatePadding(input: string): void {
  const paddingMatch = input.match(/=*$/);
  if (paddingMatch && paddingMatch[0].length > 2) {
    throw new Error('Invalid Base64 input: incorrect padding');
  }
}

/**
 * Decode Base64 string and validate the result.
 */
function decodeWithValidation(normalized: string, unpaddedLength: number): string {
  const buffer = Buffer.from(normalized, 'base64');
  
  // Validate that the decode was successful by re-encoding and comparing
  const reencoded = buffer.toString('base64');
  const normalizedOriginal = normalized.replace(/=+$/, '');
  const normalizedReencoded = reencoded.replace(/=+$/, '');
  
  if (normalizedOriginal !== normalizedReencoded && unpaddedLength > 0) {
    throw new Error('Invalid Base64 input: corrupted data');
  }
  
  return buffer.toString('utf8');
}
