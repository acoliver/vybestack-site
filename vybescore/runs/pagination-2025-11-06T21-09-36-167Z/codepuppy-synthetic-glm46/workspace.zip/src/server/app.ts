import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePaginationParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): { page?: number; limit?: number } | null {
  const MAX_LIMIT = 100;
  
  if (pageParam !== undefined) {
    const page = Number(pageParam);
    if (isNaN(page) || page <= 0 || !Number.isInteger(page)) {
      return null;
    }
  }
  
  if (limitParam !== undefined) {
    const limit = Number(limitParam);
    if (isNaN(limit) || limit <= 0 || !Number.isInteger(limit) || limit > MAX_LIMIT) {
      return null;
    }
  }
  
  return {
    page: pageParam !== undefined ? Number(pageParam) : undefined,
    limit: limitParam !== undefined ? Number(limitParam) : undefined
  };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validatePaginationParams(pageParam, limitParam);
    if (!validation) {
      return res.status(400).json({
        error: 'Invalid pagination parameters. Page and limit must be positive integers, and limit must be <= 100.'
      });
    }

    const payload = listInventory(db, validation);
    res.json(payload);
  });

  return app;
}
