import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import type { Database } from 'sql.js';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns pagination metadata', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body).toMatchObject({
      page: expect.any(Number),
      limit: expect.any(Number),
      total: expect.any(Number),
      hasNext: expect.any(Boolean),
      items: expect.any(Array)
    });
  });

  it('uses default pagination when no params provided', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBeLessThanOrEqual(5);
  });

  it('honors custom page and limit parameters', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBeLessThanOrEqual(3);
  });

  it('correctly calculates offset for pagination', async () => {
    const page1Response = await request(app).get('/inventory?page=1&limit=3');
    const page2Response = await request(app).get('/inventory?page=2&limit=3');
    
    expect(page1Response.status).toBe(200);
    expect(page2Response.status).toBe(200);
    
    // Items should be different between pages
    const page1Ids = page1Response.body.items.map((item: { id: number }) => item.id);
    const page2Ids = page2Response.body.items.map((item: { id: number }) => item.id);
    
    expect(page1Ids).not.toEqual(page2Ids);
    // Page 2 should start after page 1 items
    expect(page2Ids[0]).toBeGreaterThan(page1Ids[page1Ids.length - 1]);
  });

  it('correctly identifies when there is a next page', async () => {
    const page1Response = await request(app).get('/inventory?page=1&limit=5');
    const lastPageResponse = await request(app).get('/inventory?page=3&limit=5');
    
    expect(page1Response.status).toBe(200);
    expect(lastPageResponse.status).toBe(200);
    
    // Page 1 should have a next page (we have 15 items total)
    expect(page1Response.body.hasNext).toBe(true);
    // Last page should not have a next page
    expect(lastPageResponse.body.hasNext).toBe(false);
  });

  it('validates page parameter', async () => {
    const invalidPageResponses = await Promise.all([
      request(app).get('/inventory?page=0'),
      request(app).get('/inventory?page=-1'),
      request(app).get('/inventory?page=abc'),
      request(app).get('/inventory?page=1.5')
    ]);

    invalidPageResponses.forEach(response => {
      expect(response.status).toBe(400);
      expect(response.body).toMatchObject({
        error: expect.any(String)
      });
    });
  });

  it('validates limit parameter', async () => {
    const invalidLimitResponses = await Promise.all([
      request(app).get('/inventory?limit=0'),
      request(app).get('/inventory?limit=-5'),
      request(app).get('/inventory?limit=xyz'),
      request(app).get('/inventory?limit=1.5'),
      request(app).get('/inventory?limit=101') // exceeds MAX_LIMIT
    ]);

    invalidLimitResponses.forEach(response => {
      expect(response.status).toBe(400);
      expect(response.body).toMatchObject({
        error: expect.any(String)
      });
    });
  });

  it('handles empty results gracefully', async () => {
    const response = await request(app).get('/inventory?page=100&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items).toEqual([]);
    expect(response.body.hasNext).toBe(false);
  });
});
