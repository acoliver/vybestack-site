export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

export class FormValidator {
  private static emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  static validateForm(data: {
    firstName?: string;
    lastName?: string;
    streetAddress?: string;
    city?: string;
    stateProvince?: string;
    postalCode?: string;
    country?: string;
    email?: string;
    phone?: string;
  }): ValidationResult {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields = [
      { field: 'firstName', label: 'First name' },
      { field: 'lastName', label: 'Last name' },
      { field: 'streetAddress', label: 'Street address' },
      { field: 'city', label: 'City' },
      { field: 'stateProvince', label: 'State / Province / Region' },
      { field: 'postalCode', label: 'Postal / Zip code' },
      { field: 'country', label: 'Country' },
      { field: 'email', label: 'Email' },
      { field: 'phone', label: 'Phone number' }
    ];

    for (const { field, label } of requiredFields) {
      const value = data[field as keyof typeof data]?.trim();
      if (!value || value.length === 0) {
        errors.push({
          field,
          message: `${label} is required`
        });
      }
    }

    // Email validation
    if (data.email?.trim()) {
      const email = data.email.trim();
      if (!this.emailRegex.test(email)) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone number validation
    if (data.phone?.trim()) {
      const phone = data.phone.trim();
      // Allow digits, spaces, parentheses, dashes, and leading +
      const phoneRegex = /^[+]?[\d\s()+-]+$/;
      if (!phoneRegex.test(phone)) {
        errors.push({
          field: 'phone',
          message: 'Please enter a valid phone number (digits, spaces, parentheses, dashes, and + allowed)'
        });
      }
    }

    // Postal code validation
    if (data.postalCode?.trim()) {
      const postalCode = data.postalCode.trim();
      // Allow alphanumeric strings (UK "SW1A 1AA", Argentine "C1000", etc.)
      const postalRegex = /^[A-Za-z0-9\s-]+$/;
      if (!postalRegex.test(postalCode)) {
        errors.push({
          field: 'postalCode',
          message: 'Please enter a valid postal code'
        });
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }
}