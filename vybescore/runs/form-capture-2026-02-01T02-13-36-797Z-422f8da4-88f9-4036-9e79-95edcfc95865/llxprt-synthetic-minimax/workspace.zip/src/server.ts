import express, { Request, Response } from 'express';
import path from 'node:path';
import { DatabaseManager, Submission } from './db.js';
import { FormValidator, ValidationResult } from './validation.js';

const app = express();
const db = new DatabaseManager();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.resolve('public')));

// Configure EJS
app.set('view engine', 'ejs');
app.set('views', path.resolve('views'));

// Types for form data
interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Store validation errors and form data between requests
let lastValidationErrors: ValidationResult['errors'] = [];
let lastFormData: FormData = {};

// Routes

// GET / - Render the contact form
app.get('/', (req: Request, res: Response) => {
  res.render('contact-form', {
    errors: lastValidationErrors,
    formData: lastFormData,
    title: 'Contact Us - Definitely Not A Scam'
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName?.trim(),
    lastName: req.body.lastName?.trim(),
    streetAddress: req.body.streetAddress?.trim(),
    city: req.body.city?.trim(),
    stateProvince: req.body.stateProvince?.trim(),
    postalCode: req.body.postalCode?.trim(),
    country: req.body.country?.trim(),
    email: req.body.email?.trim(),
    phone: req.body.phone?.trim()
  };

  // Validate form data
  const validationResult = FormValidator.validateForm(formData);
  
  if (!validationResult.isValid) {
    // Store errors and form data for redisplay
    lastValidationErrors = validationResult.errors;
    lastFormData = formData;
    
    // Re-render form with errors
    res.status(400).render('contact-form', {
      errors: validationResult.errors,
      formData: formData,
      title: 'Contact Us - Definitely Not A Scam'
    });
    return;
  }

  // Clear previous errors and form data
  lastValidationErrors = [];
  lastFormData = {};

  // Prepare submission data
  const submission: Omit<Submission, 'id' | 'createdAt'> = {
    firstName: formData.firstName!,
    lastName: formData.lastName!,
    streetAddress: formData.streetAddress!,
    city: formData.city!,
    stateProvince: formData.stateProvince!,
    postalCode: formData.postalCode!,
    country: formData.country!,
    email: formData.email!,
    phone: formData.phone!
  };

  // Insert into database
  await db.insertSubmission(submission);
  
  // Persist database changes
  await db.persist();

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You - Why Did You Do That?'
  });
});

// Error handling middleware
app.use((error: Error, req: Request, res: Response) => {
  console.error('Server error:', error);
  res.status(500).send('Internal Server Error');
});

// Server lifecycle
let server: ReturnType<typeof app.listen> | null = null;

async function startServer() {
  try {
    // Initialize database
    await db.initialize();
    console.log('Database initialized');

    // Start server
    const port = parseInt(process.env.PORT || '3535', 10);
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
async function shutdown() {
  console.log('Shutting down gracefully...');
  
  if (server) {
    server.close();
  }
  
  await db.close();
  console.log('Database closed');
  
  process.exit(0);
}

// Handle shutdown signals
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start the server
startServer();
