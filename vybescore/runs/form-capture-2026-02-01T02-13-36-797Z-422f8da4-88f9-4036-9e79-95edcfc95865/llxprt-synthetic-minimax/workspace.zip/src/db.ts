import initSqlJs from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

export interface Submission {
  id?: number;
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
  createdAt?: string;
}

export class DatabaseManager {
  private sql: Awaited<ReturnType<typeof initSqlJs>> | null = null;
  private db: import('sql.js').Database | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.resolve('data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    if (this.sql === null) {
      // Use createRequire to get the require function in ES modules context
      const require = createRequire(import.meta.url);
      
      // Resolve the wasm file path
      const wasmPath = require.resolve('sql.js/dist/sql-wasm.wasm');
      
      this.sql = await initSqlJs({
        locateFile: () => wasmPath
      });
    }

    // Create data directory if it doesn't exist
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const filebuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sql!.Database(filebuffer);
    } else {
      this.db = new this.sql!.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) return;

    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;
    
    this.db.exec(schema);
  }

  async insertSubmission(submission: Omit<Submission, 'id' | 'createdAt'>): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    
    // Get the last insert id
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    const resultData = result[0];
    if (!resultData || !resultData.values || !resultData.values[0] || !resultData.values[0][0]) {
      throw new Error('Failed to get insert ID');
    }
    return resultData.values[0][0] as number;
  }

  async getAllSubmissions(): Promise<Submission[]> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      SELECT 
        id, first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone, created_at
      FROM submissions
      ORDER BY created_at DESC
    `);

    const submissions: Submission[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject();
      submissions.push({
        id: row.id as number,
        firstName: row.first_name as string,
        lastName: row.last_name as string,
        streetAddress: row.street_address as string,
        city: row.city as string,
        stateProvince: row.state_province as string,
        postalCode: row.postal_code as string,
        country: row.country as string,
        email: row.email as string,
        phone: row.phone as string,
        createdAt: row.created_at as string
      });
    }

    stmt.free();
    return submissions;
  }

  async persist(): Promise<void> {
    if (!this.db) return;
    
    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}