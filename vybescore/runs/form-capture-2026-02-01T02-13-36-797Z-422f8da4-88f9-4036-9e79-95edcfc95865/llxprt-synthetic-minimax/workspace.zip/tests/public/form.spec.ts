import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { spawn, ChildProcess } from 'node:child_process';

let serverProcess: ChildProcess | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Start the server as a child process
  return new Promise((resolve, reject) => {
    serverProcess = spawn('npm', ['run', 'build'], {
      stdio: 'pipe',
      cwd: process.cwd()
    });

    serverProcess.on('close', (code) => {
      if (code === 0) {
        // Server built successfully, now start it
        serverProcess = spawn('node', ['dist/server.js'], {
          stdio: 'pipe',
          env: { ...process.env, PORT: '3536' }
        });

        serverProcess.stdout.on('data', (data) => {
          console.log('Server output:', data.toString());
          if (data.toString().includes('Server running on port')) {
            resolve(undefined);
          }
        });

        serverProcess.stderr.on('data', (data) => {
          console.error('Server error:', data.toString());
        });

        // Timeout after 10 seconds
        setTimeout(() => {
          reject(new Error('Server failed to start within timeout'));
        }, 10000);
      } else {
        reject(new Error('Build failed'));
      }
    });
  });
});

afterAll(() => {
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
  }
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request('http://localhost:3536')
      .get('/')
      .expect(200);

    const $ = cheerio.load(response.text);
    
    // Check for all form fields
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);

    // Check that all labels are properly associated
    expect($('label[for="firstName"]').length).toBe(1);
    expect($('label[for="lastName"]').length).toBe(1);
    expect($('label[for="streetAddress"]').length).toBe(1);
    expect($('label[for="city"]').length).toBe(1);
    expect($('label[for="stateProvince"]').length).toBe(1);
    expect($('label[for="postalCode"]').length).toBe(1);
    expect($('label[for="country"]').length).toBe(1);
    expect($('label[for="email"]').length).toBe(1);
    expect($('label[for="phone"]').length).toBe(1);

    // Check for CSS file
    expect($('link[href="/styles.css"]').length).toBe(1);
  });

  it('handles form submission with valid data and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'Illinois',
      postalCode: '62701',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 217 555 0123'
    };

    const response = await request('http://localhost:3536')
      .post('/submit')
      .send(formData)
      .expect(302);

    // Check redirect to thank-you page
    expect(response.headers.location).toBe('/thank-you');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Check thank-you page content
    const thankYouResponse = await request('http://localhost:3536')
      .get('/thank-you')
      .expect(200);

    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank You');
    expect($('body').text()).toContain('stranger on the internet');
  });

  it('validates required fields and shows errors', async () => {
    const formData = {
      firstName: '',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'Illinois',
      postalCode: '62701',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 217 555 0123'
    };

    const response = await request('http://localhost:3536')
      .post('/submit')
      .send(formData)
      .expect(400);

    const $ = cheerio.load(response.text);
    
    // Should show error for missing first name
    expect($('.error-message').text()).toContain('First name');
  });

  it('validates email format and shows errors', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'Illinois',
      postalCode: '62701',
      country: 'USA',
      email: 'invalid-email',
      phone: '+1 217 555 0123'
    };

    const response = await request('http://localhost:3536')
      .post('/submit')
      .send(formData)
      .expect(400);

    const $ = cheerio.load(response.text);
    
    // Should show error for invalid email
    expect($('.error-message').text()).toContain('valid email');
  });

  it('accepts international phone numbers', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'Illinois',
      postalCode: '62701',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request('http://localhost:3536')
      .post('/submit')
      .send(formData)
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts international postal codes', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'UK',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request('http://localhost:3536')
      .post('/submit')
      .send(formData)
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });

  it('stores submission data in database', async () => {
    // First clean database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'Alice',
      lastName: 'Johnson',
      streetAddress: '789 Pine Rd',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'alice.johnson@example.com',
      phone: '+54 9 11 1234-5678'
    };

    // Submit form
    await request('http://localhost:3536')
      .post('/submit')
      .send(formData)
      .expect(302);

    // Database should exist with data
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
