declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): unknown;
    exec(sql: string): unknown[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...params: unknown[]): unknown;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
    free(): void;
  }

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  function initSqlJs(options?: { locateFile: (file: string) => string }): Promise<SqlJsStatic>;

  export default initSqlJs;
}