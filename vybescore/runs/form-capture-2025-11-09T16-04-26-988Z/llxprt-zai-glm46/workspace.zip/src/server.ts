import express from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

class FormServer {
  private app: express.Application;
  private db: Database | null = null;
  private server: import('http').Server | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  

  private saveDatabase(): void {
    if (this.db && fs.existsSync(path.join(__dirname, '..', 'data'))) {
      try {
        const data = this.db.export();
        fs.writeFileSync(this.dbPath, Buffer.from(data));
        console.log('Database saved successfully');
      } catch (error) {
        console.error('Failed to save database:', error);
      }
    }
  }

  private validateForm(data: FormData): { isValid: boolean; errors: FormErrors } {
    const errors: FormErrors = {};

    // Required field validation
    if (!data.firstName.trim()) {
      errors.firstName = 'First name is required';
    }
    if (!data.lastName.trim()) {
      errors.lastName = 'Last name is required';
    }
    if (!data.streetAddress.trim()) {
      errors.streetAddress = 'Street address is required';
    }
    if (!data.city.trim()) {
      errors.city = 'City is required';
    }
    if (!data.stateProvince.trim()) {
      errors.stateProvince = 'State/Province/Region is required';
    }
    if (!data.postalCode.trim()) {
      errors.postalCode = 'Postal/Zip code is required';
    }
    if (!data.country.trim()) {
      errors.country = 'Country is required';
    }
    if (!data.email.trim()) {
      errors.email = 'Email is required';
    }
    if (!data.phone.trim()) {
      errors.phone = 'Phone number is required';
    }

    // Email validation (simple regex)
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    // Phone validation (international format)
    if (data.phone && !/^\+?[\d\s\-()]+$/.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  private setupRoutes(): void {
    this.app.get('/', (req, res) => {
      res.render('form', { 
        errors: {}, 
        data: {},
        title: 'Friendly Contact Form'
      });
    });

    this.app.post('/submit', (req, res) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const validation = this.validateForm(formData);
      
      if (!validation.isValid) {
        return res.render('form', {
          errors: validation.errors,
          data: formData,
          title: 'Friendly Contact Form'
        });
      }

      // Insert into database
      try {
        if (this.db) {
          this.db.run(
            `INSERT INTO submissions (
              first_name, last_name, street_address, city, state_province,
              postal_code, country, email, phone
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              formData.firstName,
              formData.lastName,
              formData.streetAddress,
              formData.city,
              formData.stateProvince,
              formData.postalCode,
              formData.country,
              formData.email,
              formData.phone
            ]
          );
          
          this.saveDatabase();
        }
      } catch (error) {
        console.error('Database insertion error:', error);
        return res.status(500).render('form', {
          errors: { general: 'Failed to save submission. Please try again.' },
          data: formData,
          title: 'Friendly Contact Form'
        });
      }

      // Redirect to thank you page
      res.redirect('/thank-you');
    });

    this.app.get('/thank-you', (req, res) => {
      res.render('thank-you', { 
        title: 'Thank You!',
        firstName: req.query.firstName || 'Friend'
      });
    });
  }

  public async start(): Promise<void> {
    try {
      await this.initializeDatabasePublic();
      
      const port = process.env.PORT || 3000;
      this.server = this.app.listen(port, () => {
        console.log(`Server running on port ${port}`);
      });

      // Handle graceful shutdown
      process.on('SIGTERM', () => this.shutdown());
      process.on('SIGINT', () => this.shutdown());
      
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  public async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      let dbData: Uint8Array | undefined;
      if (fs.existsSync(this.dbPath)) {
        const fileBuffer = fs.readFileSync(this.dbPath);
        dbData = new Uint8Array(fileBuffer);
      }
      
      this.db = new SQL.Database(dbData);
      
      // Create table if it doesn't exist
      const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      this.db.run(schema);
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async initializeDatabasePublic(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      let dbData: Uint8Array | undefined;
      if (fs.existsSync(this.dbPath)) {
        const fileBuffer = fs.readFileSync(this.dbPath);
        dbData = new Uint8Array(fileBuffer);
      }
      
      this.db = new SQL.Database(dbData);
      
      // Create table if it doesn't exist
      const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      this.db.run(schema);
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  public getApp(): express.Application {
    return this.app;
  }

  private shutdown(): void {
    console.log('Shutting down server...');
    if (this.server) {
      this.server.close(() => {
        console.log('Server closed');
        if (this.db) {
          this.db.close();
          console.log('Database closed');
        }
        process.exit(0);
      });
    }
  }
}

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new FormServer();
  server.start();
}

export default FormServer;