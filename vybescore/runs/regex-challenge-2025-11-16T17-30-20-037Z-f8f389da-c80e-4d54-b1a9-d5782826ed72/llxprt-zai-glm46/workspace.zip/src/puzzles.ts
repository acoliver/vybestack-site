/**
 * Finds words starting with a given prefix while excluding specified exceptions:
 * - Returns array of matched words
 * - Case-sensitive matching
 * - Excludes any words in the exceptions array
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in prefix and create word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*`, 'g');
  
  const matches = text.match(wordPattern) || [];
  const exceptionSet = new Set(exceptions);
  
  // Filter out exceptions and return unique words
  return [...new Set(matches.filter(word => !exceptionSet.has(word)))];
}

/**
 * Finds occurrences of a token that appear after a digit and not at string start:
 * - Uses lookbehind to ensure token follows a digit
 * - Uses negative lookbehind to exclude string start
 * - Returns array of matched tokens (not positions)
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: token preceded by digit, not at start of string
  const pattern = new RegExp(`(?<!^)(?<=\\d)${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Extract the full matched token (digit + token)
    const fullMatch = match[0];
    // Find the digit that precedes the token
    const digitIndex = match.index - 1;
    if (digitIndex >= 0 && /\d/.test(text[digitIndex])) {
      matches.push(text[digitIndex] + fullMatch);
    }
  }
  
  return matches;
}

/**
 * Validates password strength with these requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const repeatedPattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (repeatedPattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses while excluding IPv4 addresses:
 * - Supports shorthand notation (e.g., ::1)
 * - Handles compressed zeros with ::
 * - Ensures IPv4 addresses don't trigger positive results
 * - Returns true if IPv6 is detected, false otherwise
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 regex patterns - simplified approach
  const ipv6Patterns = [
    // Full IPv6: 8 groups of 1-4 hex digits separated by colons
    /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    // Compressed zeros with ::
    /([0-9a-fA-F]{1,4}:){1,7}:/,
    /:[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,6}/,
    // General IPv6 pattern with :: compression
    /[0-9a-fA-F]{0,4}::[0-9a-fA-F]{0,4}/,
    // Single :: for compressed zeros
    /::[0-9a-fA-F]{1,4}/,
    /[0-9a-fA-F]{1,4}::/
  ];
  
  // IPv4 pattern to exclude - only if the entire string is IPv4
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // Check if the entire string is a pure IPv4 address
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Look for IPv6 patterns in the text
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      // Ensure we have valid IPv6 characters and structure
      const match = value.match(pattern);
      const candidate = match ? match[0] : '';
      
      // Must contain at least one colon for IPv6
      if (candidate.includes(':')) {
        // Additional validation: ensure it has valid IPv6 characters only
        if (/[0-9a-fA-F:]/.test(candidate) && !/[g-zG-Z]/.test(candidate)) {
          return true;
        }
      }
    }
  }
  
  return false;
}