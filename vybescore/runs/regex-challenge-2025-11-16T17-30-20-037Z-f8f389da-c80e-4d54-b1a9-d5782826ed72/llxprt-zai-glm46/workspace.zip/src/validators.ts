export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with support for:
 * - Unicode letters, digits, and special characters
 * - Plus tags (+tag)
 * - Common domain formats (example.com, example.co.uk)
 * - Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic structure validation
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  const [, domain] = value.split('@');
  
  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain must have at least one dot
  if (!domain.includes('.')) {
    return false;
  }
  
  // Domain labels must be valid
  const domainLabels = domain.split('.');
  for (const label of domainLabels) {
    if (label.length === 0 || label.length > 63) {
      return false;
    }
    // Domain labels cannot start or end with hyphen
    if (label.startsWith('-') || label.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers with support for:
 * - Format: (212) 555-7890, 212-555-7890, 2125557890, +1-212-555-7890
 * - Optional +1 country code
 * - Area codes cannot start with 0 or 1
 * - 10-digit format minimum
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except + at start
  const normalized = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 country code
  let mainNumber = normalized;
  if (mainNumber.startsWith('+1')) {
    mainNumber = mainNumber.substring(2);
  } else if (mainNumber.startsWith('1') && mainNumber.length > 10) {
    mainNumber = mainNumber.substring(1);
  }
  
  // Must be exactly 10 digits for standard US numbers
  if (mainNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = mainNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if extensions are allowed and present
  if (options?.allowExtensions) {
    const extMatch = value.match(/ext\.?\s*(\d+)$/i);
    if (extMatch && extMatch[1].length > 0) {
      return true;
    }
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers with support for:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9
 * - Area codes: 2-4 digits (starting with 1-9)
 * - Subscriber numbers: 6-8 digits
 * - Formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators for validation
  const normalized = value.replace(/[-\s]/g, '');
  
  // Basic validation - must contain only digits and optional + at start
  if (!/^\+?\d+$/.test(normalized)) {
    return false;
  }
  
  // Check for optional country code
  let mainNumber = normalized;
  if (mainNumber.startsWith('+54')) {
    mainNumber = mainNumber.substring(3);
  }
  
  // If no country code, must start with trunk prefix 0
  if (!normalized.startsWith('+54') && !mainNumber.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix
  if (mainNumber.startsWith('0')) {
    mainNumber = mainNumber.substring(1);
  }
  
  // Check for optional mobile indicator
  if (mainNumber.startsWith('9')) {
    mainNumber = mainNumber.substring(1);
  }
  
  // Must have at least 8 digits remaining (2-4 for area code + 6-8 for subscriber)
  if (mainNumber.length < 8) {
    return false;
  }
  
  // Try different area code lengths (2-4 digits)
  for (let areaCodeLen = 2; areaCodeLen <= 4; areaCodeLen++) {
    if (mainNumber.length < areaCodeLen + 6) continue;
    
    const areaCode = mainNumber.substring(0, areaCodeLen);
    const subscriber = mainNumber.substring(areaCodeLen);
    
    // Area code must start with 1-9 and contain only digits
    if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
      continue;
    }
    
    // Subscriber must be 6-8 digits
    if (/^\d{6,8}$/.test(subscriber)) {
      return true;
    }
  }
  
  return false;
}

/**
 * Validates personal names with support for:
 * - Unicode letters and accented characters
 * - Apostrophes, hyphens, and spaces
 * - Rejects digits, symbols, and unconventional patterns
 */
export function isValidName(value: string): boolean {
  // Must not be empty or contain only whitespace
  if (!value || !value.trim()) {
    return false;
  }
  
  // Reject digits and most special characters
  if (/[\d@#$%^&*()_+=[\]{}|:";<>,.?/]/.test(value)) {
    return false;
  }
  
  // Allow Unicode letters, accents, apostrophes, hyphens, spaces, and dots (for initials)
  const nameRegex = /^[\p{L}\p{M}'\-.\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject obviously invalid patterns like "X Æ A-12"
  if (/[Æ]/.test(value) && /\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm implementation for credit card validation
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  let sum = 0;
  let doubleDigit = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers with support for:
 * - Visa (starts with 4, 13-19 digits)
 * - Mastercard (starts with 51-55, 2221-2720, 16 digits)
 * - American Express (starts with 34, 37, 15 digits)
 * - Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const normalized = value.replace(/\D/g, '');
  
  // Check length and format for different card types
  const visaRegex = /^4\d{12}(?:\d{3})?$/; // 13-19 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/; // 16 digits, starts with 51-55 or 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  // Check if it matches any supported card type
  const isValidFormat = visaRegex.test(normalized) || mastercardRegex.test(normalized) || amexRegex.test(normalized);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(normalized);
}