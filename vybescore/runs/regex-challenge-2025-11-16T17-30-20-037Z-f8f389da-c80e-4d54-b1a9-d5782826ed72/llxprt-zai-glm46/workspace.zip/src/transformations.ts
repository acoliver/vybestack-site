/**
 * Capitalizes the first character of each sentence while:
 * - Preserving spacing between sentences
 * - Handling sentence boundaries (.?!)
 * - Leaving abbreviations intact when possible
 * - Collapsing extra spaces sensibly
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spacing around sentence punctuation
  let normalized = text.replace(/\s+([.!?])/g, '$1').replace(/([.!?])(?!\s|$)/g, '$1 ');
  
  // Then collapse multiple spaces to single spaces
  normalized = normalized.replace(/\s+/g, ' ').trim();
  
  // Capitalize first letter of sentences
  return normalized.replace(/(?:^|[.!?]\s+)([a-z])/g, (match) => {
    return match.toUpperCase();
  });
}

/**
 * Extracts URLs from text with support for:
 * - HTTP/HTTPS protocols
 * - WWW domains
 * - Common URL structures
 * - Excluding trailing punctuation
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Enhanced URL regex with better matching and exclusion of trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s<>"]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Filter and clean URLs
  return matches
    .map(url => {
      // Remove trailing punctuation
      return url.replace(/[.,;:!?)\]}]+$/g, '');
    })
    .filter(url => {
      // Basic validation - ensure it looks like a URL
      const hasDomain = /\.[a-zA-Z]{2,}/.test(url);
      const hasValidChars = /^[a-zA-Z0-9./:?#[\]@!$&'()*+,;=%]+$/.test(url);
      return hasDomain && hasValidChars;
    })
    .filter((url, index, arr) => arr.indexOf(url) === index); // Remove duplicates
}

/**
 * Converts HTTP URLs to HTTPS while leaving existing HTTPS URLs untouched:
 * - Only affects http:// schemes
 * - Preserves the rest of the URL unchanged
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs with these rules:
 * - Always upgrade http:// to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  return text.replace(/https?:\/\/([^/]+)(\/[^\s"']*)/g, (match, host, path) => {
    // Always upgrade to HTTPS
    let newUrl = 'https://' + host;
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    const docsPathMatch = path.match(/^(\/docs\/.*)/);
    const hasDynamicHints = /[?&=]|\/cgi-bin\/|\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|$)/.test(path);
    
    if (docsPathMatch && !hasDynamicHints) {
      // Rewrite to docs.example.com while preserving the docs path
      const docsPath = docsPathMatch[1];
      newUrl = `https://docs.example.com${docsPath}`;
    } else {
      // Just upgrade to HTTPS, keep original host
      newUrl += path;
    }
    
    return newUrl;
  });
}

/**
 * Extracts year from mm/dd/yyyy format:
 * - Returns the 4-digit year for valid mm/dd/yyyy dates
 * - Returns 'N/A' if format doesn't match or month/day are invalid
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for specific month-day combinations
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  if (isLeapYear) {
    daysInMonth[1] = 29; // February has 29 days in leap year
  }
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}