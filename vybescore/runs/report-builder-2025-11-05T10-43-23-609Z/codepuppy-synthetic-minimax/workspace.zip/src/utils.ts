import type { ReportData, ReportEntry } from './types.js';

export function parseReportData(jsonContent: string): ReportData {
  let data: unknown;
  
  try {
    data = JSON.parse(jsonContent);
  } catch (error) {
    throw new Error('Invalid JSON provided');
  }
  
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  // Validate required fields
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title field (expected string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary field (expected string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries field (expected array)');
  }
  
  // Validate entries
  const entries: ReportEntry[] = [];
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid label field (expected string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid amount field (expected number)`);
    }
    
    entries.push({
      label: entryObj.label,
      amount: entryObj.amount
    });
  }
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries
  };
}

export function parseArguments(args: string[]): {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataFile = args[2];
  
  if (!dataFile) {
    throw new Error('Data file path is required');
  }
  
  if (args[3] !== '--format') {
    throw new Error('Missing --format argument');
  }
  
  const format = args[4];
  
  if (!format) {
    throw new Error('Format is required');
  }
  
  const result = {
    dataFile,
    format,
    outputPath: undefined as string | undefined,
    includeTotals: false
  };
  
  // Parse optional arguments
  for (let i = 5; i < args.length; i++) {
    if (args[i] === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a path argument');
      }
      result.outputPath = args[i + 1];
      i++; // Skip the path argument
    } else if (args[i] === '--includeTotals') {
      result.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${args[i]}`);
    }
  }
  
  return result;
}