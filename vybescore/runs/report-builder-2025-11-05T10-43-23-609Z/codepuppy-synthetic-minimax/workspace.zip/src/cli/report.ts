#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions } from '../types.js';
import { getFormatter } from '../formatters.js';
import { parseArguments, parseReportData } from '../utils.js';

function main(): void {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArguments(process.argv);
    
    // Read and parse the JSON data
    const jsonContent = readFileSync(dataFile, { encoding: 'utf8' });
    const reportData: ReportData = parseReportData(jsonContent);
    
    // Get the appropriate formatter
    const formatter = getFormatter(format);
    
    // Render the report
    const options: ReportOptions = { includeTotals };
    const output = formatter.render(reportData, options);
    
    // Write the output
    if (outputPath) {
      writeFileSync(outputPath, output, { encoding: 'utf8' });
    } else {
      process.stdout.write(output);
    }
    
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    process.stderr.write(errorMessage);
    process.exit(1);
  }
}

// Check if this file is being run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}