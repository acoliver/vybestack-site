import type { ReportFormatter } from './types.js';
import { markdownFormatter } from './formats/markdown.js';
import { textFormatter } from './formats/text.js';

export const formatters: Record<string, ReportFormatter> = {
  markdown: markdownFormatter,
  text: textFormatter
};

export function getSupportedFormats(): string[] {
  return Object.keys(formatters);
}

export function getFormatter(format: string): ReportFormatter {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}