import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';

export const renderText: ReportFormatter['render'] = (data: ReportData, options: ReportOptions): string => {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries heading
  lines.push('Entries:');
  
  // Entries list
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }
  
  // Optional total
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
};

export const textFormatter: ReportFormatter = {
  render: renderText
};