/**
 * Encode plain text to Base64 using standard Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 */
export function decode(input: string): string {
  const INVALID_BASE64_ERROR = 'Invalid Base64 input';
  
  // Remove whitespace
  const cleaned = input.replace(/\s+/g, '');
  
  // Check if input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(cleaned)) {
    throw new Error(INVALID_BASE64_ERROR);
  }
  
  // Add padding if missing
  const normalized = cleaned + '='.repeat((4 - cleaned.length % 4) % 4);

  try {
    const decoded = Buffer.from(normalized, 'base64');
    // Verify the decoded buffer can be converted back to valid UTF-8 string
    const result = decoded.toString('utf8');
    // Additional validation: check if the result doesn't contain replacement characters
    // which would indicate invalid UTF-8
    if (result.includes('�')) {
      throw new Error(INVALID_BASE64_ERROR);
    }
    return result;
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
