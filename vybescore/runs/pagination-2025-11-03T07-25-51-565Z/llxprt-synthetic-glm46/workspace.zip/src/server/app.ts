import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page: must be a positive integer
    let page: number | undefined;
    if (pageParam === undefined) {
      page = 1;
    } else {
      const parsedPage = Number(pageParam);
      if (isNaN(parsedPage) || parsedPage <= 0 || !Number.isInteger(parsedPage) || parsedPage > 1000) {
        return res.status(400).json({ error: 'Page must be a positive integer no greater than 1000' });
      }
      page = parsedPage;
    }

    // Validate limit: must be a positive integer
    let limit: number | undefined;
    if (limitParam === undefined) {
      limit = 5;
    } else {
      const parsedLimit = Number(limitParam);
      if (isNaN(parsedLimit) || parsedLimit <= 0 || !Number.isInteger(parsedLimit) || parsedLimit > 100) {
        return res.status(400).json({ error: 'Limit must be a positive integer no greater than 100' });
      }
      limit = parsedLimit;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
