declare module 'sql.js' {
  export interface Database {
    exec(sql: string): void;
    prepare(sql: string): any;
    export(): Uint8Array;
    close(): void;
  }

  export function initSqlJs(config?: {
    locateFile?: (file: string) => string;
  }): Promise<{
    Database: new (buffer?: ArrayBuffer) => Database;
  }>;
}