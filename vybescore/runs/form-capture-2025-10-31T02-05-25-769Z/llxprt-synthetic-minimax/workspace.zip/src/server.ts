import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Types for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

// Database setup
let db: any = null;
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

async function initDatabase(): Promise<void> {
  try {
    const initSql: any = await (initSqlJs as any)({
      locateFile: (file: string) => {
        return require.resolve(`sql.js/dist/${file}`);
      },
    });

    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      db = new initSql.Database(fileBuffer);
    } else {
      db = new initSql.Database();
      
      // Read and execute schema
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
      db.exec(schema);
      
      // Save initial database
      const data = db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(data));
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Validation functions
function validateFormData(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName.trim()) {
    errors.firstName = 'First name is required';
  }
  if (!data.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }
  if (!data.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  if (!data.city.trim()) {
    errors.city = 'City is required';
  }
  if (!data.stateProvince.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  if (!data.postalCode.trim()) {
    errors.postalCode = 'Postal/ZIP code is required';
  }
  if (!data.country.trim()) {
    errors.country = 'Country is required';
  }
  if (!data.email.trim()) {
    errors.email = 'Email is required';
  }
  if (!data.phone.trim()) {
    errors.phone = 'Phone number is required';
  }

  // Email validation
  if (data.email.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation (international formats)
  if (data.phone.trim()) {
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode.trim()) {
    const postalRegex = /^[a-zA-Z0-9\s\-]+$/;
    if (!postalRegex.test(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal/ZIP code';
    }
  }

  return errors;
}

// Express app setup
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    formData: {},
    title: 'Contact Us - Definitely Not A Scam'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateFormData(formData);

  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', {
      errors,
      formData,
      title: 'Contact Us - Definitely Not A Scam'
    });
  }

  if (!db) {
    return res.status(500).send('Database not initialized');
  }

  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);

    stmt.free();

    // Save database to disk
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving to database:', error);
    res.status(500).send('Error saving submission');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Try to get first name from the last submission
  let firstName = 'there';
  
  if (db) {
    try {
      const result = db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      if (result.length > 0 && result[0].values.length > 0) {
        firstName = result[0].values[0][0] as string;
      }
    } catch (error) {
      console.error('Error fetching first name:', error);
    }
  }

  res.render('thank-you', { 
    firstName,
    title: 'Thank You!'
  });
});

// Error handler
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`\nReceived ${signal}. Shutting down gracefully...`);
  
  if (db) {
    try {
      const data = db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(data));
      db.close();
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
}

// Register shutdown handlers
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
initDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Visit http://localhost:${PORT}`);
  });
});