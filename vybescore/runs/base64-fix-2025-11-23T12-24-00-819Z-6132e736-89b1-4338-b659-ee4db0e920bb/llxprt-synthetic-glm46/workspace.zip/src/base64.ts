/**
 * Encode plain text to Base64 using canonical alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate if a string is valid Base64 format.
 */
function isValidBase64(input: string): boolean {
  // Check if input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  try {
    // Test if Node.js Buffer can decode it successfully
    // This is the most reliable validation for Base64
    const decoded = Buffer.from(input, 'base64').toString('utf8');
    
    // Verify that encoding the decoded result matches the original (with padding normalized)
    // This ensures the input was valid Base64
    const normalizedInput = input.replace(/=+$/, '');
    const reencoded = Buffer.from(decoded, 'utf8').toString('base64').replace(/=+$/, '');
    return normalizedInput === reencoded;
  } catch {
    return false;
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 with or without padding and rejects invalid input.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}