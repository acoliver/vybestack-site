/**
 * Base64 alphabet validation regex for canonical RFC 4648 Base64
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate whether a string is properly formatted Base64
 * Only accepts the canonical Base64 alphabet with optional padding
 */
function isValidBase64(input: string): boolean {
  // Remove whitespace and check length
  const clean = input.replace(/\s/g, '');
  
  // Check basic format
  if (!BASE64_REGEX.test(clean)) {
    return false;
  }
  
  // Check padding rules
  const paddingIndex = clean.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const padding = clean.slice(paddingIndex);
    // Only 0, 1, or 2 padding chars allowed
    if (padding.length > 2) {
      return false;
    }
    // Total length must be divisible by 4 (including padding)
    if (clean.length % 4 !== 0) {
      return false;
    }
  } else {
    // Without padding, length must still be valid
    if (clean.length % 4 !== 0) {
      return false;
    }
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using canonical RFC 4648 format.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  // Use standard Base64 encoding with Buffer's built-in 'base64' encoding
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid input.
 * Uses the canonical Base64 alphabet as specified in RFC 4648.
 */
export function decode(input: string): string {
  // Remove whitespace first
  const clean = input.replace(/\s/g, '');
  
  // Validate input format
  if (!isValidBase64(clean)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    // Use Node.js's built-in Base64 decoding
    return Buffer.from(clean, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}