import express, { type Express, Request, Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;

function validatePageLimit(
  pageParam: string | undefined,
  limitParam: string | undefined
): { page: number; limit: number } | { error: string } {
  const page = pageParam ? Number(pageParam) : 1;
  const limit = limitParam ? Number(limitParam) : 5;

  // Validate page parameter
  if (pageParam !== undefined) {
    if (isNaN(page)) {
      return { error: 'Invalid page: must be a number' };
    }
    if (!Number.isInteger(page)) {
      return { error: 'Invalid page: must be an integer' };
    }
    if (page < 1) {
      return { error: 'Invalid page: must be greater than 0' };
    }
  }

  // Validate limit parameter
  if (limitParam !== undefined) {
    if (isNaN(limit)) {
      return { error: 'Invalid limit: must be a number' };
    }
    if (!Number.isInteger(limit)) {
      return { error: 'Invalid limit: must be an integer' };
    }
    if (limit < 1) {
      return { error: 'Invalid limit: must be greater than 0' };
    }
    if (limit > MAX_LIMIT) {
      return { error: `Invalid limit: must not exceed ${MAX_LIMIT}` };
    }
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const validation = validatePageLimit(
      req.query.page as string | undefined,
      req.query.limit as string | undefined
    );

    if ('error' in validation) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const payload = listInventory(db, validation);
    res.json(payload);
  });

  return app;
}
