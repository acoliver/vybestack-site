/**
 * Form submission data structure
 */
export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

/**
 * Validation error structure
 */
export interface ValidationError {
  field: string;
  message: string;
}

/**
 * Form render data including values and errors
 */
export interface FormRenderData {
  values: Partial<FormData>;
  errors?: string[];
}

/**
 * Database row structure for submissions
 */
export interface SubmissionRow {
  id: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at: string;
}
