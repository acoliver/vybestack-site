import { FormData } from './types.js';

export interface ValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * Trim and normalize string input
 */
function normalizeInput(value: string): string {
  return value.trim();
}

/**
 * Validate required field is not empty
 */
function validateRequired(value: string, fieldName: string): string | null {
  const normalized = normalizeInput(value);
  if (!normalized) {
    return `${fieldName} is required`;
  }
  return null;
}

/**
 * Validate email format with simple regex
 */
function validateEmail(value: string): string | null {
  const normalized = normalizeInput(value);
  if (!normalized) {
    return 'Email is required';
  }

  // Simple email regex - checks for basic email structure
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(normalized)) {
    return 'Please enter a valid email address';
  }

  return null;
}

/**
 * Validate phone number format
 * Accepts digits, spaces, parentheses, dashes, and optional leading +
 */
function validatePhone(value: string): string | null {
  const normalized = normalizeInput(value);
  if (!normalized) {
    return 'Phone number is required';
  }

  // Allow leading +, then digits, spaces, parentheses, dashes
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  if (!phoneRegex.test(normalized)) {
    return 'Please enter a valid phone number';
  }

  // Ensure there's at least one digit
  if (!/\d/.test(normalized)) {
    return 'Phone number must contain at least one digit';
  }

  return null;
}

/**
 * Validate postal code format
 * Accepts alphanumeric strings with spaces
 */
function validatePostalCode(value: string): string | null {
  const normalized = normalizeInput(value);
  if (!normalized) {
    return 'Postal / Zip code is required';
  }

  // Allow alphanumeric characters and spaces
  const postalRegex = /^[\dA-Za-z\s]+$/;
  if (!postalRegex.test(normalized)) {
    return 'Please enter a valid postal / zip code';
  }

  return null;
}

/**
 * Validate all form fields
 */
export function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  // Validate required text fields
  const requiredFields: Array<keyof FormData> = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'country',
  ];

  const fieldLabels: Record<string, string> = {
    firstName: 'First name',
    lastName: 'Last name',
    streetAddress: 'Street address',
    city: 'City',
    stateProvince: 'State / Province / Region',
    country: 'Country',
  };

  for (const field of requiredFields) {
    const value = data[field];
    const label = fieldLabels[field];
    const error = validateRequired(value || '', label);
    if (error) {
      errors.push(error);
    }
  }

  // Validate email
  if (data.email !== undefined) {
    const emailError = validateEmail(data.email);
    if (emailError) {
      errors.push(emailError);
    }
  }

  // Validate phone
  if (data.phone !== undefined) {
    const phoneError = validatePhone(data.phone);
    if (phoneError) {
      errors.push(phoneError);
    }
  }

  // Validate postal code
  if (data.postalCode !== undefined) {
    const postalError = validatePostalCode(data.postalCode);
    if (postalError) {
      errors.push(postalError);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Normalize and sanitize form data
 */
export function normalizeFormData(data: Partial<FormData>): FormData {
  return {
    firstName: normalizeInput(data.firstName || ''),
    lastName: normalizeInput(data.lastName || ''),
    streetAddress: normalizeInput(data.streetAddress || ''),
    city: normalizeInput(data.city || ''),
    stateProvince: normalizeInput(data.stateProvince || ''),
    postalCode: normalizeInput(data.postalCode || ''),
    country: normalizeInput(data.country || ''),
    email: normalizeInput(data.email || ''),
    phone: normalizeInput(data.phone || ''),
  };
}
