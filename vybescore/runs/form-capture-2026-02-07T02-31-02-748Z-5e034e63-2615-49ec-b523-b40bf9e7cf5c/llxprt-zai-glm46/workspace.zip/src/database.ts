import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';
import { FormData, SubmissionRow } from './types.js';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

let db: Database | null = null;
let sqlJsInitialized = false;

/**
 * Initialize SQL.js and create/load the database
 */
export async function initializeDatabase(): Promise<void> {
  if (sqlJsInitialized && db) {
    return;
  }

  const SQL = await initSqlJs({});
  sqlJsInitialized = true;

  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    // Create schema from file
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

/**
 * Save database to disk
 */
export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

/**
 * Insert a form submission into the database
 */
export function insertSubmission(formData: FormData): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone,
  ]);

  stmt.free();
  saveDatabase();
}

/**
 * Get all submissions from the database
 */
export function getAllSubmissions(): SubmissionRow[] {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const result = db.exec('SELECT * FROM submissions ORDER BY created_at DESC');
  
  if (result.length === 0) {
    return [];
  }

  const rows = result[0];
  const submissions: SubmissionRow[] = [];

  for (let i = 0; i < rows.values.length; i++) {
    const values = rows.values[i];
    submissions.push({
      id: values[0] as number,
      first_name: values[1] as string,
      last_name: values[2] as string,
      street_address: values[3] as string,
      city: values[4] as string,
      state_province: values[5] as string,
      postal_code: values[6] as string,
      country: values[7] as string,
      email: values[8] as string,
      phone: values[9] as string,
      created_at: values[10] as string,
    });
  }

  return submissions;
}

/**
 * Close the database connection
 */
export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

/**
 * Check if database is initialized
 */
export function isDatabaseInitialized(): boolean {
  return db !== null;
}
