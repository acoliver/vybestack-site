import express, { Request, Response, Router } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, insertSubmission, closeDatabase } from './database.js';
import { validateForm, normalizeFormData } from './validation.js';
import { FormRenderData } from './types.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || '3535';

const app = express();
let server: ReturnType<typeof app.listen> | null = null;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set up EJS - templates are in src/templates whether running from src or dist
const templatesPath = path.join(__dirname, '../src/templates');
app.set('view engine', 'ejs');
app.set('views', templatesPath);

// Routes
const router = Router();

/**
 * GET / - Render the form
 */
router.get('/', (req: Request, res: Response) => {
  const renderData: FormRenderData = {
    values: {},
    errors: [],
  };
  res.render('form', renderData);
});

/**
 * POST /submit - Handle form submission
 */
router.post('/submit', (req: Request, res: Response) => {
  const formData = normalizeFormData(req.body);
  const validation = validateForm(formData);

  if (!validation.valid) {
    const renderData: FormRenderData = {
      values: formData,
      errors: validation.errors,
    };
    return res.status(400).render('form', renderData);
  }

  // Save to database
  insertSubmission(formData);

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

/**
 * GET /thank-you - Render thank you page
 */
router.get('/thank-you', (req: Request, res: Response) => {
  // Get the first name from the most recent submission if available
  // For simplicity, we'll just render the template without context
  // The template uses firstName variable but we don't have session state
  // We'll pass an empty string as fallback
  res.render('thank-you', { firstName: 'friend' });
});

app.use('/', router);

/**
 * Start the server
 */
export async function startServer(): Promise<void> {
  await initializeDatabase();
  
  return new Promise((resolve, reject) => {
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      resolve();
    });

    // Handle server errors
    server.on('error', (error: NodeJS.ErrnoException) => {
      if (error.syscall !== 'listen') {
        reject(error);
        return;
      }

      const bind = typeof PORT === 'string' ? `Pipe ${PORT}` : `Port ${PORT}`;

      switch (error.code) {
        case 'EACCES': {
          const error1 = new Error(`${bind} requires elevated privileges`);
          console.error(error1.message);
          reject(error1);
          break;
        }
        case 'EADDRINUSE': {
          const error2 = new Error(`${bind} is already in use`);
          console.error(error2.message);
          reject(error2);
          break;
        }
        default:
          reject(error);
      }
    });
  });
}

/**
 * Stop the server gracefully
 */
export async function stopServer(): Promise<void> {
  return new Promise((resolve) => {
    if (server) {
      server.close(() => {
        console.log('Server closed');
        closeDatabase();
        resolve();
      });
    } else {
      closeDatabase();
      resolve();
    }
  });
}

/**
 * Get the server instance for testing
 */
export function getServerInstance(): typeof server {
  return server;
}

/**
 * Graceful shutdown handler
 */
function setupGracefulShutdown(): void {
  const shutdown = async (signal: string): Promise<void> => {
    console.log(`Received ${signal}, shutting down gracefully...`);
    await stopServer();
    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  setupGracefulShutdown();
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

// Export app for testing
export default app;
