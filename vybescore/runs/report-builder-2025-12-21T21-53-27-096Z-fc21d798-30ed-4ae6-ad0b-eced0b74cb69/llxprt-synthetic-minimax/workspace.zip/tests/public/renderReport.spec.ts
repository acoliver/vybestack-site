import { describe, expect, it } from 'vitest';
import { renderMarkdown } from '../../src/formats/markdown.js';
import { renderText } from '../../src/formats/text.js';
import { ReportData } from '../../src/types.js';
import { execSync } from 'child_process';
import { writeFileSync, unlinkSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';

const testData: ReportData = {
  title: "Quarterly Financial Summary",
  summary: "Highlights include record revenue across regions and a healthy outlook for the next quarter.",
  entries: [
    { label: "North Region", amount: 12345.67 },
    { label: "South Region", amount: 23456.78 },
    { label: "West Region", amount: 34567.89 }
  ]
};

describe('report CLI (public smoke)', () => {
  it('renders markdown format without totals', () => {
    const result = renderMarkdown.format(testData, { includeTotals: false });
    
    const expected = `# ${testData.title}

${testData.summary}

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89`;
    
    expect(result).toBe(expected);
  });

  it('renders markdown format with totals', () => {
    const result = renderMarkdown.format(testData, { includeTotals: true });
    
    const expected = `# ${testData.title}

${testData.summary}

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89

**Total:** $70370.34`;
    
    expect(result).toBe(expected);
  });

  it('renders text format without totals', () => {
    const result = renderText.format(testData, { includeTotals: false });
    
    const expected = `${testData.title}

${testData.summary}

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89`;
    
    expect(result).toBe(expected);
  });

  it('renders text format with totals', () => {
    const result = renderText.format(testData, { includeTotals: true });
    
    const expected = `${testData.title}

${testData.summary}

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89

Total: $70370.34`;
    
    expect(result).toBe(expected);
  });

  it('CLI integration - markdown format with totals', () => {
    // Create a temporary test JSON file
    const testFile = join(tmpdir(), 'test-report.json');
    writeFileSync(testFile, JSON.stringify(testData, null, 2));
    
    try {
      const command = `node dist/cli/report.js ${testFile} --format markdown --includeTotals`;
      const result = execSync(command, { encoding: 'utf-8' });
      
      const expected = `# ${testData.title}

${testData.summary}

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89

**Total:** $70370.34
`;
      
      expect(result).toBe(expected);
    } finally {
      // Clean up
      unlinkSync(testFile);
    }
  });

  it('CLI integration - text format without totals', () => {
    // Create a temporary test JSON file
    const testFile = join(tmpdir(), 'test-report.json');
    writeFileSync(testFile, JSON.stringify(testData, null, 2));
    
    try {
      const command = `node dist/cli/report.js ${testFile} --format text`;
      const result = execSync(command, { encoding: 'utf-8' });
      
      const expected = `${testData.title}

${testData.summary}

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89
`;
      
      expect(result).toBe(expected);
    } finally {
      // Clean up
      unlinkSync(testFile);
    }
  });

  it('CLI integration - unsupported format error', () => {
    const testFile = join(tmpdir(), 'test-report.json');
    writeFileSync(testFile, JSON.stringify(testData, null, 2));
    
    try {
      const command = `node dist/cli/report.js ${testFile} --format csv`;
      expect(() => {
        execSync(command, { encoding: 'utf-8' });
      }).toThrow();
    } finally {
      unlinkSync(testFile);
    }
  });

  it('CLI integration - malformed JSON error', () => {
    const testFile = join(tmpdir(), 'malformed.json');
    writeFileSync(testFile, '{ "invalid": json }');
    
    try {
      const command = `node dist/cli/report.js ${testFile} --format markdown`;
      expect(() => {
        execSync(command, { encoding: 'utf-8' });
      }).toThrow();
    } finally {
      unlinkSync(testFile);
    }
  });

  it('CLI integration - missing required fields error', () => {
    const invalidData = { title: "Test" }; // Missing required fields
    const testFile = join(tmpdir(), 'invalid-report.json');
    writeFileSync(testFile, JSON.stringify(invalidData));
    
    try {
      const command = `node dist/cli/report.js ${testFile} --format markdown`;
      expect(() => {
        execSync(command, { encoding: 'utf-8' });
      }).toThrow();
    } finally {
      unlinkSync(testFile);
    }
  });
});
