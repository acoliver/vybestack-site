import { ReportData, Formatter, FormatOptions } from '../types.js';

export const renderText: Formatter = {
  format(data: ReportData, options: FormatOptions): string {
    const total = data.entries.reduce((sum: number, entry: { amount: number }) => sum + entry.amount, 0);
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries heading
    lines.push('Entries:');
    
    // Entry list
    for (const entry of data.entries) {
      const amount = entry.amount.toFixed(2);
      lines.push(`- ${entry.label}: $${amount}`);
    }
    
    // Total if requested
    if (options.includeTotals) {
      lines.push('');
      const totalFormatted = total.toFixed(2);
      lines.push(`Total: $${totalFormatted}`);
    }
    
    return lines.join('\n');
  }
};