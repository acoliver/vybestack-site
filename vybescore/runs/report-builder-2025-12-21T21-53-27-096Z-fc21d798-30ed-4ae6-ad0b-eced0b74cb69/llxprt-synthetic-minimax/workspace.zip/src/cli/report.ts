import { readFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { writeFileSync } from 'fs';

interface ParsedArgs {
  dataFile: string;
  options: CLIOptions;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args = argv.slice(2);
  
  if (args.length < 2) {
    throw new Error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataFile = args[0];
  
  if (!dataFile.endsWith('.json')) {
    throw new Error('Input file must be a JSON file');
  }
  
  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const nextArg = args[++i];
      if (!nextArg) {
        throw new Error('--format requires a value');
      }
      if (nextArg !== 'markdown' && nextArg !== 'text') {
        throw new Error(`Unsupported format: ${nextArg}. Supported formats: markdown, text`);
      }
      format = nextArg;
    } else if (arg === '--output') {
      output = args[++i];
      if (!output) {
        throw new Error('--output requires a value');
      }
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  
  if (!format) {
    throw new Error('--format is required. Supported formats: markdown, text');
  }
  
  return { dataFile, options: { format, output, includeTotals } };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('JSON data must be an object');
  }
  
  const reportData = data as Record<string, unknown>;
  
  // Check required fields
  if (typeof reportData.title !== 'string') {
    throw new Error('Missing or invalid "title" field (must be a string)');
  }
  
  if (typeof reportData.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (must be a string)');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Missing or invalid "entries" field (must be an array)');
  }
  
  // Validate entries
  const entries = reportData.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Entry ${index} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Entry ${index} must have a "label" field (must be a string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Entry ${index} must have an "amount" field (must be a number)`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });
  
  return {
    title: reportData.title,
    summary: reportData.summary,
    entries
  };
}

function main(): void {
  try {
    const { dataFile, options } = parseArgs(process.argv);
    
    // Read and parse JSON file
    const fileContent = readFileSync(dataFile, 'utf-8');
    let jsonData: unknown;
    
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      throw new Error(`Invalid JSON in file "${dataFile}": ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    
    // Validate report data
    const reportData = validateReportData(jsonData);
    
    // Select formatter
    const formatters = {
      markdown: renderMarkdown,
      text: renderText
    };
    
    const formatter = formatters[options.format];
    
    // Generate output
    const output = formatter.format(reportData, { includeTotals: options.includeTotals });
    
    // Write output
    if (options.output) {
      writeFileSync(options.output, output + '\n');
    } else {
      process.stdout.write(output + '\n');
    }
    
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
