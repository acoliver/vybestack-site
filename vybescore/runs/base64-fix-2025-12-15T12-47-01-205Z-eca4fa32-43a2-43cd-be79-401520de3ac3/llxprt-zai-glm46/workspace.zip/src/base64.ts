/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const INVALID_BASE64_ERROR = 'Invalid Base64 input format';

/**
 * Normalize Base64 input by adding required padding.
 * Buffer's base64 decoder can handle missing padding, but we need to
 * ensure the length is divisible by 4 for proper decoding.
 */
function normalizeBase64(input: string): string {
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  // Check for valid characters
  if (!base64Regex.test(input)) {
    throw new Error(INVALID_BASE64_ERROR);
  }
  
  // Validate padding rules
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only be 1 or 2 characters at the end
    const padding = input.substring(paddingIndex);
    if (!/^(=|==)$/.test(padding)) {
      throw new Error(INVALID_BASE64_ERROR);
    }
  }
  
  // Add padding if needed to make length divisible by 4
  const paddedLength = Math.ceil(input.length / 4) * 4;
  return input.padEnd(paddedLength, '=');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Uses standard Base64 alphabet and validates input format.
 * Accepts valid Base64 input with or without padding.
 */
export function decode(input: string): string {
  try {
    const normalized = normalizeBase64(input);
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message === INVALID_BASE64_ERROR) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
