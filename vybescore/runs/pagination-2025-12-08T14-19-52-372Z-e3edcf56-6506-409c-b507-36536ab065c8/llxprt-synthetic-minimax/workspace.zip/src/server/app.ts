import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePaginationParams(pageParam: unknown, limitParam: unknown): { page?: number; limit?: number; error?: string } {
  const MAX_LIMIT = 100;
  const MAX_PAGE = 1000;

  if (pageParam !== undefined && pageParam !== null && pageParam !== '') {
    const page = Number(pageParam);
    if (!Number.isFinite(page)) {
      return { error: 'Page must be a valid number' };
    }
    if (page <= 0 || !Number.isInteger(page)) {
      return { error: 'Page must be a positive integer' };
    }
    if (page > MAX_PAGE) {
      return { error: `Page cannot exceed ${MAX_PAGE}` };
    }
  }

  if (limitParam !== undefined && limitParam !== null && limitParam !== '') {
    const limit = Number(limitParam);
    if (!Number.isFinite(limit)) {
      return { error: 'Limit must be a valid number' };
    }
    if (limit <= 0 || !Number.isInteger(limit)) {
      return { error: 'Limit must be a positive integer' };
    }
    if (limit > MAX_LIMIT) {
      return { error: `Limit cannot exceed ${MAX_LIMIT}` };
    }
  }

  return {
    page: pageParam !== undefined && pageParam !== null && pageParam !== '' ? Number(pageParam) : undefined,
    limit: limitParam !== undefined && limitParam !== null && limitParam !== '' ? Number(limitParam) : undefined
  };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validatePaginationParams(pageParam, limitParam);
    if (validation.error) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
