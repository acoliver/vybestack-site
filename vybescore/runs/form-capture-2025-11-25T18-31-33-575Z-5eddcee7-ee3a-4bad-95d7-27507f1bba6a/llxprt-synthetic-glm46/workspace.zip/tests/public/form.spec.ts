import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';

let server: { close: () => unknown } | undefined;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import and start the server
  const serverPath = path.resolve('dist', 'server.js');
  if (!fs.existsSync(serverPath)) {
    throw new Error('Server not built. Run "npm run build" first.');
  }
  
  // Dynamic import to get the app
  const { default: app } = await import(serverPath);
  
  // Start the server on a random available port
  server = await new Promise<{ close: () => unknown }>((resolve, reject) => {
    try {
      const testServer = app.listen(0, () => {
        resolve(testServer);
      });
      testServer.on('error', reject);
    } catch (error) {
      reject(error);
    }
  });
});

afterAll(async () => {
  if (server) {
    await new Promise<void>((resolve) => {
      server!.close(() => {
        resolve();
      });
    });
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    if (!server) {
      throw new Error('Server not initialized');
    }
    
    const response = await request(server)
      .get('/')
      .expect(200);
      
    expect(response.text).toContain('<form');
    expect(response.text).toContain('firstName');
    expect(response.text).toContain('lastName');
    expect(response.text).toContain('streetAddress');
    expect(response.text).toContain('email');
    expect(response.text).toContain('phone');
  });

  it('persists submission and redirects', async () => {
    if (!server) {
      throw new Error('Server not initialized');
    }
    
    const formData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '123 Test St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'test@example.com',
      phone: '+1 555-123-4567'
    };
    
    const response = await request(server)
      .post('/submit')
      .send(formData)
      .expect(302);
      
    expect(response.headers.location).toContain('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates form input properly', async () => {
    if (!server) {
      throw new Error('Server not initialized');
    }
    
    // Test with empty required fields
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      })
      .expect(200);
      
    expect(response.text).toContain('error-list');
    expect(response.text).toContain('First Name is required');
    expect(response.text).toContain('Email is required');
  });

  it('validates email format properly', async () => {
    if (!server) {
      throw new Error('Server not initialized');
    }
    
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'invalid-email',
        phone: '+1 555-123-4567'
      })
      .expect(200);
      
    expect(response.text).toContain('Please enter a valid email address');
  });

  it('validates phone number format properly', async () => {
    if (!server) {
      throw new Error('Server not initialized');
    }
    
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: 'invalid-phone-format'
      })
      .expect(200);
      
    expect(response.text).toContain('Please enter a valid phone number');
  });
});
