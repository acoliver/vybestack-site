import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import sqljs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Set up EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Parse URL-encoded bodies
app.use(express.urlencoded({ extended: true }));

// Using any type to avoid sql.js typing issues
let db: any = null;
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await sqljs({
      locateFile: (file: string) => 
        path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });

    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schemaSQL = fs.readFileSync(schemaPath, 'utf-8');

    // Check if database exists
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      const uInt8Array = new Uint8Array(fileBuffer);
      db = new SQL.Database(uInt8Array);
    } else {
      db = new SQL.Database();
      db.run(schemaSQL);
      
      // Make sure the data directory exists
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    try {
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

// Form validation
interface FormBody {
  [key: string]: string | undefined;
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

function validateForm(body: FormBody): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Required fields validation
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!body[field] || body[field].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1').trim()} is required`);
    }
  });

  // Email validation
  if (body.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) {
    errors.push('Please provide a valid email address');
  }

  // Phone validation (international formats)
  if (body.phone && !/^\+?[\d\s\-()]+$/.test(body.phone)) {
    errors.push('Phone number should only contain digits, spaces, parentheses, dashes, and optionally a leading +');
  }

  // Postal code validation (alphanumeric)
  if (body.postalCode && !/^[a-zA-Z0-9\s-]{1,10}$/.test(body.postalCode)) {
    errors.push('Postal code should only contain letters, numbers, spaces, and hyphens');
  }
  
  return { isValid: errors.length === 0, errors };
}

// Routes
app.get('/', (req: express.Request, res: express.Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: express.Request, res: express.Response) => {
  const validation = validateForm(req.body);
  
  if (!validation.isValid) {
    return res.render('form', {
      errors: validation.errors,
      values: req.body
    });
  }
  
  // Insert into database
  try {
    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        req.body.firstName,
        req.body.lastName,
        req.body.streetAddress,
        req.body.city,
        req.body.stateProvince,
        req.body.postalCode,
        req.body.country,
        req.body.email,
        req.body.phone
      ]);
      
      stmt.free();
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to insert data:', error);
    return res.status(500).render('form', {
      errors: ['An error occurred while processing your submission. Please try again.'],
      values: req.body
    });
  }
  
  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: express.Request, res: express.Response) => {
  res.render('thank-you');
});

// Start server
async function startServer() {
  await initializeDatabase();

  if (!db) {
    console.error('Failed to initialize database. Exiting.');
    process.exit(1);
  }

  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
}

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down');
  if (db) {
    saveDatabase();
    db.close();
  }
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down');
  if (db) {
    saveDatabase();
    db.close();
  }
  process.exit(0);
});

// Export for testing
export default app;
startServer();