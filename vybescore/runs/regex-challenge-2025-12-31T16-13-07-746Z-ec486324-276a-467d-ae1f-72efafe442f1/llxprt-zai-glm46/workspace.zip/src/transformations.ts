/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences even if the input omitted it.
 * Collapse extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ').trim();

  // Add space after sentence endings if missing (before capital letter)
  result = result.replace(/([.!?])([A-Z])/g, '$1 $2');

  // Capitalize first character of the text
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());

  // Now capitalize after sentence endings (.!?) followed by space
  result = result.replace(/([.!?]\s+)([a-z])/g, (_, prefix, letter) => prefix + letter.toUpperCase());

  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  const urlPattern = /https?:\/\/(?:[-\w]+\.)+[a-z]{2,}(?::\d+)?(?:\/[^\s\]}\]"'<>]*)?/gi;

  const matches = text.match(urlPattern) || [];

  // Remove trailing punctuation
  return matches.map(url => url.replace(/[,.;:!?(){}`[\]"'<>]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions) but always upgrades scheme.
 */
export function rewriteDocsUrls(text: string): string {
  // First upgrade all http to https
  let result = text.replace(/http:\/\//gi, 'https://');

  // Pattern for example.com URLs
  const pattern = /(https:\/\/example\.com)(\/docs\/[^\s"<>?]*)/gi;

  // Dynamic indicators that prevent host rewrite
  const dynamicIndicators = [
    'cgi-bin',
    '\\?',
    '&',
    '=',
    '.jsp$',
    '.php$',
    '.asp$',
    '.aspx$',
    '.do$',
    '.cgi$',
    '.pl$',
    '.py$'
  ];
  const dynamicPattern = new RegExp(dynamicIndicators.join('|'));

  result = result.replace(pattern, (match, host, path) => {
    // Check if path contains dynamic indicators
    if (dynamicPattern.test(path)) {
      return match; // Only scheme upgraded, host stays same
    }
    return 'https://docs.example.com' + path;
  });

  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Check for mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) return 'N/A';

  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);

  // Validate month
  if (monthNum < 1 || monthNum > 12) return 'N/A';

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[monthNum - 1];

  if (dayNum < 1 || dayNum > maxDay) return 'N/A';

  // Special check for February 29 - must be leap year
  if (monthNum === 2 && dayNum === 29) {
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeapYear) return 'N/A';
  }

  return year;
}
