export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  if (!emailRegex.test(value)) return false;

  // Additional checks for invalid patterns
  if (value.includes('..')) return false;
  if (value.endsWith('.')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;

  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (domain.includes('_')) return false;
  if (domain.includes('..')) return false;
  if (domain.startsWith('-') || domain.endsWith('-')) return false;

  // Check each domain label
  const domainLabels = domain.split('.');
  for (const label of domainLabels) {
    if (label.startsWith('-') || label.endsWith('-')) return false;
    if (!/^[a-zA-Z0-9-]+$/.test(label)) return false;
  }

  // TLD must be at least 2 chars and only letters
  const tld = domainLabels[domainLabels.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) return false;

  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');

  // Check minimum length (10 digits for US number, optionally 11 with +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;

  // Handle +1 prefix
  let numberDigits = digitsOnly;
  if (digitsOnly.length === 11) {
    if (digitsOnly[0] !== '1') return false;
    numberDigits = digitsOnly.slice(1);
  }

  // Area code cannot start with 0 or 1
  if (numberDigits[0] === '0' || numberDigits[0] === '1') return false;

  // Exchange code (next 3 digits) cannot start with 0 or 1
  if (numberDigits[3] === '0' || numberDigits[3] === '1') return false;

  // Check if the format matches one of the acceptable patterns
  const patterns = [
    /^\(\d{3}\)\s?\d{3}[-.\s]?\d{4}$/, // (212) 555-7890
    /^\d{3}[-.\s]?\d{3}[-.\s]?\d{4}$/, // 212-555-7890
    /^\d{10}$/, // 2125557890
    /^\+1\s?\d{3}[-.\s]?\d{3}[-.\s]?\d{4}$/, // +1 212-555-7890
    /^\+1\s?\(\d{3}\)\s?\d{3}[-.\s]?\d{4}$/, // +1 (212) 555-7890
  ];

  return patterns.some(pattern => pattern.test(value));
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with optional country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Pattern: optional +54, optional 0 (trunk), optional 9 (mobile), area code (2-4 digits starting 1-9), subscriber (6-8 digits)
  // When country code is omitted, trunk prefix 0 is required
  const pattern = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;

  const match = cleaned.match(pattern);
  if (!match) return false;

  const [, countryCode, trunkPrefix,, areaCode, subscriber] = match;

  // If country code is omitted, trunk prefix must be present
  if (!countryCode && !trunkPrefix) return false;

  // Area code must be 2-4 digits (already enforced by regex, but double-check)
  if (areaCode.length < 2 || areaCode.length > 4) return false;

  // Subscriber must be 6-8 digits (already enforced by regex)
  if (subscriber.length < 6 || subscriber.length > 8) return false;

  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, apostrophes, hyphens, spaces
  // Must contain at least one letter
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  if (!nameRegex.test(value)) return false;

  // Must contain at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) return false;

  // Cannot contain digits
  if (/\d/.test(value)) return false;

  // Cannot be empty or only whitespace
  if (value.trim().length === 0) return false;

  // Cannot have special symbols (besides allowed apostrophes, hyphens, spaces)
  // Check for disallowed symbols
  const disallowedSymbols = /[^\p{L}'\-\s]/u;
  if (disallowedSymbols.test(value)) return false;

  // Cannot have consecutive special characters
  if (/'{2,}/.test(value) || /-{2,}/.test(value) || /\s{2,}/.test(value)) return false;

  // Cannot start or end with special characters
  if (/^['\-\s]/.test(value) || /['\-\s]$/.test(value)) return false;

  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  if (digits.length === 0) return false;

  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be only digits
  if (!/^\d+$/.test(cleaned)) return false;

  // Visa: starts with 4, length 13, 16, or 19
  const visaPattern = /^4\d{12}(\d{3}(\d{3})?)?$/;

  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPattern1 = /^5[1-5]\d{14}$/;
  const mastercardPattern2 = /^(2[2-7][2-9][0-9]|27[0-1][0-9]|2720)\d{12}$/;

  // AmEx: starts with 34 or 37, length 15
  const amexPattern = /^3[47]\d{13}$/;

  const isValidLength = visaPattern.test(cleaned) ||
                        mastercardPattern1.test(cleaned) ||
                        mastercardPattern2.test(cleaned) ||
                        amexPattern.test(cleaned);

  if (!isValidLength) return false;

  // Run Luhn check
  return runLuhnCheck(cleaned);
}
