/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to match words starting with prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');

  const matches = text.match(wordPattern) || [];

  // Filter out exceptions and remove duplicates
  const exceptionSet = new Set(exceptions);
  const result = [...new Set(matches)].filter(word => !exceptionSet.has(word));

  return result;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Look for token preceded by a digit (including the digit in the match)
  // Match pattern: digit followed by token
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  return [...new Set(matches)];
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase
 * - One lowercase
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;

  // Check for whitespace
  if (/\s/.test(value)) return false;

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;

  // Check for at least one digit
  if (!/\d/.test(value)) return false;

  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;

  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // Look for patterns of length 2-4 that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const pattern = value.substring(i, i + len);
      const nextChunk = value.substring(i + len, i + 2 * len);
      if (pattern === nextChunk) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Extract potential IPv6 addresses from the text
  // Match sequences that look like IPv6 (contain colons and hex digits)

  // Check if the string contains a valid IPv6 pattern
  // Full form: 8 groups of 1-4 hex digits separated by colons
  const fullIpv6Pattern = /(?:^|(?<![\da-fA-F:]))([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?![\da-fA-F:])/;

  // Compressed form: :: can appear once
  const compressedIpv6Pattern = /(?:^|(?<![0-9a-fA-F:]))[0-9a-fA-F]{0,4}::[0-9a-fA-F]{0,4}(?![0-9a-fA-F:])/;

  // Mixed with start/end compression
  const compressedStartPattern = /^::[0-9a-fA-F:+]+/;
  const compressedEndPattern = /[0-9a-fA-F:+]+::$/;

  // IPv6 with embedded IPv4
  const ipv6WithIpv4Pattern = /[0-9a-fA-F:+]:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/;

  // Check all patterns
  if (fullIpv6Pattern.test(value)) return true;
  if (compressedIpv6Pattern.test(value)) return true;
  if (compressedStartPattern.test(value)) return true;
  if (compressedEndPattern.test(value)) return true;
  if (ipv6WithIpv4Pattern.test(value)) return true;

  // Also check for :: in middle of hex digit groups
  if (/[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}/.test(value)) return true;

  return false;
}
