/**
 * Regular expression to match valid Base64 characters (including optional padding).
 */
const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input structure and padding.
 */
function validateBase64Input(input: string): void {
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingMatch = input.match(/=+$/);
    if (!paddingMatch || paddingMatch.index !== paddingIndex) {
      throw new Error('Invalid Base64 input: padding must be at the end');
    }
    
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
    
    // With padding, length must be a multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length for padding');
    }
  } else {
    // Without padding, length must be a multiple of 4, or close enough to be valid
    // (e.g., "dGVzdA" is 5 chars, which is valid for "test")
    // The base64 decoding will handle the actual validation
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error if the input contains invalid Base64 characters.
 */
export function decode(input: string): string {
  validateBase64Input(input);

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if decoding actually succeeded (Buffer.from may not throw for invalid input)
    const reEncoded = buffer.toString('base64');
    // Normalize both for comparison (handle missing padding in input)
    const normalizedInput = input.padEnd(Math.ceil(input.length / 4) * 4, '=');
    if (reEncoded !== normalizedInput && input !== reEncoded) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
