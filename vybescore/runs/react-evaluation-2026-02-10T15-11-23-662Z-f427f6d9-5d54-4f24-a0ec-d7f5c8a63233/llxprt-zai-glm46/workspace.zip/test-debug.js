import { createInput, createComputed } from './src/index.js'

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial sum:', sum()) // Should be 32

setInput(3)
console.log('After setInput(3), sum:', sum()) // Should be 96
