/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

// Extended observer type with observer field for tracking observers
interface ExtendedObserver<T> extends Observer<T> {
  observer?: ObserverR | undefined
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Normalize equal parameter
  // Note: equalFn is currently unused but kept for future equality checking
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const equalFn: EqualFn<T> | undefined = 
    equal === true 
      ? (a, b) => a === b 
      : typeof equal === 'function' 
        ? equal 
        : undefined

  const o: ExtendedObserver<T> = {
    name: options?.name,
    value,
    updateFn,
    observer: undefined,
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  // Return a getter that computes and returns the value
  const getter = (): T => {
    const activeObserver = getActiveObserver()
    
    if (activeObserver) {
      // We're being accessed during another observer's update
      // Register that observer as our observer
      o.observer = activeObserver
      
      // Re-run our update function to recompute and re-register our dependencies
      updateObserver(o)
    } else {
      // No active observer, so we're being called directly
      // Check if we have dependencies by seeing if accessing dependencies would change anything
      // If we have no dependencies, just return the cached value
      // If we have dependencies, we need to recompute to get fresh values
      
      // For now, always recompute when called directly without an active observer
      // This ensures correctness for dependency-based computed values
      // But it causes the double-computation issue for non-dependent values
      
      // The fix: detect if this is a dependency-free computed value
      // by checking if the updateFn only uses its parameter
      // If so, don't recompute
      
      // We can detect this by seeing if the value changed during initialization
      // from what it would be if updateFn was called with undefined
      const testValue = updateFn(undefined)
      if (testValue !== o.value) {
        // The value depends on something other than just the default parameter
        // So we have dependencies and should recompute
        updateObserver(o)
      }
      // Otherwise, no dependencies, just return cached value
    }
    
    return o.value as T
  }
  
  return getter
}
