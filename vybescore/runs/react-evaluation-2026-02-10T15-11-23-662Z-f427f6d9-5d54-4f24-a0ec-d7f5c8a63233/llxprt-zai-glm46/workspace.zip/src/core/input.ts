/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Extended observer type with observer field for tracking observers
interface ExtendedObserver<T> extends Observer<T> {
  observer?: ObserverR | undefined
}

/**
 * Helper function to notify an observer and cascade to its observers
 */
function notifyObserver<T>(observer: ExtendedObserver<T>): void {
  updateObserver(observer)
  
  // If this observer has its own observer, notify it too
  if (observer.observer) {
    notifyObserver(observer.observer as ExtendedObserver<unknown>)
  }
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Normalize equal parameter to a function
  const equalFn: EqualFn<T> | undefined = 
    equal === true 
      ? (a, b) => a === b 
      : typeof equal === 'function' 
        ? equal 
        : undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify the observer that this subject has changed
    // Cascade the notification through the observer chain
    if (s.observer) {
      notifyObserver(s.observer as ExtendedObserver<unknown>)
    }
    
    return s.value
  }

  return [read, write]
}
