#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportOptions, OutputFormat } from '../types.js';
import { validateReportData } from '../utils/validation.js';
import { getFormatter } from '../formatters/index.js';

interface CliArgs {
  dataFile: string;
  format: OutputFormat;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  let format: OutputFormat | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
      format = formatValue;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a path');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function main() {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Read and parse the JSON file
    let rawData: unknown;
    try {
      const fileContent = readFileSync(args.dataFile, 'utf-8');
      rawData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error(`Malformed JSON in ${args.dataFile}: ${error.message}`);
      }
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        throw new Error(`File not found: ${args.dataFile}`);
      }
      throw error;
    }

    // Validate the data
    const reportData = validateReportData(rawData);

    // Prepare options
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };

    // Get the formatter and render
    const formatter = getFormatter(args.format);
    const output = formatter.render(reportData, options);

    // Write output
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    } else {
      console.error('An unknown error occurred');
      process.exit(1);
    }
  }
}

main();