import type { OutputFormat, Formatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

export const formatters: Record<OutputFormat, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getFormatter(format: string): Formatter {
  const formatter = formatters[format as OutputFormat];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}