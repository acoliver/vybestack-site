/**
 * Finds words beginning with the given prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix and create word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exception => lowerWord === exception.toLowerCase());
  });
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token for safe pattern matching
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Since lookbehind with variable length has issues, use a simpler approach
  const fullTextRegex = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = [];
  let match;
  
  while ((match = fullTextRegex.exec(text)) !== null) {
    // Extract the full match (digit + token) 
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates password strength based on policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, 1212)
  const repeatedSequenceRegex = /(..)\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  // Additional check for repetitive patterns (like aaa, bbb)
  const repetitivePatternRegex = /(.)\1\1+/;
  if (repetitivePatternRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses don't trigger positive result
 */
export function containsIPv6(value: string): boolean {
  // IPv4 address pattern (to exclude)
  const ipv4Pattern = /^(\d{1,3}\.){3}\d{1,3}$/;
  const ipv4WithPort = /^(\d{1,3}\.){3}\d{1,3}:\d+$/;
  const ipv4InContext = /(\d{1,3}\.){3}\d{1,3}/;
  
  // IPv6 patterns
  // Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  const fullIPv6Pattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // Compressed IPv6 with :: (can appear at various positions)
  const compressedIPv6Pattern1 = /^::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,8}$/;
  const compressedIPv6Pattern2 = /^(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,8}$/;
  const compressedIPv6Pattern3 = /^(?:[0-9a-fA-F]{1,4}:){0,6}:[0-9a-fA-F]{1,8}$/;
  const compressedIPv6Pattern4 = /^(?:[0-9a-fA-F]{1,4}:){2,7}:$/;
  const compressedIPv6Pattern5 = /^:(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,8}$/;
  
  // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const ipv6WithIPv4Pattern = /^::ffff:(\d{1,3}\.){3}\d{1,3}$/;
  const ipv6WithIPv4FullPattern = /^(?:[0-9a-fA-F]{1,4}:){5}:(\d{1,3}\.){3}\d{1,3}$/;
  
  // If it's clearly an IPv4 address, don't detect as IPv6
  if (ipv4WithPort.test(value) || (ipv4Pattern.test(value) && !fullIPv6Pattern.test(value))) {
    return false;
  }
  
  // Try to extract IPv6 patterns from the text (not just full match)
  const ipv6InText = value.match(/[0-9a-fA-F:]+/g) || [];
  
  for (const candidate of ipv6InText) {
    // Skip IPv4 patterns that might be mixed in
    if (ipv4InContext.test(candidate) && candidate.includes('.')) {
      continue;
    }
    
    // Test against IPv6 patterns
    if (fullIPv6Pattern.test(candidate) ||
        compressedIPv6Pattern1.test(candidate) ||
        compressedIPv6Pattern2.test(candidate) ||
        compressedIPv6Pattern3.test(candidate) ||
        compressedIPv6Pattern4.test(candidate) ||
        compressedIPv6Pattern5.test(candidate) ||
        ipv6WithIPv4Pattern.test(candidate) ||
        ipv6WithIPv4FullPattern.test(candidate)) {
      return true;
    }
  }
  
  // Special case: check for :: in the context of valid IPv6
  if (value.includes('::')) {
    const parts = value.split('::');
    if (parts.length === 2 && parts[0] === '' && parts[1].split(':').length <= 7) {
      // Ends with :: followed by valid hex groups
      return true;
    }
  }
  
  return false;
}
