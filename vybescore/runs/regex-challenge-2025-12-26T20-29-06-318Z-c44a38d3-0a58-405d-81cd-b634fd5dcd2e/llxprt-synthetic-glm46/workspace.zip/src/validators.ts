export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\+[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)?@(?:(?![0-9._-])([a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,})$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  if (value.includes('..')) return false; // double dots
  if (value.startsWith('.') || value.endsWith('.')) return false; // leading/trailing dots
  if (value.includes('@.') || value.includes('.@')) return false; // dots adjacent to @
  if (value.split('@')[1].includes('_')) return false; // underscore in domain
  
  return true;
}

/**
 * Validates US phone numbers supporting (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must be 10 or 11 digits (with optional +1 country code)
  if (digitsOnly.length !== 10 && digitsOnly.length !== 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (US country code)
  if (digitsOnly.length === 11 && digitsOnly[0] !== '1') {
    return false;
  }
  
  // Extract last 10 digits for validation
  const phoneNumber = digitsOnly.length === 10 ? digitsOnly : digitsOnly.slice(1);
  
  // Area code cannot start with 0 or 1 (NPA)
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') {
    return false;
  }
  
  // Exchange code cannot start with 0 or 1 (NXX)
  if (phoneNumber[3] === '0' || phoneNumber[3] === '1') {
    return false;
  }
  
  // Validate format with regex
  const phoneRegex = /^(\+1[-.\s]?)?(\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for landlines and mobiles
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Try multiple patterns based on different spacing conventions
  
  // Pattern 1: With country code (+54), optional mobile indicator (9), area code, subscriber number
  // Format: +54 [9] areaCode subscriberNumber (spaces between all segments)
  const withCountryPattern1 = /^\+54\s+(9\s+)?([1-9]\d{0,3})\s+(\d{3,4})\s+(\d{4})$/;
  
  // Pattern 2: With country code but subscriber number as single group
  // Format: +54 [9] areaCode subscriberNumber (subscriber can be continuous)
  const withCountryPattern2 = /^\+54\s+(9\s+)?([1-9]\d{0,3})\s+(\d{6,8})$/;
  
  // Pattern 3: Without country code, with trunk prefix (0)
  // Format: 0 areaCode subscriberNumber (spaces between all segments)
  const withoutCountryPattern1 = /^0([1-9]\d{0,3})\s+(\d{3,4})\s+(\d{4})$/;
  
  // Pattern 4: Without country code but subscriber as single group
  // Format: 0 areaCode subscriberNumber (subscriber can be continuous)
  const withoutCountryPattern2 = /^0([1-9]\d{0,3})\s+(\d{6,8})$/;
  
  // Try with original spacing first
  let match = withCountryPattern1.exec(value) || 
              withCountryPattern2.exec(value) || 
              withoutCountryPattern1.exec(value) || 
              withoutCountryPattern2.exec(value);
  
  if (!match) {
    // Try hyphens as separator
    const hyphenValue = value.replace(/\s+/g, '-');
    match = /^\+54-(?:9-)?([1-9]\d{0,3})-(\d{3,4})-(\d{4})$/.exec(hyphenValue) ||
            /^\+54-(?:9-)?([1-9]\d{0,3})-(\d{6,8})$/.exec(hyphenValue) ||
            /^0-([1-9]\d{0,3})-(\d{3,4})-(\d{4})$/.exec(hyphenValue) ||
            /^0-([1-9]\d{0,3})-(\d{6,8})$/.exec(hyphenValue);
  }
  
  if (!match) {
    // Last resort: try with no separators
    const normalized = value.replace(/[\\s-]/g, '');
    match = /^\+54?(9)?([1-9]\d{0,3})(\d{6,8})$/.exec(normalized) ||
            /^0([1-9]\d{0,3})(\d{6,8})$/.exec(normalized);
  }
  
  if (!match) {
    return false;
  }
  
  // Extract area code from the right capture group
  const areaCode = match[1] || match[2] || '';
  
  // Extract subscriber number from the right capture groups
  // We need to handle different patterns differently
  let subscriberNumber = '';
  
  if (match.length === 5) {
    // Pattern with both parts of subscriber number split (e.g., 123 4567)
    subscriberNumber = (match[3] || '') + (match[4] || '');
  } else {
    // Pattern with subscriber number as single group
    subscriberNumber = match[3] || '';
  }
  
  // Area code must be 2-4 digits and start with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Use a simpler regex without Unicode property escapes for broader compatibility
  const nameRegex = /^[A-Za-z\u00C0-\u017F\s'-]+$/;
  
  // Must contain at least one letter
  if (!/[A-Za-z\u00C0-\u017F]/.test(value)) {
    return false;
  }
  
// Reject digits and symbols (except hyphens and apostrophes)
  if (/[\d@#$%^&*()=+[\]{|/<>?]/.test(value)) {
    return false;
  }
  
  // Check basic pattern matches
  return nameRegex.test(value);
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx) using prefix, length, and Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check basic length requirements
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check prefix patterns for major card types
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex1 = /^5[1-5]\d{14}$/; // 51-55
  const mastercardRegex2 = /^2(2[2-9]\d{12}|[3-6]\d{13}|7[01]\d{12}|720\d{12})$/; // 2221-2720
  const amexRegex = /^3[47]\d{13}$/;
  
  const validPrefix = visaRegex.test(digitsOnly) || 
                     mastercardRegex1.test(digitsOnly) || 
                     mastercardRegex2.test(digitsOnly) || 
                     amexRegex.test(digitsOnly);
  
  if (!validPrefix) {
    return false;
  }
  
  // Luhn checksum algorithm
  let sum = 0;
  let isEven = false;
  
  for (let i = digitsOnly.length - 1; i >= 0; i--) {
    let digit = parseInt(digitsOnly[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
