/**
 * Capitalizes the first character of each sentence after sentence terminators (.?!)
 * Ensures exactly one space between sentences and collapses extra spaces
 * Attempts to preserve abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Ensure exactly one space after sentence terminators
  result = result.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Split into sentences, capitalize each, and join back
  const sentences = result.split(/(?<=[.?!])\s+/);
  const capitalizedSentences = sentences.map(sentence => {
    if (sentence.length === 0) return sentence;
    
    // Find common abbreviations to avoid incorrect sentence splitting
    const abbreviations = ['mr', 'mrs', 'dr', 'prof', 'sr', 'jr', 'st', 'ave', 'blvd', 'rd', 'etc', 'e.g', 'i.e'];
    
    // Check if previous word is an abbreviation (simple heuristic)
    const words = sentence.split(' ');
    if (words.length > 1) {
      const lastWordOfPrevious = words[words.length - 2].toLowerCase().replace(/[.!?]$/, '');
      if (abbreviations.includes(lastWordOfPrevious)) {
        return sentence; // Don't capitalize if likely an abbreviation
      }
    }
    
    // Capitalize first letter of the sentence
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  return capitalizedSentences.join(' ');
}

/**
 * Extracts all URLs from text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http/https, www, domain names, and various TLDs
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"]+|(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s<>"]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
// Clean up trailing punctuation from each match
  return matches.map(url => {
    // Remove trailing punctuation: .,;:!?)]}"
    return url.replace(/[.,;:!?)\]\\"']+$/, '');
  }).filter(url => {
    // Filter out possible false positives
    return url.length > 3 && (url.includes('.') || url.includes('/'));
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Pattern to match http:// URLs
  const httpUrlRegex = /http:\/\/([^\s<>"]+)/g;
  
  return text.replace(httpUrlRegex, 'https://$1');
}

/**
 * Rewrites http://example.com/... URLs following specific rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com URLs
  const urlRegex = /(http:\/\/(?:www\.)?example\.com)(\/[^\s<>"]*)/g;
  
  return text.replace(urlRegex, (match, domain, path) => {
    // Always upgrade to https
    const secureDomain = domain.replace('http://', 'https://');
    
    // Check if path contains dynamic hints that should prevent host rewrite
    const dynamicHints = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    const hasDynamicHints = dynamicHints.some(hint => path.includes(hint));
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite the host to docs.example.com
      const cleanDomain = secureDomain.replace('://www.', '://').replace('://', '://docs.');
      return cleanDomain + path;
    }
    
    // Just upgrade to https
    return secureDomain + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings
 * Returns "N/A" when format doesn't match or month/day are invalid
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return "N/A";
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day based on month (basic validation, not comprehensive leap year check)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Basic leap year check
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    if ((yearNum % 4 !== 0) || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
      return "N/A"; // Invalid leap year
    }
  } else if (day > daysInMonth[month - 1]) {
    return "N/A"; // Day exceeds month days
  }
  
  return year;
}
