import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderText: ReportRenderer = {
  render(data: ReportData, options: ReportOptions): string {
    const lines: string[] = [];

    // Title
    lines.push(data.title);
    lines.push('');

    // Summary
    lines.push(data.summary);
    lines.push('');

    // Entries heading
    lines.push('Entries:');
    lines.push('');

    // Entries list
    for (const entry of data.entries) {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    }

    // Total if requested
    if (options.includeTotals) {
      lines.push('');
      lines.push(`Total: ${formatAmount(calculateTotal(data.entries))}`);
    }

    return lines.join('\n');
  },
};