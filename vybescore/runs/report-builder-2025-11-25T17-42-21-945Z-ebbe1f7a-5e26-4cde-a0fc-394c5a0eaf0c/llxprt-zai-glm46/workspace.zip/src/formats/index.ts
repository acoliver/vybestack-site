import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import type { ReportRenderer, ReportFormat } from '../types.js';

export const formatRenderers: Record<ReportFormat, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
} as const;