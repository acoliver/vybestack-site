#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions, ReportFormat } from '../types.js';
import { formatRenderers } from '../formats/index.js';

function parseArguments(): {
  dataPath: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[0];
  
  let format: ReportFormat | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        {
          const formatValue = args[i + 1];
          if (formatValue !== 'markdown' && formatValue !== 'text') {
            console.error(`Error: Unsupported format "${formatValue}"`);
            process.exit(1);
          }
          format = formatValue as ReportFormat;
        }
        i++;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        {
          outputPath = args[i + 1];
        }
        i++;
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument "${args[i]}"`);
        process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i} has missing or invalid "label" field (must be a string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${i} has missing or invalid "amount" field (must be a number)`);
    }
  }

  return obj as unknown as ReportData;
}

function main(): void {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArguments();

    // Read and parse JSON data
    let jsonData: unknown;
    try {
      const jsonContent = readFileSync(dataPath, 'utf8');
      jsonData = JSON.parse(jsonContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file "${dataPath}": ${error.message}`);
      } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error(`Error: File not found "${dataPath}"`);
      } else {
        console.error(`Error reading file "${dataPath}": ${error instanceof Error ? error.message : String(error)}`);
      }
      process.exit(1);
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Render report
    const options: ReportOptions = { includeTotals };
    const renderer = formatRenderers[format];
    const output = renderer.render(reportData, options);

    // Write output
    if (outputPath) {
      try {
        writeFileSync(outputPath, output, 'utf8');
      } catch (error) {
        console.error(`Error writing to file "${outputPath}": ${error instanceof Error ? error.message : String(error)}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
