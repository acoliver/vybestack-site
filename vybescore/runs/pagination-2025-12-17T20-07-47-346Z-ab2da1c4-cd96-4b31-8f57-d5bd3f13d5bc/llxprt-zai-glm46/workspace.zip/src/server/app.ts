import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePaginationParams(pageParam: string | undefined, limitParam: string | undefined): { page: number; limit: number } {
  const DEFAULT_PAGE = 1;
  const DEFAULT_LIMIT = 5;
  const MAX_LIMIT = 100;

  // Validate page parameter
  let page = DEFAULT_PAGE;
  if (pageParam !== undefined) {
    const parsedPage = Number(pageParam);
    if (isNaN(parsedPage) || parsedPage <= 0 || !Number.isInteger(parsedPage)) {
      throw new Error('Page must be a positive integer');
    }
    page = parsedPage;
  }

  // Validate limit parameter
  let limit = DEFAULT_LIMIT;
  if (limitParam !== undefined) {
    const parsedLimit = Number(limitParam);
    if (isNaN(parsedLimit) || parsedLimit <= 0 || !Number.isInteger(parsedLimit) || parsedLimit > MAX_LIMIT) {
      throw new Error('Limit must be a positive integer not exceeding 100');
    }
    limit = parsedLimit;
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res): void => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    try {
      const { page, limit } = validatePaginationParams(pageParam, limitParam);
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Invalid pagination parameters';
      res.status(400).json({ error: errorMessage });
    }
  });

  return app;
}
