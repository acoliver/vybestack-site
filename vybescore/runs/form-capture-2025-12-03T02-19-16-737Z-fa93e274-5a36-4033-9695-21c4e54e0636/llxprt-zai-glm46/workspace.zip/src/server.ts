import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs/promises';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

interface Database {
  run(sql: string, params?: unknown[]): unknown;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(params?: unknown[]): unknown;
  free(): void;
}

interface SqlJsStatic {
  Database: new (data?: Uint8Array) => Database;
}

class FormServer {
  private app: express.Application;
  private db: Database | null = null;
  private port: number;

  constructor() {
    this.app = express();
    this.port = parseInt(process.env.PORT || '3535', 10);
    this.setupMiddleware();
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use('/public', express.static(path.join(process.cwd(), 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(process.cwd(), 'src/templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs({
        locateFile: file => `node_modules/sql.js/dist/${file}`
      }) as SqlJsStatic;

      const dbPath = path.join(__dirname, '../data/submissions.sqlite');
      
      try {
        const dbFile = await fs.readFile(dbPath);
        this.db = new SQL.Database(dbFile);
      } catch (error) {
        this.db = new SQL.Database();
        await this.createTables();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createTables(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;

    this.db.run(schema);
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const data = this.db.export();
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    try {
      await fs.mkdir(path.dirname(dbPath), { recursive: true });
      await fs.writeFile(dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateFormData(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    if (!data.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }

    if (!data.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }

    if (!data.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }

    if (!data.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }

    if (!data.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }

    if (!data.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    }

    if (!data.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }

    if (!data.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email)) {
        errors.push({ field: 'email', message: 'Please enter a valid email address' });
      }
    }

    if (!data.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    } else {
      const phoneRegex = /^\+?[\d\s\-()]+$/;
      if (!phoneRegex.test(data.phone)) {
        errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
      }
    }

    return errors;
  }

  private setupRoutes(): void {
    this.app.get('/', (req, res) => {
      res.render('form', {
        errors: [],
        values: {},
        title: 'Friendly Contact Form'
      });
    });

    this.app.post('/submit', async (req, res) => {
      try {
        const formData: FormData = {
          firstName: req.body.firstName || '',
          lastName: req.body.lastName || '',
          streetAddress: req.body.streetAddress || '',
          city: req.body.city || '',
          stateProvince: req.body.stateProvince || '',
          postalCode: req.body.postalCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };

        const errors = this.validateFormData(formData);

        if (errors.length > 0) {
          const errorMessages = errors.map(error => error.message);
          res.render('form', {
            errors: errorMessages,
            values: formData,
            title: 'Friendly Contact Form'
          });
          return;
        }

        if (!this.db) throw new Error('Database not initialized');

        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province, 
            postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);

        stmt.free();

        await this.saveDatabase();

        res.redirect('/thank-you');
      } catch (error) {
        console.error('Error submitting form:', error);
        res.status(500).render('form', {
          errors: ['An unexpected error occurred. Please try again.'],
          values: req.body,
          title: 'Friendly Contact Form'
        });
      }
    });

    this.app.get('/thank-you', (req, res) => {
      res.render('thank-you', {
        firstName: 'Friend',
        title: 'Thank You!'
      });
    });
  }

  public async start(): Promise<void> {
    try {
      await this.initializeDatabase();
      this.setupRoutes();

      const server = this.app.listen(this.port, () => {
        console.log(`Server running on port ${this.port}`);
      });

      const gracefulShutdown = async (signal: string) => {
        console.log(`Received ${signal}, shutting down gracefully...`);
        
        server.close(async () => {
          console.log('HTTP server closed');
          
          if (this.db) {
            this.db.close();
            this.db = null;
            console.log('Database closed');
          }
          
          process.exit(0);
        });

        setTimeout(() => {
          console.error('Forced shutdown');
          process.exit(1);
        }, 5000);
      };

      process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
      process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }
}

const server = new FormServer();
server.start();