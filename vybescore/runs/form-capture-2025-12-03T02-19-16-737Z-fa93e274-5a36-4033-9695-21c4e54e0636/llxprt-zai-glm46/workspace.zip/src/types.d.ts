declare module 'sql.js' {
  function initSqlJs(config?: { locateFile?: (file: string) => string }): Promise<{
    Database: new (data?: Uint8Array) => unknown;
  }>;
  export = initSqlJs;
}