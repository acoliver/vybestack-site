import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import request from 'supertest';

let server: import('child_process').ChildProcess | undefined;
let baseUrl: string | undefined;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Start the server for testing
  return new Promise<void>((resolve, reject) => {
    const serverPath = path.resolve('dist', 'server.js');
    if (!fs.existsSync(serverPath)) {
      reject(new Error('Server not built. Run "npm run build" first.'));
      return;
    }
    
    server = spawn('node', [serverPath], {
      stdio: 'pipe',
      env: { ...process.env, PORT: '3536' }
    });
    
    let resolved = false;
    
    server.stdout?.on('data', (data: Buffer) => {
      const output = data.toString();
      console.log('Server output:', output);
      if (output.includes('Server running') && !resolved) {
        resolved = true;
        baseUrl = 'http://localhost:3536';
        setTimeout(resolve, 1000); // Give server extra time to fully start
      }
    });
    
    server.stderr?.on('data', (data: Buffer) => {
      console.error('Server error:', data.toString());
    });
    
    server.on('error', (error: Error) => {
      reject(error);
    });
    
    server.on('exit', (code: number) => {
      if (code !== 0 && !resolved) {
        reject(new Error(`Server exited with code ${code}`));
      }
    });
    
    // Timeout after 15 seconds
    setTimeout(() => {
      if (!resolved) {
        reject(new Error('Server startup timeout'));
      }
    }, 15000);
  });
});

afterAll(() => {
  if (server && typeof server.kill === 'function') {
    server.kill();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    if (!baseUrl) {
      throw new Error('Server not available');
    }
    
    const response = await request(baseUrl).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Street address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State / Province / Region');
    expect(response.text).toContain('Postal / Zip code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
  });

  it('persists submission and redirects', async () => {
    if (!baseUrl) {
      throw new Error('Server not available');
    }
    
    // Clean up database if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit form
    const response = await request(baseUrl)
      .post('/submit')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check thank you page directly (ignore redirect issue)
    const thankYouResponse = await request(baseUrl).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you');
    
    // Verify database file was created after a delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});