import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import type { Database } from 'sql.js';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns default pagination (page=1, limit=5)', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15); // 15 items in seed data
    expect(response.body.hasNext).toBe(true);
    expect(response.body.items).toHaveLength(5);
  });

  it('returns correct pagination metadata', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    expect(response.body.items).toHaveLength(3);
    // Should return items 4, 5, 6 (IDs 4, 5, 6)
    expect(response.body.items[0].id).toBe(4);
    expect(response.body.items[2].id).toBe(6);
  });

  it('handles last page correctly', async () => {
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
    expect(response.body.items).toHaveLength(5);
    // Should return items 11, 12, 13, 14, 15
    expect(response.body.items[0].id).toBe(11);
    expect(response.body.items[4].id).toBe(15);
  });

  it('rejects invalid page parameters', async () => {
    // Non-numeric page
    let response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Page must be a positive integer');

    // Negative page
    response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Page must be a positive integer');

    // Zero page
    response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Page must be a positive integer');
  });

  it('rejects invalid limit parameters', async () => {
    // Non-numeric limit
    let response = await request(app).get('/inventory?limit=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Limit must be a positive integer');

    // Negative limit
    response = await request(app).get('/inventory?limit=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Limit must be a positive integer');

    // Zero limit
    response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Limit must be a positive integer');

    // Excessive limit
    response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('not exceeding 100');
  });

  it('validates offset calculation (first page fix)', async () => {
    const response = await request(app).get('/inventory?page=1&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(3);
    // Should return first 3 items (IDs 1, 2, 3)
    expect(response.body.items[0].id).toBe(1);
    expect(response.body.items[1].id).toBe(2);
    expect(response.body.items[2].id).toBe(3);
  });
});
