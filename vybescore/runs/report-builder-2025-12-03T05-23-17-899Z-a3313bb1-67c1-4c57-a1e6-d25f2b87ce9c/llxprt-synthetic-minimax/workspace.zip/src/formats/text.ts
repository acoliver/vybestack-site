import { ReportData, RenderOptions, Formatter } from '../types.js';

export const renderText: Formatter = {
  format(data: ReportData, options: RenderOptions): string {
    let output = `${data.title}\n`;
    output += `${data.summary}\n\n`;
    output += `Entries:\n`;
    
    for (const entry of data.entries) {
      const formattedAmount = `$${entry.amount.toFixed(2)}`;
      output += `- ${entry.label}: ${formattedAmount}\n`;
    }
    
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      const formattedTotal = `$${total.toFixed(2)}`;
      output += `Total: ${formattedTotal}\n`;
    }
    
    return output;
  }
};