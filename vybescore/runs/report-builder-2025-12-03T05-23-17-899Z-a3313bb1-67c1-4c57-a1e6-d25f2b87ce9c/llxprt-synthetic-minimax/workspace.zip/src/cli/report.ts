import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: FormatType;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  const parsed: ParsedArgs = {
    dataFile: '',
    format: 'markdown',
    includeTotals: false
  };

  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    
    if (!arg.startsWith('--')) {
      if (!parsed.dataFile) {
        parsed.dataFile = arg;
      } else {
        throw new Error('Multiple data files provided');
      }
    } else {
      switch (arg) {
        case '--format': {
          i++;
          if (i >= args.length) {
            throw new Error('Missing value for --format');
          }
          const format = args[i] as FormatType;
          if (format !== 'markdown' && format !== 'text') {
            throw new Error(`Unsupported format: ${format}`);
          }
          parsed.format = format;
          break;
        }
        case '--output': {
          i++;
          if (i >= args.length) {
            throw new Error('Missing value for --output');
          }
          parsed.output = args[i];
          break;
        }
        case '--includeTotals':
          parsed.includeTotals = true;
          break;
        default:
          throw new Error(`Unknown option: ${arg}`);
      }
    }
  }

  if (!parsed.dataFile) {
    throw new Error('Data file path is required');
  }

  return parsed;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  const objData = data as Record<string, unknown>;

  if (typeof objData.title !== 'string' || !objData.title.trim()) {
    throw new Error('Invalid JSON: "title" must be a non-empty string');
  }

  if (typeof objData.summary !== 'string' || !objData.summary.trim()) {
    throw new Error('Invalid JSON: "summary" must be a non-empty string');
  }

  if (!Array.isArray(objData.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  if (objData.entries.length === 0) {
    throw new Error('Invalid JSON: "entries" cannot be empty');
  }

  for (let i = 0; i < objData.entries.length; i++) {
    const entry = objData.entries[i];
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} must be an object`);
    }

    const objEntry = entry as Record<string, unknown>;

    if (typeof objEntry.label !== 'string' || !objEntry.label.trim()) {
      throw new Error(`Invalid JSON: entry at index ${i} must have a non-empty "label" string`);
    }

    if (typeof objEntry.amount !== 'number' || isNaN(objEntry.amount)) {
      throw new Error(`Invalid JSON: entry at index ${i} must have a valid "amount" number`);
    }
  }

  return data as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf-8');
    const parsed = JSON.parse(rawData);
    return validateReportData(parsed);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('Invalid JSON:')) {
        throw error;
      }
      throw new Error(`Error reading file "${filePath}": ${error.message}`);
    }
    throw new Error(`Error reading file "${filePath}": ${error}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content);
  } else {
    console.log(content);
  }
}

function main(): void {
  try {
    const args = process.argv;
    const parsed = parseArgs(args);
    
    const reportData = loadReportData(parsed.dataFile);
    const options: RenderOptions = {
      includeTotals: parsed.includeTotals
    };

    let formatter;
    switch (parsed.format) {
      case 'markdown':
        formatter = renderMarkdown;
        break;
      case 'text':
        formatter = renderText;
        break;
      default:
        throw new Error(`Unsupported format: ${parsed.format}`);
    }

    const output = formatter.format(reportData, options);
    writeOutput(output, parsed.output);

  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error('An unexpected error occurred');
      process.exit(1);
    }
  }
}

main();