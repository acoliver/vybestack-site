import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { Request, Response } from 'express';
import { initializeDatabase, closeDatabase, insertSubmission } from './database.js';
import { validateForm } from './validation.js';
import { FormData } from './types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
let PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set EJS as the template engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    return res.render('form', {
      errors: errors.map(e => e.message),
      values: formData
    });
  }

  try {
    await initializeDatabase();
    insertSubmission(formData);
    
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An unexpected error occurred. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName || 'friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown function
async function shutdown() {
  console.log('Shutting down gracefully...');
  closeDatabase();
  process.exit(0);
}

// Server startup
async function startServer(port?: number) {
  PORT = port || PORT;
  
  try {
    await initializeDatabase();
    console.log('Database initialized successfully');
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export the Express app and startServer function for testing
export default app;
export { startServer };

// Handle shutdown signals
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

startServer();
