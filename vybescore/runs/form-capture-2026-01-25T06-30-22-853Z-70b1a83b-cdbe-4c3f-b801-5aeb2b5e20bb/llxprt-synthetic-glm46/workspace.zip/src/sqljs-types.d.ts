declare module 'sql.js' {
  export interface Database {
    close(): void;
    export(): Uint8Array;
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    each(sql: string, callback: (row: unknown) => void): void;
  }
  
  export interface Statement {
    run(...params: unknown[]): void;
    get(): unknown;
    all(): unknown[];
    free(): void;
  }
  
  export interface SqlJsStatic {
    Database: {
      new(data?: Uint8Array): Database;
    };
  }
  
  function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<SqlJsStatic>;
  
  export = initSqlJs;
}