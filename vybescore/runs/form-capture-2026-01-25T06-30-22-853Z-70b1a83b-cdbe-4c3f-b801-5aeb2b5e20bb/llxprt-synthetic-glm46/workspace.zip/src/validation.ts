import { FormData, ValidationError } from './types.js';

export function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // First name validation
  if (!formData.firstName || formData.firstName.trim() === '') {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  // Last name validation
  if (!formData.lastName || formData.lastName.trim() === '') {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  // Street address validation
  if (!formData.streetAddress || formData.streetAddress.trim() === '') {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  // City validation
  if (!formData.city || formData.city.trim() === '') {
    errors.push({ field: 'city', message: 'City is required' });
  }

  // State/Province validation
  if (!formData.stateProvince || formData.stateProvince.trim() === '') {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  // Postal code validation (alphanumeric strings allowed)
  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(formData.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, spaces, and hyphens' });
  }

  // Country validation
  if (!formData.country || formData.country.trim() === '') {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!formData.email || formData.email.trim() === '') {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!emailRegex.test(formData.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone number validation (international formats allowed)
  const phoneRegex = /^\+[\d\s\-()]+$/;
  if (!formData.phone || formData.phone.trim() === '') {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!phoneRegex.test(formData.phone.trim())) {
    errors.push({ field: 'phone', message: 'Phone number must start with + and can contain digits, spaces, parentheses, and dashes' });
  }

  return errors;
}

export function getFieldError(errors: ValidationError[], field: string): string | undefined {
  const error = errors.find(e => e.field === field);
  return error?.message;
}