import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import { Submission } from './types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

let dbInstance: initSqlJs.Database | null = null;

export async function initializeDatabase(): Promise<initSqlJs.Database> {
  if (dbInstance) {
    return dbInstance;
  }

  const SQL = await initSqlJs();
  
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load or create database
  try {
    const dbBuffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(dbBuffer);
  } catch (error) {
    // Database doesn't exist, create new one
    dbInstance = new SQL.Database();
    
    // Read and execute schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    dbInstance.run(schema);
    
    // Save initial database
    saveDatabase();
  }

  return dbInstance;
}

export function saveDatabase(): void {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }
  
  const data = dbInstance.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

export function closeDatabase(): void {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
}

export function insertSubmission(submission: Submission): void {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }

  const stmt = dbInstance.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    submission.firstName,
    submission.lastName,
    submission.streetAddress,
    submission.city,
    submission.stateProvince,
    submission.postalCode,
    submission.country,
    submission.email,
    submission.phone
  ]);

  stmt.free();
  
  // Save after each insert
  saveDatabase();
}