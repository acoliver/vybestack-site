/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates if a string contains only valid Base64 characters.
 */
function isValidBase64(input: string): boolean {
  // Check if the string contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  return base64Regex.test(input);
}

/**
 * Decode Base64 text back to plain UTF-8.
 */
export function decode(input: string): string {
  // Validate that the input contains only valid Base64 characters
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  try {
    const decoded = Buffer.from(input, 'base64').toString('utf8');
    
    // Check if the decoded content is valid UTF-8 by encoding it back and comparing
    const reencoded = Buffer.from(decoded, 'utf8').toString('base64');
    const normalizedInput = input.replace(/=+$/, ''); // Remove padding for comparison
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedReencoded) {
      throw new Error('Invalid Base64 input: decoding produced invalid data');
    }
    
    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
