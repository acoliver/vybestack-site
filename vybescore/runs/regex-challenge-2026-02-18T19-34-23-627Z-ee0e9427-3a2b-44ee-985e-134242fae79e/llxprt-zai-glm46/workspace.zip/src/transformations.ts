/**
 * Capitalizes the first character of each sentence.
 * - Capitalizes after sentence-ending punctuation (.?!)
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces
 * - Preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces: replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ');

  // Insert space after sentence-ending punctuation if missing
  normalized = normalized.replace(/([.!?])([a-zA-Z])/g, '$1 $2');

  // Capitalize first character of the string
  normalized = normalized.replace(/^[a-z]/, (match) => match.toUpperCase());

  // Capitalize after sentence-ending punctuation
  // Use a regex that looks for .?! followed by a space and a lowercase letter
  normalized = normalized.replace(/([.!?])\s+([a-z])/g, (_, punct, letter) => {
    return `${punct} ${letter.toUpperCase()}`;
  });

  // Handle case where there's no space after punctuation (edge case)
  normalized = normalized.replace(/([.!?])([a-z])/g, (_, punct, letter) => {
    return `${punct} ${letter.toUpperCase()}`;
  });

  // Trim leading/trailing whitespace
  normalized = normalized.trim();

  return normalized;
}

/**
 * Extracts all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: http:// or https:// followed by non-whitespace
  // Exclude trailing punctuation (.,;!?:)
  const urlRegex = /https?:\/\/[^\s<]+(?<![.,;!?!:])/g;

  const matches = text.match(urlRegex);

  if (!matches) {
    return [];
  }

  return matches;
}

/**
 * Converts all http:// URLs to https://.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https:// (to avoid double conversion)
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs:
 * - Upgrades scheme to https://
 * - Rewrites /docs/ paths to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern for example.com URLs
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s<]*)/g;

  return text.replace(urlPattern, (match, protocol, host, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';

    // Check if path contains dynamic hints or legacy extensions
    const dynamicHints = ['cgi-bin', '?', '&', '='];
    const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];

    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    const hasLegacyExtension = legacyExtensions.some(ext => path.includes(ext));

    // If path starts with /docs/ and doesn't have dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHint && !hasLegacyExtension) {
      return `${newProtocol}docs.example.com${path}`;
    }

    // Otherwise just upgrade the protocol
    return `${newProtocol}${host}${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or date is impossible.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;

  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  // Special validation for February in non-leap years
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeapYear) {
      return 'N/A';
    }
  }

  return year;
}
