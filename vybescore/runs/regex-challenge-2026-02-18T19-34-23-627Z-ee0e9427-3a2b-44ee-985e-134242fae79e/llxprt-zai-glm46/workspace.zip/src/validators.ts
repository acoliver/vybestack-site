export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant simplified regex
  // Local part: alphanumeric, dots, hyphens, underscores, plus
  // No consecutive dots, no leading/trailing dots in local part
  // Domain: alphanumeric labels separated by dots, no underscores
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;

  // Additional checks for common invalid patterns
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }

  // Check for trailing dot in local part or domain
  if (value.endsWith('.')) {
    return false;
  }

  // Check for underscores in domain
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) {
    return false;
  }

  // Check for leading/trailing dot in local part
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');

  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && cleaned.startsWith('1') && !cleaned.startsWith('+')) {
    // If it starts with 1 and is longer than 10 digits, strip the leading 1
    if (digits.length > 10) {
      digits = digits.substring(1);
    }
  }

  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles with country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep structure
  const normalized = value.replace(/[\s-]/g, '');

  // When country code is omitted, must have trunk prefix 0
  const hasCountryCode = normalized.startsWith('+54') || normalized.startsWith('54');
  
  // Check if we need to verify trunk prefix
  if (!hasCountryCode) {
    // Without country code, must start with 0 (trunk prefix)
    if (!normalized.startsWith('0')) {
      return false;
    }
  }

  // Extract the part after country code (if present) and mobile indicator (if present)
  let remaining = normalized;
  if (remaining.startsWith('+')) {
    remaining = remaining.substring(1); // Remove +
  }
  if (remaining.startsWith('54')) {
    remaining = remaining.substring(2); // Remove country code
  }
  
  // Check for optional mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // Check for optional trunk prefix 0
  if (remaining.startsWith('0')) {
    remaining = remaining.substring(1);
  }

  // Now remaining should be: area code + subscriber number
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  // Total: 8-12 digits
  if (remaining.length < 8 || remaining.length > 12) {
    return false;
  }

  // Must all be digits
  if (!/^\d+$/.test(remaining)) {
    return false;
  }

  // Try to extract area code (2-4 digits starting with 1-9)
  for (let len = 4; len >= 2; len--) {
    if (remaining.length >= len + 6 && remaining.length <= len + 8) {
      const potentialAreaCode = remaining.substring(0, len);
      const potentialSubscriber = remaining.substring(len);
      
      // Area code must start with 1-9
      if (/^[1-9]\d*$/.test(potentialAreaCode) && 
          potentialSubscriber.length >= 6 && 
          potentialSubscriber.length <= 8) {
        return true;
      }
    }
  }

  return false;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Name must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Regex: unicode letters, accents, apostrophes, hyphens, spaces
  // Must have at least one letter, no digits, no symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Must contain at least one letter (unicode)
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  return true;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Check if all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: 13-16 digits, starts with 4
  const visaRegex = /^4\d{12}(?:\d{3})?$/;

  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(?:5[1-5]\d{2}|2[2-7][0-9]{2})\d{12}$/;

  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;

  const validPrefix = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);

  if (!validPrefix) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;

  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}
