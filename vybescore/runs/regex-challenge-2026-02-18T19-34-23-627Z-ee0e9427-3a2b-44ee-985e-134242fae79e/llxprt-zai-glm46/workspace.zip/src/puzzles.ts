/**
 * Finds words starting with the prefix, excluding banned exception words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match word boundaries
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'g');

  const matches = text.match(wordRegex);

  if (!matches) {
    return [];
  }

  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Finds occurrences of token only when it appears after a digit and not at string start.
 * Uses lookaheads/lookbehinds.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match digit followed by token, not at start of string
  // We want to capture the digit+token combination
  const tokenRegex = new RegExp(`(?<!^)\\d${escapedToken}`, 'g');

  const matches = text.match(tokenRegex);

  return matches ? matches : [];
}

/**
 * Validates password strength.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (non-alphanumeric, non-whitespace)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const patternRegex = new RegExp(`(.{${len}})\\1`, 'g');
    if (patternRegex.test(value)) {
      return false;
    }
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns:
  // Full form: 8 groups of 1-4 hex digits separated by colons
  // Compressed form with :: for one or more consecutive zero groups
  // Mixed form (IPv4 embedded): ::ffff:192.168.1.1

  // First, check for IPv4 pattern and exclude it
  // IPv4: four groups of 1-3 digits separated by dots
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;

  // More precise IPv6 regex
  const ipv6Precise = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/;

  // Check if it's just an IPv4 address
  if (ipv4Pattern.test(value) && !ipv6Precise.test(value)) {
    return false;
  }

  // Check for IPv6
  return ipv6Precise.test(value);
}
