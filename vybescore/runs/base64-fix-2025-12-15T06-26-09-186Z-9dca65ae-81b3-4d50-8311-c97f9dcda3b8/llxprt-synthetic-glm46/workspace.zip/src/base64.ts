/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decodes standard Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // First check for invalid character placement of '='
  const equalsIdx = input.indexOf('=');
  if (equalsIdx !== -1) {
    // If '=' is found, characters after it must all be '='
    const afterEquals = input.substring(equalsIdx + 1);
    if (afterEquals && !/^=*$/.test(afterEquals)) {
      throw new Error('Invalid Base64 input: padding not at the end');
    }
    
    // Cannot have more than 2 padding characters
    if (input.length - equalsIdx > 2) {
      throw new Error('Invalid Base64 input: padding not at the end');
    }
  }

  // Validate the input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Check if decoding was successful by round-tripping
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    // Remove padding from both for comparison to handle cases where input was missing padding
    const normalizedOriginal = input.replace(/=+$/, '');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    
    if (normalizedOriginal !== normalizedReencoded) {
      throw new Error('Invalid Base64 input: corrupt data');
    }
    
    return result;
  } catch (error) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
}
