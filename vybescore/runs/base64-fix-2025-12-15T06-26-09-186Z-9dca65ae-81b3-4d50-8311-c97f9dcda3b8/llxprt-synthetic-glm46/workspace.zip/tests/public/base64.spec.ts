import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

describe('Base64 helpers (public)', () => {
  it('encodes plain ASCII text with padding', () => {
    const result = encode('hello');
    expect(result).toBe('aGVsbG8=');
  });

  it('decodes standard Base64 text', () => {
    const result = decode('aGVsbG8=');
    expect(result).toBe('hello');
  });

  it('decodes Base64 text without padding', () => {
    const result = decode('aGVsbG8');
    expect(result).toBe('hello');
  });

it('encodes non-ASCII text', () => {
    const result = encode('émoji');
    expect(result).toBe('w6ltb2pp');
  });

  it('decodes non-ASCII text', () => {
    const result = decode('w6ltb2pp');
    expect(result).toBe('émoji');
  });

  it('throws error for invalid Base64 characters', () => {
    expect(() => decode('invalid!base64')).toThrow('Invalid Base64 input: contains non-Base64 characters');
  });

  it('throws error for invalid padding placement', () => {
    expect(() => decode('YW=Jj')).toThrow('Invalid Base64 input: padding not at the end');
  });

  it('throws error for excessive padding', () => {
    expect(() => decode('YWJjZA===')).toThrow();
  });

  it('handles edge cases with 1-byte input', () => {
    const encoded = encode('a');
    expect(encoded).toBe('YQ==');
    expect(decode(encoded)).toBe('a');
  });

  it('handles edge cases with 2-byte input', () => {
    const encoded = encode('ab');
    expect(encoded).toBe('YWI=');
    expect(decode(encoded)).toBe('ab');
  });

  it('handles edge cases with 3-byte input (no padding needed)', () => {
    const encoded = encode('abc');
    expect(encoded).toBe('YWJj');
    expect(decode(encoded)).toBe('abc');
  });
});
