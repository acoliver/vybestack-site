/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Core interfaces
export interface Subject<T> {
  value: T
  observers: Set<SubjectObserver>
  notify(): void
}

export interface SubjectObserver {
  value?: unknown
  updateFn: UpdateFn<unknown>
  dependencies: Set<Subject<unknown>>
  notify(): void
  evaluate(): void
}

// Type alias for backward compatibility
export type Observer = SubjectObserver

// Global active observer for dependency tracking
let activeObserver: Observer | undefined

export function getActiveObserver(): Observer | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer | undefined) {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

export function addDependency<T>(observer: Observer, subject: Subject<T>) {
  // Initialize dependencies set if it doesn't exist
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(subject)
  subject.observers.add(observer)
}

export function notifyObserver(observer: Observer) {
  observer.notify()
}
