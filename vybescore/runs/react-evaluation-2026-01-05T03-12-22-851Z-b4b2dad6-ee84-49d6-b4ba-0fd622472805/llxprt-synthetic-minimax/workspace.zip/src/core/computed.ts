/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn,
  SubjectObserver,
  Subject,
  getActiveObserver,
  setActiveObserver,
  addDependency,
  EqualFn,
  Options
} from '../types/reactive'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  _value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): GetterFn<T> {
  // Initialize currentValue to avoid usage before assignment
  let currentValue: T
  let isInitialized = false
  let isComputing = false

  // Internal observer for managing dependencies
  const observer: SubjectObserver = {
    value: undefined,
    updateFn,
    dependencies: new Set(),
    notify() {
      // Re-evaluate when dependencies change
      this.evaluate()
    },
    evaluate() {
      if (isComputing) {
        return // Prevent circular dependencies
      }
      
      isComputing = true
      try {
        // Clear old dependencies
        const oldDeps = Array.from(this.dependencies)
        oldDeps.forEach((dep: any) => {
          if (dep.observers) {
            dep.observers.delete(this)
          }
        })
        this.dependencies.clear()
        
        // Re-evaluate with fresh dependency tracking
        const previous = setActiveObserver(this)
        try {
          const newValue = updateFn(this.value)
          this.value = newValue
          currentValue = newValue
          isInitialized = true
        } finally {
          setActiveObserver(previous)
        }
        
        // Notify observers of computed value change
        computedSubject.observers.forEach(obs => obs.evaluate())
      } finally {
        isComputing = false
      }
    }
  }

  // Create a subject for this computed value
  const computedSubject: Subject<T> = {
    value: undefined as T,
    observers: new Set(),
    notify() {
      const observers = Array.from(this.observers)
      observers.forEach(obs => obs.evaluate())
    }
  }

  // Getter function
  const getter: GetterFn<T> = () => {
    // Only evaluate if not initialized or dependencies have changed
    if (!isInitialized) {
      isComputing = true
      try {
        const previous = setActiveObserver(observer)
        try {
          currentValue = updateFn(observer.value)
          observer.value = currentValue
          computedSubject.value = currentValue
          isInitialized = true
        } finally {
          setActiveObserver(previous)
        }
      } finally {
        isComputing = false
      }
    } else {
      // Re-evaluate to get fresh value
      observer.evaluate()
    }
    
    // Register as dependency if there's an active observer
    const active = getActiveObserver()
    if (active && active !== observer) {
      addDependency(active, computedSubject)
    }
    
    return currentValue
  }

  return getter
}
