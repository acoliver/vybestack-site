/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn,
  SubjectObserver,
  setActiveObserver,
  EqualFn,
  Options
} from '../types/reactive'

export function createCallback<T>(
  updateFn: UpdateFn<T>, 
  _value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): UnsubscribeFn {
  let currentValue: T
  
  const observer: SubjectObserver = {
    value: undefined,
    updateFn,
    dependencies: new Set(),
    notify() {
      // Execute the callback when dependencies change
      try {
        const result = updateFn(this.value)
        this.value = result
        currentValue = result
      } catch (error) {
        // Handle error silently for callbacks
        console.warn('Callback error:', error)
      }
    },
    evaluate() {
      // Evaluate callback
      const previous = setActiveObserver(this)
      try {
        const result = updateFn(this.value)
        this.value = result
        currentValue = result
      } finally {
        setActiveObserver(previous)
      }
    }
  }

  // Initial evaluation
  const previous = setActiveObserver(observer)
  try {
    currentValue = updateFn(observer.value)
    observer.value = currentValue
  } finally {
    setActiveObserver(previous)
  }

  // Return unsubscribe function
  return () => {
    // Clean up dependencies
    const dependencies = Array.from(observer.dependencies)
    dependencies.forEach((dep: SubjectObserver) => {
      if (dep.observers) {
        dep.observers.delete(observer)
      }
    })
    observer.dependencies.clear()
  }
}
