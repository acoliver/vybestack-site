/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  addDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    value,
    observers: new Set(),
    notify() {
      // Notify all observers
      const observers = Array.from(this.observers)
      observers.forEach(observer => {
        observer.evaluate()
      })
    }
  }

  const read: GetterFn<T> = () => {
    const active = getActiveObserver()
    
    // Register this input as a dependency of the active observer
    if (active) {
      addDependency(active, subject)
    }
    
    return subject.value
  }

  const write: SetterFn<T> = (newValue) => {
    subject.value = newValue
    
    // Notify all observers that depend on this input
    subject.notify()
    
    return subject.value
  }

  return [read, write]
}
