import { createInput, createComputed, createCallback } from './src/index.ts'

// Test 1: Basic dependency tracking
console.log('Test 1: Basic dependency tracking')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial sum:', sum()) // Should be 32
setInput(3)
console.log('Updated sum:', sum()) // Should be 96

// Test 2: Callbacks firing
console.log('\nTest 2: Callbacks firing')
const [input2, setInput2] = createInput(1)
const output2 = createComputed(() => input2() + 1)
let value = 0
const callback = createCallback(() => {
  value = output2()
  console.log('Callback fired, value:', value)
})

console.log('Initial callback value:', value)
setInput2(3)
console.log('After input change callback value:', value)

// Test 3: Callback subscription management
console.log('\nTest 3: Callback subscription')
const [input3, setInput3] = createInput(11)
const output3 = createComputed(() => input3() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => {
  values1.push(output3())
  console.log('Callback 1 fired')
})

const values2 = []
const callback2 = createCallback(() => {
  values2.push(output3())
  console.log('Callback 2 fired')
})

console.log('Initial values1:', values1.length, 'values2:', values2.length)
setInput3(31)
console.log('After first change values1:', values1.length, 'values2:', values2.length)

unsubscribe1()
setInput3(41)
console.log('After unsubscribe values1:', values1.length, 'values2:', values2.length)