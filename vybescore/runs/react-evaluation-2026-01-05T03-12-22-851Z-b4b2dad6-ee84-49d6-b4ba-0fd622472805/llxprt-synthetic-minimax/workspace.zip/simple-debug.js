import { createInput } from '../src/core/input.js'
import { createComputed } from '../src/core/computed.js'
import { createCallback } from '../src/core/callback.js'

console.log('=== DEBUGGING REACTIVE SYSTEM ===\n')

// Test 1: Basic Input Creation
console.log('Test 1: Basic Input')
const [getInput, setInput] = createInput(5)
console.log('Initial value:', getInput()) // Should be 5
setInput(10)
console.log('After change:', getInput()) // Should be 10

// Test 2: Simple Computed Value
console.log('\nTest 2: Simple Computed')
const [input, setInput2] = createInput(3)
const double = createComputed(() => input() * 2)
console.log('Initial double:', double()) // Should be 6
setInput2(5)
console.log('After change double:', double()) // Should be 10

// Test 3: Computed of Computed
console.log('\nTest 3: Computed of Computed')
const [input3, setInput3] = createInput(2)
const timesTwo = createComputed(() => input3() * 2) // Should be 4
const timesFour = createComputed(() => timesTwo() * 2) // Should be 8
console.log('Initial timesFour:', timesFour()) // Should be 8
setInput3(3)
console.log('After change timesFour:', timesFour()) // Should be 12

console.log('\n=== END DEBUG ===')