/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a pattern to match words starting with prefix
  // \b ensures we match word boundaries - need to escape backslashes properly
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out the exceptions
  return matches.filter(match => !exceptions.includes(match));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Match the token that follows a digit (include the digit in the match)
  const digitAndTokenPattern = new RegExp(`\\d${token}`, 'g');
  const digitAndTokenMatches = text.match(digitAndTokenPattern) || [];
  
  return digitAndTokenMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Requirements:
  // - At least 10 characters
  // - One uppercase letter
  // - One lowercase letter  
  // - One digit
  // - One symbol
  // - No whitespace
  // - No immediate repeated sequences (e.g., 'abab' should fail)
  
  // Check length
  if (value.length < 10) return false;
  
  // Check no whitespace
  if (/\s/.test(value)) return false;
  
  // Check character types
  if (!/[A-Z]/.test(value)) return false;  // Uppercase
  if (!/[a-z]/.test(value)) return false;  // Lowercase
  if (!/\d/.test(value)) return false;     // Digit
  if (!/[!@#$%^&*()_+={}[\]{};':"|,.<>?]/.test(value)) return false; // Symbol
  
  // Check for immediate repeated sequences (e.g., 'abab', '1212')
  // Pattern looks for any sequence of 2+ characters that repeats immediately
  if (/(..)\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that handles various formats including shorthand
  // This pattern matches full and compressed IPv6 addresses
  // Removed ^ and $ anchors to allow searching within text
  const ipv6Pattern = /[a-f0-9]*:([a-f0-9]*:){0,7}[a-f0-9]*/i;
  
  // Check if this looks like IPv4 addresses, if so, return false
  const ipv4Pattern = /\d{1,3}(\.\d{1,3}){3}/;
  if (ipv4Pattern.test(value)) {
    // If it contains IPv4 pattern, check if it also has IPv6 patterns
    // IPv6 addresses should have colons for proper identification
    if (!value.includes(':')) return false;
  }
  
  // Search for IPv6 patterns within the text
  // Must contain colons to be IPv6
  if (!value.includes(':')) return false;
  
  return ipv6Pattern.test(value);
}
