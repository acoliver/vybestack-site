/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces between sentences
  let result = text;
  
  // Split into sentences using punctuation .,?! as sentence enders
  result = result.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Capitalize first letter of each sentence
  result = result.replace(/([.!?]\s*)([a-z])/g, (match, sentenceEnd, letter) => {
    return sentenceEnd + letter.toUpperCase();
  });
  
  // Capitalize first letter of the text if it starts with lowercase
  if (result.length > 0 && /^[a-z]/.test(result)) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs without trailing punctuation
  // Match http(s):// followed by domain and path, stopping at punctuation or end
  const urlPattern = /https?:\/\/[^\s,!?;:()]+(?=\s|[,!?;:()]|$)/g;
  
  const matches = text.match(urlPattern) || [];
  return matches.map(url => {
    // Remove trailing punctuation from URLs
    return url.replace(/[.,!?;:()]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with potential /docs/ path
  const urlPattern = /(http:\/\/)([^/\s]+)(\/docs\/[^\s]*)/g;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Check if path contains dynamic hints or legacy extensions
    if (/[?&]|=|\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path)) {
      // Still upgrade scheme to https but keep original host
      return `https://${host}${path}`;
    } else {
      // Rewrite host to docs subdomain and upgrade to https
      return `https://docs.${host}${path}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const [, month, day] = match;
  
  // Additional validation for months with 30 days and February
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Check for 30-day months
  if ([4, 6, 9, 11].includes(monthNum) && dayNum === 31) {
    return 'N/A';
  }
  
  // Check for February (leap year handling)
  if (monthNum === 2) {
    const yearNum = parseInt(match[3], 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    
    if (!isLeapYear && dayNum > 28) {
      return 'N/A';
    }
    if (isLeapYear && dayNum > 29) {
      return 'N/A';
    }
  }
  
  return match[3];
}
