export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum validation
function runLuhnCheck(creditCardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = creditCardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(creditCardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Trim whitespace
  value = value.trim();
  
  // Check for obviously invalid patterns
  // No double dots allowed
  if (value.includes('..')) return false;
  
  // Cannot start or end with dots
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  // Basic email pattern with validation
  // Local part: letters, numbers, +, -, ., but not at start/end
  // Domain: letters, numbers, hyphens, dots, but no underscores
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9+._-]*@[a-zA-Z0-9][a-zA-Z0-9-]*\.[a-zA-Z]{2,}(?:[a-zA-Z]{2})?$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Additional check for domain underscores (specifically forbidden)
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value) return false;
  
  // Remove all whitespace and separators for validation
  const cleanValue = value.replace(/[\s().-]/g, '');
  
  // Check for extension if options allowExtensions
  let cleanForDigits = cleanValue;
  if (options?.allowExtensions) {
    // Remove extension patterns like 'ext', 'x', etc.
    cleanForDigits = cleanValue.replace(/(ext|x|extension).*/i, '');
  }
  
  const digitsOnly = cleanForDigits.replace(/\D/g, '');
  
  // Must have at least 10 digits, max 11 (with country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // Handle country code
  let areaCode = '';
  let remainingDigits = '';
  
  if (digitsOnly.length === 11) {
    // Check if first digit is 1 (country code)
    if (digitsOnly[0] !== '1') return false;
    areaCode = digitsOnly.substring(1, 4);
    remainingDigits = digitsOnly.substring(4);
  } else if (digitsOnly.length === 10) {
    areaCode = digitsOnly.substring(0, 3);
    remainingDigits = digitsOnly.substring(3);
  } else {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check prefix (first digit cannot be 0 or 1)
  const prefix = remainingDigits.substring(0, 3);
  if (prefix[0] === '0' || prefix[0] === '1') return false;
  
  // Line number should be exactly 4 digits
  const lineNumber = remainingDigits.substring(3);
  if (lineNumber.length !== 4) return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Clean the input: remove spaces, hyphens, and other punctuation
  const cleaned = value.replace(/[\s().-]/g, '');
  
  if (!cleaned) return false;
  
  // Try to match different Argentine phone formats
  
  // Format 1: +54 341 123 4567 (country code + area + subscriber)
  let match = cleaned.match(/^\+54(\d{2,4})(\d{6,8})$/);
  
  if (!match) {
    // Format 2: 0 11 1234 5678 (trunk prefix + area + subscriber)
    match = cleaned.match(/^0(\d{2,4})(\d{6,8})$/);
    
    if (!match) {
      // Format 3: +54 9 11 1234 5678 (country code + mobile indicator + area + subscriber)
      match = cleaned.match(/^\+54(9)?(\d{2,4})(\d{6,8})$/);
      
      if (!match) return false;
    }
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code (2-4 digits, leading 1-9)
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0' || areaCode[0] === '9') return false;
  
  // Validate subscriber number (6-8 digits total)
  if (!subscriberNumber || subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  value = value.trim();
  
  // Empty string is not a valid name
  if (!value) return false;
  
  // Pattern: unicode letters (including accented), apostrophes, hyphens, spaces
  // Reject digits and symbols, and special patterns like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Check for obviously invalid patterns
  // Reject names containing digits
  if (/\d/.test(value)) return false;
  if (!/[\p{L}]/u.test(value)) return false;

  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(creditCardValue: string): boolean {
  // Clean the input: remove all non-digits
  const cleanValue = creditCardValue.replace(/\D/g, '');
  
  // Must have at least 13 digits and at most 19 (typical range)
  if (cleanValue.length < 13 || cleanValue.length > 19) return false;
  
  // Check card prefixes and patterns:
  // Visa: starts with 4, length 13, 16, 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  
  let isValidCardType = false;
  
  // Visa: 4 followed by 12-15 more digits (13, 16, 19 total)
  if (cleanValue.startsWith('4')) {
    if (cleanValue.length === 13 || cleanValue.length === 16 || cleanValue.length === 19) {
      isValidCardType = true;
    }
  }
  // Mastercard: 51-55 or 2221-2720 (16 digits)
  else if (cleanValue.startsWith('51') || cleanValue.startsWith('52') || 
           cleanValue.startsWith('53') || cleanValue.startsWith('54') || 
           cleanValue.startsWith('55') || cleanValue.startsWith('2221') || 
           cleanValue.startsWith('2222') || cleanValue.startsWith('2223') || 
           cleanValue.startsWith('2224') || cleanValue.startsWith('2225') || 
           cleanValue.startsWith('2226') || cleanValue.startsWith('2227') || 
           cleanValue.startsWith('2720')) {
    if (cleanValue.length === 16) {
      isValidCardType = true;
    }
  }
  // American Express: 34 or 37 (15 digits)
  else if (cleanValue.startsWith('34') || cleanValue.startsWith('37')) {
    if (cleanValue.length === 15) {
      isValidCardType = true;
    }
  }
  
  // If no valid card type found, return false
  if (!isValidCardType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}
