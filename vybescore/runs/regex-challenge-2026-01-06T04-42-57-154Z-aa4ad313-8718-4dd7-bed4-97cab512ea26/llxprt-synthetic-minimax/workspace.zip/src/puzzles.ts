/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Pattern to find words starting with the prefix
  // Use word boundaries to ensure we're matching complete words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordBoundaryPattern = new RegExp(`\\b${escapedPrefix}[\\w]*\\b`, 'gi');
  
  const foundWords: string[] = [];
  let match;
  
  while ((match = wordBoundaryPattern.exec(text)) !== null) {
    const word = match[0];
    
    // Check if word is in exceptions (case-insensitive)
    if (!exceptions.some(exc => exc.toLowerCase() === word.toLowerCase())) {
      foundWords.push(word);
    }
  }
  
  // Remove duplicates while preserving order
  const uniqueWords = foundWords.filter((word, index) => foundWords.indexOf(word) === index);
  
  return uniqueWords;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  const foundTokens: string[] = [];
  
  // Find token positions first
  const tokenPositions: number[] = [];
  let pos = 0;
  
  while ((pos = text.indexOf(token, pos)) !== -1) {
    tokenPositions.push(pos);
    pos += token.length;
  }
  
  // Check each occurrence
  tokenPositions.forEach(tokenPos => {
    // Check if not at string beginning and preceded by digit
    if (tokenPos > 0) {
      const charBefore = text.charAt(tokenPos - 1);
      if (/\d/.test(charBefore)) {
        // Return the full match including the preceding digit
        foundTokens.push(charBefore + token);
      }
    }
  });
  
  return foundTokens;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check minimum length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for no immediate repeated sequences (like abab, abab)
  // This pattern looks for any sequence that repeats immediately
  // e.g., "abab", "xyxy", "1a2a1a2a" etc.
  const repeatPattern = /(.{2,}).{0,}\1/;
  if (repeatPattern.test(value)) return false;
  
  // Also check for very obvious patterns like "abcabc", "123123"
  const simpleRepeatPattern = /(..+).{0,}\1/;
  if (simpleRepeatPattern.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First, check if there's an IPv4 pattern to reject immediately
  // IPv4 pattern: 4 numbers separated by dots, each 0-255
  const ipv4Pattern = /\b(\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // Double check this is actually IPv4 format (not just coincidental numbers)
    const numbers = value.match(/\b\d{1,3}\b/g) || [];
    for (const num of numbers) {
      const numVal = parseInt(num, 10);
      if (numVal > 255) return false; // Invalid IPv4, could be IPv6
    }
    // If we get here, it's a valid IPv4 format
    return false;
  }
  
  // Check for IPv6-specific elements:
  // 1. Contains colons (required for IPv6)
  if (!value.includes(':')) return false;
  
  // Validate the structure
  const parts = value.split(':');
  
  // Check if this looks like an IPv6 address
  let hasValidIPv6Structure = false;
  
  // Case 1: Contains :: (shorthand)
  if (value.includes('::')) {
    // Count parts, :: should compress multiple zero parts
    const nonEmptyParts = parts.filter(part => part.length > 0);
    if (nonEmptyParts.length >= 2 && nonEmptyParts.length <= 8) {
      hasValidIPv6Structure = true;
    }
  }
  // Case 2: Normal IPv6 (8 groups with some possibly empty if shorthand used elsewhere)
  else {
    // Should have exactly 8 parts for full IPv6
    const hexPattern = /^[a-f0-9]{1,4}$/i;
    let validGroups = 0;
    
    for (const part of parts) {
      if (part.length === 0) continue; // Skip empty parts (shouldn't happen without ::)
      if (hexPattern.test(part)) {
        validGroups++;
      } else {
        // If we find invalid hex groups, it's not IPv6
        return false;
      }
    }
    
    // Valid IPv6 should have 4-8 groups that are valid hex
    if (validGroups >= 4 && validGroups <= 8) {
      hasValidIPv6Structure = true;
    }
  }
  
  return hasValidIPv6Structure;
}
