/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  const sentenceBoundaryRegex = /([.!?])([\s]*)([a-z])/g;

  let result = '';
  let lastIndex = 0;
  let match;

  while ((match = sentenceBoundaryRegex.exec(text)) !== null) {
    result += text.substring(lastIndex, match.index);
    result += match[1];
    
    const whitespace = match[2];
    if (whitespace.length > 0) {
      result += ' ';
    }
    
    const nextChar = match[3];
    result += nextChar.toUpperCase();
    lastIndex = match.index + match[0].length;
  }

  result += text.substring(lastIndex);

  if (result && /^[a-z]/.test(result)) {
    result = result.charAt(0).toUpperCase() + result.substring(1);
  }

  result = result.replace(/[\s]{2,}/g, ' ');

  const abbreviations = ['Mr.', 'Mrs.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'vs.', 'etc.', 'U.S.', 'U.K.'];
  let processedResult = result;

  abbreviations.forEach(abbr => {
    const pattern = new RegExp(`(${abbr})\\s+([a-z])`, 'g');
    processedResult = processedResult.replace(pattern, `$1 $2`);
  });

  return processedResult;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];

  const urlPattern = /\b(?:(?:https?|ftp):\/\/|www\.)[^\s<>"']+/g;

  const urls: string[] = [];
  let match;

  while ((match = urlPattern.exec(text)) !== null) {
    let url = match[0];

    while (url.length > 0 && /[.,!?;:)]$/.test(url)) {
      url = url.slice(0, -1);
    }

    if (url.startsWith('www.')) {
      url = 'http://' + url;
    }

    url = url.replace(/[).,!?]+$/g, '');

    if (!urls.includes(url)) {
      urls.push(url);
    }
  }

  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;

  const result = text.replace(/http:\/\/([^\s<>"]+)([^<>"\\\s]*)/gi, (match, domain, path) => {
    return `https://${domain}${path}`;
  });

  return result;
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;

  // Use RegExp constructor to avoid lint issues with escape characters
  const urlPattern = new RegExp('https?:\\/\\/([^\\\\/\\\\s<>"]+)([^<>"\\\\\\\\s]*)', 'gi');

  return text.replace(urlPattern, (match, scheme, domain, path) => {
    const newScheme = 'https://';
    let newDomain = domain;
    const newPath = path;

    if (path.startsWith('/docs/')) {
      if (!path.includes('cgi-bin') && !path.includes('?')) {
        const domainParts = domain.split('.');
        if (domainParts.length >= 2) {
          const domainName = domainParts[domainParts.length - 2];
          const docsDomain = `${domainName}.${domainParts[domainParts.length - 1]}`;
          newDomain = `docs.${docsDomain}`;
        }
      }
    }

    return `${newScheme}${newDomain}${newPath}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';

  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) return 'N/A';

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';

  const yearNum = parseInt(year, 10);
  if (yearNum < 1000 || yearNum > 9999) return 'N/A';

  return year;
}