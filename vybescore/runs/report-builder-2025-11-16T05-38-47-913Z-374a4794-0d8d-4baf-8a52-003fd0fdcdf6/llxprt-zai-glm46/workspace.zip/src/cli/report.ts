#!/usr/bin/env node

import fs from 'fs';

import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';



interface CliOptions {
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): { filePath: string; options: CliOptions } {
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const filePath = args[2];
  const options: CliOptions = {
    format: '',
    includeTotals: false,
  };

  for (let i = 3; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        options.format = args[++i];
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        options.output = args[++i];
        break;
      case '--includeTotals':
        options.includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown option ${args[i]}`);
        process.exit(1);
    }
  }

  if (!options.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { filePath, options };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title (must be string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary (must be string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries (must be array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: entry ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: entry ${i} missing or invalid label (must be string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: entry ${i} missing or invalid amount (must be number)`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries,
  };
}

function main() {
  try {
    const { filePath, options } = parseArguments(process.argv);

    let fileContent: string;
    try {
      fileContent = fs.readFileSync(filePath, 'utf-8');
    } catch (error) {
      console.error(`Error: Cannot read file "${filePath}": ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file "${filePath}": ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }

    const reportData = validateReportData(jsonData);

    let output: string;
    switch (options.format) {
      case 'markdown':
        output = renderMarkdown(reportData, { includeTotals: options.includeTotals });
        break;
      case 'text':
        output = renderText(reportData, { includeTotals: options.includeTotals });
        break;
      default:
        console.error(`Error: Unsupported format "${options.format}"`);
        process.exit(1);
    }

    if (options.output) {
      try {
        fs.writeFileSync(options.output, output, 'utf-8');
      } catch (error) {
        console.error(`Error: Cannot write to output file "${options.output}": ${error instanceof Error ? error.message : String(error)}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();