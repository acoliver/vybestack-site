export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like user@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing/leading dots
  if (value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Split into local and domain parts
  const atPos = value.lastIndexOf('@');
  if (atPos <= 0) {
    return false; // No @ or @ at start
  }
  
  const local = value.substring(0, atPos);
  const domain = value.substring(atPos + 1);
  
  // Check local part doesn't start or end with dot
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // Check domain has no underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Check domain doesn't start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  // Local part can contain @ and other special chars
  const localRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
  // Domain part: standard domain pattern
  const domainRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  return localRegex.test(local) && domainRegex.test(domain);
}

/**
 * Validates US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + for country code
  let cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length === 11) {
    cleaned = cleaned.substring(1);
  }
  
  // Must be exactly 10 digits
  if (cleaned.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = cleaned.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code cannot start with 0 or 1
  const exchangeCode = cleaned.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Match: optional +54, optional 0 trunk prefix, optional 9 mobile indicator, area code, subscriber number
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriber = match[2];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // If country code is omitted, must have trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = /^\+?540/.test(cleaned) || (!hasCountryCode && cleaned.startsWith('0'));
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and strange names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, apostrophes, hyphens, spaces, and common accented characters
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  // Must have at least one letter
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }
  
  // Reject if contains digits or certain symbols
  if (/[\d@#$%^&*()_+=[\]{}|:;"<>,.?/`~]/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Helper: Run Luhn checksum on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths. Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 4, 13 or 16 digits
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  // Mastercard: 51-55 or 2221-2720, 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$|^2[2-7]\d{14}$/;
  // AmEx: 34 or 37, 15 digits
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  return runLuhnCheck(cleaned);
}
