/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces to single space
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Capitalize first character
  if (normalized.length > 0) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize after sentence terminators (. ! ?)
  // Use lookbehind to find terminators followed by space and lowercase letter
  normalized = normalized.replace(/([.!?])\s+([a-z])/g, (match, terminator, letter) => {
    return terminator + ' ' + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * Extracts all URLs from text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: http/https, domain with optional port, path, query, fragment
  const urlRegex = /https?:\/\/(?:[-\w])+(?:\.[-\w]+)+(?::\d+)?(?:\/[^\s]*)?/gi;
  
  const urls: string[] = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation (.,;:?!) but not / or #
    url = url.replace(/[.,;:!?]+$/, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Converts all http:// URLs to https://.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... URLs:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/example\.com(\/[^\s]*)?/gi, (match, path = '') => {
    // Upgrade scheme to https
    const httpsUrl = match.replace(/^http:/i, 'https:');
    
    // Check if we should rewrite the host
    // Skip if path contains dynamic hints
    const dynamicHints = ['cgi-bin', '?', '&', '='];
    const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    const hasLegacyExtension = legacyExtensions.some(ext => path.toLowerCase().includes(ext));
    
    // If path starts with /docs/ and no dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHint && !hasLegacyExtension) {
      return `https://docs.example.com${path}`;
    }
    
    // Otherwise just upgrade the scheme
    return httpsUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
