/**
 * Finds words starting with a prefix, excluding listed exceptions.
 * Returns array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with prefix
  const prefixRegex = new RegExp('\\b' + escapedPrefix + '\\w+', 'gi');
  
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * Finds occurrences of a token that appear after a digit.
 * Does not match tokens at the start of the string.
 * Uses lookbehind to ensure token follows a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // The test expects the full match including the digit prefix
  // So we need to capture digit+token together
  const fullMatchRegex = new RegExp('(?<!^)(\\d' + escapedToken + ')', 'g');
  const fullMatches = text.match(fullMatchRegex) || [];
  
  return fullMatches;
}

/**
 * Validates password strength.
 * At least 10 chars, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace, no immediate repeated sequences (like abab).
 */
export function isStrongPassword(value: string): boolean {
  // Check length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase, one lowercase, one digit, one symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (2+ character sequences repeated)
  // e.g., "abab" or "123123"
  for (let i = 0; i < value.length - 3; i++) {
    for (let len = 2; len <= (value.length - i) / 2; len++) {
      const pattern = value.substring(i, i + len);
      const next = value.substring(i + len, i + len * 2);
      if (pattern === next) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern:
  // - 8 groups of 1-4 hex digits separated by colons
  // - Can use :: shorthand (but only once)
  // - Can have IPv4 at the end (but not pure IPv4)
  
  // First, check if it looks like pure IPv4
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // More precise IPv6 pattern
  const ipv6Precise = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$|^::$|^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}$|^(?:[0-9a-fA-F]{1,4}:){1,7}:$|^:(?::[0-9a-fA-F]{1,4}){1,7}$/;
  
  // Check if value contains an IPv6 address
  // Look for patterns with colons and hex digits
  const hasColons = value.includes(':');
  if (!hasColons) {
    return false;
  }
  
  // Extract potential IPv6 addresses from the text
  const potentialIPv6 = value.match(/[0-9a-fA-F:]{3,}/g) || [];
  
  for (const candidate of potentialIPv6) {
    // Check if it's a valid IPv6 pattern
    if (ipv6Precise.test(candidate)) {
      return true;
    }
    
    // Check for shorthand :: notation
    if (candidate.includes('::') && /[0-9a-fA-F]/.test(candidate)) {
      return true;
    }
    
    // Check for multiple colons with hex digits
    const colons = (candidate.match(/:/g) || []).length;
    if (colons >= 2 && /[0-9a-fA-F]/.test(candidate)) {
      // Must have hex digits and colons in valid pattern
      if (/^[0-9a-fA-F:]+$/.test(candidate)) {
        return true;
      }
    }
  }
  
  return false;
}
