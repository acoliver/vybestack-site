export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Accept typical formats like name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for obviously invalid forms
  if (value.includes('..') || // No double dots
      value.endsWith('.') || // No trailing dots
      value.includes('@.') || value.includes('.@') || // No @ or dots in wrong places
      value.split('@')[1]?.includes('_')) { // No underscores in domain
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except the leading +
  const cleanValue = value.trim();
  
  // Check for leading +
  if (cleanValue.startsWith('+1')) {
    const digits = cleanValue.slice(2).replace(/\D/g, '');
    return digits.length === 10 && isValidAreaCode(digits.substring(0, 3));
  }
  
  // Check for common formats
  const allDigits = cleanValue.replace(/\D/g, '');
  
  // Must have exactly 10 digits for valid US phone
  if (allDigits.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits)
  const areaCode = allDigits.substring(0, 3);
  if (!isValidAreaCode(areaCode)) {
    return false;
  }
  
  // Format should be area code + central office code + line number
  // Additional check for invalid area codes (0 or 1)
  return true;
}

// Helper function to validate US area codes
function isValidAreaCode(areaCode: string): boolean {
  if (areaCode.length !== 3) return false;
  
  const first = areaCode.charAt(0);
  
  // First digit cannot be 0 or 1 for valid area code
  if (first === '0' || first === '1') return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input: remove spaces, hyphens, and most punctuation
  const cleanValue = value.replace(/[\s-]/g, '').replace(/[()]/g, '');
  
  // Pattern for Argentine phone validation
  // Optional +54 (country code)
  // Optional 9 (mobile indicator, only when country code present)
  // Required 0 (trunk prefix, when no country code)
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits total
  
  let pos = 0;
  
  // Check for optional country code
  let hasCountryCode = false;
  if (cleanValue.startsWith('+54')) {
    hasCountryCode = true;
    pos = 3;
  }
  
  // Check for optional mobile indicator (9)
  let hasMobileIndicator = false;
  if (pos < cleanValue.length && cleanValue.charAt(pos) === '9') {
    hasMobileIndicator = true;
    pos++;
  }
  
  // For non-country code numbers, trunk prefix (0) is required
  let hasTrunkPrefix = false;
  if (!hasCountryCode && pos < cleanValue.length && cleanValue.charAt(pos) === '0') {
    hasTrunkPrefix = true;
    pos++;
  } else if (hasCountryCode && !hasMobileIndicator && pos < cleanValue.length && cleanValue.charAt(pos) === '0') {
    // Trunk prefix can also be present after country code
    hasTrunkPrefix = true;
    pos++;
  }
  
  // Validate trunk prefix requirement
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Area code: 2-4 digits starting with 1-9
  if (pos >= cleanValue.length) return false;
  
  const areaCodeMatch = cleanValue.substring(pos).match(/^[1-9]\d{1,3}/);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[0];
  pos += areaCode.length;
  
  // Remaining digits should be 6-8 subscriber number digits
  const remainingDigits = cleanValue.substring(pos);
  if (remainingDigits.length < 6 || remainingDigits.length > 8) return false;
  
  // Ensure all remaining characters are digits
  if (!/^\d{6,8}$/.test(remainingDigits)) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const name = value.trim();
  
  // Name must not be empty
  if (!name) return false;
  
  // Reject obviously invalid patterns like "X Æ A-12" 
  // This contains special characters and numbers that are not allowed
  if (/[0-9]/.test(name)) return false; // No digits allowed
  
  // Allow letters (including unicode), spaces, hyphens, apostrophes
  // Reject symbols and other special characters
  // Pattern allows unicode letters, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}][\p{L}\s'-]*[\p{L}]$|^[\p{L}]$/u;
  
  if (!nameRegex.test(name)) {
    return false;
  }
  
  // Additional validation: must contain at least one letter
  if (!/[\p{L}]/u.test(name)) {
    return false;
  }
  
  // Reject names with problematic characters
  if (/[<>{}()[\]|`~!@#$%^&*=+_]/.test(name)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Card number must be between 13-19 digits
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check basic card types (Visa, Mastercard, AmEx)
  if (!isValidCardPrefix(digits)) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return luhnCheck(digits);
}

// Luhn checksum algorithm
function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let alternate = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (alternate) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    alternate = !alternate;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}

// Basic card prefix validation
function isValidCardPrefix(digits: string): boolean {
  // Visa: starts with 4, length 13, 16, or 19
  if (digits.startsWith('4')) {
    return digits.length === 13 || digits.length === 16 || digits.length === 19;
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if (digits.startsWith('51') || digits.startsWith('52') || 
      digits.startsWith('53') || digits.startsWith('54') || digits.startsWith('55')) {
    return digits.length === 16;
  }
  
  // Mastercard 2221-2720 range (first 4 digits)
  if (digits.length >= 4) {
    const prefix4 = digits.substring(0, 4);
    if (prefix4 >= '2221' && prefix4 <= '2720') {
      return digits.length === 16;
    }
  }
  
  // American Express: starts with 34 or 37, length 15
  if (digits.startsWith('34') || digits.startsWith('37')) {
    return digits.length === 15;
  }
  
  return false;
}
