/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing by collapsing multiple spaces into single spaces
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Pattern to find sentence boundaries: end of sentence followed by space and start of new sentence
  // We'll capitalize the first letter after sentence terminators (.?!)
  return normalized.replace(/([.?!])\s+([a-z])/g, (match, terminator, letter) => {
    return terminator + ' ' + letter.toUpperCase();
  }).replace(/^([a-z])/, (match, letter) => {
    // Capitalize the very first letter if it's at the beginning
    return letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regular expression to match URLs
  // This pattern matches http(s):// followed by domain and path
  const urlRegex = /\b(?:https?):\/\/[^\s<>"{}|\\^`[\]]+/gi;
  
  // Find all matches
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation but keep the URL clean
    return url.replace(/[.,;!?]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't affect existing https:// URLs
  // Use negative lookbehind to ensure we're only replacing http:// not already secure URLs
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  // This will capture the full URL including scheme, host, and path
  const urlPattern = /http:\/\/([^/\s<>"{}|\\^`[\]]+)([^\s<>"{}|\\^`[\]]*)/gi;
  
  return text.replace(urlPattern, (match, host, path) => {
    // Always upgrade scheme to https
    let newUrl = `https://${host}`;
    
    // Check if path contains dynamic hints or query strings
    const hasDynamicHints = /cgi-bin|[&?]|\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    // Check if path begins with /docs/
    if (!hasDynamicHints && path.startsWith('/docs/')) {
      // Extract subdomain from host (everything before first dot)
      const subdomain = host.split('.')[0];
      if (subdomain) {
        // Rewrite host to docs.example.com
        newUrl = `https://docs.${host}`;
      } else {
        newUrl = `https://docs.${host}`;
      }
    }
    
    return newUrl + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, simplified check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic year validation (4 digits)
  if (year.length !== 4) {
    return 'N/A';
  }
  
  return year;
}
