/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words starting with the prefix
  // Word boundary ensures we match complete words
  const pattern = new RegExp(`\\b${escapeRegex(prefix)}\\w*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => {
    return !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
}

// Helper function to escape special regex characters
function escapeRegex(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\\\]/g, '\\\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token occurrences that:
  // 1. Are not at the beginning of the string (negative lookbehind for start of string)
  // 2. Appear after a digit (positive lookbehind for digit)
  // This uses lookbehinds to ensure the token is embedded properly
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: not at start, preceded by a digit, followed by the token
  const pattern = new RegExp(`(?<!^).(?<=\\d)${escapedToken}`, 'gi');
  
  // Find matches
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace (not allowed)
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[a-z]/.test(value)) {
    return false; // At least one lowercase
  }
  
  if (!/[A-Z]/.test(value)) {
    return false; // At least one uppercase
  }
  
  if (!/[0-9]/.test(value)) {
    return false; // At least one digit
  }
  
  if (!/[!@#$%^&*()_+\-={}[\];':"|,.<>?]/.test(value)) {
    return false; // At least one symbol
  }
  
  // Check for immediate repeated sequences
  // Pattern to detect repeating patterns like "abab", "123123", etc.
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Check for IPv6 patterns (including shorthand ::)
  // This regex looks for patterns that are NOT IPv4 addresses
  // IPv6 can be identified by:
  // 1. Contains letters A-F (hex digits beyond 0-9)
  // 2. Uses shorthand notation ::
  // 3. Has more than 4 segments (IPv4 has 4 octets)
  // 4. Special cases like ::1 (loopback)
  
  // First, check if it's clearly an IPv4 address (4 octets of digits)
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    // It's an IPv4 address, not IPv6
    return false;
  }
  
  // IPv6 patterns to look for:
  // 1. Contains hex letters (a-f) indicating IPv6
  // 2. Uses shorthand notation ::
  // 3. Has colons in specific IPv6 formats
  
  // Pattern for IPv6 detection:
  // - Contains :: shorthand OR
  // - Has hex letters (a-f) indicating IPv6 OR  
  // - Has specific IPv6 structure with colons
  const ipv6Patterns = [
    // Contains :: shorthand notation
    /.*::.*/,
    // Contains IPv6 hex indicators (a-f) in valid positions
    /[a-fA-F0-9]*:[a-fA-F0-9]*:[a-fA-F0-9]*/,
    // Standard IPv6 formats (8 groups of hex)
    /^[a-fA-F0-9]{1,4}(:[a-fA-F0-9]{1,4}){7}$/,
    // IPv6 loopback
    /^::1$/,
    // IPv6 any address
    /^::$/,
    // IPv4-mapped IPv6 (::ffff:192.168.1.1)
    /::ffff:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/
  ];
  
  // Test against all IPv6 patterns
  return ipv6Patterns.some(pattern => pattern.test(value));
}
