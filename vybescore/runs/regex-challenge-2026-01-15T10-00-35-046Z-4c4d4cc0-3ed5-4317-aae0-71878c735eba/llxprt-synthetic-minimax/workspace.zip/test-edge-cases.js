import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './src/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './src/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './src/puzzles.js';

console.log('Testing edge cases...');

// Email validation edge cases
console.log('\n--- Email Validation ---');
console.log('Valid:', isValidEmail('user+tag@example.co.uk')); // Should be true
console.log('Invalid (double dots):', isValidEmail('user..@example.com')); // Should be false  
console.log('Invalid (trailing dot):', isValidEmail('user.@example.com')); // Should be false
console.log('Invalid (domain underscore):', isValidEmail('user@domain_name.com')); // Should be false

// US Phone validation edge cases  
console.log('\n--- US Phone Validation ---');
console.log('Valid format 1:', isValidUSPhone('(212) 555-7890')); // Should be true
console.log('Valid format 2:', isValidUSPhone('+1 212-555-7890')); // Should be true
console.log('Invalid (area code 0):', isValidUSPhone('012-555-7890')); // Should be false
console.log('Invalid (too short):', isValidUSPhone('212-555')); // Should be false

// Argentine Phone validation edge cases
console.log('\n--- Argentine Phone Validation ---');
console.log('Valid mobile:', isValidArgentinePhone('+54 9 11 1234 5678')); // Should be true
console.log('Valid landline:', isValidArgentinePhone('011 1234 5678')); // Should be true  
console.log('Invalid (no trunk prefix):', isValidArgentinePhone('11 1234 5678')); // Should be false

// Name validation edge cases
console.log('\n--- Name Validation ---');
console.log('Valid unicode:', isValidName('José García-Smith')); // Should be true
console.log('Valid with apostrophe:', isValidName("O'Connor")); // Should be true
console.log('Invalid (with digits):', isValidName('John123')); // Should be false
console.log('Invalid (X Æ A-12 style):', isValidName('X Æ A-12')); // Should be false

// Credit Card validation edge cases
console.log('\n--- Credit Card Validation ---');
console.log('Valid Visa:', isValidCreditCard('4111111111111111')); // Should be true (Luhn passes)
console.log('Invalid (bad prefix):', isValidCreditCard('9999999999999999')); // Should be false

// Text transformations edge cases
console.log('\n--- Text Transformations ---');
console.log('Capitalize sentences:', capitalizeSentences('hello world. this is a test! what about this?'));
console.log('Extract URLs:', extractUrls('Visit http://example.com or https://secure.com for more info.'));
console.log('Enforce HTTPS:', enforceHttps('Go to http://example.com, not https://already-secure.com'));
console.log('Rewrite docs URLs:', rewriteDocsUrls('See http://example.com/docs/guide and http://site.com/cgi-bin/test.jsp'));
console.log('Extract year (valid):', extractYear('12/25/2023')); // Should be '2023'
console.log('Extract year (invalid):', extractYear('not-a-date')); // Should be 'N/A'

// Regex puzzles edge cases
console.log('\n--- Regex Puzzles ---');
console.log('Prefixed words:', findPrefixedWords('The cat sat on the mat', 'c', ['cat'])); // Should be ['mat']
console.log('Embedded token:', findEmbeddedToken('abc123token def456token', 'token')); // Should find 'token' after digits
console.log('Strong password:', isStrongPassword('MyStr0ng!P@ss')); // Should be true
console.log('IPv6 detection:', containsIPv6('::1')); // Should be true (IPv6 loopback)
console.log('IPv4 exclusion:', containsIPv6('192.168.1.1')); // Should be false

console.log('\nAll edge case tests completed!');