const BASE64_ALPHABET = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_CHARS = /[^A-Za-z0-9+/=]/;

function validateBase64(input: string): void {
  if (INVALID_CHARS.test(input)) {
    throw new Error('Invalid Base64: contains characters outside the Base64 alphabet');
  }

  if (!BASE64_ALPHABET.test(input)) {
    throw new Error('Invalid Base64: malformed input');
  }

  // Check for padding in the middle of the string
  const withoutPadding = input.replace(/=+$/, '');
  if (withoutPadding.includes('=')) {
    throw new Error('Invalid Base64: padding characters found in the middle of input');
  }

  // Check length is valid (must be multiple of 4 when including padding)
  if (input.length % 4 !== 0) {
    throw new Error('Invalid Base64: length must be a multiple of 4');
  }
}

/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 with or without padding.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Remove any whitespace
  const trimmed = input.trim();

  if (trimmed.length === 0) {
    throw new Error('Invalid Base64: empty input');
  }

  // Add padding if missing
  const normalized = addPadding(trimmed);

  validateBase64(normalized);

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Add padding to a Base64 string if it's missing.
 * Base64 strings should have a length that's a multiple of 4.
 */
function addPadding(input: string): string {
  const remainder = input.length % 4;
  if (remainder === 0) {
    return input;
  }
  return input + '='.repeat(4 - remainder);
}
