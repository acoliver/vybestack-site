/**
 * Valid Base64 character set: A-Z, a-z, 0-9, +, /, and optional padding =
 */
const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 with or without padding.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!trimmed) {
    throw new Error('Failed to decode Base64 input: empty input');
  }

  // Validate that the input contains only valid Base64 characters
  if (!VALID_BASE64_REGEX.test(trimmed)) {
    throw new Error('Failed to decode Base64 input: invalid characters');
  }

  // Validate padding is correct (if present)
  const paddingLength = (trimmed.match(/=/g) || []).length;
  if (paddingLength > 2) {
    throw new Error('Failed to decode Base64 input: invalid padding');
  }

  // Padding should only appear at the end
  const nonPaddingIndex = trimmed.indexOf('=');
  if (nonPaddingIndex !== -1 && !/^=+$/.test(trimmed.slice(nonPaddingIndex))) {
    throw new Error('Failed to decode Base64 input: invalid padding placement');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if the buffer is empty (invalid base64)
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error('Failed to decode Base64 input: invalid data');
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid data');
  }
}
