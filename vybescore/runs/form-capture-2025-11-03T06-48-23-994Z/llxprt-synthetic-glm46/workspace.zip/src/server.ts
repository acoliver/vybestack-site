import express from 'express';
import path from 'path';
import fs from 'fs/promises';
import { fileURLToPath } from 'url';
import sqlite3InitModule, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = process.env.PORT || 3000;

// Form data type
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Validation errors type
interface ValidationError {
  field: string;
  message: string;
}

// Initialize SQLite with sql.js
let DB: Database | null = null;

async function initDatabase(): Promise<void> {
  try {
    // Create data directory if it doesn't exist
    await fs.mkdir(path.join(__dirname, '..', 'data'), { recursive: true });
    
    // Check if database already exists
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    let exists = false;
    
    try {
      await fs.access(dbPath);
      exists = true;
    } catch (e) {
      // File doesn't exist
    }
    
    // Load the SQLite library
    const SQL = await sqlite3InitModule();
    
    if (exists) {
      // Load existing database
      const dbData = await fs.readFile(dbPath);
      DB = new SQL.Database(dbData);
      console.log('Loaded existing database');
    } else {
      // Create new database
      DB = new SQL.Database();
      await initializeSchema();
      console.log('Created new database');
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Initialize the database schema from the schema.sql file
async function initializeSchema(): Promise<void> {
  if (!DB) throw new Error('Database not initialized');
  
  try {
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schema = await fs.readFile(schemaPath, 'utf8');
    DB.run(schema);
    console.log('Database schema initialized');
  } catch (error) {
    console.error('Failed to initialize schema:', error);
    throw error;
  }
}

// Save database back to disk
async function saveDatabase(): Promise<void> {
  if (!DB) throw new Error('Database not initialized');
  
  try {
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const data = DB.export();
    await fs.writeFile(dbPath, data);
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Validate form data
function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields
  if (!data.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!data.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!data.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!data.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!data.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  if (!data.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  }
  
  if (!data.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!data.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!data.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^[+\d\s\-\(\)]+$/.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
  }
  
  return errors;
}

// Save form submission to database
async function saveSubmission(data: FormData): Promise<void> {
  if (!DB) throw new Error('Database not initialized');
  
  try {
    const stmt = DB.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);
    
    stmt.free();
    
    // Save the database to disk
    await saveDatabase();
  } catch (error) {
    console.error('Failed to save submission:', error);
    throw error;
  }
}

// Initialize Express app
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    formData: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    },
    errors: []
  });
});

app.post('/submit', async (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    return res.status(400).render('form', {
      formData,
      errors
    });
  }

  try {
    await saveSubmission(formData);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      formData,
      errors: [{ field: 'general', message: 'An error occurred while saving your submission.' }]
    });
  }
});

app.get('/thank-you', (req, res) => {
  // Get the first name from a query parameter if available
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Start server
async function startServer() {
  try {
    await initDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Graceful shutdown
    const gracefulShutdown = () => {
      console.log('Shutting down gracefully...');
      server.close(() => {
        console.log('HTTP server closed');
        if (DB) {
          DB.close();
          console.log('Database closed');
        }
        process.exit(0);
      });
    };
    
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server if this file is run directly
startServer();