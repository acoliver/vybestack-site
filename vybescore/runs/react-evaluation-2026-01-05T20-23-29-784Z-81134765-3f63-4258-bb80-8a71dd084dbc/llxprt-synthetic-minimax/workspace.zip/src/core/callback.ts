/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver,
  cleanupObserver
} from '../types/reactive.js'

interface Subject<T> {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers?: Set<Observer<any>>
}

interface Observer<T> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  subjects?: Set<Subject<any>> | undefined
  isDisposed?: boolean
  previousValue?: T
  dependents?: Set<Observer<any>> | undefined
}

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subjects: undefined,
    dependents: undefined,
  }
  
  let disposed = false
  
  // Store persistent references to all computed values this callback has ever subscribed to
  // This is crucial for proper cleanup since observer.subjects gets cleared during evaluation
  let allComputedValues: Array<{ value: any; observer: Observer<any> }> = []
  
  // Intercept the subscription process to track computed values persistently
  const originalUpdate = updateObserver
  const wrappedUpdateObserver = (obs: Observer<T>) => {
    const previousSubjects = obs.subjects ? new Set(Array.from(obs.subjects)) : undefined
    originalUpdate(obs)
    
    // After evaluation, check which computed values this callback now depends on
    if (obs.subjects && obs.subjects.size > 0) {
      for (const subject of obs.subjects) {
        // Add to our persistent list if not already there
        const existingIndex = allComputedValues.findIndex(item => 
          item.value === subject.value && item.observer === obs
        )
        if (existingIndex === -1) {
          allComputedValues.push({ value: subject.value, observer: obs })
        }
      }
    }
    
    console.log(`Callback now tracks ${allComputedValues.length} computed values`)
  }
  
  // Execute the update function to establish dependencies
  // and trigger initial side effects
  console.log(`Callback created, initial execution to establish dependencies`)
  wrappedUpdateObserver(observer)
  console.log(`Callback dependencies established`)
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    console.log(`Callback unsubscribed, cleaning up dependencies`)
    console.log(`Cleaning up callback that tracked ${allComputedValues.length} computed values`)
    
    // Use the persistent list of computed values for proper cleanup
    for (const { value: computedValue, observer: computedObserver } of allComputedValues) {
      console.log(`Removing callback from computed value's observers list`)
      
      // Remove this callback from the computed value's observers list
      if (computedValue.observers && computedValue.observers.has(observer as any)) {
        computedValue.observers.delete(observer as any)
        console.log(`Successfully removed callback from computed value`)
      }
    }
    
    // Also clean up from any computed values that depend on this callback
    if (observer.dependents) {
      for (const dependent of observer.dependents) {
        if (dependent.subjects) {
          dependent.subjects.delete(observer as any)
        }
      }
    }
    
    // Now cleanup the observer's own references
    cleanupObserver(observer)
  }
  
  return unsubscribe
}
