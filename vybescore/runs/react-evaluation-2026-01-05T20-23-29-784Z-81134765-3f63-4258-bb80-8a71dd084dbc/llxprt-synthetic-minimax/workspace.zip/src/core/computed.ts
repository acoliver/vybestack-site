/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  registerComputedDependency,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: undefined,
  }
  
  const read: GetterFn<T> = () => {
    console.log(`Computed getter called`)
    
    // Check if we have an active observer (callback) that should be notified
    const activeObserver = getActiveObserver()
    if (activeObserver && !activeObserver.isDisposed) {
      // Register this computed value as a dependency of the active observer
      registerComputedDependency(observer, activeObserver)
    }
    
    updateObserver(observer)
    console.log(`Computed value: ${observer.value}`)
    return observer.value!
  }

  return read
}
