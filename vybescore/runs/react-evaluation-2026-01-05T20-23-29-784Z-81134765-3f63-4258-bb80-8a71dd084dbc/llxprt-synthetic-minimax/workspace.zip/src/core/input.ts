/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  subscribeSubject,
  notifySubject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(), // Initialize with empty set
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !observer.isDisposed) {
      subscribeSubject(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    console.log(`Input setter called: ${s.value} -> ${nextValue}`)
    const shouldUpdate = true // Always update for now
    if (shouldUpdate) {
      const oldValue = s.value
      s.value = nextValue
      console.log(`Input value changed: ${oldValue} -> ${s.value}, notifying ${s.observers?.size || 0} observers`)
      notifySubject(s)
    }
    return s.value
  }

  return [read, write]
}
