/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer<T> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  subjects?: Set<Subject<any>> | undefined
  isDisposed?: boolean
  previousValue?: T
  dependents?: Set<Observer<any>> | undefined
}

export interface Subject<T> {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers?: Set<Observer<T>> | undefined
}

// Global reactive system state
let activeObserver: Observer<any> | undefined = undefined

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (observer.isDisposed) return
  
  // Set this observer as the active one during computation
  const previousObserver = activeObserver
  activeObserver = observer
  
  try {
    // Clear previous subject subscriptions
    if (observer.subjects) {
      const subjectsToClear = Array.from(observer.subjects)
      for (const subject of subjectsToClear) {
        if (subject.observers) {
          subject.observers.delete(observer)
        }
      }
      observer.subjects.clear()
    }
    
    // Execute the update function to get new value and establish new dependencies
    const newValue = observer.updateFn(observer.value)
    
    // Check if value changed
    const valueChanged = observer.previousValue !== newValue
    observer.value = newValue
    observer.previousValue = newValue
    
    console.log(`Observer update: value=${newValue}, changed=${valueChanged}`)
    
    // Check if value changed and notify dependents if it did
    if (valueChanged) {
      console.log(`Observer value changed: triggering dependents`)
      // Notify any dependent observers of this computed value
      if (observer.dependents) {
        console.log(`Notifying ${observer.dependents.size} dependent observers`)
        const dependents = Array.from(observer.dependents)
        for (const dependent of dependents) {
          if (!dependent.isDisposed) {
            console.log(`Triggering dependent callback`)
            updateObserver(dependent as Observer<any>)
          }
        }
      }
    }
  } finally {
    // Restore previous active observer
    activeObserver = previousObserver
  }
}

export function subscribeSubject<T>(subject: Subject<T>, observer: Observer<any>): void {
  if (observer.isDisposed) return
  
  // Add this observer to the subject's observer list
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer as any)
  
  // Add this subject to the observer's subject list
  if (!observer.subjects) {
    observer.subjects = new Set()
  }
  observer.subjects.add(subject as any)
  
  console.log(`subscribeSubject: observer added to subject, ${subject.observers.size} observers total`)
}

export function notifySubject<T>(subject: Subject<T>): void {
  if (!subject.observers) return
  
  console.log(`notifySubject called with ${subject.observers.size} observers`)
  // Create a copy to avoid modification during iteration
  const observers = Array.from(subject.observers)
  for (const observer of observers) {
    if (!observer.isDisposed) {
      console.log(`Updating observer`)
      updateObserver(observer as Observer<any>)
    } else {
      console.log(`Skipping disposed observer during notification`)
      // Remove disposed observers from the subject's observer list
      subject.observers.delete(observer)
    }
  }
}

export function registerComputedDependency<T>(
  computedObserver: Observer<T>, 
  dependentObserver: Observer<any>
): void {
  if (dependentObserver.isDisposed || computedObserver.isDisposed) {
    return
  }
  
  if (!computedObserver.dependents) {
    computedObserver.dependents = new Set()
  }
  
  // Always re-add for dependencies to be fresh
  computedObserver.dependents.add(dependentObserver as any)
  
  if (!dependentObserver.subjects) {
    dependentObserver.subjects = new Set()
  }
  
  // Always re-add for dependencies to be fresh  
  dependentObserver.subjects.add(computedObserver as any)
}

export function unregisterComputedDependency<T>(
  computedObserver: Observer<T>, 
  dependentObserver: Observer<any>
): void {
  if (computedObserver.dependents) {
    computedObserver.dependents.delete(dependentObserver as any)
  }
  
  if (dependentObserver.subjects) {
    dependentObserver.subjects.delete(computedObserver as any)
  }
}

export function cleanupObserver<T>(observer: Observer<T>): void {
  // Mark observer as disposed
  observer.isDisposed = true
  
  if (observer.subjects) {
    for (const subject of observer.subjects) {
      if (subject.observers) {
        subject.observers.delete(observer)
      }
    }
    observer.subjects.clear()
  }
  
  if (observer.dependents) {
    // First unregister from all computed observers
    for (const dependent of observer.dependents) {
      // Remove this observer from the dependent's subject list
      if (dependent.subjects) {
        dependent.subjects.delete(observer as any)
      }
    }
    // Don't dispose or clear dependents here - let them handle their own lifecycle
    observer.dependents.clear()
  }
}
