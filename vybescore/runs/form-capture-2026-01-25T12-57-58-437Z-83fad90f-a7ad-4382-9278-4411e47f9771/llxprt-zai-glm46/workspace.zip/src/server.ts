import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.resolve(DB_DIR, 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

const PORT = process.env.PORT || 3535;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;

// Ensure data directory exists
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

// Initialize SQLite database
async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  // Load existing database or create new one
  let dbInstance: Database;
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    // Apply schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }

  return dbInstance;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[\d\s()--]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalCode.trim().length > 0 && postalRegex.test(postalCode);
}

function validateForm(formData: FormData): ValidationResult {
  const errors: string[] = [];

  // Check required fields
  if (!formData.firstName?.trim()) {
    errors.push('First name is required');
  }
  if (!formData.lastName?.trim()) {
    errors.push('Last name is required');
  }
  if (!formData.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  if (!formData.city?.trim()) {
    errors.push('City is required');
  }
  if (!formData.stateProvince?.trim()) {
    errors.push('State / Province / Region is required');
  }
  if (!formData.postalCode?.trim()) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, digits, and spaces');
  }
  if (!formData.country?.trim()) {
    errors.push('Country is required');
  }
  if (!formData.email?.trim()) {
    errors.push('Email is required');
  } else if (!validateEmail(formData.email)) {
    errors.push('Please enter a valid email address');
  }
  if (!formData.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!validatePhone(formData.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(
      'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);
    stmt.free();

    // Save database after insert
    saveDatabase(db);
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission to display first name
  let firstName = 'friend';
  if (db) {
    const result = db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
    if (result.length > 0 && result[0].values.length > 0) {
      firstName = result[0].values[0][0] as string;
    }
  }

  res.render('thank-you', { firstName });
});

// Graceful shutdown
function shutdown(): void {
  console.log('Shutting down server...');
  if (db) {
    db.close();
    db = null;
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start(): Promise<void> {
  try {
    db = await initializeDatabase();
    console.log('Database initialized');

    // Set views directory to source templates (not dist)
    // When compiled, __dirname will be dist, so we need to go to src/templates
    const viewsPath =
      __dirname.endsWith('dist') || __dirname.endsWith('dist/')
        ? path.resolve(__dirname, '..', 'src', 'templates')
        : path.resolve(__dirname, 'templates');
    app.set('views', viewsPath);
    app.set('view engine', 'ejs');

    const server = app.listen(PORT, () => {
      console.log(`Server listening on port ${PORT}`);
    });

    // Export server for testing
    (app as { server?: { close: () => void } }).server = server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
start();

export default app;
