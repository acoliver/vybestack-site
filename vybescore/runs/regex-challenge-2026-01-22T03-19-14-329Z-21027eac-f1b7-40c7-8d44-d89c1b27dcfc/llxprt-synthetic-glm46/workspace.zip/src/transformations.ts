/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Leaves abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First normalize spacing - ensure there's one space after sentence terminators
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Add one space after sentence terminators if missing
  result = result.replace(/([.!?])(?=\w)/g, '$1 ');
  
  // Split text into sentences
  const sentences = result.split(/(?<=[.!?])\s+/);
  
  // Process each sentence
  const processedSentences = sentences.map(sentence => {
    // Skip empty sentences
    if (!sentence) return '';
    
    // Capitalize first character of the sentence
    if (sentence.length > 0 && /[a-z]/i.test(sentence[0])) {
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
    
    return sentence;
  });
  
  // Join sentences back together with single spaces
  return processedSentences.join(' ');
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Match URLs with protocol (http://, https://) or domain with tld
  const urlRegex = /(https?:\/\/[^\s]+)|(?:www\.)[^\s]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?/gi;
  
  // Find all potential matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation like .,!?;:) etc.
    return url.replace(/[^\w\-.~:/?#[\]@!$&'()*+,;=%]+$/gi, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Match http:// URLs but not https:// URLs
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com URLs
  return text.replace(
    /\bhttps?:\/\/(example\.com)(\/.*?)([^\w\-.~:/?#[\]@!$&'()*+,;=]|$)/gi,
    (match, domain, path, trailing) => {
      // Check if this should have host rewrite
      const dynamicHints = /\/(cgi-bin|.*(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)|\?|&|=)/gi;
      const shouldRewrite = !dynamicHints.test(path) && path.startsWith('/docs/');
      
      // Always upgrade to https
      const secureProtocol = 'https://';
      
      // Rewrite host if needed
      const newHost = shouldRewrite ? 'docs.example.com' : domain;
      
      return secureProtocol + newHost + path + trailing;
    }
  );
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format with 4-digit year
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Check if the month/day is valid according to calendar
  if (!_isValidDate(month, day, parseInt(year, 10))) return 'N/A';
  
  return year;
}

/**
 * Helper function to validate month/day combinations
 */
function _isValidDate(month: number, day: number, year: number): boolean {
  // Check for proper day in each month (ignoring leap years for simplicity)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 29 for February (allowing leap years)
  
  // Check if month is valid (1-12) and day is valid for that month
  if (month < 1 || month > 12) return false;
  
  // Check if day is valid for the month
  if (day < 1 || day > daysInMonth[month - 1]) return false;
  
  // Special check for February on non-leap years
  if (month === 2 && day === 29) {
    // Check for leap year (year divisible by 4, except centuries unless divisible by 400)
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear) return false;
  }
  
  return true;
}
