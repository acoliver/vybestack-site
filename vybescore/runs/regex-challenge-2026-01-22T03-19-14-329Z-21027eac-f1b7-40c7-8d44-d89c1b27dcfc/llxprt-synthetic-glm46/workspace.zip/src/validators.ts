export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation using regex.
 * Accepts typical addresses like user@example.com
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Regex for email validation
  // Local part: letters, numbers, dots, hyphens, plus
  // Domain: letters, numbers, hyphens, but no underscores
  // No consecutive dots, no leading/trailing dots in local part
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  // Check basic format
  if (!emailRegex.test(value)) return false;
  
  // Check local part doesn't start/end with dot
  const [localPart, domain] = value.split('@');
  
  // Local part can't start with dot
  if (localPart.startsWith('.')) return false;
  // Local part can't end with dot
  if (localPart.endsWith('.')) return false;
  // Local part can't have consecutive dots
  if (localPart.includes('..')) return false;
  
  // Domain part can't start with hyphen or dot
  if (domain.startsWith('-') || domain.startsWith('.')) return false;
  // Domain part can't end with hyphen or dot
  if (domain.endsWith('-') || domain.endsWith('.')) return false;
  // Domain part can't contain underscores
  if (domain.includes('_')) return false;
  // Domain part can't have consecutive dots
  if (domain.includes('..')) return false;
  
  return true;
}

/**
 * US phone number validation supporting common separators and optional +1.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, and optional +1 prefix
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove whitespace and extensions for validation
  const cleanValue = value.replace(/\s+/g, '');
  
  // Check for valid extension format if allowed
  if (options?.allowExtensions && /[a-zA-Z]/.test(cleanValue)) {
    // If extensions are allowed, only check the phone part
    const phonePart = cleanValue.split(/[a-zA-Z]/)[0];
    if (!_isValidUSPhone(phonePart)) return false;
    return true;
  }
  
  return _isValidUSPhone(cleanValue);
}

// Helper function for US phone validation
function _isValidUSPhone(value: string): boolean {
  // Optional +1 prefix
  const withoutCountryCode = value.startsWith('+1');
  
  // Start with the value after removing +1 if present
  const phoneNumber = withoutCountryCode ? value.substring(2) : value;
  
  // Reject if length is too short after removing country code
  if (phoneNumber.length < 10) return false;
  
  // Extract the part that could contain the area code
  let areaCode = '';
  let remainingNumber = '';
  
  // Format 1: (212) 555-7890
  if (phoneNumber.startsWith('(') && phoneNumber.includes(')')) {
    const closingParenIdx = phoneNumber.indexOf(')');
    areaCode = phoneNumber.substring(1, closingParenIdx);
    remainingNumber = phoneNumber.substring(closingParenIdx + 1);
  } 
  // Format 2: 212-555-7890 or 2125557890
  else {
    // Take first 3 digits as area code if available
    areaCode = phoneNumber.substring(0, 3);
    remainingNumber = phoneNumber.substring(3);
  }
  
  // Valid area codes start with 2-9 (can't start with 0 or 1)
  if (areaCode.length !== 3 || !/^[2-9]\d{2}$/.test(areaCode)) return false;
  
  // Remove remaining separators
  remainingNumber = remainingNumber.replace(/[-\s(]/g, '');
  
  // Check we have exactly 7 digits after area code
  return /^\d{7}$/.test(remainingNumber);
}

/**
 * Argentine phone number validation covering mobile/landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[-\s]/g, '');
  
  // Check if it starts with country code +54
  const hasCountryCode = cleanValue.startsWith('+54');
  let remainingNumber = hasCountryCode ? cleanValue.substring(3) : cleanValue;
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !remainingNumber.startsWith('0')) return false;
  
  // Remove trunk prefix 0 if present
  if (remainingNumber.startsWith('0')) {
    remainingNumber = remainingNumber.substring(1);
  }
  
  // Check for optional mobile indicator 9
  if (remainingNumber.startsWith('9')) {
    remainingNumber = remainingNumber.substring(1);
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let validAreaCode = false;
  
  // Try to extract area code of length 2, 3, or 4
  for (let len = 2; len <= 4 && len <= remainingNumber.length; len++) {
    const potentialAreaCode = remainingNumber.substring(0, len);
    if (/^[1-9]\d{1,3}$/.test(potentialAreaCode)) {
      validAreaCode = true;
    }
  }
  
  if (!validAreaCode) return false;
  
  // Extract subscriber number (the rest of the digits)
  const subscriberNumber = remainingNumber.substring(4); // Default to max area code length
  
  // Check if subscriber number has 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  // All checks passed
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and invalid styles like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Check if the name matches valid patterns only
  // Allow unicode letters, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'-]+(\s+[\p{L}\p{M}'-]+)*$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Ensure we have at least one valid name component
  const parts = value.split(/\s+/).filter(part => part.length > 0);
  if (parts.length === 0) return false;
  
  // Check each part has at least one letter character
  const validPartRegex = /^[\p{L}\p{M}'-]+$/u;
  for (const part of parts) {
    if (!validPartRegex.test(part)) return false;
    
    // Reject parts with only symbols (no letters)
    const lettersOnly = /[\p{L}\p{M}]/u;
    if (!lettersOnly.test(part)) return false;
  }
  
  // Reject obviously unusual patterns containing numbers
  const numberRegex = /\d/;
  if (numberRegex.test(value)) return false;
  
  // Reject invalid special characters not covered by the regex
  // (e.g., slashes, brackets, etc. that might pass the regex but we want to reject)
  const invalidCharsRegex = /[<>{[\]()\/=@#$%^&*+~`|?:;,.!0-9]/u;
// New content to ensure we hit linting error line
// Fix linting error by creating a new line
  if (invalidCharsRegex.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa/Mastercard/AmEx formats
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Valid lengths: 13-19 digits
  if (cleanValue.length < 13 || cleanValue.length > 19) return false;
  
  // Check for valid prefixes (Visa, Mastercard, AmEx)
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5][0-9]{14}$/; // 16 digits, starts with 51-55
  const mastercardNewRegex = /^2[2-7][0-9]{13}$/; // New Mastercard ranges
  const amexRegex = /^3[47][0-9]{13}$/; // 15 digits, starts with 34 or 37
  
  const isValidByPrefix = 
    visaRegex.test(cleanValue) || 
    mastercardRegex.test(cleanValue) ||
    mastercardNewRegex.test(cleanValue) ||
    amexRegex.test(cleanValue);
  
  if (!isValidByPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to run the Luhn checksum algorithm
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      const doubled = digit * 2;
      // If doubled is two digits, subtract 9 (equivalent to summing the digits)
      sum += doubled > 9 ? doubled - 9 : doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
