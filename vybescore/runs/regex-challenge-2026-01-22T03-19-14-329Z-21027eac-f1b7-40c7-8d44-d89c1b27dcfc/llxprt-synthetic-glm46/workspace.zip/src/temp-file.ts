// Temporary file with correctly escaped slash
const invalidCharsRegex = /[<>{[\]()\/=@#$%^&*+~`|?:;,.!0-9]/u;
console.log(invalidCharsRegex);