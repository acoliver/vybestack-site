/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex to find words starting with the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b(${escapedPrefix}\\w*)`, 'gi');
  
  // Find all matches
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions and deduplicate
  const uniqueWords = new Set<string>();
  
  for (const match of matches) {
    // Convert exceptions to lowercase for case-insensitive comparison
    if (!exceptions.some(exception => 
      exception.toLowerCase() === match.toLowerCase()
    )) {
      uniqueWords.add(match);
    }
  }
  
  return Array.from(uniqueWords);
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex pattern to find token after a digit but not at start
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // Use capture group instead of lookbehind for broader compatibility
  const tokenRegex = new RegExp(`(\\d${escapedToken})`, 'g');
  
  // Find all matches
  const matches = text.match(tokenRegex) || [];
  
  // Deduplicate matches to avoid duplication when the same occurrence
  // appears multiple times due to overlapping matches
  const uniqueTokens = [...new Set(matches)];
  
  return uniqueTokens;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, 
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>\/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab, 1212, etc.)
  // This pattern matches any character sequence that repeats immediately
  if (/(.{2,})\1/.test(value)) return false;
  
  // Additional check for simple repeating patterns like aaa, bbb, etc.
  if (/([a-zA-Z\d!@#$%^&*()_+\-=[\]{};':"|,.<>\/?])\1\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 Regex patterns:
  // 1. Full form: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // 2. Compressed form with "::": includes one or more groups of zeros
  // 3. Can include IPv4-mapped addresses: ::ffff:192.0.2.128
  
  // Extract a potential IPv6 address from the text
  // Look for patterns with colons and hex digits
  const ipv6Candidate = value.match(/\b([0-9a-fA-F:]+)\b/);
  if (!ipv6Candidate) return false;
  
  const candidate = ipv6Candidate[1];
  
  // Pattern for full IPv6 (8 groups of 1-4 hex digits separated by colons)
  const fullIPv6Pattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // Pattern for compressed IPv6 with "::" - more flexible pattern to catch variations
  const compressedIPv6Pattern = /^[0-9a-fA-F:{1,8}]+$/;
  
  // Pattern for IPv6 with IPv4 mapped addresses (e.g., ::ffff:192.0.2.128)
  const ipv4MappedPattern = /^(?:[0-9a-fA-F]{1,4}:){0,5}:(?:[0-9a-fA-F]{1,4}:){0,1}[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/;
  
  // Pattern for IPv4 addresses to exclude
  const ipv4Pattern = /^([0-9]{1,3}\.){3}[0-9]{1,3}$/;
  
  // First, verify it's not just an IPv4 address
  if (ipv4Pattern.test(candidate)) return false;
  
  // Must contain at least one colon to be IPv6
  if (!candidate.includes(':')) return false;
  
  // Then check for any IPv6 pattern
  return (
    fullIPv6Pattern.test(candidate) ||
    compressedIPv6Pattern.test(candidate) ||
    ipv4MappedPattern.test(candidate)
  );
}
