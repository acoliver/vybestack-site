import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      let page: number | undefined = undefined;
      let limit: number | undefined = undefined;

      if (pageParam !== undefined) {
        const numPage = Number(pageParam);
        if (!Number.isFinite(numPage) || numPage <= 0) {
          return res.status(400).json({ error: 'Invalid page parameter' });
        }
        if (numPage > 100000) {
          return res.status(400).json({ error: 'Page parameter too large' });
        }
        page = Math.floor(numPage);
      }

      if (limitParam !== undefined) {
        const numLimit = Number(limitParam);
        if (!Number.isFinite(numLimit) || numLimit <= 0) {
          return res.status(400).json({ error: 'Invalid limit parameter' });
        }
        if (numLimit > 100) {
          return res.status(400).json({ error: 'Limit parameter too large' });
        }
        limit = Math.floor(numLimit);
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
