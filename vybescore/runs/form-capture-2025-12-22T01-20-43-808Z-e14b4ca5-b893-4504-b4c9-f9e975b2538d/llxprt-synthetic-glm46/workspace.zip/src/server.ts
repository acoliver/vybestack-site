import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import DatabaseFactory from 'sql.js';
import type { Database as SQLiteDatabase } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3535;
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');

let db: SQLiteDatabase | null = null;


const initializeDatabase = async (): Promise<void> => {
  try {
    const dataDir = path.dirname(DB_PATH);
    
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    let dbContent: Uint8Array | undefined;
    
    if (fs.existsSync(DB_PATH)) {
      dbContent = fs.readFileSync(DB_PATH);
    }
    
    const SQL = await DatabaseFactory();
    db = new SQL.Database(dbContent);
    
    if (!fs.existsSync(DB_PATH) || dbContent === undefined) {
      const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
      db!.run(schema);
      saveDatabase();
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
};

function saveDatabase(): void {
  try {
    if (!db) return;
    
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}


const validateForm = (formData: Record<string, string>): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  const requiredFields = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];
  
  requiredFields.forEach(field => {
    if (!formData[field] || formData[field].trim() === '') {
      const fieldName = field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
      errors.push(`${fieldName} is required`);
    }
  });
  
  if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
    errors.push('Please enter a valid email address');
  }
  
  if (formData.phone && !/^\+?[0-9\-\s()]+$/.test(formData.phone.trim())) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    formData: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const validation = validateForm(req.body);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      formData: req.body
    });
  }
  
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city,
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      req.body.first_name.trim(),
      req.body.last_name.trim(),
      req.body.street_address.trim(),
      req.body.city.trim(),
      req.body.state_province.trim(),
      req.body.postal_code.trim(),
      req.body.country.trim(),
      req.body.email.trim(),
      req.body.phone.trim()
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while processing your submission. Please try again.'],
      formData: req.body
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

const gracefulShutdown = (signal: string) => {
  console.log(`
Received ${signal}. Shutting down gracefully...`);
  
  if (db) {
    saveDatabase();
    db.close();
    console.log('Database connection closed');
  }
  
  process.exit(0);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

const startServer = async (): Promise<void> => {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
};

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
