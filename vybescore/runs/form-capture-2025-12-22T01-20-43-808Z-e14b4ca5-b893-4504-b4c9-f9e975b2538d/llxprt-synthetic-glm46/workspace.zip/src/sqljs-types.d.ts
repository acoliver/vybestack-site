declare module 'sql.js' {
  export class Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
    constructor(data?: Uint8Array);
  }
  
  export class Statement {
    run(...params: unknown[]): void;
    free(): void;
  }
  
  export interface SqlJsStatic {
    Database: typeof Database;
  }
  
  export type Database = InstanceType<typeof Database>;
  
  export default function SqlJsFactory(): Promise<SqlJsStatic>;
}