import type { ReportData, ReportEntry } from './types.js';

export function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string' || !reportData.title.trim()) {
    throw new Error('Invalid report data: missing or empty title');
  }

  if (typeof reportData.summary !== 'string' || !reportData.summary.trim()) {
    throw new Error('Invalid report data: missing or empty summary');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }

  const entries = reportData.entries as unknown[];
  for (const entry of entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid report data: each entry must be an object');
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string' || !entryObj.label.trim()) {
      throw new Error('Invalid report data: each entry must have a non-empty label');
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error('Invalid report data: each entry must have a valid amount');
    }
  }

  return reportData as unknown as ReportData;
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((total, entry) => total + entry.amount, 0);
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}