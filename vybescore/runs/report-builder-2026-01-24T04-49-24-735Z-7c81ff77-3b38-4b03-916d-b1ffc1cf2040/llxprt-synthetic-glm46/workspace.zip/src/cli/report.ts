#!/usr/bin/env node

import fs from 'fs';
import { validateReportData } from '../utils.js';
import { getRenderer } from '../formats/index.js';
import type { ReportOptions, FormatType } from '../types.js';

interface CliArgs {
  dataFile: string;
  format?: string;
  output?: string;
  includeTotals?: boolean;
}

function parseCliArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const cliArgs: CliArgs = {
    dataFile: '',
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      cliArgs.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      cliArgs.output = args[i];
    } else if (arg === '--includeTotals') {
      cliArgs.includeTotals = true;
    } else if (!cliArgs.dataFile) {
      cliArgs.dataFile = arg;
    } else {
      console.error(`Error: Unexpected argument: ${arg}`);
      process.exit(1);
    }
    
    i++;
  }

  if (!cliArgs.dataFile) {
    console.error('Error: Data file is required');
    process.exit(1);
  }

  if (!cliArgs.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return cliArgs;
}

function main(): void {
  try {
    const args = parseCliArgs();
    const format = args.format as FormatType;
    
    let dataContent: string;
    try {
      dataContent = fs.readFileSync(args.dataFile, 'utf-8');
    } catch (error) {
      console.error(`Error: Could not read file "${args.dataFile}": ${(error as Error).message}`);
      process.exit(1);
    }

    let data: unknown;
    try {
      data = JSON.parse(dataContent);
    } catch (error) {
      console.error(`Error: Failed to parse JSON in "${args.dataFile}": ${(error as Error).message}`);
      process.exit(1);
    }

    const reportData = validateReportData(data);
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };

    const renderer = getRenderer(format);
    const output = renderer.render(reportData, options);

    if (args.output) {
      try {
        fs.writeFileSync(args.output, output, 'utf-8');
      } catch (error) {
        console.error(`Error: Could not write to file "${args.output}": ${(error as Error).message}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
