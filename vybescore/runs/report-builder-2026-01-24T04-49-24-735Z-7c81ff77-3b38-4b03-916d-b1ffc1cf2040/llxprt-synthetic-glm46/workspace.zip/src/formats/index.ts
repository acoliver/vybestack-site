import type { FormatType, ReportRenderer } from '../types.js';
import { markdownRenderer } from './markdown.js';
import { textRenderer } from './text.js';

export const formatters: Record<FormatType, ReportRenderer> = {
  markdown: markdownRenderer,
  text: textRenderer,
};

export function getRenderer(format: string): ReportRenderer {
  const renderer = formatters[format as FormatType];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer;
}