#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[2];
  let format: 'markdown' | 'text' = 'markdown';
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error('Error: Unsupported format. Supported formats: markdown, text');
        process.exit(1);
      }
      format = formatValue as 'markdown' | 'text';
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      output = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  return { dataFile, format, output, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field`);
    }
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries as Array<{ label: string; amount: number }>
  };
}

function main(): void {
  try {
    const args = parseArguments(process.argv);
    
    let dataContent: string;
    try {
      dataContent = readFileSync(args.dataFile, 'utf-8');
    } catch (error) {
      console.error(`Error: Could not read file "${args.dataFile}": ${(error as Error).message}`);
      process.exit(1);
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(dataContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file "${args.dataFile}": ${(error as Error).message}`);
      process.exit(1);
    }

    const reportData = validateReportData(jsonData);
    const options: ReportOptions = { includeTotals: args.includeTotals };

    let output: string;
    if (args.format === 'markdown') {
      output = renderMarkdown(reportData, options);
    } else {
      output = renderText(reportData, options);
    }

    if (args.output) {
      try {
        writeFileSync(args.output, output, 'utf-8');
        console.log(`Report saved to ${args.output}`);
      } catch (error) {
        console.error(`Error: Could not write to file "${args.output}": ${(error as Error).message}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }
}

main();