/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode standard Base64 text back to plain UTF-8.
 * Accepts input with or without padding.
 * Throws an error if the input is invalid Base64.
 */
export function decode(input: string): string {
  // Validate Base64 format: only allow A-Z, a-z, 0-9, +, /, and = (padding)
  const validBase64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!validBase64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check if padding is correct (if present)
  const paddingMatch = input.match(/=*$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    // Padding can only be 1 or 2 = characters
    if (paddingLength > 0 && input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect padding length');
    }
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if the decoding was successful by verifying the buffer
    // If the input was invalid base64, Buffer.from may return an empty buffer
    // or incorrect data, but Node.js base64 decoding is lenient
    // We need to verify the result is valid UTF-8
    const decoded = buffer.toString('utf8');
    
    // Additional validation: encode the result and compare
    // This catches cases where invalid base64 was silently decoded
    const reencoded = Buffer.from(decoded, 'utf8').toString('base64').replace(/=*$/, '');
    const originalNoPadding = input.replace(/=*$/, '');
    
    if (reencoded !== originalNoPadding) {
      throw new Error('Invalid Base64 input: failed validation');
    }
    
    return decoded;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
