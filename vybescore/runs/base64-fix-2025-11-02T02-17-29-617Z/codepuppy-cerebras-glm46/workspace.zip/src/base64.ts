/**
 * Encode plain text to Base64 using the canonical RFC 4648 alphabet.
 * Uses standard Base64 with + and / characters, and includes required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Checks if a string has valid Base64 format according to RFC 4648.
 * Validates character set and padding rules. Accepts padded and unpadded Base64.
 */
function isValidBase64(input: string): boolean {
  // Empty input is not valid
  if (input.length === 0) return false;
  
  // Base64 regex: only A-Z, a-z, 0-9, +, /, and = for padding
  const base64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
  if (!base64Regex.test(input)) return false;
  
  // Check padding rules if padding exists
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // All padding must be at the end (no non-padding characters after first =)
    const paddingPart = input.substring(paddingIndex);
    if (!/^={1,2}$/.test(paddingPart)) return false;
    
    // If padding exists, total length must be divisible by 4
    return input.length % 4 === 0;
  }
  
  // For unpadded base64, all lengths are actually valid
  // Node.js Buffer.from can handle any length that results in valid base64 decoding
  // The only truly invalid case would be if Buffer.from throws an error
  try {
    // Test if input can be decoded by Node.js Buffer
    Buffer.from(input, 'base64').toString('utf8');
    return true;
  } catch {
    return false;
  }
}

/**
 * Decode Base64 text back to plain UTF-8 using the canonical RFC 4648 format.
 * Accepts valid Base64 input (with or without padding) and throws an error
 * for clearly invalid payloads.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters or improper padding');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: malformed data');
  }
}
