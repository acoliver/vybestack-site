/**
 * Encode plain text to Base64 using standard alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using standard Base64 validation.
 */
export function decode(input: string): string {
  // Validate input: check for valid Base64 characters and proper padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Base64 can be decoded even without padding - just validate characters
  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Additional validation: ensure the result is valid UTF-8
    if (!result) {
      throw new Error('Invalid Base64 input: decoded to empty string');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}