/**
 * Encode plain text to Base64 using RFC 4648 standard.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with required (=) padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Rejects invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  // Validate input is not empty
  if (!input || input.trim() === '') {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Check for invalid Base64 characters (only allow A-Z, a-z, 0-9, +, /, =)
  const validBase64Regex = /^[A-Za-z0-9+/=]*$/;
  if (!validBase64Regex.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for invalid padding (padding must be at the end and max 2 characters)
  const trimmed = input.trim();
  const nonPaddingIndex = trimmed.search(/[^=]/);
  const paddingStart = trimmed.indexOf('=', nonPaddingIndex + 1);
  
  if (paddingStart !== -1) {
    const paddingSection = trimmed.substring(paddingStart);
    if (paddingSection !== paddingSection[0].repeat(paddingSection.length)) {
      throw new Error('Invalid Base64 input: malformed padding');
    }
    if (paddingSection.length > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
  }

  try {
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    
    // Additional validation: check if the input length is valid Base64
    // Base64 length must be a multiple of 4 (after removing whitespace)
    const cleanInput = trimmed.replace(/\s/g, '');
    if (cleanInput.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
