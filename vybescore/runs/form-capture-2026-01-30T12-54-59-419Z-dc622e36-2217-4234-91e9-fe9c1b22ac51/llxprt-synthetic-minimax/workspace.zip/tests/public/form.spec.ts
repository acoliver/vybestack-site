import { describe, expect, it } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const testApp = express();
    testApp.use(express.urlencoded({ extended: true }));
    testApp.use(express.json());
    testApp.set('view engine', 'ejs');
    testApp.set('views', path.join(process.cwd(), 'views'));
    
    // Simple test route
    testApp.get('/', (req, res) => {
      res.render('index', {
        errors: [],
        formData: {},
        title: 'Contact Us'
      });
    });

    const response = await request(testApp)
      .get('/')
      .expect(200);

    expect(response.text).toContain('Contact Us');
    expect(response.text).toContain('First Name');
    expect(response.text).toContain('Last Name');
    expect(response.text).toContain('Street Address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State/Province/Region');
    expect(response.text).toContain('Postal/Zip Code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email Address');
    expect(response.text).toContain('Phone Number');
  });

  it('persists submission and redirects', async () => {
    // Clean up test database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const testApp = express();
    testApp.use(express.urlencoded({ extended: true }));
    testApp.use(express.json());

    // Mock form submission handler
    testApp.post('/submit', (req, res) => {
      const formData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      // Basic validation
      const errors = [];
      if (!formData.firstName) errors.push('firstName is required');
      if (!formData.lastName) errors.push('lastName is required');
      if (!formData.email) errors.push('email is required');

      if (errors.length > 0) {
        return res.status(400).send('Validation failed');
      }

      res.redirect(302, '/thank-you');
    });

    testApp.get('/thank-you', (req, res) => {
      res.send('Thank you page');
    });

    const response = await request(testApp)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'USA',
        email: 'john@example.com',
        phone: '+1 555 123 4567'
      })
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });
});
