import express, { Request, Response } from 'express';
import * as path from 'path';
import { dbManager, ContactSubmission } from './database.js';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(process.cwd(), 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Interface for form validation
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors.push({ field, message: `${field} is required` });
    }
  }

  // Email validation
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push({ field: 'email', message: 'Invalid email format' });
  }

  // Phone validation (allow international formats)
  if (data.phone && !/^\+?[0-9\s\-()]{7,}$/.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Invalid phone format' });
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[A-Za-z0-9\s-]{3,}$/.test(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Invalid postal code format' });
  }

  return errors;
}

// Routes
app.get('/', async (req: Request, res: Response) => {
  try {
    res.render('index', {
      errors: [],
      formData: {},
      title: 'Contact Us'
    });
  } catch (error) {
    console.error('Error rendering form:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    // Validate form data
    const errors = validateFormData(formData);

    if (errors.length > 0) {
      // Re-render form with errors and existing data
      return res.status(400).render('index', {
        errors,
        formData,
        title: 'Contact Us - Please Correct Errors'
      });
    }

    // Map to database submission format
    const submission: ContactSubmission = {
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province: formData.stateProvince,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    };

    // Insert into database
    await dbManager.insertSubmission(submission);
    await dbManager.saveDatabase();

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown handling
async function gracefulShutdown(signal: NodeJS.Signals): Promise<void> {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  try {
    // Close database connection
    await dbManager.closeDatabase();
    console.log('Database connection closed.');
    
    process.exit(0);
  } catch (error) {
    console.error('Error during graceful shutdown:', error);
    process.exit(1);
  }
}

// Hook into process signals
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully.');

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to access the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
