import initSqlJs, { Database } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

const DB_FILE_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

// Type definition for sql.js module
interface SqlJsModule {
  Database: new (buffer?: Uint8Array) => Database;
}

export interface ContactSubmission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsModule | null = null;

  async initialize(): Promise<void> {
    // Initialize sql.js with manual WASM file path resolution
    const wasmPath = path.resolve('node_modules/sql.js/dist/sql-wasm.wasm');
    
    this.sqlJs = await initSqlJs({
      locateFile: () => {
        return wasmPath;
      }
    }) as unknown as SqlJsModule;

    // Ensure data directory exists
    const dataDir = path.dirname(DB_FILE_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(DB_FILE_PATH)) {
      const dbBuffer = fs.readFileSync(DB_FILE_PATH);
      this.db = new (this.sqlJs as SqlJsModule).Database(dbBuffer);
    } else {
      this.db = new (this.sqlJs as SqlJsModule).Database();
    }

    // Initialize schema
    await this.initializeSchema();
  }

  private async initializeSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    // Read and execute schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    this.db.exec(schema);
  }

  async insertSubmission(submission: ContactSubmission): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
  }

  async saveDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    // Export database to buffer and write to file
    const dbBuffer: Uint8Array = this.db.export();
    fs.writeFileSync(DB_FILE_PATH, dbBuffer);
  }

  async closeDatabase(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();