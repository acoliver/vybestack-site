import express from 'express';
import path from 'path';
import databaseManager from './database';

export interface ContactFormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export interface ValidationError {
  field: keyof ContactFormData;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhoneNumber(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]*$/;
  return phone.trim().length > 0 && phoneRegex.test(phone);
}

function validateRequiredFields(data: ContactFormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  if (!data.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!data.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!data.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!data.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!data.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province is required' });
  }
  
  if (!data.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  }
  
  if (!data.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!data.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!data.phoneNumber.trim()) {
    errors.push({ field: 'phoneNumber', message: 'Phone number is required' });
  } else if (!validatePhoneNumber(data.phoneNumber)) {
    errors.push({ field: 'phoneNumber', message: 'Please enter a valid phone number' });
  }
  
  return errors;
}

function sanitizeField(field: string): string {
  return field.trim();
}

// Routes
app.get('/', (req, res) => {
  res.render('contact', {
    errors: [],
    formData: {},
    pageTitle: 'Contact Us'
  });
});

app.post('/submit', async (req, res) => {
  try {
    const formData: ContactFormData = {
      firstName: sanitizeField(req.body.firstName || ''),
      lastName: sanitizeField(req.body.lastName || ''),
      streetAddress: sanitizeField(req.body.streetAddress || ''),
      city: sanitizeField(req.body.city || ''),
      stateProvince: sanitizeField(req.body.stateProvince || ''),
      postalCode: sanitizeField(req.body.postalCode || ''),
      country: sanitizeField(req.body.country || ''),
      email: sanitizeField(req.body.email || ''),
      phoneNumber: sanitizeField(req.body.phoneNumber || '')
    };

    const errors = validateRequiredFields(formData);

    if (errors.length > 0) {
      return res.status(400).render('contact', {
        errors,
        formData,
        pageTitle: 'Contact Us - Please Correct Errors'
      });
    }

    // Insert into database
    await databaseManager.insertSubmission(formData);

    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Submission error:', error);
    res.status(500).render('contact', {
      errors: [{ field: 'general', message: 'An error occurred. Please try again.' }],
      formData: req.body,
      pageTitle: 'Contact Us - Error'
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    pageTitle: 'Thank You!'
  });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await databaseManager.closeDatabase();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await databaseManager.closeDatabase();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await databaseManager.initialize();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

if (require.main === module) {
  startServer();
}

export default app;
