import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

let db: Database | null = null;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let sqlJs: any = null;

export class DatabaseManager {
  private static instance: DatabaseManager;
  private constructor() {}

  public static getInstance(): DatabaseManager {
    if (!DatabaseManager.instance) {
      DatabaseManager.instance = new DatabaseManager();
    }
    return DatabaseManager.instance;
  }

  async initialize(): Promise<void> {
    if (!sqlJs) {
      sqlJs = await initSqlJs();
    }

    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');

    try {
      if (fs.existsSync(dbPath)) {
        const dbBuffer = fs.readFileSync(dbPath);
        db = new sqlJs.Database(dbBuffer);
      } else {
        db = new sqlJs.Database();
        
        // Ensure data directory exists
        const dataDir = path.join(process.cwd(), 'data');
        if (!fs.existsSync(dataDir)) {
          fs.mkdirSync(dataDir, { recursive: true });
        }

        // Load and execute schema
        const schema = fs.readFileSync(schemaPath, 'utf8');
        db!.exec(schema);
      }
    } catch (error) {
      console.error('Database initialization failed:', error);
      throw error;
    }
  }

  getDatabase(): Database | null {
    return db;
  }

  async insertSubmission(submission: {
    firstName: string;
    lastName: string;
    streetAddress: string;
    city: string;
    stateProvince: string;
    postalCode: string;
    country: string;
    email: string;
    phoneNumber: string;
  }): Promise<void> {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phoneNumber
    ]);

    stmt.free();
    await this.saveDatabase();
  }

  async saveDatabase(): Promise<void> {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    const dbBuffer = db.export();
    fs.writeFileSync(dbPath, Buffer.from(dbBuffer));
  }

  async closeDatabase(): Promise<void> {
    if (db) {
      db.close();
      db = null;
    }
  }
}

export default DatabaseManager.getInstance();