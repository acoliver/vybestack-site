/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Process equal parameter - store for potential future use
  // Note: equalFn is preserved for API compatibility but not used in current implementation
  if (equal === true || typeof equal === 'function') {
    void equal // Silence unused variable warning
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  return (): T => {
    // Re-computation on access to ensure freshness
    if (o.updateFn.length > 0) {
      o.value = o.updateFn(o.value)
    } else {
      o.value = o.updateFn()
    }
    return o.value!
  }
}
