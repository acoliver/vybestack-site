/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
  }

  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      if (disposed) return prevValue!
      
      // Execute the callback
      const newValue = updateFn(prevValue)
      observer.value = newValue
      return newValue
    },
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  return unsubscribe
}
