import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

// Get the directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as template engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// SQL.js initialization
import initSqlJs from 'sql.js';
const SQL = await initSqlJs({ locateFile: filename => `node_modules/sql.js/dist/${filename}` });

// Load or create database
const dbPath = path.join(__dirname, '../data/submissions.sqlite');
let db: any;

if (fs.existsSync(dbPath)) {
  const fileBuffer = fs.readFileSync(dbPath);
  db = new SQL.Database(fileBuffer);
} else {
  db = new SQL.Database();
  db.run(fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8'));
  fs.writeFileSync(dbPath, db.export());
}

interface ValidationError {
  field: string;
  message: string;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Validation functions
const validateForm = (data: FormData): ValidationError[] => {
  const errors: ValidationError[] = [];

  if (!data.firstName.trim()) errors.push({ field: 'firstName', message: 'First name is required' });
  if (!data.lastName.trim()) errors.push({ field: 'lastName', message: 'Last name is required' });
  if (!data.streetAddress.trim()) errors.push({ field: 'streetAddress', message: 'Street address is required' });
  if (!data.city.trim()) errors.push({ field: 'city', message: 'City is required' });
  if (!data.stateProvince.trim()) errors.push({ field: 'stateProvince', message: 'State/Province is required' });
  if (!data.postalCode.trim()) errors.push({ field: 'postalCode', message: 'Postal code is required' });
  if (!data.country.trim()) errors.push({ field: 'country', message: 'Country is required' });
  if (!data.phone.trim()) errors.push({ field: 'phone', message: 'Phone number is required' });

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!data.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!emailRegex.test(data.email.trim())) {
    errors.push({ field: 'email', message: 'Email is invalid' });
  }

  // Phone number validation (accepts international formats with digits, spaces, parentheses, dashes and +)
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  if (!phoneRegex.test(data.phone.trim())) {
    errors.push({ field: 'phone', message: 'Phone number format is invalid' });
  }

  return errors;
};

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], formData: {} });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    return res.status(400).render('form', { errors, formData });
  }

  // Insert into database
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
  stmt.free();

  // Export database to file
  const data = db.export();
  fs.writeFileSync(dbPath, data);

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
let server: any;
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing server...');
  if (server) {
    server.close(() => {
      console.log('Express server closed');
      const data = db.export();
      fs.writeFileSync(dbPath, data);
      db.close();
      console.log('Database closed');
    });
  }
});

// Start server
server = app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

export default app;