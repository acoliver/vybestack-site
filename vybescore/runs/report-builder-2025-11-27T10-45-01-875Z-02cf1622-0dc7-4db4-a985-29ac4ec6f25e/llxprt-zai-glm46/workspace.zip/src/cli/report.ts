#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry ${index} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${index} has missing or invalid "label" field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${index} has missing or invalid "amount" field`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

function parseArguments(args: string[]): CliOptions {
  const result: CliOptions = {
    format: 'markdown',
    includeTotals: false,
  };

  let i = 2; // Skip node and script path

  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      const format = args[i];
      if (format !== 'markdown' && format !== 'text') {
        throw new Error('Unsupported format');
      }
      result.format = format as 'markdown' | 'text';
    } else if (arg === '--output') {
      i++;
      result.output = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      // Skip non-option arguments (data file path)
    }
    i++;
  }

  return result;
}

function main() {
  try {
    const args = process.argv;

    if (args.length < 3) {
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    const dataFile = args[2];
    const options = parseArguments(args);

    // Read and parse JSON data
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(dataFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error(`Invalid JSON in file ${dataFile}: ${error.message}`);
      }
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        throw new Error(`File not found: ${dataFile}`);
      }
      throw error;
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Render report
    let output: string;
    if (options.format === 'markdown') {
      output = renderMarkdown(reportData, { includeTotals: options.includeTotals });
    } else {
      output = renderText(reportData, { includeTotals: options.includeTotals });
    }

    // Write output
    if (options.output) {
      writeFileSync(options.output, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}