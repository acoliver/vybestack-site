import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const page = pageParam ? Number(pageParam) : 1;
    const limit = limitParam ? Number(limitParam) : 5;

    if (pageParam !== undefined && (isNaN(page) || page !== parseInt(pageParam, 10) || page <= 0)) {
      return res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer.' });
    }

    if (limitParam !== undefined && (isNaN(limit) || limit !== parseInt(limitParam, 10) || limit <= 0 || limit > 100)) {
      return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer not exceeding 100.' });
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
