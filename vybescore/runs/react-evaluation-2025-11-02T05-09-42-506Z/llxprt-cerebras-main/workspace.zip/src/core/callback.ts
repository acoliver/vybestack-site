/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, initialValue?: T): UnsubscribeFn {
  let value: T = initialValue as T
  
  const observer: Observer<T> = {
    value,
    updateFn: (prev?: T) => {
      const previousObserver = getActiveObserver()
      setActiveObserver(observer as unknown as Observer<unknown>)
      
      try {
        value = updateFn(prev)
        return value
      } finally {
        setActiveObserver(previousObserver)
      }
    }
  }
  
  // Initialize the callback by running it once
  value = observer.updateFn(initialValue)
  
  let disposed = false
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Clear references to prevent memory leaks
    observer.value = undefined as unknown as T
    observer.updateFn = () => observer.value!
  }
  
  return unsubscribe
}