/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  initialValue: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Normalize equal parameter to function
  const equalFn: EqualFn<T> = typeof equal === 'function' ? equal : 
    equal === false ? () => false : 
    Object.is;

  let value: T = initialValue;
  
  // Store observers that depend on this input
  const observers = new Set<Observer<T>>()

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      observers.add(observer as Observer<T>)
    }
    return value
  }

  const write: SetterFn<T> = (nextValue: T) => {
    // Only update if the new value is different
    if (!equalFn(value, nextValue)) {
      value = nextValue
      
      // Update all dependent observers
      observers.forEach(observer => {
        updateObserver(observer)
      })
    }
    return value
  }

  return [read, write]
}
