/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  initialValue?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Normalize equal parameter to function
  const equalFn: EqualFn<T> = typeof equal === 'function' ? equal : 
    equal === false ? () => false : 
    Object.is;
  
  let value: T = initialValue as T;
  
  // Store observers that depend on this computed value
  const observers = new Set<Observer<T>>()
  
  // Store dependencies (inputs or other computed values) that this computed depends on
  const dependencies = new Set<Observer<unknown>>()
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prev?: T) => {
      // Set current computed as active observer for dependency tracking
      const previousObserver = getActiveObserver()
      setActiveObserver(observer as unknown as Observer<unknown>)
      
      // Track our previous dependencies for cleanup
      const previousDependencies = new Set(dependencies)
      dependencies.clear()
      
      try {
        const newValue = updateFn(prev)
        
        // Only update if value has actually changed
        if (!equalFn(value, newValue)) {
          value = newValue
          
          // Notify dependent observers
          observers.forEach(obs => updateObserver(obs))
        }
        
        return value
      } finally {
        // Restore previous observer
        setActiveObserver(previousObserver)
        
        // Clean up dependencies that we no longer depend on
        previousDependencies.forEach(dep => {
          if (!dependencies.has(dep)) {
            if (dep.dependencies) {
              dep.dependencies.delete(observer as unknown as Observer<unknown>)
            }
          }
        })
      }
    }
  }
  
  // Initialize the computed value
  value = observer.updateFn(initialValue)
  
  const read: GetterFn<T> = () => {
    // Register current active observer as depending on this computed
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      observers.add(currentObserver as Observer<T>)
      
      // Add this computed as a dependency of the observer
      if (!currentObserver.dependencies) {
        currentObserver.dependencies = new Set<Observer<unknown>>()
      }
      currentObserver.dependencies.add(observer as unknown as Observer<unknown>)
      
      // Also add observer as dependency of this computed for tracking
      if (!observer.dependencies) {
        observer.dependencies = new Set<Observer<unknown>>()
      }
      observer.dependencies.add(currentObserver)
    }
    
    return value
  }
  
  return read
}