#!/usr/bin/env python3

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Replace the problematic line with the correct regex
content = content.replace(
    'return text.replace(/https?://([^/\\\\s]+)(/[^\\\\s]*)?/g, (match, host, path) => {',
    'return text.replace(/https?:\\/\\/([^\\/\\s]+)(\\/[^\\s]*)?/g, (match, host, path) => {'
)

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed regex pattern")