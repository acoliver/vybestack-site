/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Inserts exactly one space between sentences even if input omitted it.
 * Collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Split on sentence endings .!? but keep them in the result
  const sentences = text.split(/([.!?]+)/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part.match(/[.!?]+/)) {
      // Sentence ending - add it and capitalize next text
      result += part;
      capitalizeNext = true;
    } else {
      // Regular text - capitalize first letter if needed
      if (capitalizeNext && part.trim()) {
        // Find first non-whitespace character and capitalize it
        const trimmed = part.trimStart();
        const leadingSpace = part.substring(0, part.indexOf(trimmed));
        const firstChar = trimmed.charAt(0).toUpperCase();
        const rest = trimmed.substring(1);
        result += leadingSpace + firstChar + rest;
        capitalizeNext = false;
      } else {
        // Normal text - just clean up extra spaces
        result += part.replace(/\s+/g, ' ');
      }
    }
  }
  
  // Clean up extra spaces around sentence endings
  result = result.replace(/\s+([.!?])/g, '$1').replace(/([.!?])\s+/g, '$1 ');
  
  return result.trim();
}

/**
 * Finds URLs in the text. Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern
  const urlRegex = /(https?:\/\/[^\s<>"]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s<>"]*)?)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)]+$/g, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  return text.replace(/https?:\/\/([^\s/]+)([^\s]*)/g, (match, host, path) => {
    // Always upgrade to https
    let newHost = host;
    const newPath = path || '';

    // Check if we should rewrite docs to docs.example.com
    const shouldRewriteDocs =
      newPath.startsWith('/docs/') &&
      !newPath.match(/\/(?:cgi-bin|.*\?.*|.*&(?:amp;)?.*|.*=.*|.*\.(?:jsp|php|asp|aspx|do|cgi|pl|py)(?:\?.*)?)$/);
    
    if (shouldRewriteDocs) {
      // Extract domain without subdomain
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        // If it's already docs. subdomain, keep it
        if (domainParts[0] === 'docs') {
          newHost = host;
        } else {
          // Create docs. subdomain
          newHost = `docs.${domainParts.slice(-2).join('.')}`;
        }
      }
    }
    
    return `https://${newHost}${newPath}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';
  
  // Additional validation for specific months
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year in February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeap = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (day > (isLeap ? 29 : 28)) return 'N/A';
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}