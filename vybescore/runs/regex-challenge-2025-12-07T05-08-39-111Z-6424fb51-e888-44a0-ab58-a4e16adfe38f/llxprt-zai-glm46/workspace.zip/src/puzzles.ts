/**
 * Matches words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Create regex to find words starting with prefix
  // \b ensures we match whole words, \w+ matches word characters
  const wordRegex = new RegExp(`\\b${escapeRegex(prefix)}\\w+`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  return matches
    .map(word => word) // Return the exact match from text
    .filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Find token preceded by a digit using regex with capture group
  const tokenRegex = new RegExp(`(\\d)${escapeRegex(token)}`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Return the full match including the digit and token
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates passwords according to security policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, 
 * no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length requirement
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // Look for patterns of length 2-4 that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const repeatRegex = new RegExp(`(.{${len}})\\1`, 'i');
    if (repeatRegex.test(value)) return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex patterns
  
  // Full IPv6 with all 8 groups
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: compression
  const compressedIPv6 = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*[0-9a-fA-F]{1,4}/;
  
  // IPv6 with leading/trailing ::
  const edgeCompressedIPv6 = /^::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}$/;
  
  // IPv6 embedded with IPv4 (like ::ffff:192.0.2.128)
  const ipv6WithIPv4 = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/;
  
  // First check if it looks like IPv4 and exclude those
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Pattern.test(value.trim())) return false;
  
  // Check for any IPv6 pattern
  return fullIPv6.test(value) || 
         compressedIPv6.test(value) || 
         edgeCompressedIPv6.test(value) || 
         ipv6WithIPv4.test(value);
}

/**
 * Helper function to escape special regex characters in the prefix/token.
 */
function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}