export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with robust regex.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email validation regex
  // Local part: letters, digits, +, -, ., apostrophes (but not consecutive dots)
  // Domain part: letters, digits, hyphens, dots (but not leading/trailing dots)
  // TLD: 2-63 letters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for common issues
  if (!emailRegex.test(value)) return false;
  
  // No consecutive dots in local part or domain
  if (value.includes('..')) return false;
  
  // No leading or trailing dots in local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // No underscore in domain
  const domain = value.substring(value.indexOf('@') + 1);
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check minimum length
  if (cleaned.length < 10) return false;
  
  // Extract country code if present
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length > 10) {
    digits = digits.substring(1);
  }
  
  // Must have exactly 10 digits for US number
  if (digits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code, optional 0 trunk prefix, optional 9 mobile indicator
  // Area code: 2-4 digits starting with 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) return false;

  // Area code and subscriber validation handled by regex
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters (including accented), apostrophes, hyphens, and spaces
  // Must contain at least one letter
  const nameRegex = /^[\p{L}'’\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter (not just spaces/hyphens/apostrophes)
  const containsLetter = /[\p{L}]/u.test(value);
  if (!containsLetter) return false;
  
  // Reject digits and obvious symbols (already handled by regex)
  return true;
}

/**
 * Helper function for Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx.
 * Accepts proper prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
// Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be only digits
  if (!/^\d+$/.test(cleaned)) return false;

  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4\d{12}(?:\d{3})?$/;

  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;

  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;

  const isValidFormat =
    visaRegex.test(cleaned) ||
    mastercardRegex.test(cleaned) ||
    amexRegex.test(cleaned);
  
  if (!isValidFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}