#!/usr/bin/env python3

with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Find line 76 and fix the unnecessary escape
for i, line in enumerate(lines):
    if i == 75:  # Line 76 (0-indexed)
        print(f"Original line 76: {repr(line)}")
        # Replace with proper regex without unnecessary escapes
        lines[i] = '  return text.replace(/https?:\\/\\/([^\\/\\s]+)(\\/[^\\s]*)?/g, (match, host, path) => {\n'
        print(f"Fixed line 76: {repr(lines[i])}")
        break

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Successfully fixed the unnecessary escape character in line 76")