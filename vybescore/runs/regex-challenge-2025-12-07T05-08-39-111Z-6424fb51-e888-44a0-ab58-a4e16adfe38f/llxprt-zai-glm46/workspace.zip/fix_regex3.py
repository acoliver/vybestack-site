#!/usr/bin/env python3

with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Find and fix the regex in line 76
for i, line in enumerate(lines):
    if i == 75 and 'https?' in line:  # Line 76 (0-indexed) with https
        print(f"Original line 76: {repr(line)}")
        # Fix the regex by replacing \\/ with / and \s with \\s
        fixed_line = line.replace('\\\\/', '/').replace('\\\\s', '\\s')
        print(f"Fixed line 76: {repr(fixed_line)}")
        lines[i] = fixed_line
        break

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Successfully fixed the unnecessary escape characters")