import { describe, expect, it, beforeAll, afterAll, beforeEach } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase } from '../../src/server.js';

let dbPath: string;
const ORIGINAL_ENV = process.env.PORT;

beforeAll(async () => {
  dbPath = path.resolve('data', 'submissions.sqlite');
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  process.env.PORT = '0';

  // Initialize the database in the server
  await initializeDatabase();
});

beforeEach(() => {
  // Reset database before each test that writes to it
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(() => {
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  process.env.PORT = ORIGINAL_ENV;
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const $ = cheerio.load(response.text);
    const fields = ['firstName', 'lastName', 'streetAddress', 'city', 'stateProvince', 'postalCode', 'country', 'email', 'phone'];

    for (const field of fields) {
      const input = $(`#${field}`);
      expect(input.length).toBe(1);
      const label = $(`label[for="${field}"]`);
      expect(label.length).toBe(1);
    }
  });

  it('shows validation errors for empty fields', async () => {
    const response = await request(app).post('/submit').type('form').send({});
    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
  });

  it('shows validation errors for invalid email', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'notanemail',
        phone: '+44 20 7946 0958',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Email must be a valid email address');
  });

  it('shows validation errors for invalid phone', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john@example.com',
        phone: 'invalid-phone!',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Phone number must contain only digits');
  });

  it('accepts valid UK submission with international phone', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '10 Downing Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 2AA',
        country: 'United Kingdom',
        email: 'jane@example.com',
        phone: '+44 20 7946 0958',
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('accepts valid Argentine submission', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Carlos',
        lastName: 'García',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'Buenos Aires',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'carlos@example.com',
        phone: '+54 9 11 1234-5678',
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: '',
        streetAddress: '123 Main St',
        city: 'London',
        postalCode: 'SW1A 1AA',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('#firstName').val()).toBe('John');
    expect($('#lastName').val()).toBe('');
    expect($('#streetAddress').val()).toBe('123 Main St');
  });

  it('renders thank you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('stranger on the internet');
    expect(response.text).toContain('/">');
  });

  it('persists submission and redirects to thank you', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: 'Test Street 1',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: '+1 555-123-4567',
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
