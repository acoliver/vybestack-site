import express, { type Request, type Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { type Database } from 'sql.js';
import * as fs from 'node:fs/promises';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;

const TEMPLATES_PATH = path.join(__dirname, '../src/templates');
app.set('view engine', 'ejs');
app.set('views', TEMPLATES_PATH);

app.use(express.static(path.join(process.cwd(), 'public')));
app.use(express.urlencoded({ extended: true }));

function validateEmail(email: string): boolean {
  const emailRegex: RegExp = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex: RegExp = /^[\d\s\-()+]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex: RegExp = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateSubmission(values: FormValues): ValidationResult {
  const errors: string[] = [];

  if (!values.firstName?.trim()) {
    errors.push('First name is required.');
  }
  if (!values.lastName?.trim()) {
    errors.push('Last name is required.');
  }
  if (!values.streetAddress?.trim()) {
    errors.push('Street address is required.');
  }
  if (!values.city?.trim()) {
    errors.push('City is required.');
  }
  if (!values.stateProvince?.trim()) {
    errors.push('State / Province / Region is required.');
  }
  if (!values.postalCode?.trim()) {
    errors.push('Postal / Zip code is required.');
  } else if (!validatePostalCode(values.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, digits, spaces, and hyphens.');
  }
  if (!values.country?.trim()) {
    errors.push('Country is required.');
  }
  if (!values.email?.trim()) {
    errors.push('Email is required.');
  } else if (!validateEmail(values.email)) {
    errors.push('Email must be a valid email address.');
  }
  if (!values.phone?.trim()) {
    errors.push('Phone number is required.');
  } else if (!validatePhone(values.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and a leading +.');
  }

  const valid: boolean = errors.length === 0;

  return {
    valid,
    errors,
  };
}

app.get('/', (_req: Request, res: Response): void => {
  res.render('form', {
    values: {},
    errors: [],
  });
});

app.post('/submit', async (req: Request, res: Response): Promise<void> => {
  const values: FormValues = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const validation = validateSubmission(values);

  if (!validation.valid) {
    res.status(400).render('form', {
      values,
      errors: validation.errors,
    });
    return;
  }

  if (!db) {
    res.status(500).render('form', {
      values,
      errors: ['Database not available. Please try again.'],
    });
    return;
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        values.firstName!.trim(),
        values.lastName!.trim(),
        values.streetAddress!.trim(),
        values.city!.trim(),
        values.stateProvince!.trim(),
        values.postalCode!.trim(),
        values.country!.trim(),
        values.email!.trim(),
        values.phone!.trim(),
      ]);
    } finally {
      stmt.free();
    }

    const data = db.export();
    const buffer = Buffer.from(data);
    await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
    await fs.writeFile(DB_PATH, buffer);

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      values,
      errors: ['An error occurred while saving your submission. Please try again.'],
    });
  }
});

app.get('/thank-you', (_req: Request, res: Response): void => {
  res.render('thank-you', {
    firstName: 'Friend',
  });
});

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();

    let dbData: Uint8Array | null = null;

    try {
      const fileData = await fs.readFile(DB_PATH);
      dbData = new Uint8Array(fileData);
    } catch {
      console.log('No existing database found, creating new one.');
    }

    db = new SQL.Database(dbData ?? undefined);

    if (!dbData) {
      const schema = await fs.readFile(SCHEMA_PATH, 'utf-8');
      db.run(schema);
      console.log('Database schema initialized.');
    } else {
      console.log('Loaded existing database.');
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

async function startServer(): Promise<void> {
  await initializeDatabase();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

  const server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  server.on('error', (error: NodeJS.ErrnoException) => {
    if (error.code === 'EADDRINUSE') {
      console.error(`Port ${port} is already in use. Please choose a different port.`);
    } else {
      console.error('Server error:', error);
    }
    process.exit(1);
  });

  const shutdown = (signal: string) => {
    return () => {
      console.log(`${signal} received, shutting down gracefully...`);
      server.close(() => {
        if (db) {
          db.close();
          db = null;
        }
        console.log('Server closed.');
        process.exit(0);
      });
    };
  };

  process.on('SIGTERM', shutdown('SIGTERM'));
  process.on('SIGINT', shutdown('SIGINT'));
}

export { app, initializeDatabase };

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
