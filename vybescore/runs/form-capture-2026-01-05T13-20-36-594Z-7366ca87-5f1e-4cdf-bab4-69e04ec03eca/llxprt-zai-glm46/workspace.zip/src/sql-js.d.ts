declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): RunResult;
    getAsObject(params?: unknown): Record<string, unknown>;
    free(): void;
  }

  export interface RunResult {
    changes: number;
    lastInsertRowid: number;
  }

  export interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  export default function initSqlJs(options?: { locateFile?: (filename: string) => string }): Promise<SqlJsStatic>;
}
