#!/usr/bin/env node

import { writeFileSync } from 'node:fs';
import { parseArguments } from './args.js';
import { getRenderer } from '../formats/index.js';
import { loadReportData } from '../utils.js';

/**
 * Main CLI execution
 */
function main(): void {
  try {
    // Parse command line arguments
    const args = parseArguments();
    
    // Load and validate report data
    const reportData = loadReportData(args.dataFile);
    
    // Get the appropriate renderer
    const renderer = getRenderer(args.format);
    if (!renderer) {
      console.error(`Unsupported format: ${args.format}`);
      process.exit(1);
    }
    
    // Render the report
    const output = renderer.render(reportData, {
      includeTotals: args.includeTotals,
    });
    
    // Handle output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf-8');
        console.error(`Report written to: ${args.outputPath}`);
      } catch (error) {
        console.error(`Failed to write to output file: ${args.outputPath}`);
        process.exit(1);
      }
    } else {
      // Output to stdout
      console.log(output);
    }
    
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

// Run the CLI
main();