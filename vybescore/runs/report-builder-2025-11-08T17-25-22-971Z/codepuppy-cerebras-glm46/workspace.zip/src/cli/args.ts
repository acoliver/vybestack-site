import type { CliArgs } from '../types.js';

/**
 * Parse command line arguments
 */
export function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  
  // Parse arguments
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i + 1];
      i++; // Skip the next arg as it's the value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i + 1];
      i++; // Skip the next arg as it's the value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  return {
    dataFile,
    format: format as 'markdown' | 'text',
    outputPath,
    includeTotals,
  };
}