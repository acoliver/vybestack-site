/**
 * Report entry interface
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Formatting options for renderers
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Renderer interface for different output formats
 */
export interface ReportRenderer {
  render(data: ReportData, options: RenderOptions): string;
}

/**
 * Parsed CLI arguments
 */
export interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}