import { readFileSync } from 'node:fs';
import type { ReportData, ReportEntry } from './types.js';

/**
 * Validate report entry structure
 */
function validateReportEntry(entry: unknown): entry is ReportEntry {
  return (
    typeof entry === 'object' &&
    entry !== null &&
    'label' in entry &&
    'amount' in entry &&
    typeof (entry as ReportEntry).label === 'string' &&
    typeof (entry as ReportEntry).amount === 'number'
  );
}

/**
 * Validate report data structure
 */
function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const obj = data as Record<string, unknown>;
  return (
    typeof obj.title === 'string' &&
    typeof obj.summary === 'string' &&
    Array.isArray(obj.entries) &&
    obj.entries.every(validateReportEntry)
  );
}

/**
 * Load and parse JSON data from file
 */
export function loadReportData(filePath: string): ReportData {
  let fileContent: string;
  
  try {
    fileContent = readFileSync(filePath, 'utf-8');
  } catch (error) {
    throw new Error(`Failed to read file: ${filePath}`);
  }

  let parsedData: unknown;
  
  try {
    parsedData = JSON.parse(fileContent);
  } catch (error) {
    throw new Error('Invalid JSON format');
  }

  if (!validateReportData(parsedData)) {
    const issues: string[] = [];
    const obj = parsedData as Record<string, unknown>;
    
    if (!obj || typeof obj !== 'object') {
      issues.push('Root must be an object');
    } else {
      if (typeof obj.title !== 'string') {
        issues.push('Missing or invalid "title" field (must be string)');
      }
      if (typeof obj.summary !== 'string') {
        issues.push('Missing or invalid "summary" field (must be string)');
      }
      if (!Array.isArray(obj.entries)) {
        issues.push('Missing or invalid "entries" field (must be array)');
      } else {
        obj.entries.forEach((entry: unknown, index: number) => {
          if (!validateReportEntry(entry)) {
            issues.push(`Entry ${index} is invalid (must have "label" string and "amount" number)`);
          }
        });
      }
    }
    
    throw new Error(`Invalid report data: ${issues.join(', ')}`);
  }

  return parsedData;
}