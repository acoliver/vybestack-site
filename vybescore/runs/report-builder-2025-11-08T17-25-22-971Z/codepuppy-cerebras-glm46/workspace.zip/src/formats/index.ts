import type { ReportRenderer } from '../types.js';
import { markdownRenderer } from './markdown.js';
import { textRenderer } from './text.js';

/**
 * Registry of available report renderers
 */
export const formatRenderers: Record<string, ReportRenderer> = {
  markdown: markdownRenderer,
  text: textRenderer,
} as const;

/**
 * Get supported format names
 */
export function getSupportedFormats(): string[] {
  return Object.keys(formatRenderers);
}

/**
 * Check if a format is supported
 */
export function isFormatSupported(format: string): boolean {
  return format in formatRenderers;
}

/**
 * Get renderer for a specific format
 */
export function getRenderer(format: string): ReportRenderer | null {
  return formatRenderers[format] || null;
}