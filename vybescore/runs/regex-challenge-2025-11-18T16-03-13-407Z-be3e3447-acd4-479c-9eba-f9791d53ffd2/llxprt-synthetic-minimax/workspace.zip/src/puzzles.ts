/**
 * Find words beginning with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[] = []): string[] {
  if (!text || !prefix) return [];
  
  // Create regex pattern to find words starting with prefix
  // Word boundary at start, then the prefix, then any word characters
  const pattern = new RegExp(`\\b${prefix}[\\w-]*`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  const result = matches.filter(match => {
    const lowercaseMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      lowercaseMatch === exception.toLowerCase()
    );
  });
  
  return result;
}

/**
 * Find occurrences where the token appears after a digit and not at the start of the string
 * Uses lookaheads and lookbehinds as requested
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Create regex that finds digit followed by token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Look for digit followed by the token, ensuring it's not at the start
  const pattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate password strength with specific requirements
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab)
  // This regex looks for any 2+ character sequence that repeats immediately
  const repeatPattern = /(..+)\1/;
  if (repeatPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses including shorthand notation
 * Ensure IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 patterns to match:
  // 1. Full IPv6 (8 groups of 4 hex digits): 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // 2. Compressed IPv6 with :: 2001:db8::8a2e:370:7334
  // 3. IPv6 with IPv4 mapping: ::ffff:192.0.2.1
  // 4. Various compressed formats
  
  const ipv6Patterns = [
    // Full format with possible leading zeros compression
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // Compressed with ::
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b/,
    /\b:(?::[0-9a-fA-F]{1,4}){1,7}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}\b/,
    /\b[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}\b/,
    // IPv4-mapped IPv6
    /\b::(?:ffff:)?(?:\d{1,3}\.){3}\d{1,3}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}\b/
  ];
  
  // Check each pattern
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}