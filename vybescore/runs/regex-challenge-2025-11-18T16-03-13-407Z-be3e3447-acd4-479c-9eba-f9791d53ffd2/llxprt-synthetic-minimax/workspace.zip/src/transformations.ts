// URL regex pattern to find URLs in text
const URL_REGEX = /\bhttps?:\/\/[^\s<>"]+[^\s<>"]/gi;

/**
 * Capitalize the first character of each sentence
 * Handles proper spacing between sentences and preserves abbreviations
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split text into sentences using common sentence endings
  // This is tricky - we need to be careful with abbreviations
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  let result = '';
  let firstSentence = true;
  
  for (let i = 0; i < sentences.length; i++) {
    let sentence = sentences[i].trim();
    
    if (sentence.length === 0) continue;
    
    // Capitalize first letter of sentence
    sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    
    // Add space before sentence if not the first
    if (!firstSentence) {
      result += ' ';
    }
    result += sentence;
    
    firstSentence = false;
  }
  
  return result;
}

/**
 * Extract all URLs from text
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  const matches = text.match(URL_REGEX) || [];
  
  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,!?;:]+\s*$/, '');
  });
}

/**
 * Replace http:// with https:// while leaving secure URLs untouched
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// but don't touch existing https://
  return text.replace(/https?:\/\//gi, 'https://');
}

/**
 * Rewrite documentation URLs according to specific rules
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // URL pattern to match http URLs with various components
  const httpUrlRegex = /http:\/\/([^\/\s]+)(\/[^\s]*)/gi;
const httpUrlRegex = /http:\/\/([^\/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(httpUrlRegex, (match, host, path) => {
    // Always upgrade to https
    const newUrl = 'https://';
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions that should skip host rewrite
      const hasDynamicHints = /(\?.*)|(&.*)|(=.*)|(cgi-bin)|(\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
      
      if (hasDynamicHints) {
        // Skip host rewrite, just upgrade scheme
        return newUrl + host + path;
      } else {
        // Rewrite host to docs.host
        const docsHost = 'docs.' + host;
        return newUrl + docsHost + path;
      }
    } else {
      // For non-docs URLs, just upgrade the scheme
      return newUrl + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy format
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}
