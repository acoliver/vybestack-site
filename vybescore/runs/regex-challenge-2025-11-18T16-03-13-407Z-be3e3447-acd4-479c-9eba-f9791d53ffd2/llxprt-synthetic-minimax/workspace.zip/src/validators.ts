// Unicode letters name validation - permits letters, accents, apostrophes, hyphens, spaces
const NAME_REGEX = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;

/**
 * Validates email addresses
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  if (!value || value.length > 254) return false;
  
  // Basic format check
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  if (!emailRegex.test(value)) return false;
  
  // Check for double dots in any part
  if (value.includes('..')) return false;
  
  // Check for trailing dots
  if (value.split('@')[1]?.startsWith('.') || value.endsWith('.')) return false;
  
  // Check for underscores in domain
  if (value.split('@')[1]?.includes('_')) return false;
  
  // More specific domain validation
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const domain = parts[1];
  const domainParts = domain.split('.');
  
  // Check each domain part
  for (const part of domainParts) {
    if (part.length === 0 || part.length > 63) return false;
    if (part.startsWith('-') || part.endsWith('-')) return false;
  }
  
  return true;
}

interface USPhoneOptions {
  requireAreaCode?: boolean;
}

export function isValidUSPhone(value: string, options?: USPhoneOptions): boolean {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { requireAreaCode = false } = options || {};
  
  if (!value) return false;
  
  // Remove all non-digits
  const digits = value.replace(/\D/g, '');
  
  // Check length (should be 10 or 11 with country code)
  if (digits.length === 11 && digits.startsWith('1')) {
    // 11 digits with country code
  } else if (digits.length === 10) {
    // 10 digits without country code
  } else {
    return false;
  }
  
  // US phone number validation regex - supports multiple formats
  const US_PHONE_REGEX = /^(?:\+1\s?)?(?:\((\d{3})\)|(\d{3}))[\s.-]?(\d{3})[\s.-]?(\d{4})$/;
  const match = value.match(US_PHONE_REGEX);
  if (!match) return false;
  
  const areaCode = match[1] || match[2];
  if (!areaCode) return false;
  
  // Check if area code is valid (first digit can't be 0 or 1)
  if (areaCode.length === 3 && (areaCode[0] === '0' || areaCode[0] === '1')) {
    return false;
  }
  
  // Check if 10 digits when 11-digit format is provided with country code
  if (digits.length === 11 && !digits.startsWith('1')) {
    return false;
  }
  
  // Check if too short
  if (digits.length < 10) return false;
  
  return true;
}

export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Argentine phone validation regex - handles landlines and mobiles
  const ARGENTINE_PHONE_REGEX = /^(?:\+54\s?)?(?:0?\s?)?(?:9\s?)?(\d{2,4})[\s.-]?(\d{3,4})[\s.-]?(\d{3,4})$/;
  const match = value.match(ARGENTINE_PHONE_REGEX);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = (match[2] || '') + (match[3] || '');
  
  // Area code must be 2-4 digits (first digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] < '1' || areaCode[0] > '9') return false;
  
  // Total subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

export function isValidName(value: string): boolean {
  if (!value || value.length === 0 || value.length > 100) return false;
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  // Check for invalid characters (digits, symbols except apostrophes and hyphens)
  const invalidPattern = /[\d^x×Ææ]/;
  if (invalidPattern.test(value)) return false;
  
  // Must match the unicode pattern
  if (!NAME_REGEX.test(value)) return false;
  
  return true;
}

// Credit card validation helpers
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove all non-digits
  const digits = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for major cards)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check card type patterns
  let isValidCard = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    isValidCard = true;
  }
  // Mastercard: starts with 51-55, length 16
  else if (/^5[1-5]/.test(digits) && digits.length === 16) {
    isValidCard = true;
  }
  // AmEx: starts with 34 or 37, length 15
  else if (/^3[47]/.test(digits) && digits.length === 15) {
    isValidCard = true;
  }
  
  if (!isValidCard) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}