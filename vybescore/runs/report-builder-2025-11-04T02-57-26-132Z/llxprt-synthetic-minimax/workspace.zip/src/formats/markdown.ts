import { ReportData, CLIOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: CLIOptions): string {
  const { entries } = data;
  const total = entries.reduce((sum, entry) => sum + entry.amount, 0);

  const lines: string[] = [];

  lines.push(`# ${data.title}`);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('## Entries');

  for (const entry of entries) {
    lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  }

  if (options.includeTotals) {
    lines.push('');
    lines.push(`**Total:** $${total.toFixed(2)}`);
  }

  return lines.join('\n');
}