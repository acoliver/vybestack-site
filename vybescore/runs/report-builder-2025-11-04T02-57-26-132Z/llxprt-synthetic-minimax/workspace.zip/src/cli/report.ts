import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(args: string[]): CLIOptions & { inputFile: string } {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];

  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i + 1] as 'markdown' | 'text';
      i++;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      output = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  return {
    inputFile,
    format,
    output,
    includeTotals,
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);

    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: title is required and must be a string');
    }

    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary is required and must be a string');
    }

    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }

    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Invalid data: each entry must have a label string');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Invalid data: each entry must have a numeric amount');
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('Invalid data:')) {
        throw error;
      }
      throw new Error(`Failed to parse JSON: ${error.message}`);
    }
    throw new Error('Failed to parse JSON');
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, 'utf-8');
  } else {
    process.stdout.write(content + '\n');
  }
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const { inputFile, format, output, includeTotals } = parseArgs(args);
    const data = loadReportData(inputFile);

    const options: CLIOptions = { format, output, includeTotals };

    let rendered: string;

    if (format === 'markdown') {
      rendered = renderMarkdown(data, options);
    } else {
      rendered = renderText(data, options);
    }

    writeOutput(rendered, output);
  } catch (error) {
    if (error instanceof Error) {
      process.stderr.write(error.message + '\n');
      process.exit(1);
    }
    process.stderr.write('An unknown error occurred\n');
    process.exit(1);
  }
}

main();