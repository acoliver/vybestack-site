export class Database {
  constructor(data?: ArrayBuffer);
  run(sql: string, ...params: unknown[]): void;
  exec(sql: string): Array<{ values: unknown[][], columns: string[] }>;
  export(): ArrayBuffer;
  prepare(sql: string): Statement;
  close(): void;
}

export interface Statement {
  run(...params: unknown[]): void;
  free(): void;
}

export interface SqlJsStatic {
  Database: typeof Database;
}

declare const SqlJs: SqlJsStatic;
export default SqlJs;