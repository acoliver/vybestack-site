import { FormData, ValidationError } from './types.js';

export function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // First name validation
  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  // Last name validation
  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  // Street address validation
  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  // City validation
  if (!data.city || data.city.trim().length === 0) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  // State/Province validation
  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  // Postal code validation (accept alphanumeric)
  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code may only contain letters, numbers, spaces, and hyphens' });
  }

  // Country validation
  if (!data.country || data.country.trim().length === 0) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  // Email validation
  if (!data.email || data.email.trim().length === 0) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation (accept international formats)
  if (!data.phone || data.phone.trim().length === 0) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^\+?[0-9\s\-()]+$/.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number may only contain digits, spaces, parentheses, dashes, and optional leading +' });
  }

  return errors;
}

export function formatFormData(body: Record<string, unknown>): FormData {
  return {
    firstName: (body.firstName as string) || '',
    lastName: (body.lastName as string) || '',
    streetAddress: (body.streetAddress as string) || '',
    city: (body.city as string) || '',
    stateProvince: (body.stateProvince as string) || '',
    postalCode: (body.postalCode as string) || '',
    country: (body.country as string) || '',
    email: (body.email as string) || '',
    phone: (body.phone as string) || '',
  };
}