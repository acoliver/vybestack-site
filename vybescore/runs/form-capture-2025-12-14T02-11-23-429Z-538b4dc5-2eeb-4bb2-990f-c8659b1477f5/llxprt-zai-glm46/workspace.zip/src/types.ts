export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationError {
  field: keyof FormData;
  message: string;
}

export interface FormSubmission extends FormData {
  id: number;
  createdAt: string;
}