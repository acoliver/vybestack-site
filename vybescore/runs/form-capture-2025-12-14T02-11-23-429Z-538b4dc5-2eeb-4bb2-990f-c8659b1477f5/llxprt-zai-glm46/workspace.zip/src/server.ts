import express from 'express';
import { FormDatabase } from './database.js';
import { validateForm, formatFormData } from './validation.js';
import { FormData } from './types.js';
import path from 'path';
import { fileURLToPath } from 'url';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;
const database = new FormDatabase();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} as Partial<FormData>
  });
});

app.post('/submit', async (req, res) => {
  try {
    const formData = formatFormData(req.body);
    const errors = validateForm(formData);

    if (errors.length > 0) {
      const errorMessages = errors.map(error => error.message);
      return res.status(400).render('form', {
        errors: errorMessages,
        values: formData
      });
    }

    // Insert into database
    await database.insertSubmission(formData);

    // Redirect to thank you page with first name
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while processing your submission. Please try again.'],
      values: formatFormData(req.body)
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Initialize database and start server
export async function startServer() {
  try {
    await database.initialize();
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown function
function shutdown(signal: string) {
  console.log(`Received ${signal}, shutting down gracefully`);
  database.close().then(() => {
    process.exit(0);
  });
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
