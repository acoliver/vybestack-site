import * as fs from 'fs';
import * as path from 'path';
// @ts-expect-error - sql.js module
import initSqlJs from 'sql.js';
import { FormData, FormSubmission } from './types.js';
import type { Database } from './sqljs-types.js';

export class FormDatabase {
  private db: Database | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    try {
        // Load sql.js library
      const SQL = await initSqlJs({
        locateFile: (file: string) => {
          // Handle WASM file location
          return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
        }
      });

      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Initialize database
      if (fs.existsSync(this.dbPath)) {
        // Load existing database
        const fileBuffer = fs.readFileSync(this.dbPath);
        // Convert Uint8Array to ArrayBuffer for sql.js
        this.db = new SQL.Database(fileBuffer.buffer.slice(fileBuffer.byteOffset, fileBuffer.byteOffset + fileBuffer.byteLength));
      } else {
        // Create new database
        this.db = new SQL.Database();
        await this.createSchema();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      (this.db as Database).run(schema);
      await this.save();
    } catch (error) {
      console.error('Failed to create schema:', error);
      throw error;
    }
  }

  async save(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const data = (this.db as Database).export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  async insertSubmission(data: FormData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

  try {
      const stmt = (this.db as Database).prepare(
        'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime("now"))'
      );
      stmt.run([
        data.firstName,
        data.lastName,
        data.streetAddress,
        data.city,
        data.stateProvince,
        data.postalCode,
        data.country,
        data.email,
        data.phone,
      ]);

      stmt.free();

      // Get the last inserted row ID
      const result = this.db.exec('SELECT last_insert_rowid() as id');
      const rowId = result[0].values[0][0] as number;

      await this.save();
      return rowId;
    } catch (error) {
      console.error('Failed to insert submission:', error);
      throw error;
    }
  }

  async getSubmissions(): Promise<FormSubmission[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const result = (this.db as Database).exec('SELECT * FROM submissions ORDER BY created_at DESC');
      
      if (result.length === 0) {
        return [];
      }

      const submissions: FormSubmission[] = result[0].values.map((row: unknown[]) => ({
        id: row[0] as number,
        firstName: row[1] as string,
        lastName: row[2] as string,
        streetAddress: row[3] as string,
        city: row[4] as string,
        stateProvince: row[5] as string,
        postalCode: row[6] as string,
        country: row[7] as string,
        email: row[8] as string,
        phone: row[9] as string,
        createdAt: row[10] as string,
      }));

      return submissions;
    } catch (error) {
      console.error('Failed to get submissions:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      (this.db as Database).close();
      this.db = null;
    }
  }
}