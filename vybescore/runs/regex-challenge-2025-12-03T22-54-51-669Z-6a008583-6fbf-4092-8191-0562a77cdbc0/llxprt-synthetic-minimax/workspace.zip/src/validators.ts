export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with typical formats like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common separators and optional +1
 * Rejects area codes starting with 0 or 1
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle +1 prefix
  let digits = cleaned;
  if (cleaned.startsWith('+1')) {
    digits = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length === 11) {
    digits = cleaned.substring(1);
  }
  
  // Must have exactly 10 digits for basic US number
  if (digits.length !== 10) return false;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check if original format is reasonable (allowing for separators)
  const phoneRegex = /^(\+1[\s.-]?)?\(?([2-9][0-8][0-9])\)?[\s.-]?([2-9][0-9]{2})[\s.-]?([0-9]{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators and normalize
  const cleaned = value.replace(/[\s.-]/g, '');
  
  // Pattern: optional +54, optional 9 (mobile), area code 2-4 digits (first digit 1-9), then 6-8 total digits
  const argentinePhoneRegex = /^(\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(argentinePhoneRegex);
  
  if (!match) return false;
  
  const [, countryCode, , trunkPrefix, , subscriberNumber] = match;
  
  // If no country code, must have trunk prefix (0)
  if (!countryCode && !trunkPrefix) return false;
  
  // Calculate total length after area code
  const remainingLength = subscriberNumber.length;
  return remainingLength >= 6 && remainingLength <= 8;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects digits, symbols, and unusual formats
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, spaces, hyphens, apostrophes
  // Must start with a letter, cannot contain digits or unusual symbols
  const nameRegex = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  return nameRegex.test(value.trim());
}

/**
 * Validates credit card numbers with Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits
  if (!/^\d{13,19}$/.test(cleaned)) return false;
  
  // Check card type prefixes
  const isVisa = /^4/.test(cleaned) && cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19;
  const isMastercard = /^5[1-5]/.test(cleaned) && cleaned.length === 16 || 
                      /^2(2[2-9]|[3-6]|7[01]|720)/.test(cleaned) && cleaned.length === 16;
  const isAmEx = /^3[47]/.test(cleaned) && cleaned.length === 15;
  
  if (!isVisa && !isMastercard && !isAmEx) return false;
  
  // Luhn checksum
  return runLuhnCheck(cleaned);
}

function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}