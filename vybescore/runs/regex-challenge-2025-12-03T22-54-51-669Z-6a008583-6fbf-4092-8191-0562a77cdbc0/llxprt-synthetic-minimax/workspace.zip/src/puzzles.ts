/**
 * Matches words starting with the prefix but excluding banned words
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const regex = new RegExp(`\\b${prefix}\\w*`, 'g');
  const matches = text.match(regex) || [];
  
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where the token is immediately preceded by a digit
  const regex = new RegExp(`\\d${token}`, 'g');
  return text.match(regex) || [];
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (like abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check length
  if (value.length < 10) return false;
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"|,.<>?]/.test(value);
  const hasNoWhitespace = !/\s/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol || !hasNoWhitespace) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, xyxy, etc.)
  const repeatedSequenceRegex = /(\w{2,})\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses
 */
export function containsIPv6(value: string): boolean {
  // Check for IPv4 patterns first - if found, return false
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // IPv6 patterns
  // Standard IPv6: groups of hex digits separated by colons
  const standardIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand (multiple possible positions)
  const shorthandIPv6 = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with leading/trailing ::
  const leadingTrailingIPv6 = /\b::(?::[0-9a-fA-F]{1,4})+\b/;
  
  // IPv4-mapped IPv6
  const ipv4MappedIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  return standardIPv6.test(value) || shorthandIPv6.test(value) || 
         leadingTrailingIPv6.test(value) || ipv4MappedIPv6.test(value);
}