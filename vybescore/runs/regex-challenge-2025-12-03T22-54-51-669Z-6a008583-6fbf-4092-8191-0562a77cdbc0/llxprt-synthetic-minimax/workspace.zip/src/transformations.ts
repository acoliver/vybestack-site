/**
 * Capitalizes the first character of each sentence, preserving spacing rules
 * Inserts exactly one space between sentences, collapses extra spaces
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence endings
  text = text.replace(/\s*([.!?])\s*/g, '$1 ');
  
  // Split sentences and capitalize each one
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  return sentences.map(sentence => {
    // Trim and capitalize first letter if it exists
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return '';
    return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
  }).filter(s => s.length > 0).join(' ');
}

/**
 * Finds URLs in the text. Returns an array of matched URL strings.
 * Removes trailing punctuation from URLs.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/[^\s]+/g;
  const urls = text.match(urlRegex) || [];
  
  return urls.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;:!?)]*$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to docs.example.com
 * Skip host rewrite for dynamic hints or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/([^/]+)(\/docs\/[^\s]*)/g, (match, host, path) => {
    // Skip if path contains dynamic hints or legacy extensions
    if (/cgi-bin|\?|&=|\.(jsp|php|asp|aspx|do|cgi|pl|py)\b/i.test(path)) {
      return 'https://' + host + path;
    }
    
    // Replace host with docs.hostname for docs paths
    const parts = host.split('.');
    if (parts.length >= 2) {
      const newHost = 'docs.' + parts.slice(-2).join('.');
      return 'https://' + newHost + path;
    }
    
    return 'https://' + host + path;
  }).replace(/http:\/\//g, 'https://');
}

/**
 * Extracts four-digit year from mm/dd/yyyy format
 * Returns 'N/A' if format invalid or month/day are invalid
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (1-12) and day (1-31, basic validation)
  if (monthNum < 1 || monthNum > 12 || dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  // Basic leap year check for February
  if (monthNum === 2 && dayNum > 29) {
    return 'N/A';
  }
  
  return year;
}