/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: new Set(),
  }
  updateObserver(o)
  
  const read = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // When this computed is accessed within another observer,
      // register this computed's subjects with that observer
      for (const subject of o.subjects!) {
        subject.observers!.add(observer)
        if (observer.subjects) observer.subjects.add(subject)
        else (observer as { subjects?: Set<typeof subject> }).subjects = new Set([subject])
      }
    }
    return o.value!
  }
  
  return read
}
