export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // More practical email validation with required restrictions
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots, trailing dots, and leading dots
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Domain should not contain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Local part should not end with dot
  const localPart = value.split('@')[0];
  if (localPart && localPart.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length
  if (digits.length < 10) {
    return false;
  }
  
  // Handle +1 country code
  let phoneDigits = digits;
  if (digits.length === 11 && digits.startsWith('1')) {
    phoneDigits = digits.slice(1);
  } else if (digits.length > 11) {
    return false;
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneDigits.length !== 10) {
    return false;
  }
  
  // Check area code - cannot start with 0 or 1
  const areaCode = phoneDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Remove all spaces and hyphens for validation
  const cleanPhone = value.replace(/[\s-]/g, '');
  
  // Pattern: [+54] [9] 0 areaCode subscriber
  // Where:
  // - +54: optional country code
  // - 9: optional mobile indicator (between country code and area code)
  // - 0: optional trunk prefix (but required if no country code)
  // - areaCode: 2-4 digits, leading digit 1-9
  // - subscriber: 6-8 digits
  
  let pattern: RegExp;
  
  if (cleanPhone.startsWith('+54')) {
    // With country code: +54[9]XX[areaCode][subscriber]
    pattern = /^\+54(?:9)?(\d{2,4})(\d{6,8})$/;
  } else if (cleanPhone.startsWith('0')) {
    // Without country code: 0[areaCode][subscriber]
    pattern = /^0(\d{2,4})(\d{6,8})$/;
  } else {
    // Invalid format - must start with +54 or 0
    return false;
  }
  
  const match = cleanPhone.match(pattern);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriber = match[2];
  
  // Area code must be 2-4 digits and not start with 0
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and invalid combinations like X Æ A-12
  const nameRegex = /^[\p{L}\p{M}'-]+(?:\s[\p{L}\p{M}'-]+)*$/u;
  
  if (!nameRegex.test(value.trim())) {
    return false;
  }
  
  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }
  
// Check for multiple consecutive special characters
  if (["'''", "--", '   '].some(pattern => value.includes(pattern))) {
    return false;
  }
  
  // Reject obviously invalid combinations like X Æ A-12
  if (/^[A-Z]\s*Æ\s*[A-Z]-\d+$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanCard = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanCard)) {
    return false;
  }
  
  // Check length (13-19 digits for major cards)
  if (cleanCard.length < 13 || cleanCard.length > 19) {
    return false;
  }
  
  // Check card prefixes for Visa, Mastercard, and AmEx
  const visaRegex = /^4\d{12}(?:\d{3})?$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  if (!visaRegex.test(cleanCard) && 
      !mastercardRegex.test(cleanCard) && 
      !amexRegex.test(cleanCard)) {
    return false;
  }
  
  // Luhn algorithm check
  return runLuhnCheck(cleanCard);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled -= 9;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}