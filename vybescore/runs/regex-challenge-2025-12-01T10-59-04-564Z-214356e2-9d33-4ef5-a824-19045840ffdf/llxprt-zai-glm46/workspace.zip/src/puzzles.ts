/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Escape the prefix for regex and create word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with the prefix
  // \b ensures word boundary, \w+ matches the rest of the word
  const prefixedWordRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  // Find all matches
  const matches = text.match(prefixedWordRegex) || [];
  
  // Filter out exceptions and return unique matches
  const result = matches.filter(word => {
    return !exceptions.includes(word.toLowerCase());
  });
  
  // Remove duplicates
  return [...new Set(result)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex that matches the full word containing the token that's preceded by a digit
  // Word boundaries ensure we get complete words
  const embeddedTokenRegex = new RegExp(`\\b\\d+${escapedToken}\\b`, 'g');
  
  // Find all matches
  return text.match(embeddedTokenRegex) || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // Minimum 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
// At least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab)
  // Check for patterns where a sequence of 2+ characters is repeated immediately
  const repeatedPatternRegex = /(.{2,})\1/;
  if (repeatedPatternRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // IPv6 regex patterns (excluding IPv4 addresses)
  
  // Standard IPv6 format: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  const ipv6Pattern = /(?:^|(?<!\d))(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?!\d)/;
  
  // IPv6 with :: (shorthand) - various combinations
  const ipv6ShorthandPattern = /(?:^|(?<!\d))(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}(?!\d)/;
  
  // IPv6 with leading/trailing ::
  const ipv6DoubleColonPattern = /(?:^|(?<!\d))::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}(?!\d)|(?:^|(?<!\d))[0-9a-fA-F]{1,4}:?(?:[0-9a-fA-F]{1,4}:){0,6}::(?!\d)/;
  
  // IPv6 with IPv4 embedded (but not standalone IPv4)
  const ipv6WithIPv4Pattern = /(?:^|(?<!\d))(?:[0-9a-fA-F]{1,4}:){6}:(?:\d{1,3}\.){3}\d{1,3}(?!\d)/;
  
  // Check for IPv6 patterns while ensuring we don't match standalone IPv4
  if (ipv6Pattern.test(value) || 
      ipv6ShorthandPattern.test(value) || 
      ipv6DoubleColonPattern.test(value) || 
      ipv6WithIPv4Pattern.test(value)) {
    
    // Ensure we're not matching a standalone IPv4 address
    // IPv4 pattern to exclude
    const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    
    // If the entire value is a valid IPv4, return false
    if (ipv4Pattern.test(value.trim())) {
      return false;
    }
    
    return true;
  }
  
  return false;
}