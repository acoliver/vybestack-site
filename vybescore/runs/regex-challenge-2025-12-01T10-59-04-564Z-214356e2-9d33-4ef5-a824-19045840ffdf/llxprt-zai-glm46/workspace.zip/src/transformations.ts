/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // First, normalize spacing around sentence endings
  // Replace .!? followed by optional spaces with .!? and ensure exactly one space
  let normalized = text.replace(/([.!?])\s*/g, '$1 ');
  
  // Replace multiple spaces with single space
  normalized = normalized.replace(/\s+/g, ' ');
  
  // Trim leading and trailing whitespace
  normalized = normalized.trim();
  
  // Capitalize first character of each sentence
  // Split by sentence endings, then process each part
  return normalized.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  // URL regex pattern that captures http/https URLs
  // Matches scheme://domain/path with various formats
  const urlRegex = /\b(?:https?:\/\/)?(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(?:[/?#][^\s]*)?\b/g;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Filter and clean URLs - remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation like .,!?;:) etc.
    return url.replace(/[.,!?;:)\]]+$/g, '');
  }).filter((url, index, arr) => {
    // Remove duplicates and ensure it's a valid URL
    return arr.indexOf(url) === index && 
           (url.includes('http://') || url.includes('https://') || 
            url.includes('www.') || /\.[a-zA-Z]{2,}/.test(url));
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Replace http:// with https://, but leave existing https:// URLs untouched
  // Using negative lookahead to avoid replacing https://
  return text.replace(/http:\/\/(?!s)/g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // First upgrade all http:// to https://
  const httpsUpgraded = text.replace(/http:\/\//g, 'https://');
  
  // Rewrite docs URLs: https://example.com/docs/... -> https://docs.example.com/...
  // But skip dynamic paths with cgi-bin, query strings, or legacy extensions
  return httpsUpgraded.replace(
    /https:\/\/(?:www\.)?([a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+)(\/docs\/)(?!(?:.*(?:\?|&|=|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)))([^\s]*)/g,
    (match, domain, docsPath, restPath) => {
      return `https://docs.${domain}${docsPath}${restPath}`;
    }
  );
}

/**
 * TODO: Extract the year from a date string in mm/dd/yyyy format.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month/day combinations
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  const maxDays = month === 2 && isLeapYear(year) ? 29 : daysInMonth[month];
  
  if (day > maxDays) {
    return 'N/A';
  }
  
  return year;
}