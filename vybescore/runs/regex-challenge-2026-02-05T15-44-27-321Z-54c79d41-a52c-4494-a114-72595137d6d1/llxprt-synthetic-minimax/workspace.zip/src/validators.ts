export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject obviously invalid forms first
  if (value.includes('..') || value.endsWith('.')) {
    return false;
  }
  
  // Allow multiple @ symbols but validate structure
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?(@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])+)*@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])+(\.[a-zA-Z]{2,})+$/;
  
  // Basic regex validation
  if (!emailRegex.test(value)) return false;
  
  // Check final domain doesn't contain underscores  
  const lastAtIndex = value.lastIndexOf('@');
  const domain = value.substring(lastAtIndex + 1);
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _ = _options; // intentionally unused
  // options parameter intentionally unused for now
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for minimum length (10 digits for US number)
  if (digitsOnly.length < 10) return false;
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (digitsOnly.startsWith('1') && digitsOnly.length === 11) {
    phoneNumber = digitsOnly.substring(1);
  } else if (digitsOnly.startsWith('1')) {
    return false; // Starts with 1 but not 11 digits total
  }
  
  // Must be exactly 10 digits after optional country code removal
  if (phoneNumber.length !== 10) return false;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check if format matches common US phone patterns (both formatted and unformatted)
  const formattedRegex = /^\(?([2-9][0-8][0-9])\)?[-. ]?([2-9][0-9]{2})[-. ]?([0-9]{4})$/;
  const unformattedRegex = /^([2-9][0-8][0-9])([2-9][0-9]{2})([0-9]{4})$/;
  
  const formattedMatch = formattedRegex.exec(value);
  const unformattedMatch = unformattedRegex.exec(phoneNumber);
  
  return formattedMatch !== null || unformattedMatch !== null;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Pattern that handles both spaced and continuous subscriber numbers
  // Required parts: optional country code (+54), optional mobile indicator (9), 
  // optional trunk prefix (0), area code (2-4 digits), subscriber number (6-8 digits total)
  const phoneRegex = /^(\+54\s*)?(9\s*)?(0\s*)?([1-9]\d{1,3}\s*)(\d{6,8})$/;
  const match = phoneRegex.exec(value.replace(/[-\s]/g, ''));
  
  if (!match) return false;
  
  // Additional validation: check the structure
  const [, countryCode, , trunkPrefix, areaCode, subscriberNumber] = match;
  
  // Total number validation: when no country code, must have trunk prefix 0
  if (!countryCode && !trunkPrefix) return false;
  
  // Area code should be 2-4 digits starting with 1-9
  const cleanAreaCode = areaCode.replace(/\s/g, '');
  if (!/^[1-9]\d{1,3}$/.test(cleanAreaCode)) return false;
  
  // Subscriber number validation: 6-8 digits
  const cleanSubscriber = subscriberNumber.replace(/\s/g, '');
  if (!/^\d{6,8}$/.test(cleanSubscriber)) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not contain digits
  if (/\d/.test(value)) return false;
  
  // Must not contain obvious fake patterns like Æ symbols
  if (/[Ææ]/.test(value)) return false;
  
  // Pattern breakdown:
  // - Unicode letters (allowing accents) at start and end
  // - Allow apostrophes, hyphens, spaces in the middle
  // - Reject symbols like @, #, $, %, etc.
  const nameRegex = /^\p{L}[\p{L}'\-\s]*\p{L}$/u;
  
  // Additional validation: ensure it doesn't contain obvious symbols
  const invalidSymbols = /[@#$%^*+=<>{}[\]\\|`~]/;
  if (invalidSymbols.test(value)) return false;
  
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Helper function for Luhn checksum
  const runLuhnCheck = (cardNumber: string): boolean => {
    const digits = cardNumber.replace(/\D/g, '');
    let sum = 0;
    let isEven = false;
    
    for (let i = digits.length - 1; i >= 0; i--) {
      let digit = parseInt(digits[i], 10);
      
      if (isEven) {
        digit *= 2;
        if (digit > 9) {
          digit -= 9;
        }
      }
      
      sum += digit;
      isEven = !isEven;
    }
    
    return sum % 10 === 0;
  };
  
  const digitsOnly = value.replace(/\D/g, '');
  
  // Visa: 16 digits starting with 4
  const visaRegex = /^4\d{15}$/;
  if (visaRegex.test(digitsOnly)) {
    return runLuhnCheck(digitsOnly);
  }
  
  // Mastercard: 16 digits starting with 51-55 or 2221-2720
  const mastercardRegex = /^((5[1-5]\d{13})|(222[1-9]\d{11}|223[0-9]\d{10}|2[4-6]\d{13}|27[01]\d{12}|2720\d{11}))(\d{0,2})$/;
  if (mastercardRegex.test(digitsOnly)) {
    return runLuhnCheck(digitsOnly);
  }
  
  // American Express: 15 digits starting with 34 or 37
  const amexRegex = /^(3[47]\d{13})$/;
  if (amexRegex.test(digitsOnly)) {
    return runLuhnCheck(digitsOnly);
  }
  
  return false;
}
