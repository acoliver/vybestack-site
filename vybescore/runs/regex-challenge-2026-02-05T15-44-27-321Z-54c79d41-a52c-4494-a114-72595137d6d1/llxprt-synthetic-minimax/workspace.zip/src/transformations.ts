/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First normalize multiple spaces to single space and ensure single space after punctuation
  const result = text.replace(/\s+/g, ' ');
  
  // Pattern: punctuation followed by space and lowercase letter
  // This captures .!? followed by optional spaces and a lowercase letter
  const sentencePattern = /([.!?])(\s*)([a-z])/g;
  
  let transformed = result.replace(sentencePattern, (match, punctuation, spaces, letter) => {
    return punctuation + (spaces ? spaces : ' ') + letter.toUpperCase();
  });
  
  // Also capitalize the first letter of the first sentence if it's lowercase
  const firstLetterPattern = /^([a-z])/;
  if (firstLetterPattern.test(transformed)) {
    transformed = transformed.replace(firstLetterPattern, (match, letter) => letter.toUpperCase());
  }
  
  return transformed;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs with common schemes
  // Matches http://, https://, ftp://, etc. followed by domain/path
  // Remove trailing punctuation like .,!? when extracting
  const urlPattern = /\b(https?|ftp):\/\/[^\s<>"']+[^\s<>"'.,!?)]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up URLs by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that commonly follows URLs
    return url.replace(/[.,!?]+$/, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Pattern to match http:// URLs (not https://)
  const httpPattern = /http:\/\/[^\s<>"']+/gi;
  
  return text.replace(httpPattern, (match) => {
    // Replace http:// with https://
    return match.replace(/^http:\/\//, 'https://');
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const httpUrlPattern = /http:\/\/([^/\s<>"']+)([^<>"'\s]*)/gi;
  
  return text.replace(httpUrlPattern, (match, host, path) => {
    // Check if path contains dynamic hints that prevent host rewrite
    const hasDynamicHints = /(\?|&|=)|(\.(cgi|pl|py|php|asp|aspx|jsp|do))|cgi-bin/i.test(path);
    
    // Always upgrade scheme to https://
    const newUrl = 'https://';
    
    let resultHost = host;
    const resultPath = path;
    
    // If path begins with /docs/ and no dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      resultHost = 'docs.' + host;
    }
    
    return newUrl + resultHost + resultPath;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day (01-31) - basic check
  if (day < 1 || day > 31) return 'N/A';
  
  // Additional validation for days in month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) return 'N/A';
  
  // Validate year is reasonable (e.g., not 0000)
  const year = parseInt(yearStr, 10);
  if (year < 1000 || year > 9999) return 'N/A';
  
  return yearStr;
}
