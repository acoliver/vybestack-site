/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words starting with the prefix (case-insensitive)
  const prefixedRegex = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(prefixedRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  const filteredMatches = matches.filter(word => 
    !exceptionsSet.has(word.toLowerCase())
  );
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to match token that appears after a digit (include the digit in the match)
  // Use negative lookbehind to ensure it's not at the start of string
  // Use positive lookbehind to require a digit before the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const embeddedRegex = new RegExp(`(?<!^)\\d${escapedToken}`, 'gi');
  
  const matches = text.match(embeddedRegex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length requirement
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for digit
  if (!/\d/.test(value)) return false;
  
  // Check for symbol
  if (!/[!@#$%^&*()_+\-={}[\];':"\\|,.<>?]/.test(value)) return false;
  
  // Check for immediate repeated sequences like "abab", "12 12" etc.
  // Look for patterns of 2+ characters repeated immediately
  for (let i = 0; i < value.length - 3; i++) {
    const sequence = value.substring(i, i + 2);
    if (value.substring(i + 2, i + 4) === sequence) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern to match IPv6 addresses including shorthand like ::
  // This pattern covers standard IPv6 formats and shorthand notation
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b|\b::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/;
  
  // Ensure it's not just detecting IPv4 patterns
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If it contains IPv4 pattern, don't consider it IPv6
  if (ipv4Pattern.test(value)) return false;
  
  return ipv6Pattern.test(value);
}
