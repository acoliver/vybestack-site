/**
 * Capitalize the first character of each sentence.
 * Handles sentence boundaries (.?!) and ensures exactly one space between sentences.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Replace multiple whitespace with single space
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Ensure exactly one space after sentence end marks (.?!), handling cases where spaces are missing
  result = result.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Define common abbreviations that don't end sentences
  // This is a conservative list to preserve readability
  const abbreviations = ['Mr.', 'Mrs.', 'Ms.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'St.', 'Mt.', 'Ave.', 'Blvd.', 'Rd.', 'i.e.', 'e.g.', 'etc.', 'vs.', 'U.S.', 'U.K.', 'N.Y.', 'L.A.', 'P.M.', 'A.M.'];
  
// Create regex pattern to match these abbreviations for negative lookahead
  const abbrPattern = abbreviations.map(abbr => abbr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  const abbrRegex = abbrPattern ? new RegExp(`\\b(?:${abbrPattern})`, '') : null;
  
  // Process to capitalize each sentence
  let processedText = '';
  let atSentenceStart = true;
  
  for (let i = 0; i < result.length; i++) {
    const currentChar = result[i];
    
    if (atSentenceStart && /[a-z]/.test(currentChar)) {
      processedText += currentChar.toUpperCase();
      atSentenceStart = false;
    } else {
      processedText += currentChar;
    }
    
    // Check if this is a sentence boundary (.?!)
    if (['.', '!', '?'].includes(currentChar)) {
      // Check if this might be an abbreviation
      if (abbrRegex) {
        // Look back to check if this is part of a known abbreviation
        const lookback = result.substring(Math.max(0, i - 8), i + 2);
        if (!abbrRegex.test(lookback)) {
          atSentenceStart = true;
        }
      } else {
        atSentenceStart = true;
      }
    } else if (!/[ \t\n\r]/.test(currentChar)) {
      atSentenceStart = false;
    }
  }
  
  // Clean up extra spaces around punctuation
  processedText = processedText.replace(/\s+([.!?])/g, '$1');
  processedText = processedText.replace(/([.!?])\s+/g, '$1 ');
  
  // Ensure first character is capitalized
  if (processedText && /[a-z]/.test(processedText[0])) {
    processedText = processedText[0].toUpperCase() + processedText.substring(1);
  }
  
  return processedText;
}

/**
 * Extract URLs from text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern - matches http/https protocols, domain names, and various common TLDs
  // Use negative lookbehind to avoid matching punctuation at the end
  const urlRegex = /(https?:\/\/(?:(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}|(?:\d{1,3}\.){3}\d{1,3})(?::\d+)?(?:\/[^\s\])}\.,;:"'<>]*)?)\b(?![\])}\.,;:"'])/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up each match to remove trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that might have been included
    return url.replace(/[,.!?;:"'\])}>]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 * Replaces http:// with https:// in all URLs.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Only replace http:// when it's part of a valid URL
  // Use negative lookbehind to ensure we're not matching within a URL
  // This pattern matches http:// followed by a valid domain/path
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs according to rules:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip the host rewrite when path contains dynamic hints like cgi-bin, query strings (?), or legacy extensions
 * - Preserve nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Match http://example.com URLs along with their paths
  return text.replace(
    /(http:\/\/example\.com)(\/[^\s]*)?/gi,
    (match, protocolHost, path = '') => {
      let newHost = 'https://example.com';
      
      if (path) {
        // Check if the path begins with /docs/
        if (path.startsWith('/docs/')) {
          // Check for dynamic hints that should prevent host rewrite
          const hasDynamicHints = /[?&=]/.test(path) ||
            /\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path) ||
            path.includes('cgi-bin');
          
          if (!hasDynamicHints) {
            newHost = 'https://docs.example.com';
          } else {
            // Still upgrade scheme to https but keep original host
            newHost = 'https://example.com';
          }
        }
      }
      
      return newHost + path;
    }
  );
}

/**
 * Extract the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format (strict)
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const [, monthStr, dayStr, yearStr] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) return 'N/A';
  
  // Check for valid day-month combinations
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  if (month === 2 && day === 29) {
    // Leap year check: divisible by 4, but not by 100 unless also divisible by 400
    if ((year % 4 !== 0) || (year % 100 === 0 && year % 400 !== 0)) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return yearStr;
}
