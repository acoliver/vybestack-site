export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses according to common standards.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Basic format check
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Validate the local part (before @)
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) return false;
  
  // Local part should not start or end with a dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Should not contain consecutive dots
  if (localPart.includes('..')) return false;
  
  // Domain should not contain underscores
  if (domain.includes('_')) return false;
  
  // Domain should not start or end with a dot or hyphen
  if (domain.startsWith('.') || domain.startsWith('-') || 
      domain.endsWith('.') || domain.endsWith('-')) return false;
  
  // Domain should not have consecutive dots
  if (domain.includes('..')) return false;
  
  // Check if at least one dot in domain (except for localhost-like domains)
  if (!domain.includes('.') || domain.split('.').some(part => part === '')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers with common formats and optional +1 country code.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Strip all whitespace and common separators to get just the digits
  const digits = value.replace(/[\s\-\(\)]/g, '');
  
  // Check if we have at least 10 digits
  if (digits.length < 10) return false;
  
  // Remove optional +1 country code if present
  let phoneNumber = digits;
  if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Now we should have exactly 10 digits
  if (phoneNumber.length !== 10) return false;
  
  // Check area code (first 3 digits) doesn't start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Optional extension handling
  if (options?.allowExtensions) {
    const extensionRegex = /^[\d\s\-\(\)]+(\s*ext\.?\s*|\s*x\s*)\d+$/;
    if (extensionRegex.test(value)) {
      // Check the main part of the number
      const mainNumber = value.split(/\s*(?:ext\.?|x)\s*/)[0].trim();
      return isValidUSPhone(mainNumber, { allowExtensions: false });
    }
  }
  
  // Basic format validation
  const phoneRegex = /^\+?1?[\s\-\(\)]*\d{3}[\s\-\)\(]*\d{3}[\s\-\(\)]*\d{4}$/;
  if (!phoneRegex.test(value)) return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers for both landlines and mobiles.
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54.
 * - Optional trunk prefix 0 immediately before the area code.
 * - Optional mobile indicator 9 between country/trunk and the area code.
 * - Area code must be 2–4 digits (leading digit 1–9).
 * - Subscriber number (after the area code) must contain 6–8 digits in total.
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code.
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove whitespace and hyphens to get clean digits for validation
  const digits = value.replace(/[\s\-]/g, '');
  
  // Try to extract country code, mobile indicator, area code and subscriber number
  let hasCountryCode = false;
  let isMobile = false;
  let areaCode = '';
  let subscriberNumber = '';
  
  // Check if starts with country code +54
  if (digits.startsWith('54')) {
    hasCountryCode = true;
    let remaining = digits.substring(2); // Remove '54'
    
    // Check for mobile indicator '9'
    if (remaining.startsWith('9')) {
      isMobile = true;
      remaining = remaining.substring(1); // Remove '9'
    }
    
    // Extract area code (2-4 digits, doesn't start with 0)
    for (let len = 4; len >= 2; len--) {
      const potentialAreaCode = remaining.substring(0, len);
      if (/^[1-9]\d{1,3}$/.test(potentialAreaCode)) {
        areaCode = potentialAreaCode;
        subscriberNumber = remaining.substring(len);
        break;
      }
    }
  } 
  // If no country code, must start with trunk prefix 0
  else if (digits.startsWith('0')) {
    let remaining = digits.substring(1); // Remove '0'
    
    // Check for mobile indicator '9'
    if (remaining.startsWith('9')) {
      isMobile = true;
      remaining = remaining.substring(1); // Remove '9'
    }
    
    // Extract area code (2-4 digits, doesn't start with 0)
    for (let len = 4; len >= 2; len--) {
      const potentialAreaCode = remaining.substring(0, len);
      if (/^[1-9]\d{1,3}$/.test(potentialAreaCode)) {
        areaCode = potentialAreaCode;
        subscriberNumber = remaining.substring(len);
        break;
      }
    }
  }
  
  // If we couldn't extract valid components, return false
  if (!areaCode || !subscriberNumber) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Check if all characters are digits
  if (!/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  // Format validation with separators
  // Examples: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  let formattedRegex;
  if (hasCountryCode) {
    if (isMobile) {
      formattedRegex = /^\+54[\s\-]?9[\s\-]?\d{2,4}[\s\-]?\d{3,4}[\s\-]?\d{4}$/;
    } else {
      formattedRegex = /^\+54[\s\-]?\d{2,4}[\s\-]?\d{3,4}[\s\-]?\d{4}$/;
    }
  } else {
    if (isMobile) {
      formattedRegex = /^09[\s\-]?\d{2,4}[\s\-]?\d{3,4}[\s\-]?\d{4}$/;
    } else {
      formattedRegex = /^0\d{2,4}[\s\-]?\d{3,4}[\s\-]?\d{4}$/;
    }
  }
  
  return formattedRegex.test(value);
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and bizarre "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace from both ends
  const trimmed = value.trim();
  
  // Name should not be empty
  if (trimmed.length === 0) return false;
  
  // Don't allow pure symbols or special characters
  if (!/[a-zA-Z\u00C0-\u024F\u0400-\u04FF]/.test(trimmed)) return false;
  
  // Allow Unicode letters, accents, apostrophes, hyphens, and spaces
  // First character should be a letter (not apostrophe or hyphen)
  const nameRegex = /^[a-zA-Z\u00C0-\u024F\u0400-\u04FF][a-zA-Z\u00C0-\u024F\u0400-\u04FF\s'\-]*$/;
  
  if (!nameRegex.test(trimmed)) return false;
  
  if (trimmed.includes('--') || trimmed.includes("''")) return false;
  
  // Don't allow sequences of spaces
  if (/ {2,}/.test(trimmed)) return false;
  
  // Don't allow names with only special characters
  if (/^['\-]+$/.test(trimmed)) return false;
  
  // Check for balanced apostrophes/hyphens (reasonable but not strict)
  const apostrophes = (trimmed.match(/'/g) || []).length;
  const hyphens = (trimmed.match(/-/g) || []).length;
  
  // Reasonable limits for apostrophes/hyphens
  if (apostrophes > 2 || hyphens > 3) return false;
  
  // Reject names that look like codes (contain digits and special characters like X Æ A-12)
  if (/\d/.test(trimmed)) return false;
  
  return true;
}

/**
 * Helper function for Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process from rightmost digit to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit = digit % 10 + 1;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx) using prefixes, lengths, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must contain only digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Visa: Starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  if (visaRegex.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  // Mastercard: Starts with 2221-2720 or 51-55, length 16
  const mastercardRegex = /^((2221\d{12})|(2[3-6]\d{14})|(27[0-1]\d{13})|(2720\d{12})|(5[1-5]\d{14}))$/;
  if (mastercardRegex.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  // AmEx: Starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  return false;
}
