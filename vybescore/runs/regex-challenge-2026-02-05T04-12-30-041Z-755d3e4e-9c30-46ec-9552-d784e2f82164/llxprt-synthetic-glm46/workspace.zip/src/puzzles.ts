/**
 * Find words beginning with the prefix but excluding the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all words that start with the given prefix
  const prefixedWordsRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z'À-ž]*`, 'gi');
  const matches = text.match(prefixedWordsRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  return matches.filter(word => !exceptionsSet.has(word.toLowerCase()));
}

/**
 * Find occurrences of a token that appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds to ensure the token position.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
// Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token after a digit but not at start of string:
  // (?<!^) - negative lookbehind to ensure not at start
  // (?<=[0-9]) - positive lookbehind to ensure preceded by a digit
  const embeddedTokenRegex = new RegExp(`(?<!^)(?<=[0-9])${escapedToken}`, 'g');
  
  const matches = text.match(embeddedTokenRegex) || [];
  return matches;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., 'abab' should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (!value || value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) return false;
  
  // Check for repeated patterns (like abab, abcabc, etc.)
  // We'll look for patterns of length 2-6 that repeat immediately
  for (let patternLength = 2; patternLength <= 6; patternLength++) {
    for (let i = 0; i <= value.length - (patternLength * 2); i++) {
      const pattern = value.substr(i, patternLength);
      const nextPart = value.substr(i + patternLength, patternLength);
      if (pattern === nextPart) {
        return false;
      }
    }
  }
  
  // Check for sequential characters (like abcdef, 123456)
  // Check for ascending sequences
  for (let i = 0; i <= value.length - 4; i++) {
    let isSequential = true;
    let isDescendingSequential = true;
    
    for (let j = 0; j < 3; j++) {
      const current = value.charCodeAt(i + j);
      const next = value.charCodeAt(i + j + 1);
      
      // Ascending check
      if (next !== current + 1) {
        isSequential = false;
      }
      
      // Descending check
      if (next !== current - 1) {
        isDescendingSequential = false;
      }
      
      // If neither pattern is continuing, break
      if (!isSequential && !isDescendingSequential) {
        break;
      }
    }
    
    if (isSequential || isDescendingSequential) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand like ::) and ensure IPv4 addresses do not trigger positive results.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 address pattern (to exclude these)
  const ipv4Regex = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?:\/\d+)?$/;
  
  // If it looks like IPv4, return false immediately
  if (ipv4Regex.test(value)) return false;
  
  // IPv6 patterns
  // Full notation: 8 groups of 4 hex digits, separated by colons
  const fullIPv6Regex = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // Shorthand notation: :: can replace one or more groups of zeros
  // Can start with: abcd:ef01:: or ::: or ::abcd or abcd::
  const shorthandIPv6Regex = /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}$/;
  
  // IPv4 mapped to IPv6: ::ffff:192.168.0.1
  const ipv4MappedRegex = /^::ffff:(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
  
  // IPv4 compatible IPv6: ::192.168.0.1
  const ipv4CompatibleRegex = /^::(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
  
  // IPv6 with port: [::1]:8080
  const ipv6WithPortRegex = /^\[(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\]:\d+$/;
  
  return fullIPv6Regex.test(value) || 
         shorthandIPv6Regex.test(value) || 
         ipv4MappedRegex.test(value) ||
         ipv4CompatibleRegex.test(value) ||
         ipv6WithPortRegex.test(value);
}
