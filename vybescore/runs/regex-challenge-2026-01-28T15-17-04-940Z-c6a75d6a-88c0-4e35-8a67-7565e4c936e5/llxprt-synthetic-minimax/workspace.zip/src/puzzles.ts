/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words beginning with prefix
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  const filteredMatches = matches.filter(word => {
    const wordLower = word.toLowerCase();
    const prefixLower = prefix.toLowerCase();
    return !exceptions.some(exception => 
      wordLower === exception.toLowerCase() ||
      (wordLower.startsWith(prefixLower) && wordLower.length === prefixLower.length)
    );
  });
  
  // Remove duplicates while preserving order
  const uniqueMatches = [...new Set(filteredMatches)];
  
  return uniqueMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token after digit and not at string start
  // Returns the full context (digit + token)
  const contexts: string[] = [];
  const regex = new RegExp(`\\d${token}`, 'g');
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    // Extract the full context (digit + token)
    contexts.push(match[0]);
  }
  
  return contexts;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern to detect IPv6 addresses including shorthand ::
  // Exclude IPv4 addresses
  
  // First check if it's clearly IPv4 format
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns
  // Standard IPv6: 8 groups of 4 hex digits
  const standardIPv6 = /\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b/;
  
  // IPv6 with shorthand ::
  const shorthandIPv6 = /\b(?:[a-fA-F0-9]{0,4}:){0,7}:[a-fA-F0-9]{0,4}\b/;
  
  // IPv6 with compressed zeros (allow multiple patterns)
  const compressedIPv6 = /\b(?:[a-fA-F0-9]{1,4}:)*::(?:[a-fA-F0-9]{1,4}:)*[a-fA-F0-9]{1,4}\b/;
  
  // IPv6 with leading zeros compressed
  const leadingCompressed = /\b::(?:[a-fA-F0-9]{1,4}:)*[a-fA-F0-9]{1,4}\b/;
  
  // IPv6 with trailing compressed
  const trailingCompressed = /\b(?:[a-fA-F0-9]{1,4}:)*::\b/;
  
  // IPv6 in brackets (for URLs)
  const bracketedIPv6 = /\[(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\]/;
  
  // Check for any of the IPv6 patterns
  if (standardIPv6.test(value) || 
      shorthandIPv6.test(value) || 
      compressedIPv6.test(value) ||
      leadingCompressed.test(value) ||
      trailingCompressed.test(value) ||
      bracketedIPv6.test(value)) {
    return true;
  }
  
  return false;
}
