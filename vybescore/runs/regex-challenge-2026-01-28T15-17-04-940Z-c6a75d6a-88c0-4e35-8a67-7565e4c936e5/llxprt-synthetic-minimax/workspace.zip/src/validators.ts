export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern for typical email addresses
  // Reject double dots, trailing dots, domains with underscores
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional validations for edge cases
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except +
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Optional country code +1
  const phonePattern = /^(?:\+1)?([2-9]\d{2})[.\-\s]?(\d{3})[.\-\s]?(\d{4})$/;
  const match = cleanValue.match(phonePattern);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  
  // Disallow impossible area codes (leading 0/1)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check total length (10 digits without country code, 11 with +1)
  const totalDigits = cleanValue.replace(/\D/g, '').length;
  if (totalDigits < 10 || totalDigits > 11) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit, non-+, non-space, non-hyphen characters
  const cleanValue = value.replace(/[^\d+\-\s]/g, '');
  
  // Pattern for Argentine phone numbers
  // Optional country code +54
  // Optional mobile indicator 9 between country/trunk and area code
  // Optional trunk prefix 0 (but required when country code is omitted)
  // Area code 2-4 digits, leading digit 1-9
  // Subscriber number 6-8 digits total
  
  const patterns = [
    // Mobile with country code: +54 9 11 1234 5678
    /^\+54\s*9\s*(?:[1-9]\d{1,3})\s*(?:\d{3}\s*){1,2}\d{1,4}$/,
    // Mobile without country code but with trunk: 9 11 1234 5678
    /^(?:9\s*)?(?:[1-9]\d{1,3})\s*(?:\d{3}\s*){1,2}\d{1,4}$/,
    // Landline with country code: +54 341 123 4567
    /^\+54\s*(?:[1-9]\d{1,3})\s*(?:\d{3}\s*){1,2}\d{1,4}$/,
    // Landline without country code but with trunk: 0 341 123 4567 or 0341 123 4567
    /^0\s*(?:[1-9]\d{1,3})\s*(?:\d{3}\s*){1,2}\d{1,4}$/
  ];
  
  // Check if any pattern matches
  const isValid = patterns.some(pattern => {
    const match = cleanValue.match(pattern);
    if (!match) return false;
    
    // Extract all digits for validation
    const allDigits = match[0].replace(/\D/g, '');
    
    // Total digits should be 8-13 (country code + mobile indicator + area code + subscriber)
    // Without country code: 8-12 digits (trunk + area code + subscriber)
    if (allDigits.length < 8 || allDigits.length > 13) {
      return false;
    }
    
    return true;
  });
  
  // Additional validation for the trunk prefix requirement
  if (!cleanValue.startsWith('+54')) {
    // When country code is omitted, must start with 0
    if (!cleanValue.trim().startsWith('0')) {
      return false;
    }
  }
  
  return isValid;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern for names with unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const namePattern = /^[\p{L}\p{M}\s'^]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject symbols and special characters
  const symbolPattern = /[^\p{L}\p{M}\s'^]/u;
  if (symbolPattern.test(value)) {
    return false;
  }
  
  // Reject X Æ A-12 style names
  if (value.includes('X') && value.includes('Æ')) {
    return false;
  }
  
  // Reject names that look like license plates (letters + numbers in certain patterns)
  if (/^[A-Z]{2,}\d{2,}$/.test(value.replace(/\s/g, ''))) {
    return false;
  }
  
  // Must be at least 2 characters and not only spaces
  if (value.trim().length < 2) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check card types and their validations
  // Visa: starts with 4, length 13, 16, or 19
  const visaPattern = /^4\d{12}(\d{3})?(\d{3})?$/;
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  // AmEx: starts with 34 or 37, length 15
  const amexPattern = /^(3[47]\d{13})$/;
  
  let isValidType = false;
  let validLength = false;
  
  if (visaPattern.test(cleanValue)) {
    isValidType = true;
    validLength = cleanValue.length === 13 || cleanValue.length === 16 || cleanValue.length === 19;
  } else if (mastercardPattern.test(cleanValue)) {
    isValidType = true;
    validLength = cleanValue.length === 16;
  } else if (amexPattern.test(cleanValue)) {
    isValidType = true;
    validLength = cleanValue.length === 15;
  }
  
  if (!isValidType || !validLength) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}
