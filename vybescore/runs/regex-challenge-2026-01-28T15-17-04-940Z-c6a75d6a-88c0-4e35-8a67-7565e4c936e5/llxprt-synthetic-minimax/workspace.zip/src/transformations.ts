/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to match sentence endings (.?!)
  const sentenceEndPattern = /([.?!])(\s*)([a-z])/g;
  
  // Replace sentence endings with uppercase first letter and normalize spacing
  const result = text
    // First, collapse multiple spaces
    .replace(/\s+/g, ' ')
    // Then capitalize first letter after sentence endings
    .replace(sentenceEndPattern, (match, punctuation, spaces, letter) => {
      return punctuation + spaces + letter.toUpperCase();
    })
    // Capitalize the very first letter if it starts with a lowercase
    .replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs without trailing punctuation
  const urlPattern = /https?:\/\/[^\s<>"')]+[^\s<>"'),.!?;:]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove any trailing punctuation that might have been captured
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?;:]+$/g, '');
  });
  
  return cleanUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave existing https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs with capture groups
  const httpUrlPattern = /http:\/\/([^/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(httpUrlPattern, (match, host, path) => {
    // Always upgrade to https
    let newUrl = `https://${host}`;
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /(\?.*$|cgi-bin|&.*$|=|jsp$|php$|asp$|aspx$|do$|cgi$|pl$|py$)/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        const pathPart = path.substring(1); // Remove leading slash
        newUrl = `https://docs.example.com/${pathPart}`;
      } else {
        // Just upgrade the scheme, keep original host
        newUrl = `https://${host}${path}`;
      }
    } else {
      // Path doesn't begin with /docs/, just upgrade the scheme
      newUrl = `https://${host}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Basic validation for month and day
  if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
    return year;
  }
  
  return 'N/A';
}
