/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value: value as T,
    updateFn,
  }
  
  // Create subject so callbacks can be tracked as dependents
  const subject: Subject<T> = {
    name: undefined,
    value: value as T,
    equalFn: undefined,
    dependents: new Set(),
  }
  
  let disposed = false
  
  // Function to execute callback with proper dependency tracking
  const executeCallback = (): T => {
    if (disposed) return undefined as T
    // Set this observer as active so it can register as dependent when inputs are read
    const previous = getActiveObserver()
    setActiveObserver(observer as any)
    
    try {
      const result = observer.updateFn(observer.value)
      observer.value = result
      subject.value = result
      return result
    } finally {
      setActiveObserver(previous)
    }
  }
  
  // Store callback for notifications
  observer.read = executeCallback
  
  // Initial execution to set up dependencies
  executeCallback()
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear dependencies to stop further updates
    subject.dependents.clear()
  }
}
