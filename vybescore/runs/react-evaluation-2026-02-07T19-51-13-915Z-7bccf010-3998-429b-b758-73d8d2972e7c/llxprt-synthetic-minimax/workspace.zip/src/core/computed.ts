/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  Subject,
  notifyDependents,
  clearDependencies
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create the observer interface that can be tracked as dependent
  const observer: Observer<T> = {
    name: options?.name,
    value: value as T,
    updateFn,
  }
  
  // Create the subject interface so this computed can have dependents
  const subject: Subject<T> = {
    name: options?.name,
    value: value as T,
    equalFn: undefined,
    dependents: new Set(),
  }
  
  let cachedValue: T | undefined = value as T
  
  // Function to recompute the value and notify dependents
  const recompute = () => {
    const previous = getActiveObserver()
    try {
      // Set this observer as active during recomputation for proper dependency tracking
      setActiveObserver(observer)
      
      // Clear previous dependencies before recomputation
      clearDependencies(subject)
      
      // Execute the update function with undefined to allow default parameters
      const result = observer.updateFn(undefined)
      cachedValue = result
      observer.value = result
      subject.value = result
    } finally {
      setActiveObserver(previous)
    }
    
    // Notify dependents of this computed value after recomputation
    notifyDependents(subject)
    
    return cachedValue!
  }
  
  // Store read function so notifyDependents can call it
  observer.read = recompute
  
  // Create the getter that properly tracks dependencies
  const getter: GetterFn<T> = () => {
    // Always recompute to ensure dependencies are tracked and value is current
    return recompute()
  }
  
  // Initial computation only if no value provided
  if (value === undefined) {
    recompute()
  }
  
  return getter
}
