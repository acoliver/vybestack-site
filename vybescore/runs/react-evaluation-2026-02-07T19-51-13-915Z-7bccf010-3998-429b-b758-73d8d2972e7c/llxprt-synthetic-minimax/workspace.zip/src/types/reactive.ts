/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ComputedNode<T> {
  value: T
  updateFn: UpdateFn<T>
  read: () => T
  dependents: Set<any>
}

export interface InputNode<T> {
  value: T
  read: () => T
  write: (value: T) => T
  dependents: Set<any>
}

export interface CallbackNode<T> {
  value: T
  updateFn: UpdateFn<T>
  read: () => void
}

export type AnyNode = ComputedNode<any> | InputNode<any> | CallbackNode<any>

let activeObserver: AnyNode | undefined

export function getActiveObserver(): AnyNode | undefined {
  return activeObserver
}

export function setActiveObserver(observer: AnyNode | undefined): void {
  activeObserver = observer
}

export function notifyDependents(subject: AnyNode): void {
  for (const dependent of [...subject.dependents]) {
    if (dependent.read) {
      dependent.read()
    }
  }
}

export function clearDependencies(subject: AnyNode): void {
  subject.dependents.clear()
}
