import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';
import { ContactFormData, SubmissionRow } from './types.js';

type SqlJsStatic = import('sql.js').SqlJsStatic;
type Database = import('sql.js').Database;

export class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor(dbPath: string = 'data/submissions.sqlite', schemaPath: string = 'db/schema.sql') {
    this.dbPath = path.resolve(dbPath);
    this.schemaPath = path.resolve(schemaPath);
  }

  async initialize(): Promise<void> {
    if (this.db) {
      // Already initialized
      return;
    }

    // Initialize sql.js with explicit WASM location
    this.sqlJs = await initSqlJs();

    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const dbBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(dbBuffer);
    } else {
      this.db = new this.sqlJs.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    if (!fs.existsSync(this.schemaPath)) {
      throw new Error(`Schema file not found at ${this.schemaPath}`);
    }

    const schemaSql = fs.readFileSync(this.schemaPath, 'utf-8');
    this.db.exec(schemaSql);
  }

  async insertSubmission(formData: ContactFormData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.bind([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.step();
    stmt.free();

    // Get the last insert ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    const id = result[0]?.values[0]?.[0] as number || 0;

    // Save database changes to file
    await this.saveDatabase();

    return id;
  }

  async getAllSubmissions(): Promise<SubmissionRow[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare("SELECT * FROM submissions ORDER BY created_at DESC");
    const submissions: SubmissionRow[] = [];

    while (stmt.step()) {
      const row = stmt.getAsObject() as unknown as SubmissionRow;
      submissions.push(row);
    }

    stmt.free();
    return submissions;
  }

  async saveDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const dbBuffer = this.db.export();
    fs.writeFileSync(this.dbPath, dbBuffer);
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}