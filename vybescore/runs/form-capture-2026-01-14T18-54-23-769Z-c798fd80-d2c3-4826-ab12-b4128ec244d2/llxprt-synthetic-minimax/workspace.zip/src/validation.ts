import { ContactFormData, ValidationError, ValidationResult } from './types.js';

export class ValidationService {
  static validateForm(data: ContactFormData): ValidationResult {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: (keyof ContactFormData)[] = [
      'firstName',
      'lastName',
      'streetAddress',
      'city',
      'stateProvince',
      'postalCode',
      'country',
      'email',
      'phone'
    ];

    for (const field of requiredFields) {
      const value = data[field]?.trim();
      if (!value || value.length === 0) {
        errors.push({
          field,
          message: `${this.getFieldDisplayName(field)} is required`
        });
      }
    }

    // Email validation (if provided and not empty)
    if (data.email?.trim()) {
      const emailRegex = /^[^@]+@[^@]+\.[^@]+$/;
      if (!emailRegex.test(data.email.trim())) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation (if provided and not empty)
    if (data.phone?.trim()) {
      const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
      if (!phoneRegex.test(data.phone.trim())) {
        errors.push({
          field: 'phone',
          message: 'Please enter a valid phone number'
        });
      }
    }

    // Postal code validation (if provided and not empty)
    if (data.postalCode?.trim()) {
      const postalRegex = /^[A-Za-z0-9\s-]{3,12}$/;
      if (!postalRegex.test(data.postalCode.trim())) {
        errors.push({
          field: 'postalCode',
          message: 'Please enter a valid postal code'
        });
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private static getFieldDisplayName(field: keyof ContactFormData): string {
    const fieldNames: Record<string, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State/Province/Region',
      postalCode: 'Postal/Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };

    return fieldNames[field] || field;
  }
}