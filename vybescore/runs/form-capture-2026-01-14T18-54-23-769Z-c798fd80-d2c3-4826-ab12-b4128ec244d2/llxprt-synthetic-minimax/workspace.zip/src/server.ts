import express, { Request, Response } from 'express';
import path from 'path';
import { DatabaseManager } from './database.js';
import { ValidationService } from './validation.js';
import { ContactFormData, TemplateData } from './types.js';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3535;

// Initialize database manager
const dbManager = new DatabaseManager();

// Initialize database immediately when module loads
let dbInitialized = false;

async function initializeDatabase(): Promise<void> {
  if (dbInitialized) {
    return;
  }
  
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');
    dbInitialized = true;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    if (process.argv[1] && process.argv[1].includes('server.ts')) {
      // Only exit if running as main server, not in tests
      process.exit(1);
    }
  }
}

// Ensure database is initialized before handling requests
async function ensureDbInitialized(): Promise<void> {
  if (!dbInitialized) {
    await initializeDatabase();
  }
}

// Configure middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from public directory
app.use(express.static(path.join(process.cwd(), 'public')));

// Configure EJS as view engine
app.set('views', path.join(process.cwd(), 'src', 'views'));
app.set('view engine', 'ejs');

// Graceful shutdown handler
async function gracefulShutdown(signal: string): Promise<void> {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  try {
    // Close database connection
    await dbManager.close();
    console.log('Database closed successfully');
  } catch (error) {
    console.error('Error closing database:', error);
  }
  
  process.exit(0);
}

// Handle graceful shutdown
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Routes

// GET / - Display contact form
app.get('/', async (req: Request, res: Response) => {
  try {
    await ensureDbInitialized();
    
    const templateData: TemplateData = {
      formData: {},
      errors: []
    };
    
    res.status(200).render('form', templateData);
  } catch (error) {
    console.error('Error rendering form:', error);
    res.status(500).send('Internal Server Error');
  }
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  try {
    await ensureDbInitialized();
    
    // Extract form data from request body
    const formData: ContactFormData = {
      firstName: req.body.firstName?.trim() || '',
      lastName: req.body.lastName?.trim() || '',
      streetAddress: req.body.streetAddress?.trim() || '',
      city: req.body.city?.trim() || '',
      stateProvince: req.body.stateProvince?.trim() || '',
      postalCode: req.body.postalCode?.trim() || '',
      country: req.body.country?.trim() || '',
      email: req.body.email?.trim() || '',
      phone: req.body.phone?.trim() || ''
    };

    // Validate form data
    const validationResult = ValidationService.validateForm(formData);

    if (!validationResult.isValid) {
      // Validation failed, re-render form with errors
      const templateData: TemplateData = {
        formData,
        errors: validationResult.errors
      };
      
      return res.status(400).render('form', templateData);
    }

    // Validation passed, insert into database
    await dbManager.insertSubmission(formData);

    // Redirect to thank-you page
    return res.redirect(302, '/thank-you');
    
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).send('Internal Server Error');
  }
});

// GET /thank-you - Display thank you page
app.get('/thank-you', async (req: Request, res: Response) => {
  try {
    await ensureDbInitialized();
    res.status(200).render('thank-you');
  } catch (error) {
    console.error('Error rendering thank-you page:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Initialize and start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Friendly Form Capture server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
      console.log('Press Ctrl+C to stop the server');
    });

    // Store server reference for graceful shutdown
    (global as typeof globalThis & { server?: unknown }).server = server;
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Initialize database when module loads
initializeDatabase().catch((error) => {
  console.error('Failed to initialize database:', error);
  process.exit(1);
});

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default app;
