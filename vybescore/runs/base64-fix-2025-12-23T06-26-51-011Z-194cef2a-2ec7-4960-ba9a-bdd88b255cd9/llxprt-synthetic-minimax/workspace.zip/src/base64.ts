/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Ensures proper padding is included as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using standard Base64.
 * Accepts input with or without padding and validates the Base64 format.
 */
export function decode(input: string): string {
  // Basic validation: check for invalid characters (only allow valid base64 chars and padding)
  const invalidChars = input.replace(/[A-Za-z0-9+/=]/g, '');
  if (invalidChars.length > 0) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Validate padding position
  const paddingMatch = input.match(/=+$/);
  const paddingCount = paddingMatch ? paddingMatch[0].length : 0;
  
  // Padding can only be at the end and maximum 2 characters
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }
  
  // Check that padding only appears at the end
  const nonPaddingPart = input.replace(/=+$/g, '');
  if (nonPaddingPart.includes('=')) {
    throw new Error('Invalid Base64 input: padding must be at the end');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
