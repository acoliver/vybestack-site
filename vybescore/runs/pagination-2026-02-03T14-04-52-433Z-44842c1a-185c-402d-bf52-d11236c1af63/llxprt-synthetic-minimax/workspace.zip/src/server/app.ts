import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    const errors: string[] = [];
    
    let page: number | undefined;
    if (pageParam !== undefined) {
      const parsedPage = Number(pageParam);
      if (Number.isNaN(parsedPage) || !Number.isInteger(parsedPage)) {
        errors.push('page must be a valid integer');
      } else if (parsedPage <= 0) {
        errors.push('page must be greater than 0');
      } else if (parsedPage > 10000) {
        errors.push('page must be less than or equal to 10000');
      } else {
        page = parsedPage;
      }
    }

    let limit: number | undefined;
    if (limitParam !== undefined) {
      const parsedLimit = Number(limitParam);
      if (Number.isNaN(parsedLimit) || !Number.isInteger(parsedLimit)) {
        errors.push('limit must be a valid integer');
      } else if (parsedLimit <= 0) {
        errors.push('limit must be greater than 0');
      } else if (parsedLimit > 1000) {
        errors.push('limit must be less than or equal to 1000');
      } else {
        limit = parsedLimit;
      }
    }

    if (errors.length > 0) {
      res.status(400).json({ 
        errors,
        message: 'Invalid query parameters'
      });
      return;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
