import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJsModule: SqlJsStatic | null = null;

  async initialize(): Promise<void> {
    // Initialize sql.js
    const SqlJs = await initSqlJs({
      locateFile: () => {
        // Use path relative to current file location
        return new URL('../node_modules/sql.js/dist/sql-wasm.wasm', import.meta.url).pathname;
      }
    });

    this.sqlJsModule = SqlJs;

    // Load existing database or create new one
    const dbExists = fs.existsSync(DB_PATH);

    if (dbExists) {
      const existingDb = fs.readFileSync(DB_PATH);
      this.db = new SqlJs.Database(existingDb);
    } else {
      this.db = new SqlJs.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    this.db.exec(schema);
    
    // Create the database file immediately
    this.saveToFile();
  }

  async insertSubmission(submission: Omit<Submission, 'id' | 'created_at'>): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    this.saveToFile();

    // Return the ID of the inserted row
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    return result[0].values[0][0] as number;
  }

  private saveToFile(): void {
    if (!this.db) throw new Error('Database not initialized');

    const data = this.db.export();
    fs.writeFileSync(DB_PATH, data);
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();