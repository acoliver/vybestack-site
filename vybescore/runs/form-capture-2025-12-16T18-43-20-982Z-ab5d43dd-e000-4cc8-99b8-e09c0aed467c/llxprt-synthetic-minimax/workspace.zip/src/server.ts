import express from 'express';
import path from 'path';
import bodyParser from 'body-parser';
import { dbManager } from './database.js';
import { validateFormData, FormData, hasErrors } from './validation.js';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));

// GET / - Show contact form
app.get('/', (req, res) => {
  res.render('contact', {
    errors: {},
    formData: {},
    title: 'Contact Us'
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req, res) => {
  const formData: FormData = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);

  if (hasErrors(errors)) {
    // Re-render form with errors and previous values
    return res.status(400).render('contact', {
      errors,
      formData,
      title: 'Contact Us'
    });
  }

  try {
    // Insert submission into database
    await dbManager.insertSubmission(formData);
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('contact', {
      errors: { _general: 'An error occurred while saving your information. Please try again.' },
      formData,
      title: 'Contact Us'
    });
  }
});

// GET /thank-you - Show thank you page
app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, closing server gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, closing server gracefully...');
  await dbManager.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();