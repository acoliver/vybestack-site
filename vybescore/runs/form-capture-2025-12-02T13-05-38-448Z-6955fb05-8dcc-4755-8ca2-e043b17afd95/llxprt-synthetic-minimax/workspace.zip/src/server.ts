import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Type definition to avoid linting issues with sql.js
interface SqlJsStatic {
  Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
}

declare class Database {
  constructor(data?: ArrayLike<number> | Buffer | null);
  exec(sql: string): void;
  prepare(sql: string): Statement;
  close(): void;
  export(): Uint8Array;
}

declare class Statement {
  run(params?: (string | number | null)[]): void;
  free(): void;
  getColumnNames(): string[];
}

// Types for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

class App {
  public app: express.Application;
  private db: Database | null = null;
  private dbPath: string;
  private schema: string;
  private sqlInstance: SqlJsStatic | null = null;

  constructor() {
    this.app = express();
    // Use process.cwd() to get the correct path in both dev and prod
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schema = `CREATE TABLE IF NOT EXISTS submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      street_address TEXT NOT NULL,
      city TEXT NOT NULL,
      state_province TEXT NOT NULL,
      postal_code TEXT NOT NULL,
      country TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );`;
    
    this.configureMiddleware();
    this.setupRoutes();
  }

  private configureMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private setupRoutes(): void {
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', { 
        errors: [], 
        formData: {},
        title: 'Contact Form'
      });
    });

    this.app.post('/submit', (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName?.trim() || '',
        lastName: req.body.lastName?.trim() || '',
        streetAddress: req.body.streetAddress?.trim() || '',
        city: req.body.city?.trim() || '',
        stateProvince: req.body.stateProvince?.trim() || '',
        postalCode: req.body.postalCode?.trim() || '',
        country: req.body.country?.trim() || '',
        email: req.body.email?.trim() || '',
        phone: req.body.phone?.trim() || '',
      };

      const errors = this.validateForm(formData);
      
      if (errors.length > 0) {
        res.status(400).render('form', { 
          errors, 
          formData,
          title: 'Contact Form - Please Fix Errors'
        });
        return;
      }

      this.insertSubmission(formData);
      res.redirect(302, '/thank-you');
    });

    this.app.get('/thank-you', (req: Request, res: Response) => {
      res.render('thank-you', { title: 'Thank You!' });
    });
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    requiredFields.forEach(field => {
      if (!data[field]) {
        errors.push({
          field,
          message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
        });
      }
    });

    // Email validation
    if (data.email && !this.isValidEmail(data.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }

    // Phone validation
    if (data.phone && !this.isValidPhone(data.phone)) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number'
      });
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && !this.isValidPostalCode(data.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Please enter a valid postal code'
      });
    }

    return errors;
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private isValidPhone(phone: string): boolean {
    // Allow digits, spaces, parentheses, dashes, and a leading +
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && /\d/.test(phone);
  }

  private isValidPostalCode(postalCode: string): boolean {
    // Allow alphanumeric strings, at least 3 characters
    const postalRegex = /^[A-Za-z0-9]{3,}$/;
    return postalRegex.test(postalCode.replace(/\s/g, ''));
  }

  private async insertSubmission(data: FormData): Promise<void> {
    if (!this.db) {
      await this.initDatabase();
    }

    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName, data.lastName, data.streetAddress, data.city,
      data.stateProvince, data.postalCode, data.country, data.email, data.phone
    ]);

    stmt.free();
    await this.saveDatabase();
  }

  private async initDatabase(): Promise<void> {
    this.sqlInstance = await initSqlJs({
      locateFile: (file: string) => {
        // Always use the absolute path from project root
        const wasmPath = path.join('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/form-capture-2025-12-02T13-05-38-448Z-6955fb05-8dcc-4755-8ca2-e043b17afd95', 'node_modules', 'sql.js', 'dist', file);
        return wasmPath;
      }
    });

    try {
      const fs = await import('fs/promises');
      try {
        const buffer = await fs.readFile(this.dbPath);
        this.db = new this.sqlInstance.Database(buffer);
      } catch (readError) {
        // Database file doesn't exist, create new one
        this.db = new this.sqlInstance.Database();
        if (this.db) {
          this.db.exec(this.schema);
        }
        // Create data directory if it doesn't exist
        const dataDir = path.dirname(this.dbPath);
        await fs.mkdir(dataDir, { recursive: true });
        await this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) {
      return;
    }

    const data = this.db.export();
    const fs = await import('fs/promises');
    const buffer = Buffer.from(data);
    await fs.writeFile(this.dbPath, buffer);
    console.log('Database saved to disk');
  }

  public async start(): Promise<void> {
    await this.initDatabase();
    const port = process.env.PORT || 3535;
    
    return new Promise((resolve, reject) => {
      this.app.listen(port, () => {
        console.log(`Server running on port ${port}`);
        resolve();
      }).on('error', reject);
    });
  }

  public async stop(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    console.log('Server stopped gracefully');
  }
}

// Handle graceful shutdown
const app = new App();

// SIGTERM handler for graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully');
  await app.stop();
  process.exit(0);
});

// Start server
if (import.meta.url === `file://${process.argv[1]}`) {
  app.start().catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { App, app as default };