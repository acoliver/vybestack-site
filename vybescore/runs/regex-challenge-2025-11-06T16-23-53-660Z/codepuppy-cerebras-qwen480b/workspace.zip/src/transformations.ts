/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences, collapse extra spaces, preserve abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Normalize spacing - collapse multiple spaces into one and trim
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Split into sentences using punctuation, keeping the punctuation
  const parts = normalized.split(/([.!?])/);
  
  let result = '';
  let isNewSentence = true;
  
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    
    if (!part) continue;
    
    if (/[.!?]/.test(part)) {
      // This is punctuation marking end of sentence
      result += part;
      if (i < parts.length - 1) {
        result += ' '; // Add space after punctuation unless it's the last
      }
      isNewSentence = true;
    } else if (isNewSentence && part.trim()) {
      // Start of new sentence - capitalize first character
      const trimmed = part.trim();
      if (trimmed) {
        result += trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
        isNewSentence = false;
      }
    } else {
      // Middle of sentence - just add the part (trimmed)
      result += part.trim();
    }
  }
  
  // Clean up any double spaces and trim
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * Extract all URLs from text without trailing punctuation.
 * Supports http, https, ftp protocols and www domains.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Comprehensive URL regex that handles various formats
  const urlRegex = /\b((?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+)\b/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean each match by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation but keep it if it's part of the URL
    return url.replace(/[.,;:!?\])}]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://, but not https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite documentation URLs from http://example.com/docs/... to https://docs.example.com/docs/...
 * Always upgrades to HTTPS. Skips host rewrite for dynamic content with specific patterns.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Pattern to match URLs from example.com
  const urlRegex = /\bhttps?:\/\/example\.com(\/[^\s"']*)/gi;
  
  return text.replace(urlRegex, (match, path) => {
    // Always upgrade to HTTPS
    let result = 'https://';
    
    // Check if we should rewrite host based on path content
    const shouldRewriteHost = path.startsWith('/docs/') && 
      !/cgi-bin|\/[^/]*\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path) &&
      !path.includes('?');
    
    if (shouldRewriteHost) {
      result += 'docs.example.com';
    } else {
      result += 'example.com';
    }
    
    result += path;
    return result;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Strict regex for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day range for the specific month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year February
  let febDays = 28;
  const yearNum = parseInt(year, 10);
  if ((yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0) {
    febDays = 29;
  }
  
  if (month === 2 && day > febDays) return 'N/A';
  if (month !== 2 && day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}
