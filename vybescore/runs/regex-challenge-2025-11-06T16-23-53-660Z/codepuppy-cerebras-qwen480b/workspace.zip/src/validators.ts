export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper RFC compliance.
 * Accepts name+tag@example.co.uk format, rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email regex that handles most cases while rejecting obviously invalid ones
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check for consecutive dots
  if (value.includes('..')) return false;
  
  // Check for trailing or leading dots
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  // Domain should not contain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting various formats.
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Remove international prefix if present
  const actualDigits = digits.startsWith('1') && digits.length === 11 ? digits.slice(1) : digits;
  
  // Must be exactly 10 digits for US numbers
  if (actualDigits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = actualDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Basic format validation
  const phoneRegex = /^\+?1?[\s-\.]?\(?\d{3}\)?[\s-\.]?\d{3}[\s-\.]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers for both landlines and mobiles.
 * Handles +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567, etc.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Pattern matching: optional +54, optional 9, area code (2-4 digits), subscriber (6-8 digits)
  const withCountryCode = /^\+54(9)?\d{2,4}\d{6,8}$/;
  const withTrunkPrefix = /^0\d{2,4}\d{6,8}$/;
  const justDigits = /^\d{10,12}$/; // Just digits (for numbers without country code)
  
  // Check if it matches any of the patterns
  if (withCountryCode.test(cleanNumber)) return true;
  if (withTrunkPrefix.test(cleanNumber)) return true;
  if (justDigits.test(cleanNumber) && !cleanNumber.startsWith('0')) {
    // Must be valid structure without leading 0 for area code
    const areaCodeLength = 2; // minimum
    const subscriberLength = cleanNumber.length - areaCodeLength;
    if (subscriberLength >= 6 && subscriberLength <= 8) return true;
  }
  
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and stylized names like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Names should contain at least 2 characters
  if (value.trim().length < 2) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and most symbols
  const nameRegex = /^[\p{L}\p{M}'’\-\s]+$/u;
  
  // Reject if it contains digits or obvious non-name symbols
  if (/\d/.test(value)) return false;
  if (/[!@#$%^&*()_+=\[\]{}|\;:"'<>,.?/]/.test(value)) return false;
  
  // Reject sequences like X Æ A-12 (contains digits)
  if (/\d/.test(value)) return false;
  
  return nameRegex.test(value.trim());
}

/**
 * Luhn checksum implementation for credit card validation.
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx.
 * Checks length, prefix, and runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^((5[1-5]\d{14})|(2(2[2-9]\d{12}|[3-6]\d{13}|7([0-1]\d{12}|20\d{11}))))$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any supported card type
  const isValidLength = visaRegex.test(cleanNumber) || 
                       mastercardRegex.test(cleanNumber) || 
                       amexRegex.test(cleanNumber);
  
  if (!isValidLength) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanNumber);
}
