/**
 * Find words beginning with the given prefix, excluding listed exceptions.
 * Uses word boundaries and negative lookaheads to filter out exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Simple approach: split into words and filter
  const words = text.split(/\s+/);
  const prefixedWords = words.filter(word => 
    word.toLowerCase().startsWith(prefix.toLowerCase())
  );
  
  // Filter out exceptions (case-insensitive)
  const result = prefixedWords.filter(word => {
    const lowerWord = word.toLowerCase();
    const exceptionFound = exceptions.some(exception => 
      exception.toLowerCase() === lowerWord
    );
    return !exceptionFound;
  });
  
  // Remove duplicates while preserving order
  return [...new Set(result)];
}

/**
 * Find occurrences of token that appear after a digit and not at string start.
 * Uses lookbehind to ensure token is preceded by a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Simple approach: look for digit+token pattern directly
  const pattern = new RegExp('\d' + token, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Remove duplicates while preserving order
  return [...new Set(matches)];
}

/**
 * Validate password strength according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., 'abab')
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length requirement
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (not alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // Check for repeated sequences like 'abab', '123123', etc.
  // Look for any 2-4 character pattern that repeats immediately
  const repeatedPattern = /(..+?)\1+/;
  if (repeatedPattern.test(value)) return false;
  
  // More specific check for exact repetitions like 'abab', 'abcabc', etc.
  // Check patterns of length 2-4 that repeat exactly twice
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - (len * 2); i++) {
      const pattern = value.substr(i, len);
      const nextPattern = value.substr(i + len, len);
      if (pattern === nextPattern) return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses including shorthand :: notation.
 * Excludes IPv4 addresses from triggering positive results.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex patterns
  
  // IPv6 regex patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: (compressed zeros)
  const compressedIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with mixed notation (embedded IPv4)
  const mixedIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check for IPv6 patterns
  const hasFullIPv6 = fullIPv6Regex.test(value);
  const hasCompressedIPv6 = compressedIPv6Regex.test(value);
  const hasMixedIPv6 = mixedIPv6Regex.test(value);
  
  // If we find IPv6 and no IPv4, or IPv6 with mixed format, return true
  if (hasFullIPv6 || hasCompressedIPv6) return true;
  if (hasMixedIPv6) return true;
  
  return false;
}