const pattern = new RegExp('\d' + 'foo', 'gi');
console.log('Pattern:', pattern);
console.log('Pattern source:', pattern.source);
console.log('Matches:', 'xfoo 1foo foo'.match(pattern) || []);