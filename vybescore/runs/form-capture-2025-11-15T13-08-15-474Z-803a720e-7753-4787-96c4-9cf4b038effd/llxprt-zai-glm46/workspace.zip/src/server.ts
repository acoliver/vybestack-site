import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

let db: initSqlJs.Database | null = null;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

app.use(express.static(path.join(__dirname, '../public')));
app.use(express.urlencoded({ extended: true }));

function validateFormData(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!formData.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!formData.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!formData.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!formData.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!formData.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!formData.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!/^[A-Za-z0-9\s-]+$/.test(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, numbers, spaces, and hyphens' });
  }

  if (!formData.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!formData.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!formData.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^\+?[\d\s\-()]+$/.test(formData.phone)) {
    errors.push({ field: 'phone', message: 'Phone number must contain only digits, spaces, hyphens, parentheses, and optional leading +' });
  }

  return errors;
}

app.get('/', (req, res) => {
  res.render('form', { 
    errors: [],
    formData: {}
  });
});

app.post('/submit', (req, res) => {
  const formData = req.body as FormData;
  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.status(400).render('form', { 
      errors,
      formData
    });
    return;
  }

  try {
    if (!db) throw new Error('Database not initialized');
    
    db.run(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      formData.firstName || '',
      formData.lastName || '',
      formData.streetAddress || '',
      formData.city || '',
      formData.stateProvince || '',
      formData.postalCode || '',
      formData.country || '',
      formData.email || '',
      formData.phone || ''
    ]);

    const data = db.export();
    fs.writeFileSync(path.join(__dirname, '../data/submissions.sqlite'), Buffer.from(data));

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: [{ field: 'database', message: 'An error occurred while saving your submission' }],
      formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

async function initializeDatabase(): Promise<void> {
  try {
    const SQLModule = await initSqlJs({
      locateFile: () => path.join(__dirname, '../node_modules/sql.js/dist/sql-wasm.wasm')
    });

    const dataPath = path.join(__dirname, '../data/submissions.sqlite');
    let dbData: Buffer | null = null;

    if (fs.existsSync(dataPath)) {
      dbData = fs.readFileSync(dataPath);
    }

    if (dbData) {
      db = new SQLModule.Database(dbData);
    } else {
      db = new SQLModule.Database();
    }

    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    if (db) {
      db.exec(schema);
    }

    if (!fs.existsSync(path.join(__dirname, '../data'))) {
      fs.mkdirSync(path.join(__dirname, '../data'), { recursive: true });
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    try {
      db.close();
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }

  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});