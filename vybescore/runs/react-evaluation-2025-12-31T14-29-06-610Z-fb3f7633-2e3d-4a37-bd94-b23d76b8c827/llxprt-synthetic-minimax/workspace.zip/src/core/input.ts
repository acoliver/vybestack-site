/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(), // Multiple observers support
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    // Register this subject with the current active observer
    const observer = getActiveObserver()
    if (observer) {
      s.observers!.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const prevValue = s.value
    s.value = nextValue
    
    // Only notify if value actually changes
    if (prevValue !== nextValue) {
      // Notify ALL observers that depend on this subject
      if (s.observers && s.observers.size > 0) {
        const observers = Array.from(s.observers!)
        
        // Update each observer that depends on this subject
        for (const observer of observers) {
          if (observer && typeof observer === 'object') {
            const anyObserver = observer as any
            if (anyObserver.updateFn) {
              updateObserver(anyObserver as Observer<unknown>)
            }
          }
        }
      }
    }
    
    return s.value
  }

  return [read, write]
}
