/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, setActiveObserver, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create observer that executes side effects when dependencies change
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      if (disposed) return observer.value as T
      
      // Execute the side effect callback
      const result = updateFn(currentValue ?? value)
      observer.value = result
      return result
    },
  }
  
  // Establish dependencies by setting this observer as active during initial execution
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  try {
    // Initial execution to establish dependencies
    // This will trigger the callback function and register dependencies
    const result = observer.updateFn(value)
    observer.value = result
  } finally {
    // Restore previous observer context
    setActiveObserver(previousObserver)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Stop further updates by making the updateFn a no-op
    observer.updateFn = (_currentValue?: T) => {
      return observer.value as T
    }
  }
}
