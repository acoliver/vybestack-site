/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  setActiveObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const read: GetterFn<T> = () => {
    // Register this computed with the current active observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Observer is valid, nothing to do but we need to reference it to avoid unused warning
    }
    
    // Set this observer as active during dependency access
    setActiveObserver(o)
    
    try {
      // Evaluate the computed value using current observer context
      const result = updateFn(o.value)
      o.value = result
      return result
    } finally {
      // Clear active observer context
      setActiveObserver(undefined)
    }
  }

  return read
}
