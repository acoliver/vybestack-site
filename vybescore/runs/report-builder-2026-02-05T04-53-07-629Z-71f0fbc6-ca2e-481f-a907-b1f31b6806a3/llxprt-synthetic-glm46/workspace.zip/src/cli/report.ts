#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { Report, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

type Format = keyof typeof formatters;

function parseArgs(): { filePath: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const filePath = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format option is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1];
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');
  
  return { filePath, format, outputPath, includeTotals };
}

function validateFormat(format: string): Format {
  if (!Object.keys(formatters).includes(format)) {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }
  return format as Format;
}

function validateReport(report: unknown): Report {
  if (!report || typeof report !== 'object') {
    throw new Error('Invalid JSON data: must be an object');
  }
  
  const obj = report as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON data: missing or invalid title field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON data: missing or invalid summary field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON data: missing or invalid entries field');
  }
  
  const entries = obj.entries.map((entry: unknown) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid JSON data: each entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid JSON data: each entry must have a label field');
    }
    
    const amount = entryObj.amount;
    
    if (typeof amount !== 'number') {
      throw new Error('Invalid JSON data: each entry must have a numeric amount field');
    }
    
    return {
      label: entryObj.label,
      amount,
    };
  });
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

function main() {
  try {
    const { filePath, format: formatName, outputPath, includeTotals } = parseArgs();
    
    const format = validateFormat(formatName);
    
    let jsonData: string;
    try {
      jsonData = readFileSync(filePath, 'utf-8');
    } catch (error) {
      console.error(`Error: Could not read file: ${filePath}`);
      process.exit(1);
    }
    
    let parsedData: unknown;
    try {
      parsedData = JSON.parse(jsonData);
    } catch (error) {
      console.error(`Error: Invalid JSON in file: ${filePath}`);
      process.exit(1);
    }
    
    const report = validateReport(parsedData);
    const formatter = formatters[format];
    const options: RenderOptions = { includeTotals };
    const rendered = formatter.render(report, options);
    
    if (outputPath) {
      try {
        writeFileSync(outputPath, rendered, 'utf-8');
      } catch (error) {
        console.error(`Error: Could not write to output file: ${outputPath}`);
        process.exit(1);
      }
    } else {
      console.log(rendered);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
