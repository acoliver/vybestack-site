/**
 * Validate Base64 input string.
 * Returns true if the input is valid Base64 (with or without padding).
 */
function isValidBase64(input: string): boolean {
  if (!input || input.length === 0) {
    return false;
  }

  // Check that all characters are valid Base64 characters
  // Valid Base64: A-Z, a-z, 0-9, +, /, and = (only at the end for padding)
  const base64Regex = /^[A-Za-z0-9+/]+={0,2}$/;

  if (!base64Regex.test(input)) {
    return false;
  }

  // Padding can only appear at the end and at most 2 characters
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      return false;
    }
  }

  return true;
}

/**
 * Normalize Base64 input by adding padding if needed.
 * Node.js Buffer.from can decode unpadded Base64, so we just need to ensure
 * the length is compatible.
 */
function normalizeBase64(input: string): string {
  // Calculate needed padding
  const paddingLength = (4 - (input.length % 4)) % 4;
  return input + '='.repeat(paddingLength);
}

/**
 * Encode plain text to Base64 using standard Base64 alphabet.
 * Output includes padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding).
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const normalized = normalizeBase64(input);
    const buffer = Buffer.from(normalized, 'base64');

    // Check if the decoding resulted in an empty buffer for non-empty input
    // This can happen for invalid but technically parseable Base64
    if (input.length > 0 && buffer.length === 0) {
      throw new Error('Invalid Base64 input');
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
