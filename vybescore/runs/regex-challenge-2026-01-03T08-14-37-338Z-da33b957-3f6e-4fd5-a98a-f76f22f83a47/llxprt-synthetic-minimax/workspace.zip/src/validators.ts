export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Pattern explanation:
  // - Start with one or more chars that can be alphanumeric, dots, underscores, percent, plus, hyphen
  // - @ symbol required
  // - Domain part with alphanumeric, dots, hyphens
  // - TLD part with 2+ alphanumeric chars
  // Reject: double dots, trailing dots, domains with underscores
  
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (/\.\./.test(value)) return false; // No double dots
  if (/\.$/.test(value)) return false; // No trailing dot
  if (/@.*\.\./.test(value)) return false; // No double dots in domain
  if (/@[a-zA-Z0-9]*_[a-zA-Z0-9]/.test(value)) return false; // No underscores in domain part
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  const phoneRegex = /^\+?1?([2-9]\d{2})([2-9]\d{2})\d{4}$/;
  
  if (!phoneRegex.test(cleaned)) return false;
  
  // Additional validation for area codes (cannot start with 0 or 1)
  const areaCode = cleaned.match(/^\+?1?([2-9]\d{2})/)?.[1];
  if (!areaCode || areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators and spaces
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // - Optional country code +54
  // - Optional trunk prefix 0 (when no country code)
  // - Optional mobile indicator 9
  // - Area code: 2-4 digits (first digit 1-9)
  // - Subscriber number: 6-8 digits total after area code
  
  const arPhoneRegex = /^(?:\+54)?(?:0)?(?:\+?)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(arPhoneRegex);
  
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriber = match[2];
  
  // Area code validation: 2-4 digits, first not 0
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0') return false;
  
  // Subscriber validation: total 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  // Additional validation: when no country code, must have trunk 0
  if (!value.includes('+54') && !value.startsWith('0')) {
    // Check if trunk prefix is present
    if (!/^0/.test(cleaned.replace(/^\+?54/, ''))) {
      return false;
    }
  }
  
  // Mobile validation: if contains 9 indicator, area should be 2-3 digits typically
  if (value.includes('9') && !/^9/.test(cleaned)) {
    // Mobile format: +54 9 XX XXX XXXX
    if (areaCode.length < 2 || areaCode.length > 3) return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern explanation:
  // - Allow unicode letters, accents, apostrophes, hyphens, spaces
  // - Reject digits and special symbols (except those mentioned)
  // - Allow 1-3 words with spaces between them
  
  // First, reject obvious invalid patterns
  if (/\d/.test(value)) return false; // No digits
  if (/[^\p{L}\p{M}\s'-]/u.test(value)) return false; // No symbols except apostrophe and hyphen

  // Must have at least one letter
  if (!/\p{L}/u.test(value)) return false;

  // Reject names starting with non-letters (except apostrophes in some cultures)
  if (!/^[\p{L}\s'-]/u.test(value)) return false;

  // Reject names ending with invalid characters
  if (!/[\p{L}\s'-]$/u.test(value)) return false;
  
  // Check for reasonable name pattern (avoid nonsense like "X Æ A-12")
  // Allow 1-3 words, each starting with a letter
  const words = value.trim().split(/\s+/);
  if (words.length === 0 || words.length > 4) return false; // Reasonable name length
  
  for (const word of words) {
    if (word.length === 0) return false; // No empty words
    if (!/^[\p{L}\p{M}'-]/u.test(word)) return false; // Word must start with letter
    if (!/[\p{L}\p{M}'-]$/u.test(word)) return false; // Word must end properly
    if (word.length > 30) return false; // Reasonable word length
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Basic validation: must have 13-19 digits (typical ranges)
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  // Check for valid prefixes (Visa, MasterCard, AmEx patterns)
  const visaRegex = /^4\d{12}(\d{3})?(\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  const discoverRegex = /^6(?:011|5\d{2})\d{12}$/;
  
  // Check if it matches any valid card type pattern
  if (!visaRegex.test(cleaned) && 
      !mastercardRegex.test(cleaned) && 
      !amexRegex.test(cleaned) && 
      !discoverRegex.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum algorithm
  return runLuhnCheck(cleaned);
}

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return (sum % 10) === 0;
}
