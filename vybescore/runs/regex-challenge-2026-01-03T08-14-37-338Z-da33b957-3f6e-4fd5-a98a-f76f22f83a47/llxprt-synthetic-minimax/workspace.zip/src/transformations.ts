/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to match sentence boundaries: end with .?! followed by space(s)
  // Then capitalize the letter following sentence endings

  return text
    // Split into sentences, preserving punctuation
    .split(/(?<=[.!?])\s+/)
    .map(sentence => {
      // Remove leading spaces for processing
      const trimmed = sentence.trim();
      if (trimmed.length === 0) return sentence;

      // Capitalize first letter, preserve rest
      return sentence.replace(/^\s*([a-z\u00C0-\u024F])/i, 
        (match, p1) => match.replace(p1, p1.toUpperCase()));
    })
    .join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches common URL formats
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s<>"']+\b/gi;

  // Find all matches
  const matches = text.match(urlPattern) || [];

  // Process matches to remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when not already https
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
  const urlPattern = /http:\/\/([^/\s]+)(\/[^\s<>"']*)?/gi;

  return text.replace(urlPattern, (match, host, path = '') => {
    let newUrl = 'https://';

    // Check for dynamic hints or legacy extensions that should skip host rewrite
    const hasDynamicHints = /cgi-bin|[?&]=|\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);

    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host to docs.example.com when path begins with /docs/
      // Keep the full path including /docs/
      newUrl += `docs.example.com${path}`.replace(/\/$/, ''); // Remove trailing slash
    } else {
      // Keep original host
      newUrl += host + path;
    }

    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) return 'N/A';

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';

  // Basic day validation for common months
  const thirtyDayMonths = [4, 6, 9, 11];
  if (thirtyDayMonths.includes(month) && day > 30) return 'N/A';
  if (month === 2 && day > 29) return 'N/A';

  // Year should be reasonable (between 1000 and 9999)
  if (year.length !== 4 || parseInt(year, 10) < 1000) return 'N/A';

  return year;
}
