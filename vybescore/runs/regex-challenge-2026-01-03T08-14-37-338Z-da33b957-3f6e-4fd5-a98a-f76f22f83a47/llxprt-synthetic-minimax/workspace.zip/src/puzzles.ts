/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern for the prefix
  const prefixPattern = new RegExp(`\\b${escapeRegex(prefix)}[a-zA-Z]*\\b`, 'gi');

  // Find all matches
  const matches = text.match(prefixPattern) || [];

  // Filter out exceptions (case insensitive)
  const lowercaseExceptions = exceptions.map(e => e.toLowerCase());

  return matches.filter(match => {
    const word = match.toLowerCase();
    return !lowercaseExceptions.includes(word);
  }).map(match => match.trim());
}

// Helper function to escape special regex characters
function escapeRegex(string: string): string {
  return string.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern explanation:
  // - Must be preceded by a digit (but not at string start)
  // - The token itself

  const escapedToken = token.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&');
  const tokenPattern = new RegExp(`(?<!^)\\d${escapedToken}(?!\\w)`, 'gi');

  // Find all matches
  const matches = text.match(tokenPattern) || [];

  // Process matches to include the digit and token
  return matches.map(match => match.trim());
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;

  // Check for whitespace
  if (/\s/.test(value)) return false;

  // Check for required character types
  if (!/[A-Z]/.test(value)) return false; // At least one uppercase
  if (!/[a-z]/.test(value)) return false; // At least one lowercase
  if (!/\d/.test(value)) return false; // At least one digit
  if (!/[!@#$%^&*()_+\-=[{};:'"|,.<>/?]/.test(value)) return false; // At least one symbol

  // Check for immediate repeated sequences
  // Pattern looks for repeated 2-character patterns
  if (/(..+)\\1/.test(value)) return false;

  // Additional check for specific patterns like "abab"
  // Using a different approach to avoid backreference issues
  for (let i = 0; i < value.length - 3; i++) {
    const substring = value.substring(i, i + 2);
    if (value.substring(i + 2, i + 4) === substring) {
      return false; // Found immediate repetition like "abab"
    }
  }

  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, ensure it's not an IPv4 address
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) return false;

  // IPv6 pattern explanation:
  // - Hex groups separated by colons
  // - Allow shorthand :: for zero groups
  // - Each group is 1-4 hex digits
  // - Must have at least 2 colons to distinguish from simple hex codes

  const ipv6Pattern = /\b(?:[a-fA-F0-9]{1,4}:){2,7}[a-fA-F0-9]{1,4}\b|\b[a-fA-F0-9]{0,4}::(?:\/[a-fA-F0-9]{1,4}:){0,6}[a-fA-F0-9]{0,4}\b/;

  return ipv6Pattern.test(value);
}
