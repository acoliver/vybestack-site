# Report Builder CLI

Implement a clean, idiomatic TypeScript command-line tool that renders reports from JSON input.

## Requirements

### CLI Usage
- Entry point: `src/cli/report.ts` (compiled to `dist/cli/report.js`).
- Invocation after building: `node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]`.
- Supported formats: `markdown`, `text`. Reject unknown formats with an error containing `Unsupported format`.
- Output goes to stdout unless `--output` is provided.
- Parse arguments using Node’s standard library (no third-party parsers).
- Ensure TypeScript imports use `.js` extensions (e.g., `import { renderMarkdown } from '../formats/markdown.js';`) so emitted JavaScript resolves correctly under NodeNext.

### Data Model
- JSON schema matches `fixtures/data.json`:
  ```json
  {
    "title": "Quarterly Financial Summary",
    "summary": "Highlights include record revenue...",
    "entries": [
      { "label": "North Region", "amount": 12345.67 },
      { "label": "South Region", "amount": 23456.78 },
      { "label": "West Region", "amount": 34567.89 }
    ]
  }
  ```
- Compute totals by summing `entries[].amount`. Amounts must render with two decimal places.
- Validate input and report helpful errors for malformed JSON or missing fields.

### Formatting Rules
- Markdown format: print `# <title>`, blank line, summary, blank line, `## Entries`, bullet list `- **<label>** — $<amount>`, optional final `**Total:** $<amount>` when `--includeTotals` is provided.
- Text format: print title, summary, `Entries:` heading, bullet list `- <label>: $<amount>`, optional `Total: $<amount>` when totals are requested.
- Render amounts exactly as `$12345.67` (two decimal places, no thousands separators) so the fixtures and totals align.
- Output comparison normalises whitespace (trim + collapse blank lines) before checking results, so focus on content and order.

- Keep the CLI minimal and delegate rendering to format modules under `src/formats/` (create at least `markdown.ts` and `text.ts`).
- Export a consistent interface from each formatter so adding new formats is easy (e.g., via a map of `format -> renderer`).
- Share typed interfaces for report data and options.
- Maintain strict TypeScript/ESLint/Prettier rules as configured.

- Do **not** modify `package.json`, `tsconfig.json`, `.eslintrc.cjs`, or `.prettierrc` (no new dependencies, scripts, or settings).
- Rely only on built-in Node modules.

## Verification Checklist

```bash
npm run lint
npm run test:public
npm run typecheck
npm run build
node dist/cli/report.js fixtures/data.json --format markdown --includeTotals
```

After the scripted checks, run the CLI manually in both formats (with and without `--includeTotals`) and point it at a malformed JSON file to confirm the error experience is polished.
