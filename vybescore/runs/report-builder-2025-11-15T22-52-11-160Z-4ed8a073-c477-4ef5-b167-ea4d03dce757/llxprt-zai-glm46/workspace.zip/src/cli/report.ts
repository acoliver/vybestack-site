#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const parsed: CliArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      parsed.format = args[i + 1];
      i++;
    } else if (arg === '--output' && i + 1 < args.length) {
      parsed.outputPath = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else if (!arg.startsWith('--') && !parsed.dataFile) {
      parsed.dataFile = arg;
    }
  }

  return parsed;
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string') {
    return false;
  }
  
  if (typeof reportData.summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(reportData.entries)) {
    return false;
  }
  
  for (const entry of reportData.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string' || typeof entryObj.amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const parsedArgs = parseArgs(args);

  if (!parsedArgs.dataFile) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }

  if (!parsedArgs.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  if (parsedArgs.format !== 'markdown' && parsedArgs.format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }

  let reportData: ReportData;
  
  try {
    const fileContent = await readFile(parsedArgs.dataFile, 'utf-8');
    const data = JSON.parse(fileContent);
    
    if (!validateReportData(data)) {
      console.error('Error: Invalid report data format');
      process.exit(1);
    }
    
    reportData = data;
  } catch (error) {
    console.error(`Error reading or parsing data file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }

  const options: ReportOptions = {
    includeTotals: parsedArgs.includeTotals,
  };

  const renderers = {
    markdown: renderMarkdown,
    text: renderText,
  };

  const renderer = renderers[parsedArgs.format as keyof typeof renderers];
  const output = renderer(reportData, options);

  if (parsedArgs.outputPath) {
    try {
      await writeFile(parsedArgs.outputPath, output);
    } catch (error) {
      console.error(`Error writing output file: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main().catch((error) => {
  console.error(`Unexpected error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  process.exit(1);
});
