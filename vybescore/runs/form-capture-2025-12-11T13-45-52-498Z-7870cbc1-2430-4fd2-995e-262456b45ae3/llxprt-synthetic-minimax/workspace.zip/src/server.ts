import express, { Request, Response } from 'express';
import * as path from 'path';
import { initializeDatabase, insertSubmission, closeDatabase } from './database';
import { validateContactForm } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/styles.css', express.static(path.join(__dirname, '../public/styles.css')));

// View engine
app.set('views', path.join(__dirname, '../views'));
app.set('view engine', 'ejs');

// GET / - Render contact form
app.get('/', async (req: Request, res: Response) => {
  try {
    res.render('form', {
      formData: {},
      errors: []
    });
  } catch (error) {
    console.error('Error rendering form:', error);
    res.status(500).send('Internal Server Error');
  }
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validationResult = validateContactForm(formData);

    if (!validationResult.isValid) {
      return res.status(400).render('form', {
        formData,
        errors: validationResult.errors
      });
    }

    // Initialize database and insert submission
    await initializeDatabase();
    insertSubmission({
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province_region: formData.stateProvinceRegion,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    });

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error handling form submission:', error);
    res.status(500).send('Internal Server Error');
  }
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  try {
    res.render('thank-you');
  } catch (error) {
    console.error('Error rendering thank you page:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Health check endpoint
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  closeDatabase();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully...');
  closeDatabase();
  process.exit(0);
});

// Start server
async function startServer() {
  try {
    // Initialize database on startup
    await initializeDatabase();
    console.log('Database initialized successfully');

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();