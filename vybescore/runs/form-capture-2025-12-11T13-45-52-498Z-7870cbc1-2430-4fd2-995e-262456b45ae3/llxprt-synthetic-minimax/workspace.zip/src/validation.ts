export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhone(phone: string): boolean {
  // Accept international phone formats with digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s()+-]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

export function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric postal codes (UK "SW1A 1AA", Argentine "C1000", etc.)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

export function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

export function validateContactForm(formData: Record<string, string>): ValidationResult {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    const value = formData[field] || '';
    if (!validateRequired(value)) {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
      });
    }
  }

  // Email validation
  const email = formData.email || '';
  if (email && !validateEmail(email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  const phone = formData.phone || '';
  if (phone && !validatePhone(phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Postal code validation
  const postalCode = formData.postalCode || '';
  if (postalCode && !validatePostalCode(postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code'
    });
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}