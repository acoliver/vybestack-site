import initSqlJs, { Database } from "sql.js";
import * as fs from "fs";
import * as path from "path";

const DB_FILE_PATH = path.join(__dirname, "../data/submissions.sqlite");
const SCHEMA_FILE_PATH = path.join(__dirname, "../db/schema.sql");

let db: Database | null = null;

export async function initializeDatabase(): Promise<Database> {
  if (db) {
    return db;
  }

  const SQL = await initSqlJs({
    locateFile: (file: string) => {
      return require.resolve(`sql.js/dist/${file}`);
    }
  });

  // Load existing database or create new one
  let buffer: Uint8Array;
  if (fs.existsSync(DB_FILE_PATH)) {
    buffer = new Uint8Array(fs.readFileSync(DB_FILE_PATH));
  } else {
    buffer = new Uint8Array(0);
  }

  db = new SQL.Database(buffer);

  // Initialize schema if needed
  const schema = fs.readFileSync(SCHEMA_FILE_PATH, "utf8");
  db.exec(schema);

  return db;
}

export function getDatabase(): Database {
  if (!db) {
    throw new Error("Database not initialized. Call initializeDatabase() first.");
  }
  return db;
}

export function saveDatabase(): void {
  if (!db) {
    return;
  }

  const data = db.export();
  fs.writeFileSync(DB_FILE_PATH, Buffer.from(data));
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

export interface ContactFormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export function insertSubmission(data: ContactFormData): void {
  const database = getDatabase();
  const stmt = database.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province_region, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    data.first_name,
    data.last_name,
    data.street_address,
    data.city,
    data.state_province_region,
    data.postal_code,
    data.country,
    data.email,
    data.phone
  ]);

  stmt.free();
  saveDatabase();
}
