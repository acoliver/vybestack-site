#!/usr/bin/env node

import { readFileSync } from 'fs';
import { writeFile } from 'fs/promises';
import type { ReportData, ReportFormat, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(processArgs: string[]): CliArgs {
  const args = processArgs.slice(2); // Skip node and script name
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  let format: ReportFormat = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value (markdown or text)');
          process.exit(1);
        }
        {
          const formatValue = args[i + 1];
          if (formatValue !== 'markdown' && formatValue !== 'text') {
            console.error(`Error: Unsupported format "${formatValue}". Supported formats: markdown, text`);
            process.exit(1);
          }
          format = formatValue as ReportFormat;
        }
        i++;
        break;
        
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a path');
          process.exit(1);
        }
        {
          outputPath = args[i + 1];
        }
        i++;
        break;
        
      case '--includeTotals':
        includeTotals = true;
        break;
        
      default:
        console.error(`Error: Unknown argument "${args[i]}"`);
        process.exit(1);
    }
  }
  
  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    console.error('Error: Invalid JSON - root must be an object');
    return false;
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    console.error('Error: Missing or invalid title field');
    return false;
  }
  
  if (typeof obj.summary !== 'string') {
    console.error('Error: Missing or invalid summary field');
    return false;
  }
  
  if (!Array.isArray(obj.entries)) {
    console.error('Error: Missing or invalid entries field');
    return false;
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      console.error('Error: Each entry must be an object');
      return false;
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      console.error('Error: Each entry must have a label field');
      return false;
    }
    
    if (typeof entryObj.amount !== 'number') {
      console.error('Error: Each entry must have an amount field');
      return false;
    }
  }
  
  return true;
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent);
    
    if (!validateReportData(data)) {
      process.exit(1);
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON in file');
    } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error('Error: File not found');
    } else {
      console.error('Error: Failed to read file');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: ReportFormat, options: ReportOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
  }
}

async function main() {
  const { dataFile, format, outputPath, includeTotals } = parseArgs(process.argv);
  
  const data = loadReportData(dataFile);
  const options: ReportOptions = { includeTotals };
  const output = renderReport(data, format, options);
  
  if (outputPath) {
    try {
      await writeFile(outputPath, output, 'utf8');
      console.log(`Report written to ${outputPath}`);
    } catch (error) {
      console.error('Error: Failed to write output file');
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main().catch(error => {
  console.error('Unexpected error:', error);
  process.exit(1);
});
