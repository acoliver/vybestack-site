/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  ComputedNode,
  getActiveNode,
  setActiveNode,
  registerDependency,
  EqualFn
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = typeof equal === 'function' ? equal : undefined

  const node: ComputedNode<T> = {
    name: options?.name,
    observers: new Set(),
    dependencies: new Set(),
    value: value as T,
    updateFn,
    compute() {
      const previous = getActiveNode()
      setActiveNode(this)
      
      try {
        // Clear previous dependencies
        this.dependencies.forEach(dep => {
          dep.observers.delete(this)
        })
        this.dependencies.clear()

        // Compute new value
        const newValue = this.updateFn(this.value)

        // Check if value changed
        const shouldUpdate = equalFn 
          ? !equalFn(this.value as T, newValue)
          : equal === false 
          ? true 
          : this.value !== newValue

        if (shouldUpdate) {
          this.value = newValue
        }

        return this.value as T
      } finally {
        setActiveNode(previous)
      }
    },
    update() {
      this.compute()
    }
  }

  // Return getter function that always recomputes
  return (): T => {
    const active = getActiveNode()
    if (active) {
      registerDependency(node)
    }
    return node.compute()
  }
}
