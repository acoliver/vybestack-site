/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  InputNode,
  getActiveNode,
  registerDependency,
  propagateUpdate,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const node: InputNode<T> = {
    name: options?.name,
    observers: new Set(),
    dependencies: new Set(),
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
    setValue(nextValue: T) {
      const shouldUpdate = this.equalFn 
        ? !this.equalFn(this.value, nextValue)
        : equal === false
        ? true
        : this.value !== nextValue

      if (shouldUpdate) {
        this.value = nextValue
        propagateUpdate(this)
      }
    },
    update() {
      // Input nodes don't need to compute, they just propagate changes
    }
  }

  const read: GetterFn<T> = () => {
    const active = getActiveNode()
    if (active) {
      registerDependency(node)
    }
    return node.value
  }

  const write: SetterFn<T> = (nextValue) => {
    node.setValue(nextValue)
    return node.value
  }

  return [read, write]
}
