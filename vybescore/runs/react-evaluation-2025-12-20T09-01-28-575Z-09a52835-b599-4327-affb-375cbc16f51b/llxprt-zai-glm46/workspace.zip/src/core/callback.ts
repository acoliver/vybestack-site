import { 
  UnsubscribeFn, 
  CallbackNode, 
  UpdateFn,
  getActiveNode,
  setActiveNode
} from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const node: CallbackNode<T> = {
    observers: new Set(),
    dependencies: new Set(),
    value: value as T,
    updateFn,
    disposed: false,
    update() {
      if (this.disposed) return

      const previous = getActiveNode()
      setActiveNode(this)
      
      try {
        // Clear previous dependencies
        this.dependencies.forEach(dep => {
          dep.observers.delete(this)
        })
        this.dependencies.clear()

        // Execute the callback
        this.value = this.updateFn(this.value)
      } finally {
        setActiveNode(previous)
      }
    }
  }

  // Initial run to establish dependencies
  node.update()

  return () => {
    if (node.disposed) return
    
    node.disposed = true
    
    // Clean up dependencies
    node.dependencies.forEach(dep => {
      dep.observers.delete(node)
    })
    node.dependencies.clear()
  }
}
