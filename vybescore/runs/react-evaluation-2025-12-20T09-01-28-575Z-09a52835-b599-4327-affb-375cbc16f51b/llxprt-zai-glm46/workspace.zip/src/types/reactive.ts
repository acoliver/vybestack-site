/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Reactive node types
export type ReactiveNode = {
  name?: string
  update(): void
  observers: Set<ReactiveNode>
  dependencies: Set<ReactiveNode>
  disposed?: boolean
}

export type InputNode<T> = ReactiveNode & {
  value: T
  equalFn?: EqualFn<T>
  setValue(value: T): void
}

export type ComputedNode<T> = ReactiveNode & {
  value: T
  compute(): T
  updateFn: UpdateFn<T>
}

export type CallbackNode<T> = ReactiveNode & {
  value: T
  updateFn: UpdateFn<T>
  disposed: boolean
}

let activeNode: ReactiveNode | undefined

export function getActiveNode(): ReactiveNode | undefined {
  return activeNode
}

export function setActiveNode(node: ReactiveNode | undefined): void {
  activeNode = node
}

// Register dependency: active node depends on dependency node
export function registerDependency(dependency: ReactiveNode): void {
  if (activeNode && activeNode !== dependency) {
    activeNode.dependencies.add(dependency)
    dependency.observers.add(activeNode)
  }
}

// Trigger updates for all observers of a node
export function notifyObservers(node: ReactiveNode): void {
  const observers = Array.from(node.observers)
  observers.forEach(observer => {
    if (!observer.disposed) {
      observer.update()
    }
  })
}

// Propagate updates through computed nodes
export function propagateUpdate(node: ReactiveNode): void {
  const observers = Array.from(node.observers)
  observers.forEach(observer => {
    if (!observer.disposed) {
      observer.update()
      // If this observer is a computed node, propagate further
      if ('compute' in observer) {
        propagateUpdate(observer)
      }
    }
  })
}
