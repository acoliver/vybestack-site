import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

// Get the directory name for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup
let db: Database | null = null;
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');

const initializeDatabase = async () => {
  const SQL = await initSqlJs({
    locateFile: (file) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.0/${file}`
  });

  try {
    // Try to load existing database
    const dbBuffer = await fs.promises.readFile(DB_PATH);
    db = new SQL.Database(new Uint8Array(dbBuffer));
  } catch (err) {
    // If no existing database, create a new one
    db = new SQL.Database();
    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;
    db.run(schema);
    saveDatabase();
  }
};

// Save database to file
const fs = await import('fs');
const saveDatabase = () => {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
};

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhoneNumber = (phone: string): boolean => {
  const phoneRegex = /^[\d\s\-\(\)\+]+$/;
  return phoneRegex.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  } = req.body;

  const errors: string[] = [];

  // Validation
  if (!firstName?.trim()) errors.push('First name is required');
  if (!lastName?.trim()) errors.push('Last name is required');
  if (!streetAddress?.trim()) errors.push('Street address is required');
  if (!city?.trim()) errors.push('City is required');
  if (!stateProvince?.trim()) errors.push('State/Province is required');
  if (!postalCode?.trim()) {
    errors.push('Postal code is required');
  } else if (!validatePostalCode(postalCode)) {
    errors.push('Postal code contains invalid characters');
  }
  if (!country?.trim()) errors.push('Country is required');
  if (!email?.trim()) {
    errors.push('Email is required');
  } else if (!validateEmail(email)) {
    errors.push('Email is invalid');
  }
  if (!phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!validatePhoneNumber(phone)) {
    errors.push('Phone number contains invalid characters');
  }

  // If validation failed, re-render form with errors
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      values: req.body
    });
  }

  // Insert into database
  if (db) {
    db.run(
      `INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        firstName,
        lastName,
        streetAddress,
        city,
        stateProvince,
        postalCode,
        country,
        email,
        phone
      ]
    );
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(firstName));
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName || 'Friend';
  res.render('thank-you', { firstName });
});

// Initialize database and start server
initializeDatabase().then(() => {
  const server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });

  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    server.close(() => {
      if (db) {
        db.close();
      }
      console.log('Server closed');
      process.exit(0);
    });
  });
});