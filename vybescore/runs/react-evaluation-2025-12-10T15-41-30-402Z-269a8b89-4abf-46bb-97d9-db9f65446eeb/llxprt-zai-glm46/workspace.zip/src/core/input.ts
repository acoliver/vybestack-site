/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = typeof equal === 'function' 
    ? equal 
    : equal === false 
      ? () => false 
      : equal === true 
        ? (lhs: T, rhs: T) => lhs === rhs
        : undefined

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && s.observers) {
      if (!s.observers.has(observer)) {
        s.observers.add(observer)
      }
      // Track this subject as a dependency for the observer
      if (!observer.dependencies) {
        observer.dependencies = new Set()
      }
      observer.dependencies.add(s as Subject<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has changed or no equality function
    if (s.equalFn) {
      if (!s.equalFn(s.value, nextValue)) {
        s.value = nextValue
        notifyObservers(s)
      }
    } else {
      s.value = nextValue
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}
