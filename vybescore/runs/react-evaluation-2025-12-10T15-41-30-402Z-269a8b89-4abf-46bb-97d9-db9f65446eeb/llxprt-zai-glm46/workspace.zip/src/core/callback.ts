/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    dependencies: new Set(),
    updateFn: () => {
      if (disposed) return value!
      
      try {
        return updateFn(observer.value)
      } catch (error) {
        // If the update function throws, we should still return something
        // but mark as disposed to prevent further updates
        disposed = true
        throw error
      }
    },
  }
  
  // Register observer to track dependencies and execute initial callback
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    
    // Clean up dependencies
    if (observer.dependencies) {
      for (const subject of observer.dependencies) {
        if (subject.observers && subject.observers.has(observer)) {
          subject.observers.delete(observer)
        }
      }
      observer.dependencies.clear()
    }
  }
}
