#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, ReportOptions, ReportFormat } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataPath: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataPath: '',
    format: 'markdown',
    includeTotals: false
  };

  // Skip node and script path
  const cliArgs = argv.slice(2);
  
  for (let i = 0; i < cliArgs.length; i++) {
    const arg = cliArgs[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 < cliArgs.length) {
          const formatArg = cliArgs[i + 1];
          if (formatArg === 'markdown' || formatArg === 'text') {
            args.format = formatArg;
          } else {
            console.error('Error: Unsupported format');
            process.exit(1);
          }
          i++; // Skip next argument as it's the format value
        }
        break;
        
      case '--output':
        if (i + 1 < cliArgs.length) {
          args.outputPath = cliArgs[i + 1];
          i++; // Skip next argument as it's the output path
        }
        break;
        
      case '--includeTotals':
        args.includeTotals = true;
        break;
        
      default:
        // Treat as data path if not a flag
        if (!arg.startsWith('--')) {
          args.dataPath = arg;
        }
        break;
    }
  }

  return args;
}

function loadAndValidateData(dataPath: string): ReportData {
  try {
    const rawData = readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(rawData) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries field');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: Missing or invalid label field`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i + 1}: Missing or invalid amount field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON in data file');
    } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error('Error: Data file not found');
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  
  // Validate required arguments
  if (!args.dataPath) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    console.error('Error: Data file path is required');
    process.exit(1);
  }

  // Load and validate data
  const data = loadAndValidateData(args.dataPath);
  
  const options: ReportOptions = {
    includeTotals: args.includeTotals
  };

  // Render based on format
  let output: string;
  
  switch (args.format) {
    case 'markdown':
      output = renderMarkdown.format(data, options);
      break;
    case 'text':
      output = renderText.format(data, options);
      break;
    default:
      console.error('Error: Unsupported format');
      process.exit(1);
  }

  // Write output
  if (args.outputPath) {
    try {
      writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error('Error: Failed to write output file');
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();
