import { describe, expect, it } from 'vitest';
import { renderMarkdown } from '../../src/formats/markdown.js';
import { renderText } from '../../src/formats/text.js';

describe('renderers', () => {
  describe('renderMarkdown', () => {
    it('renders markdown without totals', () => {
      const data = {
        title: 'Quarterly Financial Summary',
        summary: 'Highlights include record revenue growth',
        entries: [
          { label: 'North Region', amount: 12345.67 },
          { label: 'South Region', amount: 23456.78 }
        ]
      };
      const options = { includeTotals: false };
      
      const output = renderMarkdown.format(data, options);
      expect(output).toContain('# Quarterly Financial Summary');
      expect(output).toContain('## Entries');
      expect(output).toContain('**North Region** — $12345.67');
      expect(output).toContain('**South Region** — $23456.78');
      expect(output).not.toContain('Total:');
    });

    it('renders markdown with totals', () => {
      const data = {
        title: 'Quarterly Financial Summary',
        summary: 'Highlights include record revenue growth',
        entries: [
          { label: 'North Region', amount: 12345.67 },
          { label: 'South Region', amount: 23456.78 }
        ]
      };
      const options = { includeTotals: true };
      
      const output = renderMarkdown.format(data, options);
      expect(output).toContain('**Total:** $35802.45');
    });
  });

  describe('renderText', () => {
    it('renders text without totals', () => {
      const data = {
        title: 'Quarterly Financial Summary',
        summary: 'Highlights include record revenue growth',
        entries: [
          { label: 'North Region', amount: 12345.67 },
          { label: 'South Region', amount: 23456.78 }
        ]
      };
      const options = { includeTotals: false };
      
      const output = renderText.format(data, options);
      expect(output).toContain('Quarterly Financial Summary');
      expect(output).toContain('Entries:');
      expect(output).toContain('- North Region: $12345.67');
      expect(output).toContain('- South Region: $23456.78');
      expect(output).not.toContain('Total:');
    });

    it('renders text with totals', () => {
      const data = {
        title: 'Quarterly Financial Summary',
        summary: 'Highlights include record revenue growth',
        entries: [
          { label: 'North Region', amount: 12345.67 },
          { label: 'South Region', amount: 23456.78 }
        ]
      };
      const options = { includeTotals: true };
      
      const output = renderText.format(data, options);
      expect(output).toContain('Total: $35802.45');
    });
  });
});
