#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData } from '../types.js';
import { getFormatter } from '../formats/index.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  let format = '';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

function loadJsonFile(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);

    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field (must be a string)');
    }
    if (typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field (must be a string)');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field (must be an array)');
    }

    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (typeof entry.label !== 'string') {
        throw new Error(`Entry at index ${i} has missing or invalid "label" field (must be a string)`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Entry at index ${i} has missing or invalid "amount" field (must be a number)`);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON file: ${filePath}`);
      console.error(`Details: ${error.message}`);
      process.exit(1);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error(`Error: Failed to read file: ${filePath}`);
      process.exit(1);
    }
    throw error; // Never reached, but satisfies TypeScript
  }
}

function main(): void {
  const args = process.argv.slice(2);
  const { inputFile, format, outputPath, includeTotals } = parseArgs(args);

  // Load and validate data
  const data = loadJsonFile(inputFile);

  // Get the appropriate formatter
  const formatter = getFormatter(format);

  // Render the report
  const output = formatter(data, { includeTotals });

  // Write output
  if (outputPath) {
    fs.writeFileSync(outputPath, output, 'utf-8');
  } else {
    console.log(output);
  }
}

try {
  main();
} catch (error) {
  if (error instanceof Error && error.message.includes('Unsupported format')) {
    console.error(error.message);
    process.exit(1);
  } else {
    throw error;
  }
}
