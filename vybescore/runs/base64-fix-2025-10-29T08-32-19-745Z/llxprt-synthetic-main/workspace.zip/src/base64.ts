/**
 * Encode plain text to Base64 using RFC 4648 canonical alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Empty input is not valid Base64');
  }

  // Strip whitespace to handle inputs with spaces/newlines
  const trimmedInput = input.replace(/\s+/g, '');

  // Validate Base64 characters - only A-Z, a-z, 0-9, +, /, and optional padding
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(trimmedInput)) {
    throw new Error('Invalid Base64 characters in input');
  }

  try {
    return Buffer.from(trimmedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
