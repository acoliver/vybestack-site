import express, { Request, Response } from "express";
import path from "path";
import { fileURLToPath } from "url";
import { dbManager } from "./database.js";
import { validateFormData, sanitizeFormData } from "./validation.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app = express();
const PORT = process.env.PORT || 3535;

// View engine setup
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "public")));

// Routes

// GET / - Render contact form
app.get("/", async (req: Request, res: Response) => {
  res.render("index", { 
    errors: [],
    formData: {}
  });
});

// POST /submit - Handle form submission
app.post("/submit", async (req: Request, res: Response) => {
  try {
    const sanitizedData = sanitizeFormData(req.body);
    const errors = validateFormData(sanitizedData);

    if (errors.length > 0) {
      // Re-render form with errors and previously entered values
      res.status(400).render("index", {
        errors,
        formData: sanitizedData
      });
      return;
    }

    // Validation passed - insert into database
    await dbManager.insertSubmission(sanitizedData);

    // Redirect to thank you page
    res.redirect("/thank-you");
  } catch (error) {
    console.error("Error processing submission:", error);
    res.status(500).render("index", {
      errors: [{ field: "general", message: "An error occurred. Please try again." }],
      formData: sanitizeFormData(req.body)
    });
  }
});

// GET /thank-you - Thank you page
app.get("/thank-you", (req: Request, res: Response) => {
  res.render("thank-you");
});

// Graceful shutdown handler
process.on("SIGTERM", async () => {
  console.log("SIGTERM received, shutting down gracefully...");
  await dbManager.close();
  process.exit(0);
});

process.on("SIGINT", async () => {
  console.log("SIGINT received, shutting down gracefully...");
  await dbManager.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log("Database initialized successfully");

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
}

// Only start server if this file is run directly (not imported for tests)
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(error => {
    console.error("Startup error:", error);
    process.exit(1);
  });
}
