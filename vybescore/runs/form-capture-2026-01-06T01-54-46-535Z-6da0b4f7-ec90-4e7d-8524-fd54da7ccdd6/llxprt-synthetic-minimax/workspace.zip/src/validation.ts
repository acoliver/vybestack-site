export interface ValidationError {
  field: string;
  message: string;
}

export interface FormData extends Record<string, unknown> {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export function validateFormData(data: Record<string, unknown>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'first_name',
    'last_name', 
    'street_address',
    'city',
    'state_province',
    'postal_code',
    'country',
    'email',
    'phone'
  ];

  requiredFields.forEach(field => {
    const value = data[field];
    if (!value || typeof value !== 'string' || value.trim() === '') {
      const fieldStr = String(field);
      errors.push({
        field: fieldStr,
        message: `${fieldStr.replace(/_/g, ' ')} is required`
      });
    }
  });

  // Email validation
  if (data.email && typeof data.email === 'string') {
    const emailValue = data.email.trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(emailValue)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }
  }

  // Phone validation (allow international formats)
  if (data.phone && typeof data.phone === 'string') {
    const phoneValue = data.phone.trim();
    // Check if phone contains only valid characters and has reasonable digit count
    const validChars = /^[0-9\s()+-]+$/.test(phoneValue);
    const digitCount = phoneValue.replace(/[^\d]/g, '').length;
    const hasReasonableLength = digitCount >= 7;
    
    if (!validChars || !hasReasonableLength) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number'
      });
    }
  }

  // Postal code validation (alphanumeric)
  if (data.postal_code && typeof data.postal_code === 'string') {
    const postalValue = data.postal_code.trim();
    // Check if postal code contains only valid characters and has reasonable length
    const validChars = /^[A-Za-z0-9\s-]+$/.test(postalValue);
    const reasonableLength = postalValue.length >= 3 && postalValue.length <= 15;
    
    if (!validChars || !reasonableLength) {
      errors.push({
        field: 'postal_code',
        message: 'Please enter a valid postal code'
      });
    }
  }

  return errors;
}

export function sanitizeFormData(data: Record<string, unknown>): FormData {
  return {
    first_name: typeof data.first_name === 'string' ? data.first_name.trim() : '',
    last_name: typeof data.last_name === 'string' ? data.last_name.trim() : '',
    street_address: typeof data.street_address === 'string' ? data.street_address.trim() : '',
    city: typeof data.city === 'string' ? data.city.trim() : '',
    state_province: typeof data.state_province === 'string' ? data.state_province.trim() : '',
    postal_code: typeof data.postal_code === 'string' ? data.postal_code.trim() : '',
    country: typeof data.country === 'string' ? data.country.trim() : '',
    email: typeof data.email === 'string' ? data.email.trim() : '',
    phone: typeof data.phone === 'string' ? data.phone.trim() : ''
  };
}