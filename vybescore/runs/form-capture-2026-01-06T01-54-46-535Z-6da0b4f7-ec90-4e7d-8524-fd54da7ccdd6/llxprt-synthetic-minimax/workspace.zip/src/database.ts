import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'fs';
import path from 'path';

export interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;

  async initialize(): Promise<void> {
    this.sqlJs = await initSqlJs({
      locateFile: (file: string) => {
        return `node_modules/sql.js/dist/${file}`;
      }
    });

    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    
    if (fs.existsSync(dbPath)) {
      const fileContents = fs.readFileSync(dbPath);
      if (this.sqlJs) {
        this.db = new this.sqlJs.Database(fileContents);
      }
    } else {
      if (this.sqlJs) {
        this.db = new this.sqlJs.Database();
        await this.initializeSchema();
      }
    }
  }

  private async initializeSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      this.db.exec(schema);
    }
  }

  async insertSubmission(data: SubmissionData): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();
    await this.saveToDisk();
  }

  private async saveToDisk(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    const data = this.db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();