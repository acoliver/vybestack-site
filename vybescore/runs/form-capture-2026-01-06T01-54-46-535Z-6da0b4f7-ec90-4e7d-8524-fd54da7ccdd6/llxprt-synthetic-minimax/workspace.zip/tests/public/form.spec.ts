import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import type { Express } from 'express';

const dbPath = 'data/submissions.sqlite';

describe('friendly form (public smoke)', () => {
  let server: ReturnType<Express['listen']>;
  let dbManager: unknown;

  beforeAll(async () => {
    // Initialize database first
    const { dbManager: db } = await import('../../dist/database.js');
    dbManager = db;
    await dbManager.initialize();
    
    // Import the built server module
    const { app } = await import('../../dist/server.js');
    server = app.listen(0); // Use port 0 to get a random available port
  });

  afterAll(async () => {
    if (server && server.close) {
      await new Promise(resolve => server.close(resolve));
    }
    // Clean up database
    await dbManager.close();
  });

  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    
    const html = response.text as string;
    expect(html.includes('name="first_name"')).toBe(true);
    expect(html.includes('name="last_name"')).toBe(true);
    expect(html.includes('name="street_address"')).toBe(true);
    expect(html.includes('name="city"')).toBe(true);
    expect(html.includes('name="state_province"')).toBe(true);
    expect(html.includes('name="postal_code"')).toBe(true);
    expect(html.includes('name="country"')).toBe(true);
    expect(html.includes('name="email"')).toBe(true);
    expect(html.includes('name="phone"')).toBe(true);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const submissionData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Springfield',
      state_province: 'IL',
      postal_code: '62704',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1-555-123-4567'
    };

    const response = await request(server)
      .post('/submit')
      .send(submissionData);

    expect(response.status).toBe(302);
    expect(response.header.location).toBe('/thank-you');
  });
});
