// Shared interfaces for the report builder CLI

export interface Entry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: Entry[];
}

export interface CLIOptions {
  format: 'markdown' | 'text';
  includeTotals: boolean;
  outputPath?: string;
}

export interface Formatter {
  format(data: ReportData, includeTotals: boolean): string;
}