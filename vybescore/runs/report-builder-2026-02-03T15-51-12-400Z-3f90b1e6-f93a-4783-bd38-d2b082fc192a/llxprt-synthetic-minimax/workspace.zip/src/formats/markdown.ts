import { ReportData } from '../types/index.js';

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  let output = `# ${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `## Entries\n`;

  let total = 0;
  for (const entry of data.entries) {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    output += `- **${entry.label}** — ${formattedAmount}\n`;
    total += entry.amount;
  }

  if (includeTotals) {
    const formattedTotal = `$${total.toFixed(2)}`;
    output += `\n**Total:** ${formattedTotal}`;
  }

  return output;
}