#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { formatters } from '../formats/index.js';
import type { ReportData } from '../types/index.js';

interface ParsedArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 4) {
    printUsage();
    process.exit(1);
  }

  const dataPath = resolve(args[2]);
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments manually
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = args[i + 1];
        i++; // Skip next argument as it's the value
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        outputPath = resolve(args[i + 1]);
        i++; // Skip next argument as it's the value
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (!format && !outputPath && !includeTotals && !arg.startsWith('--')) {
          console.error(`Error: Unknown argument '${arg}'`);
          printUsage();
          process.exit(1);
        }
        break;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    printUsage();
    process.exit(1);
  }

  return {
    dataPath,
    format,
    outputPath,
    includeTotals
  };
}

function printUsage(): void {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('Formats: markdown, text');
}

function validateAndParseJSON(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "summary" field');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Invalid JSON: missing or invalid "entries" field');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid JSON: entry ${i + 1} missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number' || !isFinite(entry.amount)) {
        throw new Error(`Invalid JSON: entry ${i + 1} missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file '${filePath}': ${error.message}`);
      process.exit(1);
    }
    
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    
    console.error(`Error: Unexpected error reading file '${filePath}'`);
    process.exit(1);
  }
}

function validateFormat(format: string): 'markdown' | 'text' {
  const validFormats = ['markdown', 'text'] as const;
  
  if (!validFormats.includes(format as 'markdown' | 'text')) {
    console.error(`Error: Unsupported format '${format}'. Supported formats: ${validFormats.join(', ')}`);
    process.exit(1);
  }
  
  return format as 'markdown' | 'text';
}

function formatOutput(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  const formatter = formatters[format];
  
  if (!formatter) {
    console.error(`Error: Unsupported format '${format}'`);
    process.exit(1);
  }
  
  return formatter(data, includeTotals);
}

// Main execution
function main(): void {
  const args = process.argv;
  const parsed = parseArgs(args);
  const format = validateFormat(parsed.format);
  const data = validateAndParseJSON(parsed.dataPath);
  const output = formatOutput(data, format, parsed.includeTotals);
  
  if (parsed.outputPath) {
    try {
      writeFileSync(parsed.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file '${parsed.outputPath}': ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();
