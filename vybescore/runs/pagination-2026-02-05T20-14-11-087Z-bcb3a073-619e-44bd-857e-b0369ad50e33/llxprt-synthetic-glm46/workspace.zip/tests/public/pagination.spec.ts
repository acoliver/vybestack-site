import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API pagination', () => {
  it('returns first page with default limit when no params provided', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('returns specified page and limit', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBe(3);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    
    // Check that items are from pages 2 (items 4-6 based on zero-based offset)
    expect(response.body.items[0].id).toBe(4);
    expect(response.body.items[2].id).toBe(6);
  });

  it('validates page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response1 = await request(app).get('/inventory?page=0');
    expect(response1.status).toBe(400);
    expect(response1.body.error).toBe('Page must be a positive integer');

    const response2 = await request(app).get('/inventory?page=-1');
    expect(response2.status).toBe(400);
    expect(response2.body.error).toBe('Page must be a positive integer');

    const response3 = await request(app).get('/inventory?page=abc');
    expect(response3.status).toBe(400);
    expect(response3.body.error).toBe('Page must be a positive integer');

    const response4 = await request(app).get('/inventory?page=1001');
    expect(response4.status).toBe(400);
    expect(response4.body.error).toBe('Page number too large');
  });

  it('validates limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response1 = await request(app).get('/inventory?limit=0');
    expect(response1.status).toBe(400);
    expect(response1.body.error).toBe('Limit must be a positive integer');

    const response2 = await request(app).get('/inventory?limit=-5');
    expect(response2.status).toBe(400);
    expect(response2.body.error).toBe('Limit must be a positive integer');

    const response3 = await request(app).get('/inventory?limit=xyz');
    expect(response3.status).toBe(400);
    expect(response3.body.error).toBe('Limit must be a positive integer');

    const response4 = await request(app).get('/inventory?limit=101');
    expect(response4.status).toBe(400);
    expect(response4.body.error).toBe('Limit too large');
  });

  it('calculates hasNext correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Page 1 with limit 5 should have next
    const response1 = await request(app).get('/inventory?page=1&limit=5');
    expect(response1.status).toBe(200);
    expect(response1.body.hasNext).toBe(true);
    
    // Page 3 with limit 5 should not have next (last page)
    const response2 = await request(app).get('/inventory?page=3&limit=5');
    expect(response2.status).toBe(200);
    expect(response2.body.hasNext).toBe(false);
    
    // Page 3 with limit 4 should not have next (last page with 3 items)
    const response3 = await request(app).get('/inventory?page=4&limit=4');
    expect(response3.status).toBe(200);
    expect(response3.body.hasNext).toBe(false);
    expect(response3.body.items.length).toBe(3);
  });
});