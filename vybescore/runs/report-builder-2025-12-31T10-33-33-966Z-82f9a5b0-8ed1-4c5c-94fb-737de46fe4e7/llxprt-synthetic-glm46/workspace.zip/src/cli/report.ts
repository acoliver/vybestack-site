#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, CliOptions, FormatRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArguments(args: string[]): { dataPath: string; options: CliOptions } {
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  // Get data path (first argument after script name)
  let dataPath = '';
  const options: CliOptions = {
    format: 'markdown', // default
    includeTotals: false,
  };

  // Parse arguments
  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    
    if (arg.startsWith('--')) {
      // Handle options
      if (arg === '--format') {
        const format = args[i + 1];
        if (!format || !['markdown', 'text'].includes(format)) {
          console.error('Unsupported format');
          process.exit(1);
        }
        options.format = format as 'markdown' | 'text';
        i++; // skip the next argument
      } else if (arg === '--output') {
        const outputPath = args[i + 1];
        if (!outputPath) {
          console.error('Output path is required');
          process.exit(1);
        }
        options.output = outputPath;
        i++; // skip the next argument
      } else if (arg === '--includeTotals') {
        options.includeTotals = true;
      } else {
        console.error(`Unknown argument: ${arg}`);
        process.exit(1);
      }
    } else {
      // Handle positional arguments (data path)
      if (!dataPath) {
        dataPath = arg;
      } else {
        console.error(`Unexpected argument: ${arg}`);
        process.exit(1);
      }
    }
  }

  if (!dataPath) {
    console.error('Data path is required');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return { dataPath, options };
}

function validateReportData(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    console.error('Invalid data: expected object');
    return false;
  }

  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string') {
    console.error('Invalid data: title must be a string');
    return false;
  }

  if (typeof reportData.summary !== 'string') {
    console.error('Invalid data: summary must be a string');
    return false;
  }

  if (!Array.isArray(reportData.entries)) {
    console.error('Invalid data: entries must be an array');
    return false;
  }

  for (const entry of reportData.entries) {
    if (!entry || typeof entry !== 'object') {
      console.error('Invalid data: each entry must be an object');
      return false;
    }

    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      console.error('Invalid data: each entry must have a string label');
      return false;
    }

    if (typeof entryObj.amount !== 'number') {
      console.error('Invalid data: each entry must have a number amount');
      return false;
    }
  }

  return true;
}

function main() {
  const args = process.argv;
  const { dataPath, options } = parseArguments(args);

  try {
    const fileContent = readFileSync(dataPath, 'utf8');
    const data = JSON.parse(fileContent);
    
    if (!validateReportData(data)) {
      process.exit(1);
    }

    const formatter = formatters[options.format];
    if (!formatter) {
      console.error('Unsupported format');
      process.exit(1);
    }

    const result = formatter(data, options.includeTotals);

    if (options.output) {
      writeFileSync(options.output, result);
      console.log(`Report written to ${options.output}`);
    } else {
      console.log(result);
    }
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Invalid JSON in data file');
    } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Unable to locate file: ${dataPath}`);
    } else {
      console.error(`Unable to read file: ${dataPath}`);
    }
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
