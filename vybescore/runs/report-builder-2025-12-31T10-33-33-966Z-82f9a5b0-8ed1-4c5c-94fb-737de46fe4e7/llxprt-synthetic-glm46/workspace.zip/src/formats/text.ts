import type { FormatRenderer } from '../types.js';

export const renderText: FormatRenderer = (data, includeTotals = false) => {
  const lines: string[] = [];
  
  // Add title
  lines.push(data.title);
  lines.push('');
  
  // Add summary
  lines.push(data.summary);
  lines.push('');
  
  // Add entries header
  lines.push('Entries:');
  
  // Add each entry as a bulleted list
  data.entries.forEach(entry => {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  });
  
  // Add total if requested
  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: $${total.toFixed(2)}`);
  }
  
return lines.join('\n');
};