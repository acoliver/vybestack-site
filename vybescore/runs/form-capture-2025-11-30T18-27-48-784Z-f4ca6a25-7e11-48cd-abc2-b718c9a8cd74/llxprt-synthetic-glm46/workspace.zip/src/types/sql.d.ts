declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    export(): Uint8Array;
    close(): void;
  }
  
  export interface SqlJsStatic {
    Database: new (data?: ArrayBuffer) => Database;
  }
  
  export default function initSqlJs(): Promise<SqlJsStatic>;
}