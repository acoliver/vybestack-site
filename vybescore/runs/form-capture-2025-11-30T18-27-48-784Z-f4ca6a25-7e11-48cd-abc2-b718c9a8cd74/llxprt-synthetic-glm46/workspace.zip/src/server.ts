import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

interface Database {
  run(sql: string, ...params: unknown[]): void;
  export(): Uint8Array;
  close(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const PORT = process.env.PORT || 3535;
const app = express();
const dataDir = path.join(__dirname, '..', 'data');
const dbPath = path.join(dataDir, 'submissions.sqlite');

let db: Database | null = null;

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  let dbInstance: Database;
  
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    const arrayBuffer = fileBuffer.buffer.slice(fileBuffer.byteOffset, fileBuffer.byteOffset + fileBuffer.byteLength);
    dbInstance = new SQL.Database(arrayBuffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }
  
  return dbInstance;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, numbers, spaces, and hyphens' });
  }
  
  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^\+?[\d\s\-()]+$/.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, hyphens, parentheses, and an optional leading +' });
  }
  
  return errors;
}

async function startServer(): Promise<void> {
  db = await initializeDatabase();
  
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.join(__dirname, '..', 'public')));
  
  app.set('view engine', 'ejs');
  const templatesPath = path.join(__dirname.replace('/dist/', '/src/'), 'templates');
  app.set('views', templatesPath);
  
  // Copy templates to dist directory if they don't exist
  const distTemplatesPath = path.join(__dirname, 'templates');
  if (!fs.existsSync(distTemplatesPath)) {
    fs.mkdirSync(distTemplatesPath, { recursive: true });
    const formTemplate = fs.readFileSync(path.join(templatesPath, 'form.ejs'));
    const thankYouTemplate = fs.readFileSync(path.join(templatesPath, 'thank-you.ejs'));
    fs.writeFileSync(path.join(distTemplatesPath, 'form.ejs'), formTemplate);
    fs.writeFileSync(path.join(distTemplatesPath, 'thank-you.ejs'), thankYouTemplate);
  }
  
  app.get('/', (req, res) => {
    res.render('form', { 
      errors: [], 
      values: {} 
    });
  });
  
  app.post('/submit', (req, res) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const errors = validateForm(formData);
    
    if (errors.length > 0) {
      res.status(400).render('form', {
        errors: errors.map(e => e.message),
        values: formData
      });
      return;
    }
    
    try {
      db!.run(
        `INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]
      );
      
      saveDatabase(db!);
      
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).render('form', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: formData
      });
    }
  });
  
  app.get('/thank-you', (req, res) => {
    res.render('thank-you');
  });
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  
  const gracefulShutdown = (signal: string) => {
    console.log(`Received ${signal}, shutting down gracefully...`);
    
    server.close(() => {
      console.log('Express server closed');
      
      if (db) {
        db.close();
        db = null;
        console.log('Database connection closed');
      }
      
      process.exit(0);
    });
    
    setTimeout(() => {
      console.error('Forced shutdown');
      process.exit(1);
    }, 5000);
  };
  
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
