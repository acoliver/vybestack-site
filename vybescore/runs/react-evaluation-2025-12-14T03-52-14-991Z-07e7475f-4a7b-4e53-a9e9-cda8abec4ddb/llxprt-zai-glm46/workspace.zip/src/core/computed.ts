/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getCurrentTracker,
  setCurrentTracker,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = 
    _equal === true ? ((a, b) => a === b) :
    _equal === false || _equal === undefined ? undefined :
    _equal

  let currentValue = value
  let isDirty = true
  let disposed = false
  const dependencies = new Set<unknown>()
  const observers = new Set<() => void>()
  const unsubscribers = new Array<() => void>()
  let isComputing = false

  function recompute(): void {
    if (isComputing || disposed) return
    
    // Check for circular dependency
    const trackingStack: unknown[] = (globalThis as typeof globalThis & { __reactiveStack?: unknown[] }).__reactiveStack || []
    
    if (trackingStack.includes(getter)) {
      // Circular dependency detected - stop here
      return
    }
    
    isComputing = true
    
    try {
      // Clear previous subscriptions
      unsubscribers.forEach(unsub => unsub())
      unsubscribers.length = 0
      dependencies.clear()
      
      trackingStack.push(getter)
      ;(globalThis as typeof globalThis & { __reactiveStack?: unknown[] }).__reactiveStack = trackingStack
      
      try {
        // Create dependency tracker
        const depTracker = {
          track: (dep: unknown) => {
            if (!dependencies.has(dep) && !disposed) {
              dependencies.add(dep)
              const getterWithSubscribe = dep as { subscribe?: (observer: () => void) => () => void }
              if (getterWithSubscribe.subscribe) {
                const unsub = getterWithSubscribe.subscribe(() => {
                  if (!isComputing && !disposed) {
                    isDirty = true
                    // Synchronous recompute to ensure values are up-to-date
                    recompute()
                  }
                })
                if (!disposed) {
                  unsubscribers.push(unsub)
                }
              }
            }
          }
        }
        
        const previousTracker = getCurrentTracker()
        setCurrentTracker(depTracker)
        
        const oldValue = currentValue
        currentValue = updateFn(currentValue)
        
        // Check if value actually changed
        const changed = !equalFn || !equalFn(oldValue!, currentValue!)
        isDirty = false
        
        if (changed) {
          notifyObservers()
        }
        
        setCurrentTracker(previousTracker)
      } finally {
        trackingStack.pop()
        ;(globalThis as typeof globalThis & { __reactiveStack?: unknown[] }).__reactiveStack = trackingStack
      }
    } finally {
      isComputing = false
    }
  }

  function notifyObservers(): void {
    if (disposed) return
    // Notify observers synchronously to ensure values are up-to-date
    observers.forEach(observer => {
      try {
        observer()
      } catch (error) {
        console.error('Error in reactive observer:', error)
      }
    })
  }

  const getter: GetterFn<T> = () => {
    if (disposed) return currentValue!
    
    // Legacy observer tracking for backward compatibility
    const observer = getActiveObserver()
    if (observer) {
      const legacyObserver = observer as any
      if (legacyObserver.updateFn && typeof legacyObserver.updateFn === 'function') {
        // Set the current value before calling updateFn so it can use it
        legacyObserver.value = currentValue
        updateObserver(legacyObserver)
      }
    }
    
    if (isDirty) {
      recompute()
    }
    return currentValue!
  }

  // Add subscribe method to the getter
  (getter as GetterFn<T> & { subscribe: (observer: () => void) => () => void }).subscribe = (observer: () => void) => {
    if (disposed) return () => {}
    observers.add(observer)
    return () => observers.delete(observer)
  }

  // Add dispose method for cleanup
  ;(getter as GetterFn<T> & { subscribe: (observer: () => void) => () => void; dispose: () => void }).dispose = () => {
    if (disposed) return
    disposed = true
    unsubscribers.forEach(unsub => unsub())
    unsubscribers.length = 0
    observers.clear()
    dependencies.clear()
  }

  return getter
}