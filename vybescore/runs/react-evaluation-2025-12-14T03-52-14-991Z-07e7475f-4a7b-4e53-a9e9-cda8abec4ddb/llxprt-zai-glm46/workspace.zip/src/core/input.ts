/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  getCurrentTracker
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = 
    _equal === true ? ((a, b) => a === b) :
    _equal === false || _equal === undefined ? undefined :
    _equal

  // Create the core reactive input
  let currentValue = value
  const observers = new Set<() => void>()

  const read: GetterFn<T> = () => {
    // Register this input as a dependency for the current reactive computation
    const tracker = getCurrentTracker()
    if (tracker) {
      tracker.track(read)
    }
    
    // Legacy observer tracking for backward compatibility
    const observer = getActiveObserver()
    if (observer) {
      const legacyObserver = observer as Observer<T>
      // Set the current value before calling updateFn so it can use it
      legacyObserver.value = currentValue
      updateObserver(legacyObserver)
    }
    
    return currentValue
  }

  const write: SetterFn<T> = (nextValue) => {
    const changed = !equalFn || !equalFn(currentValue, nextValue)
    if (changed) {
      currentValue = nextValue
      notifyObservers()
    }
    return currentValue
  }

  function notifyObservers(): void {
    // Notify all reactive observers asynchronously to prevent call stack issues
    setTimeout(() => {
      observers.forEach(observer => {
        try {
          observer()
        } catch (error) {
          // Ignore errors to prevent breaking the reactive system
        }
      })
      
      // Legacy observer notification
      const observer = getActiveObserver()
      if (observer && 'updateFn' in observer) {
        updateObserver(observer as Observer<T>)
      }
    }, 0)
  }

  // Add subscribe method to the getter for reactive observers
  (read as GetterFn<T> & { subscribe: (observer: () => void) => () => void }).subscribe = (observer: () => void) => {
    observers.add(observer)
    return () => observers.delete(observer)
  }

  return [read, write]
}