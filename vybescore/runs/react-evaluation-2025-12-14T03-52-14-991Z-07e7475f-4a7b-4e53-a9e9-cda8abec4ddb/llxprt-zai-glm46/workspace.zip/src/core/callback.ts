/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getCurrentTracker, setCurrentTracker } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  const unsubscribers = new Array<() => void>()
  const dependencies = new Set<unknown>()

  function trackDependency(dep: unknown): void {
    if (disposed) return
    dependencies.add(dep)
    const getterWithSubscribe = dep as { subscribe?: (observer: () => void) => () => void }
    if (getterWithSubscribe.subscribe) {
      const unsub = getterWithSubscribe.subscribe(() => {
        if (!disposed) {
          setTimeout(execute, 0)
        }
      })
      unsubscribers.push(unsub)
    }
  }

  function execute(): void {
    if (disposed) return
    
    // Set up dependency tracking for this execution
    const tracker = { track: trackDependency }
    const previousTracker = getCurrentTracker()
    setCurrentTracker(tracker)
    
    try {
      updateFn(value)
    } catch (error) {
      // Silently ignore errors in callbacks to not break the reactive system
      console.error('Error in callback:', error)
    } finally {
      // Restore previous tracker
      setCurrentTracker(previousTracker)
    }
  }

  // Legacy observer support for backward compatibility
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  updateObserver(observer)

  // Initial execution to set up dependencies
  execute()

  return () => {
    if (disposed) return
    disposed = true
    unsubscribers.forEach(unsub => unsub())
    unsubscribers.length = 0
    dependencies.clear()
  }
}