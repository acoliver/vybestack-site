import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  currentPage, 
  hasNext, 
  totalItems, 
  onPageChange 
}: { 
  currentPage: number; 
  hasNext: boolean; 
  totalItems: number;
  onPageChange: (page: number) => void;
}): JSX.Element {
  return (
    <div style={{ marginTop: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
      <button 
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage <= 1}
        style={{ padding: '0.25rem 0.5rem' }}
      >
        Previous
      </button>
      
      <span>Page {currentPage}</span>
      
      <button 
        onClick={() => onPageChange(currentPage + 1)}
        disabled={!hasNext}
        style={{ padding: '0.25rem 0.5rem' }}
      >
        Next
      </button>
      
      <span style={{ marginLeft: '1rem', color: '#666' }}>
        ({totalItems} total items)
      </span>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert" style={{ color: 'red' }}>{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls 
        currentPage={currentPage}
        hasNext={data.hasNext}
        totalItems={data.total}
        onPageChange={setCurrentPage}
      />
    </section>
  );
}
