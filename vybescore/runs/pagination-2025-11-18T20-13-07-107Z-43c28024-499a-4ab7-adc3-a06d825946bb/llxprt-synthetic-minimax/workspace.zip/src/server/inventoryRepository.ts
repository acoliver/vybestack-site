import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

interface DatabaseRow {
  id: unknown;
  name: unknown;
  sku: unknown;
  price_cents: unknown;
  created_at: unknown;
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  const dbRow = row as unknown as DatabaseRow;
  return {
    id: Number(dbRow.id),
    name: String(dbRow.name),
    sku: String(dbRow.sku),
    priceCents: Number(dbRow.price_cents),
    createdAt: String(dbRow.created_at)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;

  const offset = (page - 1) * limit;

  const stmt = db.prepare(`
    SELECT * FROM inventory 
    ORDER BY id 
    LIMIT ? OFFSET ?
  `);
  stmt.bind([limit, offset]);

  const items: InventoryItem[] = [];
  while (stmt.step()) {
    items.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items,
    page,
    limit,
    total,
    hasNext
  };
}

interface ValidationError extends Error {
  status: number;
}

export function validatePaginationParams(pageParam?: string, limitParam?: string): { page: number; limit: number } {
  const errors: string[] = [];
  
  if (pageParam !== undefined) {
    const page = Number(pageParam);
    if (isNaN(page) || page <= 0 || !Number.isInteger(page)) {
      errors.push('page must be a positive integer');
    } else if (page > 1000) {
      errors.push('page must be less than or equal to 1000');
    }
  }
  
  if (limitParam !== undefined) {
    const limit = Number(limitParam);
    if (isNaN(limit) || limit <= 0 || !Number.isInteger(limit)) {
      errors.push('limit must be a positive integer');
    } else if (limit > 100) {
      errors.push('limit must be less than or equal to 100');
    }
  }
  
  if (errors.length > 0) {
    const error = new Error(`Invalid pagination parameters: ${errors.join(', ')}`) as ValidationError;
    error.status = 400;
    throw error;
  }
  
  return {
    page: pageParam ? Number(pageParam) : 1,
    limit: limitParam ? Number(limitParam) : DEFAULT_LIMIT
  };
}