import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory, validatePaginationParams } from './inventoryRepository';

interface ApiError extends Error {
  status?: number;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    try {
      const { page, limit } = validatePaginationParams(pageParam, limitParam);
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const apiError = error as ApiError;
      const status = apiError.status || 500;
      res.status(status).json({
        error: apiError.message
      });
    }
  });

  return app;
}
