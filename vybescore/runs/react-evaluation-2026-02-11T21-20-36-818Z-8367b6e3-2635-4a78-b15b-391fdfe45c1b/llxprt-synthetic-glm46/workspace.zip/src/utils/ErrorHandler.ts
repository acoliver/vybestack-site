/**
* Error handling utilities
*/

import { toast } from 'react-toastify';

export class AppError extends Error {
  statusCode: number;
  isOperational: boolean;

  constructor(message: string, statusCode = 500, isOperational = true) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    
    Error.captureStackTrace(this, this.constructor);
  }
}

export class ErrorHandler {
  static logError(error: Error, context?: string): void {
    console.error(`Error in ${context || 'unknown context'}:`, error);
  }
  
  static handle(error: Error, context?: string): void {
    this.logError(error, context);
    
    if (error instanceof AppError) {
      if (error.isOperational) {
        toast.error(error.message);
      } else {
        toast.error('An unexpected error occurred. Please try again.');
      }
    } else {
      toast.error('An unexpected error occurred. Please try again.');
    }
  }
  
  static async wrapAsync<T>(
    operation: () => Promise<T>,
    context?: string
  ): Promise<[T | null, Error | null]> {
    try {
      const result = await operation();
      return [result, null];
    } catch (error) {
      this.handle(error as Error, context);
      return [null, error as Error];
    }
  }
}