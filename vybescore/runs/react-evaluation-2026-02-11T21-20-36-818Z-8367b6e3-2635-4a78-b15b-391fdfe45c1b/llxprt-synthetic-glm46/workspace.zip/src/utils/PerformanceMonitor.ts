/**
 * Performance monitoring utilities for React components
 */

export interface PerformanceMetrics {
  renderTime: number;
  renderCount: number;
  averageRenderTime: number;
  maxRenderTime: number;
  minRenderTime: number;
  lastRenderDate: Date;
  totalRenderTime: number;
}

export class PerformanceMonitor {
  private static instances = new Map<string, PerformanceMonitor>();
  private metrics: PerformanceMetrics;
  private startTimes: Map<number, number> = new Map();
  private renderId = 0;

  constructor(private componentName: string) {
    this.metrics = {
      renderTime: 0,
      renderCount: 0,
      averageRenderTime: 0,
      maxRenderTime: 0,
      minRenderTime: Infinity,
      lastRenderDate: new Date(),
      totalRenderTime: 0
    };

    // Store instance for retrieval
    if (!PerformanceMonitor.instances.has(componentName)) {
      PerformanceMonitor.instances.set(componentName, this);
    }
  }

  // Start measuring render time
  startRender(): number {
    this.renderId++;
    const startTime = performance.now();
    this.startTimes.set(this.renderId, startTime);
    return this.renderId;
  }

  // End measuring render time and update metrics
  endRender(renderId: number): number {
    const endTime = performance.now();
    const startTime = this.startTimes.get(renderId);
    
    if (startTime === undefined) {
      console.error(`PerformanceMonitor: No start time found for render ${renderId}`);
      return 0;
    }

    const renderTime = endTime - startTime;
    this.updateMetrics(renderTime);
    
    return renderTime;
  }

  // Update performance metrics
  private updateMetrics(renderTime: number): void {
    this.metrics.renderCount++;
    this.metrics.renderTime = renderTime;
    this.metrics.totalRenderTime += renderTime;
    this.metrics.averageRenderTime = this.metrics.totalRenderTime / this.metrics.renderCount;
    this.metrics.maxRenderTime = Math.max(this.metrics.maxRenderTime, renderTime);
    this.metrics.minRenderTime = Math.min(this.metrics.minRenderTime, renderTime);
    this.metrics.lastRenderDate = new Date();

    this.startTimes.delete(this.renderId);
  }

  // Get current metrics
  getMetrics(): PerformanceMetrics {
    return { ...this.metrics };
  }

  // Reset metrics
  resetMetrics(): void {
    this.metrics = {
      renderTime: 0,
      renderCount: 0,
      averageRenderTime: 0,
      maxRenderTime: 0,
      minRenderTime: Infinity,
      lastRenderDate: new Date(),
      totalRenderTime: 0
    };
    this.startTimes.clear();
  }

  // Get performance data for all components
  static getAllMetrics(): Record<string, PerformanceMetrics> {
    const result: Record<string, PerformanceMetrics> = {};
    PerformanceMonitor.instances.forEach((monitor, name) => {
      result[name] = monitor.getMetrics();
    });
    return result;
  }

  // Get slowest components
  static getSlowestComponents(limit: number = 5): Array<{name: string, metrics: PerformanceMetrics}> {
    const components = Array.from(PerformanceMonitor.instances.entries())
      .map(([name, monitor]) => ({name, metrics: monitor.getMetrics()}))
      .sort((a, b) => b.metrics.averageRenderTime - a.metrics.averageRenderTime);
    
    return components.slice(0, limit);
  }

  // Log performance metrics to console
  static logPerformanceSummary(): void {
    const allMetrics = PerformanceMonitor.getAllMetrics();
    const slowest = PerformanceMonitor.getSlowestComponents();
    
    console.group(' React Performance Summary');
    console.log('Components Monitored:', Object.keys(allMetrics).length);
    
    if (slowest.length > 0) {
      console.log('\n Slowest Components:');
      slowest.forEach((item, index) => {
        console.log(`${index + 1}. ${item.name}: ${item.metrics.averageRenderTime.toFixed(2)}ms avg (${item.metrics.renderCount} renders)`);
      });
    }
    
    console.log('\n Detailed Metrics:');
    for (const [name, metrics] of Object.entries(allMetrics)) {
      if (metrics.renderCount > 0) {
        console.log(`${name}: ${metrics.averageRenderTime.toFixed(2)}ms avg, ${metrics.renderCount} renders`);
      }
    }
    console.groupEnd();
  }

  // Clear all monitors
  static clearAllMonitors(): void {
    PerformanceMonitor.instances.forEach(monitor => monitor.resetMetrics());
  }
}

/**
 * React Hook for monitoring component performance
 */
export function usePerformanceMonitor(componentName: string): PerformanceMonitor {
  // Use a ref to ensure we get the same monitor instance across renders
  const monitorRef = React.useRef<PerformanceMonitor>();
  
  if (!monitorRef.current) {
    monitorRef.current = new PerformanceMonitor(componentName);
  }
  
  return monitorRef.current;
}

/**
 * HOC (Higher Order Component) for adding performance monitoring to any component
 */
export function withPerformanceMonitor<P extends object>(
  WrappedComponent: React.ComponentType<P>,
  componentName?: string
): React.ComponentType<P> {
  const displayName = componentName || WrappedComponent.displayName || WrappedComponent.name || 'Component';
  
  const WithPerformanceMonitoring = React.memo((props: P) => {
    const monitor = usePerformanceMonitor(displayName);
    const renderId = React.useRef<number>();
    
    // Start timing before render
    if (typeof window !== 'undefined') {
      renderId.current = monitor.startRender();
    }
    
    // Effect to end timing after render
    React.useEffect(() => {
      if (renderId.current !== undefined) {
        const renderTime = monitor.endRender(renderId.current);
        
        // Optional: Log slow renders
        if (renderTime > 100) {
          console.warn(` Slow render detected for ${displayName}: ${renderTime.toFixed(2)}ms`);
        }
      }
    });
    
    return <WrappedComponent {...props} />;
  });
  
  WithPerformanceMonitoring.displayName = `withPerformanceMonitor(${displayName})`;
  
  return WithPerformanceMonitoring as React.ComponentType<P>;
}