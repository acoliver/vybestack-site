/**
 * Encode plain text to Base64 using RFC 4648 canonical alphabet.
 * Uses standard Base64 with + and / characters and includes required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and recovers the original Unicode string.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Validate Basic64 input format
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Remove whitespace and validate Base64 characters
  const cleanInput = input.trim();
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Regex.test(cleanInput)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for invalid padding (padding must be at the end and max 2 characters)
  const paddingIndex = cleanInput.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = cleanInput.substring(paddingIndex);
    if (padding.length > 2 || padding.includes('=') !== padding.includes(padding[0]) || 
        cleanInput.substring(paddingIndex).match(/[^=]/)) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
  }

  try {
    const result = Buffer.from(cleanInput, 'base64').toString('utf8');
    
    // Additional validation: ensure the input would encode back to the same result
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedEncoded = reencoded.replace(/=+$/, '');
    const normalizedInput = cleanInput.replace(/=+$/, '');
    
    if (normalizedEncoded !== normalizedInput) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}