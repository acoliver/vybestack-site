/**
 * Validate a Base64 string. A valid Base64 string:
 * - Contains only characters from the Base64 alphabet (A-Z, a-z, 0-9, +, /)
 * - May contain padding (=) only at the end, at most 2 characters
 * - Must have a length that is a multiple of 4 when accounting for padding
 */
function isValidBase64(input: string): boolean {
  // Check for invalid characters (anything other than Base64 alphabet or padding)
  const validPattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validPattern.test(input)) {
    return false;
  }

  // Check that padding only appears at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Ensure all characters after first '=' are also '='
    const paddingPart = input.slice(paddingIndex);
    if (!/^=+$/.test(paddingPart)) {
      return false;
    }
    // Ensure no more than 2 padding characters
    if (paddingPart.length > 2) {
      return false;
    }
  }

  // Check length: valid Base64 (with or without padding) must have length
  // that is a multiple of 4 when accounting for padding
  return input.length % 4 === 0;
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /)
 * with padding (=) as required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmedInput = input.trim();

  if (trimmedInput.length === 0) {
    throw new Error('Failed to decode Base64 input: empty string');
  }

  if (!isValidBase64(trimmedInput)) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }

  try {
    const buffer = Buffer.from(trimmedInput, 'base64');
    
    // Check if decoding actually produced meaningful data
    // If the input is invalid base64, Buffer.from may return an empty buffer
    if (buffer.length === 0 && trimmedInput.length > 0) {
      throw new Error('Failed to decode Base64 input: no valid data decoded');
    }

    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
