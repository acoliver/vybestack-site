const fs = require('fs');
let content = fs.readFileSync('src/transformations.ts', 'utf8');
content = content.replace(
  'urlRegex = /\\\\b(?:https?:\\/|www\\.)[^\\s<>\\"]+(?<![.,;:!?()])/g;',
  'urlRegex = /\\b(?:https?:\/\/|www\.)[^\\s<>\"\\]+(?<![.,;:!?()])/g;'
);
fs.writeFileSync('src/transformations.ts', content);
