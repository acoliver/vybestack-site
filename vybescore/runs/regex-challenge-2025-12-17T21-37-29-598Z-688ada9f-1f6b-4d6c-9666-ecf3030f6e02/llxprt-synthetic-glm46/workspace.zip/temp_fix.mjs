import fs from 'fs';
let content = fs.readFileSync('src/transformations.ts', 'utf8');

// Replace the broken urlRegex with the correct one
content = content.replace(
  /urlRegex = \\/\\\\\\\\b\(https?:\\\\\\\\\/|wdaw\?\)/g,
  'urlRegex = /\\b((?:https?:\\/\\/|www\\.)[^\\s<>"\\\\\]+(?<![.,;:!?()]))/g'
);

fs.writeFileSync('src/transformations.ts', content);
console.log('Fixed urlRegex line again');