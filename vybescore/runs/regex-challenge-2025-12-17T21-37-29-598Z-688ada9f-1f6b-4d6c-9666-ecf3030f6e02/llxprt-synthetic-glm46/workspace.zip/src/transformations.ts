/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize the first character of each sentence:
  // - After punctuation marks (?!)
  // - Insert exactly one space between sentences even if input omitted it
  // - Collapse extra spaces while leaving abbreviations intact when possible

  if (!text || typeof text !== 'string') {
    return '';
  }

  // Normalize spacing: ensure exactly one space after sentence-ending punctuation
  // This handles cases where sentences might be directly adjacent
  let result = text;

  // First, ensure there's always a space after sentence-ending punctuation when another sentence follows
  // (\w) captures a letter (case-insensitive)
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');

  // Now handle sentence capitalization while preserving proper spacing
  // Split by sentence delimiters but keep them attached to the text
  result = result.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });

  // Capitalize the very first letter if it's lowercase
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());

  return result;
}

/**
 * TODO: Extract URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Extract URLs from text, ensuring they don't have trailing punctuation
  // Should match:
  // - http:// and https://
  // - www. 
  // - Domains with tlds
  
  // Regex to match URLs while avoiding trailing punctuation
  // Negative lookahead asserts that the URL doesn't end with punctuation
  const urlRegex = /\b((?:https?:\/\/|www\.)[^\s<>"\\\\]+(?<![.,;:!?()]))/g;
  const matches = text.match(urlRegex);
  
  return matches ? matches : [];
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving existing secure URLs untouched
  
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Use regex to replace http:// with https:// 
  // This ensures we only replace HTTP URLs and don't double-apply to HTTPS URLs
  const result = text.replace(/http:\/\//g, 'https://');
  
  return result;
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // For URLs http://example.com/...:
  // - Always upgrade scheme to https://
  // - When path begins with /docs/, rewrite host to docs.example.com
  // - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
  // - Still upgrade scheme even when skipping host rewrite

  if (!text || typeof text !== 'string') {
    return '';
  }

  let result = text.replace(/http:\/\//g, 'https://');

  // Handle docs subdomain rewriting using a manual approach
  // Look for pattern: https://domain/docs/path
  const docsUrlPattern = /(https:\/\/([^/]+)\/(docs\/[^?&=]+))/g;

  result = result.replace(docsUrlPattern, (match, fullUrl, domain, docsPath) => {
    // Check if path contains any of the excluded elements
    // First, we need the full path to check for exclusions
    const fullPath = `/${docsPath}`;
    
    // List of exclusion patterns to check for
    const exclusionPatterns = [
      /\/cgi-bin\//,
      /\?=/,
      /\.jsp$/,
      /\.php$/,
      /\.asp$/,
      /\.aspx$/,
      /\.do$/,
      /\.cgi$/,
      /\.pl$/,
      /\.py$/
    ];

    // If any exclusion pattern is found, don't rewrite the domain
    for (const pattern of exclusionPatterns) {
      if (pattern.test(fullPath)) {
        return match; // Return original URL
      }
    }

    // If we get here, no exclusion patterns matched, so we can rewrite
    return `https://docs.${domain}/${docsPath}`;
  });

  return result;
}

/**
 * TODO: Extract year from mm/dd/yyyy format, return "N/A" for invalid inputs.
 */
export function extractYear(value: string): string {
  // Return the four-digit year for mm/dd/yyyy
  // Return "N/A" if format doesn't match or month/day are invalid

  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Check if the string matches mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth: Record<number, number> = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };

  if (day > daysInMonth[month]) {
    return 'N/A';
  }

  return year;
}