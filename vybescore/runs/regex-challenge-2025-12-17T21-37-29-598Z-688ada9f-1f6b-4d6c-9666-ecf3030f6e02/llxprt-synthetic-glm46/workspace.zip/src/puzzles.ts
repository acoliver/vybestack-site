/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') {
    return [];
  }
  
// Create regex to match words with the given prefix
  // \b matches word boundaries to ensure we're matching whole words
  const prefixedWordRegex = new RegExp(`\\b${prefix}[a-zA-Z0-9]*`, 'g');
  
  // Find all words with the given prefix
  const prefixedWords = text.match(prefixedWordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredWords = prefixedWords.filter(word => {
    // Lowercase both word and exceptions for case-insensitive comparison
    const lowerWord = word.toLowerCase();
    
    return !exceptions.some(exception => {
      const lowerException = exception.toLowerCase();
      
      // Check if the full word matches the exception
      return lowerWord === lowerException;
    });
  });
  
  // Remove duplicates and return unique matches
  return [...new Set(filteredWords)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Return occurrences where the token appears after a digit and not at the start of the string
  // Use lookaheads/lookbehinds
  
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') {
    return [];
  }
  
  // Split the text and search manually for the token after digits
  const result: string[] = [];
  
  // Find all occurrences of token and check if they're preceded by a digit
  let index = 0;
  while ((index = text.indexOf(token, index)) !== -1) {
    // Check if this occurrence is preceded by a digit and not at start
    if (index > 0 && /\d/.test(text[index - 1])) {
      // Include the preceding digit and the token
      const startIndex = index - 1;
      const endIndex = index + token.length;
      const fullMatch = text.substring(startIndex, endIndex);
      result.push(fullMatch);
    }
    
    // Move forward to avoid infinite loop
    index += token.length;
  }
  
  // Remove duplicates and return
  return [...new Set(result)];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Validate password according to policy:
  // - At least 10 characters
  // - One uppercase, one lowercase, one digit, one symbol
  // - No whitespace
  // - No immediate repeated sequences like abab
  
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) {
    return false; // No uppercase
  }
  
  if (!/[a-z]/.test(value)) {
    return false; // No lowercase
  }
  
  if (!/[0-9]/.test(value)) {
    return false; // No digit
  }
  
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false; // No symbol
  }
  
  // Check for immediate repeated sequences
  // This catches patterns like "abab" or "123123"
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result
  
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // First, check for IPv4 addresses and exclude them
  // IPv4 pattern: four groups of 1-3 digits, separated by dots
  const ipv4RegexWithBoundary = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  if (ipv4RegexWithBoundary.test(value) && !/:/.test(value)) {
    // Return false if it's a standalone IPv4 address
    return false;
  }
  
  // IPv6 pattern matching (including shorthand)
  // Full IPv6: 8 groups of 4 hex digits (optional leading zeros can be omitted)
  // Shorthand: :: can replace consecutive groups of zeros
  
  // Full IPv6 pattern with word boundaries
  const fullIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand
  const compressedIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: at start or end
  const startOrEndCompressedRegex = /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b|(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}::\b/;
  
  // IPv6 with trailing IPv4 address (IPv4-mapped IPv6 address)
  const ipv4MappedRegex = /\b(?:[0-9a-fA-F]{1,4}:){7}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // IPv4-mapped with :: shorthand
  const compressedIpv4MappedRegex = /\b::(?:ffff:)?(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // IPv6 address in square brackets (common in URLs)
  const bracketedIPv6Regex = /\[(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}(?:::[a-fA-F0-9]{0,4})*\]/;
  
  return (
    fullIPv6Regex.test(value) ||
    compressedIPv6Regex.test(value) ||
    startOrEndCompressedRegex.test(value) ||
    ipv4MappedRegex.test(value) ||
    compressedIpv4MappedRegex.test(value) ||
    bracketedIPv6Regex.test(value)
  );
}
