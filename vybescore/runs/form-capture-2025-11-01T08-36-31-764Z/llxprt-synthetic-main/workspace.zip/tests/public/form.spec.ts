import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { initSqlJs } from 'sql.js';

let app: any;
const dbPath = path.resolve('data', 'submissions.sqlite');

// Create a test app that doesn't auto-start
beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import modules but don't start server automatically
  const { createServer, gracefulShutdown } = await import('../../dist/server.js');
  
  // Create the app for testing
  app = await createServer();
  
  // Wait a moment for initialization
  await new Promise(resolve => setTimeout(resolve, 1000));
});

afterAll(async () => {
  // Close the server
  if (app && app.gracefulShutdown) {
    app.gracefulShutdown('SIGTERM');
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check if all form fields are present
    expect($('#firstName')).toHaveLength(1);
    expect($('#lastName')).toHaveLength(1);
    expect($('#streetAddress')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#stateProvince')).toHaveLength(1);
    expect($('#postalCode')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
    
    // Check if labels are properly associated with inputs
    $('label').each((i, label) => {
      const labelFor = $(label).attr('for');
      expect(labelFor).toBeTruthy();
      expect($(`#${labelFor}`)).toHaveLength(1);
    });
    
    // Check if CSS is linked
    expect($('link[rel="stylesheet"]').attr('href')).toBe('/public/styles.css');
    
    // Check form action
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'Testland',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit form
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    // Should redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
    
    // Verify redirect URL contains the first name
    expect(response.headers.location).toContain('firstName=John');
    
    // Follow redirect
    const thankYouResponse = await request(app).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);
    
    // Check thank you page contains first name
    const $ = cheerio.load(thankYouResponse.text);
    expect($('.thankyou-card')).toHaveLength(1);
    
    // Also verify that the first name appears in the response
    expect(thankYouResponse.text).toContain('John');
    
    await new Promise(resolve => setTimeout(resolve, 500)); // Wait for DB save
    
    // Verify database exists
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify data was saved
    if (fs.existsSync(dbPath)) {
      // Read database with SQL.js
      const SQL = await initSqlJs();
      const fileBuffer = fs.readFileSync(dbPath);
      const db = new (SQL.Database as any)(fileBuffer);
      const result = db.exec('SELECT * FROM submissions');
      
      // Should have one submission
      expect(result[0].values).toHaveLength(1);
      
      // Verify data matches
      const submission = result[0].values[0];
      expect(submission[1]).toBe('John'); // first_name
      expect(submission[2]).toBe('Doe'); // last_name
      expect(submission[7]).toBe('john@example.com'); // email
      
      db.close();
    }
  });
});
