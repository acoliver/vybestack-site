import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

// Define Database interface inline since type definitions aren't available
interface Database {
  run(sql: string, params?: any[]): any;
  exec(sql: string): any[];
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(params?: any[]): any;
  get(params?: any[]): any;
  free(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize express app
const app = express();
const PORT = process.env.PORT || 3000;

// Configure middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from the public directory
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set up EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize SQLite database
let db: Database;

async function initializeDatabase(): Promise<void> {
  const dbPath = path.join(__dirname, '..', '..', 'data', 'submissions.sqlite');
  
  try {
    // Initialize SQL.js
    const SQL = await initSqlJs();
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load existing database or create a new one
    const schemaPath = path.join(__dirname, '..', '..', 'db', 'schema.sql');
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      // Cast to any to bypass type checking for SQL.js
      db = new (SQL.Database as any)(fileBuffer);
    } else {
      db = new SQL.Database();
      // Create tables from schema (only if schema file exists)
      if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf8');
        db.run(schema);
      } else {
        // Create table directly if schema file doesn't exist
        db.run(`
          CREATE TABLE IF NOT EXISTS submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            street_address TEXT NOT NULL,
            city TEXT NOT NULL,
            state_province TEXT NOT NULL,
            postal_code TEXT NOT NULL,
            country TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
          );
        `);
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Helper function to save the database to disk
function saveDatabase(): void {
  try {
    const dbPath = path.join(__dirname, '..', '..', 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Form validation function
function validateForm(formData: Record<string, string>): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required fields validation
  if (!formData.firstName?.trim()) {
    errors.push('First name is required');
  }
  
  if (!formData.lastName?.trim()) {
    errors.push('Last name is required');
  }
  
  if (!formData.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  
  if (!formData.city?.trim()) {
    errors.push('City is required');
  }
  
  if (!formData.stateProvince?.trim()) {
    errors.push('State / Province / Region is required');
  }
  
  if (!formData.postalCode?.trim()) {
    errors.push('Postal / Zip code is required');
  }
  
  if (!formData.country?.trim()) {
    errors.push('Country is required');
  }
  
  // Email validation
  if (!formData.email?.trim()) {
    errors.push('Email is required');
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation (allow international formats)
  if (!formData.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!/^[+]?[(\d\s)\-]+$/.test(formData.phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  // Postal code validation (alphanumeric)
  if (formData.postalCode && !/^[a-zA-Z0-9\s]+$/.test(formData.postalCode)) {
    errors.push('Postal code should only contain letters and numbers');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = req.body as Record<string, string>;
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }
  
  try {
    // Insert data into database
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}, shutting down gracefully...`);
  
  if (db) {
    saveDatabase();
    db.close();
    console.log('Database connection closed');
  }
  
  if (server && server.close) {
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

// Handle process signals
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Export a function to initialize the server without auto-starting
export function createServer(): Promise<any> {
  return initializeDatabase().then(() => {
    // Don't start server in tests, just return the app
    return app;
  });
}

// Start server after initializing database
let server: any; // Using 'any' type for Express server to avoid type issues

async function startServer(): Promise<void> {
  await initializeDatabase();
  
  server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export default app;
export { server, gracefulShutdown, initializeDatabase };