declare module 'sql.js' {
  export default function initSqlJs(options?: any): Promise<SqlJsStatic>;
  export interface SqlJsStatic {
    Database: DatabaseStatic;
  }
  export interface DatabaseStatic {
    new (data?: ArrayBuffer): Database;
  }
  export interface Database {
    run(sql: string, params?: any[]): any;
    exec(sql: string): any[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  export interface Statement {
    run(params?: any[]): any;
    get(params?: any[]): any;
    free(): void;
  }
}