import { createServer, gracefulShutdown, initializeDatabase } from './server.js';

// Don't start server automatically - wait for tests to do it
export { createServer, gracefulShutdown, initializeDatabase };
export default {
  createServer,
  gracefulShutdown,
  initializeDatabase
};