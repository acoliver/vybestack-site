import type { ReportFormatter } from '../types.js';
import { markdownFormatter } from './markdown.js';
import { textFormatter } from './text.js';

export const formatters: Record<string, ReportFormatter> = {
  markdown: markdownFormatter,
  text: textFormatter,
};

export const SUPPORTED_FORMATS = Object.keys(formatters) as readonly string[];