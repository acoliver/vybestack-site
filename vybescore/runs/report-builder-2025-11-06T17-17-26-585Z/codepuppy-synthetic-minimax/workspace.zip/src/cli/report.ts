#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import type { ReportData, RenderOptions } from '../types.js';
import { formatters, SUPPORTED_FORMATS } from '../formats/index.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid "entries" field (expected array)');
  }

  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`);
    }
  }

  return data as ReportData;
}

async function main(): Promise<void> {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArgs();

    // Validate format
    if (!SUPPORTED_FORMATS.includes(format)) {
      console.error(`Error: Unsupported format "${format}". Supported formats: ${SUPPORTED_FORMATS.join(', ')}`);
      process.exit(1);
    }

    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = await readFile(resolve(dataFile), 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file "${dataFile}": ${error.message}`);
      } else if (error instanceof Error && ('code' in error)) {
        console.error(`Error: Could not read file "${dataFile}": ${(error as Error & { code: string }).code}`);
      } else {
        console.error(`Error: Could not read file "${dataFile}": ${error}`);
      }
      process.exit(1);
    }

    // Validate data structure
    const reportData: ReportData = validateReportData(jsonData);

    // Get formatter and render report
    const formatter = formatters[format];
    const options: RenderOptions = { includeTotals };
    const output = formatter.render(reportData, options);

    // Write output
    if (outputPath) {
      try {
        await writeFile(resolve(outputPath), output, 'utf-8');
      } catch (error) {
        console.error(`Error: Could not write to file "${outputPath}": ${error}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error}`);
    process.exit(1);
  }
}

main().catch((error) => {
  console.error(`Fatal error: ${error}`);
  process.exit(1);
});