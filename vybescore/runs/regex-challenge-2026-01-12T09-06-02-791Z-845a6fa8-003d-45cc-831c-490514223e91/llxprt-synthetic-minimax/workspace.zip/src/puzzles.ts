/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\\\]/g, '\\\\$&');
  const prefixRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences of token that appear after a digit (not at string start)
  // Use negative lookbehind to exclude start of string
  const tokenPattern = new RegExp(`(?<!^)\\d${token}\\b`, 'g');
  
  // Find all matches
  const matches = text.match(tokenPattern) || [];
  
  // Return the full match (digit + token)
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[a-z]/.test(value)) return false; // lowercase
  if (!/[A-Z]/.test(value)) return false; // uppercase
  if (!/\d/.test(value)) return false; // digit
  if (!/[^a-zA-Z0-9\s]/.test(value)) return false; // symbol - any non-alphanumeric except space
  
  // Check for immediate repeated sequences (e.g., abab should fail)
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that matches standard IPv6 and shorthand with ::
  // Must not match IPv4 patterns
  const ipv6Pattern = /(?<!\d)(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|(?<![\d:])::(?![:.\d])/g;
  
  // Additional pattern for shorthand formats
  const shorthandPattern = /(?:[0-9a-fA-F]{1,4}:){0,7}::(?::[0-9a-fA-F]{1,4}){0,7}/g;
  
  // Check for IPv6 patterns
  const hasFullIPv6 = ipv6Pattern.test(value);
  const hasShorthandIPv6 = shorthandPattern.test(value);
  
  // Reset regex lastIndex since test is called
  ipv6Pattern.lastIndex = 0;
  shorthandPattern.lastIndex = 0;
  
  // Must find IPv6 but not IPv4
  if (hasFullIPv6 || hasShorthandIPv6) {
    // Make sure it's not an IPv4 address
    const ipv4Pattern = /(?<!\d)(?:\d{1,3}\.){3}\d{1,3}(?!\d)/;
    if (ipv4Pattern.test(value)) {
      return false;
    }
    return true;
  }
  
  return false;
}
