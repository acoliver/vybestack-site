export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that accepts typical addresses like name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  // Check for obvious invalid patterns first
  if (value.includes('..') || value.endsWith('.') || value.includes('_.') || value.includes('_@')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Remove optional +1 country code
  const digitsOnly = cleaned.replace(/^\+1/, '');
  
  // Must have exactly 10 digits for valid US phone number
  if (digitsOnly.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digitsOnly.substring(0, 3);
  const firstDigit = parseInt(areaCode.charAt(0));
  
  // Area codes cannot start with 0 or 1
  if (firstDigit === 0 || firstDigit === 1) {
    return false;
  }
  
  // Check that all characters are digits (no letters or invalid chars)
  if (!/^\d{10}$/.test(digitsOnly)) {
    return false;
  }
  
  // Valid US phone number format
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove common separators (spaces, hyphens, parentheses)
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Check for valid Argentine phone patterns
  // Pattern 1: +54 9 area(2-4) subscriber(6-8)
  // Pattern 2: +54 area(2-4) subscriber(6-8)
  // Pattern 3: 0 9 area(2-4) subscriber(6-8) [no country code]
  // Pattern 4: 0 area(2-4) subscriber(6-8) [no country code]
  
  const patterns = [
    /^(\+54)9(\d{2,4})(\d{6,8})$/, // +5491131234567
    /^(\+54)(\d{2,4})(\d{6,8})$/,  // +543411234567
    /^0(9)?(\d{2,4})(\d{6,8})$/,   // 03414234567, 01112345678
  ];
  
  // Test against all patterns
  for (const pattern of patterns) {
    const match = cleaned.match(pattern);
    if (match) {
      // Group 2: area code, Group 3: subscriber (handle different patterns)
      const areaCode = match[2];
      const subscriber = match[3];
      
      if (areaCode && subscriber) {
        const areaFirstDigit = parseInt(areaCode.charAt(0));
        // Area code must be 2-4 digits with leading digit 1-9
        // Subscriber must be 6-8 digits total
        if (areaFirstDigit >= 1 && areaFirstDigit <= 9 && 
            areaCode.length >= 2 && areaCode.length <= 4 &&
            subscriber.length >= 6 && subscriber.length <= 8) {
          return true;
        }
      }
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for obviously invalid patterns first
  // Reject strings with digits or special symbols (except apostrophes, hyphens, spaces)
  if (/\d/.test(value) || /[^\p{L}\p{M}'\-\s]/u.test(value)) {
    return false;
  }
  
  // Reject the "X Æ A-12" style names or similar patterns
  if (/[^\p{L}\p{M}'\-\s]/u.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }
  
  // Check that it's not just symbols or empty after removing allowed chars
  const nameChars = value.replace(/[\p{L}\p{M}'\-\s]/gu, '');
  if (nameChars.length > 0) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be digits only
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check prefix and length patterns for different card types
  const cardPatterns = [
    /^4\d{12}(\d{3})?$/, // Visa: starts with 4, 13 or 16 digits
    /^5[1-5]\d{14}$/, // Mastercard: starts with 51-55, 16 digits
    /^3[47]\d{13}$/, // American Express: starts with 34 or 37, 15 digits
    /^6(?:011|5\d{2})\d{12}$/, // Discover: starts with 6011 or 65, 16 digits
  ];
  
  // Check if it matches any card type pattern
  const isValidLength = cardPatterns.some(pattern => pattern.test(cleaned));
  if (!isValidLength) {
    return false;
  }
  
  // Apply Luhn checksum algorithm
  return runLuhnCheck(cleaned);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i));
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
