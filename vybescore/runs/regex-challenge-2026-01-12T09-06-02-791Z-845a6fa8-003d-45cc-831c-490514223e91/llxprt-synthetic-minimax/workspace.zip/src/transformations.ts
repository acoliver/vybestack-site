/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  return text.replace(
    /(^|[.!?]\s+)([a-z])/g,
    (match, prefix, letter) => {
      return prefix + letter.toUpperCase();
    }
  );
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Match URLs and remove trailing punctuation
  const urlPattern = /\bhttps?:\/\/[^\s<>"]+|\bwww\.[^\s<>"]+/g;
  const urls = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return urls.map(url => url.replace(/[.,;:!?]*$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while preserving everything else
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Match HTTP URLs and process them
  return text.replace(/http:\/\/([^/\s]+)([^\s]*)/g, (match, host, path) => {
    // Always upgrade to https
    let newUrl = 'https://';
    
    // Check for dynamic hints or legacy extensions in path
    const hasDynamicHints = /[?&]|(cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host for docs paths: example.com -> docs.example.com
      newUrl += `docs.${host}`;
    } else {
      // Keep original host
      newUrl += host;
    }
    
    // Add the path
    newUrl += path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and extract year
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const month = parseInt(dateMatch[1]);
  const day = parseInt(dateMatch[2]);
  const year = dateMatch[3];
  
  // Validate month (01-12) and day (01-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic month-day validation
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Simplified with leap year support
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
