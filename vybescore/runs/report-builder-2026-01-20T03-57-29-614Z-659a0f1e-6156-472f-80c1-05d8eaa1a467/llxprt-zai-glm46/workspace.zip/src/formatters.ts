import type { ReportData, RenderOptions } from './types.js';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';

export type Format = 'markdown' | 'text';

export interface Formatter {
  (data: ReportData, options: RenderOptions): string;
}

export const FORMATTERS: Record<Format, Formatter> = {
  markdown: renderMarkdown,
  text: renderText
};
