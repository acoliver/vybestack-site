#!/usr/bin/env node

import * as fs from 'node:fs';
import { FORMATTERS, type Format } from '../formatters.js';
import { validateReportData } from '../validator.js';

interface CliOptions {
  format: Format;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): { filePath: string; options: CliOptions } {
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const filePath = args[0];
  const options: CliOptions = {
    format: 'markdown',
    includeTotals: false
  };

  let i = 1;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Error: Unsupported format: ${formatValue}`);
        process.exit(1);
      }
      options.format = formatValue as Format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      options.output = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }

    i++;
  }

  return { filePath, options };
}

function main() {
  const args = process.argv.slice(2);
  const { filePath, options } = parseArgs(args);

  let jsonContent: string;
  try {
    jsonContent = fs.readFileSync(filePath, 'utf-8');
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`Error reading file "${filePath}": ${errorMessage}`);
    process.exit(1);
  }

  let data: unknown;
  try {
    data = JSON.parse(jsonContent);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`Error parsing JSON: ${errorMessage}`);
    process.exit(1);
  }

  let validatedData;
  try {
    validatedData = validateReportData(data);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${errorMessage}`);
    process.exit(1);
  }

  const formatter = FORMATTERS[options.format];
  const output = formatter(validatedData, { includeTotals: options.includeTotals });

  if (options.output) {
    try {
      fs.writeFileSync(options.output, output, 'utf-8');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.error(`Error writing to file "${options.output}": ${errorMessage}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
