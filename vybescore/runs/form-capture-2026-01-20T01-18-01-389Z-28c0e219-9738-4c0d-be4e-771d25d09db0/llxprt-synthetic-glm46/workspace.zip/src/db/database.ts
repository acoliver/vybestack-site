import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.join(__dirname, '..', '..', 'data', 'submissions.sqlite');
const schemaPath = path.join(__dirname, '..', '..', 'db', 'schema.sql');

export async function initDatabase(): Promise<import('sql.js').Database> {
  const SQL = await initSqlJs();
  
  let database: import('sql.js').Database;
  
  try {
    if (fs.existsSync(dbPath)) {
      const dbFile = fs.readFileSync(dbPath);
      database = new SQL.Database(dbFile);
      console.log('Loaded existing database from', dbPath);
    } else {
      database = new SQL.Database();
      const schema = fs.readFileSync(schemaPath, 'utf8');
      database.run(schema);
      console.log('Created new database with schema');
    }
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
  
  return database;
}

export function saveDatabase(database: import('sql.js').Database) {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    const data = database.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Error saving database:', error);
  }
}