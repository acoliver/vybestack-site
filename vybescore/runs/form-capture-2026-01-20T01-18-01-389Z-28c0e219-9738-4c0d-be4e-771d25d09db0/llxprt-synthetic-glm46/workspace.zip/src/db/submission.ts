import { saveDatabase } from './database.js';

export interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export async function addSubmission(database: import('sql.js').Database, submission: Submission) {
  const stmt = database.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);
    
    stmt.free();
    saveDatabase(database);
    console.log('Submission saved successfully');
  } catch (error) {
    stmt.free();
    console.error('Error adding submission:', error);
    throw error;
  }
}