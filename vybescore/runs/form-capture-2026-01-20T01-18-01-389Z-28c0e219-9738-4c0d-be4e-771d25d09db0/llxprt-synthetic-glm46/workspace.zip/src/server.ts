import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase } from './db/database.js';
import { addSubmission } from './db/submission.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database variable
let db: import('sql.js').Database;

// Initialize database and start server
async function startServer() {
  try {
    db = await initDatabase();
    console.log('Database initialized successfully');
    
    // Routes
    app.get('/', (req, res) => {
      res.render('form', { 
        errors: {},
        formData: {}
      });
    });

    app.post('/submit', async (req, res) => {
      const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = req.body;
      
      // Validation
      const errors: Record<string, string> = {};
      
      if (!firstName?.trim()) errors.firstName = 'First name is required';
      if (!lastName?.trim()) errors.lastName = 'Last name is required';
      if (!streetAddress?.trim()) errors.streetAddress = 'Street address is required';
      if (!city?.trim()) errors.city = 'City is required';
      if (!stateProvince?.trim()) errors.stateProvince = 'State/Province/Region is required';
      if (!postalCode?.trim()) errors.postalCode = 'Postal code is required';
      if (!country?.trim()) errors.country = 'Country is required';
      if (!email?.trim()) {
        errors.email = 'Email is required';
      } else {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
          errors.email = 'Please enter a valid email address';
        }
      }
      if (!phone?.trim()) {
        errors.phone = 'Phone number is required';
      } else {
        const phoneRegex = /^[\d\s\-()]+$/;
        const cleanedPhone = phone.replace(/^[\s@]+/, '');
        if (!phoneRegex.test(cleanedPhone)) {
          errors.phone = 'Please enter a valid phone number';
        }
      }
      
      if (Object.keys(errors).length > 0) {
        return res.render('form', { errors, formData: req.body });
      }
      
      try {
        await addSubmission(db, {
          firstName,
          lastName,
          streetAddress,
          city,
          stateProvince,
          postalCode,
          country,
          email,
          phone
        });
        res.redirect('/thank-you');
      } catch (dbError) {
        console.error('Database error:', dbError);
        res.status(500).render('form', { 
          errors: { general: 'An error occurred while saving your submission' },
          formData: req.body 
        });
      }
    });

    app.get('/thank-you', (req, res) => {
      res.render('thank-you');
    });

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
async function shutdown(signal: string) {
  console.log(`Received ${signal}, shutting down gracefully`);
  if (db) {
    db.close();
  }
  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Start the server
startServer();
