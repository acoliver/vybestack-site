declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...params: unknown[]): void;
    free(): void;
  }

  interface SqlJsStatic {
    Database: typeof Database;
  }

  function initSqlJs(): Promise<SqlJsStatic>;
  export = initSqlJs;
}