import { readFileSync, writeFileSync } from 'fs';
import { ReportData, FormatOptions } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[2];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1];
  if (!format) {
    console.error('Error: --format requires a value');
    process.exit(1);
  }

  const outputIndex = args.indexOf('--output');
  const output = outputIndex !== -1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return {
    dataFile,
    format,
    output,
    includeTotals
  };
}

function validateAndParseData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: title is required and must be a string');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary is required and must be a string');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries is required and must be an array');
    }
    
    // Validate entries
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Invalid data: each entry must have a label (string)');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Invalid data: each entry must have an amount (number)');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in ${filePath}: ${error.message}`);
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
}

function main(): void {
  const args = process.argv;
  const parsedArgs = parseArgs(args);
  
  // Validate format
  if (parsedArgs.format !== 'markdown' && parsedArgs.format !== 'text') {
    console.error(`Unsupported format: ${parsedArgs.format}`);
    process.exit(1);
  }
  
  const data = validateAndParseData(parsedArgs.dataFile);
  const options: FormatOptions = {
    includeTotals: parsedArgs.includeTotals
  };
  
  // Select formatter
  const formatter = parsedArgs.format === 'markdown' ? markdownFormatter : textFormatter;
  const output = formatter.format(data, options);
  
  // Write output
  if (parsedArgs.output) {
    writeFileSync(parsedArgs.output, output, 'utf-8');
  } else {
    console.log(output);
  }
}

main();