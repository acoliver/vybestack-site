export interface FormSubmission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationError {
  field: keyof FormSubmission;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

export class FormValidator {
  private static readonly emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  private static readonly phoneRegex = /^\+?[\d\s\-()]+$/;
  private static readonly postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;

  static validate(data: Partial<FormSubmission>): ValidationResult {
    const errors: ValidationError[] = [];

    // Required fields validation
    const requiredFields: (keyof FormSubmission)[] = [
      'first_name',
      'last_name', 
      'street_address',
      'city',
      'state_province',
      'postal_code',
      'country',
      'email',
      'phone'
    ];

    for (const field of requiredFields) {
      const value = data[field]?.trim();
      if (!value || value === '') {
        errors.push({
          field,
          message: `${this.getFieldDisplayName(field)} is required`
        });
      }
    }

    // Email validation
    if (data.email && data.email.trim()) {
      const email = data.email.trim();
      if (!this.emailRegex.test(email)) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation
    if (data.phone && data.phone.trim()) {
      const phone = data.phone.trim();
      if (!this.phoneRegex.test(phone)) {
        errors.push({
          field: 'phone',
          message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +'
        });
      }
    }

    // Postal code validation
    if (data.postal_code && data.postal_code.trim()) {
      const postalCode = data.postal_code.trim();
      if (!this.postalCodeRegex.test(postalCode)) {
        errors.push({
          field: 'postal_code',
          message: 'Postal code can only contain letters, numbers, spaces, and dashes'
        });
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private static getFieldDisplayName(field: keyof FormSubmission): string {
    const displayNames: Record<keyof FormSubmission, string> = {
      first_name: 'First name',
      last_name: 'Last name',
      street_address: 'Street address',
      city: 'City',
      state_province: 'State / Province / Region',
      postal_code: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };

    return displayNames[field] || field;
  }

  static getErrorsByField(errors: ValidationError[]): Record<string, string> {
    const errorsByField: Record<string, string> = {};
    
    for (const error of errors) {
      errorsByField[error.field] = error.message;
    }

    return errorsByField;
  }
}