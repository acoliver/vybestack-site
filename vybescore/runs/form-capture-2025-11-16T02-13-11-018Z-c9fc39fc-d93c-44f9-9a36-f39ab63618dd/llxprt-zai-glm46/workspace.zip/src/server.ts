import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { DatabaseManager, FormSubmission } from './database.js';
import { FormValidator, ValidationResult } from './validation.js';

const app = express();
const db = new DatabaseManager();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Error handling middleware
interface AppError extends Error {
  statusCode?: number;
}

const handleAsync = (fn: (req: Request, res: Response, next: NextFunction) => Promise<void>) => {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

// Routes
app.get('/', handleAsync(async (req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    formData: {},
    errorMessages: []
  });
}));

app.post('/submit', handleAsync(async (req: Request, res: Response) => {
  const formData: Partial<FormSubmission> = {
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    street_address: req.body.street_address,
    city: req.body.city,
    state_province: req.body.state_province,
    postal_code: req.body.postal_code,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const validation: ValidationResult = FormValidator.validate(formData);

  if (!validation.isValid) {
    const errorsByField = FormValidator.getErrorsByField(validation.errors);
    const errorMessages = validation.errors.map(err => err.message);

    return res.status(400).render('form', {
      errors: errorsByField,
      formData,
      errorMessages
    });
  }

  // Convert partial to full FormSubmission (we know all fields are valid and non-empty)
  const submission: FormSubmission = formData as FormSubmission;
  
  await db.insertSubmission(submission);
  
  res.redirect(302, '/thank-you');
}));

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware
app.use((err: AppError, req: Request, res: Response) => {
  console.error('Error:', err);
  res.status(err.statusCode || 500).render('form', {
    errors: {},
    formData: {},
    errorMessages: [err.message || 'An unexpected error occurred']
  });
});

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).render('form', {
    errors: {},
    formData: {},
    errorMessages: ['Page not found']
  });
});

// Graceful shutdown
const gracefulShutdown = async (signal: string) => {
  console.log(`
Received ${signal}. Closing database and server...`);
  
  try {
    await db.close();
    console.log('Database closed successfully.');
  } catch (error) {
    console.error('Error closing database:', error);
  }
  
  process.exit(0);
};

// Start server
const startServer = async () => {
  try {
    await db.initialize();
    console.log('Database initialized successfully.');
    
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Handle graceful shutdown
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Start the server
startServer().catch(error => {
  console.error('Server startup failed:', error);
  process.exit(1);
});
