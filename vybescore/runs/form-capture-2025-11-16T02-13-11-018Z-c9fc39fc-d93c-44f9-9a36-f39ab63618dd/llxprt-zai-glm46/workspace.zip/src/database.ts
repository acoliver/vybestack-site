import fs from 'fs';
import path from 'path';
import initSqlJs, { Database } from 'sql.js';

export interface FormSubmission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export interface SubmissionRecord extends FormSubmission {
  id: number;
  created_at: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private readonly dbPath: string;
  private readonly schemaPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Initialize SQL.js
    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        // Default location for sql-wasm.wasm file
        return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
      }
    });

    // Initialize database
    if (fs.existsSync(this.dbPath)) {
      // Load existing database
      const dbBuffer = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(dbBuffer);
    } else {
      // Create new database
      this.db = new SQL.Database();
      await this.loadSchema();
    }
  }

  private async loadSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schema = fs.readFileSync(this.schemaPath, 'utf8');
    this.db.run(schema);
  }

  async insertSubmission(submission: FormSubmission): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    const idResult = this.db.exec('SELECT last_insert_rowid() as id');
    const id = idResult[0].values[0][0] as number;
    stmt.free();

    // Save database to disk
    await this.saveDatabase();

    return id;
  }

  async getAllSubmissions(): Promise<SubmissionRecord[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const result = this.db.exec('SELECT * FROM submissions ORDER BY created_at DESC');
    
    if (result.length === 0) {
      return [];
    }

    const columns = result[0].columns;
    const values = result[0].values;

    const submissions: SubmissionRecord[] = values.map(row => {
      const submission: Record<string, unknown> = {};
      columns.forEach((column, index) => {
        submission[column] = row[index];
      });
      return submission as unknown as SubmissionRecord;
    });

    return submissions;
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      await this.saveDatabase();
      this.db.close();
      this.db = null;
    }
  }
}