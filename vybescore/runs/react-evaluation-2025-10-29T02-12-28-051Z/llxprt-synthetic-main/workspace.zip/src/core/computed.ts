/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  subscribe,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T>
  
  if (equal === undefined) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? (lhs: T, rhs: T) => lhs === rhs : () => false
  } else {
    equalFn = equal
  }

  let currentValue = value
  
  const getter: GetterFn<T> = (): T => {
    // Register this computed value as a dependent of the active observer
    const observer = getActiveObserver()
    
    // Every time we evaluate, we recalculate
    const newValue = updateFn(currentValue)
    
    // Check if value actually changed
    const valueChanged = currentValue === undefined || !equalFn(currentValue, newValue)
    if (valueChanged) {
      currentValue = newValue
    }
    
    // If there's an active observer, track this computed value as a dependency
    if (observer) {
      subscribe(observer as Observer<unknown>)
    }
    
    return currentValue as T
  }
  
  return getter
}