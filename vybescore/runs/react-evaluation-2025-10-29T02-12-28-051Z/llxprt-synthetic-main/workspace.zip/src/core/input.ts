/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  subscribe,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T>
  
  if (equal === undefined) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? (lhs: T, rhs: T) => lhs === rhs : () => false
  } else {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this input as a dependency of the active observer
      subscribe(observer as Observer<unknown>)
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Update all dependent observers
      if (s.observer) {
        try {
          updateObserver(s.observer as Observer<T>)
        } catch (error) {
          console.error('Error updating observer:', error)
        }
      }
    }
    return s.value
  }

  return [read, write]
}
