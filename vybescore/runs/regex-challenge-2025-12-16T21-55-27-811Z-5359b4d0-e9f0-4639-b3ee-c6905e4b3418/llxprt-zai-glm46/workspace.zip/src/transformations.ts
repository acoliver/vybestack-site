/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 * Capitalizes after .!? punctuation, ensures single space between sentences, and handles abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return text;
  }
  
  // Common abbreviations that should not trigger sentence capitalization
  const abbreviations = /\b(Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Mt|etc|e\.g|i\.e|vs|approx|no|vol|fig|tab|eq|ref|al|et|ca|cf|ibid|op|cit|esp|ff|p|pp|ed|eds|repr|trans|dept|univ|assn|corp|ltd|inc|co|ltd|plc)\.?$/i;
  
  // Split by sentence endings, but keep track of the delimiters
  const sentences = text.split(/([.!?]+)/);
  
  let result = '';
  let capitalizeNext = true; // First character should be capitalized
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    if (i % 2 === 0) {
      // Text segment
      if (segment.trim()) {
        if (capitalizeNext) {
          // Capitalize first non-space character
          result += segment.replace(/^(\s*)([a-z])/, (_, spaces, letter) => spaces + letter.toUpperCase());
          capitalizeNext = false;
        } else {
          result += segment;
        }
      } else if (segment) {
        // Preserve spaces
        result += segment;
      }
    } else {
      // Punctuation segment
      result += segment;
      
      // Check if we should capitalize the next segment
      // Look ahead to see if the next text segment starts with an abbreviation
      if (i < sentences.length - 1) {
        const nextText = sentences[i + 1];
        const firstWord = nextText.trim().split(/\s+/)[0];
        
        if (firstWord && !abbreviations.test(firstWord)) {
          capitalizeNext = true;
        }
      }
      
      // Ensure single space after punctuation if there's content after
      if (i < sentences.length - 1 && sentences[i + 1].trim()) {
        // Remove extra spaces after punctuation and ensure exactly one
        result = result.replace(/([.!?]+)\s+/, '$1 ');
      }
    }
  }
  
  // Clean up multiple spaces
  result = result.replace(/\s{2,}/g, ' ');
  
  return result.trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex that matches http, https, ftp, and protocol-less URLs
  const urlRegex = /\b((?:https?:\/\/|ftp:\/\/|www\.)[^\s/$.?#].[^\s]*)(?=[^\w-])?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?(){}[\]"']+$/g, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Always upgrades scheme to https://
 * Moves /docs/ paths to docs.example.com host
 * Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/([^/]+)(\/[^\s]*)/g, (match, host, path) => {
    // Always upgrade to https
    let newUrl = `https://${host}${path}`;
    
    // Check if path starts with /docs/ and doesn't contain dynamic content hints
    const docsPathRegex = /^\/docs\//;
    const dynamicContentRegex = /(\/cgi-bin|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$)/i;
    
    if (docsPathRegex.test(path) && !dynamicContentRegex.test(path)) {
      // Rewrite host to docs.example.com for docs paths without dynamic content
      const baseHost = host.replace(/^www\./, ''); // Remove www. prefix if present
      newUrl = `https://docs.${baseHost}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and capture month, day, year
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.trim().match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day ranges for each month (considering leap years for February)
  const maxDays = {
    1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  // Check for leap year
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  // Adjust February days for leap years
  if (month === 2 && isLeapYear(year)) {
    maxDays[2] = 29;
  }
  
  // Check if day is valid for the month
  if (day > maxDays[month as keyof typeof maxDays]) {
    return 'N/A';
  }
  
  return year;
}