/**
 * Match words starting with the prefix but excluding banned words.
 * Returns an array of words that start with the given prefix but are not in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to find words starting with the prefix
  // \b ensures we match whole words only
  // [a-zA-Z]+ matches the word characters after the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\b${escapedPrefix}([a-zA-Z]+)`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    const fullWord = match[0];
    const lowercaseWord = fullWord.toLowerCase();
    
    // Check if the word is not in the exceptions list (case-insensitive)
    const isException = exceptions.some(exception => 
      exception.toLowerCase() === lowercaseWord
    );
    
    if (!isException) {
      matches.push(fullWord);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds to match the specific positioning requirements.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match digit + token (returning the full match)
  const pattern = new RegExp('\\d' + escapedToken, 'g');
  
  const matches = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 * Requirements: At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
const hasSymbol = /[!@#$%^&*()_+=[\]{};':"\\|,.<>/?]/.test(value);
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 * Matches various IPv6 formats including compressed notation with ::.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 addresses contain colons and hex digits
  const trimmed = value.trim();
  
  // Simple IPv6 detection pattern
const ipv6Pattern = /([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}/;
  
  return ipv6Pattern.test(trimmed) && trimmed.includes(':');
}