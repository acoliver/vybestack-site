export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to run Luhn checksum validation on credit card numbers
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email addresses with comprehensive regex
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for invalid patterns
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  const [, domain] = value.split('@');
  
  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain cannot start or end with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats and optional +1 prefix
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + for country code
  let cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 country code
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2);
  }
  
  // Must be exactly 10 digits for US numbers
  if (cleaned.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = cleaned.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = cleaned.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Check if this looks like a valid format by testing against common patterns
  const patterns = [
    /^\+?1?\s*\(?(\d{3})\)?[-.\s]?(\d{3})[-.\s]?(\d{4})$/, // +1 (212) 555-7890, 212-555-7890
    /^\+?1?\s*(\d{3})[-.\s]?(\d{3})[-.\s]?(\d{4})$/, // 2125557890, 212 555 7890
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // ^(?:\+54|0)?         - Optional +54 country code or 0 trunk prefix
  // (?:9)?              - Optional mobile indicator 9
  // (\d{2,4})           - Area code (2-4 digits, leading digit 1-9)
  // (\d{6,8})$          - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54|0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits and lead with 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If country code is omitted, must start with trunk prefix 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const trimmed = value.trim();
  
  // Cannot be empty or too short
  if (trimmed.length < 1) {
    return false;
  }
  
  // Name validation regex
  // ^[\p{L}\p{M}'’\-\s]+$ - Unicode letters, diacritical marks, apostrophes, hyphens, and spaces
  // [\p{L}\p{M}] matches Unicode letters and combining marks (accents)
  const nameRegex = /^[\p{L}\p{M}'’\-\s]+$/u;
  
  if (!nameRegex.test(trimmed)) {
    return false;
  }
  
  // Additional validation: reject names with only symbols or too many consecutive special characters
  const invalidPatterns = [
    /^['\-\s]+$/, // Starts with only apostrophes, hyphens, or spaces
    /['\-\s]{3,}/, // Three or more consecutive special characters
    /\d/, // Any digits
    /[^\p{L}\p{M}'’\-\s]/u, // Any other symbols not in the allowed set
  ];
  
  return !invalidPatterns.some(pattern => pattern.test(trimmed));
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx prefixes and lengths with Luhn checksum)
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Basic length check (13-19 digits for major card types)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Credit card validation patterns with prefixes and lengths
  const cardPatterns = [
    { name: 'Visa', regex: /^4(\d{12}|\d{15})$/, lengths: [13, 16] },
    { name: 'Mastercard', regex: /^5[1-5]\d{14}$/, lengths: [16] },
    { name: 'Mastercard (new)', regex: /^2(2[2-9]\d{13}|[3-6]\d{14}|7[01]\d{13}|720\d{12})$/, lengths: [16] },
    { name: 'American Express', regex: /^3[47]\d{13}$/, lengths: [15] },
    { name: 'Diners Club', regex: /^3(0[0-5]|[68]\d)\d{11}$/, lengths: [14] },
    { name: 'Discover', regex: /^6(011|5\d{2})\d{12}$/, lengths: [16] },
    { name: 'JCB', regex: /^(2131|1800|35\d{3})\d{11}$/, lengths: [16] },
  ];
  
  // Check if digits match any card pattern
  const validPattern = cardPatterns.some(pattern => {
    return pattern.regex.test(digits) && pattern.lengths.includes(digits.length);
  });
  
  if (!validPattern) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(digits);
}
