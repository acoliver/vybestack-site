/**
 * Encode plain text to Base64 using the standard Base64 format.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate if a string contains only valid Base64 characters and proper padding.
 */
function isValidBase64(input: string): boolean {
  // Standard Base64 alphabet: A-Z, a-z, 0-9, +, /
  // Optional padding with '=', but only at the end and only 0-2 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // For inputs without padding, check if they would be valid with added padding
  if (!input.includes('=')) {
    // Calculate what the padding should be
    const paddingNeeded = input.length % 4;
    return paddingNeeded !== 1;
  }
  
  // If padding is present, it must be valid
  const paddingIndex = input.indexOf('=');
  const afterPadding = input.substring(paddingIndex);
  
  // Padding must be 1 or 2 characters of '=' only
  if (!/^=+$/.test(afterPadding) || afterPadding.length > 2) {
    return false;
  }
  
  // For valid Base64, the total length should be a multiple of 4
  // when including padding
  return input.length % 4 === 0;
}

/**
 * Decode Base64 text back to plain UTF-8 using the standard Base64 alphabet.
 * Accepts inputs with or without padding and validates the input format.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters or incorrect padding');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
