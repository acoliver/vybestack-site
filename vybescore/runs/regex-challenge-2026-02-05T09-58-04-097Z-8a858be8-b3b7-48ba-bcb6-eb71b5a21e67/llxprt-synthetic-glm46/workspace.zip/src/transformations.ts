/**
 * Capitalizes the first character of each sentence in the text.
 * Handles proper spacing between sentences and preserves abbreviations when possible.
 * Inserts exactly one space between sentences and collapses extra spaces sensibly.
 */
export function capitalizeSentences(text: string): string {
  return text
    // First, normalize multiple spaces
    .replace(/\s+/g, ' ')
    // Ensure sentences are properly spaced after sentence terminators
    .replace(/([.?!])(?!\s)/g, '$1 ')
    // Capitalize first letter after sentence start
    .replace(/(?:^|[.?!]\s+)([a-z])/g, (match, letter) => match.replace(letter, letter.toUpperCase()))
    // Capitalize very first character if needed
    .replace(/^([a-z])/, (match, letter) => letter.toUpperCase())
    // Remove extra spaces before sentence terminators
    .replace(/\s+([.?!])/g, '$1')
    // Ensure one space after sentence terminators (but not at end)
    .replace(/([.?!])(?!\s|$)/g, '$1 ');
}

/**
 * Extracts all URLs from the given text.
 * Returns an array of URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches common URL formats
  // Includes scheme (http/https/ftp) and optional www
  // Allows for domain names, path, query strings, and fragments
  const urlPattern = /(https?:\/\/|ftp:\/\/)+(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,63}\b(?:[-a-zA-Z0-9()@:%_+.~#?&//=]*)/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?)\]]+$/, ''));
}

/**
 * Forces all http:// schemes to https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, being careful not to affect https:// urls
  return text.replace(/http:\/\/((?!https:\/\/).*)/g, 'https://$1');
}

/**
 * Rewrites URLs from http://example.com/... to https://..., with special handling for docs paths.
 * For URLs starting with http://example.com/ with /docs/ paths, rewrites to https://docs.example.com/...
 * Skips host rewrite for paths with dynamic hints like cgi-bin, query strings, or legacy extensions.
 * Always upgrades scheme to https://.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(
    /http:\/\/example\.com\/([^?&#]*)(.*)/g,
    (match, path, remainder) => {
      // Always upgrade to https
      const newScheme = 'https://';
      
      // Check if path begins with /docs/ and doesn't contain forbidden patterns
      if (path.startsWith('docs/') && !shouldSkipHostRewrite(path, remainder)) {
        // Rewrite to docs.example.com host
        return `${newScheme}docs.example.com/${path}${remainder}`;
      }
      
      // Just upgrade scheme, keep original host
      return `${newScheme}example.com/${path}${remainder}`;
    }
  );
}

/**
 * Helper function to determine if host rewrite should be skipped.
 */
function shouldSkipHostRewrite(path: string, remainder: string): boolean {
  const fullPath = path + remainder;
  
  // Patterns that should skip host rewrite
  const skipPatterns = [
    /cgi-bin/,
    /[?&=]/,         // Query strings
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i  // Legacy extensions
  ];
  
  return skipPatterns.some(pattern => pattern.test(fullPath));
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  const datePattern = /^(0[1-9]|1[0-2])\/([0-2]\d|3[0-1])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for days in month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  // Adjust February days for leap years
  if (month === 2 && isLeapYear(year)) {
    daysInMonth[1] = 29;
  }
  
  // Check if day is valid for the month
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
