/**
 * Finds words beginning with the specified prefix, excluding listed exceptions.
 * Uses word boundaries to match whole words and negative lookahead to exclude exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!prefix) return [];
  
  // Create exception pattern
  const exceptionPattern = exceptions.length > 0 
    ? `(?!(?:${exceptions.join('|')})\\b)` 
    : '';
  
  // Match words that start with the prefix but aren't in exceptions
  const wordPattern = new RegExp(`\\b${prefix}[^\\s]*${exceptionPattern}`, 'g');
  const matches = text.match(wordPattern) || [];
  
  // Filter for exact word matches and remove duplicates
  return Array.from(new Set(matches.filter(match => {
    const words = match.split(/\s+/);
    return words.length === 1 && /^[a-zA-Z]+$/.test(match);
  })));
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookbehind to ensure the token is preceded by a digit and not at the start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!token) return [];
  
  // Escape special regex chars in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match token that's preceded by a digit but not at string start
  // Using a workaround since lookbehind isn't supported in all environments
  const tokenPattern = new RegExp(`(\\d)(${escapedToken})`, 'g');
  const matches: string[] = [];
  
  text.replace(tokenPattern, (match, precedingDigit, actualToken) => {
    matches.push(actualToken);
    return match;
  });
  
  return matches;
}

/**
 * Validates passwords according to the security policy.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Basic length and character requirements
  if (value.length < 10) return false;
  
  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[^A-Za-z0-9\s]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Check for repeated sequences (like abab, abcabc, etc.)
  // Common repeated patterns of length 2-4
  const repeatedPattern = /(.{2,4})\1+/;
  if (repeatedPattern.test(value) && value.length > 6) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses don't trigger positive results.
 * Returns true if IPv6 address is found, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude obvious IPv4 addresses
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If it contains an IPv4 address but not a full IPv6 address, return false
  if (ipv4Pattern.test(value)) {
    // Check if there's also an IPv6 address
    const ipv6Pattern = /(?:^|[^0-9])(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}(?:$|[^a-fA-F0-9:])/;
    if (!ipv6Pattern.test(value.replace(/\s+/g, ''))) {
      return false;
    }
  }
  
  // IPv6 patterns (various formats)
  const ipv6Patterns = [
    // Standard format: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    // Compressed format with :: (can appear multiple times)
    /(?:[0-9a-fA-F]{1,4}:){0,7}:(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/,
    // IPv6 withIPv4 embedded: 2001:db8::192.0.2.33
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/,
    // Shortened versions and edge cases
    /::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}/,
    /[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5}/,
    /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,4}/,
    /::/
  ];
  
  
  
  // Test all IPv6 patterns
  for (const pattern of ipv6Patterns) {
    const matches = value.match(pattern);
    if (matches && matches.length > 0) {
      // Ensure it's not just a simple IPv4-like pattern
      for (const match of matches) {
        // Additional validation to confirm it's truly IPv6
        if (match.includes(':') && !ipv4Pattern.test(match)) {
          return true;
        }
      }
    }
  }
  
  // Comprehensive IPv6 detection with word boundaries
  const comprehensiveIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b|\b::[0-9a-fA-F]+(?::[0-9a-fA-F]+)*\b|[0-9a-fA-F]+::[0-9a-fA-F]+(?::[0-9a-fA-F]+)*\b|\b::\b/;
  
  return comprehensiveIPv6.test(value);
}
