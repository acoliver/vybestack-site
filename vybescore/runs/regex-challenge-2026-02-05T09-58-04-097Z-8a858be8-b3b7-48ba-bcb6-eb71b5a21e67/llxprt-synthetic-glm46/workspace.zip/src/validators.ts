export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using a comprehensive regex pattern.
 * Accepts standard formats while rejecting double dots, trailing dots, 
 * domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant pattern with additional restrictions
  // Local part: letters, digits, and limited special chars
  // Domain: standard domain format without underscores
  // No double dots, no leading/trailing dots in local part
  const emailPattern = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for disallowed patterns
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // No double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // No leading or trailing dots in local part
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain cannot contain underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Check valid patterns: (optional +1) + (optional parentheses) + 10 digits
  const usPhonePattern = /^(?:(?:\+?1)[\s-]*)?(?:\(?([2-9]\d{2})\)?[\s-]*)([2-9]\d{2})[\s-]*(\d{4})$/;
  const match = value.match(usPhonePattern);
  
  if (!match) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = match[1];
  if (areaCode && (areaCode.startsWith('0') || areaCode.startsWith('1'))) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Supports patterns like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Handles optional country code +54, trunk prefix 0, mobile indicator 9, and various separators.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation, but keep the structure
  const cleaned = value.replace(/[-\s]/g, '');
  
  // Check for common formats
  // Format 1: +54 9 11 1234 5678 (country + mobile)
  // Format 2: 011 1234 5678 (trunk + area + subscriber)
  // Format 3: +54 341 123 4567 (country + landline)
  // Format 4: 0341 4234567 (trunk + area + subscriber)
  
  // Pattern matches:
  // Optional +54
  // Optional 0 trunk prefix (required if no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  const argentinePhonePattern = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(argentinePhonePattern);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriber = match[2];
  
  // When country code is omitted, number must begin with trunk prefix 0
  if (!cleaned.startsWith('+54') && !value.startsWith('0')) {
    return false;
  }
  
  // Area code length check (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number length check (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and extreme cases like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Must contain at least one letter, reject names that are only symbols
  // Reject digits and common symbols not used in names
  
  const onlyValidChars = /^[\p{L}\p{M}\s'-]+$/u;
  
  // Must have at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  
  // Reject if contains digits or invalid symbols
  const hasInvalidChars = /[0-9@#$%^&*()_+=\[\]{}|\\:;<>,.\/~`]/.test(value);
  
  // Reject obvious non-names
  const obviouslyInvalid = /^(X|X Æ A-12|test|123|n\/a)$/i.test(value.trim());
  
  return hasLetter && onlyValidChars.test(value) && !hasInvalidChars && !obviouslyInvalid;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and AmEx.
 * Checks proper prefixes and lengths, then performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes for validation
  const cleaned = value.replace(/[-\s]/g, '');
  
  // Basic length check (13-19 digits typical for major cards)
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16 digits
  const visa = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16 digits
  const mastercard = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  
  // AmEx: starts with 34 or 37, length 15 digits
  const amex = /^3[47]\d{13}$/;
  
  // Check if it matches any supported card type
  const validPrefix = visa.test(cleaned) || mastercard.test(cleaned) || amex.test(cleaned);
  
  if (!validPrefix) {
    return false;
  }
  
  // Perform Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum algorithm.
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    const digit = parseInt(number.charAt(i), 10);
    
    if (isEven) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled = doubled.toString().split('').map(Number).reduce((a, b) => a + b, 0);
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
