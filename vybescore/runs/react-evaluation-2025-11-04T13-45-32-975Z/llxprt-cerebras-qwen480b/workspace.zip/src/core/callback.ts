/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(callbackFn: () => T, initialValue?: T): UnsubscribeFn {
  // Create an observer for the callback
  let observerValue: T | undefined = initialValue
  const observer: Observer<T> = {
    get value() {
      return observerValue
    },
    set value(v: T | undefined) {
      observerValue = v
    },
    updateFn: () => {
      const result = callbackFn()
      observerValue = result
      return result
    },
  }
  
  // Track dependencies by making the callback observe its dependencies
  updateObserver(observer)
  
  let disposed = false
  
  // Return unsubscribe function to clean up the observer
  return () => {
    if (disposed) return
    disposed = true
    
    // Setting updateFn to noop effectively unsubscribes the observer
    observer.updateFn = () => observer.value!
  }
}