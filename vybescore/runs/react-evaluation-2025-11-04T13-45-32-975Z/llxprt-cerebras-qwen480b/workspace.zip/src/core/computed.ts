/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  Observer, 
  ObserverR,
  EqualFn,
  getActiveObserver,
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  computeFn: () => T,
  initialValue?: T,
  equal?: EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create observer for this computed
  let observerValue: T | undefined = initialValue
  const observer: Observer<T> = {
    name: options?.name,
    get value() {
      return observerValue
    },
    set value(v: T | undefined) {
      observerValue = v
    },
    updateFn: () => {
      const newValue = computeFn()
      // Check if value has actually changed
      if (!equalFn(observerValue!, newValue)) {
        observerValue = newValue
      }
      return observerValue!
    },
  }
  
  // Array to track dependencies (to prevent duplicates)
  const dependencies: ObserverR[] = []
  
  // Determine equality function
  const equalFn: EqualFn<T> = equal ?? Object.is

  // Create getter function that also tracks dependencies
  const getter: GetterFn<T> = () => {
    // Check if there's currently an active observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Add this active observer to our dependencies list if not already present
      if (!dependencies.includes(activeObserver)) {
        dependencies.push(activeObserver)
      }
    }
    
    // Return the current computed value
    return observerValue!
  }
  
  // Track our own dependencies by computing the initial value
  updateObserver(observer)
  
  // Override the update function to notify our dependents when we change
  const originalUpdateFn = observer.updateFn
  observer.updateFn = () => {
    // Save current dependencies to detect changes
    const previousDependencies = [...dependencies]
    // Clear our dependencies to rebuild during recomputation
    dependencies.length = 0
    
    // Compute new value
    const oldValue = observerValue
    const result = originalUpdateFn()
    
    // If our value changed, notify our dependents
    if (!equalFn(oldValue!, result)) {
      // Notify previous dependents that were tracking us
      for (const dependent of previousDependencies) {
        // Only notify if it's a full Observer (has updateFn)
        if ('updateFn' in dependent) {
          updateObserver(dependent as Observer<unknown>)
        }
      }
    }
    
    return result
  }
  
  return getter
}