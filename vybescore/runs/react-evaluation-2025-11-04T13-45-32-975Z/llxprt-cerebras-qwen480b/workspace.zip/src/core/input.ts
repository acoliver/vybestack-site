/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  initialValue: T,
  equal?: EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Array to track multiple observers
  const observers: Observer<T>[] = []

  // Determine equality function
  const equalFn: EqualFn<T> = equal ?? Object.is

  let value: T = initialValue

  const read: GetterFn<T> = () => {
    // Get active observer (if any)
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Add observer to list if not already present
      if (!observers.includes(activeObserver as Observer<T>)) {
        observers.push(activeObserver as Observer<T>)
      }
    }
    return value
  }

  const write: SetterFn<T> = (nextValue: T) => {
    // Check if value has actually changed
    if (!equalFn(value, nextValue)) {
      value = nextValue
      
      // Notify all observers of the change
      for (const observer of observers) {
        updateObserver(observer)
      }
    }
    return value
  }

  return [read, write]
}