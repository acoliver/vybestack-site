#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';

import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, FormatType, ReportOptions } from '../types.js';

function parseArguments(args: string[]): {
  dataPath: string;
  format: FormatType;
  outputPath?: string;
  options: ReportOptions;
} {
  const dataPath = args[0];
  if (!dataPath) {
    throw new Error('Please provide a data file path');
  }

  let format: FormatType = 'markdown';
  let outputPath: string | undefined;
  const options: ReportOptions = {
    includeTotals: false,
  };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--format') {
      const formatValue = args[++i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
      format = formatValue as FormatType;
    } else if (arg === '--output') {
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  return { dataPath, format, outputPath, options };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: data must be an object');
  }

  const dataObj = data as Record<string, unknown>;

  if (typeof dataObj.title !== 'string') {
    throw new Error('Invalid JSON: title must be a string');
  }

  if (typeof dataObj.summary !== 'string') {
    throw new Error('Invalid JSON: summary must be a string');
  }

  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Invalid JSON: entries must be an array');
  }

  for (const entry of dataObj.entries) {
    if (!entry || typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid JSON: each entry must be an object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid JSON: entry.label must be a string');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid JSON: entry.amount must be a number');
    }
  }

  return dataObj as unknown as ReportData;
}

function loadReportData(dataPath: string): ReportData {
  const absolutePath = path.resolve(dataPath);
  const content = fs.readFileSync(absolutePath, 'utf-8');
  
  let data:
    | { success: true; data: ReportData }
    | { success: false; error: unknown };
  try {
    const parsed = JSON.parse(content);
    data = { success: true, data: validateReportData(parsed) };
  } catch (error) {
    data = { success: false, error };
  }

  if (!data.success) {
    if (data.error instanceof SyntaxError) {
      throw new Error('Invalid JSON: ' + data.error.message);
    } else if (data.error instanceof Error) {
      throw new Error(data.error.message);
    } else {
      throw new Error('Unknown error occurred');
    }
  }

  return data.data;
}

function getFormatter(format: FormatType) {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main() {
  const args = process.argv.slice(2);
  try {
    const { dataPath, format, outputPath, options } = parseArguments(args);
    const data = loadReportData(dataPath);
    const formatter = getFormatter(format);
    const result = formatter.format(data, options);

    if (outputPath) {
      fs.writeFileSync(path.resolve(outputPath), result, 'utf-8');
    } else {
      console.log(result);
    }
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
}

main();
