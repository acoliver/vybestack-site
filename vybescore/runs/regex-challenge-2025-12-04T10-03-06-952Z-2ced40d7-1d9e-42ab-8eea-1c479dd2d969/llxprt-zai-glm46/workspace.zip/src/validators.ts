export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (typeof value !== 'string' || value.trim() === '') {
    return false;
  }

  // Basic pattern: local@domain.tld with validation for common issues
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional validation rules
  // Reject double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }

  // Reject trailing dot in local part or domain
  if (value.endsWith('.')) {
    return false;
  }

  // Reject domains with underscores
  const domainParts = value.split('@')[1].split('.');
  if (domainParts.some((part) => part.includes('_'))) {
    return false;
  }

  // Ensure domain has at least one period and valid TLD
  const domain = value.split('@')[1];
  if (!domain.includes('.') || domain.split('.').some((part) => part.length === 0)) {
    return false;
  }

  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  if (typeof value !== 'string' || value.trim() === '') {
    return false;
  }

  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.slice(1);
  }

  // Must have exactly 10 digits for US phone numbers
  if (digits.length !== 10) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Validate format patterns
  const validPatterns = [
    /^\+?1?\s*\(\s*\d{3}\s*\)\s*\d{3}\s*[-.\s]?\s*\d{4}$/, // (212) 555-7890, +1 (212) 555-7890
    /^\+?1?\s*\d{3}\s*[-.\s]?\s*\d{3}\s*[-.\s]?\s*\d{4}$/, // 212-555-7890, 212.555.7890, 212 555 7890
    /^\+?1?\s*\d{10}$/, // 2125557890
  ];

  // Check if the original format matches any valid pattern
  const isValidFormat = validPatterns.some((pattern) => pattern.test(value));
  
  return isValidFormat;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (typeof value !== 'string' || value.trim() === '') {
    return false;
  }

  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');
  
  let digits = cleaned;
  let hasCountryCode = false;
  
  // Handle optional +54 country code
  if (digits.startsWith('+54')) {
    digits = digits.slice(3);
    hasCountryCode = true;
  }

  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !digits.startsWith('0')) {
    return false;
  }

  // Remove trunk prefix 0 if present
  if (digits.startsWith('0')) {
    digits = digits.slice(1);
  }

  // Check for mobile indicator 9 (between country/trunk and area code)
  const hasMobileIndicator = digits.startsWith('9');
  if (hasMobileIndicator) {
    digits = digits.slice(1);
  }

  // At this point, digits should contain area code + subscriber number
  // Area code is 2-4 digits, subscriber number is 6-8 digits
  if (digits.length < 8 || digits.length > 12) { // 2+6 to 4+8
    return false;
  }

  // Extract area code (2-4 digits, leading digit 1-9)
  // Try different area code lengths (2, 3, 4)
  for (const acLength of [2, 3, 4]) {
    if (acLength <= digits.length) {
      const potentialAreaCode = digits.slice(0, acLength);
      const potentialSubscriber = digits.slice(acLength);
      
      // Area code must be 2-4 digits, leading digit 1-9
      if (potentialAreaCode.length >= 2 && potentialAreaCode.length <= 4 &&
          potentialAreaCode[0] !== '0' &&
          potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
        return true; // Found a valid combination
      }
    }
  }

  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (typeof value !== 'string' || value.trim() === '') {
    return false;
  }

  const trimmed = value.trim();
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and patterns like X Æ A-12
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(trimmed)) {
    return false;
  }

  // Reject names that contain digits
  if (/\d/.test(trimmed)) {
    return false;
  }

  // Reject names with multiple consecutive apostrophes or hyphens
  if (/''|--/.test(trimmed)) {
    return false;
  }

  // Reject names that start or end with apostrophe or hyphen
  if (/^['\-\s]|['\-\s]$/.test(trimmed)) {
    return false;
  }

  // Ensure at least one letter
  if (!/[\p{L}]/u.test(trimmed)) {
    return false;
  }

  // Reject obviously problematic patterns like "X Æ A-12"
  if (/\b[IX]\b|Æ|A-12|A-?12/i.test(trimmed)) {
    return false;
  }

  return true;
}

/**
 * TODO: Validate credit card numbers for major card types using Luhn algorithm.
 */
export function isValidCreditCard(value: string): boolean {
  if (typeof value !== 'string' || value.trim() === '') {
    return false;
  }

  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length for major card types
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d{10}|20\d{9})))$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37

  // Check if it matches any major card type
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }

  // Luhn algorithm
  return runLuhnCheck(digits);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;

  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}