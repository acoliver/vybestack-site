

/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (typeof text !== 'string' || text.trim() === '') {
    return text;
  }

  // Split text into sentences using punctuation that typically ends sentences
  const sentences = text.split(/([.?!])/);
  
  let result = '';
  let i = 0;
  
  while (i < sentences.length) {
    // Get the sentence content
    const content = sentences[i];
    // Get the punctuation if it exists
    const punctuation = sentences[i + 1] || '';
    
    if (content.trim() === '') {
      // Preserve empty segments
      result += content;
      if (punctuation) {
        result += punctuation;
      }
      i += 2;
      continue;
    }
    
    // Capitalize the first letter of the content
    const trimmed = content.trim();
    const firstChar = trimmed.charAt(0).toUpperCase();
    const rest = trimmed.slice(1);
    const capitalized = content.replace(trimmed, firstChar + rest);
    
    result += capitalized;
    
    if (punctuation) {
      result += punctuation;
      // Add a space after punctuation if there's more content
      if (i + 2 < sentences.length) {
        result += ' ';
      }
    }
    
    i += 2; // Move past content and punctuation
  }

  // Clean up any extra spaces
  return result
    .replace(/\s+/g, ' ') // Collapse multiple spaces
    .replace(/\s+([.?!])/g, '$1') // Remove spaces before punctuation
    .replace(/([.?!])\s+/g, '$1 ') // Ensure single space after punctuation
    .trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (typeof text !== 'string' || text.trim() === '') {
    return [];
  }

  // URL regex that matches http/https URLs with domain and optional path/query
  const urlRegex = /https?:\/\/(?:www\.)?[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9](?:\.[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])+(?:[?#][^\s)\]}\.,;:!?'"`]*)?(?:\/[^\s)\]}\.,;:!?'"`]*)?/g;
  
  const matches = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    // Remove trailing punctuation that's not part of the URL
    url = url.replace(/[.,;:!?'"`)\]}\]]+$/, '');
    if (url.length > 0) {
      matches.push(url);
    }
  }
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (typeof text !== 'string') {
    return text;
  }

  // Replace http:// with https://, but be careful not to modify https://
  return text.replace(/http:\/\/(?!\s)/g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (typeof text !== 'string') {
    return text;
  }

  return text.replace(/http:\/\/([^/]+)(\/[^\s]*)?/g, (match, host, path) => {
    path = path || '';
    
    // Always upgrade to https
    let newUrl = 'https://';
    
    // Check if path starts with /docs/ and doesn't contain excluded patterns
    if (path.startsWith('/docs/')) {
      // Check for excluded patterns that should prevent host rewrite
      const excludedPatterns = [
        /\/cgi-bin\//,
        /[?&]/, // Query strings (check for ? or &)
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)($|[?#])/ // Legacy extensions
      ];
      
      const shouldExclude = excludedPatterns.some(pattern => pattern.test(path));
      
      if (!shouldExclude) {
        // Rewrite host to docs.example.com
        newUrl += 'docs.' + host;
      } else {
        // Keep original host
        newUrl += host;
      }
    } else {
      // Keep original host
      newUrl += host;
    }
    
    // Add the path
    newUrl += path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract a 4-digit year from mm/dd/yyyy format, return 'N/A' if invalid.
 */
export function extractYear(value: string): string {
  if (typeof value !== 'string' || value.trim() === '') {
    return 'N/A';
  }

  // Match mm/dd/yyyy format and validate month/day ranges
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [
    31, // January
    28, // February (non-leap year)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31, // December
  ];

  // Check for leap year February
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || parseInt(year, 10) % 400 === 0;
  if (month === 2 && isLeapYear) {
    if (day < 1 || day > 29) {
      return 'N/A';
    }
  } else if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  return year;
}