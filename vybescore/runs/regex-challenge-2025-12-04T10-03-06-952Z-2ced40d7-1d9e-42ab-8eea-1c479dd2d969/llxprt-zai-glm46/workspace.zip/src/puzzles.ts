/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (typeof text !== 'string' || typeof prefix !== 'string' || !Array.isArray(exceptions)) {
    return [];
  }

  if (prefix === '') {
    return [];
  }

  // Create a Set of exceptions for O(1) lookup (case-insensitive)
  const exceptionSet = new Set(exceptions.map((ex) => ex.toLowerCase()));
  
  // Escape special regex characters in the prefix and create word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp('\\b' + escapedPrefix + '[a-zA-Z]*\\b', 'g');
  
  // Find all words starting with the prefix
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions and return unique results
  return matches
    .filter((word) => !exceptionSet.has(word.toLowerCase()))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (typeof text !== 'string' || typeof token !== 'string' || token === '') {
    return [];
  }

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Look for token preceded by a digit (including the digit in the match)
  const pattern = new RegExp('\\d' + escapedToken, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  const password = value;

  // Minimum length of 10 characters
  if (password.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(password)) {
    return false;
  }

  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(password)) {
    return false;
  }

  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(password)) {
    return false;
  }

  // Must contain at least one digit
  if (!/\d/.test(password)) {
    return false;
  }

  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^\w\s]/.test(password)) {
    return false;
  }

  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // We'll check for patterns of length 2-4 that repeat immediately
  for (let len = 2; len <= 4; len++) {
    if (password.length >= len * 2) {
      for (let i = 0; i <= password.length - len * 2; i++) {
        const segment = password.slice(i, i + len);
        const nextSegment = password.slice(i + len, i + len * 2);
        if (segment === nextSegment) {
          return false;
        }
      }
    }
  }

  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  // First, exclude IPv4 addresses to avoid false positives
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  if (ipv4Pattern.test(value)) {
    // If it contains an IPv4 address, we need to check if there's also an IPv6 address
    // Remove the IPv4 address and continue checking for IPv6
    const withoutIPv4 = value.replace(ipv4Pattern, '');
    if (withoutIPv4.trim() === '') {
      return false; // Only IPv4 found
    }
    value = withoutIPv4;
  }

  // Simplified IPv6 pattern for TypeScript compatibility
  // This matches common IPv6 patterns while avoiding complex lookbehinds
  const ipv6Pattern = /(?:^|(?<=\s))(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(?:ffff(?::0{1,4}){0,1}:){0,1}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])\.(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])\.(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])\.(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])\.(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])\.(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9])\.(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9])[0-9]))/;

  return ipv6Pattern.test(value);
}