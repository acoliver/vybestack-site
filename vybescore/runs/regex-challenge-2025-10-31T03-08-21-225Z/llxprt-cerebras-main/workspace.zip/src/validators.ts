export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex pattern matching
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email regex that handles typical addresses while rejecting invalid forms
  // Local part: allow alphanumeric, dots, underscores, dashes, plus signs
  // Domain part: allow alphanumeric, dots, dashes but not underscores
  // Properly handles edge cases like double dots, trailing dots
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for edge cases
  if (!emailRegex.test(value)) return false;
  
  // Check for double dots
  if (value.includes('..')) return false;
  
  // Check for trailing dot in local part or domain
  const [localPart, domainPart] = value.split('@');
  if (localPart.endsWith('.') || domainPart.endsWith('.')) return false;
  
  // Check for underscores in domain part
  if (domainPart.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers with support for various formats
 * Supports (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters except for the plus sign at the beginning
  let cleanValue = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  if (cleanValue.startsWith('+1')) {
    cleanValue = cleanValue.substring(2);
  } else if (cleanValue.startsWith('+')) {
    // If it starts with + but not +1, it's not a valid US phone number
    return false;
  }
  
  // Check if we have exactly 10 digits now
  if (cleanValue.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = cleanValue.substring(0, 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex pattern to match Argentine phone numbers
  // Supports optional country code (+54), optional trunk prefix (0), optional mobile indicator (9)
  // Area code (2-4 digits, first digit 1-9), subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54|0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, , areaCode, subscriberNumber] = match;
  
  // If no country code, must have trunk prefix (0)
  if (!countryCode && !value.startsWith('0')) return false;
  
  // Validate area code and subscriber number lengths
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and names with consecutive non-letter characters
  const nameRegex = /^[^\d\W][\w\s'-]*(?:[^\d\W]|[\s'-][^\d\W])?$/u;
  
  // Additional checks for "X Æ A-12" style names (containing digits)
  if (!nameRegex.test(value) || /\d/.test(value)) return false;
  
  return true;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum)
 * Supports Visa, Mastercard, and AmEx
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check basic format with regex
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits, starts with 51-55
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  // Check if it matches any card format
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn algorithm check
  return runLuhnCheck(cleanValue);
}

/**
 * Implementation of the Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}