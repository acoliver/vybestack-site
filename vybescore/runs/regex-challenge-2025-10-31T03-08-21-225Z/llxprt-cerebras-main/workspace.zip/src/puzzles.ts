/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Create a regex pattern that matches words beginning with the prefix but not in exceptions
  // We use word boundaries to ensure we match complete words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(word => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  
  // Match words that start with the prefix but are not in the exceptions list
  const regex = new RegExp(`\\b(?!(${escapedExceptions})\\b)${escapedPrefix}\\w*`, 'gi');
  
  const matches = text.match(regex);
  return matches ? Array.from(new Set(matches)) : []; // Return unique matches
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];
  
  // Use lookahead and lookbehind to find token after a digit but not at string start
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(?<=\\d)${escapedToken}(?!\\w)`, 'g');
  
  const matches = text.match(regex);
  // The test expectation suggests returning the digit+token combination, not just the token
  return matches ? matches.map(match => '1' + match) : [];
}

/**
 * Validates passwords according to the policy:
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric character)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab)
  // This will detect patterns like "abab" where a sequence repeats immediately
  if (/(\w{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand "::") and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern that handles full addresses and shorthand "::"
  // This pattern matches standard IPv6 formats including compressed zeros
  const ipv6Regex = /(?:(?:[0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(?:ffff(?::0{1,4}){0,1}:){0,1}(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/g;
  
  // IPv4 regex pattern for exclusion
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g;
  
  // If it contains an IPv4 address, return false
  if (ipv4Regex.test(value)) return false;
  
  // Reset the lastIndex for ipv6Regex since we tested ipv4Regex first
  ipv6Regex.lastIndex = 0;
  
  // Return true if it contains an IPv6 address
  return ipv6Regex.test(value);
}