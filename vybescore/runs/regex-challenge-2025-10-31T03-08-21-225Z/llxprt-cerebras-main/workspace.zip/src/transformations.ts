/**
 * Capitalize the first character of each sentence, preserving spacing rules
 * Inserts exactly one space between sentences even if the input omitted it
 * Collapses extra spaces sensibly while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Split by sentence-ending punctuation followed by whitespace or end of string
  // This regex looks for sentence endings (.?!), captures them, and allows for subsequent spaces
  return text.replace(/(^|[.?!]\s*)(\w)/g, (match, p1, p2) => {
    // p1 is the punctuation and space (or start of string)
    // p2 is the first letter of the next sentence
    return p1 + p2.toUpperCase();
  });
}

/**
 * Extract URLs from text, returning an array of matched URL strings
 * Excludes trailing punctuation
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Regex pattern to match URLs (http/https) including domains and paths
  // Exclude trailing punctuation like .,!;: etc
  const urlRegex = /https?:\/\/[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s.,!;:?"]*)?/g;
  
  const matches = text.match(urlRegex);
  return matches ? matches : [];
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https://, but don't modify already secure URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/
 * Skip host rewrite when path contains dynamic hints like cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Regex to match URLs that start with http:// and optionally have docs paths, 
  // but not containing dynamic/legacy elements
  return text.replace(
    /http:\/\/([a-zA-Z0-9.-]+)(\/docs\/[^?\s]*)/g,
    (match, host, path) => {
      // Check if path contains dynamic hints (cgi-bin, query strings, legacy extensions)
      if (path.match(/cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py|\?|&|=/)) {
        // Just upgrade to https, don't change host
        return `https://${host}${path}`;
      } else {
        // Upgrade scheme and change host to docs.host
        return `https://docs.${host}${path}`;
      }
    }
  );
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Check if the string matches mm/dd/yyyy pattern
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Additional validation for month/day
  if (monthNum < 1 || monthNum > 12 || dayNum < 1 || dayNum > 31) return 'N/A';
  
  return year;
}