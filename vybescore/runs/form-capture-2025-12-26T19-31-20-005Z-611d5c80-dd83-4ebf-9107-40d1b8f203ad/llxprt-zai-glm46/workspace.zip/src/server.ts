import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

import 'ejs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, '..');

const DB_PATH = path.join(projectRoot, 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(projectRoot, 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

let db: Database | null = null;

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[\d\s+\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateFormData(data: FormData): { errors: ValidationErrors; valid: boolean } {
  const errors: ValidationErrors = {};

  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State / Province / Region is required';
  }
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal / Zip code is required';
  } else if (!validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Postal code must contain only letters, digits, spaces, and hyphens';
  }
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Phone number may contain digits, spaces, parentheses, dashes, and a leading +';
  }

  return {
    errors,
    valid: Object.keys(errors).length === 0
  };
}

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    return new SQL.Database(buffer);
  }

  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  const database = new SQL.Database();
  database.run(schema);

  saveDatabase(database);

  return database;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    const errorMessages = Object.values(validation.errors);
    res.status(400).render('form', {
      errors: errorMessages,
      values: formData
    });
    return;
  }

  if (db) {
    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim()
      ]
    );

    saveDatabase(db);
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = (req.query.firstName as string) || 'friend';
  res.render('thank-you', { firstName });
});

app.use('/public', express.static(path.join(projectRoot, 'public')));

let serverInstance: unknown = null;

function startServer(port: number = 3535): express.Express {
  app.set('views', path.join(projectRoot, 'src', 'templates'));
  app.set('view engine', 'ejs');

  serverInstance = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  return app;
}

async function shutdown(): Promise<void> {
  console.log('Shutting down server...');
  if (db) {
    db.close();
    db = null;
  }
}

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

initializeDatabase()
  .then((database) => {
    db = database;
    const appInstance = startServer(PORT);

    process.on('SIGTERM', async () => {
      await shutdown();
      if (serverInstance && typeof serverInstance === 'object' && 'close' in serverInstance) {
        (serverInstance as { close: (cb?: () => void) => void }).close(() => {
          console.log('Server closed');
          process.exit(0);
        });
      }
    });

    process.on('SIGINT', async () => {
      await shutdown();
      if (serverInstance && typeof serverInstance === 'object' && 'close' in serverInstance) {
        (serverInstance as { close: (cb?: () => void) => void }).close(() => {
          console.log('Server closed');
          process.exit(0);
        });
      }
    });

    return { app: appInstance, server: serverInstance };
  })
  .catch((err) => {
    console.error('Failed to initialize database:', err);
    process.exit(1);
  });
