import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
// @ts-expect-error - sql.js doesn't provide proper type definitions
import initSqlJs from 'sql.js';

interface Database {
  exec(sql: string): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...params: unknown[]): void;
  get(): unknown;
  all(): unknown[];
  free(): void;
}

// Get __dirname equivalent for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}



const app = express();
const port = process.env.PORT || '3000';

let db: Database | null = null;
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');

// Ensure data directory exists
const dataDir = path.dirname(dbPath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const dbFile = fs.readFileSync(dbPath);
      db = new SQL.Database(dbFile);
      console.log('Loaded existing database');
    } else {
      db = new SQL.Database();
      console.log('Created new database');
    }
    
    // Ensure schema exists
    const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    if (db) {
      db.exec(schema);
    }
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\d\sA-Za-z-]+$/;
  return postalRegex.test(postalCode) && postalCode.length > 0;
}

function validateFormData(formData: Partial<FormData>): { errors: string[]; valid: boolean } {
  const errors: string[] = [];
  
  // Required fields
  if (!formData.firstName?.trim()) errors.push('First name is required');
  if (!formData.lastName?.trim()) errors.push('Last name is required');
  if (!formData.streetAddress?.trim()) errors.push('Street address is required');
  if (!formData.city?.trim()) errors.push('City is required');
  if (!formData.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!formData.postalCode?.trim()) errors.push('Postal code is required');
  if (!formData.country?.trim()) errors.push('Country is required');
  if (!formData.email?.trim()) errors.push('Email is required');
  if (!formData.phone?.trim()) errors.push('Phone number is required');
  
  // Email format validation
  if (formData.email && !validateEmail(formData.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone format validation
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  // Postal code format validation
  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.push('Please enter a valid postal code');
  }
  
  return { errors, valid: errors.length === 0 };
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {},
    title: 'Friendly Contact Form'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };
  
  const validation = validateFormData(formData);
  
  if (!validation.valid) {
    return res.render('form', {
      errors: validation.errors,
      values: formData,
      title: 'Friendly Contact Form - Errors'
    });
  }
  
  try {
    if (!db) throw new Error('Database not initialized');
    
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank-you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    const validation = validateFormData(formData);
    validation.errors.push('An error occurred while saving your submission');
    
    res.render('form', {
      errors: validation.errors,
      values: formData,
      title: 'Friendly Contact Form - Error'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission to extract first name
  try {
    if (!db) {
      return res.render('thank-you', { firstName: 'Friend', title: 'Thank You!' });
    }
    
    const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
    const result = stmt.get() as { first_name: string } | undefined;
    stmt.free();
    
    const firstName = result?.first_name || 'Friend';
    res.render('thank-you', { firstName, title: 'Thank You!' });
  } catch (error) {
    console.error('Error retrieving submission:', error);
    res.render('thank-you', { firstName: 'Friend', title: 'Thank You!' });
  }
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Unhandled error:', err);
  res.status(500).render('form', {
    errors: ['An unexpected error occurred. Please try again.'],
    values: {},
    title: 'Friendly Contact Form - Error'
  });
});

// Start server and initialize database
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(parseInt(port), () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Graceful shutdown handling
  const gracefulShutdown = (signal: string) => {
    console.log(`\nReceived ${signal}. Starting graceful shutdown...`);
    
    server.close(async () => {
      console.log('Express server closed');
      
      if (db) {
        saveDatabase();
        db.close();
        db = null;
        console.log('Database closed');
      }
      
      process.exit(0);
    });
    
    // Force shutdown after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };
  
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

// Export app for testing
export { app };

// Start the server
startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});