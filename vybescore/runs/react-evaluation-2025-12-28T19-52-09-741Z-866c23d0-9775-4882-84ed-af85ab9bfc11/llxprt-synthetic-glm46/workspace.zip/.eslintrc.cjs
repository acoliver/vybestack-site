const fs = require('node:fs');
const path = require('node:path');

const workspaceRoot = __dirname;
const workspaceTsconfig =
  ['tsconfig.eslint.json', 'tsconfig.json']
    .map((filename) => path.join(workspaceRoot, filename))
    .find((file) => fs.existsSync(file)) ||
  path.join(workspaceRoot, 'tsconfig.json');

module.exports = {
  extends: ['eslint:recommended', 'plugin:@typescript-eslint/recommended'],
  parser: '@typescript-eslint/parser',
  plugins: ['@typescript-eslint'],
  rules: {
    '@typescript-eslint/no-unused-vars': 'error',
    '@typescript-eslint/no-explicit-any': 'warn',
  },
}
