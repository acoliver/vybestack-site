/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type Observer<T> = {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  disposed?: boolean
}

export type ObservableR = {
  name?: string
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  observers?: Set<Observer<any>>
}

export type ObservableV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Observable<T> = ObservableR & ObservableV<T>

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let activeObserver: Observer<any> | undefined

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function setActiveObserver(observer: Observer<any> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function addObserver<T>(observable: Observable<T>, observer: Observer<any>): void {
  if (!observable.observers) {
    observable.observers = new Set()
  }
  observable.observers.add(observer)
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function removeObserver<T>(observable: Observable<T>, observer: Observer<any>): void {
  if (observable.observers) {
    observable.observers.delete(observer)
  }
}

export function notifyObservers<T>(observable: Observable<T>): void {
  if (observable.observers) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    for (const observer of observable.observers) {
      if (!observer.disposed) {
        updateObserver(observer)
      }
    }
  }
}
