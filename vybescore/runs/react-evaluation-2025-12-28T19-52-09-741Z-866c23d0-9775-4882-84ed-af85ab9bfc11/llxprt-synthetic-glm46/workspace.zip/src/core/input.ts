/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Observable,
  getActiveObserver,
  addObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const observable: Observable<T> = {
    name: options?.name,
    value,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserver(observable, observer)
    }
    return observable.value
  }

  const write: SetterFn<T> = (nextValue) => {
    observable.value = nextValue
    notifyObservers(observable)
    return observable.value
  }

  return [read, write]
}
