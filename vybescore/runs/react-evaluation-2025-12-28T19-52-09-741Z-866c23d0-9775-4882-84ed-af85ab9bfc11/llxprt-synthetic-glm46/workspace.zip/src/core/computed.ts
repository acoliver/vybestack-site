/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Observable,
  addObserver,
  notifyObservers,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    disposed: false
  }
  
  const observable: Observable<T> = {
    name: options?.name,
    value: value as T,
  }

  // Register observer to be notified when dependencies change
  const computedObserver: Observer<T> = {
    ...observer,
    updateFn: (value?: T) => {
      // Recompute value
      const previousObserver = getActiveObserver()
      setActiveObserver(observer)
      try {
        const newValue = updateFn(value)
        if (newValue !== observer.value) {
          observer.value = newValue
          observable.value = newValue
          // Notify observers of this computed value
          notifyObservers(observable)
        }
        return newValue
      } finally {
        setActiveObserver(previousObserver)
      }
    }
  }

  const read: GetterFn<T> = () => {
    // Register current observer if any
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      addObserver(observable, currentObserver)
    }
    
    // Set this computed as active observer to track dependencies
    const previousObserver = getActiveObserver()
    setActiveObserver(computedObserver)
    
    try {
      const newValue = updateFn(observer.value)
      observer.value = newValue
      observable.value = newValue
      return newValue
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  return read
}
