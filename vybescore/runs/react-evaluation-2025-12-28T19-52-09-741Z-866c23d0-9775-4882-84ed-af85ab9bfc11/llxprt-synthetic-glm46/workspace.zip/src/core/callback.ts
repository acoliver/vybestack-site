/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, getActiveObserver, setActiveObserver, UpdateFn } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    disposed: false
  }
  
  let disposed = false
  
  // Register the observer to track dependencies
  const previousObserver = getActiveObserver()
  
  // Execute the callback function initially to track dependencies
  setActiveObserver(observer)
  try {
    updateFn(value)
  } finally {
    setActiveObserver(previousObserver)
  }
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Mark as disposed to prevent further updates
    observer.disposed = true
    
    // Clear the observer references
    observer.value = undefined
    observer.updateFn = () => value as T
  }
  
  return unsubscribe
}
