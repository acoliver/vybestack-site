const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const ERROR_MESSAGE = 'Invalid Base64 input';

/**
 * Validate if a string has valid Base64 characters.
 * Standard Base64 uses: A-Z, a-z, 0-9, +, / and padding with =
 */
function isValidBase64(input: string): boolean {
  return VALID_BASE64_REGEX.test(input);
}

/**
 * Encode plain text to Base64 using standard Base64 alphabet.
 * Output includes padding (=) as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Normalize: strip whitespace
  const normalized = input.trim();
  
  // Validate the input
  if (!isValidBase64(normalized)) {
    throw new Error(ERROR_MESSAGE);
  }
  
  try {
    const buffer = Buffer.from(normalized, 'base64');
    
    // Check if decoding actually produced valid data
    // If the input was invalid, Buffer.from might return an empty buffer
    // or data that doesn't round-trip correctly
    const decoded = buffer.toString('utf8');
    
    // Verify by re-encoding: if we encode and get the same input (modulo padding),
    // the input was valid
    const reEncoded = Buffer.from(decoded, 'utf8').toString('base64');
    // Normalize both for comparison (re-encode always adds padding)
    const normalizedOriginal = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=');
    
    // If re-encoding produces a different result, the input was invalid
    if (reEncoded !== normalizedOriginal) {
      throw new Error(ERROR_MESSAGE);
    }
    
    return decoded;
  } catch (error) {
    throw new Error(ERROR_MESSAGE);
  }
}
