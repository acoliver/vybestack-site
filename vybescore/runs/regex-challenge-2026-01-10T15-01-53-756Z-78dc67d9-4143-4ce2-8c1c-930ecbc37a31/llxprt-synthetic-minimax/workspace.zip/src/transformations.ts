/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Normalize spacing - collapse multiple spaces and trim
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Pattern to match sentence boundaries and next word
  // Group 1: sentence ending punctuation (.?!)
  // Group 2: optional whitespace
  // Group 3: first letter of next sentence to capitalize
  const pattern = /([.!?])(\s*)(\w)/g;
  
  // Replace sentence by sentence
  const result = normalized.replace(pattern, (_match, punctuation, whitespace, nextChar) => {
    return punctuation + whitespace + nextChar.toUpperCase();
  });
  
  // Capitalize first character of the entire text
  return result.replace(/^(\w)/, (_match, firstChar) => {
    return firstChar.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs with common schemes and domains
  // - http:// or https://
  // - Optional www.
  // - Domain with TLD
  // - Optional path, query, fragment
  const urlPattern = /\b(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  
  const matches = text.match(urlPattern);
  if (!matches) {
    return [];
  }
  
  // Clean up URLs by removing trailing punctuation
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[.,;!?]+$/, '');
  });
  
  // Filter out obviously non-URL matches (single dots, etc.)
  return cleanUrls.filter(url => url.includes('.'));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Pattern to match http:// URLs (case-insensitive)
  const httpPattern = /http:\/\/([^\s]+)/gi;
  
  return text.replace(httpPattern, (match, url) => {
    return 'https://' + url;
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match HTTP URLs
  const httpUrlPattern = /http:\/\/[^\s"'<>]+/g;
  
  return text.replace(httpUrlPattern, (fullUrl) => {
    // Parse the URL components
    const urlMatch = fullUrl.match(/^http:\/\/([^/]+)(.*)$/);
    if (!urlMatch) {
      return fullUrl;
    }
    
    const host = urlMatch[1];
    const path = urlMatch[2];
    
    // Check for dynamic hints or legacy extensions in the path
    const hasDynamicHints = path.includes('cgi-bin') || 
                            path.includes('?') || 
                            path.includes('&') || 
                            path.includes('=') ||
                            path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Extract domain part from host and create docs subdomain
      const newHost = 'docs.' + host;
      return 'https://' + newHost + path;
    } else {
      // Just upgrade scheme to https
      return 'https://' + host + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  // Days per month: Jan(31), Feb(28/29), Mar(31), Apr(30), May(31), Jun(30)
  // Jul(31), Aug(31), Sep(30), Oct(31), Nov(30), Dec(31)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (isLeapYear && day > 29) {
      return 'N/A';
    } else if (!isLeapYear && day > 28) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // If all validations pass, return the year
  return year;
}
