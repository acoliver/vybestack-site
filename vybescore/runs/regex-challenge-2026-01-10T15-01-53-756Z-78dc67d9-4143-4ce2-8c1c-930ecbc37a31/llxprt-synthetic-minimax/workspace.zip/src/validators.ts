export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for invalid patterns first:
  // - No consecutive dots anywhere
  // - No trailing dot anywhere (especially after @ symbol)
  // - No domain with underscores (NO underscores allowed in domain at all)
  if (value.includes('..')) {
    return false;
  }
  
  // Check if domain part contains underscores or trailing dots
  const atIndex = value.indexOf('@');
  if (atIndex !== -1) {
    const domain = value.substring(atIndex + 1);
    if (domain.includes('_') || domain.endsWith('.')) {
      return false;
    }
  }
  
  // Also check for trailing dots anywhere in the email
  if (value.endsWith('.')) {
    return false;
  }
  
  // Basic email validation using regex
  // Pattern breakdown:
  // - Username: letters, numbers, dots, underscores, percent, plus, hyphens
  // - @ symbol
  // - Domain: letters, numbers, hyphens, dots (NO underscores)
  // - TLD: letters only, 2+ characters
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length (should be 10 digits, or 11 with leading 1)
  if (digitsOnly.length === 10) {
    // Standard 10-digit US number
    const areaCode = parseInt(digitsOnly.substring(0, 3));
    // Area code cannot start with 0 or 1
    if (areaCode < 200 || areaCode > 999) {
      return false;
    }
    return true;
  } else if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // 11-digit with country code 1
    const areaCode = parseInt(digitsOnly.substring(1, 4));
    if (areaCode < 200 || areaCode > 999) {
      return false;
    }
    return true;
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove common separators but keep structure
  const cleanValue = value.replace(/[\s-]+/g, ' ').trim();
  
  // Match Argentine phone patterns:
  // 1. International: +54 area_code subscriber_number_parts
  // 2. Domestic: 0 area_code subscriber_number_parts
  // 3. With mobile indicator: +54 [9] [0] area_code subscriber_number_parts
  
  // First check if it's international format with +54
  if (cleanValue.includes('+54')) {
    // Pattern for international format: +54 area_code subscriber_parts
    // The subscriber number can be split (e.g., "123 4567" = 7 digits total)
    const internationalPattern = /^\+54\s*([1-9]\d{1,3})\s*(\d{3,4})(?:\s*(\d{4,4}))?$/;
    const match = cleanValue.match(internationalPattern);
    
    if (match) {
      const areaCode = match[1];
      const subscriber1 = match[2];
      const subscriber2 = match[3] || '';
      
      // Calculate total subscriber digits
      const totalSubscriber = subscriber1 + subscriber2;
      
      // Validate lengths
      if (areaCode.length >= 2 && areaCode.length <= 4 && 
          totalSubscriber.length >= 6 && totalSubscriber.length <= 8) {
        return true;
      }
    }
    
    // Also handle format with mobile indicator 9
    const mobilePattern = /^\+54\s*9\s*([1-9]\d{1,3})\s*(\d{3,4})(?:\s*(\d{4,4}))?$/;
    const mobileMatch = cleanValue.match(mobilePattern);
    if (mobileMatch) {
      const areaCode = mobileMatch[1];
      const subscriber1 = mobileMatch[2];
      const subscriber2 = mobileMatch[3] || '';
      
      const totalSubscriber = subscriber1 + subscriber2;
      
      if (areaCode.length >= 2 && areaCode.length <= 4 && 
          totalSubscriber.length >= 6 && totalSubscriber.length <= 8) {
        return true;
      }
    }
  }
  
  // Check for domestic format (starting with 0)
  if (cleanValue.startsWith('0')) {
    const domesticPattern = /^0\s*([1-9]\d{1,3})\s*(\d{3,4})(?:\s*(\d{4,4}))?$/;
    const domesticMatch = cleanValue.match(domesticPattern);
    if (domesticMatch) {
      const areaCode = domesticMatch[1];
      const subscriber1 = domesticMatch[2];
      const subscriber2 = domesticMatch[3] || '';
      
      const totalSubscriber = subscriber1 + subscriber2;
      
      if (areaCode.length >= 2 && areaCode.length <= 4 && 
          totalSubscriber.length >= 6 && totalSubscriber.length <= 8) {
        return true;
      }
    }
  }
  
  // Also try the flexible pattern that might match various combinations
  const flexiblePattern = /^(\+54\s?)?(?:9\s?)?(?:0\s?)?([1-9]\d{1,3})\s?(\d{3,4})(?:\s?(\d{4,4}))?$/;
  const flexibleMatch = cleanValue.match(flexiblePattern);
  
  if (flexibleMatch) {
    const areaCode = flexibleMatch[2];
    const subscriber1 = flexibleMatch[3];
    const subscriber2 = flexibleMatch[4] || '';
    
    const totalSubscriber = subscriber1 + subscriber2;
    
    // Validate area code and subscriber lengths
    if (areaCode.length >= 2 && areaCode.length <= 4 && 
        totalSubscriber.length >= 6 && totalSubscriber.length <= 8) {
      return true;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern for valid names:
  // - Unicode letters allowed (with \\p{L} unicode property)
  // - Spaces, apostrophes, hyphens allowed between name parts
  // - No digits allowed
  // - No symbols except apostrophe and hyphen
  
  // Use unicode property escapes for proper unicode support
  // \p{L} matches any unicode letter
  // Each name part should start with a letter and contain letters/spaces/apostrophes/hyphens
  const nameRegex = /^[\p{L}](?:[\p{L}\s'-]*[\p{L}])?$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject obviously non-name patterns
  if (value.includes('X Æ A-12')) {
    return false;
  }
  
  // Check for any digits (shouldn't be any due to regex, but double-checking)
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for valid card types and lengths
  // Visa: 16 digits starting with 4
  // Mastercard: 16 digits starting with 51-55
  // American Express: 15 digits starting with 34 or 37
  const cardLength = digitsOnly.length;
  let cardPrefix = '';
  
  if (cardLength === 16) {
    cardPrefix = digitsOnly.substring(0, 2);
  } else if (cardLength === 15) {
    cardPrefix = digitsOnly.substring(0, 2);
  } else if (cardLength === 13) {
    // Some Visa cards are 13 digits
    if (digitsOnly.startsWith('4')) {
      return runLuhnCheck(digitsOnly);
    }
    return false;
  }
  
  // Check prefixes
  let isValidType = false;
  if (digitsOnly.startsWith('4') && (cardLength === 13 || cardLength === 16)) {
    // Visa
    isValidType = true;
  } else if ((cardPrefix >= '51' && cardPrefix <= '55') && cardLength === 16) {
    // Mastercard
    isValidType = true;
  } else if ((digitsOnly.startsWith('34') || digitsOnly.startsWith('37')) && cardLength === 15) {
    // American Express
    isValidType = true;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}

function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
