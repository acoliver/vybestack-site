/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create pattern for words starting with the prefix
  // Word boundary followed by the prefix (case insensitive), then word characters
  const pattern = new RegExp(`\\b${prefix}\\w*`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exact matches of exceptions (case insensitive)
  const filteredMatches = matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === lowerWord
    );
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern explanation:
  // (?<!^) - negative lookbehind: not at the very beginning of string
  // \\d${token} - matches a digit followed by the token
  // This finds the digit-token combination where token appears after a digit but not at start
  const pattern = new RegExp(`(?<!^)\\d${token}`, 'gi');
  
  const matches = text.match(pattern);
  return matches || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Length check: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace check
  if (/\s/.test(value)) {
    return false;
  }
  
  // Character type requirements
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>?]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  const repeatedPattern = /(.{2})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  // Check for other repeated patterns like ababab
  const longerRepeatedPattern = /(.{3,})\1/;
  if (longerRepeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that includes shorthand notation (::)
  // Pattern breakdown:
  // - Full IPv6: 8 groups of 4 hex digits separated by colons
  // - Shorthand: :: for consecutive zero groups
  // - Mixed: IPv6 with IPv4 embedded
  // Exclude IPv4 addresses by not matching dotted decimal format
  
  // Pattern for IPv6 (comprehensive)
  const ipv6Pattern = /(?:[a-fA-F0-9]{1,4}:){2,7}[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:){1,7}:|(?::){1,7}[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}:){1,7}:(?![\d.]+)/;
  
  // Additional check for shorthand notation
  const shorthandPattern = /::/;
  
  // Check if the string contains IPv6 notation
  const hasColon = value.includes(':');
  if (!hasColon) {
    return false;
  }
  
  // Avoid matching IPv4 addresses (dotted decimal)
  if (/\d+\.\d+\.\d+\.\d+/.test(value)) {
    return false;
  }
  
  // Match IPv6 patterns
  return ipv6Pattern.test(value) || shorthandPattern.test(value);
}
