/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input string and add padding if needed.
 */
function normalizeBase64(input: string): string {
  // Check if input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input');
  }
  
  // Remove existing padding for normalization
  const withoutPadding = input.replace(/=+$/, '');
  
  // Calculate required padding
  const paddingLength = (4 - (withoutPadding.length % 4)) % 4;
  return withoutPadding + '='.repeat(paddingLength);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Remove whitespace
  const trimmed = input.trim();
  
  try {
    // Normalize padding and decode
    const normalized = normalizeBase64(trimmed);
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input');
  }
}
