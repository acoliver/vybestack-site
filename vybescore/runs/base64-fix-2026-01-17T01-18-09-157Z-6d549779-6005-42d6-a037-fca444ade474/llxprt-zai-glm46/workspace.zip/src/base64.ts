const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_BASE64_ERROR = 'Invalid Base64 input';
const FAILED_DECODE_ERROR = 'Failed to decode Base64 input';

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates that the input is valid Base64 and throws an error for invalid payloads.
 */
export function decode(input: string): string {
  // Remove any whitespace from the input
  const trimmed = input.trim();

  // Validate Base64 format
  if (!trimmed || !VALID_BASE64_REGEX.test(trimmed)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  // Check for invalid padding
  const paddingLength = (trimmed.match(/=/g) || []).length;
  if (paddingLength > 2) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  // Padding should only appear at the end
  if (paddingLength > 0 && !/=+$/.test(trimmed)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');

    // Check if the decoded buffer is empty when input is not just padding
    if (buffer.length === 0 && trimmed !== '') {
      throw new Error(INVALID_BASE64_ERROR);
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(FAILED_DECODE_ERROR);
  }
}
