import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function validatePaginationParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): { error?: string; page?: number; limit?: number } {
  // Parse and validate page
  let page: number;
  if (pageParam === undefined) {
    page = 1;
  } else {
    const parsedPage = Number(pageParam);
    if (isNaN(parsedPage) || !Number.isInteger(parsedPage) || parsedPage < 1) {
      return { error: 'Page must be a positive integer' };
    }
    page = parsedPage;
  }

  // Parse and validate limit
  let limit: number;
  if (limitParam === undefined) {
    limit = DEFAULT_LIMIT;
  } else {
    const parsedLimit = Number(limitParam);
    if (isNaN(parsedLimit) || !Number.isInteger(parsedLimit) || parsedLimit < 1) {
      return { error: 'Limit must be a positive integer' };
    }
    if (parsedLimit > MAX_LIMIT) {
      return { error: `Limit cannot exceed ${MAX_LIMIT}` };
    }
    limit = parsedLimit;
  }

  return { page, limit };
}

export function listInventory(
  db: Database,
  options: { page: number; limit: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = Math.floor(options.page);
  const limit = Math.floor(options.limit);

  // Fixed: offset should be (page - 1) * limit to get the correct slice
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
