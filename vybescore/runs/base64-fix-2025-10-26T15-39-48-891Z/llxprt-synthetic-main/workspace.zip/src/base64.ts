

/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Handles standard Base64 input and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate Base64 input: only allow Base64 characters and padding
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input');
  }

  // Ensure proper padding if missing
  const paddedInput = padInput(input);
  
  try {
    const result = Buffer.from(paddedInput, 'base64').toString('utf8');
    
    // Validate the decoded result is valid UTF-8
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    const normalizedInput = paddedInput.replace(/=+$/, '');
    
    if (normalizedReencoded !== normalizedInput) {
      throw new Error('Invalid Base64 input');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Add proper padding to Base64 input if missing.
 */
function padInput(input: string): string {
  // Remove any existing padding first
  const withoutPadding = input.replace(/=+$/, '');
  
  // Calculate required padding
  const paddingLength = (4 - (withoutPadding.length % 4)) % 4;
  return withoutPadding + '='.repeat(paddingLength);
}
