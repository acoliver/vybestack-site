import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// Import sql.js with type declarations
// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import initSqlJs from 'sql.js';

// Define Database interface for proper typing
interface Database {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): {
    run(...params: unknown[]): void;
    free(): void;
  };
  export(): Uint8Array;
  close(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set EJS as templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// SQLite database setup
let db: Database | null = null;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load sql.js
    const SQL = await initSqlJs();

    // Load existing database or create new one
    let dbBuffer: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      const dbFile = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(dbFile);
    }

    db = new SQL.Database(dbBuffer);

    // Read and execute schema
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    if (db) {
      db.run(schema);
    }

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation function
function validateFormData(data: FormData): { errors: string[]; valid: boolean } {
  const errors: string[] = [];

  // Required fields validation
  if (!data.firstName?.trim()) errors.push('First name is required');
  if (!data.lastName?.trim()) errors.push('Last name is required');
  if (!data.streetAddress?.trim()) errors.push('Street address is required');
  if (!data.city?.trim()) errors.push('City is required');
  if (!data.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!data.postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!data.country?.trim()) errors.push('Country is required');
  if (!data.email?.trim()) errors.push('Email is required');
  if (!data.phone?.trim()) errors.push('Phone number is required');

  // Email validation (simple regex)
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation (international format)
  if (data.phone && !/^[+]?[0-9\s\-()]+$/.test(data.phone)) {
    errors.push('Please enter a valid phone number');
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
    errors.push('Please enter a valid postal/zip code');
  }

  return {
    errors,
    valid: errors.length === 0
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    return res.render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  // Insert into database
  if (!db) {
    const errors = ['Database connection error'];
    return res.render('form', { errors, values: formData });
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database insertion error:', error);
    const errors = ['Failed to save your submission. Please try again.'];
    res.render('form', { errors, values: formData });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { firstName: 'Friend' });
});

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
    db = null;
  }
  
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  shutdown();
});

// Start the server
startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
