/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 with or without padding.
 */
const INVALID_BASE64_INPUT = 'Invalid Base64 input';
const FAILED_TO_DECODE_INPUT = 'Failed to decode Base64 input';

export function decode(input: string): string {
  // Validate input contains only Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error(INVALID_BASE64_INPUT);
  }

  // Check if input is empty after normalization
  if (!input || input.trim() === '') {
    throw new Error(INVALID_BASE64_INPUT);
  }

  // Normalize input: handle URL-safe variant and add padding if needed
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  
  // Add padding if missing
  const mod = normalized.length % 4;
  const padded = mod === 0 ? normalized : normalized + '='.repeat(4 - mod);

  try {
    const decoded = Buffer.from(padded, 'base64').toString('utf8');
    
    // Validate that the decoded result contains only valid UTF-8 characters
    // This helps catch clearly invalid Base64 input
    if (!isValidUtf8(decoded)) {
      throw new Error(INVALID_BASE64_INPUT);
    }
    
    return decoded;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid')) {
      throw error;
    }
    throw new Error(FAILED_TO_DECODE_INPUT);
  }
}

function isValidUtf8(str: string): boolean {
  try {
    // Test if we can round-trip through UTF-8 bytes
    const bytes = Buffer.from(str, 'utf8');
    const roundTrip = bytes.toString('utf8');
    return roundTrip === str;
  } catch {
    return false;
  }
}
