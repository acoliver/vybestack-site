export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportOptions {
  includeTotals: boolean;
  format: 'markdown' | 'text';
  output?: string;
}

export type Formatter = (data: ReportData, options: Pick<ReportOptions, 'includeTotals'>) => string;
