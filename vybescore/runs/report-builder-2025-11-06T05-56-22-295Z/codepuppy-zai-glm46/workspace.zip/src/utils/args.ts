import type { ReportOptions } from '../types/report.js';

export interface ParsedArgs {
  dataFile: string;
  options: ReportOptions;
}

export function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[2];
  if (!dataFile || dataFile.startsWith('--')) {
    throw new Error('Please provide a data file path');
  }

  const options: Partial<ReportOptions> = {};
  
  // Parse command line arguments
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      const format = args[i];
      if (format !== 'markdown' && format !== 'text') {
        throw new Error('Unsupported format');
      }
      options.format = format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      options.output = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!options.format) {
    throw new Error('--format is required (markdown or text)');
  }

  return {
    dataFile,
    options: {
      format: options.format as 'markdown' | 'text',
      includeTotals: options.includeTotals || false,
      output: options.output,
    },
  };
}
