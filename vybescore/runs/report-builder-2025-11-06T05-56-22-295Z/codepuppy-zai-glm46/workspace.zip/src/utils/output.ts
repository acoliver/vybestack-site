import { writeFileSync } from 'node:fs';

export function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      throw new Error(`Failed to write to output file: ${outputPath}`);
    }
  } else {
    process.stdout.write(content);
  }
}
