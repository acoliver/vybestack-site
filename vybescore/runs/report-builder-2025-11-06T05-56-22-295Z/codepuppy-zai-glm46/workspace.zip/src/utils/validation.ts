import type { ReportData, ReportEntry } from '../types/report.js';
import { readFileSync } from 'node:fs';

function validateReportEntry(entry: unknown): ReportEntry {
  if (typeof entry !== 'object' || entry === null) {
    throw new Error('Each entry must be an object');
  }

  const entryObj = entry as Record<string, unknown>;
  
  if (typeof entryObj.label !== 'string') {
    throw new Error('Each entry must have a string label');
  }
  
  if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
    throw new Error('Each entry must have a valid number amount');
  }

  return {
    label: entryObj.label,
    amount: entryObj.amount,
  };
}

export function loadAndValidateReportData(filePath: string): ReportData {
  let content: string;
  try {
    content = readFileSync(filePath, 'utf-8');
  } catch (error) {
    throw new Error(`Failed to read file: ${filePath}`);
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch (error) {
    throw new Error('Invalid JSON format');
  }

  if (typeof parsed !== 'object' || parsed === null) {
    throw new Error('JSON must be an object');
  }

  const data = parsed as Record<string, unknown>;

  if (typeof data.title !== 'string') {
    throw new Error('Report must have a string title');
  }

  if (typeof data.summary !== 'string') {
    throw new Error('Report must have a string summary');
  }

  if (!Array.isArray(data.entries)) {
    throw new Error('Report must have an entries array');
  }

  const entries = data.entries.map((entry, index) => {
    try {
      return validateReportEntry(entry);
    } catch (error) {
      throw new Error(`Invalid entry at index ${index}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  });

  return {
    title: data.title,
    summary: data.summary,
    entries,
  };
}
