#!/usr/bin/env node

import { parseArgs } from '../utils/args.js';
import { loadAndValidateReportData } from '../utils/validation.js';
import { getFormatter } from '../formatters/index.js';
import { writeOutput } from '../utils/output.js';

function main(): void {
  try {
    const { dataFile, options } = parseArgs(process.argv);
    const data = loadAndValidateReportData(dataFile);
    const formatter = getFormatter(options.format);
    const output = formatter(data, { includeTotals: options.includeTotals });
    writeOutput(output, options.output);
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    process.exit(1);
  }
}

main();
