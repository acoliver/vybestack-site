/**
 * Encode plain text to Base64 using the canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Check for valid Base64 characters only
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check for invalid padding placement
  if (input.includes('=')) {
    const paddingIndex = input.indexOf('=');
    const basePart = input.substring(0, paddingIndex);
    // Padding can only appear at the end and max 2 characters
    if (input.slice(paddingIndex).split('').some(c => c !== '=')) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
    // Must be at end and valid length
    if (paddingIndex < input.length - 2 || 
        (paddingIndex === input.length - 1 && basePart.length % 4 !== 3) ||
        (paddingIndex === input.length - 2 && basePart.length % 4 !== 2)) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
  }
  
  // Normalize padding by adding it if missing
  const paddingNeeded = (4 - (input.length % 4)) % 4;
  const normalized = input + '='.repeat(paddingNeeded);
  
  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
