/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  ObserverR,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // For tests that use default parameters, we need to handle the case where no initial value is provided
  // The update function may have default parameters like (x: number = 3)
  
  // Create a subject to track when this computed value should update
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn: undefined
  }

  // The computed observer that gets notified when dependencies change
  const computedObserver: ObserverR = {
    name: options?.name,
    updateFn: () => {
      // When notified, recompute the value and notify observers of this computed
      const prevValue = observer.value
      observer.value = updateFn(observer.value)
      subject.value = observer.value!
      
      // Only notify if value actually changed
      if (prevValue !== observer.value) {
        // Notify all observers that depend on this computed value
        for (const obs of subject.observers) {
          if ('updateFn' in obs && obs.updateFn) {
            const o = obs as Observer<unknown>
            updateObserver(o)
          }
        }
      }
    }
  } as ObserverR & { updateFn: () => void }

  // Initialize the value
  if (value !== undefined) {
    observer.value = value
    subject.value = value
  } else {
    // We need to compute the initial value
    setActiveObserver(computedObserver)
    try {
      observer.value = updateFn(undefined)
      subject.value = observer.value!
    } finally {
      setActiveObserver(undefined)
    }
  }

  const computed: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // If computed is accessed within another active observer,
      // register that observer to be notified when this computed changes
      subject.observers.add(activeObserver)
    }
    
    // Ensure we're tracking the current correct value
    // Only recompute if we don't have a cached value
    if (subject.value === undefined) {
      setActiveObserver(computedObserver)
      try {
        observer.value = updateFn(observer.value)
        subject.value = observer.value!
      } finally {
        setActiveObserver(activeObserver)
      }
    }
    
    return subject.value as T
  }

  return computed
}