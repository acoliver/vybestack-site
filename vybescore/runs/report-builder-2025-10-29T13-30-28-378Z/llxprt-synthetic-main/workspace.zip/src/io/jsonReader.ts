import { readFileSync } from 'fs';
import type { ReportData } from '../types.js';

/**
 * Read and parse JSON file with proper validation
 */
export function readJsonFile(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const parsedData = JSON.parse(fileContent);
    
    // Validate required fields
    if (!parsedData || typeof parsedData !== 'object') {
      throw new Error('Invalid JSON: expected an object');
    }
    
    if (typeof parsedData.title !== 'string') {
      throw new Error('Invalid JSON: title is required and must be a string');
    }
    
    if (typeof parsedData.summary !== 'string') {
      throw new Error('Invalid JSON: summary is required and must be a string');
    }
    
    if (!Array.isArray(parsedData.entries)) {
      throw new Error('Invalid JSON: entries is required and must be an array');
    }
    
    // Validate each entry
    for (let i = 0; i < parsedData.entries.length; i++) {
      const entry = parsedData.entries[i];
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid JSON: entry ${i} must be an object`);
      }
      
      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid JSON: entry ${i} must have a label string`);
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid JSON: entry ${i} must have an amount number`);
      }
    }
    
    return parsedData as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON syntax: ${error.message}`);
    }
    
    // Rethrow validation errors
    throw error;
  }
}