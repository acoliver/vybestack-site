import type { ReportData, ReportOptions } from '../types.js';

/**
 * Base interface for all report formatters
 */
export interface Formatter {
  render(data: ReportData, options: ReportOptions): string;
}

/**
 * Render function type for formatters
 */
export type RenderFunction = (data: ReportData, options: ReportOptions) => string;

/**
 * Registry of available formatters
 */
export const formatters = {
  markdown: () => import('./markdown.js'),
  text: () => import('./text.js'),
} as const;

export type SupportedFormat = keyof typeof formatters;