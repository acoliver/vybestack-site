import type { ReportData, ReportOptions } from '../types.js';

/**
 * Calculate the total amount from all entries
 */
function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Format amount with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Render report data in plain text format
 */
export const renderText = (data: ReportData, options: ReportOptions) => {
  const lines = [
    data.title,
    data.summary,
    'Entries:',
  ];

  // Add entries as bullet points
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  // Add total if requested
  if (options.includeTotals) {
    lines.push(`Total: ${formatAmount(calculateTotal(data))}`);
  }

  return lines.join('\n');
};