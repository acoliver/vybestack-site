#!/usr/bin/env node

import { parseArgs } from './args.js';
import { readJsonFile } from '../io/jsonReader.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { writeFileSync } from 'fs';

/**
 * Main CLI function
 */
async function main(): Promise<void> {
  try {
    // Parse command line arguments
    const { filePath, options } = parseArgs(process.argv);

    // Read and validate JSON data
    const data = readJsonFile(filePath);

    // Select renderer based on format option
    const render = options.format === 'markdown' ? renderMarkdown : renderText;

    // Generate report
    const report = render(data, options);

    // Write output
    if (options.outputPath) {
      writeFileSync(options.outputPath, report, 'utf8');
    } else {
      console.log(report);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

// Run the CLI
main();
