import type { ReportOptions } from '../types.js';

/**
 * Parse command line arguments using Node.js standard library
 */
export function parseArgs(argv: string[]): { filePath: string; options: ReportOptions } {
  const args = argv.slice(2); // Remove node path and script name
  
  // Check minimum required arguments
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const filePath = args[0];
  
  // Initialize default options
  const options: ReportOptions = {
    format: 'text', // Will be overridden by --format
    includeTotals: false,
  };

  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          throw new Error('--format requires a value');
        }
        i++;
        {
          const formatValue = args[i];
          if (formatValue !== 'markdown' && formatValue !== 'text') {
            throw new Error('Unsupported format');
          }
          options.format = formatValue;
        }
        break;
        
      case '--output':
        if (i + 1 >= args.length) {
          throw new Error('--output requires a value');
        }
        i++;
        {
          options.outputPath = args[i];
        }
        break;
        
      case '--includeTotals':
        options.includeTotals = true;
        break;
        
      default:
        throw new Error(`Unknown argument: ${args[i]}`);
    }
  }

  // Verify that format was provided
  if (!options.format) {
    throw new Error('--format is required');
  }

  return { filePath, options };
}