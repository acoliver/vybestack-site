/**
 * Represents a single entry in a report
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Represents the full report data structure from JSON
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * CLI options passed to the report generator
 */
export interface ReportOptions {
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}