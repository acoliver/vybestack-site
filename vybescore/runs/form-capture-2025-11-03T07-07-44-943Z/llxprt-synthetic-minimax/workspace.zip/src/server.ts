import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'submissions.sqlite');

interface FormData {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;

async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: () => {
      const path = require('path');
      return path.join(require.resolve('sql.js'), '..', 'dist', 'sql-wasm.wasm');
    }
  });

  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (fs.existsSync(DB_FILE)) {
    const buffer = fs.readFileSync(DB_FILE);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(__dirname, '..', '..', 'db', 'schema.sql'), 'utf8');
    db.exec(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    fs.writeFileSync(DB_FILE, Buffer.from(data));
  }
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'first_name',
    'last_name',
    'street_address',
    'city',
    'state_province',
    'postal_code',
    'country',
    'email',
    'phone'
  ];

  requiredFields.forEach((field) => {
    if (!data[field] || data[field]!.trim() === '') {
      errors.push({ field, message: `${field.replace('_', ' ')} is required` });
    }
  });

  // Email validation
  if (data.email && data.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.push({ field: 'email', message: 'Invalid email format' });
    }
  }

  // Phone validation
  if (data.phone && data.phone.trim() !== '') {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Invalid phone number format' });
    }
  }

  // Postal code validation (alphanumeric)
  if (data.postal_code && data.postal_code.trim() !== '') {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(data.postal_code)) {
      errors.push({ field: 'postal_code', message: 'Invalid postal code format' });
    }
  }

  return errors;
}

const app = express();

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// GET / - Render form
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    formData: {} as FormData,
    errors: [] as ValidationError[]
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response, next: NextFunction) => {
  try {
    const formData: FormData = req.body;

    // Validate form data
    const errors = validateFormData(formData);

    if (errors.length > 0) {
      // Re-render form with errors and previous values
      return res.status(200).render('form', {
        formData,
        errors
      });
    }

    // Insert into database
    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.first_name!.trim(),
        formData.last_name!.trim(),
        formData.street_address!.trim(),
        formData.city!.trim(),
        formData.state_province!.trim(),
        formData.postal_code!.trim(),
        formData.country!.trim(),
        formData.email!.trim(),
        formData.phone!.trim()
      ]);

      stmt.free();
      saveDatabase();
    }

    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    next(error);
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  // Get the first name from the most recent submission
  let firstName = 'valued user';
  
  if (db) {
    try {
      const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      const result = stmt.step();
      if (result) {
        const row = stmt.getAsObject();
        firstName = row['first_name'] as string || 'valued user';
      }
      stmt.free();
    } catch (error) {
      console.error('Error fetching first name:', error);
    }
  }

  res.render('thank-you', { firstName });
});

// Graceful shutdown
async function shutdown() {
  console.log('\nShutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
initializeDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  });