/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const observers: Set<Observer<unknown>> = new Set()

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      observers.add(observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const prevValue = s.value
    s.value = nextValue
    
    // Check if value actually changed (if equal function provided)
    let changed = true
    if (s.equalFn) {
      changed = !s.equalFn(prevValue, nextValue)
    } else if (_equal === false) {
      changed = prevValue !== nextValue
    }
    
    if (changed) {
      // Notify all observers that depend on this input
      // Use a copy of the set to avoid issues if observers are added/removed during iteration
      const observersCopy = Array.from(observers)
      observersCopy.forEach((observer) => updateObserver(observer as Observer<unknown>))
    }
    
    return s.value
  }

  return [read, write]
}
