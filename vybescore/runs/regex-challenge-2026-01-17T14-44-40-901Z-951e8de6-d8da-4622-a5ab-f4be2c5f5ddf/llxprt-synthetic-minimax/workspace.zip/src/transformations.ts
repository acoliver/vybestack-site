/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Normalize spacing by collapsing multiple spaces
  const normalizedText = text.replace(/\s+/g, ' ');
  
  // Capitalize first letter of the entire text
  let result = normalizedText.charAt(0).toUpperCase() + normalizedText.substring(1);
  
  // Capitalize first letter after sentence ending punctuation
  result = result.replace(/([.!?])\s+([a-z])/g, (match, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Simple and direct URL pattern
  const urlPattern = /https?:\/\/[a-zA-Z0-9.-]+/g;
  
  const matches = text.match(urlPattern);
  
  if (!matches) {
    return [];
  }
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that shouldn't be part of the URL
    return url.replace(/[.,;:!?]+$/g, '').replace(/[>"']+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs with http scheme - fix to properly capture host and path
  const httpUrlPattern = /http:\/\/([^\s<>"'&:;!?)]+)([^\s<>"'&:;!?)]*)/g;
  
  return text.replace(httpUrlPattern, (match, host, path) => {
    let newUrl = 'https://' + host;
    
    // Check if the full URL (host + path) begins with /docs/ after the domain
    const fullUrl = host + path;
    if (fullUrl.startsWith('/docs/') || fullUrl.includes('/docs/')) {
      // Skip host rewrite if path contains dynamic hints
      const hasDynamicHints = /(\?|=|&|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.host.com
        const hostParts = host.split('.');
        if (hostParts.length >= 2) {
          newUrl = 'https://docs.' + host + path;
          return newUrl;
        }
      }
    }
    
    // Default: just upgrade scheme to https
    newUrl += path;
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional basic validation for month/day combinations
  // This is a simple check - could be more comprehensive
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Simplified, doesn't handle leap years properly
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
