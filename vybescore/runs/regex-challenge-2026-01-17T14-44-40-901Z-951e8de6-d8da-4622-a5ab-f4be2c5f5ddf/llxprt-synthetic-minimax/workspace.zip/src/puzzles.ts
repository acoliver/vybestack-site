/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a pattern that matches words starting with the prefix
  // Word boundary, then prefix, then word characters
  const pattern = new RegExp(`\\b${prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\w*`, 'g');
  
  const matches = text.match(pattern);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions
  return matches.filter(word => {
    const wordLower = word.toLowerCase();
    const prefixLower = prefix.toLowerCase();
    
    return !exceptions.some(exception => {
      const exceptionLower = exception.toLowerCase();
      // Check if this is the exact word (accounting for prefix)
      return wordLower === prefixLower + exceptionLower || 
             wordLower.startsWith(prefixLower) && 
             exceptions.some(ex => wordLower === prefixLower + ex.toLowerCase());
    });
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern using lookbehind to find token that appears after a digit
  // This should capture the entire token after the digit
  const pattern = new RegExp(`(?<=\\d)${token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // If we have matches, we need to reconstruct the full embedded token including the digit
  // Let's use a different approach - find all tokens preceded by a digit
  const fullPattern = new RegExp(`\\d${token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, 'g');
  
  const fullMatches = text.match(fullPattern) || [];
  
  return fullMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\|,.<>\/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // Look for patterns like abab, 1212, XYXY, etc.
  const repeatPattern = /(\w\w)\1/; // Looking for 2-character sequences repeated
  if (repeatPattern.test(value)) {
    return false;
  }
  
  // Check for longer repeated sequences like ABCABC or 123123
  const longerRepeatPattern = /(\w{3,})\1/;
  if (longerRepeatPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if this looks like an IPv4 address - if so, return false immediately
  if (/^\d+\.\d+\.\d+\.\d+$/.test(value)) {
    return false;
  }
  
  // Check if this is a pure IPv4 address anywhere in the string (but not mixed IPv6/IPv4)
  // If the string contains only IPv4 patterns, it's not IPv6
  const onlyIpv4 = /^.*\d+\.\d+\.\d+\.\d+.*$/;
  if (onlyIpv4.test(value) && !value.includes(':')) {
    return false;
  }
  
  // IPv6 pattern that handles various formats including shorthand `::`
  // This should match patterns like:
  // - 2001:db8::1 (compressed with ::)
  // - 2001:0db8:0000:0000:0000:ff00:0042:0329 (full form)
  // - ::1 (loopback shorthand)
  // - :: (all zeros shorthand)
  // Simple approach: look for hex characters and colons, but exclude pure IPv4
  
  // Check for IPv6 with text before it (like "Address: ")
  const textPattern = /.*[0-9a-fA-F]*:[0-9a-fA-F]*.*/;
  
  // If it doesn't look like IPv6 at all, return false
  if (!textPattern.test(value)) {
    return false;
  }
  
  // Check for compressed notation with ::
  if (/::/.test(value)) {
    // Allow compressed IPv6 with hex digits and colons, handle text before
    const compressedPattern = /.*[0-9a-fA-F]*:[0-9a-fA-F]*::[0-9a-fA-F:]*.*/;
    if (compressedPattern.test(value)) {
      return true;
    }
  }
  
  // Check for standard IPv6 notation (with colons but not dots)
  if (value.includes(':') && !value.includes('.')) {
    const standardPattern = /.*[0-9a-fA-F]*:[0-9a-fA-F:]*[0-9a-fA-F:]*.*/;
    if (standardPattern.test(value)) {
      return true;
    }
  }
  
  // Check if it's IPv6+IPv4 mixed format (valid IPv6)
  const mixedPattern = /.*[0-9a-fA-F]*:[0-9a-fA-F]*:\d+\.\d+\.\d+\.\d+.*/;
  if (mixedPattern.test(value)) {
    return true;
  }
  
  return false;
}