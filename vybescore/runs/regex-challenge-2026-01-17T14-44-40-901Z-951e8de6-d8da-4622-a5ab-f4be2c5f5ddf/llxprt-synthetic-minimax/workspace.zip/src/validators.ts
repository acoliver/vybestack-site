export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation pattern
  // Rejects: domains with underscores, trailing dots, double dots
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid forms
  const [localPart, domain] = value.split('@');
  
  // Check for trailing dots in domain
  if (domain.endsWith('.')) {
    return false;
  }
  
  // Check for double dots in local part
  if (localPart.includes('..')) {
    return false;
  }
  
  // Check for underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  const cleanValue = value.replace(/[\s\-().]/g, '');
  
  // Check for optional +1 prefix
  let normalizedValue = cleanValue;
  if (normalizedValue.startsWith('1') && normalizedValue.length === 11) {
    normalizedValue = normalizedValue.substring(1);
  }
  
  // US phone must be 10 digits total (3 area code + 7 subscriber)
  if (normalizedValue.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = normalizedValue.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check format patterns using cleaned value
  const formats = [
    /^\d{10}$/,                     // 2125557890
    /^\(\d{3}\)\s?\d{3}\s?\d{4}$/,  // (212) 555-7890
    /^\d{3}\s?-\s?\d{3}\s?\d{4}$/, // 212-555-7890
    /^\+1\s?\d{3}\s?\d{3}\s?\d{4}$/, // +1 212-555-7890
  ];
  
  // Check cleaned format
  if (formats[0].test(normalizedValue)) {
    return true;
  }
  
  // Check original value against other formats
  if (formats[1].test(value) || formats[2].test(value) || formats[3].test(value)) {
    return true;
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators and punctuation
  const cleanValue = value.replace(/[\s\-().+]/g, '');
  
  // Pattern that handles various Argentine phone formats:
  // Optional +54 country code, optional 9 for mobile, area 2-4 digits (1-9), subscriber 6-8 digits
  const patterns = [
    /^54[1-9]\d{1,3}\d{6,8}$/,      // With country code: 54[area][subscriber] (landline)
    /^549[1-9]\d{1,3}\d{6,8}$/,     // With country + mobile: 549[area][subscriber]  
    /^0[1-9]\d{1,3}\d{6,8}$/,       // National format: 0[area][subscriber]
    /^09[1-9]\d{1,3}\d{6,8}$/,      // National with mobile: 09[area][subscriber]
  ];
  
  // Check if any pattern matches
  return patterns.some(pattern => pattern.test(cleanValue));
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check if empty or only whitespace
  if (!value.trim()) {
    return false;
  }
  
  // Allow unicode letters, spaces, apostrophes, hyphens
  // Reject digits and symbols
  const namePattern = /^[\p{L}\s'\-]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Reject names that contain digits anywhere
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names that contain symbols (other than allowed ' and -)
  if (/[^\p{L}\s'\-]/u.test(value)) {
    return false;
  }
  
  // Reject obviously invalid patterns like "X Æ A-12" style
  if (value.includes('Æ') || /X.*A.*\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const cleanNumber = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cleanNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cleanNumber[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanNumber = value.replace(/\D/g, '');
  
  // Check for empty or very short numbers
  if (cleanNumber.length < 13 || cleanNumber.length > 19) {
    return false;
  }
  
  // Check card type and validate prefix/length
  let isValidCard = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (cleanNumber.startsWith('4')) {
    isValidCard = cleanNumber.length === 13 || cleanNumber.length === 16 || cleanNumber.length === 19;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if (cleanNumber.startsWith('51') || cleanNumber.startsWith('52') || 
           cleanNumber.startsWith('53') || cleanNumber.startsWith('54') || 
           cleanNumber.startsWith('55') ||
           (cleanNumber.startsWith('2221') && parseInt(cleanNumber.substring(0, 4)) >= 2221 && 
            parseInt(cleanNumber.substring(0, 4)) <= 2720) ||
           cleanNumber.startsWith('2720')) {
    isValidCard = cleanNumber.length === 16;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((cleanNumber.startsWith('34') || cleanNumber.startsWith('37'))) {
    isValidCard = cleanNumber.length === 15;
  }
  
  if (!isValidCard) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleanNumber);
}
