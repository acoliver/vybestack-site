const validators = require('./dist/src/validators.js');
const transformations = require('./dist/src/transformations.js');
const puzzles = require('./dist/src/puzzles.js');

console.log('=== Testing Validators ===');

// Test email edge cases
console.log('Email edge cases:');
console.log('Valid: user@tag@example.co.uk', validators.isValidEmail('user@tag@example.co.uk'));
console.log('Invalid: user..name@example.com', validators.isValidEmail('user..name@example.com'));
console.log('Invalid: user@example_.com', validators.isValidEmail('user@example_.com'));
console.log('Invalid: user@example.com.', validators.isValidEmail('user@example.com.'));

// Test US phone edge cases
console.log('US phone edge cases:');
console.log('Valid: +1 (212) 555-7890', validators.isValidUSPhone('+1 (212) 555-7890'));
console.log('Valid: 2125557890', validators.isValidUSPhone('2125557890'));
console.log('Invalid: 212-555-789', validators.isValidUSPhone('212-555-789'));
console.log('Invalid: 012-555-7890', validators.isValidUSPhone('012-555-7890'));

// Test Argentine phone edge cases
console.log('Argentine phone edge cases:');
console.log('Valid: +54 9 11 1234 5678', validators.isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('Valid: 011 1234 5678', validators.isValidArgentinePhone('011 1234 5678'));
console.log('Valid: +54 341 123 4567', validators.isValidArgentinePhone('+54 341 123 4567'));
console.log('Valid: 0341 4234567', validators.isValidArgentinePhone('0341 4234567'));
console.log('Invalid: 001 1234 5678', validators.isValidArgentinePhone('001 1234 5678'));

// Test name edge cases
console.log('Name edge cases:');
console.log('Valid: José María García-López', validators.isValidName('José María García-López'));
console.log('Valid: O\'Brien-Smith', validators.isValidName('O\'Brien-Smith'));
console.log('Invalid: John123', validators.isValidName('John123'));
console.log('Invalid: X Æ A-12', validators.isValidName('X Æ A-12'));

// Test credit card edge cases
console.log('Credit card edge cases:');
console.log('Valid: 4111111111111111 (Visa)', validators.isValidCreditCard('4111111111111111'));
console.log('Valid: 5105105105105100 (Mastercard)', validators.isValidCreditCard('5105105105105100'));
console.log('Valid: 378282246310005 (AmEx)', validators.isValidCreditCard('378282246310005'));
console.log('Invalid: 4111111111111112', validators.isValidCreditCard('4111111111111112'));
console.log('Invalid: 123456789012', validators.isValidCreditCard('123456789012'));

console.log('\n=== Testing Transformations ===');

console.log('Capitalize sentences:');
console.log(transformations.capitalizeSentences('hello world. how are you?')).toBe();
console.log(transformations.capitalizeSentences('hello world. how are you?'));

console.log('\nExtract URLs:');
console.log(transformations.extractUrls('Visit http://example.com today. Also check https://test.com!'));

console.log('\nEnforce HTTPS:');
console.log(transformations.enforceHttps('http://example.com and https://secure.com'));

console.log('\nRewrite docs URLs:');
console.log(transformations.rewriteDocsUrls('See http://example.com/docs/guide for more info'));
console.log(transformations.rewriteDocsUrls('See http://example.com/cgi-bin/test?param=1'));

console.log('\nExtract year:');
console.log('Valid:', transformations.extractYear('01/31/2024'));
console.log('Invalid:', transformations.extractYear('not-a-date'));

console.log('\n=== Testing Puzzles ===');

console.log('Find prefixed words:');
console.log(puzzles.findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));

console.log('\nFind embedded tokens:');
console.log(puzzles.findEmbeddedToken('xfoo 1foo foo', 'foo'));

console.log('\nStrong password:');
console.log('Valid:', puzzles.isStrongPassword('Abcdef!234'));
console.log('Invalid (too short):', puzzles.isStrongPassword('Ab!1'));
console.log('Invalid (has space):', puzzles.isStrongPassword('Abcdef !234'));
console.log('Invalid (no uppercase):', puzzles.isStrongPassword('abcdef!234'));
console.log('Invalid (no symbol):', puzzles.isStrongPassword('Abcdef234'));
console.log('Invalid (repeated):', puzzles.isStrongPassword('abab!234'));

console.log('\nContains IPv6:');
console.log('Valid IPv6:', puzzles.containsIPv6('Address: 2001:db8::1'));
console.log('Invalid IPv4:', puzzles.containsIPv6('192.168.1.1'));
console.log('Mixed format:', puzzles.containsIPv6('::ffff:192.168.1.1'));