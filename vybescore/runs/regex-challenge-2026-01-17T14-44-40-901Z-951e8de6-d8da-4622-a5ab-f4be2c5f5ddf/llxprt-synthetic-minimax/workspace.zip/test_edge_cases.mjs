import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/src/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/src/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './dist/src/puzzles.js';

console.log('=== Testing Validators ===');

// Test email edge cases
console.log('Email edge cases:');
console.log('Valid: user@tag@example.co.uk', isValidEmail('user@tag@example.co.uk'));
console.log('Invalid: user..name@example.com', isValidEmail('user..name@example.com'));
console.log('Invalid: user@example_.com', isValidEmail('user@example_.com'));
console.log('Invalid: user@example.com.', isValidEmail('user@example.com.'));

// Test US phone edge cases
console.log('US phone edge cases:');
console.log('Valid: +1 (212) 555-7890', isValidUSPhone('+1 (212) 555-7890'));
console.log('Valid: 2125557890', isValidUSPhone('2125557890'));
console.log('Invalid: 212-555-789', isValidUSPhone('212-555-789'));
console.log('Invalid: 012-555-7890', isValidUSPhone('012-555-7890'));

// Test Argentine phone edge cases
console.log('Argentine phone edge cases:');
console.log('Valid: +54 9 11 1234 5678', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('Valid: 011 1234 5678', isValidArgentinePhone('011 1234 5678'));
console.log('Valid: +54 341 123 4567', isValidArgentinePhone('+54 341 123 4567'));
console.log('Valid: 0341 4234567', isValidArgentinePhone('0341 4234567'));
console.log('Invalid: 001 1234 5678', isValidArgentinePhone('001 1234 5678'));

// Test name edge cases
console.log('Name edge cases:');
console.log('Valid: José María García-López', isValidName('José María García-López'));
console.log('Valid: O\'Brien-Smith', isValidName('O\'Brien-Smith'));
console.log('Invalid: John123', isValidName('John123'));
console.log('Invalid: X Æ A-12', isValidName('X Æ A-12'));

// Test credit card edge cases
console.log('Credit card edge cases:');
console.log('Valid: 4111111111111111 (Visa)', isValidCreditCard('4111111111111111'));
console.log('Valid: 5105105105105100 (Mastercard)', isValidCreditCard('5105105105105100'));
console.log('Valid: 378282246310005 (AmEx)', isValidCreditCard('378282246310005'));
console.log('Invalid: 4111111111111112', isValidCreditCard('4111111111111112'));
console.log('Invalid: 123456789012', isValidCreditCard('123456789012'));

console.log('\n=== Testing Transformations ===');

console.log('Capitalize sentences:');
console.log('Input: hello world. how are you?');
console.log('Output:', capitalizeSentences('hello world. how are you?'));

console.log('\nExtract URLs:');
console.log('Input: Visit http://example.com today. Also check https://test.com!');
console.log('Output:', extractUrls('Visit http://example.com today. Also check https://test.com!'));

console.log('\nEnforce HTTPS:');
console.log('Input: http://example.com and https://secure.com');
console.log('Output:', enforceHttps('http://example.com and https://secure.com'));

console.log('\nRewrite docs URLs:');
console.log('Input: See http://example.com/docs/guide for more info');
console.log('Output:', rewriteDocsUrls('See http://example.com/docs/guide for more info'));
console.log('Input: See http://example.com/cgi-bin/test?param=1');
console.log('Output:', rewriteDocsUrls('See http://example.com/cgi-bin/test?param=1'));

console.log('\nExtract year:');
console.log('Valid: 01/31/2024 ->', extractYear('01/31/2024'));
console.log('Invalid: not-a-date ->', extractYear('not-a-date'));

console.log('\n=== Testing Puzzles ===');

console.log('Find prefixed words:');
console.log('Input: preview prevent prefix, prefix: "pre", exceptions: ["prevent"]');
console.log('Output:', findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));

console.log('\nFind embedded tokens:');
console.log('Input: xfoo 1foo foo, token: "foo"');
console.log('Output:', findEmbeddedToken('xfoo 1foo foo', 'foo'));

console.log('\nStrong password:');
console.log('Valid: Abcdef!234 ->', isStrongPassword('Abcdef!234'));
console.log('Invalid (too short): Ab!1 ->', isStrongPassword('Ab!1'));
console.log('Invalid (has space): Abcdef !234 ->', isStrongPassword('Abcdef !234'));
console.log('Invalid (no uppercase): abcdef!234 ->', isStrongPassword('abcdef!234'));
console.log('Invalid (no symbol): Abcdef234 ->', isStrongPassword('Abcdef234'));
console.log('Invalid (repeated): abab!234 ->', isStrongPassword('abab!234'));

console.log('\nContains IPv6:');
console.log('Valid IPv6: Address: 2001:db8::1 ->', containsIPv6('Address: 2001:db8::1'));
console.log('Invalid IPv4: 192.168.1.1 ->', containsIPv6('192.168.1.1'));
console.log('Mixed format: ::ffff:192.168.1.1 ->', containsIPv6('::ffff:192.168.1.1'));