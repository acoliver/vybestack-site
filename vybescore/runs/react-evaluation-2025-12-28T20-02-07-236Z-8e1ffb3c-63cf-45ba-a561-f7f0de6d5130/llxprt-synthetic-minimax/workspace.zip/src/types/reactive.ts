/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Registry for tracking dependencies
const subjects = new WeakMap<object, Set<Observer<T>>>()
const computedByUpdateFn = new WeakMap<unknown, Observer<unknown>>()

// Get or create dependent set for a subject
function getDependents<T>(subject: object): Set<Observer<T>> {
  if (!subjects.has(subject)) {
    subjects.set(subject, new Set())
  }
  return subjects.get(subject)! as Set<Observer<T>>
}

// Register an observer as dependent on a subject
export function registerDependency<T>(subject: object, observer: Observer<T>) {
  getDependents<T>(subject).add(observer)
}

// Notify all dependents of a subject to update
export function notifySubjectDependents(subject: object) {
  if (subjects.has(subject)) {
    const dependents = subjects.get(subject)!
    dependents.forEach(observer => {
      updateObserver(observer)
    })
  }
}

// Check if computed observer exists for update function
export function getComputedObserver<T>(updateFn: UpdateFn<T>): Observer<T> | undefined {
  return computedByUpdateFn.get(updateFn) as Observer<T> | undefined
}

// Store computed observer for update function
export function setComputedObserver<T>(updateFn: UpdateFn<T>, observer: Observer<T>) {
  computedByUpdateFn.set(updateFn, observer as Observer<unknown>)
}
