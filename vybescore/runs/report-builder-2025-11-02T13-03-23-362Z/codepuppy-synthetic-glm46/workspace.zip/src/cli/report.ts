#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, RenderOptions, ReportRenderer } from '../types/index.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const result: CliArgs = {
    dataFile: args[0],
    format: '',
    includeTotals: false,
  };

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        result.format = args[i + 1];
        i++; // Skip next arg
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a path');
          process.exit(1);
        }
        result.outputPath = args[i + 1];
        i++; // Skip next arg
        break;
      case '--includeTotals':
        result.includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument: ${args[i]}`);
        process.exit(1);
    }
  }

  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries field');
  }

  for (const [i, entry] of obj.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry ${i} is not an object`);
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i} has missing or invalid label`);
    }
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${i} has missing or invalid amount`);
    }
  }

  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArgs();

    // Load and validate JSON data
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(args.dataFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in ${args.dataFile}: ${error.message}`);
      } else {
        console.error(`Error: Failed to read ${args.dataFile}: ${error}`);
      }
      process.exit(1);
    }

    const reportData = validateReportData(jsonData);

    const options: RenderOptions = {
      format: args.format as 'markdown' | 'text',
      includeTotals: args.includeTotals,
    };

    // Select renderer
    let renderer: ReportRenderer;
    switch (args.format) {
      case 'markdown':
        renderer = renderMarkdown;
        break;
      case 'text':
        renderer = renderText;
        break;
      default:
        console.error(`Error: Unsupported format: ${args.format}`);
        process.exit(1);
    }

    // Generate report
    const output = renderer(reportData, options);

    // Write output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error: Failed to write to ${args.outputPath}: ${error}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error}`);
    process.exit(1);
  }
}

// Check if this file is being run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
