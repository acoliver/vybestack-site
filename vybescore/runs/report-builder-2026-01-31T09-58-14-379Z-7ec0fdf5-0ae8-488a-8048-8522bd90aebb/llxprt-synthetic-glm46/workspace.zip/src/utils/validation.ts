import { ReportData } from '../types.js';
import * as fs from 'node:fs';

export const validateReportData = (data: unknown): ReportData => {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (must be an array)');
  }

  const entries = obj.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "label" field (must be a string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "amount" field (must be a number)`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries
  };
};

export const validateFileExists = (filePath: string): void => {
  if (!fs.existsSync(filePath)) {
    throw new Error(`File not found: ${filePath}`);
  }
};

export const parseJSONFile = (filePath: string): unknown => {
  try {
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(fileContent);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
};