#!/usr/bin/env node

import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { validateReportData, validateFileExists, parseJSONFile } from '../utils/validation.js';
import { CLIOptions } from '../types.js';
import * as fs from 'node:fs';

const SUPPORTED_FORMATS = ['markdown', 'text'] as const;

const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText
} as const;

const parseArguments = (): CLIOptions & { inputPath: string } => {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const result: Partial<CLIOptions & { inputPath: string }> = {};
  
  for (let i = 0; i < args.length; i++) {
    if (i === 0) {
      result.inputPath = args[i];
    } else if (args[i] === '--format' && i + 1 < args.length) {
      const format = args[i + 1] as CLIOptions['format'];
      if (!SUPPORTED_FORMATS.includes(format)) {
        console.error(`Unsupported format: ${format}. Supported formats: ${SUPPORTED_FORMATS.join(', ')}`);
        process.exit(1);
      }
      result.format = format;
      i++;
    } else if (args[i] === '--output' && i + 1 < args.length) {
      result.output = args[i + 1];
      i++;
    } else if (args[i] === '--includeTotals') {
      result.includeTotals = true;
    } else {
      console.error(`Unknown argument: ${args[i]}`);
      process.exit(1);
    }
  }

  if (!result.inputPath || !result.format) {
    console.error('Missing required arguments. Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return result as CLIOptions & { inputPath: string };
};

const main = (): void => {
  try {
    const { inputPath, format, output, includeTotals } = parseArguments();
    
    validateFileExists(inputPath);
    
    const rawData = parseJSONFile(inputPath);
    const reportData = validateReportData(rawData);
    
    const renderer = formatRenderers[format];
    const renderedReport = renderer(reportData, { includeTotals });
    
    if (output) {
      fs.writeFileSync(output, renderedReport);
    } else {
      console.log(renderedReport);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'An unknown error occurred');
    process.exit(1);
  }
};

main();
