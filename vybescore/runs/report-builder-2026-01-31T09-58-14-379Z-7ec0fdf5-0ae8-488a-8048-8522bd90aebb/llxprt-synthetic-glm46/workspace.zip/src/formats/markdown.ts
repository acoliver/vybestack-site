import { ReportData, FormatRenderer } from '../types.js';

const formatAmount = (amount: number): string => {
  return `$${amount.toFixed(2)}`;
};

const calculateTotal = (entries: ReportData['entries']): number => {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
};

export const renderMarkdown: FormatRenderer['render'] = (data, options) => {
  const lines = [
    `# ${data.title}`,
    '',
    data.summary,
    '',
    '## Entries',
    ...data.entries.map(entry => `- **${entry.label}** — ${formatAmount(entry.amount)}`)
  ];

  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }

  return lines.join('\n');
};