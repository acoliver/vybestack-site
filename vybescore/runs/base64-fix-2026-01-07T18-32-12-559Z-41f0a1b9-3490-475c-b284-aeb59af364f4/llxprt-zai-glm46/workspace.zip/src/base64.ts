/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input string.
 * Returns true if the input is valid Base64, false otherwise.
 */
function isValidBase64(input: string): boolean {
  // Remove any padding for validation
  const withoutPadding = input.replace(/=+$/, '');
  
  // Check if the string (after padding removal) is a valid base64 string
  // Valid Base64 characters: A-Z, a-z, 0-9, +, /
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Pattern.test(input)) {
    return false;
  }
  
  // Check for invalid characters by attempting to decode and verify length
  try {
    Buffer.from(input, 'base64');
    // For valid base64, after removing padding, the length must be divisible by 4
    // OR if there's padding, the total length (with padding) must be divisible by 4
    if (input.includes('=')) {
      return input.length % 4 === 0;
    }
    return withoutPadding.length % 4 === 0 || withoutPadding.length % 4 === 2 || withoutPadding.length % 4 === 3;
  } catch {
    return false;
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Failed to decode Base64 input: empty input');
  }
  
  // Validate the input format
  if (!isValidBase64(input)) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
