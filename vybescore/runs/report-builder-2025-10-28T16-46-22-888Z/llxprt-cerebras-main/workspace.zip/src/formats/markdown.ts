import { ReportData } from './README.md'; // Interface shared across formatters

export function renderMarkdown(data: ReportData, includeTotals: boolean = false): string {
  let result = `# ${data.title}\n\n`;
  result += `${data.summary}\n\n`;
  result += '## Entries\n';

  for (const entry of data.entries) {
    result += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  }

  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    result += `\n**Total:** $${total.toFixed(2)}\n`;
  }

  return result;
}