/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export { activeObserver }

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Global registry to track which observers depend on which subjects
const subjectObservers = new Map<Subject<unknown>, ObserverR[]>()

export function getSubjectObservers(subject: Subject<unknown>): ObserverR[] {
  let observers = subjectObservers.get(subject)
  if (!observers) {
    observers = []
    subjectObservers.set(subject, observers)
  }
  return observers
}

export function addSubjectObserver(subject: Subject<unknown>, observer: ObserverR): void {
  const observers = getSubjectObservers(subject)
  if (!observers.includes(observer)) {
    observers.push(observer)
  }
}

export function removeSubjectObserver(subject: Subject<unknown>, observer: ObserverR): void {
  const observers = getSubjectObservers(subject)
  const index = observers.indexOf(observer)
  if (index !== -1) {
    observers.splice(index, 1)
  }
}

export function trackDependency(subject: Subject<unknown>): void {
  const observer = getActiveObserver()
  if (observer) {
    // Link observer to subject
    if (!subject.observer) {
      subject.observer = observer
    }
    // Also add to global registry
    addSubjectObserver(subject, observer)
  }
}

export function notifySubjectObservers<T>(subject: Subject<T>): void {
  const observers = getSubjectObservers(subject as Subject<unknown>)
  for (const observer of observers) {
    if ('updateFn' in observer) {
      updateObserver(observer as Observer<T>)
    }
  }
}

// Registry for computed values
const computedObservers = new Map<Observer<unknown>, {
  recompute: () => void
  subjects: Subject<unknown>[]
  dependents: Observer<unknown>[]
}>()

export function registerComputed<T>(
  observer: Observer<T>,
  recompute: () => void,
  subjects: Subject<unknown>[]
): void {
  computedObservers.set(observer as Observer<unknown>, {
    recompute,
    subjects,
    dependents: []
  })
}

export function addDependent(observer: Observer<unknown>, dependent: Observer<unknown>): void {
  const entry = computedObservers.get(observer)
  if (entry && !entry.dependents.includes(dependent)) {
    entry.dependents.push(dependent)
  }
}

export function getComputedSubjects(observer: Observer<unknown>): Subject<unknown>[] {
  const entry = computedObservers.get(observer)
  return entry ? entry.subjects : []
}

export function getComputedDependents(observer: Observer<unknown>): Observer<unknown>[] {
  const entry = computedObservers.get(observer)
  return entry ? entry.dependents : []
}
