/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

// Global registry to track computed values
const computedRegistry = new Map<GetterFn<unknown>, {
  observer: Observer<unknown>
  recompute: () => void
  dependents: ObserverR[]
}>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const hasInitialValue = arguments.length >= 2
  
  const o: Observer<T> = {
    name: options?.name,
    value: hasInitialValue ? value : undefined,
    updateFn,
  }
  
  let cachedValue = hasInitialValue ? value : undefined
  const dependents: ObserverR[] = []
  
  const recomputeValue = () => {
    // Update the cached value by recomputing
    const newValue = o.updateFn(o.value)
    if (newValue !== undefined) {
      cachedValue = newValue
      o.value = newValue
    }
    
    // Recursively update computed dependents when this computed value changes
    for (const dependent of dependents) {
      // Trigger recompute for dependent computed values
      const dependentEntry = Array.from(computedRegistry.values()).find(
        entry => entry.observer === dependent
      )
      if (dependentEntry) {
        dependentEntry.recompute()
      } else {
        // For callbacks or other observers, just update them
        if ('updateFn' in dependent) {
          updateObserver(dependent as Observer<unknown>)
        }
      }
    }
  }
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !dependents.includes(observer)) {
      dependents.push(observer)
    }
    
    if (cachedValue === undefined) {
      recomputeValue()
    }
    
    return cachedValue as T
  }
  
  // Register in the registry before initial computation
  computedRegistry.set(getter as GetterFn<unknown>, {
    observer: o as Observer<unknown>,
    recompute: recomputeValue,
    dependents
  })
  
  // Initial computation
  recomputeValue()
  
  return getter
}