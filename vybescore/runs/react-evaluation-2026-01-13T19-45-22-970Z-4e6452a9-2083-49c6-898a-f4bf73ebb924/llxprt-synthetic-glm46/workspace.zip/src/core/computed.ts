/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  updateObserver,
  getActiveObserver,
  registerComputed,
  addDependent,
  getComputedDependents
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const hasInitialValue = arguments.length >= 2
  
  const observer: Observer<T> = {
    name: options?.name,
    value: hasInitialValue ? value : undefined,
    updateFn,
  }
  
  let cachedValue = hasInitialValue ? value : undefined
  
  const recomputeValue = () => {
    // Update the cached value by recomputing
    const newValue = observer.updateFn(observer.value)
    if (newValue !== undefined) {
      cachedValue = newValue
      observer.value = newValue
    }
    
    // Update all dependents when this computed value changes
    for (const dependent of getComputedDependents(observer as Observer<unknown>)) {
      updateObserver(dependent as Observer<unknown>)
    }
  }
  
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      addDependent(observer as Observer<unknown>, currentObserver as Observer<unknown>)
    }
    
    if (cachedValue === undefined) {
      recomputeValue()
    }
    
    return cachedValue as T
  }
  
  // Register the computed observer
  registerComputed(
    observer as Observer<unknown>,
    recomputeValue,
    []
  )
  
  // Initial computation
  recomputeValue()
  
  return getter
}
