/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  trackDependency,
  notifySubjectObservers
} from '../types/reactive.js'

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined = undefined
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Set the direct link for backwards compatibility
      if (!s.observer) {
        s.observer = observer
      }
      // Use centralized tracking
      trackDependency(s as Subject<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !equalFn ? true : !equalFn(s.value, nextValue)
    if (!shouldUpdate) return s.value
    
    s.value = nextValue
    
    // Trigger all observers that depend on this subject
    notifySubjectObservers(s)
    
    return s.value
  }

  return [read, write]
}
