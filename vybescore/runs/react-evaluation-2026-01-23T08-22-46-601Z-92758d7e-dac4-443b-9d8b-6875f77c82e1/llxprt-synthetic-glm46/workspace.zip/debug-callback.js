import { createInput, createComputed, createCallback } from './src/index.js'

console.log("Debugging only callbacks...")

// Create fresh instances for callback test
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
const output2 = createComputed(() => output() * 2)

let value = 0
let count = 0

createCallback(() => {
  count++
  console.log(`Callback fired #${count}`)
  console.log("  input:", input())
  console.log("  output:", output())
  console.log("  output2:", output2())
  value = output()
})

console.log("Initial state:")
console.log("  value:", value)
console.log("  count:", count)

setInput(3)

console.log("After setInput(3):")
console.log("  value:", value)
console.log("  count:", count)
console.log("Expected value: 4")

setInput(5)

console.log("After setInput(5):")
console.log("  value:", value)
console.log("  count:", count)
console.log("Expected value: 6")