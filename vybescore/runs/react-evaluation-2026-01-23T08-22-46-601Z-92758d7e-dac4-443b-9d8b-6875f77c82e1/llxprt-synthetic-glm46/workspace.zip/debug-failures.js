import { createInput, createComputed, createCallback } from './src/index.js'

console.log("Debugging failing tests...")

// Test 1: compute cells can depend on other compute cells
console.log("=== Test 1: Computed chain ===")
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log("Initial:")
console.log("input:", input())
console.log("timesTwo:", timesTwo())
console.log("timesThirty:", timesThirty())
console.log("sum:", sum())
console.log("Expected sum: 32")

console.log("\nAfter setInput(3):")
setInput(3)
console.log("input:", input())
console.log("timesTwo:", timesTwo())
console.log("timesThirty:", timesThirty())
console.log("sum:", sum())
console.log("Expected sum: 96")

// Test 2: compute cells fire callbacks
console.log("\n=== Test 2: Callbacks ===")
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0
createCallback(() => {
  value = output()
  console.log("Callback fired with value:", value)
})

console.log("Before setInput2(3):")
console.log("input2:", input2())
console.log("output:", output())
console.log("value:", value)

setInput2(3)

console.log("After setInput2(3):")
console.log("input2:", input2()) 
console.log("output:", output())
console.log("value:", value)
console.log("Expected value: 4")

// Test 3: callbacks can be added and removed
console.log("\n=== Test 3: Multiple callbacks ===")
const [input3, setInput3] = createInput(11)
const output3 = createComputed(() => input3() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => {
  const val = output3()
  console.log("Callback 1 fired with:", val)
  values1.push(val)
})

const values2 = []
createCallback(() => {
  const val = output3()
  console.log("Callback 2 fired with:", val)
  values2.push(val)
})

console.log("Before setInput3(31):")
console.log("input3:", input3())
console.log("output3:", output3())
console.log("values1:", values1)
console.log("values2:", values2)

setInput3(31)

console.log("After setInput3(31):")
console.log("input3:", input3())
console.log("output3:", output3())
console.log("values1:", values1)
console.log("values2:", values2)

unsubscribe1()
console.log("Unsubscribed callback 1")

setInput3(41)

console.log("After setInput3(41):")
console.log("input3:", input3())
console.log("output3:", output3())
console.log("values1:", values1)
console.log("values2:", values2)
console.log("Expected: values2.length > values1.length")