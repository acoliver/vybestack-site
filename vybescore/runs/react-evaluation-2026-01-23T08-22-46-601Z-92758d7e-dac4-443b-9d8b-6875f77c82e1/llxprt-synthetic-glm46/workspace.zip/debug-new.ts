import { createInput as newCreateInput } from './src/core/new-input.js'
import { createComputed as newCreateComputed } from './src/core/new-computed.js'
import { createCallback as newCreateCallback } from './src/core/new-callback.js'

console.log("=== Testing new implementation ===")

const [input, setInput] = newCreateInput(1)
const output = newCreateComputed(() => input() + 1)

console.log("Created input and computed")

const values1 = []
const unsubscribe1 = newCreateCallback(() => {
  console.log("Callback 1 firing!")
  const val = output()
  console.log("Callback 1 got output:", val)
  values1.push(val)
})

console.log("After callback 1 created, values1:", values1)

const values2 = []
newCreateCallback(() => {
  console.log("Callback 2 firing!")
  const val = output()
  console.log("Callback 2 got output:", val)
  values2.push(val)
})

console.log("After callback 2 created")

console.log("Before set input - values1:", values1, "values2:", values2)

setInput(3)

console.log("After set input - values1:", values1, "values2:", values2)

unsubscribe1()

setInput(5)

console.log("After unsubscribe and set input - values1:", values1, "values2:", values2)