import { createInput, createComputed, createCallback } from './src/index.js'

console.log("Debugging dependent callbacks (like the failing test)...")

const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

console.log("=== Creating callbacks ===")

const values1 = []
let callback1Count = 0
const unsubscribe1 = createCallback(() => {
  callback1Count++
  const val = output()
  console.log(`Callback 1 fired #${callback1Count} with val: ${val}`)
  values1.push(val)
})

const values2 = []
let callback2Count = 0
createCallback(() => {
  callback2Count++
  const val = output()
  console.log(`Callback 2 fired #${callback2Count} with val: ${val}`)
  values2.push(val)
})

console.log("=== Initial state ===")
console.log("input:", input())
console.log("output:", output())
console.log("values1:", values1)
console.log("values2:", values2)

console.log("\n=== Setting input to 31 ===")
setInput(31)

console.log("After setInput(31):")
console.log("input:", input())
console.log("output:", output())
console.log("values1:", values1)
console.log("values2:", values2)

console.log("\n=== Unsubscribing callback 1 ===")
unsubscribe1()
console.log("Unsubscribed callback 1")

console.log("\n=== Setting input to 41 ===")
setInput(41)

console.log("After setInput(41):")
console.log("input:", input())
console.log("output:", output())
console.log("values1:", values1)
console.log("values2:", values2)

console.log(`\n=== Results ===`)
console.log("values1.length:", values1.length)
console.log("values2.length:", values2.length)
console.log("Expected: values2.length > values1.length")