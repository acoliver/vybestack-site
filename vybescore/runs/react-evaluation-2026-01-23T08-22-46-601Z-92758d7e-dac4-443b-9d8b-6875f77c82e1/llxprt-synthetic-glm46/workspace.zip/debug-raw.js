import { activeTracker } from './src/types/reactive.js'
import { createInput, createComputed, createCallback } from './src/index.js'

console.log("=== Debugging active tracker state ===")

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
const output2 = createComputed(() => input() * 2)

console.log("After creating input and computeds:")
console.log("dependencies size:", activeTracker.dependencies.size)
for (const [subject, observers] of activeTracker.dependencies) {
  console.log(`  subject has ${observers.size} observers`)
}

console.log("\n=== Creating callbacks ===")

const values1 = []
const unsubscribe1 = createCallback(() => {
  console.log("Callback 1 firing, checking dependencies:")
  console.log("  dependencies size:", activeTracker.dependencies.size)
  const val = output()
  values1.push(val)
})

const values2 = []
createCallback(() => {
  console.log("Callback 2 firing, checking dependencies:")
  console.log("  dependencies size:", activeTracker.dependencies.size)
  const val = output()
  values2.push(val)
})

console.log("After creating callbacks:")
console.log("dependencies size:", activeTracker.dependencies.size)
for (const [subject, observers] of activeTracker.dependencies) {
  console.log(`  subject has ${observers.size} observers`)
}

console.log("\n=== Setting input to 31 ===")
setInput(31)

console.log("After setInput(31):")
console.log("values1:", values1, "length:", values1.length)
console.log("values2:", values2, "length:", values2.length)
console.log("dependencies size:", activeTracker.dependencies.size)
for (const [subject, observers] of activeTracker.dependencies) {
  console.log(`  subject has ${observers.size} observers`)
}

console.log("\n=== Unsubscribing callback 1 ===")
unsubscribe1()
console.log("Unsubscribed callback 1")
console.log("dependencies size:", activeTracker.dependencies.size)
for (const [subject, observers] of activeTracker.dependencies) {
  console.log(`  subject has ${observers.size} observers`)
}

console.log("\n=== Setting input to 41 ===")
setInput(41)

console.log("After setInput(41):")
console.log("values1:", values1, "length:", values1.length)
console.log("values2:", values2, "length:", values2.length)
console.log("dependencies size:", activeTracker.dependencies.size)
for (const [subject, observers] of activeTracker.dependencies) {
  console.log(`  subject has ${observers.size} observers`)
}