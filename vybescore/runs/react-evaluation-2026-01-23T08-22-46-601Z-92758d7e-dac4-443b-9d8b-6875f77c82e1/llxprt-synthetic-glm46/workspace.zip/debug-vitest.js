import { createInput, createComputed, createCallback } from './src/index.js'

console.log("Debugging vitest timeout issue...")

async function runTest() {
  console.log("Starting test...")
  
  try {
    console.log("Test before: Starting createInput...")
    const [input, setInput] = createInput(1)
    console.log("Test after: Created input, value:", input())
    
    console.log("Test before: Starting createComputed...")
    const timesTwo = createComputed(() => input() * 2)
    console.log("Test after: Created computed, value:", timesTwo())
    
    console.log("Test before: Starting second computed...")
    const timesThirty = createComputed(() => input() * 30)
    console.log("Test after: Created second computed, value:", timesThirty())
    
    console.log("Test before: Starting sum computed...")
    const sum = createComputed(() => timesTwo() + timesThirty())
    console.log("Test after: Created sum, value:", sum())
    
    console.log("Test before: Setting input to 3...")
    setInput(3)
    console.log("Test after: Set input to 3, sum:", sum())
    
    console.log("Test before: Starting callback...")
    const output = createComputed(() => input() + 1)
    let value = 0
    const unsubscribe = createCallback(() => {
      value = output()
      console.log("Callback triggered, value:", value)
    })
    console.log("Test after: Created callback")
    
    console.log("Test before: Setting input to 7...")
    setInput(7)
    console.log("Test after: Set input to 7, final value:", value)
    
    console.log("SUCCESS: All operations completed")
    
    return Promise.resolve()
  } catch (error) {
    console.error("Test failed:", error)
    console.error(error.stack)
    return Promise.reject(error)
  }
}

runTest()
  .then(() => console.log("Test completed successfully"))
  .catch(error => console.error("Test failed:", error))