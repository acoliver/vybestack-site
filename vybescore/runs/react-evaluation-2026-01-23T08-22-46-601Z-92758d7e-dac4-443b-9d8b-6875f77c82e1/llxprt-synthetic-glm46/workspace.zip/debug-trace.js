import { createInput, createComputed, createCallback } from './src/index.js'

console.log("=== Tracing callback creation ===")

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
const output2 = createComputed(() => input() * 2)

console.log("Created input and computeds")

// Let's try to manually force the dependency registration
const values1 = []
const val1_before = output()

console.log("Before callback 1, output:", val1_before)

const unsubscribe1 = createCallback(() => {
  console.log("Callback 1 firing!")
  const val = output()
  console.log("Callback 1 got output:", val)
  values1.push(val)
})

console.log("After callback 1 created, values1:", values1)

const values2 = []
createCallback(() => {
  console.log("Callback 2 firing!")
  const val = output()
  console.log("Callback 2 got output:", val)
  values2.push(val)
})

console.log("After callback 2 created")

console.log("Before set input - values1:", values1, "values2:", values2)

setInput(3)

console.log("After set input - values1:", values1, "values2:", values2)

unsubscribe1()

setInput(5)

console.log("After unsubscribe and set input - values1:", values1, "values2:", values2)