/**
 * Simple reactive types and tracking
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Simple reactive tracking
export class ReactiveTracker {
  static instance = new ReactiveTracker()
  
  activeObserver: ((() => void) | null) = null
  dependencies = new Map<() => void, Set<() => void>>()
  computedState = new Map<() => unknown, { fn: (...args: unknown[]) => unknown; value: unknown; deps: Set<() => unknown> }>()
  notificationDepth = 0
  pendingNotifications = new Set<() => void>()
  
  setActiveObserver(observer: (() => void) | null): void {
    this.activeObserver = observer
  }
  
  registerDependency(subject: () => void): void {
    if (!this.activeObserver) return
    
    if (!this.dependencies.has(subject)) {
      this.dependencies.set(subject, new Set())
    }
    this.dependencies.get(subject)!.add(this.activeObserver)
  }
  
  notifySubjectChanged(subject: () => void): void {
    const observers = this.dependencies.get(subject)
    if (observers) {
      if (this.notificationDepth > 0) {
        // Queue notifications if we're already notifying
        for (const observer of observers) {
          this.pendingNotifications.add(observer)
        }
      } else {
        // Create a copy of observers to avoid issues with collection modifications
        const observersToNotify = Array.from(observers)
        this.notificationDepth++
        try {
          for (const observer of observersToNotify) {
            observer()
          }
        } finally {
          this.notificationDepth--
          // Process pending notifications
          if (this.notificationDepth === 0 && this.pendingNotifications.size > 0) {
            const pending = Array.from(this.pendingNotifications)
            this.pendingNotifications.clear()
            for (const observer of pending) {
              observer()
            }
          }
        }
      }
    }
  }
  
  getActiveObserver(): ((() => void) | null) {
    return this.activeObserver
  }
}

export function getActiveObserver(): (() => void) | null {
  return ReactiveTracker.instance.getActiveObserver()
}

declare let globalThis: unknown
const tracker = ReactiveTracker.instance

if (!(globalThis as { __reactiveTracker?: typeof tracker }).__reactiveTracker) {
  (globalThis as { __reactiveTracker: typeof tracker }).__reactiveTracker = tracker
}

export const activeTracker = (globalThis as { __reactiveTracker?: typeof tracker }).__reactiveTracker || tracker
