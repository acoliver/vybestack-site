/**
 * New callback implementation using global tracking
 */

import {
  UnsubscribeFn,
  UpdateFn
} from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let currentValue = value
  let dependencies = new Set<() => void>()
  
  // Function that executes the callback when dependencies change
  const callbackObserver = (): void => {
    if (disposed) return
    executeCallback()
  }
  
  function executeCallback(): void {
    // Clear previous dependencies
    dependencies.forEach(dep => {
      const obs = (dep as any).observers
      if (obs) {
        obs.delete(callbackObserver)
      }
    })
    dependencies.clear()
    
    const previousObserver = (globalThis as any).__activeObserver
    ;(globalThis as any).__activeObserver = callbackObserver
    
    try {
      currentValue = updateFn(currentValue)
      
      // Store new dependencies
      dependencies = new Set((globalThis as any).__currentDependencies || [])
      
    } finally {
      ;(globalThis as any).__activeObserver = previousObserver
      ;(globalThis as any).__currentDependencies = undefined
    }
  }
  
  // Initial execution
  executeCallback()
  
  return () => {
    disposed = true
    
    // Clean up observers
    dependencies.forEach(dep => {
      const obs = (dep as any).observers
      if (obs) {
        obs.delete(callbackObserver)
      }
    })
    dependencies.clear()
  }
}