/**
 * New input implementation that tracks all observers
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const observers = new Set<() => void>()
  
  const read: GetterFn<T> = () => {
    // Register this input as a dependency for any active observer
    const activeObserver = (globalThis as any).__activeObserver
    if (activeObserver) {
      observers.add(activeObserver)
    }
    return value
  }

  const write: SetterFn<T> = (nextValue: T): T => {
    const equalFn = typeof equal === 'function' ? equal : ((a: T, b: T) => a === b)
    if (!equalFn(value, nextValue)) {
      value = nextValue
      
      // Notify all observers that this input has changed
      for (const observer of Array.from(observers)) {
        try {
          observer()
        } catch (e) {
          console.error('Observer error:', e)
        }
      }
    }
    return value
  }

  return [read, write]
}