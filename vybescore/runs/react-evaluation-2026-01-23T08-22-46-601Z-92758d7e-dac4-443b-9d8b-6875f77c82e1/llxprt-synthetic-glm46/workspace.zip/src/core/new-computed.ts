/**
 * New computed implementation using global tracking
 */

import { 
  GetterFn, 
  UpdateFn
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  _options?: { name?: string }
): GetterFn<T> {
  let currentValue = value
  let firstComputation = true
  let dependencies = new Set<() => void>()
  
  // Observer function that recomputes when dependencies change
  const recomputeObserver = (): void => {
    recompute()
  }
  
  function recompute(): void {
    const previousObserver = (globalThis as any).__activeObserver
    ;(globalThis as any).__activeObserver = recomputeObserver
    
    try {
      // Clear previous dependencies
      dependencies.forEach(dep => {
        const obs = (dep as any).observers
        if (obs) {
          obs.delete(recomputeObserver)
        }
      })
      dependencies.clear()
      
      // Recompute value
      const currentValueForUpdate = firstComputation ? undefined : currentValue
      currentValue = updateFn(currentValueForUpdate)
      firstComputation = false
      
      // Store new dependencies
      dependencies = new Set((globalThis as any).__currentDependencies || [])
      
    } finally {
      ;(globalThis as any).__activeObserver = previousObserver
      ;(globalThis as any).__currentDependencies = undefined
    }
  }
  
  const getter: GetterFn<T> = (): T => {
    const activeObserver = (globalThis as any).__activeObserver
    
    // Register this computed as a dependency for the active observer
    if (activeObserver && activeObserver !== recomputeObserver) {
      if (!(globalThis as any).__currentDependencies) {
        (globalThis as any).__currentDependencies = new Set()
      }
      (globalThis as any).__currentDependencies.add(recomputeObserver)
    }
    
    // Ensure we have a value
    if (firstComputation) {
      recompute()
    }
    
    return currentValue as T
  }
  
  return getter
}