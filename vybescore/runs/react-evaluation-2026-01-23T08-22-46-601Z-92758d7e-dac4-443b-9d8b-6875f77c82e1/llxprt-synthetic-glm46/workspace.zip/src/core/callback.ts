/**
 * Working callback implementation with proper reactive tracking
 */

import {
  UnsubscribeFn,
  UpdateFn
} from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let currentValue = value
  
  // Function that executes the callback when dependencies change
  const callbackObserver = (): void => {
    if (disposed) return
    executeCallback()
  }
  
  function executeCallback(): void {
    const global = globalThis as any
    const previousObserver = global.__activeObserver
    global.__activeObserver = callbackObserver
    
    try {
      currentValue = updateFn(currentValue)
    } finally {
      global.__activeObserver = previousObserver
    }
  }
  
  // Initial execution
  executeCallback()
  
  const unsubscribe = (): void => {
    disposed = true
  }

  // Attach observers list for dependency management
  ;(callbackObserver as any).observers = new Set<() => void>()

  return unsubscribe
}
