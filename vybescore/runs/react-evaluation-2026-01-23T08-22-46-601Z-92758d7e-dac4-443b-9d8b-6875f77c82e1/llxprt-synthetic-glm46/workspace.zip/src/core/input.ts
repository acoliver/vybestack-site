/**
 * Working input implementation with proper reactive tracking
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Store all inputs' callbacks for debugging
const globalCallbacks = new Set<() => void>()
const allInputs = new Set<() => any>()

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const callbacks = new Set<() => void>()
  
  const read: GetterFn<T> = () => {
    console.log('Input read, active observer:', (globalThis as any).__activeObserver?.name)
    // Register this input as a dependency for any active observer
    const activeObserver = (globalThis as any).__activeObserver
    if (activeObserver) {
      callbacks.add(activeObserver)
      globalCallbacks.add(activeObserver)
      console.log('Added observer to callbacks, total observers:', callbacks.size)
    }
    return value
  }

  const write: SetterFn<T> = (nextValue: T): T => {
    const equalFn = typeof equal === 'function' ? equal : ((a: T, b: T) => a === b)
    if (!equalFn(value, nextValue)) {
      value = nextValue
      
      console.log('Input value changed, notifying', callbacks.size, 'callbacks')
      // Notify all registered callbacks
      const callbacksToNotify = Array.from(callbacks)
      for (const callback of callbacksToNotify) {
        try {
          console.log('Calling callback:', callback.name)
          callback()
        } catch (e) {
          console.error('Callback error:', e)
        }
      }
    }
    return value
  }

  // Store for debugging
  allInputs.add(read)
  ;(read as any).callbacks = callbacks
  ;(read as any).name = 'input'

  return [read, write]
}
