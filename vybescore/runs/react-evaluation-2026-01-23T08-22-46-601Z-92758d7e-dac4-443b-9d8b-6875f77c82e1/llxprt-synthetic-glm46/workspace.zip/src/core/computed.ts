/**
 * Working computed implementation with proper reactive tracking
 */

import { 
  GetterFn, 
  UpdateFn
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  _options?: { name?: string }
): GetterFn<T> {
  let currentValue = value
  let firstComputation = true
  let dependencies = new Set<() => any>()
  
  // Observer function that recomputes when dependencies change
  const recomputeObserver = (): void => {
    console.log('Recompute observer called')
    recompute()
  }
  
  function recompute(): void {
    const previousObserver = (globalThis as any).__activeObserver
    ;(globalThis as any).__activeObserver = recomputeObserver
    
    try {
      // Clear previous dependencies
      dependencies.forEach(dep => {
        if ((dep as any).callbacks) {
          (dep as any).callbacks.delete(recomputeObserver)
        }
      })
      dependencies.clear()
      
      console.log('Recomputing computed value')
      currentValue = updateFn(currentValue)
      firstComputation = false
      
      // Store new dependencies
      console.log('New dependencies count:', dependencies.size)
      
    } finally {
      ;(globalThis as any).__activeObserver = previousObserver
    }
  }
  
  const getter: GetterFn<T> = (): T => {
    const activeObserver = (globalThis as any).__activeObserver
    console.log('Computed getter accessed, active observer:', activeObserver?.name)
    
    // Register this computed as a dependency for the active observer
    if (activeObserver && activeObserver !== recomputeObserver) {
      if (activeObserver.callbacks) {
        activeObserver.callbacks.add(recomputeObserver)
        console.log('Added computed to dependency tracking')
      }
    }
    
    // Ensure we have a value
    if (firstComputation) {
      recompute()
    }
    
    return currentValue as T
  }
  
  // Store dependencies for cleanup
  ;(getter as any).dependencies = dependencies
  ;(getter as any).name = 'computed'

  return getter
}
