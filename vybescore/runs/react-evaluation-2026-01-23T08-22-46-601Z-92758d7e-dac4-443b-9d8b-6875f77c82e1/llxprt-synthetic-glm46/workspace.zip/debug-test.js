import { createInput, createComputed, createCallback } from './src/index.js'

console.log("Testing reactive functions...")

try {
  // Test 1: Basic input functionality
  console.log("Test 1: Basic input")
  const [input, setInput] = createInput(1)
  console.log("Initial value:", input())
  setInput(3)
  console.log("After setting to 3:", input())
  
  // Test 2: Computed depends on input
  console.log("\nTest 2: Computed depends on input")
  const timesTwo = createComputed(() => input() * 2)
  console.log("timesTwo():", timesTwo())
  setInput(5)
  console.log("After set input to 5, timesTwo():", timesTwo())
  
  // Test 3: Computed depends on other computed
  console.log("\nTest 3: Computed depends on other computed")
  const timesThirty = createComputed(() => input() * 30)
  const sum = createComputed(() => timesTwo() + timesThirty())
  console.log("sum():", sum())
  setInput(3)
  console.log("After set input to 3, sum():", sum())
  
  // Test 4: Callbacks
  console.log("\nTest 4: Callbacks")
  const output = createComputed(() => input() + 1)
  let value = 0
  const unsubscribe = createCallback(() => {
    value = output()
    console.log("Callback triggered, value:", value)
  })
  setInput(7)
  console.log("Final value from callback:", value)
  
  console.log("\nAll tests completed successfully!")
} catch (error) {
  console.error("Error during testing:", error)
  console.error(error.stack)
}