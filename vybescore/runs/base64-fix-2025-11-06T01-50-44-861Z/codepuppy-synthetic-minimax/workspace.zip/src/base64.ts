/**
 * Encode plain text to Base64 using RFC 4648 canonical alphabet.
 * Uses standard Base64 with '+' and '/' characters and proper '=' padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) using the standard alphabet.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate that the input contains only Base64 characters
  // Allowed: A-Z, a-z, 0-9, +, /, and optional padding =
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!input.length) {
    throw new Error('Base64 input cannot be empty');
  }
  
  if (!base64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  try {
    // Add padding if missing for proper decoding
    let normalizedInput = input;
    const paddingNeeded = (4 - (input.length % 4)) % 4;
    if (paddingNeeded > 0 && !input.includes('=')) {
      normalizedInput = input + '='.repeat(paddingNeeded);
    }
    
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
