/**
 * Regular expression to validate standard Base64 strings.
 * Matches the canonical Base64 alphabet: A-Z, a-z, 0-9, +, /, with optional padding (=).
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]+={0,2}$/;

/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws an error for invalid Base64 strings.
 */
export function decode(input: string): string {
  // Remove any whitespace for more forgiving input handling
  const trimmed = input.trim();

  // Validate the input is valid Base64
  if (!BASE64_REGEX.test(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if the decoded buffer is valid UTF-8
    // If the original input was invalid Base64, Buffer.from may succeed
    // but produce incorrect results. We verify by checking if we can encode back.
    const verification = buffer.toString('base64');
    // Normalize for comparison (both should have same padding)
    const normalizedInput = trimmed.replace(/=+$/, '');
    const normalizedVerification = verification.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedVerification) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
