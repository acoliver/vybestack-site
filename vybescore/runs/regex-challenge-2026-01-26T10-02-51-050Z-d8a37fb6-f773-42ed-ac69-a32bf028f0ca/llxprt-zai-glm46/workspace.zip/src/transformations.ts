/**
 * Capitalize the first character of each sentence.
 * - Capitalizes first character after sentence-ending punctuation (. ! ?)
 * - Inserts exactly one space between sentences if input omitted it
 * - Collapses extra spaces while preserving internal spacing
 * - Leaves abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces into single spaces (but not newlines)
  let result = text.replace(/[ \t]+/g, ' ');
  
  // Ensure exactly one space after sentence-ending punctuation
  // Look for punctuation followed by optional space(s) and a lowercase letter
  result = result.replace(/([.!?])\s*([a-z])/g, '$1 $2');
  
  // Capitalize first character of the entire string
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());
  
  // Capitalize first character after sentence-ending punctuation
  // Use simple patterns since lookbehind has limited support
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, punct, letter) => {
    return punct + letter.toUpperCase();
  });
  
  // Handle newlines after punctuation
  result = result.replace(/([.!?])\s*\n\s*([a-z])/g, (match, punct, letter) => {
    return punct + '\n' + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL pattern
  // Matches http://, https://, and www. URLs
  // Excludes trailing punctuation (., !, ?, ;, :, ', ", ), ], })
  const urlRegex = /(https?:\/\/|www\.)[^\s<>"'`{|[\\]+(?:\([^\s<>"'`]*?\))?[^.,!?;:'"\]}\s]*/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[.,!?;:'"\]}]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, ?, &, =, .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // Captures: scheme, host, optional path
  const urlPattern = /(https?:\/\/)([a-zA-Z0-9.-]+)(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if this is example.com (or subdomain) and path starts with /docs/
    const isExampleHost = /(^|\.)example\.com$/.test(host);
    const hasDocsPath = path.startsWith('/docs/');
    
    // Dynamic hints that should prevent host rewrite
    const dynamicHints = [
      'cgi-bin', '?', '&', '=',
      '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'
    ];
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    // Rewrite host for docs paths without dynamic hints
    if (isExampleHost && hasDocsPath && !hasDynamicHint) {
      const newHost = 'docs.example.com';
      return newScheme + newHost + path;
    }
    
    // Otherwise just upgrade the scheme
    return newScheme + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
