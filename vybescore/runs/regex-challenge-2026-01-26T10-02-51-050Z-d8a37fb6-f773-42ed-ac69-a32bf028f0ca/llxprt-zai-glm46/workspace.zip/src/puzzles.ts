/**
 * Find words starting with the prefix but excluding banned words.
 * Uses word boundaries and negative lookahead for exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build pattern: word starting with prefix, not in exceptions list
  // Use word boundary to match whole words
  const exceptionPattern = exceptions.length > 0 
    ? exceptions.join('|').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    : '';
  
  // Build regex: match words starting with prefix
  let pattern = `\\b${escapedPrefix}\\w*\\b`;
  
  // If we have exceptions, use a negative lookahead approach
  if (exceptionPattern) {
    pattern = `\\b(?!(${exceptionPattern})\\b)${escapedPrefix}\\w*\\b`;
  }
  
  const regex = new RegExp(pattern, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (in case they slipped through)
  return matches.filter(word => 
    !exceptions.some(ex => ex.toLowerCase() === word.toLowerCase())
  );
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookbehind assertions.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Simpler approach: find all occurrences and filter - return full match including the digit
  const simpleRegex = new RegExp(escapedToken, 'g');
  const simpleMatches: string[] = [];
  let simpleMatch: RegExpExecArray | null;
  
  while ((simpleMatch = simpleRegex.exec(text)) !== null) {
    // Check if preceded by a digit and not at start
    if (simpleMatch.index > 0 && /\d/.test(text[simpleMatch.index - 1])) {
      // Return the full match including the digit (lookbehind to get the digit)
      simpleMatches.push(text[simpleMatch.index - 1] + simpleMatch[0]);
    }
  }
  
  return simpleMatches;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~`]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, 1212)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment = value.substr(i, len);
      const nextSegment = value.substr(i + len, len);
      if (segment === nextSegment) {
        return false;
      }
    }
  }
  
  // Also check for longer repeating patterns (but allow single character repeats like "aaa")
  const repeatedPattern = /(.{2,})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 * Returns true only if IPv6 is detected.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude pure IPv4 addresses
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Check for :: (compressed IPv6)
  if (value.includes('::')) {
    // Must also have valid IPv6 characters (hex digits and colons)
    if (/[0-9a-fA-F:]/.test(value) && value.includes(':')) {
      return true;
    }
  }
  
  // Full IPv6 pattern (8 groups of hex)
  const ipv6FullPattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  if (ipv6FullPattern.test(value)) {
    return true;
  }
  
  // Compressed IPv6 patterns (with ::)
  const ipv6CompressedPatterns = [
    /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/,  // Generic compressed
    /::1/,  // Loopback
    /^::$/,  // All interfaces
  ];
  
  for (const pattern of ipv6CompressedPatterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
