export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with strict rules.
 * Accepts typical addresses like name@tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Main pattern: local@domain
  // Local part: alphanumeric, dots, hyphens, plus (but no consecutive dots, no leading/trailing dot)
  // Domain: alphanumeric labels separated by dots, 2-6 char TLD
  // No underscores in domain
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks: no consecutive dots, no leading/trailing dots in local or domain parts
  const [local, domain] = value.split('@');
  
  // Check for double dots or trailing/leading dots in local part
  if (local.includes('..') || local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Check for double dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, optionally 11 with +1 country code)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let numberDigits = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    numberDigits = digitsOnly.slice(1);
  } else if (digitsOnly.length > 11) {
    // Too long, unless extensions are allowed
    if (options?.allowExtensions && digitsOnly.length > 11) {
      numberDigits = digitsOnly.slice(0, 11);
      if (numberDigits.startsWith('1')) {
        numberDigits = numberDigits.slice(1);
      }
    } else {
      return false;
    }
  }
  
  // Must be exactly 10 digits now
  if (numberDigits.length !== 10) {
    return false;
  }
  
  // Check area code: first digit cannot be 0 or 1
  const areaCode = parseInt(numberDigits.slice(0, 1), 10);
  if (areaCode < 2) {
    return false;
  }
  
  // Validate format with optional parentheses, spaces, hyphens
  const formattedRegex = /^\+?1?[\s\-.]?\(?[2-9]\d{2}\)?[\s\-.]?\d{3}[\s\-.]?\d{4}(?:x\d+)?$/;
  return formattedRegex.test(value.replace(/\s+/g, ' ').trim());
}

/**
 * Validate Argentine phone numbers.
 * Supports landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens, parentheses) for validation
  const cleaned = value.replace(/[\s\-.()]/g, '');
  
  // Must have at least 8 digits (area code + subscriber minimum)
  if (cleaned.length < 8) {
    return false;
  }
  
  // Extract components
  let remaining = cleaned;
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  
  // Check for country code +54
  if (remaining.startsWith('+54')) {
    remaining = remaining.slice(3);
    hasCountryCode = true;
  } else if (remaining.startsWith('54') && cleaned.length > 10) {
    // Only treat 54 as country code if there are enough digits remaining
    remaining = remaining.slice(2);
    hasCountryCode = true;
  }
  
  // Check for trunk prefix 0 (only if no country code)
  if (!hasCountryCode && remaining.startsWith('0')) {
    remaining = remaining.slice(1);
    hasTrunkPrefix = true;
  }
  
  // Check for mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // At this point, remaining should be: area_code (2-4 digits) + subscriber (6-8 digits)
  // Total should be 8-12 digits
  if (remaining.length < 8 || remaining.length > 12) {
    return false;
  }
  
  // Area code: 2-4 digits, leading digit must be 1-9 (not 0)
  let areaCodeLength: number;
  
  // Determine area code length based on total length
  if (remaining.length === 8) {
    // 2 digit area code + 6 digit subscriber
    areaCodeLength = 2;
  } else if (remaining.length === 9) {
    // 3 digit area code + 6 digit subscriber
    areaCodeLength = 3;
  } else if (remaining.length === 10) {
    // 4 digit area code + 6 digit subscriber
    areaCodeLength = 4;
  } else if (remaining.length === 11) {
    // 4 digit area code + 7 digit subscriber
    areaCodeLength = 4;
  } else {
    // 12: 4 digit area code + 8 digit subscriber
    areaCodeLength = 4;
  }
  
  const areaCode = remaining.slice(0, areaCodeLength);
  const subscriber = remaining.slice(areaCodeLength);
  
  // Area code leading digit must be 1-9
  if (areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // If no country code, must have trunk prefix (the 0 we removed)
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and special symbols (except apostrophe, hyphen, space)
  const nameRegex = /^[\p{L}'\- ]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for digits (would be caught by above, but being explicit)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for suspicious symbols (anything that's not a letter, apostrophe, hyphen, or space)
  const suspiciousRegex = /[^\p{L}'\- ]/u;
  if (suspiciousRegex.test(value)) {
    return false;
  }
  
  // Name should contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function: Run Luhn checksum on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check valid lengths: 13-19 digits (typical card lengths)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check prefixes and lengths for different card types
  // Visa: starts with 4, length 13, 16, or 19
  const visaRegex = /^4\d{12}(\d{3}(\d{3})?)?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mcRegex1 = /^5[1-5]\d{14}$/;
  const mcRegex2 = /^2[2-7]\d{14}$/; // Simplified 2-series
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  let validPrefix = false;
  if (visaRegex.test(cleaned) && [13, 16, 19].includes(cleaned.length)) {
    validPrefix = true;
  } else if (mcRegex1.test(cleaned) || mcRegex2.test(cleaned)) {
    validPrefix = true;
  } else if (amexRegex.test(cleaned) && cleaned.length === 15) {
    validPrefix = true;
  }
  
  if (!validPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
