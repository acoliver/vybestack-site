import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/src/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/src/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './dist/src/puzzles.js';

console.log('=== Comprehensive Edge Case Tests ===\n');

console.log('--- Email Edge Cases ---');
console.log('name@tag@example.co.uk:', isValidEmail('name@tag@example.co.uk'));
console.log('.user@example.com:', isValidEmail('.user@example.com'));
console.log('user.@example.com:', isValidEmail('user.@example.com'));
console.log('user..name@example.com:', isValidEmail('user..name@example.com'));
console.log('user@example_domain.com:', isValidEmail('user@example_domain.com'));

console.log('\n--- US Phone Edge Cases ---');
console.log('1-212-555-7890:', isValidUSPhone('1-212-555-7890'));
console.log('+1 (212) 555-7890:', isValidUSPhone('+1 (212) 555-7890'));
console.log('212-555-789:', isValidUSPhone('212-555-789'));
console.log('112-555-7890:', isValidUSPhone('112-555-7890'));

console.log('\n--- Argentine Phone Edge Cases ---');
console.log('5491112345678:', isValidArgentinePhone('5491112345678'));
console.log('+5491112345678:', isValidArgentinePhone('+5491112345678'));
console.log('0800-123-4567:', isValidArgentinePhone('0800-123-4567'));
console.log('0811-123-4567:', isValidArgentinePhone('0811-123-4567'));

console.log('\n--- Name Edge Cases ---');
console.log('José María González:', isValidName('José María González'));
console.log('Anne-Marie:', isValidName('Anne-Marie'));
console.log("D'Angelo:", isValidName("D'Angelo"));
console.log('名字:', isValidName('名字'));
console.log('Æon Flux:', isValidName('Æon Flux'));
console.log('Test_underscore:', isValidName('Test_underscore'));

console.log('\n--- Credit Card Edge Cases ---');
console.log('4111 1111 1111 1111:', isValidCreditCard('4111 1111 1111 1111'));
console.log('5111 1111 1111 1111:', isValidCreditCard('5111 1111 1111 1111'));
console.log('3711 1111 1111 1111:', isValidCreditCard('3711 1111 1111 1111'));
console.log('4111 1111 1111 1112:', isValidCreditCard('4111 1111 1111 1112'));

console.log('\n--- Transformations Edge Cases ---');
console.log('capitalizeSentences:', capitalizeSentences('hello.how are you?i\'m fine.thanks!'));
console.log('extractUrls:', extractUrls('Visit https://example.com/path?q=value, and http://test.com.'));
console.log('enforceHttps:', enforceHttps('Link: http://example.com and https://secure.com'));
console.log('rewriteDocsUrls:', rewriteDocsUrls('See http://example.com/docs/api and http://example.com/docs/test.php?x=1'));
console.log('extractYear valid:', extractYear('12/31/2024'));
console.log('extractYear invalid month:', extractYear('13/31/2024'));
console.log('extractYear invalid day:', extractYear('02/30/2024'));
console.log('extractYear bad format:', extractYear('2024-12-31'));

console.log('\n--- Puzzle Edge Cases ---');
console.log('findPrefixedWords:', findPrefixedWords('preview preheat prevent prefix', 'pre', ['prevent']));
console.log('findEmbeddedToken:', findEmbeddedToken('123foo bar 9foo abc', 'foo'));
console.log('isStrongPassword ab123AB!@:', isStrongPassword('ab123AB!@'));
console.log('isStrongPassword abcabcABC1!:', isStrongPassword('abcabcABC1!'));
console.log('containsIPv6 valid:', containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334'));
console.log('containsIPv6 compressed:', containsIPv6('2001:db8::1'));
console.log('containsIPv6 IPv4:', containsIPv6('192.168.1.1'));
console.log('containsIPv6 mixed:', containsIPv6('::ffff:192.168.1.1'));
