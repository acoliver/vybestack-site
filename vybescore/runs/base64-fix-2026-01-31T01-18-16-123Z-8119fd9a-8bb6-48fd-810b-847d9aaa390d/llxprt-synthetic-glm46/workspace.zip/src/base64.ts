/**
 * Encode plain text to Base64 using canonical Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64 strings.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Check if input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  try {
    const decoded = Buffer.from(input, 'base64').toString('utf8');
    
    // Verify by encoding back and checking if it matches (ignoring padding differences)
    const reencoded = Buffer.from(decoded, 'utf8').toString('base64');
    // Normalize both strings by removing padding for comparison
    const normalizedInput = input.replace(/=+$/, '');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedReencoded) {
      throw new Error('Invalid Base64 input: corruption detected');
    }
    
    return decoded;
  } catch (error) {
    throw new Error('Invalid Base64 input: decoding failed');
  }
}
