/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  // Use standard base64, not base64url
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding and validates the input.
 */
export function decode(input: string): string {
  // Remove whitespace
  const normalized = input.replace(/\s+/g, '');
  
  // Validate that the input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(normalized)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Ensure proper padding for decoding
  let padded = normalized;
  const mod = normalized.length % 4;
  if (mod === 2) {
    padded += '==';
  } else if (mod === 3) {
    padded += '=';
  } else if (mod !== 0) {
    throw new Error('Invalid Base64 input: incorrect length');
  }
  
  try {
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
