import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone_number: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sql: { Database: new (buffer?: Uint8Array) => Database } | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    this.sql = (await initSqlJs({
      locateFile: (file: string) => join(process.cwd(), 'public', file)
    })) as unknown as { Database: new (buffer?: Uint8Array) => Database };

    // Ensure data directory exists
    const dataDir = join(process.cwd(), 'data');
    if (!existsSync(dataDir)) {
      mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (existsSync(this.dbPath)) {
      const filebuffer = readFileSync(this.dbPath);
      this.db = new this.sql.Database(filebuffer);
    } else {
      this.db = new this.sql.Database();
      this.createSchema();
    }
  }

  private createSchema(): void {
    if (!this.db) throw new Error('Database not initialized');
    
    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province_region TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone_number TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `;
    
    this.db.run(schema);
    this.save();
  }

  async insertSubmission(data: FormData): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province_region, postal_code, country, email, phone_number)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province_region,
      data.postal_code,
      data.country,
      data.email,
      data.phone_number
    ]);

    stmt.free();
    this.save();

    // Get the last inserted ID
    const result = this.db.exec('SELECT last_insert_rowid() as id');
    return result[0].values[0][0] as number;
  }

  save(): void {
    if (!this.db) throw new Error('Database not initialized');
    
    const data = this.db.export();
    writeFileSync(this.dbPath, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();