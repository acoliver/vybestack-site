import express, { Request, Response } from 'express';
import path from 'path';
import { dbManager, FormData } from './database';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Form validation interface
interface FormErrors {
  [key: string]: string;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[0-9\s()-]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateFormData(data: FormData): FormErrors {
  const errors: FormErrors = {};

  if (!data.first_name?.trim()) {
    errors.first_name = 'First name is required';
  }
  if (!data.last_name?.trim()) {
    errors.last_name = 'Last name is required';
  }
  if (!data.street_address?.trim()) {
    errors.street_address = 'Street address is required';
  }
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  if (!data.state_province_region?.trim()) {
    errors.state_province_region = 'State/Province/Region is required';
  }
  if (!data.postal_code?.trim()) {
    errors.postal_code = 'Postal/ZIP code is required';
  } else if (!validatePostalCode(data.postal_code)) {
    errors.postal_code = 'Please enter a valid postal code';
  }
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  if (!data.phone_number?.trim()) {
    errors.phone_number = 'Phone number is required';
  } else if (!validatePhone(data.phone_number)) {
    errors.phone_number = 'Please enter a valid phone number';
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    data: {}, 
    errors: {} 
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      first_name: req.body.first_name,
      last_name: req.body.last_name,
      street_address: req.body.street_address,
      city: req.body.city,
      state_province_region: req.body.state_province_region,
      postal_code: req.body.postal_code,
      country: req.body.country,
      email: req.body.email,
      phone_number: req.body.phone_number,
    };

    const errors = validateFormData(formData);
    
    if (Object.keys(errors).length > 0) {
      return res.status(400).render('form', { 
        data: formData, 
        errors 
      });
    }

    await dbManager.insertSubmission(formData);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).send('Something went wrong!');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing server gracefully');
  dbManager.close();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, closing server gracefully');
  dbManager.close();
  process.exit(0);
});

// Start server
async function startServer() {
  try {
    await dbManager.initialize();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();