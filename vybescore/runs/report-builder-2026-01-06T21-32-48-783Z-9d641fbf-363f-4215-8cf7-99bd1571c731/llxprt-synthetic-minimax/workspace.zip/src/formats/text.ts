import { ReportData, CliOptions } from '../types.js';

export function renderText(data: ReportData, options: CliOptions): string {
  const { title, summary, entries } = data;
  
  // Build the output parts
  const parts: string[] = [];
  
  // Title
  parts.push(title);
  parts.push(''); // blank line
  
  // Summary
  parts.push(summary);
  parts.push(''); // blank line
  
  // Entries heading
  parts.push('Entries:');
  
  // Bullet list entries
  for (const entry of entries) {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    parts.push(`- ${entry.label}: ${formattedAmount}`);
  }
  
  // Include totals if requested
  if (options.includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = `$${total.toFixed(2)}`;
    parts.push('');
    parts.push(`Total: ${formattedTotal}`);
  }
  
  return parts.join('\n');
}