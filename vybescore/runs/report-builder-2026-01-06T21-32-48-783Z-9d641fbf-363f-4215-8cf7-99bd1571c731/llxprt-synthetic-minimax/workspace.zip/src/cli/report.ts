import { readFileSync, writeFileSync } from 'fs';
import { resolve } from 'path';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, CliOptions } from '../types.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  // Skip node executable and script path
  const argsList = argv.slice(2);
  
  for (let i = 0; i < argsList.length; i++) {
    const arg = argsList[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 < argsList.length) {
          args.format = argsList[i + 1];
          i++; // Skip next argument as it's the format value
        }
        break;
      case '--output':
        if (i + 1 < argsList.length) {
          args.output = argsList[i + 1];
          i++; // Skip next argument as it's the output value
        }
        break;
      case '--includeTotals':
        args.includeTotals = true;
        break;
      default:
        // Treat as data file if not a flag
        if (!arg.startsWith('--')) {
          args.dataFile = arg;
        }
        break;
    }
  }

  return args;
}

function validateArgs(args: ParsedArgs): void {
  if (!args.dataFile) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: Format is required (--format markdown|--format text)');
    process.exit(1);
  }

  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error(`Error: Unsupported format "${args.format}". Supported formats: markdown, text`);
    process.exit(1);
  }
}

function readAndParseJson(filePath: string): ReportData {
  try {
    const resolvedPath = resolve(filePath);
    const content = readFileSync(resolvedPath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid required field: title (string)');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid required field: summary (string)');
    }
    
    if (!data.entries || !Array.isArray(data.entries) || data.entries.length === 0) {
      throw new Error('Missing or invalid required field: entries (array with at least one entry)');
    }
    
    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: Missing or invalid required field: label (string)`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i + 1}: Missing or invalid required field: amount (number)`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}": ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Failed to read or parse file "${filePath}"`);
    }
    process.exit(1);
  }
}

function formatReport(data: ReportData, format: string, includeTotals: boolean): string {
  const options: CliOptions = {
    format: format as 'markdown' | 'text',
    includeTotals,
  };

  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      // This should not happen due to validation, but handle defensively
      console.error(`Error: Unsupported format "${format}"`);
      process.exit(1);
  }
}

function outputReport(report: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, report, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file "${outputPath}": ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    // Output to stdout
    process.stdout.write(report);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  validateArgs(args);
  
  const data = readAndParseJson(args.dataFile);
  const report = formatReport(data, args.format, args.includeTotals);
  outputReport(report, args.output);
}

// Only run main if this module is the entry point
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
