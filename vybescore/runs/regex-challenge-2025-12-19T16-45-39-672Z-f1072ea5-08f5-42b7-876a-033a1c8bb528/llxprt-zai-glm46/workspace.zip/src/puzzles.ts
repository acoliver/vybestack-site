/**
 * Matches words starting with the prefix but excluding banned words
 * Returns an array of matching words
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') {
    return [];
  }
  
  // Escape the prefix for regex and create word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with the prefix
  // \b ensures we match whole words only
  // [a-zA-Z'-]* allows for apostrophes and hyphens within words
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z'-]*`, 'gi');
  
  // Find all matches
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions and return unique matches
  const filteredMatches = matches
    .filter(word => {
      // Check if the word is in the exceptions list
      const isException = exceptions.some(exception => {
        const exceptionLower = exception.toLowerCase();
        return word.toLowerCase() === exceptionLower || word.toLowerCase().startsWith(exceptionLower);
      });
      
      return !isException;
    })
    .filter((word, index, array) => array.indexOf(word) === index); // Remove duplicates
  
  return filteredMatches;
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string
 * Uses lookaheads and lookbehinds for precise matching
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') {
    return [];
  }
  
  // Escape the token for regex to handle special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match the token when it's preceded by a digit
  // Using \d before the token to ensure it comes after a digit
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(tokenPattern) || [];
  
  // Return unique matches
  const uniqueMatches = [...new Set(matches)];
  
  return uniqueMatches;
}

/**
 * Validates passwords according to security policy
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  // Use a simplified pattern that doesn't trigger eslint warnings
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for repeated characters (e.g., aaa, bbb)
  if (/(.)\1{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses
 * Returns true if IPv6 address is found, false otherwise
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // IPv4 pattern to exclude
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 patterns (comprehensive)
  const ipv6Patterns = [
    // Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    
    // Shortened with :: (zero compression): 2001:db8::1
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/,
    
    // Leading zeros omitted: 2001:db8:85a3:0:0:8a2e:370:7334
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    
    // Mixed with IPv4: ::ffff:192.0.2.128
    /\b::ffff:(?:\d{1,3}\.){3}\d{1,3}\b/,
    
    // Loopback: ::1
    /\b::1\b/,
    
    // Unspecified: ::
    /\b::\b/,
    
    // Link-local: fe80::
    /\bfe80::[0-9a-fA-F]{1,4}%?\d*\b/,
    
    // Unique local: fc00::
    /\bfc[01]::[0-9a-fA-F:]+\b/,
    
    // Multicast: ff00::
    /\bff[0-9a-fA-F]{2}::[0-9a-fA-F:]+\b/,
    
    // General pattern for most IPv6 addresses
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}(?::\d{1,3}(?:\.\d{1,3}){3})?\b/
  ];
  
  // First, check if the string contains any IPv4 addresses
  if (ipv4Pattern.test(value)) {
    // If it contains IPv4, we need to be more careful
    // We should only return true if we find IPv6 AND not IPv4
    // or if we find IPv6 in addition to IPv4
    
    // Check for IPv6 in the string
    for (const pattern of ipv6Patterns) {
      const matches = value.match(pattern);
      if (matches) {
        // For each IPv6 match, check if it's not actually an IPv4 address
        for (const match of matches) {
          // If the match contains dots but also colons, it's likely IPv6
          if (match.includes(':') && !ipv4Pattern.test(match.trim())) {
            return true;
          }
          // If it doesn't contain dots but has colons, it's IPv6
          if (match.includes(':') && !match.includes('.')) {
            return true;
          }
        }
      }
    }
    return false;
  }
  
  // No IPv4 found, just check for IPv6
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}