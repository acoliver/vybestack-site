export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  // More strict validation for common patterns
  const strictEmailRegex = /^[a-zA-Z0-9][a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]*[a-zA-Z0-9]@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check for basic email structure first
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validation rules
  // Reject double dots in local part
  if (value.includes('..')) {
    return false;
  }
  
  // Reject leading or trailing dots
  if (value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Split into local and domain parts
  const [localPart, domain] = value.split('@');
  
  // Local part validation
  // Reject consecutive dots
  if (localPart.includes('..')) {
    return false;
  }
  
  // Reject leading or trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain validation
  // Reject underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject double dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  // Reject leading or trailing dots in domain
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Check if domain has at least one dot and ends with valid TLD
  if (!strictEmailRegex.test(value)) {
    return false;
  }
  
  // Additional check for domain segments
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.length === 0) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers with comprehensive format support
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters first
  const cleaned = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('1') && digits.length > 10) {
    digits = digits.substring(1);
  }
  
  // Must have exactly 10 digits for US number
  if (digits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Area code cannot be 555 (used for fictional numbers in some contexts)
  if (areaCode === '555') {
    // Allow 555-1212 as it's commonly used in examples, but be more restrictive
    const lineNumber = digits.substring(6);
    if (lineNumber === '1212') {
      return false;
    }
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate format using regex patterns
  const patterns = [
    // With parentheses and separators: (212) 555-7890, (212)555-7890
    /^\+?1?\s*\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/,
    // Without parentheses: 212-555-7890, 212.555.7890, 212 555 7890
    /^\+?1?\s*([2-9]\d{2})[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/,
    // Just digits: 2125557890, 12125557890
    /^\+?1?([2-9]\d{2})([2-9]\d{2})(\d{4})$/
  ];
  
  for (const pattern of patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}

/**
 * Validates Argentine phone numbers with complex format handling
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must contain 6-8 digits
 * - When country code is omitted, must begin with trunk prefix 0
 * - Allow single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters for analysis
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have the right number of digits (including country code)
  // Minimum: area code (2-4) + subscriber (6-8) = 8-12 digits
  // With country code: +54 adds 2 digits = 10-14 digits
  if (digitsOnly.length < 8 || digitsOnly.length > 14) {
    return false;
  }
  
  // Try to extract components
  let remainingDigits = digitsOnly;
  let countryCode = '';
  
  // Check for +54 country code
  if (remainingDigits.startsWith('54') && remainingDigits.length >= 10) {
    countryCode = '54';
    remainingDigits = remainingDigits.substring(2);
  }
  
  // Check for trunk prefix 0 (when no country code)
  if (!countryCode && remainingDigits.startsWith('0')) {
    remainingDigits = remainingDigits.substring(1);
  }
  
  // Check for mobile indicator 9
  if (remainingDigits.startsWith('9')) {
    remainingDigits = remainingDigits.substring(1);
  }
  
  // Now we should have area code + subscriber number
  if (remainingDigits.length < 8 || remainingDigits.length > 12) {
    return false;
  }
  
  // Try to split into area code and subscriber number
  let areaCode = '';
  
  // Area code is 2-4 digits, try different lengths
  for (let areaCodeLength = 2; areaCodeLength <= 4; areaCodeLength++) {
    if (remainingDigits.length > areaCodeLength) {
      const testAreaCode = remainingDigits.substring(0, areaCodeLength);
      const testSubscriberNumber = remainingDigits.substring(areaCodeLength);
      
      // Validate area code: 2-4 digits, leading digit 1-9
      if (/^[1-9]\d{1,3}$/.test(testAreaCode)) {
        // Validate subscriber number: 6-8 digits
        if (/^\d{6,8}$/.test(testSubscriberNumber)) {
          areaCode = testAreaCode;
          break;
        }
      }
    }
  }
  
  // If we couldn't find a valid split, try other combinations
  if (!areaCode) {
    return false;
  }
  
  // If we didn't extract country code but the original number didn't start with 0
  // and doesn't have country code, this might be invalid
  if (!countryCode && !value.startsWith('+54') && !value.startsWith('0')) {
    // Allow this for some cases where the area code is at the beginning
    // But be more strict
    if (areaCode !== '11') { // Buenos Aires is a special case
      return false;
    }
  }
  
  return true;
}

/**
 * Validates personal names with unicode support
 * Allows unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  const trimmed = value.trim();
  
  // Empty name is invalid
  if (trimmed.length === 0) {
    return false;
  }
  
  // Very short names (less than 2 characters) are probably invalid
  if (trimmed.length < 2) {
    return false;
  }
  
  // Very long names are suspicious (more than 100 characters)
  if (trimmed.length > 100) {
    return false;
  }
  
  // Regex pattern for valid names
  // Allows: unicode letters (including accented characters), apostrophes, hyphens, spaces
  // Rejects: digits, symbols, emojis, X Æ A-12 style names
  const namePattern = /^[\p{L}\p{M}'][\p{L}\p{M}'\-\s]*$/u;
  
  if (!namePattern.test(trimmed)) {
    return false;
  }
  
  // Ensure the name has at least one letter
  if (!/[\p{L}\p{M}]/u.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx prefixes and lengths)
 * Runs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters (spaces, hyphens, etc.)
  const cleaned = value.replace(/\D/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check valid length (13-19 digits for most cards)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Card issuer patterns
  const cardPatterns = {
    visa: /^4[0-9]{12}(?:[0-9]{3})?$/, // 13 or 16 digits, starts with 4
    mastercard: /^5[1-5][0-9]{14}$/, // 16 digits, starts with 51-55
    mastercardNew: /^2[2-7][0-9]{14}$/, // New Mastercard ranges (2221-2720)
    amex: /^3[47][0-9]{13}$/, // 15 digits, starts with 34 or 37
    discover: /^6(?:011|5[0-9]{2})[0-9]{12}$/, // 16 digits
    diners: /^3(?:0[0-5]|[68][0-9])[0-9]{11}$/, // 14 digits
    jcb: /^(?:2131|1800|35\d{3})\d{11}$/ // 16 digits, starts with 35
  };
  
  // Check if the card number matches any known pattern
  let isValidPattern = false;
  for (const pattern of Object.values(cardPatterns)) {
    if (pattern.test(cleaned)) {
      isValidPattern = true;
      break;
    }
  }
  
  if (!isValidPattern) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
