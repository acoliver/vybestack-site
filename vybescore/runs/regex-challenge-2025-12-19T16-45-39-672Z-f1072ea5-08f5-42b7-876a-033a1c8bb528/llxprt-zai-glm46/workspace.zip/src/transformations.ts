/**
 * Capitalizes the first character of each sentence
 * After .?! inserts exactly one space between sentences
 * Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // First, normalize whitespace - collapse multiple spaces to single space
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Common abbreviations that should not trigger sentence boundaries
  const abbreviations = [
    'Mr.', 'Mrs.', 'Ms.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'St.',
    'Mt.', 'Ave.', 'Blvd.', 'Rd.', 'Inc.', 'Ltd.', 'Corp.', 'Co.',
    'U.S.', 'U.K.', 'U.S.A.', 'U.S.S.R.', 'e.g.', 'i.e.',
    'vs.', 'etc.', 'al.', 'approx.', 'est.', 'No.', 'Fig.', 'Figs.',
    'vol.', 'vols.', 'ed.', 'eds.', 'p.', 'pp.', 'ch.', 'sec.',
    'dept.', 'div.', 'rev.', 'univ.', 'assn.', 'bldg.', 'ft.'
  ];
  
  // Create regex pattern for abbreviations
  // const abbreviationPattern = new RegExp(`\\b(${abbreviations.join('|')})`, 'gi');
  
  // Insert space after sentence-ending punctuation if not present
  // But be careful with abbreviations
  result = result.replace(/([.!?])(?![\s']|$)/g, '$1 ');
  
  // Now split into sentences, being careful with abbreviations
  // We'll use a more sophisticated approach
  
  // Mark sentence boundaries while avoiding abbreviations
  let markedText = result;
  
  // Replace known abbreviations with temporary markers
  abbreviations.forEach(abbrev => {
    const regex = new RegExp(abbrev, 'gi');
    markedText = markedText.replace(regex, match => match.replace(/\./g, '§§DOT§§'));
  });
  
  // Find sentence boundaries in the marked text
  const sentences: string[] = [];
  let currentSentence = '';
  
  for (let i = 0; i < markedText.length; i++) {
    const char = markedText[i];
    currentSentence += char;
    
    // Check for sentence-ending punctuation
    if (char === '.' || char === '!' || char === '?') {
      // Look ahead to see if this is really the end of a sentence
      const nextChar = markedText[i + 1];
      if (!nextChar || /\s/.test(nextChar)) {
        sentences.push(currentSentence);
        currentSentence = '';
        
        // Skip any whitespace after the punctuation
        while (i + 1 < markedText.length && /\s/.test(markedText[i + 1])) {
          i++;
        }
      }
    }
  }
  
  // Add any remaining text
  if (currentSentence.trim()) {
    sentences.push(currentSentence);
  }
  
  // Capitalize each sentence and join them
  const capitalizedSentences = sentences.map(sentence => {
    // Restore dots from temporary markers
    let restored = sentence.replace(/§§DOT§§/g, '.');
    
    // Trim and capitalize first character
    restored = restored.trim();
    if (restored.length > 0) {
      restored = restored[0].toUpperCase() + restored.slice(1);
    }
    
    return restored;
  });
  
  // Join sentences with single spaces
  result = capitalizedSentences.join(' ');
  
  // Final cleanup: ensure single spaces between words
  result = result.replace(/\s+/g, ' ').trim();
  
  return result;
}

/**
 * Finds URLs in the text and returns an array of matched URL strings
 * Removes trailing punctuation like commas, periods, etc.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }
  
  // URL pattern that matches most common URL formats
  // This is a comprehensive pattern that matches:
  // - http://, https://, ftp:// protocols
  // - www. prefix
  // - domain names with various TLDs
  // - IP addresses
  // - paths, query strings, fragments
  const urlPattern = new RegExp(
    '\\b(?:(?:https?|ftp):\\/\\/|www\\.)[-a-zA-Z0-9@:%._+~#=]{1,256}\\.[a-zA-Z0-9()]{1,6}\\b(?:[-a-zA-Z0-9()@:%_+.~#?&\\/=]*)',
    'gi'
  );
  
  // Find all matches
  const matches = text.match(urlPattern) || [];
  
  // Clean up matches: remove trailing punctuation
  const cleanedMatches = matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?)]}]+$/g, '');
  }).filter(url => url.length > 0); // Filter out empty strings after cleanup
  
  // Remove duplicates while preserving order
  const uniqueMatches = Array.from(new Set(cleanedMatches));
  
  return uniqueMatches;
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched
 * Replaces http:// with https:// but preserves https:// URLs as they are
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Use regex to replace http:// with https://
  // This pattern matches http:// but not https:// (using negative lookahead)
  const httpPattern = /http:\/\//g;
  
  return text.replace(httpPattern, 'https://');
}

/**
 * Rewrites http://example.com/... URLs according to complex rules
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite when path contains dynamic hints or legacy extensions
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Pattern to match URLs from example.com
  // This is more complex because we need to capture different parts of the URL
  const urlPattern = new RegExp(
    '(https?:\\/\\/)([^\\/:]+(?:\\.[^\\/:]+)*)(\\/[^\\s]*)?',
    'gi'
  );
  
  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    // Always upgrade scheme to https
    const newScheme = 'https://';
    
    // If no path, just upgrade the scheme
    if (!path || path === '/') {
      return newScheme + host;
    }
    
    // Check if we should skip host rewrite due to dynamic hints or legacy extensions
    const dynamicHints = [
      'cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', 
      '.do', '.cgi', '.pl', '.py', '.rb', '.cfm', '.cfml'
    ];
    
    const shouldSkipHostRewrite = dynamicHints.some(hint => 
      path.toLowerCase().includes(hint.toLowerCase())
    );
    
    // Check if the path begins with /docs/ (case insensitive)
    const docsPathPattern = /^\/docs\//i;
    const isDocsPath = docsPathPattern.test(path);
    
    // Only perform host rewrite for docs paths and when we shouldn't skip
    if (isDocsPath && !shouldSkipHostRewrite) {
      // Extract the base domain and TLD
      const domainParts = host.split('.');
      
      // If we have at least 2 parts (domain.tld), rewrite to docs.domain.tld
      if (domainParts.length >= 2) {
        const newHost = 'docs.' + domainParts.slice(-2).join('.');
        return newScheme + newHost + path;
      } else if (domainParts.length === 1) {
        // For single-part hosts (like localhost), just prepend docs.
        const newHost = 'docs.' + domainParts[0];
        return newScheme + newHost + path;
      }
    }
    
    // Otherwise, just upgrade the scheme
    return newScheme + host + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings
 * Returns 'N/A' when the format is invalid or month/day are invalid
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = datePattern.exec(value.trim());
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [
    31, // January
    28, // February (leap year handled below)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  // Check for leap year
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  const maxDays = (month === 2 && isLeapYear) ? 29 : daysInMonth[month - 1];
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  // Check for reasonable year range (e.g., 1000-2999)
  if (yearNum < 1000 || yearNum > 2999) {
    return 'N/A';
  }
  
  return year;
}