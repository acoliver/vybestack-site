/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words starting with the prefix
  // Use raw regex literal instead of string to avoid escaping issues
  const regexPattern = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  const matches = text.match(regexPattern) || [];
  
  // Filter out the exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  return matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use regex to find token after a digit, not at start of string
  const matches = [];
  const tokenPattern = new RegExp(token, 'gi');
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    const position = match.index;
    
    // Check if this token is not at the start and is preceded by a digit
    if (position > 0 && /\d/.test(text[position - 1])) {
      // Return the token that comes after the digit (digit + token)
      const digitBefore = text[position - 1];
      matches.push(digitBefore + match[0]);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (!value || value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "1212", "abcabc")
  // This pattern looks for any 2+ character sequence that repeats immediately
  for (let i = 0; i < value.length - 3; i++) {
    for (let j = 2; j <= Math.floor((value.length - i) / 2); j++) {
      const sequence = value.substring(i, i + j);
      const nextPart = value.substring(i + j, i + 2 * j);
      if (sequence === nextPart && j >= 2) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, let's exclude obvious IPv4 addresses to avoid false positives
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 regex pattern
  // This pattern handles:
  // - Full IPv6: 2001:0db8:0000:0000:0000:ff00:0042:8329
  // - Compressed with :: : 2001:db8::ff00:42:8329
  // - Leading zeros omitted: 2001:db8:0:0:0:ff00:42:8329
  // - IPv4-mapped: ::ffff:192.0.2.1
  
  const ipv6Patterns = [
    // Standard full IPv6 (8 groups of 1-4 hex digits)
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    
    // IPv6 with :: compression (at least one group of zeros compressed)
    /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/,
    
    // IPv6 starting with :: (starts with compressed zeros)
    /\b::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/,
    
    // IPv6 ending with :: (ends with compressed zeros)
    /\b(?:[0-9a-fA-F]{1,4}:)+::\b/,
    
    // IPv6 with :: in middle (general case)
    /\b(?:[0-9a-fA-F]{1,4}:)+::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/,
    
    // IPv4-mapped IPv6 addresses
    /\b::(?:ffff:)?(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/,
    
    // IPv4-embedded IPv6
    /\b(?:[0-9a-fA-F]{1,4}:){2}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/
  ];
  
  // Test against all IPv6 patterns
  return ipv6Patterns.some(pattern => pattern.test(value));
}
