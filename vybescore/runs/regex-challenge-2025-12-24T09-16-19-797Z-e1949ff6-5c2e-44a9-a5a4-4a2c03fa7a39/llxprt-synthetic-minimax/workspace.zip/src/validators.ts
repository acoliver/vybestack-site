export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  // Remove all non-digit characters
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for obviously invalid patterns first
  if (value.includes('@@') || value.includes('..') || value.endsWith('.') || value.startsWith('@')) {
    return false;
  }
  
  // Basic email regex pattern
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Check for underscores in domain (reject)
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle +1 prefix
  let normalizedNumber = digitsOnly;
  if (normalizedNumber.startsWith('1') && normalizedNumber.length === 11) {
    normalizedNumber = normalizedNumber.substring(1);
  }
  
  // Must be exactly 10 digits now
  if (normalizedNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = normalizedNumber.substring(0, 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if the original format matches one of the allowed patterns
  const allowedPatterns = [
    /^\+?1?[.\-\s]?\(?\d{3}\)?[.\-\s]?\d{3}[.\-\s]?\d{4}$/, // +1 (212) 555-7890
    /^\+?1?[.\-\s]?\d{3}[.\-\s]?\d{3}[.\-\s]?\d{4}$/, // +1 212-555-7890
    /^\+?1?\d{10}$/ // +12125557890
  ];
  
  return allowedPatterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-separator characters first, but keep track of separators
  const cleanValue = value.replace(/[\s-]/g, ' ').trim();
  
  // Extract just digits to validate the structure
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length - need at least 8 digits (2-4 area + 6-8 subscriber)
  if (digitsOnly.length < 8) {
    return false;
  }
  
  if (digitsOnly.length > 13) { // +54 + 9 + 4 area + 8 subscriber
    return false;
  }
  
  // Pattern matching for Argentine phone numbers
  // Country code: +54 (optional)
  // Mobile indicator: 9 (optional, only if country code present or after trunk 0)
  // Area code: 2-4 digits (first digit 1-9)
  // Subscriber: 6-8 digits
  
  const patterns = [
    // +54 9 XX XXXXXXX (mobile with country code)
    /^\+54\s?9\s?\d{2,4}\s?\d{6,8}$/,
    // 0XX XXXXXXX (landline without country code)
    /^0\d{2,4}\s?\d{6,8}$/,
    // +54 XX XXXXXXX (landline with country code) - this should match +54 341 123 4567
    /^\+54\s?\d{3}\s?\d{3}\s?\d{4}$/,
    // 09XX XXXXXXX (mobile without country code)
    /^09\d{2,4}\s?\d{6,8}$/
  ];
  
  // Check if any pattern matches
  if (!patterns.some(pattern => pattern.test(cleanValue))) {
    return false;
  }
  
  // Additional validation: ensure area code starts with 1-9 and total structure is correct
  const match = cleanValue.match(/\+?54\s?9?\s?(\d{2,4})\s?(\d{6,8})/);
  if (match) {
    const areaCode = match[1];
    const subscriber = match[2];
    
    // Area code must start with 1-9
    if (areaCode[0] < '1' || areaCode[0] > '9') {
      return false;
    }
    
    // Subscriber number must be 6-8 digits
    if (subscriber.length < 6 || subscriber.length > 8) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Empty or too short names are invalid
  if (!value || value.trim().length < 2) {
    return false;
  }
  
  // Check for invalid patterns
  // Reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject symbols except apostrophes, hyphens, and spaces
  // No need to escape - in the middle of character class, hyphen doesn't need escaping
  if (/[^a-zA-ZÀ-ÿ\s'\-]/.test(value)) {
    return false;
  }
  
  // Reject "X Æ A-12" style names (contains special characters not allowed)
  if (/[ÆØÅæøå]/.test(value) || /[^\w\s'\-]/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/[a-zA-ZÀ-ÿ]/.test(value)) {
    return false;
  }
  
  // Check that it's not just spaces, apostrophes, hyphens
  // No need to escape - at the end of character class, hyphen doesn't need escaping
  const lettersOnly = value.replace(/[\s'\-]/g, '');
  if (lettersOnly.length === 0) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');

  // Check if we have a valid length (13-19 digits for most cards)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }

  // Check card type based on prefix and length
  const isVisa = digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19);
  const isMastercard = (digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || digits.startsWith('54') || digits.startsWith('55')) && digits.length === 16;
  const isAmex = (digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15;

  // If not a recognized card type, reject
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }

  // Perform Luhn checksum
  return runLuhnCheck(digits);
}