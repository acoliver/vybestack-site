/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Handle edge cases
  if (!text || text.length === 0) {
    return text;
  }
  
  // Split into sentences using . ? ! as delimiters
  // Use regex to find sentence boundaries
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  // Process each sentence
  const processedSentences = sentences.map(sentence => {
    if (!sentence.trim()) {
      return sentence; // Keep empty sentences as is
    }
    
    // Capitalize the first letter of each sentence
    return sentence.replace(/^\s*([a-zA-ZÀ-ÿ])/, (match, letter) => {
      return match.replace(letter, letter.toUpperCase());
    });
  });
  
  // Join sentences with single space, preserving original spacing for empty sentences
  return processedSentences.join(' ').replace(/\s+/g, ' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern - simpler approach to avoid compilation issues
  const urlRegex = /https?:\/\/[^\s<>"'()[\]]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation that might have been captured
    return url.replace(/[.,!?]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
  const httpUrlPattern = /http:\/\/([^\/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(httpUrlPattern, (match, host, path) => {
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions that should skip host rewrite
      const hasDynamicHints = /(\?|=|;|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py|cgi-bin)/i.test(path);
      
      if (hasDynamicHints) {
        // Only upgrade scheme, keep original host
        return 'https://' + host + path;
      } else {
        // Rewrite host to docs.{originalHost}
        const docsHost = 'docs.' + host;
        return 'https://' + docsHost + path;
      }
    }
    
    // For non-docs paths, just upgrade scheme
    return 'https://' + host + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = new Date(parseInt(year), month, 0).getDate();
  if (day < 1 || day > daysInMonth) {
    return 'N/A';
  }
  
  return year;
}