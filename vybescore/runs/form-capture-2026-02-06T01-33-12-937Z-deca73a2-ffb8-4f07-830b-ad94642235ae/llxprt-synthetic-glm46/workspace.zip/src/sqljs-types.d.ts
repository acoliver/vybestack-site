export interface Database {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...params: unknown[]): void;
  free(): void;
}

interface InitJs {
  Database: new (data?: Uint8Array) => Database;
}

declare module 'sql.js' {
  function init(): Promise<InitJs>;
  export = init;
}