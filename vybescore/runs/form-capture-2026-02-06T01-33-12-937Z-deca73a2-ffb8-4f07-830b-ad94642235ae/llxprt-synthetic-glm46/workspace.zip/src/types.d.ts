declare module 'sql.js' {
  function init(): Promise<SqlJs>;
  export = init;
  
  interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  interface Statement {
    run(...params: unknown[]): void;
    free(): void;
  }
  
  interface SqlJs {
    Database: new (data?: Uint8Array) => Database;
  }
  
  // Make Database available as a type
  export type Database = Database;
  export type Statement = Statement;
}