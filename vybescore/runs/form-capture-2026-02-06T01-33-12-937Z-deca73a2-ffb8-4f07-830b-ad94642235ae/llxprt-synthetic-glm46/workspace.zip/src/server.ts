import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { Server as HttpServer } from 'http';

// Import the types for sql.js from our custom declaration
/// <reference path="./types.d.ts" />
// Import the Database type directly from the module
import { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

type FormData = {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
};

type ValidationError = string;
type ValidationResult = { isValid: boolean; errors: ValidationError[] };

const port = process.env.PORT || 3535;
const dataDir = path.join(__dirname, '..', 'data');
const dbPath = path.join(dataDir, 'submissions.sqlite');
const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');

let db: Database;

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  return /^[+]?[0-9()\s-]+$/.test(phone);
}

function validateEmail(email: string): boolean {
  // Basic email validation
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validatePostalCode(postal: string): boolean {
  // Allow alphanumeric characters, spaces, and dashes
  return /^[a-zA-Z0-9\s-]+$/.test(postal);
}

function validateForm(formData: FormData): ValidationResult {
  const errors: ValidationError[] = [];
  
  console.log('Validating form data:', formData);
  
  if (!formData.firstName.trim()) {
    errors.push('First name is required');
  }
  
  if (!formData.lastName.trim()) {
    errors.push('Last name is required');
  }
  
  if (!formData.streetAddress.trim()) {
    errors.push('Street address is required');
  }
  
  if (!formData.city.trim()) {
    errors.push('City is required');
  }
  
  if (!formData.stateProvince.trim()) {
    errors.push('State/Province/Region is required');
  }
  
  if (!formData.postalCode.trim()) {
    errors.push('Postal/Zip code is required');
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push('Postal/Zip code contains invalid characters');
  }
  
  if (!formData.country.trim()) {
    errors.push('Country is required');
  }
  
  if (!formData.email.trim()) {
    errors.push('Email is required');
  } else if (!validateEmail(formData.email)) {
    errors.push('Email format is invalid');
  }
  
  if (!formData.phone.trim()) {
    errors.push('Phone number is required');
  } else if (!validatePhone(formData.phone)) {
    errors.push('Phone number contains invalid characters');
  }
  
  console.log('Validation result:', { isValid: errors.length === 0, errors });
  return {
    isValid: errors.length === 0,
    errors
  };
}

async function initDatabase(): Promise<void> {
  try {
    // Ensure data directory exists
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Initialize SQL.js
    const sqljs = await import('sql.js');
    const initSqlJs = sqljs.default;
    const SQL = await initSqlJs();
    
    // Check if database exists
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(schemaPath, 'utf8');
      const statements = schema.split(';').filter(stmt => stmt.trim());
      statements.forEach(stmt => {
        if (stmt.trim()) {
          db.run(stmt);
        }
      });
      saveDatabase();
    }
  } catch (error) {
    console.error('Database initialization failed:', error);
    throw error;
  }
}

function saveDatabase(): void {
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

function closeDatabase(): void {
  if (db) {
    db.close();
  }
}

export async function createServer(): Promise<express.Application> {
  await initDatabase();
  
  const app = express();
  
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(path.join(__dirname, '..', 'public')));
  
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));
  
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { errors: null, values: {} });
  });
  
app.post('/submit', (req: Request, res: Response) => {
  console.log('POST /submit received');
  const formData = req.body as FormData;
  console.log('Form data received:', formData);
  
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    console.log('Validation failed:', validation.errors);
    return res.status(400).render('form', { 
      errors: validation.errors, 
      values: formData 
    });
  }
  
  console.log('Validation passed, inserting into database');
  try {
    const stmt = db.prepare(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))`
    );
    
    stmt.run(
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    );
    
    stmt.free();
    saveDatabase();
    
    console.log('Database insertion successful, redirecting to /thank-you');
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database insertion failed:', error);
    return res.status(500).render('form', {
      errors: ['An unexpected error occurred. Please try again.', `Error: ${error}`],
      values: formData
    });
  }
});
  
  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', { firstName: 'Dear Friend' });
  });
  
  return app;
}

import { Server } from 'http';

function gracefulShutdown(server: HttpServer): void {
  console.log('Shutting down gracefully...');
  server.close(() => {
    console.log('Server closed');
    closeDatabase();
    process.exit(0);
  });
  
  // Force shutdown after 10 seconds
  setTimeout(() => {
    console.log('Forcing shutdown...');
    process.exit(1);
  }, 10000);
}

async function startServer(): Promise<void> {
  try {
    const app = await createServer();
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    // Handle SIGTERM for graceful shutdown
    process.on('SIGTERM', () => gracefulShutdown(server));
    process.on('SIGINT', () => gracefulShutdown(server));
    
    return;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();
