/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input and validates it properly.
 */
export function decode(input: string): string {
  // Validate Base64 input using the standard alphabet and optional padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Additional validation: if padding is present, it must be at the end and properly formed
  if (input.includes('=')) {
    const paddingIndex = input.indexOf('=');
    const afterPadding = input.slice(paddingIndex);
    
    // Padding can only be '=' or '==', and must be at the end
    if (!/^=+$/.test(afterPadding) || afterPadding.length > 2) {
      throw new Error('Invalid Base64 input: invalid padding format');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
