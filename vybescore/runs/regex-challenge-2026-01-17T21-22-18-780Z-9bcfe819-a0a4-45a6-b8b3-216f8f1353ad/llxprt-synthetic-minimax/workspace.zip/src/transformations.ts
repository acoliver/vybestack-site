/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces by collapsing multiple spaces to single spaces
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Capitalize the very first character if it's a letter
  if (result.length > 0 && /[a-zA-Z]/.test(result[0])) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  // Pattern to match sentence endings followed by whitespace and new sentences
  const sentencePattern = /([.!?])\s*([a-zA-Z])/g;
  
  // Capitalize first letter after sentence endings and ensure proper spacing
  result = result.replace(sentencePattern, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs (http/https/ftp, with optional trailing punctuation)
  const urlPattern = /\b(?:https?|ftp):\/\/[^\s<>"'{}|\\^`[\]!,?;:\']*/gi;
  
  const urls = text.match(urlPattern) || [];
  
  // Clean up URLs by removing trailing punctuation but preserve domain
  const cleanUrls = urls.map(url => {
    // Remove trailing punctuation that commonly follows URLs
    return url.replace(/[.,!?;:\']+$/g, '');
  });
  
  // Remove duplicates while preserving order
  const uniqueUrls = cleanUrls.filter((url, index) => {
    return cleanUrls.indexOf(url) === index;
  });
  
  return uniqueUrls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while preserving the rest of the URL
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
  // Capture: scheme, host, path
  const urlPattern = /http:\/\/([^/]+)([^\s]*)/gi;
  
  return text.replace(urlPattern, (match, host, path) => {
    // Check for dynamic hints or legacy extensions in path
    const dynamicHints = /(cgi-bin|[?.=&],php|asp|aspx|do|cgi|pl|[.py])/i;
    const hasDynamicHints = dynamicHints.test(path);
    
    // Always upgrade scheme to https
    let newUrl = 'https://' + host;
    
    // If path starts with /docs/ and has no dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Extract original domain (e.g., example.com from docs.example.com)
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        const domain = domainParts.slice(-2).join('.');
        newUrl = 'https://docs.' + domain + path;
      } else {
        newUrl = 'https://docs.' + host + path;
      }
    } else {
      // Keep the original host but upgrade scheme
      newUrl = 'https://' + host + path;
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 29 for February (simplified leap year check)
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    // Handle leap year for February
    if (month === 2 && day === 29) {
      // Simplified leap year check
      const yearNum = parseInt(year, 10);
      if (yearNum % 4 !== 0 || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
        return 'N/A';
      }
    } else {
      return 'N/A';
    }
  }
  
  return year;
}
