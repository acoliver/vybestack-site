export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern for typical email addresses
  // Reject double dots, trailing dots, domains with underscores
  const emailPattern = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  return emailPattern.test(value.trim());
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + for country code
  const cleanValue = value.trim();
  
  // Pattern for US phone numbers
  // Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
  // Disallows area codes starting with 0 or 1
  const phonePattern = /^\+?1?[\s.-]?\(?([2-9][0-8][0-9])\)?[\s.-]?([2-9][0-9]{2})[\s.-]?([0-9]{4})[\s.-]?(?:[xX]|ext\.?|extension)?\s*([0-9]{1,5})?$/;
  
  if (!phonePattern.test(cleanValue)) {
    return false;
  }
  
  // Extract digits for area code validation
  const digits = cleanValue.replace(/\D/g, '');
  const areaCodeStart = digits.startsWith('1') ? 1 : 0;
  const areaCode = digits.substring(areaCodeStart, areaCodeStart + 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode.length === 3 && (areaCode.startsWith('0') || areaCode.startsWith('1'))) {
    return false;
  }
  
  // Total length validation (country code + area code + number)
  const totalLength = digits.length;
  const hasCountryCode = digits.startsWith('1');
  
  if (hasCountryCode && totalLength !== 11) {
    return false;
  }
  
  if (!hasCountryCode && totalLength !== 10) {
    return false;
  }
  
  return true;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleanValue = value.trim();
  
  // Remove all non-digit, non-space, non-hyphen characters
  const normalizedValue = cleanValue.replace(/[^\d\s-]/g, '');
  
  // Pattern for Argentine phone numbers
  // Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  // Optional country code +54
  // Optional trunk prefix 0 before area code
  // Optional mobile indicator 9 between country/trunk and area code
  // Area code: 2-4 digits (leading 1-9)
  // Subscriber number: 6-8 digits total
  const pattern = /^(?:\+54\s*)?(?:0\s*)?(?:9\s*)?([1-9]\d{1,3})\s*([0-9]{6,8})$/;
  
  const match = normalizedValue.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number (6-8 digits total)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, number must begin with trunk prefix 0
  if (!cleanValue.startsWith('+54') && !cleanValue.trim().startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern for valid names
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and complex names like "X Æ A-12"
  const namePattern = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!namePattern.test(value.trim())) {
    return false;
  }
  
  // Additional validation: no consecutive special characters
  const specialCharPattern = /['\-\s]{3,}/;
  if (specialCharPattern.test(value)) {
    return false;
  }
  
  // Reject names that look like codes (contain numbers or complex symbols)
  if (/[0-9]/.test(value)) {
    return false;
  }
  // Check for symbols that aren't allowed (basic unicode check)
  if (/[^\p{L}\p{M}\s'-]/u.test(value)) {
    return false;
  }
  
  // Minimum length check (at least 2 characters for a meaningful name)
  if (value.trim().length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  const cleanValue = value.replace(/\s|-/g, '');
  
  // Visa: starts with 4, length 13, 16, or 19
  const visaPattern = /^4[0-9]{12}(?:[0-9]{3})?$|^4[0-9]{15}$|^4[0-9]{18}$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPattern = /^5[1-5][0-9]{14}$|^2[2-7][0-9]{13}$/;
  
  // American Express: starts with 34 or 37, length 15
  const amexPattern = /^3[47][0-9]{13}$/;
  
  let isValid = false;
  
  // Check against all card patterns
  if (visaPattern.test(cleanValue)) {
    isValid = true;
  } else if (mastercardPattern.test(cleanValue)) {
    isValid = true;
  } else if (amexPattern.test(cleanValue)) {
    isValid = true;
  }
  
  if (!isValid) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleanValue);
}
