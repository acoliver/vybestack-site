/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words beginning with prefix (case insensitive)
  const prefixPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case insensitive)
  const filteredMatches = matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exc => exc.toLowerCase() === lowerMatch);
  });
  
  return filteredMatches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token occurrences that:
  // 1. Appear after a digit (positive lookbehind)
  // 2. Are not at the start of the string (negative lookbehind)
  const pattern = new RegExp(`(?<!^)(?<=\\d)${token}`, 'gi');
  
  try {
    const matches = text.match(pattern);
    return matches ? matches : [];
  } catch (e) {
    // Fallback for older regex engines without lookbehind support
    const result: string[] = [];
    let index = 0;
    
    while (index < text.length) {
      const digitIndex = text.search(/\d/);
      if (digitIndex === -1) break;
      
      // Look for token after this digit position
      const remainingText = text.substring(digitIndex + 1);
      const tokenIndex = remainingText.indexOf(token);
      
      if (tokenIndex !== -1) {
        // Found token after digit, and it's not at the very start of the whole string
        if (digitIndex + tokenIndex + 1 > 0) {
          result.push(token);
        }
        // Move past this token to find more occurrences
        index = digitIndex + tokenIndex + 1;
      } else {
        // No token found after this digit, move past the digit
        index = digitIndex + 1;
      }
    }
    
    return result;
  }
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Length check - at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace check
  if (/\s/.test(value)) {
    return false;
  }
  
  // Character type requirements
  if (!/[A-Z]/.test(value)) {
    return false; // Missing uppercase
  }
  
  if (!/[a-z]/.test(value)) {
    return false; // Missing lowercase
  }
  
  if (!/[0-9]/.test(value)) {
    return false; // Missing digit
  }
  
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false; // Missing symbol
  }
  
  // Check for immediate repeated sequences
  // Pattern to find 4+ character repeats like "abab", "123123", etc.
  const repeatPattern = /(..+)\1/;
  if (repeatPattern.test(value)) {
    return false;
  }
  
  // Additional check for consecutive identical characters (3+ in a row)
  const consecutivePattern = /(.)\1\1/;
  if (consecutivePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern to match IPv6 addresses including shorthand notation
  // IPv6 addresses contain colons (:) and hex digits (0-9A-Fa-f)
  // Include shorthand using :: (double colon)
  const ipv6Pattern = /(?:[0-9A-Fa-f]{1,4}:){1,7}[0-9A-Fa-f]{1,4}|(?:[0-9A-Fa-f]{1,4}:){1,6}::[0-9A-Fa-f]{1,4}|(?:[0-9A-Fa-f]{1,4}:){1,5}::(?:[0-9A-Fa-f]{1,4}:){0,1}[0-9A-Fa-f]{1,4}|(?:[0-9A-Fa-f]{1,4}:){1,4}::(?:[0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4}|(?:[0-9A-Fa-f]{1,4}:){1,3}::(?:[0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4}|(?:[0-9A-Fa-f]{1,4}:){1,2}::(?:[0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4}|[0-9A-Fa-f]{1,4}::(?:[0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4}|::(?:[0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4}|::/i;
  
  // First, check if the pattern matches (this would catch IPv6)
  if (ipv6Pattern.test(value)) {
    // Ensure it's not an IPv4 address that somehow triggered the pattern
    const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
    if (ipv4Pattern.test(value)) {
      // If it looks like IPv4, it's not IPv6
      return false;
    }
    // If it doesn't look like IPv4, it's IPv6
    return true;
  }
  
  // Additional check: IPv6 addresses typically contain more than 7 colon-separated segments
  // or contain :: shorthand notation
  if (value.includes('::')) {
    // Contains shorthand notation, likely IPv6
    const segments = value.split('::');
    if (segments.length >= 2) {
      // Ensure it's not mixed with IPv4-like segments
      for (const segment of segments) {
        if (segment.match(/^\d+$/)) {
          // Numeric-only segment might be IPv4, but IPv6 can have these
          continue;
        }
      }
      return true;
    }
  }
  
  // Check for typical IPv6 hex segments separated by colons
  const colonSegments = value.split(':');
  if (colonSegments.length >= 8) {
    // Too many segments for IPv4, likely IPv6
    return true;
  }
  
  // If we reach here, it's not IPv6
  return false;
}
