/**
 * Regular expression to validate Base64 strings.
 * Allows standard Base64 characters with or without padding.
 */
const BASE64_REGEX = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}(==)?|[A-Za-z0-9+/]{3}=?)?$/;

/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error if the input is not valid Base64.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate Base64 format before attempting decode
  if (!BASE64_REGEX.test(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding produced valid output
    // A properly decoded Base64 string should never be empty if input was valid
    if (trimmed.length > 0 && buffer.length === 0) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
