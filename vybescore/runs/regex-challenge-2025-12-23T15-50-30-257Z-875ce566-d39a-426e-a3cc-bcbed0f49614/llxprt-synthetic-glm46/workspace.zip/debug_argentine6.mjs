// Let's debug the specific matching issue with '+54 9 01 1234 5678'
const problemCase = '+54 9 01 1234 5678';
console.log(`Target: '${problemCase}'`);

// This should match pattern: [+54] [9] [01] [1234] [5678]
// Where area code should be "01" (starts with 0, so should be invalid)

const normalized = problemCase.replace(/[\s-]/g, '');
console.log(`Normalized: '${normalized}'`);

const argPhoneRegex = /^(\+54)?9?0?([2-9]\d{1,3})(\d{6,8})$/;
const match = normalized.match(argPhoneRegex);

if (match) {
  console.log(`Matches: [${match.slice(1).join(', ')}]`);
  console.log(`Country: '${match[1]}`, Area: '${match[2]}', Subscriber: '${match[3]}'`);
  
  // The issue is that "01" (in the original) becomes "112" after removing the "0" trunk prefix
  // This was designed to handle area codes that start with 0 after trunk prefix removal
  // But the problem is that the regex is correctly stripping the "0" and then matching "112"
  // We need to catch the case where the area code would have started with 0

  // Let's try extracting what the area code would be before trunk prefix removal
  const with0Match = '+5490112345678'.match(/^(\+54)?9?0?([0-9]\d{1,3})(\d{6,8})$/);
  if (with0Match) {
    console.log(`Before trunk prefix: Area would be '${with0Match[2]}'`);
    if (with0Match[2].startsWith('0')) {
      console.log('This should be invalid because area code starts with 0');
    }
  }
}

// Let's try a different approach - parse the pattern before normalization
function parseArgentinePhone(value) {
  console.log(`\nParsing: '${value}'`);
  
  // Check for hyphens in subscriber part
  if (/\d{3,}-\d{3,}/.test(value)) {
    console.log('REJECTED: Hyphen in subscriber part');
    return false;
  }
  
  // Parse step by step without removing all separators
  const parts = value.split(/\s+/);
  console.log(`Parts: [${parts.join(', ')}]`);
  
  // Find country code if present
  let hasCountryCode = false;
  let remainingParts = [...parts];
  if (parts[0] === '+54') {
    hasCountryCode = true;
    remainingParts = parts.slice(1);
    console.log('Has country code +54');
  } else if (parts[0].startsWith('+54')) {
    hasCountryCode = true;
    // Handle cases like +549... where 9 is attached to country code
    remainingParts = [parts[0].slice(3), ...parts.slice(1)];
    console.log(`Has country code +54, remaining: [${remainingParts.join(', ')}]`);
  }
  
  // Look for mobile indicator 9
  let hasMobile = false;
  if (remainingParts[0] === '9' || remainingParts[0]?.startsWith('9')) {
    hasMobile = true;
    const current = remainingParts[0];
    remainingParts[0] = current.startsWith('9') ? current.slice(1) : remainingParts.slice(1)[0];
    console.log('Has mobile indicator 9');
  }
  
  // Parse area code and subscriber
  const joined = remainingParts.join('');
  console.log(`Joined remaining: '${joined}'`);
  
  // This should have format like 0111234567 or 3411234567
  const phoneMatch = joined.match(/^0?(\d{2,4})(\d{6,8})$/);
  if (!phoneMatch) {
    console.log('REJECTED: Cannot parse area and subscriber');
    return false;
  }
  
  const areaCode = phoneMatch[1];
  const subscriber = phoneMatch[2];
  
  console.log(`Area code: '${areaCode}', Subscriber: '${subscriber}'`);
  
  // Validate area code doesn't start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    console.log('REJECTED: Area code starts with 0 or 1');
    return false;
  }
  
  // Validate lengths
  if (areaCode.length < 2 || areaCode.length > 4) {
    console.log('REJECTED: Area code length invalid');
    return false;
  }
  
  if (subscriber.length < 6 || subscriber.length > 8) {
    console.log('REJECTED: Subscriber length invalid');
    return false;
  }
  
  // If no country code, must start with trunk prefix 0 in original
  if (!hasCountryCode && !value.startsWith('0')) {
    console.log('REJECTED: No country code but no trunk prefix');
    return false;
  }
  
  console.log('ACCEPTED');
  return true;
}

['+54 9 01 1234 5678', '+54 9 11 123-456'].forEach(parseArgentinePhone);