export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check for newlines or carriage returns in the email
  if (/[\r\n]/.test(value)) return false;
  
  // Basic email validation using regex
  // Allows name+tag@example.co.uk format
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Check for consecutive dots
  if (value.includes('..')) return false;
  
  // Check for trailing dots in local part or domain
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  // Check for trailing dot in local part before @
  const [localPart] = value.split('@');
  if (localPart && localPart.endsWith('.')) return false;
  
  // Check for underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  return emailRegex.test(value);
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Ignore the options parameter (not needed for basic validation, but kept for signature compatibility)
  void options;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // US phone numbers should have exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Exchange code (middle 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) return false;
  
  // Additional format validation - reject numbers with invalid area codes early
  if (/^((\+1\s*)?0|0\d)/.test(value)) return false;
  
  // Verify all characters are valid (digits, parentheses, hyphens, spaces)
  if (!/^[\d\-\s\(\)\+]+$/.test(value)) return false;
  
  // Check if the format matches one of the accepted patterns
  const patterns = [
    /^\+1\s*\(\d{3}\)\s*\d{3}-\d{4}$/, // (212) 555-7890 with +1
    /^\s*\(\d{3}\)\s*\d{3}-\d{4}$/, // (212) 555-7890
    /^\(\d{3}\)\d{3}-\d{4}$/, // (415)555-0199 - without spaces
    /^\+1\s*\d{3}-\d{3}-\d{4}$/, // 212-555-7890 with +1
    /^\d{3}-\d{3}-\d{4}$/, // 212-555-7890
    /^\+1\s*\d{10}$/, // 2125557890 with +1
    /^\d{10}$/ // 2125557890
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check for hyphens within components (disallowed)
  // Only allow hyphens as separators between main components (area code, subscriber)
  if (/\d-\d/.test(value)) return false;
  
  // Parse step by step without removing all separators to preserve area code prefix info
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Extract parts for validation  
  let remaining = cleanValue;
  let hasCountryCode = false;
  
  // Remove country code if present
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.substring(3);
  }
  
  // Remove mobile indicator if present
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // At this point, we should have something like 0111234567 or 11234567
  // Extract area code based on what comes after optional trunk prefix
  let areaCode: string, subscriber: string;
  
  if (remaining.startsWith('0')) {
    // Format: 0 AreaCode Subscriber
    const match = remaining.match(/^0([0-9]{1,3})([0-9]{6,8})$/);
    if (!match) return false;
    areaCode = match[1];
    subscriber = match[2];
  } else {
    // Format: AreaCode Subscriber (no trunk prefix, should have country code)
    if (!hasCountryCode) return false; // Must have country code if no trunk prefix
    const match = remaining.match(/^([0-9]{2,4})([0-9]{6,8})$/);
    if (!match) return false;
    areaCode = match[1];
    subscriber = match[2];
  }
  
  // Area code validation: 2-4 digits with leading digit NOT 0 (but 1 is allowed)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode.startsWith('0')) return false;
  
  // Subscriber length validation: 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and obviously invalid names
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Should not be all spaces or empty
  if (!value.trim()) return false;
  
  return nameRegex.test(value);
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanDigits = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanDigits)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|4[0-9]\d|5[0-9]\d|6[0-9]\d|7[01]\d|720)\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleanDigits) && !mastercardRegex.test(cleanDigits) && !amexRegex.test(cleanDigits)) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(cleanDigits);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}
