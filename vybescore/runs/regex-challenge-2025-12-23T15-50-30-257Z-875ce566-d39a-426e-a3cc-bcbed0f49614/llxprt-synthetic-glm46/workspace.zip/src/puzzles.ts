/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Create regex to find words starting with the prefix
  const prefixRegex = new RegExp(`\\b${escapeRegex(prefix)}\\w+`, 'g');
  
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Helper function to escape special regex characters
 */
function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];

  // Find all occurrences of digit followed by token
  // Match 3foo (separated by dash) and 4foo (followed by letters), but not foo5 (token followed by digit)
  const tokenRegex = new RegExp(`(\\d)${escapeRegex(token)}(?=\\D|$)`, 'g');

  const results: string[] = [];
  let match;

  // Find all matches and construct the full token with the preceding digit
  while ((match = tokenRegex.exec(text)) !== null) {
    results.push(match[1] + token);
  }

  return results;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for symbol (non-alphanumeric character)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab)
  if (/(.{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex patterns (including shorthand)
  // This allows for the various IPv6 formats including :: shorthand
  const ipv6Patterns = [
    // Full IPv6 pattern with :: shorthand
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    // IPv6 with :: compression
    /(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/,
    // IPv6 with leading :: compression
    /::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/,
    // IPv6 with trailing :: compression
    /(?:[0-9a-fA-F]{1,4}:){1,7}::/,
    // IPv6 with ::
    /::/,
    // IPv6 with embedded IPv4
    /(?:[0-9a-fA-F]{1,4}:){5,6}:(?:\d{1,3}\.){3}\d{1,3}/,
    // IPv6 with :: embedded IPv4
    /::(?:ffff:)?(?:\d{1,3}\.){3}\d{1,3}/
  ];
  
  // Check for IPv6 patterns while ensuring it's not just an IPv4 address
  const hasIPv6 = ipv6Patterns.some(pattern => pattern.test(value));
  
  // Make sure we have IPv6, not just IPv4
  // Check if the entire content is a pure IPv4 address
  const isPureIPv4 = /^\b(?:\d{1,3}\.){3}\d{1,3}\b$/.test(value.trim());
  
  return hasIPv6 && !isPureIPv4;
}
