/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Split into sentences using .?! as delimiters
  const sentences = text.split(/([.!?])/);
  
  for (let i = 0; i < sentences.length; i++) {
    // Every two elements form a complete sentence (content + delimiter)
    if (i % 2 === 0 && sentences[i].trim()) {
      // Get the sentence content
      const sentence = sentences[i];
      const delimiter = sentences[i + 1] || '';
      
      // Find the first alphabetic character and capitalize it
      const capitalizedSentence = sentence.replace(/^(\s*)([a-zA-Z])/, (match, space, letter) => {
        return space + letter.toUpperCase();
      });
      
      // Single space after sentence unless there's already punctuation
      const spacing = delimiter ? (delimiter.match(/[.!?]/) ? ' ' : '') : '';
      
      sentences[i] = capitalizedSentence;
      sentences[i + 1] = delimiter + spacing;
    }
  }
  
  return sentences.join('').replace(/\s+/g, ' ').replace(/\s+([.!?])/g, '$1').trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern - matches most common URL formats
  const urlRegex = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from matches
  return matches.map(url => url.replace(/[.,;:!?]+$/g, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https:// for all URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Always upgrade to https first
  let result = text.replace(/http:\/\//g, 'https://');
  
  // For docs.example.com URLs, rewrite host when path starts with /docs/
  // Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
  const urlPattern = /(https:\/\/example\.com)(\/docs\/[^?\s]*)(\?[^#\s]*|#[^#\s]*|)/g;
  
  result = result.replace(urlPattern, (match, protocol, path, query) => {
    // Check for dynamic hints that should prevent host rewrite
    const hasQueryString = query.includes('?');
    const hasDynamicHints = /\b(cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)\b/.test(path + query);
    
    if (hasQueryString || hasDynamicHints) {
      return match; // Keep original host for dynamic URLs
    }
    
    // Rewrite to docs.example.com for docs paths
    return 'https://docs.example.com' + path + query;
  });
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format and capture the year
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';
  
  // Basic validation for month/day combinations (not exhaustive but sufficient)
  const monthsWith30Days = [4, 6, 9, 11];
  if (monthsWith30Days.includes(month) && day > 30) return 'N/A';
  
  // February
  if (month === 2 && day > 29) return 'N/A';
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    // Check if leap year
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (!isLeapYear) return 'N/A';
  }
  
  return year;
}
