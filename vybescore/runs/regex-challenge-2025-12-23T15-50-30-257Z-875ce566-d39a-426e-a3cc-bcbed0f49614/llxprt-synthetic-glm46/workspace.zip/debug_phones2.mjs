// Test the specific case that's failing
const problemPhone = '555-012-3456';
console.log(`Testing problem phone: ${problemPhone}`);

// Extract the digits
const digitsOnly = problemPhone.replace(/\D/g, '');
console.log(`Digits only: ${digitsOnly}`);

// Remove country code if present
let phoneNumber = digitsOnly;
if (phoneNumber.startsWith('1')) {
  phoneNumber = phoneNumber.substring(1);
}
console.log(`After removing country code: ${phoneNumber}`);

// Check length
console.log(`Length check: ${phoneNumber.length === 10}`);

// Check area code
const areaCode = phoneNumber.substring(0, 3);
console.log(`Area code: ${areaCode}, starts with 0/1: ${areaCode.startsWith('0') || areaCode.startsWith('1')}`);

// Check if any part starts with 0 or 1 that shouldn't
const firstPart = phoneNumber.substring(0, 3); // area code
const secondPart = phoneNumber.substring(3, 6); // exchange
console.log(`Exchange code: ${secondPart}, starts with 0/1: ${secondPart.startsWith('0') || secondPart.startsWith('1')}`);

// Test additional patterns
console.log(`Test \\d-0\\d- pattern: ${/\d-0\d-/.test(problemPhone)}`);
console.log(`Test \\d\\(0\\d pattern: ${/\d\(0\d/.test(problemPhone)}`);
console.log(`Test ^\\d{3}0\\d pattern: ${/^\d{3}0\d/.test(problemPhone)}`);