import fs from 'fs';

const valid = [
  '+1 (212) 555-7890',
  '212-555-7890',
  '(415)555-0199',
  '4155550199'
];
const invalid = [
  '012-555-7890',
  '212-55-7890',
  '555-012-3456',
  '1 (800) FLOWERS'
];

console.log('Testing US phone numbers...');
const validatorCode = fs.readFileSync('./src/validators.ts', 'utf8');

// Create a new function based on the current implementation
function isValidUSPhone(value, options) {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // US phone numbers should have exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Check if the format matches one of the accepted patterns
  const patterns = [
    /^\+1\s*\(\d{3}\)\s*\d{3}-\d{4}$/, // (212) 555-7890 with +1
    /^\s*\(\d{3}\)\s*\d{3}-\d{4}$/, // (212) 555-7890
    /^\+1\s*\d{3}-\d{3}-\d{4}$/, // 212-555-7890 with +1
    /^\s*\d{3}-\d{3}-\d{4}$/, // 212-555-7890
    /^\+1\s*\d{10}$/, // 2125557890 with +1
    /^\s*\d{10}$/
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

valid.forEach(sample => {
  console.log(`Valid '${sample}': ${isValidUSPhone(sample)}`);
});
console.log('---');
invalid.forEach(sample => {
  console.log(`Invalid '${sample}': ${isValidUSPhone(sample)}`);
});