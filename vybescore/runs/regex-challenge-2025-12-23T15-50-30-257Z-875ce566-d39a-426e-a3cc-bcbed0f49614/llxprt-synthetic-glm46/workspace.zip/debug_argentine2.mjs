// Debug the specific invalid cases
const problemCases = [
  '+54 9 01 1234 5678',   // Should fail: area code starts with 0
  '+54 9 11 123-456'     // Should fail: hyphen in subscriber part
];

problemCases.forEach(sample => {
  console.log(`\nTesting: '${sample}'`);
  const normalized = sample.replace(/[\s-]/g, '');
  console.log(`Normalized: '${normalized}'`);
  
  const argPhoneRegex = /^(\+54)?9?0?([1-9]\d{1,3})(\d{6,8})$/;
  const match = normalized.match(argPhoneRegex);
  
  if (!match) {
    console.log('  Failed: No regex match');
  } else {
    console.log(`  Match groups: [${match.slice(1).join(', ')}]`);
    const countryCode = match[1];
    const areaCode = match[2];
    const subscriber = match[3];
    
    console.log(`  Country code: '${countryCode}'`);
    console.log(`  Area code: '${areaCode}' (length: ${areaCode.length})`);
    console.log(`  Subscriber: '${subscriber}' (length: ${subscriber.length})`);
    
    // Check individual conditions
    if (!countryCode && !normalized.startsWith('0')) {
      console.log('  Failed: No country code but does not start with 0');
    }
    
    if (areaCode.length < 2 || areaCode.length > 4) {
      console.log('  Failed: Area code length invalid');
    }
    
    if (subscriber.length < 6 || subscriber.length > 8) {
      console.log('  Failed: Subscriber length invalid');
    }
    
    // Area code validation rule
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      console.log(`  Failed: Area code '${areaCode}' starts with 0 or 1`);
    }
  }
});