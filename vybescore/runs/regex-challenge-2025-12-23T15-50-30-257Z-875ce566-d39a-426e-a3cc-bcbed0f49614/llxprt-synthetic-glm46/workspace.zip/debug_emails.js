const validSamples = [
  'name+tag@example.co.uk',
  'user.name@example.travel',
  'a_b-c.d@example.io'
];
const invalidSamples = [
  'user..dot@example.com',
  'user.@example.com',
  'user@example_domain.com',
  'user@example.com\nmalicious'
];

console.log('Current validator results:');
const currentIsValidEmail = (email) => {
  if (!email || typeof email !== 'string') return false;
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  if (email.includes('..')) return false;
  
  if (email.startsWith('.') || email.endsWith('.')) return false;
  
  const domainParts = email.split('@')[1]?.split('.') || [];
  if (domainParts.some(part => part.includes('_'))) return false;
  
  return emailRegex.test(email);
};

validSamples.forEach(sample => {
  console.log(`Valid '${sample}': ${currentIsValidEmail(sample)}`);
});
console.log('---');
invalidSamples.forEach(sample => {
  console.log(`Invalid '${sample}': ${currentIsValidEmail(sample)}`);
});