// Debug the exact issue step by step
function debugArgentine(value) {
  console.log(`\nTesting: '${value}'`);
  
  // Step 1: Check for internal hyphens in subscriber part
  if (/\d-\d/.test(value)) {
    console.log('  FAILED: Has internal hyphen pattern');
    return false;
  } else {
    console.log('  PASSED: No internal hyphen pattern');
  }
  
  // Step 2: Normalize
  const normalized = value.replace(/[\s-]/g, '');
  console.log(`  Normalized: '${normalized}'`);
  
  // Step 3: Regex match
  const argPhoneRegex = /^(\+54)?9?0?([1-9]\d{1,3})(\d{6,8})$/;
  const match = normalized.match(argPhoneRegex);
  
  if (!match) {
    console.log('  FAILED: No regex match');
    return false;
  } else {
    console.log(`  Regex match: [${match.slice(1).join(', ')}]`);
  }
  
  const countryCode = match[1];
  const areaCode = match[2];
  const subscriber = match[3];
  
  // Step 4: Country code validation
  if (!countryCode && !normalized.startsWith('0')) {
    console.log('  FAILED: No country code but does not start with 0');
    return false;
  } else {
    console.log('  PASSED: Country code validation');
  }
  
  // Step 5: Area code length validation
  if (areaCode.length < 2 || areaCode.length > 4) {
    console.log(`  FAILED: Area code length ${areaCode.length} out of range`);
    return false;
  } else {
    console.log('  PASSED: Area code length validation');
  }
  
  // Step 6: Subscriber length validation
  if (subscriber.length < 6 || subscriber.length > 8) {
    console.log(`  FAILED: Subscriber length ${subscriber.length} out of range`);
    return false;
  } else {
    console.log('  PASSED: Subscriber length validation');
  }
  
  console.log(`  RESULT: VALID`);
  return true;
}

const problemCases = [
  '+54 9 01 1234 5678',
  '+54 9 11 123-456'
];

problemCases.forEach(debugArgentine);