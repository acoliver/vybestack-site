const valid = [
  '+1 (212) 555-7890',
  '212-555-7890',
  '(415)555-0199',
  '4155550199'
];

console.log('Testing valid phone numbers...');

function isValidUSPhone(value, options) {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // US phone numbers should have exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Exchange code (middle 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) return false;
  
  // Additional format validation - reject numbers with invalid area codes early
  if (/^((\+1\s*)?0|0\d)/.test(value)) return false;
  
  // Verify all characters are valid (digits, parentheses, hyphens, spaces)
  if (!/^[\d\-\s\(\)]+$/.test(value)) return false;
  
  // Check if the format matches one of the accepted patterns
  const patterns = [
    /^\+1\s*\(\d{3}\)\s*\d{3}-\d{4}$/, // (212) 555-7890 with +1
    /^\(\d{3}\)\s*\d{3}-\d{4}$/, // (212) 555-7890
    /^\+1\s*\d{3}-\d{3}-\d{4}$/, // 212-555-7890 with +1
    /^\d{3}-\d{3}-\d{4}$/, // 212-555-7890
    /^\+1\s*\d{10}$/, // 2125557890 with +1
    /^\d{10}$/ // 2125557890
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

valid.forEach(sample => {
  console.log(`Valid '${sample}': ${isValidUSPhone(sample)}`);
  if (!isValidUSPhone(sample)) {
    console.log(`  Why it fails:`);
    const digitsOnly = sample.replace(/\D/g, '');
    console.log(`    Digits only: ${digitsOnly}`);
    
    let phoneNumber = digitsOnly;
    if (phoneNumber.startsWith('1')) {
      phoneNumber = phoneNumber.substring(1);
    }
    console.log(`    After removing country code: ${phoneNumber}`);
    
    const areaCode = phoneNumber.substring(0, 3);
    const exchangeCode = phoneNumber.substring(3, 6);
    console.log(`    Area code: ${areaCode} (starts with 0/1: ${areaCode.startsWith('0') || areaCode.startsWith('1')})`);
    console.log(`    Exchange code: ${exchangeCode} (starts with 0/1: ${exchangeCode.startsWith('0') || exchangeCode.startsWith('1')})`);
    
    const patterns = [
      /^\+1\s*\(\d{3}\)\s*\d{3}-\d{4}$/,
      /^\(\d{3}\)\s*\d{3}-\d{4}$/,
      /^\+1\s*\d{3}-\d{3}-\d{4}$/,
      /^\d{3}-\d{3}-\d{4}$/,
      /^\+1\s*\d{10}$/,
      /^\d{10}$/
    ];
    
    patterns.forEach((pattern, i) => {
      console.log(`    Pattern ${i}: ${pattern.test(sample)}`);
    });
  }
});