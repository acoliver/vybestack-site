const valid = [
  '+1 (212) 555-7890',
  '212-555-7890',
  '(415)555-0199',
  '4155550199'
];
const invalid = [
  '012-555-7890',
  '212-55-7890',
  '555-012-3456',
  '1 (800) FLOWERS'
];

console.log('Testing US phone numbers...');

// Import our current validator
const fs = require('fs');
const validatorCode = fs.readFileSync('./src/validators.ts', 'utf8');

// Extract the function and test it
eval(`
${validatorCode.replace(/export/g, '')}

valid.forEach(sample => {
  console.log(\`Valid '\${sample}': \${isValidUSPhone(sample)}\`);
});
console.log('---');
invalid.forEach(sample => {
  console.log(\`Invalid '\${sample}': \${isValidUSPhone(sample)}\`);
});
`);