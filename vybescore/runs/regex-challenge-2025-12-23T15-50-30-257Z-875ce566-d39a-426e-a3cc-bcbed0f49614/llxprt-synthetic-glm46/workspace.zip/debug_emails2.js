console.log('Testing our updated validator...');
import { isValidEmail } from './src/validators.js';

const invalidEmail = 'user.@example.com';
console.log(`Testing '${invalidEmail}': ${isValidEmail(invalidEmail)}`);

// Let's debug the specific case
const email = 'user.@example.com';
console.log(`Email: ${email}`);
console.log(`Contains trailing dot in local part: ${email.split('@')[0].endsWith('.')}`);
console.log(`Basic regex test: ${/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/.test(email)}`);