// Check which invalid cases are still passing by testing one by one
const invalid = [
  '+54 123 456',
  '1234 567890', 
  '+54 9 01 1234 5678',
  '+54 9 11 123-456'
];

function isValidArgentinePhone(value) {
  if (!value || typeof value !== 'string') return false;
  
  console.log(`Testing: '${value}'`);
  
  // Check for hyphens within components (disallowed)
  if (/\d-\d/.test(value)) {
    console.log('  -> FAILED: Contains digit-digit pattern');
    return false;
  }
  
  // Allow single spaces or hyphens as separators, but ignore them for validation
  const normalized = value.replace(/[\s-]/g, '');
  console.log(`  -> Normalized: '${normalized}'`);
  
  // Argentine phone regex pattern
  const argPhoneRegex = /^(\+54)?9?0?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = normalized.match(argPhoneRegex);
  if (!match) {
    console.log('  -> FAILED: No regex match');
    return false;
  }
  console.log(`  -> Regex matches: [${match.slice(1).join(', ')}]`);
  
  const countryCode = match[1];
  const areaCode = match[2];
  const subscriber = match[3];
  
  // If no country code, must start with trunk prefix 0
  if (!countryCode && ! normalized.startsWith('0')) {
    console.log('  -> FAILED: No country code but no leading 0');
    return false;
  }
  
  // Area code must be 2-4 digits with leading digit NOT 0
  if (areaCode.length < 2 || areaCode.length > 4) {
    console.log(`  -> FAILED: Area code length ${areaCode.length} out of range`);
    return false;
  }
  if (areaCode.startsWith('0')) {
    console.log(`  -> FAILED: Area code starts with 0`);
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    console.log(`  -> FAILED: Subscriber length ${subscriber.length} out of range`);
    return false;
  }
  
  console.log('  -> PASSED: All checks passed');
  return true;
}

invalid.forEach(isValidArgentinePhone);