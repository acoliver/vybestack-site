import { defineConfig } from 'vitest/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';

const gradingDir = path.dirname(fileURLToPath(import.meta.url));
const preferredWorkspace = path.resolve(gradingDir, 'workspace');
const fallbackWorkspace = path.resolve(gradingDir, '../../problems/regex-challenge/workspace');
const workspaceRoot = fs.existsSync(preferredWorkspace) ? preferredWorkspace : fallbackWorkspace;

export default defineConfig({
  test: {
    include: ['tests/hidden/**/*.spec.ts'],
    environment: 'node',
    globals: true
  },
  resolve: {
    alias: {
      '@workspace': path.join('.', 'src'),
      '@workspace-tests': path.join('.', 'tests')
    }
  }
});
