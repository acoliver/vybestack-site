const valid = [
  '+54 9 11 1234 5678',
  '011 1234 5678',
  '+54 341 123 4567',
  '0341 4234567'
];
const invalid = [
  '+54 123 456',
  '1234 567890',
  '+54 9 01 1234 5678',
  '+54 9 11 123-456'
];

console.log('Testing Argentine phone numbers...');

function isValidArgentinePhone(value) {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex pattern
  // Format: [+54][9][0]AreaCode[Subscriber]
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  const argPhoneRegex = /^(\+54)?9?0?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = normalized.match(argPhoneRegex);
  if (!match) return false;
  
  const countryCode = match[1]; // +54 or undefined
  const areaCode = match[2];
  const subscriber = match[3];
  
  // If no country code, must start with trunk prefix 0
  if (!countryCode && !normalized.startsWith('0')) return false;
  
  // Area code must be 2-4 digits with leading 1-9
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  return true;
}

valid.forEach(sample => {
  console.log(`Valid '${sample}': ${isValidArgentinePhone(sample)}`);
});
console.log('---');
invalid.forEach(sample => {
  console.log(`Invalid '${sample}': ${isValidArgentinePhone(sample)}`);
});