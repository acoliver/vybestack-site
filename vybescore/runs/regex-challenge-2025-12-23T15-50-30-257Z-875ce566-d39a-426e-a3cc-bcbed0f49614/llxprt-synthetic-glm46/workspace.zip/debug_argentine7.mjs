// Let's try a simpler approach to fix the Argentine phone validation
// The issue is that our regex removes the trunk prefix 0, so we lose the original check

function isValidArgentinePhone(value) {
  if (!value || typeof value !== 'string') return false;
  
  // Check for hyphens in subscriber part (invalid)
  if (/\d-\d/.test(value)) return false;
  
  // Parse without removing all separators to preserve area code prefix info
  const cleanValue = value.replace(/[\s-]/g, '');
  console.log(`Testing: '${value}', cleaned: '${cleanValue}'`);
  
  // Extract parts for validation  
  let remaining = cleanValue;
  let hasCountryCode = false;
  
  // Remove country code if present
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.substring(3);
    console.log(`After removing +54: '${remaining}'`);
  }
  
  // Remove mobile indicator if present
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
    console.log(`After removing 9: '${remaining}'`);
  }
  
  // At this point, we should have something like 0111234567 or 11234567
  // Extract area code based on what comes after optional trunk prefix
  let areaCode, subscriber;
  
  if (remaining.startsWith('0')) {
    // Format: 0 AreaCode Subscriber
    console.log(`Has trunk prefix, parsing as 0 + area + subscriber`);
    const match = remaining.match(/^0([0-9]{1,3})([0-9]{6,8})$/);
    if (!match) return false;
    areaCode = match[1];
    subscriber = match[2];
  } else {
    // Format: AreaCode Subscriber (no trunk prefix, should have country code)
    console.log(`No trunk prefix, parsing as area + subscriber`);
    if (!hasCountryCode) return false; // Must have country code if no trunk prefix
    const match = remaining.match(/^([0-9]{2,4})([0-9]{6,8})$/);
    if (!match) return false;
    areaCode = match[1];
    subscriber = match[2];
  }
  
  console.log(`Area code: '${areaCode}', Subscriber: '${subscriber}'`);
  
  // Area code validation
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Subscriber length validation
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  console.log('PASSED');
  return true;
}

const invalid = [
  '+54 123 456',
  '1234 567890',
  '+54 9 01 1234 5678',
  '+54 9 11 123-456'
];

invalid.forEach(sample => {
  console.log(`\n--- Analyzing '${sample}' ---`);
  const result = isValidArgentinePhone(sample);
  console.log(`${sample}: ${result}`);
});