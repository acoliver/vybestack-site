// Debug with the logic from validators.ts but compiled manually

function isValidArgentinePhone(value) {
  if (!value || typeof value !== 'string') return false;
  
  // Check for hyphens within components (disallowed)
  // Only allow hyphens as separators between main components (area code, subscriber)
  if (/\d-\d/.test(value)) {
    console.log('  FAILED: Has digit-digits pattern');
    return false;
  }
  
  // Parse step by step without removing all separators to preserve area code prefix info
  const cleanValue = value.replace(/[\s-]/g, '');
  console.log(`  Cleaned: '${cleanValue}'`);
  
  // Extract parts for validation  
  let remaining = cleanValue;
  let hasCountryCode = false;
  
  // Remove country code if present
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.substring(3);
    console.log(`  After removing +54: '${remaining}'`);
  }
  
  // Remove mobile indicator if present
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
    console.log(`  After removing 9: '${remaining}'`);
  }
  
  // At this point, we should have something like 0111234567 or 11234567
  // Extract area code based on what comes after optional trunk prefix
  let areaCode, subscriber;
  
  if (remaining.startsWith('0')) {
    // Format: 0 AreaCode Subscriber
    const match = remaining.match(/^0([0-9]{1,3})([0-9]{6,8})$/);
    if (!match) {
      console.log('  FAILED: Could not parse with trunk prefix');
      return false;
    }
    areaCode = match[1];
    subscriber = match[2];
    console.log(`  Area code with trunk: '${areaCode}', subscriber: '${subscriber}'`);
  } else {
    // Format: AreaCode Subscriber (no trunk prefix, should have country code)
    if (!hasCountryCode) {
      console.log('  FAILED: No country code and no trunk prefix');
      return false; // Must have country code if no trunk prefix
    }
    const match = remaining.match(/^([0-9]{2,4})([0-9]{6,8})$/);
    if (!match) {
      console.log('  FAILED: Could not parse without trunk prefix');
      return false;
    }
    areaCode = match[1];
    subscriber = match[2];
    console.log(`  Area code without trunk: '${areaCode}', subscriber: '${subscriber}'`);
  }
  
  // Area code validation: 2-4 digits with leading digit NOT 0 or 1
  if (areaCode.length < 2 || areaCode.length > 4) {
    console.log(`  FAILED: Area code length ${areaCode.length} invalid`);
    return false;
  }
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    console.log(`  FAILED: Area code starts with ${areaCode[0]}`);
    return false;
  }
  
  // Subscriber length validation: 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    console.log(`  FAILED: Subscriber length ${subscriber.length} invalid`);
    return false;
  }
  
  console.log('  PASSED: All validations passed');
  return true;
}

const valid = [
  '+54 9 11 1234 5678',
  '011 1234 5678', 
  '+54 341 123 4567',
  '0341 4234567'
];

console.log('Testing valid samples:');
valid.forEach(sample => {
  console.log(`\n'${sample}':`);
  const result = isValidArgentinePhone(sample);
  console.log(`Result: ${result}`);
});