// Let me update the debug script to match the latest change

function isValidArgentinePhone(value) {
  if (!value || typeof value !== 'string') return false;
  
  if (/\d-\d/.test(value)) {
    console.log('  FAILED: Has digit-digits pattern');
    return false;
  }
  
  const cleanValue = value.replace(/[\s-]/g, '');
  console.log(`  Cleaned: '${cleanValue}'`);
  
  let remaining = cleanValue;
  let hasCountryCode = false;
  
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.substring(3);
    console.log(`  After removing +54: '${remaining}'`);
  }
  
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
    console.log(`  After removing 9: '${remaining}'`);
  }
  
  let areaCode, subscriber;
  
  if (remaining.startsWith('0')) {
    const match = remaining.match(/^0([0-9]{1,3})([0-9]{6,8})$/);
    if (!match) {
      console.log('  FAILED: Could not parse with trunk prefix');
      return false;
    }
    areaCode = match[1];
    subscriber = match[2];
    console.log(`  Area code with trunk: '${areaCode}', subscriber: '${subscriber}'`);
  } else {
    if (!hasCountryCode) {
      console.log('  FAILED: No country code and no trunk prefix');
      return false;
    }
    const match = remaining.match(/^([0-9]{2,4})([0-9]{6,8})$/);
    if (!match) {
      console.log('  FAILED: Could not parse without trunk prefix');
      return false;
    }
    areaCode = match[1];
    subscriber = match[2];
    console.log(`  Area code without trunk: '${areaCode}', subscriber: '${subscriber}'`);
  }
  
  if (areaCode.length < 2 || areaCode.length > 4) {
    console.log(`  FAILED: Area code length ${areaCode.length} invalid`);
    return false;
  }
  if (areaCode.startsWith('0')) {  // Updated to only check for 0
    console.log(`  FAILED: Area code starts with ${areaCode[0]}`);
    return false;
  }
  
  if (subscriber.length < 6 || subscriber.length > 8) {
    console.log(`  FAILED: Subscriber length ${subscriber.length} invalid`);
    return false;
  }
  
  console.log('  PASSED: All validations passed');
  return true;
}

const valid = [
  '+54 9 11 1234 5678',
  '011 1234 5678', 
  '+54 341 123 4567',
  '0341 4234567'
];

console.log('Testing valid samples after latest fix:');
valid.forEach(sample => {
  console.log(`\n'${sample}':`);
  const result = isValidArgentinePhone(sample);
  console.log(`Result: ${result}`);
});