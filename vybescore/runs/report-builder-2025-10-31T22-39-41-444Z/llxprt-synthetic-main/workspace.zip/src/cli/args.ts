import type { CliArgs } from '../types.js';

/**
 * Parse command line arguments
 */
export function parseArgs(processArgs: string[]): CliArgs {
  // Remove first two elements: node executable and script path
  const args = processArgs.slice(2);

  // Basic validation
  if (args.length < 3) {
    throw new Error(
      'Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
    );
  }

  const dataFile = args[0];
  
  // Check if format flag is provided
  if (args[1] !== '--format') {
    throw new Error('Missing format argument. Use --format <markdown|text>');
  }

  const format = args[2] as 'markdown' | 'text';
  
  // Validate format
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  // Parse optional arguments
  const result: CliArgs = {
    dataFile,
    format,
  };

  // Process remaining arguments
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a file path');
      }
      result.output = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  return result;
}