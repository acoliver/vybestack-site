import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { parseArgs } from './args.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

// Map of formatters
const formatters = {
  markdown: markdownFormatter,
  text: textFormatter,
};

/**
 * Validate and parse JSON data
 */
function parseReportData(jsonContent: string): ReportData {
  let data: unknown;

  try {
    data = JSON.parse(jsonContent);
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    throw new Error('Invalid JSON: Unknown error');
  }

  // Type guard for ReportData
  if (
    typeof data !== 'object' ||
    data === null ||
    !('title' in data) ||
    !('summary' in data) ||
    !('entries' in data)
  ) {
    throw new Error(
      'Invalid report data: Missing required fields (title, summary, or entries)'
    );
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid report data: title must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid report data: summary must be a string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }

  const entries = reportData.entries.map((entry, index) => {
    if (
      typeof entry !== 'object' ||
      entry === null ||
      !('label' in entry) ||
      !('amount' in entry)
    ) {
      throw new Error(
        `Invalid report data: Entry at index ${index} is missing required fields (label or amount)`
      );
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: Entry label at index ${index} must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: Entry amount at index ${index} must be a number`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries,
  };
}

/**
 * Main CLI function
 */
function main(): void {
  try {
    // Parse command line arguments
    const args = parseArgs(process.argv);

    // Read and parse JSON data
    let jsonData: string;
    try {
      jsonData = readFileSync(args.dataFile, 'utf8');
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(`Failed to read file '${args.dataFile}': ${error.message}`);
      }
      throw new Error(`Failed to read file '${args.dataFile}': Unknown error`);
    }

    const reportData = parseReportData(jsonData);

    // Get formatter
    const formatter = formatters[args.format];

    // Set render options
    const options: RenderOptions = {
      includeTotals: args.includeTotals ?? false,
    };

    // Render report
    const output = formatter.render(reportData, options);

    // Write output
    if (args.output) {
      try {
        writeFileSync(args.output, output, 'utf8');
        console.log(`Report saved to ${args.output}`);
      } catch (error) {
        if (error instanceof Error) {
          throw new Error(`Failed to write to file '${args.output}': ${error.message}`);
        }
        throw new Error(`Failed to write to file '${args.output}': Unknown error`);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Unknown error');
    }
    process.exit(1);
  }
}

// Run the main function if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}