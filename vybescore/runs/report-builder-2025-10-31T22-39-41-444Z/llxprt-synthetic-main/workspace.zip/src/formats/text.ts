import type { ReportData, RenderOptions, Formatter } from '../types.js';

/**
 * Calculate total from entries
 */
function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Format amount with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Render text report
 */
function render(data: ReportData, options: RenderOptions): string {
  const lines = [];

  // Add title
  lines.push(data.title);
  lines.push('');

  // Add summary
  lines.push(data.summary);
  lines.push('');

  // Add entries section
  lines.push('Entries:');
  data.entries.forEach(entry => {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  });

  // Add totals if requested
  if (options.includeTotals) {
    const total = calculateTotal(data);
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join('\n');
}

export const textFormatter: Formatter = {
  format: 'text',
  render,
};

// Export the render function and formatter
export { render };