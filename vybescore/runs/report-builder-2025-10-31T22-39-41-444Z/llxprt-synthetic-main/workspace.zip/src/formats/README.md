# Report Formatters

This directory contains formatter modules for rendering reports in different formats.

Each formatter module exports:

1. A `render` function that takes `ReportData` and `RenderOptions` and returns a string
2. A `Formatter` object with the format name and render function

## Available Formatters

### Markdown (`markdown.ts`)
Renders reports in Markdown format with:
- H1 title
- Summary text
- H2 entries header
- Bullet list with bold labels

### Text (`text.ts`)
Renders reports in plain text format with:
- Title as plain text
- Summary text
- "Entries:" header
- Bullet list with label: amount format

## Adding New Formatters

To add a new format:

1. Create a new TypeScript file in this directory
2. Implement a `render` function that follows the same interface
3. Export a `Formatter` object with the format name and render function
4. Import and register the formatter in the CLI module