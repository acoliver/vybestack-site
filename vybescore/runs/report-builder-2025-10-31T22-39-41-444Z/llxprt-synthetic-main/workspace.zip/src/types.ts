/**
 * TypeScript types for the report builder CLI
 */

// Entry in the report data
export interface Entry {
  label: string;
  amount: number;
}

// Report data structure from JSON input
export interface ReportData {
  title: string;
  summary: string;
  entries: Entry[];
}

// Options passed to formatters
export interface RenderOptions {
  includeTotals: boolean;
}

// Common formatter interface
export interface Formatter {
  format: string;
  render(data: ReportData, options: RenderOptions): string;
}

// CLI arguments parsed from command line
export interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  output?: string;
  includeTotals?: boolean;
}