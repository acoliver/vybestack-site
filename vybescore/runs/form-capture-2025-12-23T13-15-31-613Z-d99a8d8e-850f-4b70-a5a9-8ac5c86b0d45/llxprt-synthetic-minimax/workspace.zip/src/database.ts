import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'fs';
import path from 'path';

interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseService {
  private db: Database | null = null;
  private sql: SqlJsStatic | null = null;
  private dbPath: string;

  constructor(dbPath: string = 'data/submissions.sqlite') {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    this.sql = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const dbBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sql!.Database(dbBuffer);
    } else {
      this.db = new this.sql!.Database();
      await this.createSchema();
      await this.save();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schema = fs.readFileSync('db/schema.sql', 'utf8');
    this.db.exec(schema);
  }

  async insertSubmission(submission: Submission): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    await this.save();
  }

  private async save(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}