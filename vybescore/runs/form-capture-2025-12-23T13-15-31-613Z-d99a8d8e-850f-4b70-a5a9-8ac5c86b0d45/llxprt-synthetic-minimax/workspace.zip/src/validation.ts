export interface ValidationErrors {
  [key: string]: string;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city.trim()) {
    errors.city = 'City is required';
  }

  if (!data.stateProvinceRegion.trim()) {
    errors.stateProvinceRegion = 'State/Province/Region is required';
  }

  if (!data.postalCode.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }

  if (!data.country.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email.trim()) {
    errors.email = 'Email is required';
  } else if (!isValidEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!isValidPhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  return errors;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[0-9\s()\-.]+$/;
  return phoneRegex.test(phone) && /[0-9]/.test(phone);
}
