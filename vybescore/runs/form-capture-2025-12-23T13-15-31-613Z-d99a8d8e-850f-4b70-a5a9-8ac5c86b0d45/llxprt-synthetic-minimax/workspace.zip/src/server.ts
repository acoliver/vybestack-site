import express, { Request, Response } from 'express';
import path from 'path';
import { DatabaseService } from './database';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.replace(/\s/g, '').length >= 3;
}

function validateFormData(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};
  if (!data.firstName.trim()) errors.firstName = 'First name is required';
  if (!data.lastName.trim()) errors.lastName = 'Last name is required';
  if (!data.streetAddress.trim()) errors.streetAddress = 'Street address is required';
  if (!data.city.trim()) errors.city = 'City is required';
  if (!data.stateProvinceRegion.trim()) errors.stateProvinceRegion = 'State/Province/Region is required';
  if (!data.postalCode.trim()) errors.postalCode = 'Postal code is required';
  else if (!validatePostalCode(data.postalCode)) errors.postalCode = 'Please enter a valid postal code';
  if (!data.country.trim()) errors.country = 'Country is required';
  if (!data.email.trim()) errors.email = 'Email is required';
  else if (!validateEmail(data.email)) errors.email = 'Please enter a valid email address';
  if (!data.phone.trim()) errors.phone = 'Phone number is required';
  else if (!validatePhone(data.phone)) errors.phone = 'Please enter a valid phone number';
  return errors;
}

const app = express();
const port = process.env.PORT || 3535;
const database = new DatabaseService();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: {}, formData: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvinceRegion: req.body.stateProvinceRegion || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);
  if (Object.keys(errors).length > 0) {
    res.status(400).render('form', { errors, formData });
    return;
  }

  try {
    await database.insertSubmission(formData);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    res.status(500).render('form', { errors: { general: 'An error occurred. Please try again.' }, formData });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

async function startServer(): Promise<ReturnType<typeof app.listen>> {
  try {
    await database.initialize();
    console.log('Database initialized successfully');

    const server = app.listen(port, () => {
      console.log(`Server is running on http://localhost:${port}`);
    });

    process.on('SIGTERM', async () => {
      console.log('SIGTERM received, shutting down gracefully');
      await database.close();
      server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    });

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

if (require.main === module) {
  startServer();
}