const http = require('http');

const BASE_URL = 'http://localhost:3535';

function makeRequest(path, method = 'GET', data = null) {
    return new Promise((resolve, reject) => {
        const url = new URL(path, BASE_URL);
        const options = {
            hostname: url.hostname,
            port: url.port,
            path: url.pathname,
            method: method,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            }
        };

        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', (chunk) => {
                body += chunk;
            });
            res.on('end', () => {
                resolve({
                    statusCode: res.statusCode,
                    headers: res.headers,
                    body: body
                });
            });
        });

        req.on('error', reject);

        if (data) {
            const params = new URLSearchParams(data);
            req.write(params.toString());
        }

        req.end();
    });
}

async function testRoutes() {
    console.log('Testing public routes...');
    
    try {
        // Test GET / (form page)
        console.log('\n1. Testing GET /');
        const formResponse = await makeRequest('/');
        
        if (formResponse.statusCode === 200 && formResponse.body.includes('Contact Us')) {
            console.log('[OK] GET / returns 200 and contains contact form');
        } else {
            console.log(' GET / failed:', formResponse.statusCode);
            console.log('Response preview:', formResponse.body.substring(0, 200));
        }

        // Test GET /thank-you
        console.log('\n2. Testing GET /thank-you');
        const thankYouResponse = await makeRequest('/thank-you');
        
        if (thankYouResponse.statusCode === 200 && thankYouResponse.body.includes('Thank You!')) {
            console.log('[OK] GET /thank-you returns 200 and contains thank you message');
        } else {
            console.log(' GET /thank-you failed:', thankYouResponse.statusCode);
            console.log('Response preview:', thankYouResponse.body.substring(0, 200));
        }

        // Test POST /submit with valid data
        console.log('\n3. Testing POST /submit with valid data');
        const validData = {
            firstName: 'John',
            lastName: 'Doe',
            streetAddress: '123 Main St',
            city: 'Anytown',
            stateProvinceRegion: 'State',
            postalZipCode: '12345',
            country: 'Country',
            email: 'john.doe@example.com',
            phone: '+1 (555) 123-4567'
        };
        
        const submitResponse = await makeRequest('/submit', 'POST', validData);
        
        if (submitResponse.statusCode === 302) {
            const location = submitResponse.headers.location;
            if (location === '/thank-you') {
                console.log('[OK] POST /submit redirects to /thank-you');
            } else {
                console.log(' POST /submit redirects to wrong location:', location);
            }
        } else {
            console.log(' POST /submit failed:', submitResponse.statusCode);
            console.log('Response preview:', submitResponse.body.substring(0, 300));
        }

        // Test POST /submit with invalid data
        console.log('\n4. Testing POST /submit with invalid data');
        const invalidData = {
            firstName: '',  // Empty required field
            lastName: 'Doe',
            email: 'invalid-email',  // Invalid email
            phone: ''  // Empty required field
        };
        
        const invalidResponse = await makeRequest('/submit', 'POST', invalidData);
        
        if (invalidResponse.statusCode === 400 && invalidResponse.body.includes('Contact Form - Please Fix Errors')) {
            console.log('[OK] POST /submit with invalid data returns 400 with error page');
        } else {
            console.log(' POST /submit with invalid data failed:', invalidResponse.statusCode);
            console.log('Response preview:', invalidResponse.body.substring(0, 300));
        }

        // Test 404 route
        console.log('\n5. Testing 404 route');
        const notFoundResponse = await makeRequest('/nonexistent');
        
        if (notFoundResponse.statusCode === 404) {
            console.log('[OK] GET /nonexistent returns 404');
        } else {
            console.log(' GET /nonexistent failed:', notFoundResponse.statusCode);
        }

        console.log('\n[OK] All public route tests completed!');
        
    } catch (error) {
        console.error(' Test failed with error:', error.message);
        console.log('Make sure the server is running on port 3535');
    }
}

// Wait a bit for server to be ready, then run tests
setTimeout(testRoutes, 2000);
