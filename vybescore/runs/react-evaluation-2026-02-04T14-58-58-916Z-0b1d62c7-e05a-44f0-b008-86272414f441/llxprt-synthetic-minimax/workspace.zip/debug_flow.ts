import { createInput, createComputed, createCallback } from './src/index.ts'

// Understanding the exact flow
console.log('=== Understanding the notification flow ===')

console.log('\n1. Creating input:')
const [input, setInput] = createInput(1)
console.log('  input() =', input())

console.log('\n2. Creating computed:')
const output = createComputed(() => {
  const computedValue = input() + 1
  console.log('    COMPUTED: input() + 1 =', input() + 1, '=', computedValue)
  return computedValue
})

console.log('\n3. Initial computed access:')
const initialOutput = output()
console.log('  Initial output =', initialOutput)

console.log('\n4. Creating callback and checking dependencies:')
let capturedValue = 0

const unsubscribe = createCallback(() => {
  console.log('    CALLBACK: Starting execution...')
  const val = output()
  console.log('    CALLBACK: output() =', val)
  capturedValue = val
  return val
})

console.log('\n5. Checking if callback captured the value:')
console.log('  capturedValue =', capturedValue)

console.log('\n6. Understanding the relationship...')
console.log('  The callback should have been registered as an observer of the computed')
console.log('  But we need to trace exactly how this registration works')

// Let's manually check what should happen
console.log('\n7. Manual verification:')
console.log('  When input changes from 1 to 3:')
console.log('    Expected: computed value changes from 2 to 4')
console.log('    Expected: callback should fire again with new value')
console.log('    Current callback captured value:', capturedValue)