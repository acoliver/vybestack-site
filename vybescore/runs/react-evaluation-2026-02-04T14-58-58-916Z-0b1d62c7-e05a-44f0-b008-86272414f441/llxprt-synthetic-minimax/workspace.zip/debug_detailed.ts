import { createInput, createComputed, createCallback } from './src/index.ts'

// More detailed debug to understand dependency tracking
console.log('=== Detailed dependency tracking ===')

// Test 1: Understanding the flow
console.log('\n--- Test 1: Basic callback dependency ---')
const [input, setInput] = createInput(1)
const output = createComputed(() => {
  console.log('  Computed: input() + 1 =', input() + 1)
  return input() + 1
})

console.log('Initial setup:')
console.log('  input() =', input())
console.log('  output() =', output())

let callbackFired = false
const callback = createCallback(() => {
  console.log('  Callback executing...')
  const val = output()
  console.log('  Callback: output() =', val)
  callbackFired = true
  return val
})

console.log('After callback creation:')
console.log('  Callback fired =', callbackFired)

// Force another access to see if it tracks dependencies properly
console.log('Accessing output again:')
console.log('  output() =', output())

console.log('Now changing input:')
setInput(3)
console.log('  input() =', input())
console.log('  output() =', output())
console.log('  Callback fired =', callbackFired)

// Test 2: Understanding computed notifications
console.log('\n--- Test 2: Computed notifications ---')
const [input2, setInput2] = createInput(1)
const output2 = createComputed(() => {
  console.log('    Computed: input2() + 1 =', input2() + 1)
  return input2() + 1
})

console.log('Accessing computed to establish dependency:')
const computedValue = output2()
console.log('  Computed value =', computedValue)

console.log('Creating callback on computed:')
const callback2 = createCallback(() => {
  console.log('    Callback2 executing...')
  const val = output2()
  console.log('    Callback2: output2() =', val)
  return val
})

console.log('Input before change:', input2())
setInput2(5)
console.log('Input after change:', input2())
console.log('Computed after change:', output2())