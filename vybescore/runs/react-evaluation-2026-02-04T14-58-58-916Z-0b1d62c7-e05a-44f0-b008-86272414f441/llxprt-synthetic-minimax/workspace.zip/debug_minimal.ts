import { createInput, createComputed, createCallback } from './src/index.ts'

// Minimal test to isolate the exact issue
console.log('=== Minimal test for callback re-execution ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => {
  console.log('  COMPUTED: input() + 1 =', input() + 1)
  return input() + 1
})

console.log('\n1. Initial setup:')
const initialOutput = output()
console.log('  Initial output =', initialOutput)

console.log('\n2. Creating callback:')
let callbackExecutionCount = 0
const unsubscribe = createCallback(() => {
  callbackExecutionCount++
  const val = output()
  console.log(`  CALLBACK #${callbackExecutionCount}: output() =`, val)
  return val
})

console.log('\n3. Before input change:')
console.log('  input() =', input())
console.log('  output() =', output())
console.log('  Callback execution count =', callbackExecutionCount)

console.log('\n4. Changing input to 3:')
setInput(3)

console.log('\n5. After input change:')
console.log('  input() =', input())
console.log('  output() =', output())
console.log('  Callback execution count =', callbackExecutionCount)

console.log('\n6. Expected: Callback should have executed again, count should be 2')
console.log('  Actual count:', callbackExecutionCount)