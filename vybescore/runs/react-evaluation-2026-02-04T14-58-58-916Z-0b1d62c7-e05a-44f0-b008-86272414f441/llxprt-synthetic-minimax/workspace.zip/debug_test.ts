import { createInput, createComputed, createCallback } from './src/index.ts'

// Debug first failing test
console.log('=== Test 1: compute cells fire callbacks ===')
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0
console.log('Initial value:', value)
console.log('Initial output:', output())

const unsubscribe = createCallback(() => {
  value = output()
  console.log('Callback fired, value:', value)
})

console.log('Input before change:', input())
setInput(3)
console.log('Input after change:', input())
console.log('Output after change:', output())
console.log('Value after change:', value)

// Debug second failing test  
console.log('\n=== Test 2: callbacks can be added and removed ===')
const [input2, setInput2] = createInput(11)
const output2 = createComputed(() => input2() + 1)

const values1: number[] = []
const unsubscribe1 = createCallback(() => {
  const val = output2()
  values1.push(val)
  console.log('Callback1 fired, value:', val)
})

const values2: number[] = []
createCallback(() => {
  const val = output2()
  values2.push(val)
  console.log('Callback2 fired, value:', val)
})

console.log('Values1 length:', values1.length)
console.log('Values2 length:', values2.length)

setInput2(31)
console.log('After first change - Values1 length:', values1.length)
console.log('After first change - Values2 length:', values2.length)

unsubscribe1()
setInput2(41)
console.log('After second change - Values1 length:', values1.length)
console.log('After second change - Values2 length:', values2.length)