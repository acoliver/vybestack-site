import { createInput, createComputed, createCallback } from './src/index.ts'

// Let's trace the exact dependency registration
console.log('=== Tracing dependency registration ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => {
  const result = input() + 1
  console.log('  COMPUTED: input() + 1 =', input(), '+ 1 =', result)
  return result
})

console.log('\n1. Initial output access:')
const val1 = output()
console.log('  Computed value:', val1)

console.log('\n2. Understanding what happens during callback creation...')

// Let's manually trace what createCallback does
let callbackCount = 0
console.log('\n3. Creating callback manually to understand the flow:')

// This simulates what createCallback does internally
import { getActiveObserver, setActiveObserver } from './src/types/reactive.js'

// Let's manually check the flow
console.log('  Current active observer before callback:', getActiveObserver())

const callback = () => {
  callbackCount++
  const val = output()
  console.log(`  MANUAL CALLBACK #${callbackCount}: output() =`, val)
  return val
}

// Execute callback to establish dependencies
console.log('\n4. Executing callback to establish dependencies:')
callback()

console.log('\n5. Checking dependencies after callback execution...')

// Now change input and see what happens
console.log('\n6. Changing input:')
setInput(3)
console.log('  Input changed to:', input())

console.log('\n7. Manually triggering callback to see if it works:')
callback()

console.log('\n8. Final callback count:', callbackCount)