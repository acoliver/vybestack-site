import { createInput, createComputed, createCallback } from './src/index.ts'

// Let's understand exactly what happens during callback execution
console.log('=== Understanding the exact problem ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => {
  const result = input() + 1
  console.log('  COMPUTED: input() + 1 =', input(), '+ 1 =', result)
  return result
})

console.log('\n1. Initial computed access:')
const val1 = output()
console.log('  output() =', val1)

console.log('\n2. Creating callback:')
let callbackCount = 0
const unsubscribe = createCallback(() => {
  callbackCount++
  const val = output()
  console.log(`  CALLBACK #${callbackCount}: output() =`, val)
})

console.log('\n3. After callback creation, checking what was tracked...')

// Now let's manually trigger what should happen when input changes
console.log('\n4. Simulating what should happen when input changes:')
console.log('  Current input value:', input())
console.log('  Setting input to 3...')
setInput(3)
console.log('  New input value:', input())

// Manually access output to see if the callback would have been triggered
console.log('\n5. Manual output access after input change:')
const val2 = output()
console.log('  output() =', val2)

console.log('\n6. Callback execution count:', callbackCount)
console.log('  Expected: 2 (callback should have fired again)')
console.log('  Actual:', callbackCount)