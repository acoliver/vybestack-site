import { createInput, createComputed, createCallback } from './src/index.ts'

// Direct test to understand the exact problem
console.log('=== Understanding the notification chain ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => {
  console.log('  COMPUTED: input() + 1 =', input() + 1)
  return input() + 1
})

console.log('\n1. Initial setup:')
const initialValue = output()
console.log('  Initial computed value =', initialValue)

console.log('\n2. Creating callback:')
let callbackCount = 0
let capturedValue = 0

const unsubscribe = createCallback(() => {
  callbackCount++
  capturedValue = output()
  console.log(`  CALLBACK #${callbackCount}: captured value =`, capturedValue)
})

console.log('\n3. Before input change:')
console.log('  input() =', input())
console.log('  output() =', output())
console.log('  callbackCount =', callbackCount)
console.log('  capturedValue =', capturedValue)

console.log('\n4. Changing input to 3:')
setInput(3)

console.log('\n5. After input change:')
console.log('  input() =', input())
console.log('  output() =', output())
console.log('  callbackCount =', callbackCount)
console.log('  capturedValue =', capturedValue)

console.log('\n=== Analysis ===')
console.log('Expected: callbackCount = 2, capturedValue = 4')
console.log('Actual: callbackCount =', callbackCount + ', capturedValue =', capturedValue)