import { createInput, createComputed, createCallback } from './src/index.ts'

// Even more detailed debugging to understand notification chain
console.log('=== Understanding notification chain ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => {
  console.log('COMPUTED EXECUTING: input() + 1 =', input() + 1)
  return input() + 1
})

console.log('\n1. Initial access to computed:')
console.log('  output() =', output())

console.log('\n2. Creating callback:')
const unsubscribe = createCallback(() => {
  console.log('  CALLBACK EXECUTING...')
  const val = output()
  console.log('  CALLBACK: output() =', val)
  return val
})

console.log('\n3. Initial state:')
console.log('  input() =', input())
console.log('  output() =', output())

console.log('\n4. Changing input to 3:')
setInput(3)

console.log('\n5. After input change:')
console.log('  input() =', input())
console.log('  output() =', output())

console.log('\n6. Manual callback execution to see if it tracks new value:')
console.log('  Calling callback manually...')

// Let's manually check what the callback should see
const manualValue = output()
console.log('  Manual value check =', manualValue)