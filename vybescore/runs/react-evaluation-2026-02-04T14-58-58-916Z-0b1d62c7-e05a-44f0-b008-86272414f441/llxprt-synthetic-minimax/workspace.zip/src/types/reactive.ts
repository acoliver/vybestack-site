/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string
}

// Observer interface for reactive computation
export interface Observer<T> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  subscribers?: Set<any>
  dependencies?: Set<any>
}

// Subject interface for reactive sources  
export interface Subject<T> {
  name?: string
  value: T
  observers?: Set<any>
  equalFn?: EqualFn<T>
}

let activeObserver: any = undefined

export function getActiveObserver<T>(): Observer<T> | undefined {
  return activeObserver
}

export function setActiveObserver<T>(observer: Observer<T> | undefined): Observer<T> | undefined {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function trackDependency(subject: any, observer: any): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
  
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(subject)
}

export function notifyDependents(subject: Subject<any>): void {
  if (subject.observers) {
    const observerArray = Array.from(subject.observers)
    for (const observer of observerArray) {
      updateObserver(observer as Observer<any>)
    }
  }
}

export function notifySubscribers(observer: Observer<any>): void {
  if (observer.subscribers) {
    const subscriberArray = Array.from(observer.subscribers)
    for (const subscriber of subscriberArray) {
      updateObserver(subscriber as Observer<any>)
    }
  }
}

export function addSubscriber(observer: any, subscriber: any): void {
  if (!observer.subscribers) {
    observer.subscribers = new Set()
  }
  observer.subscribers.add(subscriber)
}

export function removeDependency(subject: any, observer: any): void {
  subject.observers?.delete(observer)
  observer.dependencies?.delete(subject)
}

// Computed interface for reactive derived values
export interface Computed<T> extends Observer<T> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  subscribers?: Set<any>
  dependencies?: Set<any>
}

export function registerComputedDependency(computed: any, observer: any): void {
  if (!computed.subscribers) {
    computed.subscribers = new Set()
  }
  computed.subscribers.add(observer)
}
