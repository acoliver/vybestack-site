/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  getActiveObserver,
  setActiveObserver,
  updateObserver,
  trackDependency,
  Computed,
  EqualFn,
  notifySubscribers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Computed<T> = {
    name: options?.name,
    value,
    updateFn,
    subscribers: new Set(),
  }

  const computed: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      trackDependency(o, activeObserver)
      if (!o.subscribers) {
        o.subscribers = new Set()
      }
      o.subscribers.add(activeObserver)
    }
    
    const previousObserver = setActiveObserver(o)
    try {
      const newValue = o.updateFn(o.value)
      const oldValue = o.value
      o.value = newValue
      
      // Notify subscribers when value changes
      if (oldValue !== newValue && o.subscribers) {
        notifySubscribers(o)
      }
    } finally {
      setActiveObserver(previousObserver)
    }
    return o.value!
  }

  return computed
}
