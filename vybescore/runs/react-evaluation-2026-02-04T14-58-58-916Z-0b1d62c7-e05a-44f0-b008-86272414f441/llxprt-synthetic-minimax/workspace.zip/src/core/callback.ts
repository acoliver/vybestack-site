/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  setActiveObserver,
  updateObserver,
  trackDependency,
  notifyDependents
} from '../types/reactive.js'

export function createCallback<T>(updateFn: (value?: T) => T, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set(),
    subscribers: new Set(),
  }
  
  let disposed = false
  
  const executeCallback = () => {
    const previousObserver = setActiveObserver(observer)
    try {
      // Execute the update function to establish dependencies
      observer.value = updateFn(observer.value)
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  // Execute callback initially to establish dependencies
  executeCallback()
  
  // Register callback as observer with all its dependencies
  if (observer.dependencies) {
    for (const subject of observer.dependencies) {
      if (!subject.observers) {
        subject.observers = new Set()
      }
      subject.observers.add(observer)
      
      // Also register as subscriber if this is a computed value
      if (subject.subscribers) {
        subject.subscribers.add(observer)
      }
    }
  }
  
  // Execute callback initially to establish dependencies
  executeCallback()
  
  // Ensure callback is registered with all its dependencies
  if (observer.dependencies) {
    for (const subject of observer.dependencies) {
      if (!subject.observers) {
        subject.observers = new Set()
      }
      subject.observers.add(observer)
    }
  }
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    if (observer.dependencies) {
      for (const subject of observer.dependencies) {
        subject.observers?.delete(observer)
      }
      observer.dependencies.clear()
    }
    observer.subscribers?.clear()
  }
  
  return unsubscribe
}
