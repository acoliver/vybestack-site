import { createInput, createComputed, createCallback } from './src/index.ts'

// Final test to verify our understanding
console.log('=== Final verification test ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => {
  const result = input() + 1
  console.log('  COMPUTED: input() + 1 =', input(), '+ 1 =', result)
  return result
})

console.log('\n1. Initial output access:')
const val1 = output()
console.log('  Initial computed value:', val1)

console.log('\n2. Creating callback:')
let capturedValues: number[] = []

const unsubscribe = createCallback(() => {
  const val = output()
  console.log('  CALLBACK: captured value =', val)
  capturedValues.push(val)
})

console.log('\n3. Before input change:')
console.log('  Captured values:', capturedValues)

console.log('\n4. Changing input to 3:')
setInput(3)

console.log('\n5. After input change:')
console.log('  Computed value:', output())
console.log('  Captured values:', capturedValues)

console.log('\n=== Final Analysis ===')
console.log('Expected: Callback should have fired again, capturedValues = [2, 4]')
console.log('Actual: capturedValues =', capturedValues)