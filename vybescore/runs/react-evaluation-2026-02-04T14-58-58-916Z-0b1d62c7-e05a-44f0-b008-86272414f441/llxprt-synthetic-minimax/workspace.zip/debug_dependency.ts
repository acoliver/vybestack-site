import { createInput, createComputed, createCallback } from './src/index.ts'

// Deep dive into the dependency tracking
console.log('=== Deep dependency tracking analysis ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => {
  console.log('  COMPUTED EXECUTING: input() + 1 =', input() + 1)
  return input() + 1
})

console.log('\n1. Initial computed access:')
const computed1 = output()
console.log('  Computed value =', computed1)

console.log('\n2. Creating callback to track what happens:')
let executionLog: string[] = []
const unsubscribe = createCallback(() => {
  const step = executionLog.length + 1
  console.log(`  CALLBACK EXECUTION #${step} START`)
  const val = output()
  console.log(`  CALLBACK EXECUTION #${step}: output() = ${val}`)
  executionLog.push(`Step ${step}: output = ${val}`)
  console.log(`  CALLBACK EXECUTION #${step} END`)
})

console.log('\n3. Checking computed again:')
const computed2 = output()
console.log('  Computed value =', computed2)

console.log('\n4. Now changing the input:')
console.log('  Current input =', input())
setInput(5)
console.log('  New input =', input())

console.log('\n5. Checking computed after change:')
const computed3 = output()
console.log('  Computed value =', computed3)

console.log('\n6. Execution log:')
executionLog.forEach((log, i) => {
  console.log(`  ${log}`)
})

console.log('\n=== Key Questions ===')
console.log('1. How many times should the callback have executed?')
console.log('2. Does the callback see the new computed value?')
console.log('3. Is the notification chain working properly?')