import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Get the directory name of the current module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set EJS as template engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db: Database;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

const initDatabase = async () => {
  const SQL = await initSqlJs();
  let dbData: Uint8Array | null = null;
  
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    dbData = new Uint8Array(fileBuffer);
  }
  
  db = new SQL.Database(dbData);
  
  // Create table if not exists
  const schemaSql = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
  db.run(schemaSql);
};

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  // Updated to not escape parentheses - ESLint fix
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  // Allow alphanumeric postal codes with spaces and dashes
  // Updated to not escape dash when inside character class - ESLint fix
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
};

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const validateForm = (body: FormData): string[] => {
  const errors: string[] = [];
  
  // Check required fields
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ] as const;
  
  for (const field of requiredFields) {
    // Convert camelCase to spaced words for error messages
    const fieldName = field.replace(/([A-Z])/g, ' $1');
    if (!body[field] || body[field].trim() === '') {
      errors.push(`${fieldName} is required`);
    }
  }
  
  // Validate email separately
  if (body.email && !validateEmail(body.email)) {
    errors.push('Email must be valid');
  }
  
  // Validate phone separately
  if (body.phone && !validatePhone(body.phone)) {
    errors.push('Phone number format is invalid');
  }
  
  // Validate postal code separately
  if (body.postalCode && !validatePostalCode(body.postalCode)) {
    errors.push('Postal code format is invalid');
  }
  
  return errors;
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  // Add error messages to response for debugging
  console.log('Form body:', req.body);
  
  const errors = validateForm(req.body as FormData);
  
  console.log('Validation errors:', errors);
  
  if (errors.length > 0) {
    return res.status(400).render('form', { 
      errors, 
      values: req.body 
    });
  }
  
  // Insert into database
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    req.body.firstName,
    req.body.lastName,
    req.body.streetAddress,
    req.body.city,
    req.body.stateProvince,
    req.body.postalCode,
    req.body.country,
    req.body.email,
    req.body.phone
  ]);
  
  stmt.free();
  
  // Write database back to file
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
  
  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the last submission to show on thank you page
  const result = db.exec("SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1");
  const firstName = result.length > 0 ? result[0].values[0][0] as string : 'Friend';
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown
let server: ReturnType<typeof app.listen> | null = null;
const startServer = async () => {
  await initDatabase();
  server = app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
};

const gracefulShutdown = () => {
  console.log('Shutting down gracefully...');
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  
  if (db) {
    // Write database back to file before closing
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
    db.close();
    console.log('Database closed');
  }
  
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Initialize the database immediately for tests
// The tests can import the app and it will already have db initialized
initDatabase().catch(err => {
  console.error('Failed to initialize the database:', err);
});

// Export app for testing
export default app;

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(err => {
    console.error('Failed to initialize the database:', err);
    process.exit(1);
  });
}