import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

let server: ReturnType<typeof express.listen> | null = null;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import the server implementation
  const module = await import('../../src/server.js');
  app = module.default;
  server = app.listen(3000);
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = load(response.text);
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'john.doe@example.com',
        phone: '+1 555 123 4567'
      })
      .expect(302);
      
    expect(response.header.location).toBe('/thank-you');
  });
  
  it('shows error for invalid email', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1 555 123 4567'
      })
      .expect(400);
      
    const $ = load(response.text);
    expect($('.error-list')).toHaveLength(1);
    expect($('.error-list li').text()).toContain('Email must be valid');
  });
  
  it('accepts international postal codes', async () => {
    // Clean up db first
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Maria',
        lastName: 'Gonzalez',
        streetAddress: 'Av. Corrientes 123',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'maria.gonzalez@example.com',
        phone: '+54 9 11 1234-5678'
      })
      .expect(302);
      
    expect(response.header.location).toBe('/thank-you');
  });
  
  it('thank you page shows first name', async () => {
    // Clean up db first
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Submit form first
    await request(app)
      .post('/submit')
      .send({
        firstName: 'Alice',
        lastName: 'Smith',
        streetAddress: '456 Oak St',
        city: 'Somewhere',
        stateProvince: 'State',
        postalCode: 'A1B 2C3',
        country: 'Canada',
        email: 'alice.smith@example.com',
        phone: '+1 555 987 6543'
      })
      .expect(302);
      
    // Visit thank you page
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    
    const $ = load(response.text);
    expect($('h1').text()).toContain('Alice');
    expect($('p').text()).toContain('somewhere safe');
  });
});