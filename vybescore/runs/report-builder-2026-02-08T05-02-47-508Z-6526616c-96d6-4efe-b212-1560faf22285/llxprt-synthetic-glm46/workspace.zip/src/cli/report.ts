#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(): CliOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    showUsage();
    process.exit(1);
  }
  
  const options: CliOptions = {
    format: '',
    output: undefined,
    includeTotals: false,
  };
  
  // Find the data file first (should not start with --)
  let dataFile: string | undefined;
  let i = 0;
  for (; i < args.length; i++) {
    if (!args[i].startsWith('--')) {
      dataFile = args[i];
      break;
    }
  }
  
  if (!dataFile) {
    console.error('Error: Data file path required');
    showUsage();
    process.exit(1);
  }
  
  // Parse the remaining arguments
  for (let j = i + 1; j < args.length; j++) {
    const arg = args[j];
    
    if (arg === '--format') {
      j++;
      if (j >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      options.format = args[j];
    } else if (arg === '--output') {
      j++;
      if (j >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.output = args[j];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown option: ${arg}`);
      showUsage();
      process.exit(1);
    }
  }
  
  return options;
}

function showUsage(): void {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('Supported formats: markdown, text');
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string' || obj.title === '') {
    throw new Error('Invalid JSON: title is required and must be a string');
  }
  
  if (typeof obj.summary !== 'string' || obj.summary === '') {
    throw new Error('Invalid JSON: summary is required and must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: entries is required and must be an array');
  }
  
  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string' || entryObj.label === '') {
      throw new Error(`Invalid JSON: entry at index ${i} must have a non-empty label`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} must have a numeric amount`);
    }
    
    if (entryObj.amount < 0) {
      throw new Error(`Invalid JSON: entry at index ${i} must have a non-negative amount`);
    }
  }
  
  return obj as unknown as ReportData;
}

function main(): void {
  try {
    const options = parseArgs();
    
    // Validate format
    if (options.format !== 'markdown' && options.format !== 'text') {
      console.error('Error: Unsupported format');
      process.exit(1);
    }
    
    // Get data file from args
    const args = process.argv.slice(2);
    let dataFile: string | undefined;
    for (const arg of args) {
      if (!arg.startsWith('--')) {
        dataFile = arg;
        break;
      }
    }
    
    if (!dataFile) {
      console.error('Error: Data file path required');
      showUsage();
      process.exit(1);
    }
    
    // Read and parse JSON data
    let data: unknown;
    try {
      const fileContent = readFileSync(dataFile, 'utf8');
      data = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file '${dataFile}': ${error.message}`);
      } else {
        console.error(`Error: Could not read file '${dataFile}': ${error instanceof Error ? error.message : String(error)}`);
      }
      process.exit(1);
    }
    
    // Validate data
    const reportData = validateReportData(data);
    
    // Render the report
    const renderOptions = {
      includeTotals: options.includeTotals,
    };
    
    let output: string;
    if (options.format === 'markdown') {
      output = renderMarkdown(reportData, renderOptions);
    } else {
      output = renderText(reportData, renderOptions);
    }
    
    // Write output
    if (options.output) {
      writeFileSync(options.output, output, 'utf8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
