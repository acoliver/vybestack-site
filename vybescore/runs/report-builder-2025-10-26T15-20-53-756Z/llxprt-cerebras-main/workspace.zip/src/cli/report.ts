import { readFileSync } from 'fs';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
function parseArgs(): { 
  dataFile: string; 
  format: string; 
  outputFile?: string; 
  includeTotals: boolean 
} {
  const args = process.argv.slice(2);
  const parsedArgs: { 
    dataFile: string; 
    format: string; 
    outputFile?: string; 
    includeTotals: boolean 
  } = { 
    dataFile: '', 
    format: '', 
    includeTotals: false 
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      parsedArgs.format = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--output' && i + 1 < args.length) {
      parsedArgs.outputFile = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      parsedArgs.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      // Assume this is the data file path
      parsedArgs.dataFile = arg;
    }
  }

  // Validate required arguments
  if (!parsedArgs.dataFile) {
    throw new Error('Missing data file argument');
  }

  if (!parsedArgs.format) {
    throw new Error('Missing --format argument');
  }

  // Validate format
  if (parsedArgs.format !== 'markdown' && parsedArgs.format !== 'text') {
    throw new Error(`Unsupported format: ${parsedArgs.format}`);
  }

  return parsedArgs;
}

// Load and validate JSON data
function loadData(filePath: string): ReportData {
  try {
    const data = JSON.parse(readFileSync(filePath, 'utf-8'));
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid title in data');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary in data');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries array in data');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Missing or invalid label in entry');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Missing or invalid amount in entry');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Failed to load data from ${filePath}: ${error.message}`);
    }
    throw new Error(`Failed to load data from ${filePath}: Invalid JSON`);
  }
}

// Main function
function main() {
  try {
    const args = parseArgs();
    const data = loadData(args.dataFile);
    
    let output: string;
    
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(data, { includeTotals: args.includeTotals });
        break;
      case 'text':
        output = renderText(data, { includeTotals: args.includeTotals });
        break;
      default:
        throw new Error(`Unsupported format: ${args.format}`);
    }
    
    if (args.outputFile) {
      // For this implementation we're focusing on stdout only
      // as per requirements, but I'll leave this here for future extension
      throw new Error('Output file option not implemented');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    }
    
    console.error('An unexpected error occurred');
    process.exit(1);
  }
}

main();