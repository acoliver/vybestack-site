import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = parseInt(process.env.PORT || '3000', 10);
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const DATA_DIR = path.dirname(DB_PATH);

// Validation types
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Global variables
let sql: typeof initSqlJs | null = null;
let db: Database | null = null;

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    sql = await initSqlJs({
      locateFile: (file) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file),
    });

    // Create data directory if it doesn't exist
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }

    // Load existing database or create new one
    let databaseBuffer: Uint8Array | null = null;
    if (fs.existsSync(DB_PATH)) {
      const buffer = fs.readFileSync(DB_PATH);
      databaseBuffer = new Uint8Array(buffer);
    }

    db = new sql.Database(databaseBuffer);

    // Create table if it doesn't exist
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;
    db.run(createTableSQL);

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[0-9\s\-\(\)]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (handle UK "SW1A 1AA", Argentine "C1000", "B1675")
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors.push({ field, message: `${field} is required` });
    }
  }

  // Email validation
  if (data.email && !validateEmail(data.email.trim())) {
    errors.push({ field: 'email', message: 'Invalid email address' });
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone.trim())) {
    errors.push({ field: 'phone', message: 'Invalid phone number' });
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Invalid postal code' });
  }

  return errors;
}

// Express app
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs');

// Routes

// GET / - Render form
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    // Re-render form with errors and previously entered values
    const errorMessages = errors.map((err) => err.message);
    return res.status(400).render('form', {
      errors: errorMessages,
      values: formData,
    });
  }

  // Insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const insertSQL = `
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.run(insertSQL, [
      formData.firstName.trim(),
      formData.lastName.trim(),
      formData.streetAddress.trim(),
      formData.city.trim(),
      formData.stateProvince.trim(),
      formData.postalCode.trim(),
      formData.country.trim(),
      formData.email.trim().toLowerCase(),
      formData.phone.trim(),
    ]);

    // Save database to disk
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting into database:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData,
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  // Get firstName from the last submission for personalization
  let firstName = 'there';
  try {
    if (db) {
      const result = db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      if (result.length > 0 && result[0].values.length > 0) {
        firstName = result[0].values[0][0] as string;
      }
    }
  } catch (error) {
    console.error('Error fetching first name:', error);
  }

  res.render('thank-you', { firstName });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error('Unhandled error:', err);
  res.status(500).send('Internal Server Error');
});

// Graceful shutdown handler
function gracefulShutdown(): void {
  console.log('Received SIGTERM, shutting down gracefully...');

  // Close database connection
  if (db) {
    db.close();
  }

  // Close Express server
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });

  // Force exit after 10 seconds
  setTimeout(() => {
    console.error('Forced shutdown after timeout');
    process.exit(1);
  }, 10000);
}

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();

  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  // Hook into SIGTERM for graceful shutdown
  process.on('SIGTERM', gracefulShutdown);

  // Also handle SIGINT (Ctrl+C)
  process.on('SIGINT', gracefulShutdown);
}

// Start the server
startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});