/**
 * Validate a Base64 string to ensure it only contains valid characters
 * and has proper structure.
 * Throws an error if the input is invalid.
 */
function validateBase64(input: string): void {
  // Standard Base64 alphabet: A-Z, a-z, 0-9, +, /, and optional padding =
  const validPattern = /^[A-Za-z0-9+/]+={0,2}$/;

  if (!validPattern.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the standard alphabet');
  }

  // Check that padding only appears at the end
  const hasPaddingAfterNonPadding = /=.+[^=]/.test(input);
  if (hasPaddingAfterNonPadding) {
    throw new Error('Invalid Base64 input: padding in the middle');
  }

  // Check padding count is valid (0, 1, or 2 padding characters)
  const paddingMatch = input.match(/=+$/);
  const paddingCount = paddingMatch ? paddingMatch[0].length : 0;
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }
}

/**
 * Encode plain text to Base64 using the standard alphabet.
 * Output includes padding characters as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate the input format (only for non-empty input)
  if (trimmed.length > 0) {
    validateBase64(trimmed);
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');

    // Check if we got an empty buffer from non-empty input
    // This can happen with malformed input that passes the regex but is invalid
    if (trimmed.length > 0 && buffer.length === 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }

    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
