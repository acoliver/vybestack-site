#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { ReportData, ReportFormat } from '../types.js';
import { FORMAT_RENDERERS } from '../formats/index.js';

interface CliOptions {
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): { dataPath: string; options: CliOptions } {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]',
    );
    process.exit(1);
  }

  const dataPath = args[0];
  let format: ReportFormat | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      if (args[i] !== 'markdown' && args[i] !== 'text') {
        console.error(`Error: Unsupported format: ${args[i]}`);
        process.exit(1);
      }
      format = args[i] as ReportFormat;
    } else if (args[i] === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${args[i]}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataPath, options: { format, outputPath, includeTotals } };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title field');
  }

  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries field');
  }

  const entries = obj.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${index} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid label`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid amount`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

async function main(): Promise<void> {
  try {
    const { dataPath, options } = parseArguments();

    // Read and parse JSON data
    let rawData: unknown;
    try {
      const fileContent = await readFile(dataPath, 'utf8');
      rawData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file "${dataPath}": ${error.message}`);
        process.exit(1);
      } else {
        console.error(`Error: Could not read file "${dataPath}": ${error}`);
        process.exit(1);
      }
    }

    // Validate data structure
    let reportData: ReportData;
    try {
      reportData = validateReportData(rawData);
    } catch (error) {
      console.error(`Error: ${error}`);
      process.exit(1);
    }

    // Render report
    const renderer = FORMAT_RENDERERS[options.format];
    const output = renderer(reportData, { includeTotals: options.includeTotals });

    // Write output
    if (options.outputPath) {
      try {
        await writeFile(options.outputPath, output, 'utf8');
      } catch (error) {
        console.error(`Error: Could not write to output file "${options.outputPath}": ${error}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Unexpected error: ${error}`);
    process.exit(1);
  }
}

main();