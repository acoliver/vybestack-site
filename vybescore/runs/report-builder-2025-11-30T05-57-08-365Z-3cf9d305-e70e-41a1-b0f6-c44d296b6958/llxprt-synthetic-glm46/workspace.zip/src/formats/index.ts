import { ReportFormat, ReportRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const FORMAT_RENDERERS: Record<ReportFormat, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export { renderMarkdown, renderText };