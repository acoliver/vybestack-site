/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces and handle sentence boundaries
  return text
    // Split on sentence endings (periods, question marks, exclamation points) followed by spaces
    .split(/(?<=[.?!])\s+/)
    .map(sentence => {
      const trimmed = sentence.trim();
      if (trimmed.length === 0) return trimmed;
      // Capitalize first letter and handle special cases like "i"
      if (trimmed.toLowerCase() === 'i') {
        return 'I';
      }
      return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
    })
    .join('. ')
    // Handle cases where original had different spacing
    .replace(/\. +/g, '. ')
    .replace(/! +/g, '! ')
    .replace(/\? +/g, '? ');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http/https URLs and captures them without trailing punctuation
  const urlRegex = /https?:\/\/[^\s<>"')\\]]+(?=[)\s<>"'\\.,;!?]|$)/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove any trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[.,;!?]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, find all http URLs
  const httpUrlRegex = /http:\/\/([^\/\s]+)(\/[^\s]*)?/g;
  
  return text.replace(httpUrlRegex, (match, host, path) => {
    const fullPath = path || '/';
    
    // Check if path contains dynamic hints that should prevent host rewrite
    const dynamicHints = /\?(.*=)|&(.*=)|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)/i;
    const hasDynamicContent = dynamicHints.test(fullPath);
    
    let newUrl = 'https://';
    
    if (fullPath.startsWith('/docs/') && !hasDynamicContent) {
      // Rewrite host to docs.example.com
      newUrl += 'docs.' + host + fullPath;
    } else {
      // Keep original host
      newUrl += host + fullPath;
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}
