export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with common patterns
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for specific invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }

  // Check domain doesn't contain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }

  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.trim();
  const phoneRegex = /^(?:\+1\s*)?(?:\(?(\d{3})\)?[-\s]?)?(\d{3})[-\s]?(\d{4})$/;
  
  const match = phoneRegex.exec(cleaned);
  if (!match) {
    return false;
  }

  const areaCode = match[1];
  // Area code cannot start with 0 or 1
  if (areaCode && (areaCode[0] === '0' || areaCode[0] === '1')) {
    return false;
  }

  // Basic length check
  const allDigits = cleaned.replace(/\D/g, '');
  if (allDigits.length < 10 || allDigits.length > 11) {
    return false;
  }

  return true;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleaned = value.trim();
  
  // Remove all spaces and hyphens for processing
  const digitsOnly = cleaned.replace(/[\s-]/g, '');
  
  // Pattern matching Argentine phone formats
  // +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  const argPhoneRegex = /^(?:\+54)?(?:\s*9\s*)?(\d{2,4})(\d{6,8})$/;
  const match = argPhoneRegex.exec(digitsOnly);
  
  if (!match) {
    return false;
  }

  const areaCode = match[1];
  const subscriberNumber = match[2];

  // Area code must start with 1-9 and be 2-4 digits
  if (areaCode[0] === '0' || areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Subscriber number must be 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  // When country code is omitted, must start with trunk prefix
  if (!cleaned.startsWith('+54') && !cleaned.trim().startsWith('0')) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and symbols (except apostrophes and hyphens)
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value.trim())) {
    return false;
  }

  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) {
    return false;
  }

  // Reject obviously invalid patterns like "X Æ A-12"
  if (/\d/.test(value) || value.includes('Æ')) {
    return false;
  }

  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/\s/g, '');
  
  // Must be 13-19 digits
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }

  // Check card type prefixes
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const isVisa = /^4/.test(cleaned) && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19);
  const isMastercard = /^(5[1-5]|2[2-7])/.test(cleaned) && cleaned.length === 16;
  const isAmex = /^(34|37)/.test(cleaned) && cleaned.length === 15;

  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
