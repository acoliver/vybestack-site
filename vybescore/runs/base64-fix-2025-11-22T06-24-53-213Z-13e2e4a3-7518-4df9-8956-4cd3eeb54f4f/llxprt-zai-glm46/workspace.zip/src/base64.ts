/**
 * Base64 alphabet validation regex
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Check if the input contains only valid Base64 characters
  if (!BASE64_REGEX.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Check if decoding resulted in empty buffer (which happens with invalid base64)
    if (input && Buffer.from(input, 'base64').length === 0) {
      throw new Error('Invalid Base64 input: cannot decode');
    }
    
    return result;
  } catch (error) {
    throw new Error('Invalid Base64 input: cannot decode');
  }
}
