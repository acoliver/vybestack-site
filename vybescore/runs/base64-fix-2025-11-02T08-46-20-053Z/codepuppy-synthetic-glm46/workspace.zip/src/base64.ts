/**
 * Valid Base64 characters according to RFC 4648
 */
const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using RFC 4648 standard.
 * Uses the canonical Base64 alphabet with '+' and '/' characters
 * and includes proper '=' padding when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and
 * rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Input cannot be empty');
  }

  // Remove any whitespace characters (common allowance)
  const trimmedInput = input.replace(/\s/g, '');

  // Validate the input contains only valid Base64 characters
  if (!VALID_BASE64_REGEX.test(trimmedInput)) {
    throw new Error('Invalid Base64 format: contains illegal characters');
  }

  // Check for proper padding length
  const paddingLength = (trimmedInput.match(/=/g) || []).length;
  
  // Base64 strings must have a total length that's a multiple of 4
  if (trimmedInput.length % 4 !== 0) {
    throw new Error('Invalid Base64 format: incorrect length');
  }

  // Check padding usage
  if (paddingLength > 2) {
    throw new Error('Invalid Base64 format: too much padding');
  }

  // Total length must be at least 4 characters (minimum valid Base64)
  if (trimmedInput.length < 4) {
    throw new Error('Invalid Base64 format: too short');
  }

  try {
    return Buffer.from(trimmedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
