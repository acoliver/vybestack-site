import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function renderText(data: ReportData, options: RenderOptions): string {
  let output = '';

  output += `${data.title}\n`;
  output += `${data.summary}\n`;
  output += `Entries:\n`;

  for (const entry of data.entries) {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }

  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `Total: ${formatAmount(total)}`;
  }

  return output;
}

export const textRenderer: ReportRenderer = {
  render: renderText,
};