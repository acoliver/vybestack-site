import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  let output = '';

  output += `# ${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `## Entries\n`;

  for (const entry of data.entries) {
    output += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
  }

  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\n**Total:** ${formatAmount(total)}`;
  }

  return output;
}

export const markdownRenderer: ReportRenderer = {
  render: renderMarkdown,
};