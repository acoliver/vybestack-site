#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs';
import { resolve } from 'node:path';

import type { ReportData, FormatType, RenderOptions } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

function parseArgs(): { dataFile: string; format: FormatType; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    process.stderr.write('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]\n');
    process.exit(1);
  }

  const dataFile = args[0];
  
  const formatIndex = args.findIndex(arg => arg === '--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    process.stderr.write('Error: --format argument is required and must specify a format\n');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1] as FormatType;
  if (format !== 'markdown' && format !== 'text') {
    process.stderr.write(`Error: Unsupported format "${format}". Supported formats: markdown, text\n`);
    process.exit(1);
  }

  const outputIndex = args.findIndex(arg => arg === '--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (must be an array)');
  }

  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry at index ${index} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid "label" field (must be a string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid "amount" field (must be a number)`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

function main(): void {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArgs();

    readFile(resolve(dataFile), 'utf-8', (err, fileData) => {
      if (err) {
        process.stderr.write(`Error reading file "${dataFile}": ${err.message}\n`);
        process.exit(1);
      }

      let jsonData: unknown;
      try {
        jsonData = JSON.parse(fileData);
      } catch (parseErr) {
        process.stderr.write(`Error parsing JSON in "${dataFile}": ${parseErr instanceof Error ? parseErr.message : String(parseErr)}\n`);
        process.exit(1);
      }

      let reportData: ReportData;
      try {
        reportData = validateReportData(jsonData);
      } catch (validationErr) {
        process.stderr.write(`${validationErr instanceof Error ? validationErr.message : String(validationErr)}\n`);
        process.exit(1);
      }

      const options: RenderOptions = { includeTotals };
      
      let output: string;
      if (format === 'markdown') {
        output = markdownRenderer.render(reportData, options);
      } else {
        output = textRenderer.render(reportData, options);
      }

      if (outputPath) {
        writeFile(resolve(outputPath), output, 'utf-8', (writeErr) => {
          if (writeErr) {
            process.stderr.write(`Error writing to file "${outputPath}": ${writeErr.message}\n`);
            process.exit(1);
          }
        });
      } else {
        process.stdout.write(output);
      }
    });
  } catch (err) {
    process.stderr.write(`${err instanceof Error ? err.message : String(err)}\n`);
    process.exit(1);
  }
}

main();