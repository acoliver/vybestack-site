/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle the equal parameter - if boolean true, use Object.is, 
  // if it's a function use it, otherwise don't perform equality checks
  const equalFn: EqualFn<T> = equal === true 
    ? Object.is 
    : typeof equal === 'function' 
    ? equal 
    : () => false
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Update the observer with initial value
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Create dependency link 
      if (!(o as any).dependents) {
        (o as any).dependents = new Set<Observer<any>>()
      }
      (o as any).dependents.add(activeObserver)
    }
    return o.value!
  }
  
  // Override the updateFn to handle dependency tracking
  o.updateFn = (prevValue?: T) => {
    const newValue = updateFn(prevValue)
    // Only update if the new value is different from the current value
    if (!equalFn(o.value as T, newValue)) {
      o.value = newValue
      
      // Notify all dependent observers about the change
      const dependents = (o as any).dependents as Set<Observer<any>> | undefined
      if (dependents) {
        dependents.forEach(dep => {
          updateObserver(dep)
        })
      }
    }
    return newValue
  }
  
  return getter
}