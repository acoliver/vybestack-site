#!/usr/bin/env node

import * as fs from 'fs';
import { ReportData } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
const args = process.argv.slice(2);
let filePath: string | null = null;
let format: string | null = null;
let outputPath: string | null = null;
let includeTotals = false;

for (let i = 0; i < args.length; i++) {
  switch (args[i]) {
    case '--format':
      if (i + 1 < args.length) {
        format = args[i + 1];
        i++;
      } else {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      break;
    case '--output':
      if (i + 1 < args.length) {
        outputPath = args[i + 1];
        i++;
      } else {
        console.error('Error: --output requires a path argument');
        process.exit(1);
      }
      break;
    case '--includeTotals':
      includeTotals = true;
      break;
    default:
      if (!filePath) {
        filePath = args[i];
      } else {
        console.error(`Error: Unexpected argument '${args[i]}'`);
        process.exit(1);
      }
  }
}

// Validate required arguments
if (!filePath) {
  console.error('Error: JSON data file path is required');
  process.exit(1);
}

if (!format) {
  console.error('Error: --format is required');
  process.exit(1);
}

// Validate format
if (format !== 'markdown' && format !== 'text') {
  console.error(`Error: Unsupported format '${format}'`);
  process.exit(1);
}

// Read and parse JSON data
let rawData: string;
try {
  rawData = fs.readFileSync(filePath, 'utf8');
} catch (error) {
  console.error(`Error: Could not read file '${filePath}'`);
  process.exit(1);
}

let data: ReportData;
try {
  data = JSON.parse(rawData);
} catch (error) {
  console.error(`Error: Invalid JSON in file '${filePath}'`);
  process.exit(1);
}

// Validate data structure
if (!data.title || !data.summary || !Array.isArray(data.entries)) {
  console.error('Error: Invalid data structure in JSON file');
  process.exit(1);
}

for (const entry of data.entries) {
  if (!entry.label || typeof entry.amount !== 'number') {
    console.error('Error: Invalid entry structure in JSON file');
    process.exit(1);
  }
}

// Render the report
let renderedReport: string;
if (format === 'markdown') {
  renderedReport = renderMarkdown(data, { includeTotals });
} else { // format === 'text'
  renderedReport = renderText(data, { includeTotals });
}

// Output the report
if (outputPath) {
  try {
    fs.writeFileSync(outputPath, renderedReport);
    console.log(`Report written to ${outputPath}`);
  } catch (error) {
    console.error(`Error: Could not write to file '${outputPath}'`);
    process.exit(1);
  }
} else {
  console.log(renderedReport);
}