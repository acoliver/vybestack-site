import { describe, expect, it } from 'vitest';
import * as fs from 'fs';
import * as path from 'path';
import { execSync } from 'child_process';

const projectRoot = path.resolve(__dirname, '../../');

describe('report CLI (public smoke)', () => {
  it('should render markdown format correctly with totals', () => {
    const output = execSync(
      `node ${path.join(projectRoot, 'dist/cli/report.js')} ${path.join(projectRoot, 'fixtures/data.json')} --format markdown --includeTotals`,
      { encoding: 'utf8' }
    );
    
    const expected = `# Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89

**Total:** $70370.34
`;
    
    expect(output.trim()).toBe(expected.trim());
  });

  it('should render text format correctly with totals', () => {
    const output = execSync(
      `node ${path.join(projectRoot, 'dist/cli/report.js')} ${path.join(projectRoot, 'fixtures/data.json')} --format text --includeTotals`,
      { encoding: 'utf8' }
    );
    
    const expected = `Quarterly Financial Summary

Highlights include record revenue across regions and a healthy outlook for the next quarter.

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89

Total: $70370.34
`;
    
    expect(output.trim()).toBe(expected.trim());
  });

  it('should handle missing format argument', () => {
    try {
      execSync(
        `node ${path.join(projectRoot, 'dist/cli/report.js')} ${path.join(projectRoot, 'fixtures/data.json')}`,
        { encoding: 'utf8' }
      );
      // Should not reach here if error is thrown
      expect(true).toBe(false);
    } catch (error) {
      expect(error.stderr).toContain('--format is required');
    }
  });

  it('should handle unsupported format', () => {
    try {
      execSync(
        `node ${path.join(projectRoot, 'dist/cli/report.js')} ${path.join(projectRoot, 'fixtures/data.json')} --format xml`,
        { encoding: 'utf8' }
      );
      // Should not reach here if error is thrown
      expect(true).toBe(false);
    } catch (error) {
      expect(error.stderr).toContain('Unsupported format');
    }
  });
});