import { ReportData } from '../types.js';

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  let output = `# ${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `## Entries\n\n`;
  
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  for (const entry of data.entries) {
    const formattedAmount = formatCurrency(entry.amount);
    output += `- **${entry.label}** — ${formattedAmount}\n`;
  }
  
  if (includeTotals) {
    output += `\n**Total:** ${formatCurrency(total)}\n`;
  }
  
  return output;
}

function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}