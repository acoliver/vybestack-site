import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    output: undefined,
    includeTotals: false
  };

  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      if (i + 1 < argv.length) {
        args.format = argv[++i];
      } else {
        throw new Error('Missing value for --format option');
      }
    } else if (arg === '--output') {
      if (i + 1 < argv.length) {
        args.output = argv[++i];
      } else {
        throw new Error('Missing value for --output option');
      }
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      if (!args.dataFile) {
        args.dataFile = arg;
      }
    }
  }

  if (!args.dataFile) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  if (!args.format) {
    throw new Error('Missing required --format option');
  }

  return args;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }

  if (!reportData.entries || !Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  const entries: unknown[] = reportData.entries;
  const validatedEntries = entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entries[${index}] must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${index}].label must be a string`);
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid JSON: entries[${index}].amount must be a number`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries: validatedEntries
  };
}

function readAndParseJson(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        throw new Error(`File not found: ${filePath}`);
      } else if (error.message.includes('JSON')) {
        throw new Error('Invalid JSON: malformed JSON');
      } else {
        throw new Error(`Error reading file: ${error.message}`);
      }
    } else {
      throw new Error('Error reading JSON file');
    }
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, 'utf8');
  } else {
    process.stdout.write(content);
  }
}

function render(format: string, data: ReportData, includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, includeTotals);
    case 'text':
      return renderText(data, includeTotals);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    const data = readAndParseJson(args.dataFile);
    const output = render(args.format, data, args.includeTotals);
    writeOutput(output, args.output);
    process.exit(0);
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    } else {
      console.error('Unknown error occurred');
      process.exit(1);
    }
  }
}

main();
