import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import session from 'express-session';

// Extend the session type to include our custom properties
declare module 'express-session' {
  interface SessionData {
    firstName?: string;
  }
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function setupDatabase(): Promise<Database> {
  const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  const dataDir = path.dirname(dbPath);
  
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  let fileBuffer: Buffer;
  if (fs.existsSync(dbPath)) {
    fileBuffer = fs.readFileSync(dbPath);
  } else {
    fileBuffer = Buffer.alloc(0);
  }
  
  const SQL = await initSqlJs();
  const db = new SQL.Database(fileBuffer);
  
  initDatabase(db);
  return db;
};

function initDatabase(db: Database): void {
  const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');
  db.exec(schema);
}

function saveDatabase(db: Database): void {
  const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

function validateForm(values: Record<string, string>): { errors: string[]; isValid: boolean } {
  const errors: string[] = [];
  
  if (!values.firstName?.trim()) {
    errors.push('First name is required');
  }
  
  if (!values.lastName?.trim()) {
    errors.push('Last name is required');
  }
  
  if (!values.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  
  if (!values.city?.trim()) {
    errors.push('City is required');
  }
  
  if (!values.stateProvince?.trim()) {
    errors.push('State/Province/Region is required');
  }
  
  if (!values.postalCode?.trim()) {
    errors.push('Postal/Zip code is required');
  }
  
  if (!values.country?.trim()) {
    errors.push('Country is required');
  }
  
  if (!values.email?.trim()) {
    errors.push('Email is required');
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
    errors.push('Email is not valid');
  }
  
  if (!values.phone?.trim()) {
    errors.push('Phone number is required');
} else if (!/^\+?[\d\s\-()]+$/.test(values.phone)) {
    errors.push('Phone number is not valid');
  }
  
  return { errors, isValid: errors.length === 0 };
}

async function startServer(): Promise<void> {
  const app = express();
  const port = process.env.PORT || 3535;
  
  const db = await setupDatabase();
  
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.join(__dirname, '..', 'public')));
  
  // Setup session middleware
  app.use(session({
    secret: 'friendly-form-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to false for development, true in production with HTTPS
  }));
  
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));
  
  app.get('/', (req, res) => {
    res.render('form', { errors: [], values: {} });
  });
  
  app.post('/submit', (req, res) => {
    const values = req.body;
    const { errors, isValid } = validateForm(values);
    
    if (!isValid) {
      res.status(400);
      return res.render('form', { errors, values });
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      values.firstName,
      values.lastName,
      values.streetAddress,
      values.city,
      values.stateProvince,
      values.postalCode,
      values.country,
      values.email,
      values.phone
    ]);
    
    stmt.free();
    
    saveDatabase(db);
    
    // Store the first name for the thank-you page
    req.session.firstName = values.firstName || 'Friend';
    
    res.redirect(302, '/thank-you');
  });
  
  app.get('/thank-you', (req, res) => {
    const firstName = req.session?.firstName || 'Friend';
    res.render('thank-you', { firstName });
  });
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    server.close(() => {
      console.log('Server closed');
      db.close();
      process.exit(0);
    });
  });
  
  process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    server.close(() => {
      console.log('Server closed');
      db.close();
      process.exit(0);
    });
  });
}

startServer().catch(err => {
  console.error('Failed to start server', err);
  process.exit(1);
});
