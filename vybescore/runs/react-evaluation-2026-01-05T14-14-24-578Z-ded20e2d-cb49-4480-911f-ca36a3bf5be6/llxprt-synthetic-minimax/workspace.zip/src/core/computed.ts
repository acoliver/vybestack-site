/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Store observers that depend on this computed value
  const subscribers: Array<(newValue: T) => void> = []

  const getter: GetterFn<T> = () => {
    // Track dependencies by setting this as active observer
    const previousObserver = getActiveObserver()
    try {
      // Temporarily set this computed as the active observer
      (globalThis as { __activeObserver?: unknown }).__activeObserver = observer
      
      // Execute the update function to compute new value
      const newValue = updateFn(value)
      const valueChanged = newValue !== observer.value
      
      observer.value = newValue
      
      // If value changed, notify all subscribers
      if (valueChanged) {
        subscribers.forEach(callback => {
          try {
            callback(newValue!)
          } catch (error) {
            console.warn('Subscriber error:', error)
          }
        })
      }
      
      return observer.value!
    } finally {
      // Restore previous active observer
      (globalThis as { __activeObserver?: unknown }).__activeObserver = previousObserver
    }
  }

  return getter as GetterFn<T> & { subscribe: (callback: (newValue: T) => void) => () => void }
}
