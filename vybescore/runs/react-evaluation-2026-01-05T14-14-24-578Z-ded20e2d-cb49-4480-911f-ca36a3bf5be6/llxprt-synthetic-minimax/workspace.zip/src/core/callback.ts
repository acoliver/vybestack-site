/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let callbackValue = value
  const observer: Observer<T> = {
    value: callbackValue,
    updateFn,
  }

  // Store subscriptions to cleanup
  const subscriptions: Subject<T>[] = []

  // Execute the callback immediately and register for updates
  const executeCallback = () => {
    if (disposed) return
    
    try {
      callbackValue = updateFn(callbackValue)
      observer.value = callbackValue
    } catch (error) {
      console.warn('Callback execution error:', error)
    }
  }

  // Register this callback as an observer
  updateObserver(observer)

  // Trigger initial execution if we have dependencies
  const activeObserver = getActiveObserver()
  if (activeObserver) {
    executeCallback()
  }

  return () => {
    if (disposed) return
    disposed = true
    
    // Clear subscriptions
    subscriptions.forEach(subscription => {
      subscription.observer = undefined
    })
    subscriptions.length = 0
    
    // Dispose observer
    observer.value = undefined
    observer.updateFn = () => callbackValue!
  }
}
