/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const getter: GetterFn<T> = () => {
    // Register active observer as dependent on this input
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      subject.observer = activeObserver
    }
    return subject.value
  }

  const setter: SetterFn<T> = (nextValue) => {
    subject.value = nextValue
    
    // Notify the registered observer about the change
    if (subject.observer) {
      updateObserver(subject.observer as Observer<unknown>)
    }
    
    return subject.value
  }

  return [getter, setter]
}
