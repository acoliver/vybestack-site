import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    const page = pageParam ? Number(pageParam) : 1;
    const limit = limitParam ? Number(limitParam) : 5;

    // Check for invalid values: non-numeric, negative, zero, or excessive
    if (pageParam !== undefined && (isNaN(page) || page < 1 || !Number.isInteger(page) || page > 10000)) {
      return res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer.' });
    }
    if (limitParam !== undefined && (isNaN(limit) || limit < 1 || !Number.isInteger(limit) || limit > 1000)) {
      return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer.' });
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
