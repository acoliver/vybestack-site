/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  trackDependency,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    disposed: false,
  }
  
  // Create a subject to represent this computed value
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
  }
  
  // Store subject reference on observer for cleanup
  o.subject = subject as Subject<unknown>
  
  // Track the computed's dependencies on first evaluation
  updateObserver(o)
  
  return (): T => {
    // Track this computed as dependent on any subjects read during this call
    trackDependency(subject as Subject<unknown>)
    return o.value!
  }
}
