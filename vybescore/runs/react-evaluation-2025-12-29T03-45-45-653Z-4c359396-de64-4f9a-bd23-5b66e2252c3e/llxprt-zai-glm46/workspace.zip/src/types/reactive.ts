/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  disposed?: boolean
  sources?: Set<Subject<unknown>>
  subject?: Subject<unknown>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let updateDepth = 0
const queuedUpdates: Set<ObserverR> = new Set()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (observer.disposed) return
  
  // Queue the update if we're already updating (to prevent infinite recursion)
  if (updateDepth > 0) {
    queuedUpdates.add(observer)
    return
  }
  
  updateDepth++
  try {
    const previous = activeObserver
    activeObserver = observer
    try {
      observer.value = observer.updateFn(observer.value)
    } finally {
      activeObserver = previous
    }
    
    // Clear sources - will be re-tracked on next read
    observer.sources = undefined
    
    // Update subject value and notify observers
    if (observer.subject) {
      (observer.subject as Subject<T>).value = observer.value!
      notifyObservers(observer.subject)
    }
  } finally {
    updateDepth--
    
    // Process queued updates when done
    if (updateDepth === 0 && queuedUpdates.size > 0) {
      const toUpdate = Array.from(queuedUpdates)
      queuedUpdates.clear()
      for (const obs of toUpdate) {
        if (!obs.disposed) {
          updateObserver(obs as Observer<unknown>)
        }
      }
    }
  }
}

export function trackDependency(subject: Subject<unknown>): void {
  const observer = activeObserver
  if (observer) {
    // Add this subject to the observer's sources
    if (!observer.sources) {
      observer.sources = new Set()
    }
    observer.sources.add(subject)
    
    // Add the observer to the subject's observers
    if (!subject.observers) {
      subject.observers = new Set()
    }
    if (!subject.observers.has(observer)) {
      subject.observers.add(observer)
    }
  }
}

export function notifyObservers(subject: Subject<unknown>): void {
  if (subject.observers) {
    const observers = Array.from(subject.observers)
    for (const observer of observers) {
      if (!observer.disposed) {
        updateObserver(observer as Observer<unknown>)
      }
    }
  }
}
