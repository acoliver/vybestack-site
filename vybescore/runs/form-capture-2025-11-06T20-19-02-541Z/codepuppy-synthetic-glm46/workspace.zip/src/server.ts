import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

let db: Database | null = null;

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
    });

    let data = new Uint8Array(0);
    
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      data = fs.readFileSync(DB_PATH);
    }

    db = new SQL.Database(data);

    // Initialize schema if needed
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

function validateFormData(formData: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  // Validate required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    const value = formData[field]?.trim();
    if (!value || value.length === 0) {
      const fieldNames: Record<string, string> = {
        firstName: 'First name',
        lastName: 'Last name',
        streetAddress: 'Street address',
        city: 'City',
        stateProvince: 'State / Province / Region',
        postalCode: 'Postal / Zip code',
        country: 'Country',
        email: 'Email',
        phone: 'Phone number'
      };
      errors.push(`${fieldNames[field]} is required`);
    }
  }

  // Validate email format
  if (formData.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email.trim())) {
      errors.push('Please enter a valid email address');
    }
  }

  // Validate phone number (international format)
  if (formData.phone) {
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    if (!phoneRegex.test(formData.phone.trim())) {
      errors.push('Phone number can only contain digits, spaces, dashes, parentheses, and an optional leading +');
    }
  }

  // Validate postal code (alphanumeric)
  if (formData.postalCode) {
    const postalRegex = /^[\w\s-]+$/;
    if (!postalRegex.test(formData.postalCode.trim())) {
      errors.push('Postal code can only contain letters, numbers, spaces, and dashes');
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

function extractFormData(req: Request): Partial<FormData> {
  return {
    firstName: req.body.firstName?.trim(),
    lastName: req.body.lastName?.trim(),
    streetAddress: req.body.streetAddress?.trim(),
    city: req.body.city?.trim(),
    stateProvince: req.body.stateProvince?.trim(),
    postalCode: req.body.postalCode?.trim(),
    country: req.body.country?.trim(),
    email: req.body.email?.trim(),
    phone: req.body.phone?.trim(),
  };
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = extractFormData(req);
  const validation = validateFormData(formData);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName || '',
      formData.lastName || '',
      formData.streetAddress || '',
      formData.city || '',
      formData.stateProvince || '',
      formData.postalCode || '',
      formData.country || '',
      formData.email || '',
      formData.phone || ''
    ]);

    stmt.free();
    saveDatabase();

    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!)}`);
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Unhandled error:', err);
  res.status(500).render('form', {
    errors: ['An unexpected error occurred. Please try again.'],
    values: {}
  });
});

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).render('form', {
    errors: ['Page not found.'],
    values: {}
  });
});

let server: ReturnType<typeof app.listen> | null = null;

async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

function gracefulShutdown(shouldExit = true): Promise<void> {
  console.log('Shutting down gracefully...');
  
  return new Promise((resolve) => {
    if (server) {
      server.close(() => {
        console.log('HTTP server closed');
        
        if (db) {
          db.close();
          console.log('Database connection closed');
        }
        
        if (shouldExit) {
          process.exit(0);
        }
        resolve();
      });
    } else {
      if (db) {
        db.close();
      }
      if (shouldExit) {
        process.exit(0);
      }
      resolve();
    }
  });
}

// Handle process signals
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  gracefulShutdown();
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  gracefulShutdown();
});

// Export for testing before starting
export { app, server, gracefulShutdown, initializeDatabase };

// Start the server only when run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}