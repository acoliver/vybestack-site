import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

import { app, gracefulShutdown, initializeDatabase } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Initialize database for tests
  await initializeDatabase();
});

afterAll(async () => {
  await gracefulShutdown(false);
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toBeDefined();
    const $ = cheerio.load(response.text || '');
    expect($('form[action="/submit"]')).toHaveLength(1);
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you\?firstName=John/);

    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Verify thank you page
    const thankYouResponse = await request(app).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toBeDefined();
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you, John!');
  });

  it('handles validation errors', async () => {
    const invalidData = {
      firstName: '',
      lastName: 'Doe',
      email: 'invalid-email',
      phone: 'invalid-phone-!@#'
    };

    const response = await request(app)
      .post('/submit')
      .send(invalidData);

    expect(response.status).toBe(400);
    expect(response.text).toBeDefined();
    const $ = cheerio.load(response.text);
    expect($('.error-list')).toHaveLength(1);
    expect($('.error-list li').length).toBeGreaterThan(0);
  });

  it('handles international formats', async () => {
    const internationalData = {
      firstName: 'María',
      lastName: 'González',
      streetAddress: 'Calle 123 #45-67',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'maria.gonzalez@example.co.uk',
      phone: '+44 20 7946 0958'
    };

    const response = await request(app)
      .post('/submit')
      .send(internationalData);

    expect(response.status).toBe(302);
  });
});
