#!/usr/bin/env node

/**
 * Report Builder CLI
 * 
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

import type { ReportData, RenderOptions, Renderer } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

// Map of supported format renderers
const renderers: Record<string, Renderer> = {
  markdown: markdownRenderer,
  text: textRenderer,
};

interface CLIOptions {
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): { dataPath: string; options: CLIOptions } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataPath = args[0];
  const options: CLIOptions = {
    format: '',
    includeTotals: false,
  };
  
  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      options.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a path');
      }
      options.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
    
    i++;
  }
  
  if (!options.format) {
    throw new Error('--format is required');
  }
  
  return { dataPath, options };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (must be a string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (must be a string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (must be an array)');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (must be a string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (must be a number)`);
    }
  }
  
  return obj as unknown as ReportData;
}

function loadReportData(dataPath: string): ReportData {
  try {
    const fullPath = resolve(dataPath);
    const fileContent = readFileSync(fullPath, 'utf8');
    const data = JSON.parse(fileContent);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file "${dataPath}": ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: "${dataPath}"`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, options: CLIOptions): string {
  const renderer = renderers[options.format];
  
  if (!renderer) {
    throw new Error(`Unsupported format: "${options.format}". Supported formats: ${Object.keys(renderers).join(', ')}`);
  }
  
  const renderOptions: RenderOptions = {
    includeTotals: options.includeTotals,
  };
  
  return renderer.render(data, renderOptions);
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      const fullPath = resolve(outputPath);
      writeFileSync(fullPath, content, 'utf8');
      console.error(`Report written to: ${fullPath}`);
    } catch (error) {
      throw new Error(`Failed to write to file "${outputPath}": ${error instanceof Error ? error.message : String(error)}`);
    }
  } else {
    process.stdout.write(content);
  }
}

function main(): void {
  try {
    const { dataPath, options } = parseArguments();
    const data = loadReportData(dataPath);
    const rendered = renderReport(data, options);
    writeOutput(rendered, options.outputPath);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}