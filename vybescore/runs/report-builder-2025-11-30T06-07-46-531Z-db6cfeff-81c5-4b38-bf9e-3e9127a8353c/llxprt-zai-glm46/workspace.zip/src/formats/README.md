# Report Formats

This directory contains format-specific renderers for the report builder CLI.

## Available Formats

### Markdown (`markdown.ts`)
- Renders reports in Markdown format
- Includes proper heading structure and formatting
- Supports totals when requested

### Text (`text.ts`)
- Renders reports in plain text format
- Simple, clean formatting suitable for console output
- Supports totals when requested

## Adding New Formats

To add a new format:

1. Create a new TypeScript file in this directory (e.g., `html.ts`)
2. Implement the `Renderer` interface from `../types.js`
3. Export both the render function and a renderer object:

```typescript
import type { ReportData, RenderOptions, Renderer } from '../types.js';

export function renderYourFormat(data: ReportData, options: RenderOptions): string {
  // Your rendering logic here
  return result;
}

export const yourFormatRenderer: Renderer = {
  render: renderYourFormat,
};
```

4. Import and register the renderer in the main CLI module (`../cli/report.ts`)
