import { readFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import initSqlJs, { type Database, type SqlJsStatic } from 'sql.js';

// Find seed file - check multiple possible locations
const SEED_PATH = path.resolve(process.cwd(), 'data/seed.sql');
if (!existsSync(SEED_PATH)) {
  throw new Error(`Seed file not found at ${SEED_PATH}`);
}
let sqlJsInstance: Promise<SqlJsStatic> | undefined;

function locateWasm(file: string): string {
  // Use the correct path to locate WASM files
  const wasmPath = path.resolve(process.cwd(), 'node_modules/sql.js/dist', file);
  return wasmPath;
}

function getSqlModule(): Promise<SqlJsStatic> {
  if (!sqlJsInstance) {
    sqlJsInstance = initSqlJs({
      locateFile: locateWasm
    });
  }

  return sqlJsInstance;
}

export async function createDatabase(): Promise<Database> {
  const SQL = await getSqlModule();
  const db = new SQL.Database();
  const seed = readFileSync(SEED_PATH, 'utf8');
  db.run(seed);
  return db;
}
