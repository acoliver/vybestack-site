export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 simplified email validation
  // Local part: letters, digits, and these special chars: !#$%&'*+-/=?^_`{|}~
  // Domain: letters, digits, hyphens, dots (but not starting/ending with dot or having consecutive dots)
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validations to reject problematic cases
  // No double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dot in domain
  const domain = value.split('@')[1];
  if (domain && domain.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit and non-plus characters
  const cleaned = value.replace(/[^+\d]/g, '');
  
  // Check for optional +1 prefix
  let remaining = cleaned;
  if (remaining.startsWith('+1')) {
    remaining = remaining.substring(2);
  }
  
  // Must be exactly 10 digits after optional +1
  if (!/^\d{10}$/.test(remaining)) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = remaining.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern explanation:
  // Option 1: +54 (country) + optional 9 (mobile) + area (2-4 digits starting 1-9) + subscriber (6-8 digits)
  // Option 2: 0 (trunk) + optional 9 (mobile) + area (2-4 digits starting 1-9) + subscriber (6-8 digits)
  
  const countryCodePattern = /^\+54(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const trunkPattern = /^0(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  return countryCodePattern.test(cleaned) || trunkPattern.test(cleaned);
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must start with a letter (unicode aware)
  // Allow letters (including accents), apostrophes, hyphens, and spaces
  // At least one character
  // No digits, symbols, or unusual characters
  
  // Unicode property escapes for letters
  const namePattern = /^[\p{L}](?:[\p{L}\p{M}'\-\s]*[\p{L}\p{M}])?$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Reject empty strings or strings that are just whitespace
  if (!value.trim()) {
    return false;
  }
  
  // Reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject unusual symbols (beyond apostrophe, hyphen, space)
  if (/[!@#$%^&*()_+=[{};:"\\|,.<>/?`~]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm implementation for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  // Remove all non-digits
  const digits = cardNumber.replace(/\D/g, '');
  
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digits for processing
  const digits = value.replace(/\D/g, '');
  
  if (digits.length === 0) {
    return false;
  }
  
  // Check for common credit card patterns:
  // Visa: 16 digits starting with 4
  // MasterCard: 16 digits starting with 51-55 or 2221-2720
  // American Express: 15 digits starting with 34 or 37
  
  const digitCount = digits.length;
  const prefix = parseInt(digits.substring(0, 2));
  const prefix4 = parseInt(digits.substring(0, 4));
  const firstDigit = parseInt(digits[0]);
  
  // Visa: starts with 4, 13, 16, or 19 digits
  if (firstDigit === 4 && (digitCount === 13 || digitCount === 16 || digitCount === 19)) {
    return runLuhnCheck(value);
  }
  
  // MasterCard: 16 digits, starts with 51-55 or 2221-2720
  if (digitCount === 16 && ((prefix >= 51 && prefix <= 55) || (prefix4 >= 2221 && prefix4 <= 2720))) {
    return runLuhnCheck(value);
  }
  
  // American Express: 15 digits, starts with 34 or 37
  if (digitCount === 15 && (prefix === 34 || prefix === 37)) {
    return runLuhnCheck(value);
  }
  
  return false;
}