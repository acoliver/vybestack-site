/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern for words starting with the prefix
  // Use word boundaries to match complete words
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));
  return matches.filter(word => !exceptionsSet.has(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // To get the full match including the preceding digit, we need to capture it
  // Create a pattern that captures the digit followed by the token
  const fullPattern = new RegExp(`(?<!^)(\\d)${token}`, 'gi');
  const matches = text.match(fullPattern) || [];
  
  // The matches include the digit, but we want to return the full occurrence
  // which includes the digit
  return matches.map(match => match);
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab", "testtest", etc.
  // This pattern looks for any 2+ character sequence that repeats immediately
  const repeatedSequencePattern = /(..+)\1/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns
  // Full format: 8 groups of 1-4 hex digits separated by colons
  // Compressed format: uses :: to represent multiple zero groups
  // IPv4-mapped format: can have IPv4 address at the end
  
  // Pattern breakdown:
  // 1. Check for :: (zero or more groups of zeros compressed)
  // 2. Full hex groups (1-4 hex digits each)
  // 3. Optional IPv4-mapped address at the end
  
  // Also check for common IPv6 patterns that might not match the strict pattern above
  // Look for :: anywhere in the address (IPv6 shorthand indicator)
  const hasIPv6Shorthand = /::/.test(value);
  
  // Count the number of colon groups (separators)
  const colonCount = (value.match(/:/g) || []).length;
  
  // IPv6 should have at least 2 colons (even in ::1 form)
  // And typically 3-7 non-empty colon groups (accounting for :: compression)
  // Or it could be just :: (loopback)
  const hasValidIPv6Structure = hasIPv6Shorthand || colonCount >= 7;
  
  // Must contain hex digits (not just dots like IPv4)
  const containsHexDigits = /[a-f0-9]/i.test(value);
  
  // Must NOT be a pure IPv4 address
  // IPv4 pattern: 4 groups of 1-3 digits separated by dots
  const isIPv4 = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(value);
  
  if (isIPv4) {
    return false;
  }
  
  // Final check: must contain hex digits and have IPv6 structure
  return containsHexDigits && hasValidIPv6Structure;
}