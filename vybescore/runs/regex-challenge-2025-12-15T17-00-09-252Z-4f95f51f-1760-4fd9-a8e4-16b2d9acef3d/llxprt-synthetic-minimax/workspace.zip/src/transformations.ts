/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return text;
  }
  
  // Process sentence by sentence
  const sentencePattern = /([.!?]+)(\s*)/g;
  
  let processedResult = '';
  let lastEnd = 0;
  let match;
  
  // Process each sentence terminator
  while ((match = sentencePattern.exec(text)) !== null) {
    // Add the text before this terminator
    processedResult += text.substring(lastEnd, match.index);
    
    // Add the terminator
    processedResult += match[1];
    
    // Add exactly one space after the terminator (if there's more text)
    if (match.index + match[0].length < text.length) {
      processedResult += ' ';
    }
    
    lastEnd = match.index + match[0].length;
  }
  
  // Add remaining text
  processedResult += text.substring(lastEnd);
  
  // Now capitalize the first letter after each sentence terminator (or start of string)
  // Look for sentence endings followed by optional whitespace and then a letter
  const capitalizePattern = /([.!?]\s+)([a-z])/g;
  processedResult = processedResult.replace(capitalizePattern, (match, sentenceEnd, letter) => {
    return sentenceEnd + letter.toUpperCase();
  });
  
  // Also capitalize the very first letter if it's not already capitalized
  if (processedResult.length > 0 && /[a-z]/.test(processedResult[0])) {
    processedResult = processedResult[0].toUpperCase() + processedResult.substring(1);
  }
  
  return processedResult;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern - matches http(s):// followed by domain and path
  // Includes common TLDs and allows for subdomains
  const urlPattern = /https?:\/\/[^\s<>"']+(?:\/[^\s<>"']*)*/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation from URLs
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation like .,;:!? etc.
    return url.replace(/[.,;:!?]+$/, '');
  });
  
  return cleanedUrls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  // Use word boundaries to avoid matching http:// in longer words
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  // Captures: scheme, host, and path
  const urlPattern = /https?:\/\/([^/\s]+)(\/[^\s<>"']*)?/gi;
  
  return text.replace(urlPattern, (match, host, path = '') => {
    // If it's already https, keep as is (don't double upgrade)
    if (match.startsWith('https://')) {
      return match;
    }
    
    // If path starts with /docs/, consider rewriting the host
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints in the path
      const hasDynamicHints = /(\?|=|&|\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)|cgi-bin)/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.{original-domain}
        const docsHost = `docs.${host}`;
        return `https://${docsHost}${path}`;
      }
    }
    
    // Default: just upgrade to https
    return `https://${host}${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [
    31, // January
    (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0 ? 29 : 28, // February (leap year check)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // If all validations pass, return the year
  return match[3];
}