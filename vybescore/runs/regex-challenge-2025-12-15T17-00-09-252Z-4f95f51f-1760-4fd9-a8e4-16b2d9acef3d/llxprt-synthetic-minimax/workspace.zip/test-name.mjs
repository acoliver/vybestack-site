import { isValidName } from './dist/src/validators.js';

console.log('Testing O\'Brien character by character:');
const testName = "O'Brien";
console.log(`Input: ${JSON.stringify(testName)}`);
console.log(`Characters: ${[...testName].map(c => c.charCodeAt(0)).join(', ')}`);
console.log(`Length: ${testName.length}`);

for (let i = 0; i < testName.length; i++) {
  const char = testName[i];
  console.log(`Char ${i}: ${JSON.stringify(char)} (${char.charCodeAt(0)}) - Letter: ${/\p{L}/u.test(char)}, Apostrophe: ${char === "'"}`);
}

// Test the regex directly
const namePattern = /^[\p{L}](?:[\p{L}\p{M}'\-\s]*[\p{L}\p{M}])?$/u;
console.log(`Pattern test: ${namePattern.test(testName)}`);
console.log(`Pattern test with trim: ${namePattern.test(testName.trim())}`);

// Test with actual function
console.log(`Function result: ${isValidName(testName)}`);

// Test individual parts
console.log('\nTesting regex parts:');
console.log(`First char test: ${/^[\p{L}]/u.test(testName)}`);
console.log(`Full pattern test: ${namePattern.test(testName)}`);
console.log(`Contains digit: ${/\d/.test(testName)}`);
console.log(`Contains symbols: ${/[!@#$%^&*()_+=[{};':"\\|,.<>/?`~]/.test(testName)}`);