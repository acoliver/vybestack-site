// Test edge cases for regex challenge functions
import * as validators from './dist/src/validators.js';
import * as transformations from './dist/src/transformations.js';
import * as puzzles from './dist/src/puzzles.js';

console.log('Testing isValidName with tricky cases:');
const nameTests = [
  'Jane Doe',          // should pass
  'José María',        // should pass (accents)
  'O\'Brien',          // should pass (apostrophe)
  'Smith-Jones',       // should pass (hyphen)
  'X Æ A-12',          // should fail (gibberish)
  'John123',           // should fail (digits)
  'John@Doe',          // should fail (symbols)
  '',                  // should fail (empty)
  '   ',               // should fail (whitespace only)
  'A',                 // should pass (single letter)
  'Zürich',            // should pass (unicode)
];

nameTests.forEach(name => {
  const result = validators.isValidName(name);
  console.log(`${name}: ${result ? 'PASS' : 'FAIL'}`);
});

console.log('\nTesting isValidEmail with edge cases:');
const emailTests = [
  'user@example.com',
  'name+tag@example.co.uk',
  'user@@example.com',     // should fail
  'user@example..com',     // should fail
  'user@domain_with_underscore.com', // should fail
];

emailTests.forEach(email => {
  const result = validators.isValidEmail(email);
  console.log(`${email}: ${result ? 'PASS' : 'FAIL'}`);
});

console.log('\nTesting isValidUSPhone:');
const usPhoneTests = [
  '(212) 555-7890',
  '212-555-7890',
  '2125557890',
  '+1 212-555-7890',
  '012-555-7890',  // should fail (area code 012)
  '123-456-7890',  // should fail (area code 123)
];

usPhoneTests.forEach(phone => {
  const result = validators.isValidUSPhone(phone);
  console.log(`${phone}: ${result ? 'PASS' : 'FAIL'}`);
});

console.log('\nTesting isValidArgentinePhone:');
const argPhoneTests = [
  '+54 9 11 1234 5678',
  '011 1234 5678',
  '+54 341 123 4567',
  '0341 4234567',
  '1234 5678',     // should fail (no area code)
  '+54 11 1234',   // should fail (too few digits)
];

argPhoneTests.forEach(phone => {
  const result = validators.isValidArgentinePhone(phone);
  console.log(`${phone}: ${result ? 'PASS' : 'FAIL'}`);
});

console.log('\nTesting capitalizeSentences:');
const sentenceTests = [
  'hello world. how are you?',
  'no space.after.period',
  'multiple   spaces   between   words',
  'u.s.a. is an abbreviation',
];

sentenceTests.forEach(text => {
  const result = transformations.capitalizeSentences(text);
  console.log(`"${text}" -> "${result}"`);
});

console.log('\nTesting extractUrls:');
const urlTests = [
  'Visit http://example.com today',
  'Check out https://example.com/path?query=value',
  'Multiple URLs: http://a.com and https://b.com.',
];

urlTests.forEach(text => {
  const result = transformations.extractUrls(text);
  console.log(`"${text}" -> ${JSON.stringify(result)}`);
});

console.log('\nTesting rewriteDocsUrls:');
const docsUrlTests = [
  'http://example.com/docs/guide',
  'http://example.com/docs/api/v1',
  'http://example.com/docs/index.jsp',  // should skip host rewrite
  'http://example.com/other/path',
];

docsUrlTests.forEach(text => {
  const result = transformations.rewriteDocsUrls(text);
  console.log(`"${text}" -> "${result}"`);
});

console.log('\nTesting isStrongPassword:');
const passwordTests = [
  'Password123!',           // should pass
  'Weak1!',                 // should fail (too short)
  'noUpperCase123!',        // should fail (no uppercase)
  'NOLOWERCASE123!',        // should fail (no lowercase)
  'NoNumbers!',             // should fail (no numbers)
  'NoSymbols123',           // should fail (no symbols)
  'has spaces 123!',        // should fail (has spaces)
  'abab12345!',             // should fail (repeated sequence)
  'PerfectPassword123!',    // should pass
];

passwordTests.forEach(pw => {
  const result = puzzles.isStrongPassword(pw);
  console.log(`${pw}: ${result ? 'PASS' : 'FAIL'}`);
});

console.log('\nTesting isValidCreditCard:');
const ccTests = [
  '4111111111111111',  // Visa test number
  '5555555555554444',  // Mastercard test number
  '378282246310005',   // AmEx test number
  '1234567890123456',  // Invalid number
];

ccTests.forEach(cc => {
  const result = validators.isValidCreditCard(cc);
  console.log(`${cc}: ${result ? 'PASS (valid Luhn)' : 'FAIL (invalid)'}`);
});