/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
  }
  
  // Observer for re-computing when dependencies change
  const o: Observer<T> = {
    name: options?.name,
    value: value as T,
    updateFn: () => {
      // Re-compute fresh without using previous value
      // This ensures we get the current state of dependencies
      const newValue = updateFn()
      const oldValue = s.value
      s.value = newValue
      
      // If the value changed, trigger dependent observers
      if (newValue !== oldValue && s.observer) {
        updateObserver(s.observer as Observer<unknown>)
      }
      
      return newValue
    },
  }
  
  const read: GetterFn<T> = () => {
    // Set this observer as active during dependency collection
    updateObserver(o)
    return s.value
  }
  
  return read
}