import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  setActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === false) return undefined
  if (typeof equal === 'function') return equal
  if (equal === true || equal === undefined) return (a, b) => a === b
  return undefined
}

function hasUpdateFn(obj: unknown): obj is Observer<unknown> {
  return typeof (obj as Observer<unknown>).updateFn === 'function'
}

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: createEqualFn(equal),
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const active = getActiveObserver()
    if (active) {
      s.observers = s.observers || new Set()
      s.observers.add(active)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldVal = s.value
    s.value = nextValue
    
    const changed = s.equalFn ? !s.equalFn(oldVal, s.value) : oldVal !== s.value
    if (changed && s.observers) {
      const observers = Array.from(s.observers)
      observers.forEach(observer => {
        if (hasUpdateFn(observer)) {
          const previous = getActiveObserver()
          setActiveObserver(observer)
          try {
            observer.value = observer.updateFn(observer.value)
          } finally {
            setActiveObserver(previous)
          }
        }
      })
    }
    
    return s.value
  }

  return [read, write]
}