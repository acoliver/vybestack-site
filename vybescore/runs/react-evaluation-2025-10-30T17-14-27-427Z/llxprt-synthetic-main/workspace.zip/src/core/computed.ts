import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  setActiveObserver,
  getActiveObserver,
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  let recomputed = false
  
  const compute = () => {
    if (recomputed) return
    const previousActive = getActiveObserver()
    setActiveObserver(observer)
    try {
      observer.value = updateFn(observer.value)
      recomputed = true
    } finally {
      setActiveObserver(previousActive)
    }
  }
  
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      const subject = { observers: new Set() } as { observers: Set<unknown> }
      if (!subject.observers.has(observer)) {
        subject.observers.add(observer)
      }
      
      compute()
    }
    
    if (!recomputed || observer.value === undefined) {
      compute()
    }
    
    return observer.value!
  }
  
  return getter
}