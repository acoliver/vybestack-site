/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Set<ObserverR>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T> & {
  observers?: Set<ObserverR>
}

export let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return (globalThis as { _activeObserver?: ObserverR })._activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  (globalThis as { _activeObserver?: ObserverR })._activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(previous)
  }
}

export function addDependency(subject: Subject<unknown>): void {
  const active = getActiveObserver()
  if (active) {
    subject.observers = subject.observers || new Set()
    subject.observers.add(active)
  }
}

export function notifyObservers<T>(subject: Subject<T>, newValue?: T): void {
  if (newValue !== undefined) {
    const shouldNotify = subject.equalFn ? 
      !subject.equalFn(subject.value, newValue) : 
      subject.value !== newValue
    
    if (!shouldNotify) return
    
    subject.value = newValue
  }

  if (subject.observers) {
    const observers = Array.from(subject.observers)
    observers.forEach(observer => {
      if ((observer as Observer<unknown>).updateFn) {
        updateObserver(observer as Observer<unknown>)
      }
    })
  }
}