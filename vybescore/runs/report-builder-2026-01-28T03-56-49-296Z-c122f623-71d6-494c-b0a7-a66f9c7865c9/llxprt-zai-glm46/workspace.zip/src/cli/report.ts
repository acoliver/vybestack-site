#!/usr/bin/env node
/**
 * Report Builder CLI
 *
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import * as fs from 'node:fs';
import { getFormatter } from '../formats/index.js';
import { validateReportData } from '../utils.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parses command line arguments
 */
function parseArgs(args: string[]): CliArgs {
  const positional: string[] = [];
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      positional.push(arg);
    }
  }

  if (positional.length !== 1) {
    throw new Error('Expected exactly one input file path');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return {
    inputFile: positional[0],
    format,
    outputPath,
    includeTotals,
  };
}

/**
 * Reads and parses JSON from a file
 */
function readJsonFile(filePath: string): unknown {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

/**
 * Main entry point
 */
function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Read and parse input file
    const rawData = readJsonFile(args.inputFile);
    const data = validateReportData(rawData);

    // Get the appropriate formatter
    const formatter = getFormatter(args.format);

    // Render the report
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    const output = formatter(data, options);

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
