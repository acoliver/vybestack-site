/**
 * Markdown format renderer for reports
 */

import { formatCurrency, calculateTotal } from '../utils.js';
import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';

export const renderMarkdown: ReportRenderer = (data: ReportData, options: RenderOptions) => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);

  // Blank line
  lines.push('');

  // Summary
  lines.push(data.summary);

  // Blank line
  lines.push('');

  // Entries heading
  lines.push('## Entries');

  // Entries list
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatCurrency(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    const total = calculateTotal(data);
    lines.push(`**Total:** ${formatCurrency(total)}`);
  }

  return lines.join('\n');
};
