/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  const read: GetterFn<T> = () => {
    // Track dependency when being observed
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all observers of the change
    const observers = Array.from(s.observers)
    observers.forEach(observer => {
      if (observer && 'updateFn' in observer) {
        updateObserver(observer as Observer<unknown>)
      }
    })
    
    return s.value
  }

  return [read, write]
}
