/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const disposed = false
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue?: T) => {
      if (disposed) return currentValue!
      // Don't pass the previous computed value to preserve default parameters
      return updateFn(undefined)
    },
  }
  
  // Initial evaluation
  o.value = updateFn(undefined)
  
  return (): T => {
    if (disposed) return o.value!
    
    // Re-evaluate without passing the cached value
    o.value = updateFn(undefined)
    return o.value!
  }
}
