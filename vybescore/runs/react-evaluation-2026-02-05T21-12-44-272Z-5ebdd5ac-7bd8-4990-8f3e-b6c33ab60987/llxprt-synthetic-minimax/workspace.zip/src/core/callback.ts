/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const disposed = { current: false }
  
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      if (disposed.current) return currentValue!
      return updateFn(currentValue)
    },
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  return () => {
    disposed.current = true
    observer.value = undefined
    observer.updateFn = () => undefined!
  }
}
