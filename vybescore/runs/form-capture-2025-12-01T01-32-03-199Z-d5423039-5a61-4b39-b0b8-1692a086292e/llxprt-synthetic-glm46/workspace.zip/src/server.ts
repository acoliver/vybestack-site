import express from 'express';
import { getDatabase, saveDatabase, closeDatabase } from './database.js';
import { validateForm, FormInput } from './validation.js';

const app = express();
const port = process.env.PORT || 3535;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', './src/templates');

app.get('/', async (req, res) => {
  try {
    res.render('form', {
      errors: {},
      values: {},
      title: 'Friendly Contact Form'
    });
  } catch (error) {
    console.error('Error rendering form:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.post('/submit', async (req, res) => {
  try {
    const formData: FormInput = req.body;
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      res.status(400).render('form', {
        errors: validation.errors,
        values: formData,
        title: 'Friendly Contact Form'
      });
      return;
    }
    
    const db = await getDatabase();
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.first_name,
      formData.last_name,
      formData.street_address,
      formData.city,
      formData.state_province,
      formData.postal_code,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    await saveDatabase();
    
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/thank-you', async (req, res) => {
  try {
    res.render('thank-you', {
      title: 'Thank You!'
    });
  } catch (error) {
    console.error('Error rendering thank you page:', error);
    res.status(500).send('Internal Server Error');
  }
});

const server = app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

const gracefulShutdown = async (signal: string) => {
  console.log(`Received ${signal}, shutting down gracefully`);
  server.close(async () => {
    console.log('Express server closed');
    closeDatabase();
    console.log('Database closed');
    process.exit(0);
  });
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));