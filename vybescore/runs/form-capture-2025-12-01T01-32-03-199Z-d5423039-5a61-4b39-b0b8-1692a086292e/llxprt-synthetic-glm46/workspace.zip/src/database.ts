import fs from 'fs';
import path from 'path';
// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import initSqlJs, { Database as SqliteDatabase } from 'sql.js';

// Use non-null assertion operator since we check for null in all operations
let db: SqliteDatabase | null = null;

export const getDatabase = async (): Promise<SqliteDatabase> => {
  if (db) {
    return db;
  }

  const SQL = await initSqlJs();
  const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  
  try {
    const data = fs.readFileSync(dbPath);
    db = new SQL.Database(data);
  } catch (error) {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
    db.run(schema);
  }
  
  return db!;
};

export const saveDatabase = async (): Promise<void> => {
  if (!db) {
    return;
  }
  
  const data = db.export();
  const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  
  // Ensure data directory exists
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  fs.writeFileSync(dbPath, Buffer.from(data));
};

export const closeDatabase = (): void => {
  if (db) {
    db.close();
    db = null;
  }
};

export const insertSubmission = (submission: Record<string, string>): void => {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    submission.first_name,
    submission.last_name,
    submission.street_address,
    submission.city,
    submission.state_province,
    submission.postal_code,
    submission.country,
    submission.email,
    submission.phone
  ]);
  
  stmt.free();
};