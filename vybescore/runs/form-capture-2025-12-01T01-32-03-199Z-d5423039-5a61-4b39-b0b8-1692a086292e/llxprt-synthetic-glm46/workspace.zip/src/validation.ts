export interface FormInput {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationError {
  [key: string]: string;
}

export const validateForm = (formData: FormInput): { isValid: boolean; errors: ValidationError } => {
  const errors: ValidationError = {};
  
  if (!formData.first_name.trim()) {
    errors.first_name = 'First name is required';
  }
  
  if (!formData.last_name.trim()) {
    errors.last_name = 'Last name is required';
  }
  
  if (!formData.street_address.trim()) {
    errors.street_address = 'Street address is required';
  }
  
  if (!formData.city.trim()) {
    errors.city = 'City is required';
  }
  
  if (!formData.state_province.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }
  
  if (!formData.postal_code.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  }
  
  if (!formData.country.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!formData.email.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!formData.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!/^[+\d\s\-()]+$/.test(formData.phone)) {
    errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};