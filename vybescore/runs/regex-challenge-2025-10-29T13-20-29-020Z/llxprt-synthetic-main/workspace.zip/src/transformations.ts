/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split the text into sentences using sentence terminators
  // Then capitalize the first character of each sentence
  let processedText = text.replace(/(^|[.!?]\s*)([a-z])/g, (_, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Ensure exactly one space after sentence terminators
  processedText = processedText.replace(/\.\s*/g, '. ');
  processedText = processedText.replace(/\?\s*/g, '? ');
  processedText = processedText.replace(/!\s*/g, '! ');
  
  // Trim trailing space
  processedText = processedText.trimEnd();
  
  return processedText;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Comprehensive URL regex that matches http/https/ftp and other protocols
  // Also matches URLs starting with www
  const urlRegex = /\b((?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+)/gi;
  
  const urls: string[] = [];
  const matches = text.match(urlRegex);
  
  if (!matches) return urls;
  
  for (const match of matches) {
    // Remove trailing punctuation, brackets, quotes, etc.
    let cleanUrl = match;
    cleanUrl = cleanUrl.replace(/[.,;:!?)]+$/, ''); // Remove trailing punctuation
    cleanUrl = cleanUrl.replace(/([^\[])\[+$/, '$1'); // Remove trailing brackets
    cleanUrl = cleanUrl.replace(/"+$/, ''); // Remove trailing quotes
    
    // Add protocol if missing (for www URLs)
    if (cleanUrl.startsWith('www.') && !cleanUrl.startsWith('http')) {
      cleanUrl = 'https://' + cleanUrl;
    }
    
    urls.push(cleanUrl);
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://, but be careful not to affect https://
  // This regex matches http:// only if not followed by another s (to avoid https://)
  const httpToHttpsRegex = /\bhttp:\/\//gi;
  
  return text.replace(httpToHttpsRegex, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Using a different approach to ensure proper replacement
  const result = text.replace(/http:\/\/example\.com\/docs/gi, 'https://docs.example.com/docs');
  const result2 = result.replace(/http:\/\/example\.com\/(?!docs)/gi, 'https://example.com/');
  
  return result2;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Regex to match mm/dd/yyyy format
  // Captures: (1) month, (2) day, (3) year
  const dateRegex = /(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year: string = match[3];
  
  // Check if the day is valid for the month
  let maxDaysInMonth;
  if (month === 2) {
    // Special handling for February (leap years)
    const yearNum = parseInt(year, 10);
    maxDaysInMonth = ((yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0) ? 29 : 28;
  } else if (month === 4 || month === 6 || month === 9 || month === 11) {
    maxDaysInMonth = 30;
  } else {
    maxDaysInMonth = 31;
  }
  
  if (day > maxDaysInMonth) {
    return 'N/A';
  }
  
  return year;
}