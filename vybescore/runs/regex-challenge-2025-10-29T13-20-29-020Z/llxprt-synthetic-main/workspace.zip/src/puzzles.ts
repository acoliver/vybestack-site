/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create word boundary regex pattern from prefix
  // \b matches word boundary, prefix is escaped to handle special regex chars
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const prefixedWordRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  // Find all words starting with the prefix
  const matches = text.match(prefixedWordRegex);
  if (!matches) return [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  const filtered = matches.filter(word => !exceptionSet.has(word.toLowerCase()));
  
  // Return unique words
  return [...new Set(filtered)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match token only when it's preceded by a digit and not at the start of string
  // Use a pattern that captures the digit and token together
  const tokenRegex = new RegExp(`(\\d${escapedToken})`, 'gi');
  
  const matches = text.match(tokenRegex);
  return matches ? [...matches] : [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for repeated patterns anywhere in the string (like abcabcxyz)
  const repeatedSequenceRegex = /(.{3,})\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv4 regex to match and exclude IPv4 addresses
  const ipv4Regex = /\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If the string contains an IPv4 address, return false (we're only looking for IPv6)
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // IPv6 regex patterns to match various IPv6 formats
  // Full IPv6: 8 groups of 4 hex digits
  const fullIPv6Regex = /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand, must have at least 2 colon-separated groups
  const shorthandIPv6Regex = /\b([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with embedded IPv4 (e.g., ::ffff:192.0.2.128)
  const embeddedIPv4Regex = /\b([0-9a-fA-F]{1,4}:){1,4}:(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // IPv6 with port (e.g., [2001:db8::1]:8080)
  const ipv6WithPortRegex = /\[([0-9a-fA-F:]+)\]/;
  
  const hasIPv6 = fullIPv6Regex.test(value) || 
                 shorthandIPv6Regex.test(value) || 
                 embeddedIPv4Regex.test(value) ||
                 ipv6WithPortRegex.test(value);
  
  return hasIPv6;
}