export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email format validation with enhanced checks
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for invalid patterns
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots in local part or domain
  const [localPart, domain] = value.split('@');
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject dots at beginning of local part or domain
  if (localPart.startsWith('.') || domain.startsWith('.')) {
    return false;
  }
  
  // Ensure at least one dot in domain (for TLD)
  if (!domain.includes('.') || domain.split('.').length < 2) {
    return false;
  }
  
  // Check domain segments don't start/end with hyphens
  const domainSegments = domain.split('.');
  for (const segment of domainSegments) {
    if (segment.startsWith('-') || segment.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all separators (spaces, hyphens, parentheses, dots)
  const cleaned = value.replace(/[\s\-().]/g, '');
  
  // Check for optional +1 country code
  const hasCountryCode = cleaned.startsWith('+1');
  const digits = hasCountryCode ? cleaned.substring(2) : cleaned;
  
  // Must have 10 digits for a valid US phone number (area code + number)
  if (digits.length !== 10) {
    return false;
  }
  
  // All characters must be digits
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Area code validation: first digit cannot be 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate the original format allows proper common patterns
  // Support formats like: (212) 555-7890, 212-555-7890, 2125557890, +1 2125557890
  const validFormats = [
    /^\(\d{3}\)\s?\d{3}[-.\s]?\d{4}$/, // (xxx) xxx-xxxx etc.
    /^\d{3}[-.\s]\d{3}[-.\s]\d{4}$/,    // xxx-xxx-xxxx etc.
    /^\d{10}$/,                         // 10 consecutive digits
    /^\+1\s?\d{10}$/,                   // +1 followed by 10 digits
    /^\+1\s?\(\d{3}\)\s?\d{3}[-.\s]?\d{4}$/, // +1 (xxx) xxx-xxxx etc.
    /^\+1\s?\d{3}[-.\s]\d{3}[-.\s]\d{4}$/   // +1 xxx-xxx-xxxx etc.
  ];
  
  // Check if the original format matches one of the valid patterns
  const isValidFormat = validFormats.some(format => format.test(value));
  
  return isValidFormat;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators (spaces, hyphens) for validation but keep track of structure
  const cleaned = value.replace(/[\s\-]/g, '');
  
  // Comprehensive regex for Argentine phone numbers
  // Pattern breakdown:
  // ^(?:\+54)? - Optional +54 country code
  // (?:0)? - Optional trunk prefix 0
  // (?:9)? - Optional mobile indicator 9
  // (\d{2,4}) - Area code (2-4 digits, first digit 1-9)
  // (\d{6,8}) - Subscriber number (6-8 digits)
  // $ - End of string
  const argPhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // More specific validation to enforce rules about structure
  const withCountryCodeRegex = /^\+54(?:0)?(?:9)?[1-9]\d{1,3}\d{6,8}$/;
  const withoutCountryCodeRegex = /^0(?:9)?[1-9]\d{1,3}\d{6,8}$/;
  
  // Check that when country code is omitted, number begins with trunk prefix
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  // Use appropriate regex based on presence of country code
  const isValidFormat = cleaned.startsWith('+54') 
    ? withCountryCodeRegex.test(cleaned)
    : withoutCountryCodeRegex.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Additional validation with full regex
  const match = argPhoneRegex.exec(cleaned);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || !/^[1-9]/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Unicode-aware name validation
  // \p{L} matches any unicode letter
  // \p{M} matches marks like accents
  // Allow spaces, apostrophes, and hyphens between name parts
  const nameRegex = /^[\p{L}\p{M}]+(?:['\s-][\p{L}\p{M}]+)*$/u;
  
  // Basic format check
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with too many special characters
  const specialCharCount = (value.match(/['\s-]/g) || []).length;
  const letterCount = (value.match(/\p{L}/gu) || []).length;
  
  // Too many special characters relative to letters indicates invalid name
  if (specialCharCount >= letterCount) {
    return false;
  }
  
  // Reject consecutive special characters (except for spaces after apostrophes/hyphens)
  if (value.includes('--') || value.includes("''")) {
    return false;
  }
  
  // Reject names with leading or trailing spaces, apostrophes, or hyphens
  if (/^[\s'-]|[\s'-]$/.test(value)) {
    return false;
  }
  
  // Reject names that look like "X Æ A-12" style names (has digits mixed with special chars)
  if (/[\p{L}]\s*[ÆØÅ]\s*[\p{L}]/u.test(value)) {
    return false;
  }
  
  return true;
}

// Helper function for Luhn algorithm checksum
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;

  // Start from rightmost digit
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);

    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        sum += (digit % 10) + 1;
      } else {
        sum += digit;
      }
    } else {
      sum += digit;
    }

    doubleDigit = !doubleDigit;
  }

  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens from the input
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Validate Visa, Mastercard, and AmEx
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // American Express: 15 digits, starts with 34 or 37
  
  const visaRegex = /^4\d{12}(?:\d{3})?$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5]\d{14}|^(2221|2720)\d{12}$/; // Starts with 51-55 or 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits starting with 34 or 37
  
  let isValidLengthAndPrefix = false;
  
  if (visaRegex.test(cleaned)) {
    // Visa: 13 or 16 digits
    isValidLengthAndPrefix = (cleaned.length === 13 || cleaned.length === 16);
  } else if (mastercardRegex.test(cleaned)) {
    // Mastercard: 16 digits
    isValidLengthAndPrefix = cleaned.length === 16;
  } else if (amexRegex.test(cleaned)) {
    // American Express: 15 digits
    isValidLengthAndPrefix = cleaned.length === 15;
  }
  
  if (!isValidLengthAndPrefix) {
    return false;
  }
  
  // Run Luhn algorithm
  return runLuhnCheck(cleaned);
}
