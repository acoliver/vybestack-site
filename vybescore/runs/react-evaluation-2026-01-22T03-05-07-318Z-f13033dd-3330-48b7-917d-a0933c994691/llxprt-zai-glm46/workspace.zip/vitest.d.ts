/// <reference types="vitest/globals" />

declare module 'vitest' {
  export { describe, it, expect } from 'vitest'
}
