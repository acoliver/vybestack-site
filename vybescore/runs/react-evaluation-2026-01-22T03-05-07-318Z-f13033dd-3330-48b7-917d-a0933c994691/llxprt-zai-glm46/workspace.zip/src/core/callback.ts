/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    __subjects: new Set(),
  }
  
  // Execute initially to set up dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects it depends on
    const subjects = observer.__subjects
    if (subjects) {
      // Create a copy to avoid modification during iteration
      const subjectsArray = Array.from(subjects)
      subjectsArray.forEach(subject => {
        const observers = (subject as any).__observers as Set<any> | undefined
        if (observers) {
          observers.delete(observer)
        }
      })
      subjects.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
