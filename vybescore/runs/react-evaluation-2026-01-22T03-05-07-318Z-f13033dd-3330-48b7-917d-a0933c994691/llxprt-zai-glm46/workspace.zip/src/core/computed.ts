/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Default equality function using Object.is.
 */
function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return Object.is(lhs, rhs)
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    __subjects: new Set(),
  }
  
  // Track observers that depend on this computed
  const dependentObservers = new Set<Observer<any>>()
  
  // Compute initial value
  updateObserver(o)
  
  // Create getter that registers dependencies and tracks dependents
  const getter = (): T => {
    const activeObserver = getActiveObserver()
    
    // If we're being observed, register this computed with the active observer
    if (activeObserver) {
      if (!activeObserver.__subjects) {
        activeObserver.__subjects = new Set()
      }
      activeObserver.__subjects.add(o)
      
      // Track the active observer as dependent on this computed
      dependentObservers.add(activeObserver as Observer<any>)
    }
    
    return o.value!
  }
  
  // Store getter on observer
  ;(o as any).__getter = getter
  
  // Override updateFn to propagate updates
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    // Recompute value
    const result = originalUpdateFn(prevValue)
    
    // After recomputing, notify all dependent observers
    dependentObservers.forEach(obs => {
      // Only update if this observer still depends on us (checked after recompute)
      if (obs.__subjects?.has(o)) {
        updateObserver(obs)
      }
    })
    
    return result
  }
  
  return getter
}
