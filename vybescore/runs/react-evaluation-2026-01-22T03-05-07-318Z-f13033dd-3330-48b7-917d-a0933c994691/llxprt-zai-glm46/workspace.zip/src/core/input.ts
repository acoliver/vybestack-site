/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Default equality function using Object.is.
 */
function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return Object.is(lhs, rhs)
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Convert boolean to equal function, otherwise use provided function or undefined
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = defaultEqual
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else {
    equalFn = undefined
  }
  
  // Support multiple observers
  const observers = new Set<ObserverR>()
  
  const s: Subject<T> = {
    name: options?.name,
    __observers: observers,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this subject with the active observer
      if (!observer.__subjects) {
        observer.__subjects = new Set()
      }
      observer.__subjects.add(s)
      
      // Register the observer with this subject
      observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Skip update if value hasn't changed and equality check is enabled
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers to update (create a copy to avoid modification issues)
    const observersArray = Array.from(observers)
    observersArray.forEach(obs => {
      updateObserver(obs as Observer<unknown>)
    })
    
    return s.value
  }

  return [read, write]
}
