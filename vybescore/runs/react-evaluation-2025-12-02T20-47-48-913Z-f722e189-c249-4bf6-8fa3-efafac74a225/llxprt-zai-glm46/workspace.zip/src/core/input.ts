/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

let updateDepth = 0

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add this subject to observer's dependencies
      const currentObserver = observer as Observer<unknown>
      if (!currentObserver.dependencies) {
        currentObserver.dependencies = []
      }
      currentObserver.dependencies.push(s as Subject<unknown>)
      
      // Register this observer with the subject
      if (!s.observers) {
        s.observers = []
      }
      if (!s.observers.includes(currentObserver)) {
        s.observers.push(currentObserver)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = s.equalFn ? !s.equalFn(s.value, nextValue) : s.value !== nextValue
    if (shouldUpdate && updateDepth === 0) {
      s.value = nextValue
      
      updateDepth++
      try {
        // Notify all observers that depend on this subject
        if (s.observers) {
          const observers = [...s.observers]
          observers.forEach(observer => {
            if (!(observer as Observer<unknown>).disposed) {
              // Re-compute the observer
              const obs = observer as Observer<unknown>
              const previous = getActiveObserver()
              
              // Set this observer as active to track its dependencies
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              ;(globalThis as any).__activeObserver = obs
              obs.dependencies = []
              
              try {
                obs.value = obs.updateFn(obs.value)
              } finally {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                ;(globalThis as any).__activeObserver = previous
              }
              
              // Recursively notify dependents
              if (obs.dependents) {
                obs.dependents.forEach(dep => {
                  if (!dep.disposed) {
                    // Call the dependent's update function
                    const dependentObserver = dep as Observer<unknown>
                    if (dependentObserver.updateFn) {
                      dependentObserver.value = dependentObserver.updateFn(dependentObserver.value)
                    }
                  }
                })
              }
            }
          })
        }
      } finally {
        updateDepth--
      }
    }
    return s.value
  }

  return [read, write]
}
