/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    disposed: false,
    dependencies: []
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  return (): void => {
    observer.disposed = true
    observer.value = undefined
    observer.updateFn = () => value!
    observer.dependencies = []
  }
}
