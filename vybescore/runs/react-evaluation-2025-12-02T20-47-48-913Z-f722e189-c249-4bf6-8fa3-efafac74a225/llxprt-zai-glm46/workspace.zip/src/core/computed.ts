/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: [],
    dependents: [],
    disposed: false
  }
  
  // Initialize with initial computation
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && observer !== o) {
      // Another observer depends on this computed value
      const currentObserver = observer as Observer<unknown>
      if (!o.dependents) {
        o.dependents = []
      }
      if (!o.dependents.includes(currentObserver)) {
        o.dependents.push(currentObserver)
      }
    }
    
    return o.value!
  }
  
  return getter
}
