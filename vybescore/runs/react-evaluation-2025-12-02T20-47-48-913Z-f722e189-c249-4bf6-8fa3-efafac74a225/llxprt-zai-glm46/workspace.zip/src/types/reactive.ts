/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependencies?: Subject<unknown>[]
  dependents?: Observer<unknown>[]
  disposed?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Subject<unknown>[]
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T> & {
  observers?: Observer<unknown>[]
}

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export { activeObserver }

let updateDepth = 0

export function getUpdateDepth(): number {
  return updateDepth
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (observer.disposed) return
  
  const previous = activeObserver
  activeObserver = observer
  
  // Store previous dependencies before clearing
  const oldDependencies = observer.dependencies || []
  observer.dependencies = []
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // Find new dependencies and set up reverse relationships
  oldDependencies.forEach(dep => {
    // Remove this observer from old dependencies
    if (dep.observers) {
      dep.observers = dep.observers.filter(obs => obs !== observer)
    }
  })
}

export function notifyUpdate<T>(observer: Observer<T>): void {
  if (observer.disposed || updateDepth > 0) return
  
  updateDepth++
  try {
    // Re-compute the observer value
    const previous = activeObserver
    activeObserver = observer
    observer.dependencies = []
    
    try {
      observer.value = observer.updateFn(observer.value)
    } finally {
      activeObserver = previous
    }
    
    // Notify dependent observers
    if (observer.dependents) {
      const dependents = [...observer.dependents]
      dependents.forEach(depObserver => {
        if (!depObserver.disposed) {
          notifyUpdate(depObserver as Observer<unknown>)
        }
      })
    }
  } finally {
    updateDepth--
  }
}

export function notifyObservers(subject: Subject<unknown>): void {
  if (subject.observers) {
    subject.observers.forEach(observer => {
      updateObserver(observer as Observer<unknown>)
    })
  }
}
