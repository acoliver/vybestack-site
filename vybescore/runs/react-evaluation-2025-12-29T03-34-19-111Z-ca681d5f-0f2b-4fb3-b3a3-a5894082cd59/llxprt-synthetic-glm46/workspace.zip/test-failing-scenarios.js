// Test the failing scenarios from the comprehensive tests

// Simplified reactive system implementation
let activeObserver = null

function getActiveObserver() {
  return activeObserver
}

function setActiveObserver(observer) {
  activeObserver = observer
}

function clearActiveObserver() {
  activeObserver = null
}

function updateObserver(observer) {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

const observerGraph = new WeakMap()
const subjectGraph = new WeakMap()

function registerDependency(observer, subject) {
  if (!observer) return
  
  let subjects = observerGraph.get(observer)
  if (!subjects) {
    subjects = new Set()
    observerGraph.set(observer, subjects)
  }
  subjects.add(subject)
  
  let observers = subjectGraph.get(subject)
  if (!observers) {
    observers = new Set()
    subjectGraph.set(subject, observers)
  }
  observers.add(observer)
}

function updateSubject(subject) {
  const observers = subjectGraph.get(subject)
  if (!observers) return

  observers.forEach(observer => {
    const previous = activeObserver
    activeObserver = observer
    try {
      updateObserver(observer)
    } finally {
      activeObserver = previous
    }
  })
}

function createInput(value) {
  const subject = {
    value,
    observer: undefined
  }

  const read = () => {
    const observer = getActiveObserver()
    if (observer) {
      subject.observer = observer
      registerDependency(observer, subject)
    }
    return subject.value
  }

  const write = (nextValue) => {
    if (subject.value === nextValue) {
      return subject.value
    }
    
    subject.value = nextValue
    updateSubject(subject)
    return subject.value
  }

  return [read, write]
}

function createComputed(updateFn) {
  const observer = {
    value: undefined,
    updateFn: (currentValue) => {
      const previousObserver = getActiveObserver()
      setActiveObserver(observer)
      
      try {
        const newValue = updateFn(currentValue)
        return newValue
      } finally {
        if (previousObserver) {
          setActiveObserver(previousObserver)
        } else {
          clearActiveObserver()
        }
      }
    }
  }
  
  updateObserver(observer)
  
  return () => {
    return observer.value
  }
}

console.log('=== Test 1: compute cells can depend on other compute cells ===')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial sum:', sum()) // Should be 32
setInput(3)
console.log('After setInput(3), sum:', sum()) // Should be 96

console.log('\n=== Test 2: compute cells fire callbacks ===')
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0

// Create callback (skipping for this test - focus on computed)
setInput2(3)
console.log('After setInput2(3), output:', output()) // Should be 4, value should be 4

console.log('\n=== Test completed ===')