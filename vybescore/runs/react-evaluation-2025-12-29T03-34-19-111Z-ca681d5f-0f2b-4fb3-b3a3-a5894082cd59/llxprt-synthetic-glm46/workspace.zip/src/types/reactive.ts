/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR): void {
  activeObserver = observer
}

export function clearActiveObserver(): void {
  activeObserver = undefined
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Global registry for observer tracking
const observerGraph = new WeakMap<ObserverR, Set<Subject<any>>>()
const subjectGraph = new WeakMap<Subject<any>, Set<ObserverR>>()

export function registerDependency<T>(observer: ObserverR | undefined, subject: Subject<T>): void {
  if (!observer) return
  
  let subjects = observerGraph.get(observer)
  if (!subjects) {
    subjects = new Set()
    observerGraph.set(observer, subjects)
  }
  if (!subjects.has(subject)) {
    subjects.add(subject as Subject<any>)
  }
  
  let observers = subjectGraph.get(subject as Subject<any>)
  if (!observers) {
    observers = new Set()
    subjectGraph.set(subject as Subject<any>, observers)
  }
  if (!observers.has(observer)) {
    observers.add(observer)
  }
}

export function updateSubject<T>(subject: Subject<T>): void {
  // Get all observers that depend on this subject
  const observers = subjectGraph.get(subject as Subject<any>)
  if (!observers) return

  // Notify all dependent observers
  const observersCopy = Array.from(observers)
  observersCopy.forEach(observer => {
    setActiveNotify(observer as Observer<T>)
  })
}

function setActiveNotify<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  
  try {
    updateObserver(observer)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (!subject.observer) return
  
  setActiveNotify(subject.observer as Observer<T>)
}
