/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  clearActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equality function parameter
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue?: T) => {
      // Set this computed as the active observer to track dependencies
      const previousObserver = getActiveObserver()
      setActiveObserver(o)
      
      try {
        const newValue = updateFn(currentValue)
        
        // Check if we should update based on equality function
        if (equalFn) {
          if (currentValue !== undefined && equalFn(currentValue, newValue)) {
            return currentValue // No change needed
          }
        }
        
        return newValue
      } finally {
        // Restore the previous active observer
        if (previousObserver) {
          setActiveObserver(previousObserver as ObserverR)
        } else {
          clearActiveObserver()
        }
      }
    },
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  return (): T => {
    const currentObserver = getActiveObserver()
    
    // If this computed is being accessed by another observer, mark as dependency
    if (currentObserver) {
      // This computed value depends on the current active observer
      // The dependency tracking is handled in the getter function
    }
    
    return o.value!
  }
}