// Test the reactive system with a simple scenario

// Create a simple reactive system
let activeObserver = null

function getActiveObserver() {
  return activeObserver
}

function setActiveObserver(observer) {
  activeObserver = observer
}

function clearActiveObserver() {
  activeObserver = null
}

function updateObserver(observer) {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Observer and Subject graph
const observerGraph = new WeakMap()
const subjectGraph = new WeakMap()

function registerDependency(observer, subject) {
  if (!observer) return
  
  let subjects = observerGraph.get(observer)
  if (!subjects) {
    subjects = new Set()
    observerGraph.set(observer, subjects)
  }
  subjects.add(subject)
  
  let observers = subjectGraph.get(subject)
  if (!observers) {
    observers = new Set()
    subjectGraph.set(subject, observers)
  }
  observers.add(observer)
}

function updateSubject(subject) {
  const observers = subjectGraph.get(subject)
  if (!observers) return

  observers.forEach(observer => {
    const previous = activeObserver
    activeObserver = observer
    try {
      updateObserver(observer)
    } finally {
      activeObserver = previous
    }
  })
}

function createInput(value) {
  const subject = {
    value,
    observer: undefined
  }

  const read = () => {
    const observer = getActiveObserver()
    if (observer) {
      subject.observer = observer
      registerDependency(observer, subject)
    }
    return subject.value
  }

  const write = (nextValue) => {
    if (subject.value === nextValue) {
      return subject.value
    }
    
    subject.value = nextValue
    updateSubject(subject)
    return subject.value
  }

  return [read, write]
}

function createComputed(updateFn) {
  const observer = {
    value: undefined,
    updateFn: (currentValue) => {
      const previousObserver = getActiveObserver()
      setActiveObserver(observer)
      
      try {
        const newValue = updateFn(currentValue)
        return newValue
      } finally {
        if (previousObserver) {
          setActiveObserver(previousObserver)
        } else {
          clearActiveObserver()
        }
      }
    }
  }
  
  updateObserver(observer)
  
  return () => {
    return observer.value
  }
}

console.log('=== Simple Reactive Test ===')

// Test 1: Basic input
const [input, setInput] = createInput(1)
console.log('Initial input:', input())

setInput(3)
console.log('After setInput(3):', input())

// Test 2: Simple computed
const double = createComputed(() => input() * 2)
console.log('Initial double:', double())

setInput(5)
console.log('After setInput(5):')
console.log('Input:', input())
console.log('Double:', double())

console.log('=== Test completed ===')