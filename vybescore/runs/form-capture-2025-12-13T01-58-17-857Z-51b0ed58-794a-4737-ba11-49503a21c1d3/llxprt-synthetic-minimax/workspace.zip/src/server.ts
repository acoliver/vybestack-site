import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import http from 'http';
import initSqlJs, { Database } from 'sql.js';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Database setup
let db: Database | null = null;

interface SubmissionData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
};

const validatePostalCode = (postalCode: string): boolean => {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
};

const validateForm = (data: SubmissionData): ValidationError[] => {
  const errors: ValidationError[] = [];

  // Required fields validation
  const requiredFields: (keyof SubmissionData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field]?.trim()) {
      errors.push({ field, message: `${field} is required` });
    }
  });

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }

  return errors;
};

// Database initialization
const initDatabase = async (): Promise<void> => {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
      }
    });

    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    let dbFile: Uint8Array | null = null;
    
    // Load existing database if it exists
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      dbFile = new Uint8Array(dbBuffer);
    }

    db = new SQL.Database(dbFile || undefined);
    
    // Initialize schema if needed
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    db.exec(schema);

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};

// Save database to file
const saveDatabase = (): void => {
  if (db) {
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
};

// Routes

// GET / - Render contact form
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    formData: {},
    title: 'Contact Us'
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  const formData: SubmissionData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    // Re-render form with errors
    return res.status(400).render('form', {
      errors,
      formData,
      title: 'Contact Us - Please Fix Errors'
    });
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect('/thank-you');
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Health check endpoint
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Global variable to store server instance
declare global {
  // eslint-disable-next-line no-var
  var server: http.Server | undefined;
}

// Graceful shutdown
const gracefulShutdown = (): void => {
  console.log('Starting graceful shutdown...');
  
  if (db) {
    db.close();
    console.log('Database connection closed');
  }
  
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
const startServer = async (): Promise<void> => {
  try {
    await initDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });

    // Store server reference for shutdown
    global.server = server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Export app for testing
export { app };

// Start the server
startServer();