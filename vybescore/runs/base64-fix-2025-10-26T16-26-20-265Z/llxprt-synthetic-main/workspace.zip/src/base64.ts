/**
 * Encode plain text to Base64 using the canonical RFC 4648 Base64 alphabet.
 * Includes proper padding ("=") as required by the specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using the canonical RFC 4648 Base64 alphabet.
 * Accepts valid Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Validate the input contains only Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Validate padding is only at the end and is correct
  if (input.includes('=')) {
    const paddingIndex = input.indexOf('=');
    const paddingPart = input.substring(paddingIndex);
    
    // All padding characters must be at the end
    if (!/^=+$/.test(paddingPart)) {
      throw new Error('Invalid Base64 input: padding characters are not at the end');
    }
    
    // Only 0, 1, or 2 padding characters are allowed
    if (paddingPart.length > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
  }

  try {
    const decoded = Buffer.from(input, 'base64').toString('utf8');
    
    // If the input contains non-Base64 characters, Buffer will silently replace them
    // So we need to re-encode the result and compare with the original to validate
    const reEncoded = Buffer.from(decoded, 'utf8').toString('base64');
    
    // Pad the re-encoded value to match the original input's length
    const paddedReEncoded = reEncoded.padEnd(input.length, '=');
    
    // Handle cases where padding characters might be missing in the re-encoded version
    // by checking if the original is a padded version of the re-encoded value
    if (!isValidBase64Padding(input, paddedReEncoded)) {
      throw new Error('Invalid Base64 input');
    }
    
    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Helper function to validate Base64 padding differences
 */
function isValidBase64Padding(original: string, reEncoded: string): boolean {
  // If they're exactly the same, it's valid
  if (original === reEncoded) {
    return true;
  }
  
  // If the original has padding and the re-encoded doesn't, check if removing padding from original matches
  if (original.includes('=') || reEncoded.includes('=')) {
    const originalWithoutPadding = original.replace(/=+$/, '');
    const reEncodedWithoutPadding = reEncoded.replace(/=+$/, '');
    
    // Check if the non-padded parts are equal
    // This handles cases where Node.js produces the minimal padding but the input has more padding
    return originalWithoutPadding === reEncodedWithoutPadding;
  }
  
  return false;
}
