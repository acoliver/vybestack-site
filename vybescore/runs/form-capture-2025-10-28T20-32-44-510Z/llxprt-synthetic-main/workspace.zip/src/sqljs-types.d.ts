/* eslint-disable @typescript-eslint/no-explicit-any */
declare module 'sql.js' {
  interface Database {
    export(): Uint8Array;
    run(sql: string, params?: any[]): any;
    prepare(sql: string): Statement;
    close(): void;
  }

  interface Statement {
    run(params?: any[]): any;
    free(): void;
  }

  function initSqlJs(): Promise<SqlJs>;

  class SqlJs {
    Database: DatabaseClass;
  }

  interface DatabaseClass {
    new(buffer?: Uint8Array): Database;
  }

  export { initSqlJs, Database, Statement };
}