import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer, stopServer, app } from '../../src/server.js';

beforeAll(async () => {
  await startServer();
});

afterAll(async () => {
  await stopServer();
});

const getTestAgent = () => {
  return request(app);
};

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await getTestAgent().get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check that form posts to /submit
    expect($('form[action="/submit"]')).toHaveLength(1);
    
    // Check for stylesheet link
    expect($('link[href="/public/styles.css"]')).toHaveLength(1);
  });

  it('validates required fields and shows errors', async () => {
    const response = await getTestAgent()
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      });
    
    // Should re-render form with errors
    expect(response.status).toBe(400);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    expect($('.error-list li').length).toBeGreaterThan(0);
  });

  it('validates email format', async () => {
    const response = await getTestAgent()
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1 555-123-4567'
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('email');
  });

  it('validates phone format', async () => {
    const response = await getTestAgent()
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'john@example.com',
        phone: 'invalid-phone!'
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText.toLowerCase()).toMatch(/phone/);
  });

  it('persists submission and redirects', async () => {
    const dbPath = path.resolve('data', 'submissions.sqlite');
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await getTestAgent()
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Avenue',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'jane@example.com',
        phone: '+44 20 7946 0958'
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('accepts international phone formats', async () => {
    const dbPath = path.resolve('data', 'submissions.sqlite');
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await getTestAgent()
      .post('/submit')
      .send({
        firstName: 'Carlos',
        lastName: 'Garcia',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'carlos@example.com',
        phone: '+54 9 11 1234-5678'
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('renders thank-you page', async () => {
    const response = await getTestAgent().get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    expect($('.thankyou-card').length).toBe(1);
    expect($('.thankyou-card h1').text()).toContain('Thank you');
    
    // Check for humorous/scam-warning text
    const bodyText = $('.thankyou-card').text().toLowerCase();
    expect(bodyText).toMatch(/stranger|internet|identity|spam/);
    
    // Check for link back to form
    expect($('a[href="/"]')).toHaveLength(1);
  });

  it('preserves form values on validation error', async () => {
    const formData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '789 Test St',
      city: 'Testville',
      stateProvince: 'TX',
      postalCode: '75001',
      country: 'USA',
      email: 'not-an-email',
      phone: '+1 555-999-8888'
    };
    
    const response = await getTestAgent()
      .post('/submit')
      .send(formData);
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    // Check that values are preserved
    expect($('input[name="firstName"]').val()).toBe('Test');
    expect($('input[name="lastName"]').val()).toBe('User');
    expect($('input[name="email"]').val()).toBe('not-an-email');
  });
});
