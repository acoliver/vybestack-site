import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

let db: Database | null = null;

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(data: Partial<FormData>): string[] {
  const errors: string[] = [];

  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push('First name is required.');
  }
  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push('Last name is required.');
  }
  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push('Street address is required.');
  }
  if (!data.city || data.city.trim().length === 0) {
    errors.push('City is required.');
  }
  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push('State / Province / Region is required.');
  }
  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push('Postal / Zip code is required.');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, numbers, spaces, and hyphens.');
  }
  if (!data.country || data.country.trim().length === 0) {
    errors.push('Country is required.');
  }
  if (!data.email || data.email.trim().length === 0) {
    errors.push('Email is required.');
  } else if (!validateEmail(data.email)) {
    errors.push('Please enter a valid email address.');
  }
  if (!data.phone || data.phone.trim().length === 0) {
    errors.push('Phone number is required.');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +.');
  }

  return errors;
}

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  let dbInstance: Database;
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    saveDatabase(dbInstance);
  }

  return dbInstance;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from public directory
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Determine the correct templates directory
// When running from dist/, templates are in src/templates
// When running from src/ (dev), templates are in src/templates
const templatesDir = path.join(process.cwd(), 'src', 'templates');

app.set('views', templatesDir);
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    res.status(400).render('form', {
      errors,
      values: formData
    });
    return;
  }

  if (!db) {
    errors.push('Database not initialized. Please try again.');
    res.status(500).render('form', {
      errors,
      values: formData
    });
    return;
  }

  try {
    db.run(
      `INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );

    saveDatabase(db);

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    errors.push('Failed to save submission. Please try again.');
    res.status(500).render('form', {
      errors,
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    firstName: 'Friend'
  });
});

let server: ReturnType<typeof app.listen> | null = null;

export { app };

export async function startServer(): Promise<number> {
  db = await initializeDatabase();
  const port = typeof PORT === 'string' ? parseInt(PORT, 10) : PORT;
  
  return new Promise((resolve) => {
    server = app.listen(port, () => {
      console.log(`Server listening on port ${port}`);
      resolve(port);
    });
  });
}

export async function stopServer(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
  
  if (server) {
    return new Promise((resolve) => {
      server!.close(() => {
        console.log('Server closed');
        resolve();
      });
    });
  }
}

process.on('SIGTERM', async () => {
  console.log('SIGTERM signal received: closing HTTP server');
  await stopServer();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT signal received: closing HTTP server');
  await stopServer();
  process.exit(0);
});

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
