#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, ReportOptions, ReportFormat } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  const cliArgs = args.slice(2);

  if (cliArgs.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = cliArgs[0];
  
  let format: ReportFormat | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < cliArgs.length; i++) {
    const arg = cliArgs[i];
    
    if (arg === '--format') {
      i++;
      if (i >= cliArgs.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const formatValue = cliArgs[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Error: Unsupported format: ${formatValue}`);
        process.exit(1);
      }
      format = formatValue;
    } else if (arg === '--output') {
      i++;
      if (i >= cliArgs.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      outputPath = cliArgs[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataFile, format, outputPath, includeTotals };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected object');
    }
    
    const obj = data as Record<string, unknown>;
    
    if (typeof obj.title !== 'string') {
      throw new Error('Invalid report data: missing or invalid "title" field (required string)');
    }
    
    if (typeof obj.summary !== 'string') {
      throw new Error('Invalid report data: missing or invalid "summary" field (required string)');
    }
    
    if (!Array.isArray(obj.entries)) {
      throw new Error('Invalid report data: missing or invalid "entries" field (required array)');
    }
    
    const entries = obj.entries.map((entry, index) => {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid report data: entry at index ${index} is not an object`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid report data: entry at index ${index} has missing or invalid "label" field (required string)`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid report data: entry at index ${index} has missing or invalid "amount" field (required number)`);
      }
      
      return {
        label: entryObj.label,
        amount: entryObj.amount,
      };
    });
    
    return {
      title: obj.title,
      summary: obj.summary,
      entries,
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${filePath}: ${error.message}`);
    } else if (error instanceof Error && error.message.includes('ENOENT')) {
      console.error(`Error: File not found: ${filePath}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Failed to read file ${filePath}`);
    }
    process.exit(1);
  }
}

function main(): void {
  try {
    const args = parseArguments(process.argv);
    const data = loadReportData(args.dataFile);
    const options: ReportOptions = { includeTotals: args.includeTotals };
    
    let output: string;
    switch (args.format) {
      case 'markdown':
        output = markdownRenderer.render(data, options);
        break;
      case 'text':
        output = textRenderer.render(data, options);
        break;
    }
    
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
