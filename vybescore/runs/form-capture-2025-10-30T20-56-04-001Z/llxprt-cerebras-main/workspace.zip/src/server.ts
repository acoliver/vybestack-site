import express, { Request, Response, Application } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';
import { Server } from 'http';

// Get the directory name of the current module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app: Application = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database initialization
let db: Database;
let server: Server;

const initDatabase = async () => {
  const SQL = await initSqlJs({ 
    locateFile: (file: string) => `node_modules/sql.js/dist/${file}` 
  });
  
  // Path to the SQLite database file
  const dbPath = path.resolve('data', 'submissions.sqlite');
  
  // Check if the database file exists
  if (fs.existsSync(dbPath)) {
    // Load existing database
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(new Uint8Array(fileBuffer));
  } else {
    // Create new database
    db = new SQL.Database();
    
    // Execute schema.sql to create tables
    const schemaSql = fs.readFileSync(path.resolve('db', 'schema.sql'), 'utf8');
    db.run(schemaSql);
    
    // Ensure data directory exists
    if (!fs.existsSync('data')) {
      fs.mkdirSync('data');
    }
    
    // Save new database to file
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  }
};

// Form validation function
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const validateForm = (formData: FormData) => {
  const errors: string[] = [];
  
  // Check required fields
  const requiredFields = [
    'firstName', 
    'lastName', 
    'streetAddress', 
    'city', 
    'stateProvince', 
    'postalCode', 
    'country', 
    'email', 
    'phone'
  ];
  
  requiredFields.forEach(field => {
    if (!formData[field as keyof FormData] || formData[field as keyof FormData].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1')} is required`);
    }
  });
  
  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (formData.email && !emailRegex.test(formData.email)) {
    errors.push('Email must be valid');
  }
  
  // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (formData.phone && !phoneRegex.test(formData.phone)) {
    errors.push('Phone number format is invalid');
  }
  
  // Postal code validation (accept alphanumeric)
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  if (formData.postalCode && !postalCodeRegex.test(formData.postalCode)) {
    errors.push('Postal code format is invalid');
  }
  
  return errors;
};

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = req.body;
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    return res.status(400).render('form', { 
      errors, 
      values: formData 
    });
  }
  
  // Insert submission into database
  const stmt = db.prepare(`INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
  stmt.free();
  
  // Save database to file
  const data = db.export();
  const buffer = Buffer.from(data);
  const dbPath = path.resolve('data', 'submissions.sqlite');
  fs.writeFileSync(dbPath, buffer);
  
  // Redirect to thank you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(formData.firstName));
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Start server
const startServer = async () => {
  await initDatabase();
  server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
  return server;
};

startServer().then((srv) => {
  server = srv;
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server and database');
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
    });
  }
  
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    const dbPath = path.resolve('data', 'submissions.sqlite');
    fs.writeFileSync(dbPath, buffer);
    db.close();
    console.log('Database closed');
  }
});

export default app;