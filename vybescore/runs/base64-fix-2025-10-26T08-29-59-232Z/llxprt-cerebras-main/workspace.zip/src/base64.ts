/**
 * Encode plain text to Base64 using RFC 4648 standard alphabet and required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 string.
 * 
 * @param input Base64 string to decode
 * @returns Decoded UTF-8 string
 * @throws Error if input is not valid Base64
 */
export function decode(input: string): string {
  // Validate Base64 format with optional padding
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}