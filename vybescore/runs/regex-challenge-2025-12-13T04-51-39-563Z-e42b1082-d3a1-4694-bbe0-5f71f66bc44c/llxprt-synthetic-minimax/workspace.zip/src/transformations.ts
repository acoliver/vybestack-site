/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // Split text into sentences based on .?! followed by space or end
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  return sentences.map((sentence) => {
    // Always capitalize first letter of each sentence
    const trimmed = sentence.trim();
    if (!trimmed) {
      return sentence; // Keep original spacing if empty
    }
    
    // Capitalize first letter while preserving the rest
    const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
    
    // Preserve original leading spaces from the sentence
    const leadingSpaces = sentence.match(/^\s*/)?.[0] || '';
    
    return leadingSpaces + capitalized;
  }).join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"'`|\\^{}[\]]*[^\s<>"'`|\\^{}[\].,!?;:)]/gi;
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?;:]+\)$/, '');
  });
}

/**
 * TODO: Replace http:// with https:// but leave https:// untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Replace http:// with https:// but leave https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // Pattern to match http URLs
  return text.replace(/http:\/\/([^/\s]+)(\S*)/g, (match, host, path) => {
    // Always upgrade to https
    let result = `https://${host}`;
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should skip host rewrite
      const hasDynamicHints = /(\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
      
      if (!hasDynamicHints) {
        // Replace domain part with docs subdomain
        const newHost = host.replace(/^([a-zA-Z0-9-]+\.)?([a-zA-Z0-9-]+\.[a-zA-Z0-9-]+)$/, 'docs.$2');
        result = `https://${newHost}`;
      }
    }
    
    return result + path;
  });
}

/**
 * TODO: Extract the year from date strings in mm/dd/yyyy format.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }
  
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return match[3];
}