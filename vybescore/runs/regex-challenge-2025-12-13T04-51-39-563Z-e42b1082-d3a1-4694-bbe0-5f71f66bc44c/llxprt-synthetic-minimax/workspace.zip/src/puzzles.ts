/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Escape special regex characters in exceptions
  const escapedExceptions = exceptions.map(ex => ex.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  const exceptionsPattern = escapedExceptions.join('|');
  
  // Create regex pattern that finds words starting with prefix, excluding exceptions
  const pattern = new RegExp(`\\b(?!${exceptionsPattern})${prefix}\\w*\\b`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Remove duplicates and filter out exact matches to the exceptions
  return [...new Set(matches)].filter(match => 
    !exceptions.some(ex => ex.toLowerCase() === match.toLowerCase())
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Pattern explanation:
  // (?<=\d) - Positive lookbehind: must be preceded by a digit
  // (?<!^) - Negative lookbehind: must not be at the start of string
  // ${token} - The token to find
  const tokenPattern = `(?<!^)(?<=\\d)${token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`;
  
  const regex = new RegExp(tokenPattern, 'gi');
  
  // Find all occurrences and return them
  const results: string[] = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    // Get the full match including the preceding digit
    const startPos = match.index - 1; // Position of the digit
    if (startPos >= 0 && /\d/.test(text[startPos])) {
      results.push(text[startPos] + match[0]);
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "1212")
  // This regex looks for any 2-character sequence that repeats immediately
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // IPv6 patterns to match:
  // 1. Full IPv6: 8 groups of 4 hexadecimal digits separated by colons
  // 2. IPv6 with :: (shorthand notation)
  // 3. IPv6 with leading zeros omitted
  // 4. IPv6-mapped IPv4 addresses
  
  const ipv6Patterns = [
    // Full IPv6 (8 groups of 4 hex digits)
    /(?<![0-9a-fA-F:])(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?![0-9a-fA-F:])/,
    
    // IPv6 with :: (most common shorthand patterns)
    /(?<![0-9a-fA-F:])([0-9a-fA-F]{0,4}:){1,7}:(?![0-9a-fA-F:])/,
    /(?<![0-9a-fA-F:]):(:[0-9a-fA-F]{1,4}){1,7}(?![0-9a-fA-F:])/,
    /(?<![0-9a-fA-F:])([0-9a-fA-F]{1,4}:){1,6}([0-9a-fA-F]{1,4})?(?![0-9a-fA-F:])/,
    /(?<![0-9a-fA-F:])([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}(?![0-9a-fA-F:])/,
    /(?<![0-9a-fA-F:])([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}(?![0-9a-fA-F:])/,
    /(?<![0-9a-fA-F:])([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}(?![0-9a-fA-F:])/,
    /(?<![0-9a-fA-F:])([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}(?![0-9a-fA-F:])/,
    /(?<![0-9a-fA-F:])[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})(?![0-9a-fA-F:])/,
    
    // IPv6-mapped IPv4
    /(?<![0-9a-fA-F:])(?:[0-9a-fA-F]{1,4}:){7}(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?![0-9a-fA-F:])/,
    
    // IPv6 with :: and IPv4 mapped
    /(?<![0-9a-fA-F:])(?:[0-9a-fA-F]{1,4}:){0,6}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?![0-9a-fA-F:])/,
    
    // General pattern with optional :: (looser matching)
    /(?<![0-9a-fA-F:])([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}(?![0-9a-fA-F:])/
  ];
  
  // First check if this looks like an IPv4 address - if so, exclude it
  const ipv4Regex = /(?<![0-9.])(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?![0-9.])/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Test if any IPv6 pattern matches
  return ipv6Patterns.some(pattern => pattern.test(value));
}