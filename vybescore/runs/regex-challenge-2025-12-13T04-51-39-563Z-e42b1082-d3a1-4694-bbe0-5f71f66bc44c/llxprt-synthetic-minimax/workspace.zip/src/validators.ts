export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern explanation:
  // ^(?!\.) - Cannot start with a dot
  // [a-zA-Z0-9._%+-]+ - Local part: letters, numbers, dots, underscores, %, +, - (no double dots)
  // (?<!\.) - Cannot end with a dot
  // @ - Required @ symbol
  // [a-zA-Z0-9-]+(?<!\.) - Domain: letters, numbers, hyphens (no trailing dot)
  // (?:\.[a-zA-Z0-9-]+)* - Additional domain parts starting with dot
  // \.[a-zA-Z]{2,}$ - TLD must be at least 2 letters
  const emailRegex = /^(?!\.)[a-zA-Z0-9._%+-]+(?<!\.)@[a-zA-Z0-9-]+(?<!\.)(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters to count total digits
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have 10 or 11 digits (with optional +1 country code)
  if (digitsOnly.length !== 10 && digitsOnly.length !== 11) {
    return false;
  }
  
  // If 11 digits, first must be 1
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Extract the 10-digit number (remove country code if present)
  const phoneNumber = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check format using regex
  // Optional +1, optional parentheses around area code, optional separators
  const phoneRegex = /^(\+1[\s.-]?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
  return phoneRegex.test(value.trim());
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens to normalize the input
  const normalized = value.replace(/[\s-]/g, '');
  
  // Must be between 10-13 digits total
  if (normalized.length < 10 || normalized.length > 13) {
    return false;
  }
  
  // Pattern explanation:
  // ^\+?54? - Optional +54 country code
  // 9? - Optional mobile indicator 9
  // 0? - Optional trunk prefix 0 (required when no country code)
  // ([1-9]\d{1,3}) - Area code: 2-4 digits, first digit 1-9
  // (\d{6,8})$ - Subscriber number: 6-8 digits
  
  // Case 1: With country code (+54)
  const internationalRegex = /^(\+54)(\d{0,1})?(\d{0,1})?([1-9]\d{1,3})(\d{6,8})$/;
  if (internationalRegex.test(value.replace(/[\s-]/g, ''))) {
    const match = value.replace(/[\s-]/g, '').match(internationalRegex);
    if (match) {
      // Validate specific combinations:
      // +54 9 (mobile indicator) area_code subscriber
      // +54 area_code subscriber (landline)
      // If mobile indicator present (2nd capture group), area code must be 2 digits
      // If no mobile indicator, area code can be 2-4 digits
      const mobileIndicator = match[2] || '';
      const areaCode = match[4];
      
      if (mobileIndicator === '9') {
        // Mobile: area code should be 2 digits
        return areaCode.length === 2;
      } else {
        // Landline: area code should be 2-4 digits
        return areaCode.length >= 2 && areaCode.length <= 4;
      }
    }
  }
  
  // Case 2: Without country code (local format)
  // Must start with 0 (trunk prefix)
  const localRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  if (localRegex.test(normalized)) {
    const match = normalized.match(localRegex);
    if (match) {
      const areaCode = match[1];
      const subscriber = match[2];
      
      // Area code should be 2-4 digits, subscriber should be 6-8 digits
      return areaCode.length >= 2 && areaCode.length <= 4 && 
             subscriber.length >= 6 && subscriber.length <= 8;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty and should contain at least one letter
  if (!value || !value.trim()) {
    return false;
  }
  
  // Pattern explanation:
  // ^ - Start of string
  // (?!.*\d) - Negative lookahead: no digits anywhere
  // (?!.*[^\p{L}\p{M}\p{Zs}'-]) - Negative lookahead: no symbols except apostrophe, hyphen, space
  // \p{L} - Unicode letters (including accented characters)
  // \p{M} - Unicode combining marks (accents, diacritics)
  // \p{Zs} - Unicode space separators
  // [\p{L}\p{M}\p{Zs}'-]+ - Allow letters, accents, spaces, apostrophes, and hyphens
  // $ - End of string
  const nameRegex = /^(?!.*\d)(?!.*[^\p{L}\p{M}\p{Zs}'-])[\p{L}\p{M}\p{Zs}'-]+$/u;
  
  return nameRegex.test(value.trim());
}

/**
 * TODO: Validate credit cards using Luhn algorithm and card type rules.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must be between 13-19 digits (standard credit card length range)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for card type and validate prefix/length
  // Visa: Starts with 4, length 13, 16, or 19
  if (digitsOnly.startsWith('4')) {
    if (![13, 16, 19].includes(digitsOnly.length)) {
      return false;
    }
  }
  // Mastercard: Starts with 51-55 or 2221-2720, length 16
  else if (digitsOnly.startsWith('51') || digitsOnly.startsWith('52') || 
           digitsOnly.startsWith('53') || digitsOnly.startsWith('54') || 
           digitsOnly.startsWith('55')) {
    if (digitsOnly.length !== 16) {
      return false;
    }
  }
  else if (digitsOnly.startsWith('2221') || digitsOnly.startsWith('2222') || 
           digitsOnly.startsWith('2223') || digitsOnly.startsWith('2224') || 
           digitsOnly.startsWith('2225') || digitsOnly.startsWith('2226') || 
           digitsOnly.startsWith('2227') || digitsOnly.startsWith('2228') || 
           digitsOnly.startsWith('2229') || digitsOnly.startsWith('223') || 
           digitsOnly.startsWith('224') || digitsOnly.startsWith('225') || 
           digitsOnly.startsWith('226') || digitsOnly.startsWith('227') || 
           digitsOnly.startsWith('228') || digitsOnly.startsWith('229') || 
           digitsOnly.startsWith('23') || digitsOnly.startsWith('24') || 
           digitsOnly.startsWith('25') || digitsOnly.startsWith('26') || 
           digitsOnly.startsWith('270') || digitsOnly.startsWith('271') || 
           digitsOnly.startsWith('2720')) {
    if (digitsOnly.length !== 16) {
      return false;
    }
  }
  // AmEx: Starts with 34 or 37, length 15
  else if (digitsOnly.startsWith('34') || digitsOnly.startsWith('37')) {
    if (digitsOnly.length !== 15) {
      return false;
    }
  }
  // Not a recognized card type
  else {
    return false;
  }
  
  // Apply Luhn algorithm
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to run Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}