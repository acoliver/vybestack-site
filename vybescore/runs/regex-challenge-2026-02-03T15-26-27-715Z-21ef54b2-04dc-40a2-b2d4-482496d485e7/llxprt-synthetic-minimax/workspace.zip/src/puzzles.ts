/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find all words starting with the prefix
  const words = text.match(/\b\w+\b/g) || [];
  const prefixedWords = words.filter(word => word.startsWith(prefix));
  
  // Filter out exceptions
  return prefixedWords.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern: digit followed by the token, but not at string start
  const pattern = new RegExp(`(?<!^)\\d(${token})`, 'g');
  
  const matches: string[] = [];
  let match;
  
  // Use exec in a loop to find all matches
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]); // The full match (digit + token)
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+={};':"|,.<>/]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // Pattern: two characters followed by the same two characters
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if it looks like it contains IPv4 addresses
  // If it's pure IPv4, we should reject it
  const hasIPv4 = /(\d{1,3}\.){3}\d{1,3}/.test(value);
  
  if (hasIPv4) {
    // If it contains IPv4, check if there's also IPv6
    // If the value is purely IPv4, reject
    const cleanValue = value.replace(/(\d{1,3}\.){3}\d{1,3}/g, '');
    if (cleanValue.trim() === '') {
      return false;
    }
  }
  
  // Pattern for IPv6 addresses (including shorthand ::)
  const ipv6Pattern = /(^|[^0-9])([0-9A-Fa-f]{1,4}:){2,7}[0-9A-Fa-f]{0,4}(?![0-9])/;
  
  // Shorthand patterns
  const hasIPv6Shorthand = /::/.test(value);
  const ipv6ShorthandPattern = /(^|[^0-9])::([0-9A-Fa-f]{1,4}:){0,7}[0-9A-Fa-f]{0,4}(?![0-9])/;
  
  // Check for standard or shorthand IPv6
  return ipv6Pattern.test(value) || (hasIPv6Shorthand && ipv6ShorthandPattern.test(value));
}
