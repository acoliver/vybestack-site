export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check
  const emailRegex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check for domains with underscores
  const domainParts = value.split('@')[1]?.split('.');
  if (domainParts) {
    for (const part of domainParts) {
      if (part.includes('_')) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for length check
  const digits = value.replace(/\D/g, '');
  
  // Optional +1 prefix check
  if (digits.startsWith('1') && digits.length === 11) {
    // Strip the country code for area code validation
    const localNumber = digits.substring(1);
    return isValidUSLocalNumber(localNumber);
  }
  
  return isValidUSLocalNumber(digits);
}

function isValidUSLocalNumber(digits: string): boolean {
  // Check length (10 digits for local number)
  if (digits.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check for optional country code +54
  let remaining = cleanNumber;
  if (remaining.startsWith('+54')) {
    remaining = remaining.substring(3);
  }
  
  // Check for optional trunk prefix 0
  if (remaining.startsWith('0')) {
    remaining = remaining.substring(1);
  }
  
  // Check for optional mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // Now remaining should start with area code (2-4 digits, leading digit 1-9)
  if (remaining.length < 2) {
    return false;
  }
  
  const areaCode = remaining.substring(0, 2);
  const areaCodeLeading = parseInt(areaCode[0]);
  
  if (areaCodeLeading < 1 || areaCodeLeading > 9) {
    return false;
  }
  
  // Check total remaining length for subscriber number
  const subscriberLength = remaining.length - areaCode.length;
  if (subscriberLength < 6 || subscriberLength > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must be non-empty
  if (!value.trim()) {
    return false;
  }
  
  // Check that it doesn't contain digits or symbols (excluding allowed characters)
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional check to reject X Æ A-12 style names
  if (value.includes('Æ') || value.includes('X')) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check prefix for major card types
  const startsWithVisa = digits.startsWith('4');
  const startsWithMastercard = digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
                                digits.startsWith('54') || digits.startsWith('55') || digits.startsWith('222') || 
                                digits.startsWith('223') || digits.startsWith('224') || digits.startsWith('225') || 
                                digits.startsWith('226') || digits.startsWith('227') || digits.startsWith('228') || 
                                digits.startsWith('229') || digits.startsWith('23') || digits.startsWith('24') || 
                                digits.startsWith('25') || digits.startsWith('26') || digits.startsWith('270') || 
                                digits.startsWith('271') || digits.startsWith('272');
  const startsWithAmEx = digits.startsWith('34') || digits.startsWith('37');
  
  if (!startsWithVisa && !startsWithMastercard && !startsWithAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
