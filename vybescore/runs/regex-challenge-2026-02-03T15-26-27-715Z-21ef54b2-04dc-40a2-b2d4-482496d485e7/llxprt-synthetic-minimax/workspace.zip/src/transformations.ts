/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences by .?! followed by any whitespace
  const sentences = text.split(/(?<=[.!?])\s*/);
  
  return sentences.map(sentence => {
    // Find first letter and capitalize it
    const match = sentence.match(/[a-zA-Z]/);
    if (match) {
      const index = match.index!;
      const firstPart = sentence.substring(0, index);
      const letter = match[0].toUpperCase();
      const rest = sentence.substring(index + 1);
      return firstPart + letter + rest;
    }
    return sentence;
  }).join(' ');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs - match http/https scheme and domain/path until whitespace/punctuation
  const urlPattern = /https?:\/\/[^\s,;!?]*[^\s,;!?]/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation while preserving domain dots
  return matches.map(url => {
    let cleanedUrl = url;
    // Remove trailing punctuation that doesn't belong to URLs
    while (cleanedUrl.length > 0 && ',\';!?'.includes(cleanedUrl[cleanedUrl.length - 1])) {
      cleanedUrl = cleanedUrl.slice(0, -1);
    }
    return cleanedUrl;
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/]+)(\/docs\/[^\s]*)/g, (match, host, path) => {
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = path.includes('cgi-bin') || path.includes('?') || path.includes('&') || 
                           path.includes('=') || path.includes('.jsp') || path.includes('.php') || 
                           path.includes('.asp') || path.includes('.aspx') || path.includes('.do') || 
                           path.includes('.cgi') || path.includes('.pl') || path.includes('.py');
    
    if (hasDynamicHints) {
      // Just upgrade the scheme to https://
      return 'https://' + host + path;
    } else {
      // Move docs paths to docs subdomain and upgrade scheme
      return 'https://docs.' + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Check for mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}
