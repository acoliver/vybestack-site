import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      if (pageParam === '' || !/^\d+$/.test(pageParam)) {
        return res.status(400).json({ error: 'Page must be a positive integer' });
      }
      const pageNum = Number(pageParam);
      if (pageNum <= 0) {
        return res.status(400).json({ error: 'Page must be a positive integer' });
      }
      if (pageNum > 1000) {
        return res.status(400).json({ error: 'Page cannot exceed 1000' });
      }
      page = pageNum;
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      if (limitParam === '' || !/^\d+$/.test(limitParam)) {
        return res.status(400).json({ error: 'Limit must be a positive integer' });
      }
      const limitNum = Number(limitParam);
      if (limitNum <= 0) {
        return res.status(400).json({ error: 'Limit must be a positive integer' });
      }
      if (limitNum > 100) {
        return res.status(400).json({ error: 'Limit cannot exceed 100' });
      }
      limit = limitNum;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
