export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that rejects:
  // - Double dots (..)
  // - Trailing/leading dots
  // - Domains with underscores
  // - Invalid characters
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (value.includes('..')) return false;
  if (value.includes('@.')) return false;
  if (value.includes('.@')) return false;
  if (value.includes('_')) return false; // Underscores not allowed in domain
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // PhoneValidationOptions reserved for future extensions (e.g., allowExtensions)
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (area code + 7 digits = 10, or 11 with country code)
  if (digitsOnly.length < 10) return false;
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    phoneNumber = digitsOnly.slice(1);
  } else if (digitsOnly.length > 11) {
    return false; // Too long even with country code
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Validate format matches one of the supported patterns
  const patterns = [
    /^\(\d{3}\)\s*\d{3}-?\d{4}$/, // (212) 555-7890
    /^\d{3}-?\d{3}-?\d{4}$/,       // 212-555-7890 or 2125557890
    /^\+1\s*\(\d{3}\)\s*\d{3}-?\d{4}$/, // +1 (212) 555-7890
    /^\+1\s*\d{3}-?\d{3}-?\d{4}$/,      // +1 212-555-7890
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits after area code
 * - When country code omitted, must start with trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // ^\+?54? - Optional country code +54
  // 0? - Optional trunk prefix 0
  // 9? - Optional mobile indicator 9
  // [1-9]\d{1,3} - Area code (2-4 digits, leading 1-9)
  // \d{6,8}$ - Subscriber number (6-8 digits)
  const withCountryCode = /^\+?540?9?[1-9]\d{1,3}\d{6,8}$/;
  const withoutCountryCode = /^0[1-9]\d{1,3}\d{6,8}$/;
  
  return withCountryCode.test(cleaned) || withoutCountryCode.test(cleaned);
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and Elon Musk's baby style names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Unicode letters (including accents), apostrophes, hyphens, spaces
  // Must have at least one letter
  // No digits or special symbols
  const nameRegex = /^[\p{L}'-]+(?:[\s\u00A0]+[\p{L}'-]+)*$/u;
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  // Reject names with digits or special symbols
  if (/\d/.test(value)) return false;
  if (/[^\p{L}'\-\s\u00A0]/u.test(value)) return false;
  
  // Must not be empty or just spaces/hyphens/apostrophes
  const trimmed = value.trim();
  if (trimmed.length === 0) return false;
  
  return nameRegex.test(trimmed);
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Visa: starts with 4, length 13 or 16
  const visaPattern = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPattern = /^5[1-5]\d{14}$|^2[2-7][0-9]{14}$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check prefix and length
  const validPattern = visaPattern.test(cleaned) || 
                       mastercardPattern.test(cleaned) || 
                       amexPattern.test(cleaned);
  
  if (!validPattern) return false;
  
  // Luhn algorithm
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
