/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after sentence-ending punctuation (.?!)
 * - Ensures exactly one space between sentences
 * - Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Insert space after sentence-ending punctuation if missing
  // But be careful not to break abbreviations
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Capitalize first letter of the entire text
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Capitalize after sentence-ending punctuation
  // This regex matches punctuation followed by space(s) and a lowercase letter
  result = result.replace(/([.!?])\s+([a-z])/g, (match, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Extract URLs from text.
 * Returns an array of URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https protocols
  // Negative lookahead to avoid matching trailing punctuation
  const urlPattern = /https?:\/\/[^\s<>"{}|\\^`[\]]+(?<![.,!?;:])/g;
  
  const matches = text.match(urlPattern) || [];
  
  return matches;
}

/**
 * Force all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(http:\/\/example\.com)(\/[^\s<>"{}|\\^`[\]]*)/g;
  
  return text.replace(urlPattern, (match, protocolAndHost, path) => {
    // Always upgrade to https
    const httpsUrl = 'https://example.com' + path;
    
    // Check if we should skip the docs rewrite
    // Skip for: cgi-bin, query strings, legacy extensions
    const skipDocsRewrite = /\/(cgi-bin)|[?&=]|(\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|[?#]|$))/.test(path);
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/') && !skipDocsRewrite) {
      return 'https://docs.example.com' + path;
    }
    
    return httpsUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy formatted dates.
 * Returns 'N/A' if the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
