/**
 * Find words starting with the given prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match words starting with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive comparison)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  return matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * Find occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookbehind to ensure the token is preceded by a digit.
 * Returns the full match including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token (not at start of string)
  // The pattern matches the digit + token combination
  const tokenPattern = new RegExp(`(?:^|\\D)\\d${escapedToken}(?![a-zA-Z0-9])`, 'g');
  
  const matches = text.match(tokenPattern) || [];
  
  // Remove the non-digit prefix if present
  return matches.map(match => match.replace(/^[^\d]/, ''));
}

/**
 * Validate password strength.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value)) return false;
  
  // Check for repeated sequences (like abab, 1212, etc.)
  // Look for patterns of 2-4 characters that repeat immediately
  const repeatedPattern = /(.{2,4})\1+/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // First, check if this looks like a pure IPv4 address and exclude it
  // IPv4 pattern: 1-3 digits, repeated 4 times with dots (must be entire string)
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 pattern (simplified but effective):
  // - 8 groups of 1-4 hex digits separated by colons
  // - Or with :: shorthand for consecutive zeros
  // - Can include IPv4-mapped addresses at the end
  
  // Full IPv6 pattern without shorthand (8 groups)
  const fullIPv6 = /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: shorthand (anywhere in the address)
  const shorthandIPv6 = /([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*/;
  
  // IPv6 with :: at start
  const startShorthand = /::([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: at end
  const endShorthand = /([0-9a-fA-F]{1,4}:){1,7}::/;
  
  // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const embeddedIPv4 = /([0-9a-fA-F]{1,4}:)*::[fF]{4}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  return fullIPv6.test(value) || 
         shorthandIPv6.test(value) || 
         startShorthand.test(value) || 
         endShorthand.test(value) ||
         embeddedIPv4.test(value);
}
