export interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvinceRegion?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phoneNumber?: string;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export function validateFormData(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city.trim()) {
    errors.city = 'City is required';
  }

  if (!data.stateProvinceRegion.trim()) {
    errors.stateProvinceRegion = 'State/Province/Region is required';
  }

  if (!data.postalCode.trim()) {
    errors.postalCode = 'Postal code is required';
  }

  if (!data.country.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email.trim()) {
    errors.email = 'Email is required';
  }

  if (!data.phoneNumber.trim()) {
    errors.phoneNumber = 'Phone number is required';
  }

  // Email validation
  if (data.email && data.email.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone number validation (international format)
  if (data.phoneNumber && data.phoneNumber.trim()) {
    const phoneRegex = /^[+]?[0-9\s\-()]{7,}$/;
    if (!phoneRegex.test(data.phoneNumber.trim())) {
      errors.phoneNumber = 'Please enter a valid phone number';
    }
  }

  // Postal code validation (allow alphanumeric)
  if (data.postalCode && data.postalCode.trim()) {
    const postalRegex = /^[A-Za-z0-9\s-]{3,12}$/;
    if (!postalRegex.test(data.postalCode.trim())) {
      errors.postalCode = 'Please enter a valid postal code';
    }
  }

  return errors;
}

export function hasErrors(errors: ValidationErrors): boolean {
  return Object.keys(errors).length > 0;
}