import express, { Request, Response } from 'express';
import * as path from 'path';
import { DatabaseHelper } from './database';
import { validateFormData, FormData, hasErrors } from './validation';

const app = express();
const port = process.env['PORT'] || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));
app.set('views', path.join(__dirname, '../views'));
app.set('view engine', 'ejs');

// Database instance
const dbHelper = new DatabaseHelper();

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await dbHelper.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await dbHelper.close();
  process.exit(0);
});

// Routes
app.get('/', async (_req: Request, res: Response) => {
  res.render('form', { 
    data: {},
    errors: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phoneNumber: req.body.phoneNumber || ''
    };

    const errors = validateFormData(formData);

    if (hasErrors(errors)) {
      // Re-render form with errors and previously entered values
      return res.status(400).render('form', {
        data: formData,
        errors: errors
      });
    }

    // Valid submission, store in database
    await dbHelper.insertSubmission(formData);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
    
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).render('form', {
      data: req.body,
      errors: { general: 'An error occurred while processing your submission. Please try again.' }
    });
  }
});

app.get('/thank-you', async (_req: Request, res: Response) => {
  res.render('thank-you');
});

// Initialize database and start server
async function startServer() {
  try {
    await dbHelper.initialize();
    console.log('Database initialized successfully');
    
    app.listen(port, () => {
      console.log(`Server running on http://localhost:${port}`);
      console.log(`Visit http://localhost:${port} to see the friendly form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer().catch(console.error);
