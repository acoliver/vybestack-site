import initSqlJs, { Database } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export class DatabaseHelper {
  private db: Database | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor(dbPath: string = 'data/submissions.sqlite', schemaPath: string = 'db/schema.sql') {
    this.dbPath = path.resolve(dbPath);
    this.schemaPath = path.resolve(schemaPath);
  }

  public async initialize(): Promise<void> {
    const dbExists = fs.existsSync(this.dbPath);
    const SQL = await initSqlJs();
    
    if (dbExists) {
      // Load existing database
      const dbBuffer = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(dbBuffer);
    } else {
      // Create new database
      this.db = new SQL.Database();
      
      // Read and execute schema
      const schemaSql = fs.readFileSync(this.schemaPath, 'utf-8');
      this.db!.exec(schemaSql);
      
      // Ensure directory exists
      const dir = path.dirname(this.dbPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }
  }

  public async insertSubmission(submission: FormSubmission): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db!.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        submission.firstName,
        submission.lastName,
        submission.streetAddress,
        submission.city,
        submission.stateProvinceRegion,
        submission.postalCode,
        submission.country,
        submission.email,
        submission.phoneNumber
      ]);
    } finally {
      stmt.free();
    }

    // Write database back to file
    const dbData = this.db.export();
    if (dbData) {
      fs.writeFileSync(this.dbPath, Buffer.from(dbData));
    }
  }

  public async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  public getDatabase(): Database | null {
    return this.db;
  }
}