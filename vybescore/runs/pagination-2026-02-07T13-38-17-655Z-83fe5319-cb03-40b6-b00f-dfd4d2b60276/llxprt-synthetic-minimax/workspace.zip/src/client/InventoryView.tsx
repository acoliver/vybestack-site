import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  page, 
  total, 
  limit, 
  hasNext, 
  onPrevious, 
  onNext 
}: { 
  page: number; 
  total: number; 
  limit: number; 
  hasNext: boolean; 
  onPrevious: () => void; 
  onNext: () => void; 
}): JSX.Element {
  const totalPages = Math.ceil(total / limit);
  const canGoPrevious = page > 1;
  const canGoNext = hasNext;

  return (
    <div>
      <p>
        Page {page} of {totalPages} ({total} total items)
      </p>
      <nav>
        <button 
          onClick={onPrevious}
          disabled={!canGoPrevious}
          type="button"
        >
          Previous
        </button>
        <button 
          onClick={onNext}
          disabled={!canGoNext}
          type="button"
        >
          Next
        </button>
      </nav>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [page, setPage] = useState(1);
  const [limit] = useState(PAGE_LIMIT);
  const { status, data, error } = useInventory(page, limit);

  const handlePrevious = (): void => {
    if (page > 1) {
      setPage(prev => prev - 1);
    }
  };

  const handleNext = (): void => {
    if (data?.hasNext) {
      setPage(prev => prev + 1);
    }
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return (
      <section>
        <h1>Inventory</h1>
        <p role="alert">{error ?? 'Unable to load inventory.'}</p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls
        page={page}
        total={data.total}
        limit={data.limit}
        hasNext={data.hasNext}
        onPrevious={handlePrevious}
        onNext={handleNext}
      />
    </section>
  );
}
