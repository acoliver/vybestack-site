import type { ReportFormatter } from '../types.js';

/**
 * Format an amount as a dollar string with exactly two decimal places.
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate the total of all entry amounts.
 */
function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Render a report in Markdown format.
 */
export const renderMarkdown: ReportFormatter = (data, options) => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);

  // Summary
  lines.push('');
  lines.push(data.summary);

  // Entries heading and list
  lines.push('');
  lines.push('## Entries');
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(``);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }

  return lines.join('\n');
};
