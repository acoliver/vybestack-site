#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, ReportFormatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Map of format names to their corresponding formatter functions.
 */
const FORMATTERS: Record<string, ReportFormatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * CLI configuration parsed from command line arguments.
 */
interface CliConfig {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

/**
 * Parse command line arguments.
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */
function parseArgs(args: string[]): CliConfig {
  const [inputFile, ...rest] = args;

  if (!inputFile) {
    console.error('Error: Input file path is required.');
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    const nextArg = rest[i + 1];

    switch (arg) {
      case '--format':
        if (!nextArg || nextArg.startsWith('--')) {
          console.error('Error: --format requires a value.');
          process.exit(1);
        }
        format = nextArg;
        i++; // Skip next arg as we consumed it
        break;

      case '--output':
        if (!nextArg || nextArg.startsWith('--')) {
          console.error('Error: --output requires a value.');
          process.exit(1);
        }
        outputPath = nextArg;
        i++; // Skip next arg as we consumed it
        break;

      case '--includeTotals':
        includeTotals = true;
        break;

      default:
        console.error(`Error: Unknown argument: ${arg}`);
        console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
        process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required.');
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

/**
 * Validate and parse report data from JSON.
 */
function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(
        `Invalid report data: entry at index ${index} is not an object`
      );
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid report data: entry at index ${index} missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid report data: entry at index ${index} missing or invalid "amount" field (expected number)`
      );
    }

    return { label: entryObj.label, amount: entryObj.amount };
  });

  return { title: obj.title, summary: obj.summary, entries };
}

/**
 * Main entry point.
 */
function main(): void {
  // Parse command line arguments (skip first two: node and script path)
  const args = process.argv.slice(2);
  const config = parseArgs(args);

  // Read and parse input file
  let inputData: unknown;
  try {
    const inputContent = fs.readFileSync(config.inputFile, 'utf-8');
    inputData = JSON.parse(inputContent);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON from ${config.inputFile}: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: Failed to read file ${config.inputFile}: ${error.message}`);
    } else {
      console.error(`Error: Failed to read file ${config.inputFile}`);
    }
    process.exit(1);
  }

  // Validate report data
  let reportData: ReportData;
  try {
    reportData = validateReportData(inputData);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }

  // Get formatter
  const formatter = FORMATTERS[config.format];
  if (!formatter) {
    console.error(`Error: Unsupported format: ${config.format}`);
    console.error(`Supported formats: ${Object.keys(FORMATTERS).join(', ')}`);
    process.exit(1);
  }

  // Render report
  const output = formatter(reportData, { includeTotals: config.includeTotals });

  // Write output
  if (config.outputPath) {
    try {
      fs.writeFileSync(config.outputPath, output, 'utf-8');
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`Error: Failed to write output to ${config.outputPath}: ${message}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
