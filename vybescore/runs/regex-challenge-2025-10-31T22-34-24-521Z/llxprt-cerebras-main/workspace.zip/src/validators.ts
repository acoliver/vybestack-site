export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects invalid forms like double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Check basic email format with proper local part and domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  // Must have valid format
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for double dots in local or domain parts
  if (value.includes('..')) {
    return false;
  }

  // Check for trailing dot in local part or domain
  if (value.startsWith('.') || value.endsWith('.') || 
      value.includes('.@') || value.includes('@.')) {
    return false;
  }

  // Check for underscores in domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers in formats like (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix, rejects impossible area codes (0XX or 1XX)
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for length validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle optional +1 prefix
  const startsWithPlusOne = value.startsWith('+1');
  const phoneNumber = startsWithPlusOne ? digitsOnly.substring(1) : digitsOnly;
  
  // Basic length check: 10 digits after removing formatting
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check that area code doesn't start with 0 or 1
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') {
    return false;
  }
  
  // Validate with regex for formats like (212) 555-7890, 212-555-7890, 2125557890
  const phoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s\-]?\d{3}[\s\-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers in common formats
 * Supports landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separator characters for digit counting
  const cleanValue = value.replace(/[\s\-+]/g, '');
  
  // Check if too short
  if (cleanValue.length < 6) {
    return false;
  }
  
  // Regex pattern for Argentine phone numbers
  // This pattern checks for correct structure with optional elements
  const argentinePhoneRegex = /^(\+54\s?)?(0|9\s?)?([1-9]\d{1,3})\s?(\d{6,8})$/;
  
  // Check if pattern matches
  const match = value.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  // Extract the area code from match
  const areaCode = match[3];
  const subscriberNumber = match[4];
  
  // Validate area code has 2-4 digits with first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Validate subscriber number has 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If no country code, must start with trunk prefix 0
  if (!value.startsWith('+54') && !value.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Check for any digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for forbidden name patterns (X Æ A-12 style)
  if (/^[Xx]\s*[Ææ]\s*[Aa][-]?\d+$/.test(value)) {
    return false;
  }
  
  // Pattern allowing unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  return nameRegex.test(value);
}

/**
 * Helper function to run Luhn algorithm check
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Remove non-digits for checksum calculation
  const cleanValue = value.replace(/\D/g, '');
  
  // Process from right to left
  for (let i = cleanValue.length - 1; i >= 0; i--) {
    let digit = parseInt(cleanValue[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers with length/prefix checks plus Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s\-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Visa starts with 4 and is 13/16 digits long
  if (/^4/.test(cleanValue) && (cleanValue.length === 13 || cleanValue.length === 16)) {
    return runLuhnCheck(value);
  }
  
  // Mastercard starts with 5 and is 16 digits long
  if (/^5[1-5]/.test(cleanValue) && cleanValue.length === 16) {
    return runLuhnCheck(value);
  }
  
  // AmEx starts with 34 or 37 and is 15 digits long
  if (/^3[47]/.test(cleanValue) && cleanValue.length === 15) {
    return runLuhnCheck(value);
  }
  
  // If none match, it's not valid
  return false;
}