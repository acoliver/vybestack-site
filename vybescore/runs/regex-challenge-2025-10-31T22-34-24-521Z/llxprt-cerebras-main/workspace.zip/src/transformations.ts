/**
 * Capitalizes the first character of each sentence in the text
 * Insert exactly one space between sentences, collapse extra spaces
 * Leave abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // If text is empty or only whitespace, return as is
  if (!text || !text.trim()) {
    return text;
  }

  // Split text by sentence ending punctuation followed by whitespace or end of string
  // This regex captures the punctuation and any following whitespace
  return text.replace(/(^|[.!?]+)(\s*)([a-z])/g, (match, punctuation, spaces, letter) => {
    // Keep the punctuation, ensure exactly one space, and capitalize the letter
    return punctuation + ' ' + letter.toUpperCase();
  }).trim();
}

/**
 * Extracts all URLs from text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // Regex pattern for URLs - matches http/https protocols
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s,.\]()'"{}]*/gi;
  const matches = text.match(urlRegex);
  
  // Return array of matched URLs or empty array if none
  return matches ? matches : [];
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https:// (case insensitive)
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Helper function to check if URL path contains dynamic elements
 */
function hasDynamicElements(url: string): boolean {
  try {
    const urlObj = new URL(url);
    const path = urlObj.pathname;
    const search = urlObj.search;
    
    // Check for dynamic path elements or query strings
    return path.includes('cgi-bin') || 
           (search && search.length > 0) ||
           /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/.test(path);
  } catch (e) {
    // If URL parsing fails, assume it might have dynamic elements
    return true;
  }
}

/**
 * Rewrites URLs that start with http:// to https://
 * Also moves docs paths to docs.example.com
 */
export function rewriteDocsUrls(text: string): string {
  // Regex to match http:// URLs followed by a domain and possible path
  return text.replace(/http:\/\/([\w.-]+)(\/[^\s,.\]()'"{}]*)?/gi, (match, domain, path = '/') => {
    // Check if path contains dynamic elements that would prevent host rewrite
    if (hasDynamicElements(match)) {
      // Just upgrade to https, no host rewrite
      return `https://${domain}${path}`;
    }
    
    // If path starts with /docs/, rewrite the host
    if (path.startsWith('/docs/')) {
      return `https://docs.${domain}${path}`;
    }
    
    // Otherwise just upgrade to https
    return `https://${domain}${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings
 * Returns 'N/A' for invalid formats or invalid month/day values
 */
export function extractYear(value: string): string {
  // Check if string matches exactly the mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  // If no match, return 'N/A'
  if (!match) {
    return 'N/A';
  }
  
  // Extract parts
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month is 1-12 and day is 1-31
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Return the year part
  return year;
}