import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

export const app = express();
let db: Database | null = null;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Validation functions
function validateRequired(value: string, fieldName: string): string | null {
  if (!value || value.trim() === '') {
    return `${fieldName} is required`;
  }
  return null;
}

function validateEmail(email: string): string | null {
  const trimmed = email.trim();
  if (!trimmed) {
    return 'Email is required';
  }
  // Simple but effective email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmed)) {
    return 'Please enter a valid email address';
  }
  return null;
}

function validatePhone(phone: string): string | null {
  const trimmed = phone.trim();
  if (!trimmed) {
    return 'Phone number is required';
  }
  // Allow international formats: digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  if (!phoneRegex.test(trimmed)) {
    return 'Please enter a valid phone number';
  }
  return null;
}

function validatePostalCode(postalCode: string): string | null {
  const trimmed = postalCode.trim();
  if (!trimmed) {
    return 'Postal / Zip code is required';
  }
  // Allow alphanumeric strings with spaces for international formats
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  if (!postalRegex.test(trimmed)) {
    return 'Please enter a valid postal code';
  }
  return null;
}

function validateForm(data: FormData): ValidationResult {
  const errors: string[] = [];

  const requiredError = validateRequired(data.firstName, 'First name');
  if (requiredError) errors.push(requiredError);

  const lastNameError = validateRequired(data.lastName, 'Last name');
  if (lastNameError) errors.push(lastNameError);

  const addressError = validateRequired(data.streetAddress, 'Street address');
  if (addressError) errors.push(addressError);

  const cityError = validateRequired(data.city, 'City');
  if (cityError) errors.push(cityError);

  const stateError = validateRequired(data.stateProvince, 'State / Province / Region');
  if (stateError) errors.push(stateError);

  const postalError = validatePostalCode(data.postalCode);
  if (postalError) errors.push(postalError);

  const countryError = validateRequired(data.country, 'Country');
  if (countryError) errors.push(countryError);

  const emailError = validateEmail(data.email);
  if (emailError) errors.push(emailError);

  const phoneError = validatePhone(data.phone);
  if (phoneError) errors.push(phoneError);

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Database initialization
export async function initDatabase(): Promise<void> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Initialize SQL.js
  const SQL = await initSqlJs();

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    // Run schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

export { saveDatabase };

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName.trim(),
      formData.lastName.trim(),
      formData.streetAddress.trim(),
      formData.city.trim(),
      formData.stateProvince.trim(),
      formData.postalCode.trim(),
      formData.country.trim(),
      formData.email.trim(),
      formData.phone.trim(),
    ]);

    stmt.free();
    saveDatabase();
  }

  // Redirect to thank you page with first name
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName || 'Friend';
  res.render('thank-you', { firstName });
});

// Server lifecycle
export const PORT = process.env.PORT || '3535';

let server: ReturnType<typeof app.listen> | null = null;

export async function startServer(): Promise<void> {
  await initDatabase();
  return new Promise((resolve) => {
    server = app.listen(Number(PORT), () => {
      console.log(`Server listening on port ${PORT}`);
      resolve();
    });
  });
}

export function stopServer(): void {
  if (db) {
    db.close();
    db = null;
  }
  if (server) {
    server.close();
    server = null;
  }
}

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  stopServer();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  stopServer();
  process.exit(0);
});

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
