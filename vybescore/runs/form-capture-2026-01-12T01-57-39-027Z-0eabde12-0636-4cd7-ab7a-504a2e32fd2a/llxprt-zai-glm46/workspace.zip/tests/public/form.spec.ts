import { describe, expect, it, afterAll, beforeEach } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, stopServer, initDatabase } from '../../src/server';

describe('friendly form (public smoke)', () => {
  const dbPath = path.resolve('data', 'submissions.sqlite');

  beforeEach(() => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });

  it('renders the form with all fields', async () => {
    await initDatabase();
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check all required fields exist with proper labels and inputs
    const fields = [
      { label: 'First name', inputName: 'firstName', inputId: 'firstName' },
      { label: 'Last name', inputName: 'lastName', inputId: 'lastName' },
      { label: 'Street address', inputName: 'streetAddress', inputId: 'streetAddress' },
      { label: 'City', inputName: 'city', inputId: 'city' },
      { label: 'State / Province / Region', inputName: 'stateProvince', inputId: 'stateProvince' },
      { label: 'Postal / Zip code', inputName: 'postalCode', inputId: 'postalCode' },
      { label: 'Country', inputName: 'country', inputId: 'country' },
      { label: 'Email', inputName: 'email', inputId: 'email' },
      { label: 'Phone number', inputName: 'phone', inputId: 'phone' },
    ];

    for (const field of fields) {
      const label = $(`label[for="${field.inputId}"]`);
      expect(label.length).toBeGreaterThan(0);
      expect(label.text().trim()).toBe(field.label);

      const input = $(`#${field.inputId}[name="${field.inputName}"]`);
      expect(input.length).toBeGreaterThan(0);
      expect(input.attr('type')).toBeDefined();
    }

    // Check form action and method
    const form = $('form[action="/submit"][method="post"]');
    expect(form.length).toBeGreaterThan(0);

    // Check submit button
    const submitButton = $('button[type="submit"]');
    expect(submitButton.length).toBeGreaterThan(0);
  });

  it('persists submission and redirects', async () => {
    await initDatabase();
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    // Should redirect with 302
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you\?firstName=/);
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Follow redirect
    const thankYouResponse = await request(app).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you');
    expect($('body').text()).toContain(formData.firstName);
  });

  it('shows validation errors for empty required fields', async () => {
    await initDatabase();
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({});

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    // Check for error list
    const errorList = $('.error-list');
    expect(errorList.length).toBeGreaterThan(0);
    expect(errorList.find('li').length).toBeGreaterThan(0);
  });

  it('shows validation error for invalid email', async () => {
    await initDatabase();
    
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Avenue',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'not-a-valid-email',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const pageText = $('body').text();
    expect(pageText).toMatch(/valid email/i);
  });

  it('accepts international phone formats', async () => {
    await initDatabase();
    
    const testCases = [
      { phone: '+44 20 7946 0958', desc: 'UK format with spaces' },
      { phone: '+54 9 11 1234-5678', desc: 'Argentina format with dashes' },
      { phone: '+1 (555) 123-4567', desc: 'US format with parentheses' },
    ];

    for (const testCase of testCases) {
      const formData = {
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '789 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: testCase.phone,
      };

      const response = await request(app)
        .post('/submit')
        .type('form')
        .send(formData);

      expect(response.status).toBe(302);
    }
  });

  it('accepts international postal code formats', async () => {
    await initDatabase();
    
    const testCases = [
      { postal: 'SW1A 1AA', desc: 'UK format' },
      { postal: 'C1000', desc: 'Argentina format' },
      { postal: 'B1675', desc: 'Argentina B format' },
      { postal: '12345', desc: 'Simple digits' },
    ];

    for (const testCase of testCases) {
      const formData = {
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '789 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: testCase.postal,
        country: 'Test Country',
        email: 'test@example.com',
        phone: '+1 5551234567',
      };

      const response = await request(app)
        .post('/submit')
        .type('form')
        .send(formData);

      expect(response.status).toBe(302);
    }
  });

  it('rejects invalid phone format', async () => {
    await initDatabase();
    
    const formData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '789 Test St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'test@example.com',
      phone: 'invalid-phone!',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const pageText = $('body').text();
    expect(pageText).toMatch(/valid phone/i);
  });

  it('rejects invalid postal code format', async () => {
    await initDatabase();
    
    const formData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '789 Test St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: 'invalid@postal!',
      country: 'Test Country',
      email: 'test@example.com',
      phone: '+1 5551234567',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const pageText = $('body').text();
    expect(pageText).toMatch(/valid postal/i);
  });

  it('preserves form values on validation error', async () => {
    await initDatabase();
    
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Avenue',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'invalid-email',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    // Check that values are preserved
    expect($('#firstName').val()).toBe(formData.firstName);
    expect($('#lastName').val()).toBe(formData.lastName);
    expect($('#email').val()).toBe(formData.email);
  });

  it('serves static stylesheet', async () => {
    await initDatabase();
    
    const response = await request(app).get('/public/styles.css');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/css');
    expect(response.text.length).toBeGreaterThan(100);
  });

  afterAll(() => {
    stopServer();
  });
});
