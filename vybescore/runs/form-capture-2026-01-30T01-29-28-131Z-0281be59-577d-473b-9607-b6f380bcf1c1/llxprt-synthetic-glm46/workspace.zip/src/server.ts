import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

interface Database {
  exec(sql: string): void;
  prepare(sql: string): PreparedStatement;
  export(): Uint8Array;
  close(): void;
}

interface PreparedStatement {
  run(params?: unknown[]): void;
  free(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

const app = express();
const PORT = process.env.PORT || 3535;

let db: Database | null = null;

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[\d\sA-Za-z]+$/;
  return postalCode.trim().length > 0 && postalCodeRegex.test(postalCode);
}

function validateForm(formData: FormSubmission): ValidationResult {
  const errors: string[] = [];
  
  if (!formData.firstName.trim()) errors.push('First name is required');
  if (!formData.lastName.trim()) errors.push('Last name is required');
  if (!formData.streetAddress.trim()) errors.push('Street address is required');
  if (!formData.city.trim()) errors.push('City is required');
  if (!formData.stateProvince.trim()) errors.push('State/Province/Region is required');
  if (!formData.postalCode.trim()) errors.push('Postal/Zip code is required');
  if (!formData.country.trim()) errors.push('Country is required');
  if (!formData.email.trim()) errors.push('Email is required');
  if (!formData.phone.trim()) errors.push('Phone number is required');
  
  if (formData.email.trim() && !validateEmail(formData.email)) {
    errors.push('Email address is not valid');
  }
  
  if (formData.phone.trim() && !validatePhone(formData.phone)) {
    errors.push('Phone number format is not valid');
  }
  
  if (formData.postalCode.trim() && !validatePostalCode(formData.postalCode)) {
    errors.push('Postal code format is not valid');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    const dbPath = path.join(__dirname, 'data', 'submissions.sqlite');
    
    const dbExists = fs.existsSync(dbPath);
    
    if (!dbExists) {
      const schemaPath = path.join(__dirname, 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf-8');
      db = new SQL.Database();
      db.exec(schema);
      
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    } else {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (!db) return;
  
  try {
    const dbPath = path.join(__dirname, 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function shutdownGracefully(): void {
  if (db) {
    saveDatabase();
    db.close();
    db = null;
  }
  
  process.exit(0);
}

export default async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));
  
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.join(__dirname, 'public')));
  
  app.get('/', (req, res) => {
    res.render('form', { errors: [], values: {} });
  });
  
  app.post('/submit', (req, res) => {
    const formData: FormSubmission = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.status(400).render('form', { 
        errors: validation.errors, 
        values: formData 
      });
    }
    
    if (!db) {
      return res.status(500).render('form', { 
        errors: ['Database error occurred. Please try again later.'], 
        values: formData 
      });
    }
    
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      saveDatabase();
      
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Database insertion error:', error);
      return res.status(500).render('form', { 
        errors: ['Failed to save your submission. Please try again.'], 
        values: formData 
      });
    }
  });
  
  app.get('/thank-you', (req, res) => {
    res.render('thank-you', { firstName: 'Friend' });
  });
  
  process.on('SIGTERM', shutdownGracefully);
  process.on('SIGINT', shutdownGracefully);
  
  const server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
  
  process.on('SIGTERM', () => {
    shutdownGracefully();
    server.close();
  });
  
  process.on('SIGINT', () => {
    shutdownGracefully();
    server.close();
  });
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
