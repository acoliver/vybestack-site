import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number;
    if (pageParam === undefined) {
      page = 1; // default
    } else {
      const pageNum = Number(pageParam);
      if (isNaN(pageNum) || pageNum <= 0 || !Number.isInteger(pageNum)) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer.' });
      }
      if (pageNum > 1000) { // reasonable upper bound
        return res.status(400).json({ error: 'Invalid page parameter. Page number too large.' });
      }
      page = pageNum;
    }

    // Validate limit parameter
    let limit: number;
    if (limitParam === undefined) {
      limit = 5; // default
    } else {
      const limitNum = Number(limitParam);
      if (isNaN(limitNum) || limitNum <= 0 || !Number.isInteger(limitNum)) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer.' });
      }
      if (limitNum > 100) { // reasonable upper bound
        return res.status(400).json({ error: 'Invalid limit parameter. Limit too large.' });
      }
      limit = limitNum;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
