/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle the equal parameter - if it's a boolean, use Object.is for truthy values or always return false for falsy
  const equalFn: EqualFn<T> | undefined = 
    typeof equal === 'function' ? equal : 
    equal === true ? Object.is : 
    equal === false ? () => false : 
    undefined

  // Track dependencies for this computed
  const dependencies = new Set<Observer<unknown>>()
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // When updating, we need to track what this computed depends on
      // First clear existing dependencies
      dependencies.clear()
      
      // Temporarily replace getActiveObserver to collect dependencies
      const originalGetActiveObserver = getActiveObserver;
      // @ts-expect-error TypeScript limitation with replacing functions
      global.getActiveObserver = () => observer;
      
      try {
        const newValue = updateFn(prevValue);
        
        // Compare with previous value if equalFn exists
        if (equalFn && prevValue !== undefined && equalFn(prevValue, newValue)) {
          return prevValue;
        }
        
        return newValue;
      } finally {
        // Restore original getActiveObserver function
        // @ts-expect-error TypeScript limitation with replacing functions
        global.getActiveObserver = originalGetActiveObserver;
      }
    }
  };
  
  // Run initial computation
  updateObserver(observer);
  
  // Return getter function that tracks when this computed is used by others
  return () => {
    const activeObserver = getActiveObserver();
    if (activeObserver) {
      // @ts-expect-error TypeScript limitation with dynamic properties
      if (!activeObserver.dependencies) {
        // @ts-expect-error TypeScript limitation with dynamic properties
        activeObserver.dependencies = new Set<Observer<unknown>>();
      }
      // @ts-expect-error TypeScript limitation with dynamic properties
      activeObserver.dependencies.add(observer);
    }
    
    return observer.value!;
  };
}