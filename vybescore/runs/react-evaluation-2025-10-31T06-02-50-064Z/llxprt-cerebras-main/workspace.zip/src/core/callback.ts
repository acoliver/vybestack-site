/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver } from '../types/reactive.js';

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  };
  
  // Register observer to track dependencies and get initial value
  updateObserver(observer);
  
  let disposed = false;
  
  // Store a reference to parent observer for cleanup
  const parentObserver = getActiveObserver();
  
  return () => {
    if (disposed) return;
    disposed = true;
    
    // Clear observer to stop further updates
    observer.value = undefined;
    observer.updateFn = () => undefined as unknown as T;
    
    // Remove this callback from parent's dependencies
    if (parentObserver) {
      // @ts-expect-error TypeScript limitation with dynamic properties
      if (parentObserver.dependencies) {
        // @ts-expect-error TypeScript limitation with dynamic properties
        parentObserver.dependencies.delete(observer);
      }
    }
  };
}