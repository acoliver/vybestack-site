/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part of an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle the equal parameter - if it's a boolean, use Object.is for truthy values or always return false for falsy
  const equalFn: EqualFn<T> | undefined = 
    typeof equal === 'function' ? equal : 
    equal === true ? Object.is : 
    equal === false ? () => false : 
    undefined

  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      subject.observer = activeObserver
    }
    return subject.value
  }

  const setter: SetterFn<T> = (nextValue: T) => {
    // If equalFn is provided, use it to check if value has actually changed
    // If no equalFn is provided, always update
    if (subject.equalFn && subject.equalFn(subject.value, nextValue)) {
      return subject.value
    }

    subject.value = nextValue
    
    // If there's an observer, update it
    if (subject.observer) {
      updateObserver(subject.observer as Observer<unknown>)
    }
    
    return subject.value
  }

  return [getter, setter]
}