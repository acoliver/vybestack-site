/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, Subject } from '../types/reactive.js'

/**
 * Extended observer type that tracks its subscriptions for cleanup.
 */
type CleanupObserver<T> = Observer<T> & {
  _subjects?: Set<Subject<unknown>>
}

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn & { _observer: CleanupObserver<T> } {
  const observer: CleanupObserver<T> = {
    value,
    updateFn,
    _isObserver: true,
    _subjects: new Set(),
  }
  
  // Register observer to track dependencies by running it once
  // This establishes which subjects this callback depends on
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects that are tracking it
    if (observer._subjects) {
      for (const subject of observer._subjects) {
        if (subject.observers) {
          const index = subject.observers.indexOf(observer)
          if (index !== -1) {
            subject.observers.splice(index, 1)
          }
        }
      }
      observer._subjects.clear()
    }
    
    // Optionally clear to help GC
    observer.value = undefined
  }
  
  // Attach observer for debugging
  ;(unsubscribe as UnsubscribeFn & { _observer: CleanupObserver<T> })._observer = observer
  
  return unsubscribe as UnsubscribeFn & { _observer: CleanupObserver<T> }
}
