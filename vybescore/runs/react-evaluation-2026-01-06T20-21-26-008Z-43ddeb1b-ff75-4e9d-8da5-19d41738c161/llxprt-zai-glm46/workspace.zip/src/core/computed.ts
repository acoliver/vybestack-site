/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  ObserverR,
  updateObserver,
  getActiveObserver,
  EqualFn,
  Subject
} from '../types/reactive.js'

/**
 * Extended observer type that tracks its subscriptions for cleanup.
 */
type CleanupObserver<T> = Observer<T> & {
  _subjects?: Set<Subject<unknown>>
}

// Export the computed observer for debugging
export type { ComputedObserver as ComputedObserverType }

type ComputedObserver<T> = Observer<T> & { observers?: ObserverR[] }

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> & { _observer: ComputedObserver<T> } {
  const o: ComputedObserver<T> = {
    name: options?.name,
    value,
    updateFn,
    _isObserver: true,
    observers: undefined,
    _dirty: false,  // Start clean since we compute during creation
  }
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && (observer as unknown as { _isObserver?: true })._isObserver) {
      // Register this observer as dependent on the computed
      if (!o.observers) o.observers = []
      if (!o.observers.includes(observer)) {
        o.observers.push(observer)
        // Track this computed in the observer's cleanup set
        const cleanupObs = observer as unknown as CleanupObserver<unknown>
        if (!cleanupObs._subjects) {
          cleanupObs._subjects = new Set()
        }
        cleanupObs._subjects.add(o as Subject<unknown>)
      }
    }
    
    // Only recompute if dirty
    if (o._dirty) {
      updateObserver(o)
    }
    
    return o.value!
  }
  
  // Attach observer to the function for debugging
  ;(read as unknown as { _observer: ComputedObserver<T> })._observer = o
  
  // Compute initial value
  updateObserver(o)
  
  return read as GetterFn<T> & { _observer: ComputedObserver<T> }
}
