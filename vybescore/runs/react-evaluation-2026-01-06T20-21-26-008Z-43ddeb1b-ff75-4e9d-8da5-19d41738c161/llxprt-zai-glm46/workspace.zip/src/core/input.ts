/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Extended observer type that tracks its subscriptions for cleanup.
 */
type CleanupObserver<T> = Observer<T> & {
  _subjects?: Set<Subject<unknown>>
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> & { observers?: ObserverR[] } = {
    name: options?.name,
    observers: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && (observer as unknown as { _isObserver?: true })._isObserver) {
      if (!s.observers) s.observers = []
      // Check if observer already exists to prevent duplicates
      if (!s.observers.includes(observer)) {
        s.observers.push(observer)
        // Track this subject in the observer's cleanup set
        const cleanupObs = observer as unknown as CleanupObserver<unknown>
        if (!cleanupObs._subjects) {
          cleanupObs._subjects = new Set()
        }
        cleanupObs._subjects.add(s as Subject<unknown>)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all observers that value changed
    if (s.observers) {
      // Collect observers to notify to avoid issues with array modification during iteration
      const observersToNotify = [...s.observers]
      
      // First pass: mark all observers and their dependents as dirty
      for (const obs of observersToNotify) {
        // For computed observers, propagate dirty flag to their dependents FIRST
        if (obs.observers) {
          const dependentsToNotify = [...obs.observers]
          for (const dependent of dependentsToNotify) {
            (dependent as unknown as { _dirty?: boolean })._dirty = true
          }
        }
        // Mark observer itself as dirty AFTER marking dependents
        (obs as unknown as { _dirty?: boolean })._dirty = true
      }
      
      // Second pass: actually execute all observers (which will trigger callbacks)
      for (const obs of observersToNotify) {
        // Check if still dirty (might have been cleared by a parent)
        if ((obs as unknown as { _dirty?: boolean })._dirty) {
          updateObserver(obs as Observer<unknown>)
        }
      }
    }
    
    return s.value
  }

  return [read, write]
}
