// Node.js test file for pagination functionality
import { createApp } from './src/server/app.js';
import { createDatabase } from './src/server/db.js';

async function testPagination() {
  console.log('Creating database...');
  const db = await createDatabase();
  const app = await createApp(db);

  console.log('Testing pagination functionality...');
  
  // Test default values
  console.log('\n1. Testing default values (page=1, limit=5):');
  try {
    const response1 = await fetch('http://localhost:9999/inventory');
    const data1 = await response1.json();
    console.log('Default response:', {
      page: data1.page,
      limit: data1.limit,
      total: data1.total,
      itemsCount: data1.items.length,
      hasNext: data1.hasNext
    });
  } catch (error) {
    console.error('Error with default values:', error.message);
  }
  
  // Test page 2
  console.log('\n2. Testing page 2:');
  try {
    const response2 = await fetch('http://localhost:9999/inventory?page=2&limit=5');
    const data2 = await response2.json();
    console.log('Page 2 response:', {
      page: data2.page,
      limit: data2.limit,
      total: data2.total,
      itemsCount: data2.items.length,
      hasNext: data2.hasNext
    });
  } catch (error) {
    console.error('Error with page 2:', error.message);
  }
  
  // Test invalid page parameter
  console.log('\n3. Testing invalid page parameter:');
  try {
    const response3 = await fetch('http://localhost:9999/inventory?page=abc');
    const data3 = await response3.json();
    console.log('Invalid page response:', data3);
  } catch (error) {
    console.error('Error with invalid page:', error.message);
  }
  
  // Test limit validation
  console.log('\n4. Testing limit validation:');
  try {
    const response4 = await fetch('http://localhost:9999/inventory?limit=0');
    const data4 = await response4.json();
    console.log('Invalid limit response:', data4);
  } catch (error) {
    console.error('Error with invalid limit:', error.message);
  }
  
  console.log('\nPagination tests completed!');
  process.exit(0);
}

// Don't run tests automatically
// testPagination();