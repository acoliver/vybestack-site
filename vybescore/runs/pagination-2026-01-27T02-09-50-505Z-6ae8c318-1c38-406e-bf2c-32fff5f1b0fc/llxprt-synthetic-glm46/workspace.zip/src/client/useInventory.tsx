import { useEffect, useState } from 'react';
import type { InventoryPage } from '../shared/types';

interface InventoryState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  data: InventoryPage | null;
  error: string | null;
}

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number): InventoryState {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);

  useEffect(() => {
    let cancelled = false;

    async function load(): Promise<void> {
      setState((prev) => ({ ...prev, status: 'loading', error: null }));
      try {
        const params = new URLSearchParams({
          page: page.toString(),
          limit: limit.toString()
        });
        const response = await fetch(`/inventory?${params}`);
        if (!response.ok) {
          // Try to parse the error message from the server response
          let errorMessage = `Request failed with status ${response.status}`;
          try {
            const errorResponse = await response.json();
            if (errorResponse.error) {
              errorMessage = errorResponse.error;
            }
          } catch {
            // If parsing fails, use the default message
          }
          throw new Error(errorMessage);
        }
        const payload = (await response.json()) as InventoryPage;
        if (!cancelled) {
          setState({ status: 'ready', data: payload, error: null });
        }
      } catch (error) {
        if (!cancelled) {
          const message = error instanceof Error ? error.message : 'Unknown error';
          setState({ status: 'error', data: null, error: message });
        }
      }
    }

    if (state.status === 'idle') {
      load();
    }
    // When page or limit changes, reset to loading and refetch
    else {
      load();
    }

    return () => {
      cancelled = true;
    };
  }, [page, limit, state.status]);

  // Reset when dependencies change to avoid stale data
  useEffect(() => {
    setState((prev) => ({ ...prev, status: 'idle' }));
  }, [page, limit]);

  return state;
}
