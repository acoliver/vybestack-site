import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): React.ReactElement {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): React.ReactElement {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const canGoPrevious = currentPage > 1;
  const canGoNext = data.hasNext;

  const handlePrevious = (): void => {
    if (canGoPrevious) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNext = (): void => {
    if (canGoNext) {
      setCurrentPage(currentPage + 1);
    }
  };

  // Empty state handling
  if (data.items.length === 0) {
    return (
      <section>
        <h1>Inventory</h1>
        <p>No inventory items found.</p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      
      <nav aria-label="Pagination navigation">
        <button 
          onClick={handlePrevious}
          disabled={!canGoPrevious}
          style={{ marginRight: '1rem' }}
        >
          Previous
        </button>
        <span style={{ margin: '0 1rem' }}>
          Page {currentPage} of {data.total > 0 ? Math.ceil(data.total / PAGE_LIMIT) : 1} 
          (Showing {data.items.length} of {data.total} items)
        </span>
        <button 
          onClick={handleNext}
          disabled={!canGoNext}
          style={{ marginLeft: '1rem' }}
        >
          Next
        </button>
      </nav>
    </section>
  );
}
