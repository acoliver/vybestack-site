/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * - Capitalize the first character of each sentence (after .?!)
 * - Insert exactly one space between sentences even if input omitted it
 * - Collapse extra spaces sensibly while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, capitalize the first letter of the entire text
  let result = text.replace(/^\s*([a-zA-Zà-ÿÀ-ÿĀ-žÑñ])/u, (match, letter) => {
    return match.replace(letter, letter.toUpperCase());
  });
  
  // Then handle sentence endings (.?!)
  // Capitalize letters that come after sentence endings
  result = result.replace(/([.!?]+\s*)([a-zA-Zà-ÿÀ-ÿĀ-žÑñ])/gu, (match, ending, letter) => {
    return ending + letter.toUpperCase();
  });
  
  // Clean up multiple spaces
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * Extract all URLs detected in the text.
 * Return an array of URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex that captures the URL and removes trailing punctuation
  const urlRegex = /\bhttps?:\/\/[^\s<>"{}|\\^`[\]]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * Replace http:// schemes with https:// while leaving secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://.
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, ?, &, =, .jsp, .php, etc.)
 * - Preserve nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Find all http:// URLs
  const urlRegex = /http:\/\/([^\/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(urlRegex, (match, domain, path) => {
    let finalDomain = domain;
    const finalPath = path;
    
    // Check if path contains dynamic hints that prevent host rewrite
    const hasDynamicHints = /(\?|&|=|\\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
    
    // Only rewrite host if path starts with /docs/ and has no dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Replace the domain with docs.domain
      finalDomain = 'docs.' + domain;
    }
    
    return 'https://' + finalDomain + finalPath;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 * Return N/A if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}