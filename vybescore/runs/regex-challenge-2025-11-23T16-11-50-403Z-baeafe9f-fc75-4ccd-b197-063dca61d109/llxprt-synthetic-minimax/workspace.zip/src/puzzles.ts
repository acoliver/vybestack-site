/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with prefix
  const regex = new RegExp(`\\b${escapedPrefix}[\\w-]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionsLower = exceptions.map(exc => exc.toLowerCase());
  
  return matches.filter(match => {
    const matchLower = match.toLowerCase();
    return !exceptionsLower.includes(matchLower);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find tokens that appear after a digit (capturing the full match including digit)
  const regex = new RegExp(`(\\d)${escapedToken}`, 'g');
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * TODO: Check for strong password with various requirements.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for no immediate repeated sequences like abab
  // This regex looks for any 2+ character sequence that repeats immediately
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Simple IPv6 detection patterns
  // Full IPv6 format (8 groups of 4 hex digits)
  const fullPattern = /\b(?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}\b/;
  
  // Compressed IPv6 with :: 
  const compressedPattern = /\b(?:[0-9A-Fa-f]{1,4}:)*::(?:[0-9A-Fa-f]{1,4}:)*[0-9A-Fa-f]{1,4}\b/;
  
  // Check if it's an IPv4 address first - exclude those
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  return fullPattern.test(value) || compressedPattern.test(value);
}