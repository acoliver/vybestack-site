export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to run Luhn checksum validation for credit cards
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email addresses with basic rules.
 * Accept typical addresses like name+tag@example.co.uk
 * Reject double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  const trimmed = value.trim();
  
  // Basic structure check
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(trimmed)) {
    return false;
  }
  
  // Additional checks
  // No consecutive dots
  if (trimmed.includes('..')) {
    return false;
  }
  
  // No trailing dots in domain
  if (trimmed.match(/@[^@]+\.$/)) {
    return false;
  }
  
  // No underscores in domain
  if (trimmed.match(/@[^@]+_/)) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  const phoneNumber = value.trim();
  
  // Remove all non-digit characters except leading +
  const digitRegex = /^\+?1?[\s\-()]*(\d{3})[\s\-()]*(\d{3})[\s\-\.]*(\d{4})[\s\-\.]*$/;
  const match = digitRegex.exec(phoneNumber);
  
  if (!match) {
    return false;
  }
  
  const areaCode = parseInt(match[1], 10);
  const exchangeCode = parseInt(match[2], 10);
  
  // Check for impossible area codes (0 or 1)
  if (areaCode === 0 || areaCode === 1) {
    return false;
  }
  
  // Check for impossible exchange codes (0 or 1)
  if (exchangeCode === 0 || exchangeCode === 1) {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handle landlines and mobiles such as:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  const phoneNumber = value.trim();
  
  // Remove all non-digit characters except spaces and hyphens for analysis
  const normalized = phoneNumber.replace(/[\s\-]/g, '');
  
  // Pattern: Optional +54, Optional 9 (mobile indicator), Optional 0 (trunk prefix),
  // 2-4 digit area code (first digit 1-9), 6-8 digit subscriber number
  const phoneRegex = /^(?:\+54)?9?0?([1-9]\d{1,3})(\d{6,8})$/;
  const match = phoneRegex.exec(normalized);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code should be 2-4 digits, first digit 1-9 (already validated by regex)
  // Subscriber number should be 6-8 digits (already validated by regex)
  
  // If no country code, must have trunk prefix (0)
  if (!phoneNumber.startsWith('+54')) {
    if (!/^0\d/.test(phoneNumber.replace(/[\s\-]/g, ''))) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate names with unicode letters, accents, apostrophes, hyphens, spaces.
 * Reject digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  const trimmed = value.trim();
  
  if (trimmed.length === 0) {
    return false;
  }
  
  // Allow unicode letters, spaces, apostrophes, hyphens
  // Reject if contains digits or unusual symbols
  const nameRegex = /^[\p{L}\p{M}\s'\-]+$/u;
  
  if (!nameRegex.test(trimmed)) {
    return false;
  }
  
  // Reject names that look like codes or contain numbers
  if (/\d/.test(trimmed)) {
    return false;
  }
  
  // Reject names with multiple consecutive spaces
  if (/\s{2,}/.test(trimmed)) {
    return false;
  }
  
  // Reject names starting or ending with spaces (after trim)
  return true;
}

/**
 * Validate credit card numbers with Luhn checksum.
 * Accept Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  const trimmed = value.replace(/\s|-/g, '');
  
  // Must be 13-19 digits
  if (!/^\d{13,19}$/.test(trimmed)) {
    return false;
  }
  
  // Check card type prefixes
  const isVisa = /^4\d{12}(\d{3})?(\d{3})?$/;
  const isMastercard = /^5[1-5]\d{14}$/;
  const isAmEx = /^3[47]\d{13}$/;
  
  if (!isVisa.test(trimmed) && !isMastercard.test(trimmed) && !isAmEx.test(trimmed)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(trimmed);
}