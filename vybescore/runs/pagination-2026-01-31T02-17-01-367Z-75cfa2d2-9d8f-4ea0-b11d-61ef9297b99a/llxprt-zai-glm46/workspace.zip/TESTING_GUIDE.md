# Manual Testing Guide

## Starting the Server

```bash
npm run dev:server
```

The server will start on http://localhost:3333

## API Testing Examples

### 1. Default Pagination (page 1, limit 5)
```bash
curl "http://localhost:3333/inventory"
```
Expected: Items 1-5, page=1, limit=5, total=15, hasNext=true

### 2. Second Page
```bash
curl "http://localhost:3333/inventory?page=2&limit=5"
```
Expected: Items 6-10, page=2, limit=5, total=15, hasNext=true

### 3. Last Page
```bash
curl "http://localhost:3333/inventory?page=3&limit=5"
```
Expected: Items 11-15, page=3, limit=5, total=15, hasNext=false

### 4. Beyond Last Page
```bash
curl "http://localhost:3333/inventory?page=4&limit=5"
```
Expected: Empty items array, page=4, limit=5, total=15, hasNext=false

### 5. Custom Limit
```bash
curl "http://localhost:3333/inventory?page=1&limit=3"
```
Expected: Items 1-3, page=1, limit=3, total=15, hasNext=true

### 6. Invalid Page (Negative)
```bash
curl "http://localhost:3333/inventory?page=-1"
```
Expected: HTTP 400, error: "Invalid page parameter: must be a positive integer"

### 7. Invalid Page (Zero)
```bash
curl "http://localhost:3333/inventory?page=0"
```
Expected: HTTP 400, error: "Invalid page parameter: must be a positive integer"

### 8. Invalid Page (Non-numeric)
```bash
curl "http://localhost:3333/inventory?page=abc"
```
Expected: HTTP 400, error: "Invalid page parameter: must be a positive integer"

### 9. Invalid Limit (Negative)
```bash
curl "http://localhost:3333/inventory?limit=-5"
```
Expected: HTTP 400, error: "Invalid limit parameter: must be a positive integer"

### 10. Invalid Limit (Zero)
```bash
curl "http://localhost:3333/inventory?limit=0"
```
Expected: HTTP 400, error: "Invalid limit parameter: must be a positive integer"

### 11. Invalid Limit (Non-numeric)
```bash
curl "http://localhost:3333/inventory?limit=xyz"
```
Expected: HTTP 400, error: "Invalid limit parameter: must be a positive integer"

## React Client Testing

The React client (`InventoryView.tsx`) should:
1. Load the first page of inventory on initial render
2. Display items in a list with name, SKU, and price
3. Show pagination controls at the bottom
4. Enable the "Previous" button only when not on the first page
5. Enable the "Next" button only when there are more pages
6. Display current page number and total pages
7. Reload data when navigating between pages
8. Show error messages from the server if validation fails
9. Display empty state when no items are returned

## Database Information

The database is seeded with 15 inventory items:
- IDs: 1-15
- Default pagination: 5 items per page
- Total pages with default limit: 3 pages

## Automated Checks

All checks should pass:
```bash
npm run typecheck  # TypeScript compilation
npm run lint       # ESLint
npm run test:public # Public API tests
```
