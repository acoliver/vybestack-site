/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const subject: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
    dependents: new Set(),
    isDisposed: false,
  }

  const observer: Observer<T> = {
    name: options?.name,
    value,
    isDisposed: false,
    dependents: new Set(),
    updateFn,
  }

  const read: GetterFn<T> = () => {
    // Re-compute the value every time it's accessed (true reactive behavior)
    updateObserver(observer)
    
    // Update subject value from observer
    if (observer.value !== undefined) {
      subject.value = observer.value
    }
    
    // Return the computed value
    return subject.value
  }

  return read
}
