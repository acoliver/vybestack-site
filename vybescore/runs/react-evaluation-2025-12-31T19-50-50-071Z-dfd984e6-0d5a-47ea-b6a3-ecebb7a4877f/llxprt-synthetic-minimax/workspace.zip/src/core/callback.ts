/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, Subject, updateObserver, subscribe, getActiveObserver, UpdateFn } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const initialValue = value ?? ({} as T)
  
  const subject: Subject<T> = {
    name: 'callback',
    value: initialValue,
    equalFn: undefined,
    dependents: new Set(),
    isDisposed: false,
  }

  const observer: Observer<T> = {
    name: 'callback-observer',
    value: initialValue,
    isDisposed: false,
    updateFn: () => {
      // Execute the user's callback function and track dependencies
      const result = updateFn()
      return result ?? initialValue
    },
  }
  
  // Execute callback initially to establish dependency tracking
  // This makes the callback part of the reactive dependency graph
  updateObserver(observer)
  
  // Update subject value if observer has a value
  if (observer.value !== undefined) {
    subject.value = observer.value
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Mark disposed to stop further updates
    observer.isDisposed = true
    subject.isDisposed = true
    
    // Clear dependency tracking
    if (subject.dependents) {
      subject.dependents.clear()
    }
    
    // Clear the observer to stop updates
    observer.updateFn = () => {
      return initialValue
    }
  }
}
