/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  isDisposed?: boolean
  updateFn?: UpdateFn<unknown>
  value?: unknown
  dependents?: Set<ObserverR>
  observable?: unknown
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  dependents: Set<ObserverR>
  isDisposed?: boolean
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // If updateFn expects arguments but observer.value is undefined,
    // try to pass the original value that was provided during creation
    const result = observer.updateFn(observer.value)
    observer.value = result
  } finally {
    activeObserver = previous
  }
}

export function subscribe<T>(observer: ObserverR, subject: Subject<T>): void {
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(observer)
}

export function unsubscribe<T>(observer: ObserverR, subject: Subject<T>): void {
  if (subject.dependents) {
    subject.dependents.delete(observer)
  }
}

export function notifyDependents<T>(subject: Subject<T>): void {
  if (subject.dependents) {
    const dependentsArray = Array.from(subject.dependents)
    dependentsArray.forEach(dependent => {
      if (!dependent.isDisposed && dependent.updateFn) {
        updateObserver(dependent as Observer<unknown>)
      }
    })
  }
}
