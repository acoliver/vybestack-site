declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): unknown;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    free(): void;
  }

  export interface Statement {
    run(...params: unknown[]): unknown;
    free(): void;
  }

  export default function initSqlJs(): Promise<typeof SqlJs>;

  export namespace SqlJs {
    const Database: new (data?: Uint8Array) => Database;
  }
}