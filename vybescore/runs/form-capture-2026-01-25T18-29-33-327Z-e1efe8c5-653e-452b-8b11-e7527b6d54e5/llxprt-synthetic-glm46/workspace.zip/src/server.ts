import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import fs from 'fs';
import { readFileSync } from 'fs';

// Form data interface
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Validation errors interface
interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Validate form data
function validateFormData(data: Partial<FormData>): { isValid: boolean; errors: ValidationErrors } {
  const errors: ValidationErrors = {};
  
  // Required field validation
  if (!data.firstName || data.firstName.trim() === '') {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName || data.lastName.trim() === '') {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city || data.city.trim() === '') {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.stateProvince = 'State / Province / Region is required';
  }
  
  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.postalCode = 'Postal / Zip code is required';
  }
  
  if (!data.country || data.country.trim() === '') {
    errors.country = 'Country is required';
  }
  
  if (!data.email || data.email.trim() === '') {
    errors.email = 'Email is required';
  } else {
    // Email validation (simple regex)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }
  
  if (!data.phone || data.phone.trim() === '') {
    errors.phone = 'Phone number is required';
  } else {
    // Phone validation (accept digits, spaces, parentheses, dashes, and leading +)
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }
  
  // Postal code validation (alphanumeric)
  if (data.postalCode) {
    // Accept alphanumeric characters with possible spaces, like UK "SW1A 1AA" or Argentine formats
    const postalCodeRegex = /^[a-zA-Z0-9\s]+$/;
    if (!postalCodeRegex.test(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Polyfill __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Database interface
let db: import('sql.js').Database | null = null;

// Setup Express app
const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'src', 'templates'));

// Initialize database
async function initializeDatabase() {
  try {
    const SQL = await initSqlJs();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    try {
      // Try to load existing database
      const filebuffer = readFileSync(dbPath);
      db = new SQL.Database(filebuffer);
    } catch (error) {
      // If file doesn't exist, create a new database
      db = new SQL.Database();
      
      // Read schema
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      const schema = readFileSync(schemaPath, 'utf8');
      
      // Execute schema
      db.run(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Graceful shutdown function
async function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Shutting down gracefully.`);
  
if (db) {
      try {
        // Save database to file
        const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
        const data = db.export();
        fs.writeFileSync(dbPath, Buffer.from(data));
        console.log('Database saved successfully.');
      } catch (error) {
        console.error('Error saving database:', error);
      }
    }
  
  process.exit(0);
}

// Routes
// GET / - render the form
app.get('/', (req, res) => {
  res.render('form', { 
    values: {}, 
    errors: [] 
  });
});

// POST /submit - handle form submission
app.post('/submit', (req, res) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };
  
  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    // If validation fails, re-render the form with errors and entered values
    const errorMessages = Object.values(validation.errors);
    return res.status(400).render('form', {
      values: formData,
      errors: errorMessages
    });
  }
  
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    // Database methods should be available
    
    // Insert form data into database
    const insertStatement = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    insertStatement.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    insertStatement.free();
    
    // Redirect to thank you page with first name for personalization
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName || '')}`);
    
  } catch (error) {
    console.error('Error saving form data to database:', error);
    const errorMessages = ['An error occurred while saving your data. Please try again.'];
    return res.status(500).render('form', {
      values: formData,
      errors: errorMessages
    });
  }
});

// GET /thank-you - render the thank you page
app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'There';
  res.render('thank-you', { firstName });
});

// Register signal handlers
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer() {
  await initializeDatabase();
  
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
