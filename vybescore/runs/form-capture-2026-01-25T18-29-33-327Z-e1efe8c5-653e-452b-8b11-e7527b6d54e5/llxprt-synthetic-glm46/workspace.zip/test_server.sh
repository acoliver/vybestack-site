#!/bin/bash

# Start the server and wait for it to initialize
npm start &
SERVER_PID=$!

# Give the server time to start up
sleep 5

# Verify server is responding
curl -s http://localhost:3535/

# Kill the server
kill $SERVER_PID
wait $SERVER_PID 2>/dev/null

echo "Server test completed"