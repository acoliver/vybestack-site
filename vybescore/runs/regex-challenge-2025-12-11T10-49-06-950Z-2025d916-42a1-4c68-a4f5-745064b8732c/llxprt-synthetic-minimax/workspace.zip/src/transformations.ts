/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences based on ending punctuation
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  const processedSentences = sentences.map(sentence => {
    const trimmed = sentence.trim();
    if (!trimmed) return trimmed;
    
    // Capitalize first letter
    const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
    
    return capitalized;
  });
  
  // Join sentences with single space
  return processedSentences.join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that captures http/https URLs
  const urlRegex = /\bhttps?:\/\/[^\s<>"')\]]+/gi;
  
  const matches = text.match(urlRegex);
  if (!matches) {
    return [];
  }
  
  // Clean up trailing punctuation and other characters
  return matches.map(url => {
    // Remove trailing punctuation that might be sentence ending
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but leave https:// untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com\/([^\s<>"')\]]*)/gi, (match, path) => {
    // Always upgrade to https
    let result = 'https://example.com/';
    
    // Check if path should trigger host rewrite
    const shouldRewriteHost = !path.includes('?') && !path.includes('&') && !path.includes('=') &&
                              !path.includes('cgi-bin') &&
                              !path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i);
    
    if (shouldRewriteHost && path.startsWith('docs/')) {
      // Rewrite host to docs.example.com
      result = 'https://docs.example.com/' + path;
    } else {
      // Keep original host but upgrade to https
      result = 'https://example.com/' + path;
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Validate month (01-12)
  const monthNum = parseInt(month, 10);
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const dayNum = parseInt(day, 10);
  const daysInMonth = new Date(parseInt(year, 10), monthNum, 0).getDate();
  
  if (dayNum < 1 || dayNum > daysInMonth) {
    return 'N/A';
  }
  
  return year;
}
