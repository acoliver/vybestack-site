/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words starting with prefix
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z0-9]*\\b`, 'g');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(match => !exceptions.includes(match));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all occurrences where token is preceded by a digit (not at start of string)
  const pattern = new RegExp(`(\\d${token})`, 'g');
  const matches = text.match(pattern) || [];
  
  // Return the full matches (digit + token)
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Must not contain whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol
  if (!/[!@#$%^&*()_+\-={}[\];':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Must not contain immediate repeated sequences like "abab"
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns
  // Pattern 1: Standard IPv6 with 8 groups of 4 hex digits
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Pattern 2: IPv6 with :: (shorthand for consecutive zeros)
  const shorthandIPv6 = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // Pattern 3: IPv6 with :: at the end
  const endIPv6 = /\b[0-9a-fA-F]{1,4}:(?:[0-9a-fA-F]{1,4}:)*::\b/;
  
  // Pattern 4: IPv6 with :: at the beginning
  const startIPv6 = /\b::(?:[0-9a-fA-F]{1,4}:){1,}[0-9a-fA-F]{0,4}\b/;
  
  // Pattern 5: IPv6 with embedded IPv4 (IPv4 in last two groups)
  const embeddedIPv4 = /\b(?:[0-9a-fA-F]{1,4}:){5}::(?:\d{1,3}\.){3}\d{1,3}\b|\b(?:[0-9a-fA-F]{1,4}:){6}\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // Pattern 6: IPv6 with single :: anywhere in between
  const middleIPv6 = /\b[0-9a-fA-F]{1,4}:(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // Check against all patterns
  return fullIPv6.test(value) || shorthandIPv6.test(value) || 
         endIPv6.test(value) || startIPv6.test(value) || 
         embeddedIPv4.test(value) || middleIPv6.test(value);
}