export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with common patterns
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for obviously invalid forms
  if (value.includes('..') || value.endsWith('.') || value.includes('@example.co.uk.')) {
    return false;
  }
  
  // Check for domain underscores (e.g., bad_domain_1.com)
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except '+'
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if too short after cleaning
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let digits = cleaned;
  if (cleaned.startsWith('+1')) {
    digits = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length === 11) {
    digits = cleaned.substring(1);
  }
  
  // Must have exactly 10 digits after country code removal
  if (digits.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators, keep only digits and +
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern for country code present: +54[9](optional)areaCode(2-4 digits starting 1-9)subscriber(6-8 digits)
  const countryCodePattern = /^(\+54)(9)?([1-9]\d{1,3})(\d{6,8})$/;
  // Pattern for country code absent: 0areaCode(2-4 digits starting 1-9)subscriber(6-8 digits)
  const trunkPattern = /^(0)([1-9]\d{1,3})(\d{6,8})$/;
  
  const countryMatch = cleaned.match(countryCodePattern);
  if (countryMatch) {
    const [, , , areaCode, subscriber] = countryMatch;
    const totalLength = areaCode.length + subscriber.length;
    // Total subscriber part (area code + subscriber number) should be 8-12 digits
    return totalLength >= 8 && totalLength <= 12;
  }
  
  const trunkMatch = cleaned.match(trunkPattern);
  if (trunkMatch) {
    const [, , areaCode, subscriber] = trunkMatch;
    const totalLength = areaCode.length + subscriber.length;
    // Total subscriber part should be 8-12 digits
    return totalLength >= 8 && totalLength <= 12;
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value.trim()) {
    return false;
  }
  
  // Allow unicode letters (including accented characters), spaces, apostrophes, and hyphens
  // Reject digits, symbols, and weird patterns like X Æ A-12
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject obviously fake names or names with patterns like X Æ A-12
  if (value.includes('Æ') || /\b[A-Z]\s+[A-Z]\s+[A-Z]-\d+/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit cards with proper card type detection and Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check card type and prefix validation
  let isValidCardType = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (cleaned.startsWith('4') && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19)) {
    isValidCardType = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if ((cleaned.startsWith('51') || cleaned.startsWith('52') || cleaned.startsWith('53') || 
             cleaned.startsWith('54') || cleaned.startsWith('55') || 
             (cleaned.startsWith('222') && cleaned.substring(0, 4) >= '2221' && cleaned.substring(0, 4) <= '2720')) &&
            cleaned.length === 16) {
    isValidCardType = true;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15) {
    isValidCardType = true;
  }
  
  if (!isValidCardType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
