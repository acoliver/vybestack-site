/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

function normalizeEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') {
    return equal ? (lhs: T, rhs: T) => lhs === rhs : undefined
  }
  return equal
}

/**
 * Creates a computed (derived) closure with
 * supplied function which computes current value
 * of closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  normalizeEqualFn(_equal) // Used to normalize but equality checking not implemented in basic version
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Initial computation to track dependencies
  updateObserver(o)
  
  const getter = (): T => {
    const active = getActiveObserver()
    if (active) {
      // Being accessed during dependency tracking
      // Add our observer to the dependency's observer set
      if (!o.observers) {
        o.observers = new Set()
      }
      o.observers.add(active)
    }
    return o.value!
  }
  
  return getter
}
