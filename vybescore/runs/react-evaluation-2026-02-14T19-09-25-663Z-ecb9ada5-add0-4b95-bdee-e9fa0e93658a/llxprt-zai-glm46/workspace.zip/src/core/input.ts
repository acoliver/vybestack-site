/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

function normalizeEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') {
    return equal ? (lhs: T, rhs: T) => lhs === rhs : undefined
  }
  return equal
}

/**
 * Creates an input closure. The value is accessed
 * via accessor and changed via
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = normalizeEqualFn(_equal)
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    s.value = nextValue
    notifyObservers(s.observers)
    return s.value
  }

  return [read, write]
}
