/**
 * Validate Base64 input and throw error for invalid data.
 */
function validateBase64(input: string): void {
  // Check for invalid characters first (including padding)
  if (!/^[A-Za-z0-9+/=]*$/.test(input)) {
    throw new Error('Invalid Base64: contains characters outside Base64 alphabet');
  }
  
  // Check if padding is only at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingSection = input.substring(paddingIndex);
    if (!/^=+$/.test(paddingSection)) {
      throw new Error('Invalid Base64: padding in middle of string');
    }
  }
  
  // Check if padding length is valid (0, 1, or 2 characters)
  const paddingCount = (input.match(/=/g) || []).length;
  if (paddingCount > 2) {
    throw new Error('Invalid Base64: too much padding');
  }
  
  // Check if total length (with padding) is valid (must be multiple of 4)
  // Allow non-multiple-of-4 length - Base64 without padding is valid
  // The Buffer.from() call will handle the actual validation
}

/**
 * Encode plain text to Base64 using canonical alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 with proper validation.
 */
export function decode(input: string): string {
  validateBase64(input);
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
