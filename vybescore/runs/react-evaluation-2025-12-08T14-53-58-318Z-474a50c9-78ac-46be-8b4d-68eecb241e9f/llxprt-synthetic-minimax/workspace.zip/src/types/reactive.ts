/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Use unknown instead of recursive type references
export type ObserverR = {
  name?: string
  dependencies: Set<unknown>
  dependents: Set<unknown>
  dirty: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer?: ObserverR | undefined
  dependencies: Set<unknown>
  dependents: Set<unknown>
  dirty: boolean
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Global reactive tracking context
let activeObserver: ObserverR | null = null

export function getActiveObserver(): ObserverR | null {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | null): void {
  activeObserver = observer
}

// Register a dependency relationship
export function registerDependency<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.observer = observer
  observer.dependencies.add(subject)
  subject.dependents.add(observer)
}

// Notify dependents of a change
export function notifyDependents<T>(subject: Subject<T>): void {
  subject.dirty = true
  
  // Recursive function to mark all dependents dirty and re-execute callbacks
  const markDirtyAndExecute = (dep: unknown) => {
    const dependent = dep as any
    if (dependent.dirty) return // Already marked dirty, avoid cycles
    
    dependent.dirty = true
    
    // If this is an observer with an updateFn, check if we should execute it
    if (dependent.updateFn && typeof dependent.updateFn === 'function') {
      // Execute observers that have no dependents (terminal nodes like callbacks)
      // or have special handling requirements
      if (dependent.dependents.size === 0) {
        const previous = getActiveObserver()
        setActiveObserver(dependent)
        
        try {
          dependent.value = dependent.updateFn(dependent.value)
        } finally {
          setActiveObserver(previous)
        }
      }
    }
    
    // Mark all dependents of this dependent as dirty too
    if (dependent.dependents) {
      dependent.dependents.forEach((subDep: unknown) => markDirtyAndExecute(subDep))
    }
  }
  
  // Mark all dependents as dirty and execute callbacks
  subject.dependents.forEach(markDirtyAndExecute)
}
      }
    }
    
    // Mark all dependents of this dependent as dirty too
    if (dependent.dependents) {
      dependent.dependents.forEach((subDep: unknown) => markDirtyAndExecute(subDep))
    }
  }
  
  // Mark all dependents as dirty and execute callbacks
  subject.dependents.forEach(markDirtyAndExecute)
}

// Read from a subject and track dependency
export function readFromSubject<T>(subject: Subject<T>, observer: ObserverR): T {
  const observerCheck = getActiveObserver()
  if (observerCheck && observerCheck !== observer) {
    registerDependency(subject, observerCheck)
  }
  return subject.value
}

// Update an observer
export function updateObserver<T>(observer: Observer<T>): void {
  const previous = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    if (observer.updateFn && observer.dirty) {
      observer.value = observer.updateFn(observer.value)
      observer.dirty = false
    }
  } finally {
    setActiveObserver(previous)
  }
}

// Notify observers of changes
export function notifyObservers<T>(observer: Observer<T>): void {
  updateObserver(observer)
}