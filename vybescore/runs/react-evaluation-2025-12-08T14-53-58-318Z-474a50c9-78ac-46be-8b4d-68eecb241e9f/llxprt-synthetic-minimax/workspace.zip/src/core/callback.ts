/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set(),
    dependents: new Set(),
    dirty: true
  }
  
  // Function to execute the callback
  const executeCallback = () => {
    const previous = getActiveObserver()
    // Don't set active observer here - let computed values preserve it
    // This allows computed values to properly track their dependencies
    
    try {
      observer.value = observer.updateFn(observer.value)
      observer.dirty = false
    } finally {
      // Restore the previous active observer
      setActiveObserver(previous)
    }
  }
  
  // Execute the callback to register dependencies and run the effect
  executeCallback()
  
  let disposed = false
  
  return () => {
    if (disposed) return
    
    disposed = true
    
    // Remove from dependencies
    observer.dependencies.forEach(dep => {
      const subject = dep as any
      subject.dependents.delete(observer)
    })
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => undefined as any
  }
}