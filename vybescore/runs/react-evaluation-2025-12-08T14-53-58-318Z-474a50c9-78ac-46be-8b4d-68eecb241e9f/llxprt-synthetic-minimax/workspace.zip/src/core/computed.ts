/**
 * Computed closure implementation for derived values.
 */ 

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  getActiveObserver,
  setActiveObserver,
  notifyDependents,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    dependencies: new Set(),
    dependents: new Set(),
    value,
    updateFn,
    dirty: true
  }
  
  const getter: GetterFn<T> = () => {
    // Set this observer as active so dependencies get registered
    const previous = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      if (observer.dirty && observer.updateFn) {
        const oldValue = observer.value
        const result = observer.updateFn(observer.value)
        observer.value = result
        observer.dirty = false
        
        // If value changed, notify dependents
        if (oldValue !== result) {
          notifyDependents(observer as Subject<T>)
        }
      }
      return observer.value as T
    } finally {
      setActiveObserver(previous)
    }
  }
  
  return getter
}