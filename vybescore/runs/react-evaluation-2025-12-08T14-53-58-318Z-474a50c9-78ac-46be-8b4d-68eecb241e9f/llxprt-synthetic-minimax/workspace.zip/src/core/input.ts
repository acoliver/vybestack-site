/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  registerDependency,
  notifyDependents,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    dependencies: new Set(),
    dependents: new Set(),
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
    dirty: false,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      subject.observer = observer
      registerDependency(subject, observer)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    subject.value = nextValue
    notifyDependents(subject)
    return subject.value
  }

  return [read, write]
}