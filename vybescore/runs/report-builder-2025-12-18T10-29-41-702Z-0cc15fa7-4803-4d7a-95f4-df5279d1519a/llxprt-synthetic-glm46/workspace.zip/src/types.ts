/**
 * Report data interface matching the JSON schema
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Individual report entry data
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Options for report rendering
 */
export interface ReportOptions {
  includeTotals?: boolean;
}

/**
 * Report renderer function interface
 */
export interface ReportRenderer {
  (data: ReportData, options?: ReportOptions): string;
}