#!/usr/bin/env node

import fs from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, ReportOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals?: boolean;
}

/**
 * Parses command line arguments
 * @param args Process.argv array (excluding node and script path)
 * @returns Parsed arguments
 */
function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  let i = 1;
  while (i < args.length) {
    const flag = args[i];
    
    if (flag === '--format') {
      if (!args[i + 1]) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i + 1];
      i += 2;
    } else if (flag === '--output') {
      if (!args[i + 1]) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i += 2;
    } else if (flag === '--includeTotals') {
      includeTotals = true;
      i += 1;
    } else {
      console.error(`Error: Unknown flag ${flag}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataFile, format, outputPath, includeTotals };
}

/**
 * Loads and validates JSON data from a file
 * @param filePath Path to the JSON file
 * @returns Parsed report data
 */
function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent);
    
    // Validate the data structure
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: title is required and must be a string');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary is required and must be a string');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries is required and must be an array');
    }
    
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}].label is required and must be a string`);
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entries[${i}].amount is required and must be a number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in ${filePath}`);
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    }
    process.exit(1);
  }
}

/**
 * Main execution function
 */
function main(): void {
  const args = parseArgs(process.argv.slice(2));
  
  // Validate format
  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error('Error: Unsupported format. Supported formats: markdown, text');
    process.exit(1);
  }
  
  // Load and validate data
  const data = loadReportData(args.dataFile);
  
  // Prepare options
  const options: ReportOptions = {
    includeTotals: args.includeTotals
  };
  
  // Render the report
  let output: string;
  if (args.format === 'markdown') {
    output = renderMarkdown(data, options);
  } else {
    output = renderText(data, options);
  }
  
  // Write output
  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf8');
      console.log(`Report written to ${args.outputPath}`);
    } catch (error) {
      console.error(`Error writing to ${args.outputPath}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

// Run the main function
main();
