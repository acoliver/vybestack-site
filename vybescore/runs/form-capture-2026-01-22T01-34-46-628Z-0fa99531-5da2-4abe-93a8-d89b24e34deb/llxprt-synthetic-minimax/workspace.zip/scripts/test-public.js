const http = require('http');

// Simple test server communication
function testServer() {
  const port = process.env.PORT || 3535;
  
  console.log('Testing server on port', port);
  
  // Test 1: Check if server responds
  const req = http.request({
    hostname: 'localhost',
    port: port,
    path: '/',
    method: 'GET'
  }, (res) => {
    console.log('Server status:', res.statusCode);
    
    if (res.statusCode === 200) {
      console.log('[OK] Server is responding on port', port);
      
      // Test 2: Check health endpoint
      http.request({
        hostname: 'localhost',
        port: port,
        path: '/health',
        method: 'GET'
      }, (healthRes) => {
        console.log('Health check status:', healthRes.statusCode);
        
        if (healthRes.statusCode === 200) {
          console.log('[OK] Health endpoint is working');
        } else {
          console.log(' Health endpoint failed');
        }
      }).on('error', (err) => {
        console.log(' Health endpoint error:', err.message);
      }).end();
      
    } else {
      console.log(' Server not responding correctly');
    }
  }).on('error', (err) => {
    console.log(' Server connection failed:', err.message);
    console.log('Make sure to run "npm start" first to start the server');
  }).end();
}

// Run tests
console.log(' Testing Friendly Form Capture application...\n');
testServer();

console.log('\n Manual testing checklist:');
console.log('1. Open http://localhost:' + (process.env.PORT || 3535));
console.log('2. Fill out the contact form with test data');
console.log('3. Submit the form and verify redirect to thank-you page');
console.log('4. Test form validation by submitting empty fields');
console.log('5. Test international phone formats (e.g. +44 20 7946 0958)');
console.log('6. Test international postal codes (e.g. SW1A 1AA, C1000)');
console.log('7. Verify SQLite database is created in data/submissions.sqlite');
console.log('\n[OK] All tests completed!');