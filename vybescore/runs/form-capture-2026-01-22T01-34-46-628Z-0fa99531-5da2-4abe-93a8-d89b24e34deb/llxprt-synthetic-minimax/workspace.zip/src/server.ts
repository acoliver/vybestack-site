import express from 'express';
import * as path from 'path';
import { DatabaseService } from './database';
import { ValidationService, FormData } from './validation';

interface RequestWithFormData extends express.Request {
  formData?: FormData;
  validationErrors?: { [fieldName: string]: string };
}

export class AppServer {
  private app: express.Application;
  private db: DatabaseService;
  private validationService: ValidationService;
  private server: import('http').Server | null = null;

  constructor() {
    this.app = express();
    this.db = new DatabaseService();
    this.validationService = new ValidationService();
    
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    // Serve static files
    this.app.use('/public', express.static(path.join(process.cwd(), 'public')));
    
    // Parse URL-encoded bodies
    this.app.use(express.urlencoded({ extended: true }));
    
    // Parse JSON bodies
    this.app.use(express.json());
    
    // Set EJS as view engine
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(process.cwd(), 'views'));
  }

  private setupRoutes(): void {
    // Home page - contact form
    this.app.get('/', (req: RequestWithFormData, res) => {
      res.render('contact-form', {
        title: 'Friendly Contact Form',
        errors: req.validationErrors || {},
        formData: req.formData || {} as FormData
      });
    });

    // Handle form submission
    this.app.post('/submit', async (req: RequestWithFormData, res) => {
      try {
        const formData: FormData = {
          first_name: (req.body.first_name || '').trim(),
          last_name: (req.body.last_name || '').trim(),
          street_address: (req.body.street_address || '').trim(),
          city: (req.body.city || '').trim(),
          state_province_region: (req.body.state_province_region || '').trim(),
          postal_code: (req.body.postal_code || '').trim(),
          country: (req.body.country || '').trim(),
          email: (req.body.email || '').trim(),
          phone_number: (req.body.phone_number || '').trim()
        };

        // Validate form data
        const validationResult = this.validationService.validateFormData(formData);
        
        if (!validationResult.isValid) {
          // Render form with errors
          res.status(400).render('contact-form', {
            title: 'Contact Form - Please Fix Errors',
            errors: validationResult.errors,
            formData
          });
          return;
        }

        // Save to database
        await this.db.saveSubmission(formData);
        
        // Redirect to thank you page
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Error processing form submission:', error);
        res.status(500).render('contact-form', {
          title: 'Contact Form - Error',
          errors: { general: 'Sorry, there was an error processing your submission. Please try again.' },
          formData: req.body as FormData
        });
      }
    });

    // Thank you page
    this.app.get('/thank-you', (req, res) => {
      res.render('thank-you', {
        title: 'Thank You!'
      });
    });

    // Health check endpoint
    this.app.get('/health', (req, res) => {
      res.status(200).json({ 
        status: 'healthy', 
        timestamp: new Date().toISOString() 
      });
    });
  }

  public async start(port: number = 3535): Promise<void> {
    try {
      // Initialize database
      await this.db.initialize();
      
      // Start server
      this.server = this.app.listen(port, () => {
        console.log(` Friendly Form Capture server running on port ${port}`);
        console.log(` Visit http://localhost:${port} to fill out the contact form`);
      });

      // Handle graceful shutdown
      this.setupGracefulShutdown();
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  private setupGracefulShutdown(): void {
    process.on('SIGTERM', async () => {
      console.log('\n Received SIGTERM, shutting down gracefully...');
      await this.shutdown();
    });

    process.on('SIGINT', async () => {
      console.log('\n Received SIGINT, shutting down gracefully...');
      await this.shutdown();
    });
  }

  private async shutdown(): Promise<void> {
    try {
      // Close database connection
      await this.db.close();
      
      // Close server
      if (this.server) {
        this.server.close();
      }
      
      console.log('[OK] Server shutdown complete');
      process.exit(0);
    } catch (error) {
      console.error('Error during shutdown:', error);
      process.exit(1);
    }
  }

  public getApp(): express.Application {
    return this.app;
  }
}

// Start server if this file is run directly
if (require.main === module) {
  const port = parseInt(process.env.PORT || '3535', 10);
  
  const server = new AppServer();
  server.start(port).catch(error => {
    console.error('Failed to start application:', error);
    process.exit(1);
  });
}
