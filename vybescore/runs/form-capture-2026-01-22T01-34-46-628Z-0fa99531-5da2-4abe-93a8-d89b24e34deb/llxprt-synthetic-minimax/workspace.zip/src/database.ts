import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface ContactSubmission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone_number: string;
  created_at?: string;
}

export class DatabaseService {
  private db: Database | null = null;
  private dbPath: string;
  private sql: SqlJsStatic | null = null;

  constructor(dbPath: string = 'data/submissions.sqlite') {
    this.dbPath = dbPath;
    this.ensureDataDirectory();
  }

  private ensureDataDirectory(): void {
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
  }

  public async initialize(): Promise<void> {
    try {
      // Initialize sql.js
      this.sql = await initSqlJs();
      
      // Load existing database or create new one
      let dbData: Uint8Array | null = null;
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        dbData = new Uint8Array(dbBuffer);
      }

      this.db = new this.sql.Database(dbData);
      
      // Initialize schema if needed
      await this.initializeSchema();
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw new Error('Database initialization failed');
    }
  }

  private async initializeSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      // Read schema file
      const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      if (fs.existsSync(schemaPath)) {
        const schemaSql = fs.readFileSync(schemaPath, 'utf-8');
        this.db.exec(schemaSql);
      }
    } catch (error) {
      console.error('Failed to initialize schema:', error);
      throw new Error('Schema initialization failed');
    }
  }

  public async saveSubmission(submission: ContactSubmission): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const insertSql = `
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province_region, postal_code, country, email, phone_number
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

    const stmt = this.db.prepare(insertSql);
    
    try {
      stmt.run([
        submission.first_name,
        submission.last_name,
        submission.street_address,
        submission.city,
        submission.state_province_region,
        submission.postal_code,
        submission.country,
        submission.email,
        submission.phone_number
      ]);
      
      // Get the last inserted row ID
      const result = this.db.exec("SELECT last_insert_rowid() as id");
      const rowId = result[0]?.values[0][0] as number;
      
      // Persist to disk
      await this.persist();
      
      return rowId;
    } finally {
      stmt.free();
    }
  }

  public async getAllSubmissions(): Promise<ContactSubmission[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const selectSql = `
        SELECT id, first_name, last_name, street_address, city, 
               state_province_region, postal_code, country, email, 
               phone_number, created_at
        FROM submissions 
        ORDER BY created_at DESC
      `;

    const result = this.db.exec(selectSql);
    
    if (!result[0]?.values) {
      return [];
    }

    return result[0].values.map((row: unknown[]) => ({
      id: row[0] as number,
      first_name: row[1] as string,
      last_name: row[2] as string,
      street_address: row[3] as string,
      city: row[4] as string,
      state_province_region: row[5] as string,
      postal_code: row[6] as string,
      country: row[7] as string,
      email: row[8] as string,
      phone_number: row[9] as string,
      created_at: row[10] as string
    }));
  }

  public async persist(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const dbData = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(dbData));
    } catch (error) {
      console.error('Failed to persist database:', error);
      throw new Error('Database persistence failed');
    }
  }

  public async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}