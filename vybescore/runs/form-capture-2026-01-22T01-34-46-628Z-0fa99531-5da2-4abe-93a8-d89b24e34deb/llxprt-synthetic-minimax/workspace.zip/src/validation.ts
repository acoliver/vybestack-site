export interface ValidationResult {
  isValid: boolean;
  errors: { [fieldName: string]: string };
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone_number: string;
}

export class ValidationService {
  public validateFormData(formData: FormData): ValidationResult {
    const errors: { [fieldName: string]: string } = {};

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'first_name', 'last_name', 'street_address', 'city', 
      'state_province_region', 'postal_code', 'country', 'email', 'phone_number'
    ];

    requiredFields.forEach(field => {
      const value = formData[field]?.trim();
      if (!value) {
        errors[field] = `${this.formatFieldName(field)} is required`;
      }
    });

    // Email validation (only if not empty)
    if (formData.email.trim() && !this.isValidEmail(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }

    // Phone number validation (only if not empty)
    if (formData.phone_number.trim() && !this.isValidPhone(formData.phone_number)) {
      errors.phone_number = 'Please enter a valid phone number';
    }

    // Postal code validation (only if not empty)
    if (formData.postal_code.trim() && !this.isValidPostalCode(formData.postal_code)) {
      errors.postal_code = 'Please enter a valid postal code';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  private formatFieldName(field: string): string {
    return field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  }

  private isValidEmail(email: string): boolean {
    // Simple but effective email regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email.trim());
  }

  private isValidPhone(phone: string): boolean {
    // Remove all non-digit characters except @, spaces, parentheses, and dashes
    // Check if it contains at least some digits
    const cleanedPhone = phone.replace(/[^\d@()\-\s]/g, '');
    const digitCount = (cleanedPhone.match(/\d/g) || []).length;
    
    // Must have at least 7 digits to be a valid phone number
    return digitCount >= 7 && digitCount <= 15;
  }

  private isValidPostalCode(postalCode: string): boolean {
    // Postal codes should be 3-10 alphanumeric characters, possibly with spaces
    // Examples: "SW1A 1AA", "C1000", "B1675", "12345", "123-456"
    const cleanedCode = postalCode.replace(/\s/g, '').toUpperCase();
    
    // Allow alphanumeric with optional dashes
    const postalRegex = /^[A-Z0-9]{3,10}(-[A-Z0-9]{3,7})?$/;
    
    // Must pass the regex and have reasonable length
    return postalRegex.test(cleanedCode) && cleanedCode.length >= 3 && cleanedCode.length <= 10;
  }
}