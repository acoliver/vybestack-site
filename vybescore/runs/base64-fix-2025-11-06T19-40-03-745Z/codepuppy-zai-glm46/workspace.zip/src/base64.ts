/**
 * Encode plain text to Base64 using the canonical RFC 4648 alphabet.
 * Uses standard Base64 with padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Remove whitespace
  const cleaned = input.replace(/\s/g, '');
  
  // Empty input should decode to empty string
  if (cleaned.length === 0) {
    return '';
  }

  // Validate basic Base64 format (only allow A-Z, a-z, 0-9, +, /, =)
  if (!/^[A-Za-z0-9+/=]*$/.test(cleaned)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Validate Base64 structure per RFC 4648
  validateBase64Structure(cleaned);

  try {
    const result = Buffer.from(cleaned, 'base64').toString('utf8');
    
    // Additional validation: ensure we didn't lose data due to invalid padding
    // Re-encode and compare to detect cases where Node.js silently accepts invalid input
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedReencoded = normalizeBase64(reencoded);
    const normalizedInput = normalizeBase64(cleaned);
    
    if (normalizedReencoded !== normalizedInput) {
      throw new Error('Invalid Base64 input: malformed structure');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Validate Base64 structure according to RFC 4648
 */
function validateBase64Structure(input: string): void {
  const len = input.length;
  
  // Check length requirements
  if (len % 4 !== 0) {
    throw new Error('Invalid Base64 input: length must be multiple of 4');
  }

  // Check padding rules
  const padIndex = input.indexOf('=');
  if (padIndex !== -1) {
    // Padding can only appear at the end
    if (padIndex < len - 2) {
      throw new Error('Invalid Base64 input: padding in wrong position');
    }
    
    // Only 1 or 2 padding characters allowed
    const padCount = len - padIndex;
    if (padCount > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
    
    // If padding present, all characters before padding must be valid
    const beforePadding = input.substring(0, padIndex);
    if (!/^[A-Za-z0-9+/]*$/.test(beforePadding)) {
      throw new Error('Invalid Base64 input: illegal characters before padding');
    }
  }
}

/**
 * Normalize Base64 string by removing padding for comparison
 */
function normalizeBase64(input: string): string {
  return input.replace(/=+$/, '');
}
