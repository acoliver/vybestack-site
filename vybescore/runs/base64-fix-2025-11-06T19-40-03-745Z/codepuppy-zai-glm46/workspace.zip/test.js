console.log('Direct test:'); console.log(Buffer.from('hello', 'utf8').toString('base64'));
