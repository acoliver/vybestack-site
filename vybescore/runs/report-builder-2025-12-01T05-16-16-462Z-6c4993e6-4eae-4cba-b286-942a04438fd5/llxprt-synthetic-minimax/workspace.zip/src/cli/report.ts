import { readFileSync, writeFileSync } from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, CliOptions } from '../types.js';

function parseArgs(args: string[]): CliOptions {
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[2];
  const options: Partial<CliOptions> = { includeTotals: false };

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];

    switch (arg) {
      case '--format': {
        if (i + 1 >= args.length) {
          throw new Error('Format value is required');
        }
        const formatValue = args[i + 1];
        if (formatValue !== 'markdown' && formatValue !== 'text') {
          throw new Error(`Unsupported format: ${formatValue}`);
        }
        options.format = formatValue as 'markdown' | 'text';
        i++; // Skip the next argument as it's the format value
        break;
      }
      
      case '--output': {
        if (i + 1 >= args.length) {
          throw new Error('Output path is required');
        }
        options.output = args[i + 1];
        i++; // Skip the next argument as it's the output path
        break;
      }
      
      case '--includeTotals':
        options.includeTotals = true;
        break;
      
      default:
        throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!options.format) {
    throw new Error('--format is required');
  }

  return {
    dataFile,
    format: options.format,
    output: options.output,
    includeTotals: options.includeTotals || false
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (data.title === undefined || data.title === null) {
      throw new Error('Invalid data: "title" is required');
    }
    if (data.summary === undefined || data.summary === null) {
      throw new Error('Invalid data: "summary" is required');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: "entries" is required and must be an array');
    }
    
    // Validate entries
    for (const [index, entry] of data.entries.entries()) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${index}].label is required and must be a string`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entries[${index}].amount is required and must be a number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, 'utf-8');
  } else {
    process.stdout.write(content);
  }
}

function main(): void {
  try {
    const options = parseArgs(process.argv);
    const data = loadReportData(options.dataFile);
    
    let renderedOutput: string;
    
    if (options.format === 'markdown') {
      renderedOutput = renderMarkdown(data, options.includeTotals);
    } else {
      renderedOutput = renderText(data, options.includeTotals);
    }
    
    writeOutput(renderedOutput, options.output);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();