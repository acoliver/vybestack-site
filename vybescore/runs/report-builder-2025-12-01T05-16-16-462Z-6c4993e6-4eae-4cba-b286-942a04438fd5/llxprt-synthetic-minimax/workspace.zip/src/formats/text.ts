import { ReportData } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function renderText(data: ReportData, includeTotals: boolean): string {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  let output = `${data.title}
\n`;
  output += `${data.summary}
\n`;
  output += `Entries:\n`;
  
  for (const entry of data.entries) {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }
  
  if (includeTotals) {
    output += `\nTotal: ${formatAmount(total)}\n`;
  }
  
  return output;
}