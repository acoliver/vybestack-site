#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { ReportData, FormatOptions, Format } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: Format;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(argv: string[]): CliArgs {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 1) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  const formatValue = args[formatIndex + 1];
  if (formatValue !== 'markdown' && formatValue !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  const outputIndex = args.indexOf('--output');
  const output = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataFile,
    format: formatValue as Format,
    output,
    includeTotals,
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContent) as unknown;
    
    // Validate the structure
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected an object');
    }
    
    const reportData = data as Record<string, unknown>;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid data: title must be a string');
    }
    
    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid data: summary must be a string');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }
    
    const entries = reportData.entries as unknown[];
    
    for (const entry of entries) {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error('Invalid data: each entry must be an object');
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error('Invalid data: entry.label must be a string');
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error('Invalid data: entry.amount must be a number');
      }
    }
    
    return reportData as unknown as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${filePath}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Failed to load file ${filePath}`);
    }
    process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to file ${outputPath}`);
      process.exit(1);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  const args = parseArguments(process.argv);
  
  const data = loadReportData(args.dataFile);
  
  const options: FormatOptions = {
    includeTotals: args.includeTotals,
  };
  
  const formatters = {
    markdown: markdownFormatter,
    text: textFormatter,
  };
  
  const formatter = formatters[args.format];
  const output = formatter.render(data, options);
  
  writeOutput(output, args.output);
}

main();