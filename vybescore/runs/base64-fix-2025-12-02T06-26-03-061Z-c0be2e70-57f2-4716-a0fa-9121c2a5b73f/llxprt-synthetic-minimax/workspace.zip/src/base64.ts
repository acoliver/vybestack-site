/**
 * Encode plain text to Base64 using standard Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws descriptive errors for invalid Base64.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Check for invalid characters (should only contain A-Z, a-z, 0-9, +, /, and = for padding)
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for proper padding length
  const paddingLength = input.length % 4;
  if (paddingLength === 1) {
    throw new Error('Invalid Base64 input: length must be a multiple of 4 or have valid padding');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}
