import express, { Request, Response } from 'express';
import * as path from 'path';
import { validateFormData } from './validation.js';
import { initializeDatabase, insertSubmission, closeDatabase } from './database.js';
import { FormData, ValidationResult } from './types.js';

interface TemplateData {
  formData: Partial<FormData>;
  errors: Record<string, string>;
}

// Helper function to convert FormData to template data
function convertToTemplateData(formData?: Partial<FormData>, validationResult?: ValidationResult): TemplateData {
  if (!validationResult) {
    return { formData: formData || {}, errors: {} };
  }

  const errors: Record<string, string> = {};
  validationResult.errors.forEach((error) => {
    switch (error.field) {
      case 'firstName':
        errors.firstName = error.message;
        break;
      case 'lastName':
        errors.lastName = error.message;
        break;
      case 'streetAddress':
        errors.streetAddress = error.message;
        break;
      case 'city':
        errors.city = error.message;
        break;
      case 'stateProvince':
        errors.stateProvince = error.message;
        break;
      case 'postalCode':
        errors.postalCode = error.message;
        break;
      case 'country':
        errors.country = error.message;
        break;
      case 'email':
        errors.email = error.message;
        break;
      case 'phone':
        errors.phone = error.message;
        break;
    }
  });

  return { formData: formData || {}, errors };
}

const app = express();
const PORT = parseInt(process.env.PORT || '3535');

// Initialize database
initializeDatabase().catch(console.error);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { formData: {}, errors: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName?.trim(),
    lastName: req.body.lastName?.trim(),
    streetAddress: req.body.streetAddress?.trim(),
    city: req.body.city?.trim(),
    stateProvince: req.body.stateProvince?.trim(),
    postalCode: req.body.postalCode?.trim(),
    country: req.body.country?.trim(),
    email: req.body.email?.trim(),
    phone: req.body.phone?.trim(),
  };

  const validationResult = validateFormData(formData);

  if (!validationResult.isValid) {
    const templateData = convertToTemplateData(formData, validationResult);
    res.status(400).render('form', templateData);
    return;
  }

  try {
    await insertSubmission(validationResult.data!);
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    const templateData = convertToTemplateData(formData, validationResult);
    res.status(500).render('form', templateData);
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Health check endpoint
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok' });
});

// Graceful shutdown handling
const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Handle graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  server.close(async () => {
    await closeDatabase();
    process.exit(0);
  });
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  server.close(async () => {
    await closeDatabase();
    process.exit(0);
  });
});

export default app;