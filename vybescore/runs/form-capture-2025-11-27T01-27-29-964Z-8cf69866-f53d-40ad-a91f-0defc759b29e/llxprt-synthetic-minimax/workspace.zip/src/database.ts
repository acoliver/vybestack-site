import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';
import { FormData } from './types.js';

let db: Database | null = null;
let SqlJs: SqlJsStatic | null = null;

const DB_FILE_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

export async function initializeDatabase(): Promise<void> {
  if (!SqlJs) {
    SqlJs = await initSqlJs();
  }

  // Ensure data directory exists
  const dataDir = path.dirname(DB_FILE_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (fs.existsSync(DB_FILE_PATH)) {
    // Load existing database
    const fileBuffer = fs.readFileSync(DB_FILE_PATH);
    db = new SqlJs.Database(fileBuffer);
  } else {
    // Create new database and initialize schema
    db = new SqlJs.Database();
    await initializeSchema();
    await saveDatabase();
  }
}

async function initializeSchema(): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  
  const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
  db.exec(schema);
}

export async function saveDatabase(): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  
  const binaryArray = db.export();
  const buffer = Buffer.from(binaryArray);
  fs.writeFileSync(DB_FILE_PATH, buffer);
}

export async function insertSubmission(data: FormData): Promise<void> {
  if (!db) throw new Error('Database not initialized');

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    data.firstName,
    data.lastName,
    data.streetAddress,
    data.city,
    data.stateProvince,
    data.postalCode,
    data.country,
    data.email,
    data.phone
  ]);

  stmt.free();
  await saveDatabase();
}

export async function closeDatabase(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
}

// Handle graceful shutdown
process.on('SIGTERM', async () => {
  await closeDatabase();
  process.exit(0);
});

process.on('SIGINT', async () => {
  await closeDatabase();
  process.exit(0);
});