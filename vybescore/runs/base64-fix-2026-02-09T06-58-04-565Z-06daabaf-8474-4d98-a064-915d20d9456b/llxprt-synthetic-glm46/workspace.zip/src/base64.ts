/**
 * Regular expression to validate Base64 input.
 * Allows characters A-Z, a-z, 0-9, +, / and optional padding = at the end
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and rejects clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate input format
  if (!BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check for invalid padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must only appear at the end of the string
    if (!/^(=+)?$/.test(input.substring(paddingIndex))) {
      throw new Error('Invalid Base64 input: invalid padding placement');
    }
    
    // Padding must be 1 or 2 '=' characters
    const paddingLength = input.length - paddingIndex;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    
    // If padding is present, the total length must be divisible by 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length with padding');
    }
  } else {
    // Without padding, the length must be divisible by 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if the buffer is empty when input is not empty (invalid Base64)
    if (buffer.length === 0 && input.length > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
