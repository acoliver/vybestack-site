/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const words = text.match(/\b\w+/g) || [];
  const results: string[] = [];
  
  for (const word of words) {
    if (word.startsWith(prefix) && !exceptions.includes(word)) {
      results.push(word);
    }
  }
  
  return results;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const results: string[] = [];
  
  // Match a digit followed by the token, but not at the start of the string
  // Use negative lookbehind to ensure it's not at the start
  const regex = new RegExp(`(?<!^)\\d${token}`, 'g');
  
  let match;
  while ((match = regex.exec(text)) !== null) {
    results.push(match[0]);
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~`]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // This checks for any 4-character sequence that repeats immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern: 4 groups of 1-3 digits separated by dots
  const ipv4Regex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Regex.test(value) && value.match(/^(\d{1,3}\.){3}\d{1,3}$/)) {
    return false;
  }
  
  // IPv6 patterns
  // Full form: 8 groups of 1-4 hex digits separated by colons
  const fullIpv6Regex = /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Shorthand with :: (can be at start, middle, or end)
  const shorthandIpv6Regex = /\b(::)?([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  return fullIpv6Regex.test(value) || shorthandIpv6Regex.test(value);
}