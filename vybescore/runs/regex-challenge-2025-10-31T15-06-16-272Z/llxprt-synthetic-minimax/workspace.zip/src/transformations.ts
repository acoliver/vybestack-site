/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: replace multiple spaces with single spaces
  let normalized = text.replace(/\s+/g, ' ');
  
  // Capitalize first character of the string
  if (normalized.length > 0) {
    normalized = normalized[0].toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize first character after sentence endings (.?!)
  normalized = normalized.replace(/([.!?]\s+)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /\bhttps?:\/\/[^\s<>"')]+[^\s<>"'),.]/g;
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation
    while (url.length > 0 && /[.,;:!?]$/.test(url[url.length - 1])) {
      url = url.slice(0, -1);
    }
    return url;
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/]+)(\/docs\/[^\s<>"')]*)/g, (match, host, path) => {
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(\?|&|=)|(cgi-bin)/.test(path) || 
                           /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
    
    if (hasDynamicHints) {
      // Just upgrade to https, don't rewrite host
      return 'https://' + host + path;
    } else {
      // Upgrade to https and rewrite host
      return 'https://docs.' + host + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31, simplified check)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}