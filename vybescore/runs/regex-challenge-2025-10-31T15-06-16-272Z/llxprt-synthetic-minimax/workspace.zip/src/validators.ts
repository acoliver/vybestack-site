export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with common patterns
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^(?!.*\.\.)[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional check: domain shouldn't contain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Check that domain doesn't end with a dot
  if (value.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except + at the beginning
  const cleanValue = value.trim();
  
  // Match various US phone formats
  const phoneRegex = /^(?:\+1[-.\s]?)?(?:\(?([2-9][0-8][0-9])\)?[-.\s]?)([2-9][0-9]{2})[-.\s]?([0-9]{4})$/;
  const match = cleanValue.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  const areaCode = parseInt(match[1], 10);
  const exchangeCode = parseInt(match[2], 10);
  
  // Check for invalid area codes (0 or 1)
  if (areaCode < 200 || areaCode > 999) {
    return false;
  }
  
  // Check exchange code
  if (exchangeCode < 200) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-space/hyphen characters, but keep + at the start
  const cleanValue = value.trim();
  
  // Match Argentine phone patterns
  // Optional +54, optional 9 for mobile, optional 0 trunk, area code 2-4 digits (1-9), 6-8 total digits remaining
  const phoneRegex = /^(?:\+54\s*)?(?:9\s*)?(?:0\s*)?([1-9]\d{1,3})\s*[\d\s-]{6,8}$/;
  
  const match = cleanValue.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  // When country code is omitted, must start with 0
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) {
    return false;
  }
  
  // Extract the part after area code (subscriber number)
  const afterAreaCode = cleanValue.replace(/^(?:\+54\s*)?(?:9\s*)?0*([1-9]\d{1,3})\s*/, '');
  const subscriberDigits = afterAreaCode.replace(/[+\s-]/g, '');
  
  // Total digits in subscriber number should be 6-8
  if (subscriberDigits.length < 6 || subscriberDigits.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Check if the name contains digits or symbols
  // Allow: unicode letters (including accents), spaces, apostrophes, hyphens
  // Reject: digits, special symbols like X Æ A-12 style names
  const nameRegex = /^[\p{L}][\p{L}\p{M}\s'\-]*[\p{L}\p{M}]$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for any digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for invalid symbols (not apostrophe, hyphen, or space)
  if (/[^'\s\p{L}\p{M}-]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check for valid prefixes based on card type
  // Visa: starts with 4, length 13-19
  // MasterCard: starts with 51-55 or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  const isVisa = /^(?:4[0-9]{12}(?:[0-9]{3})?|4[0-9]{15})$/.test(cleanValue);
  const isMasterCard = /^(?:5[1-5][0-9]{14}|2(?:2[2-9][0-9]{2}|[3-6][0-9]{3}|7[01][0-9]{2}|720)[0-9]{12})$/.test(cleanValue);
  const isAmEx = /^3[47][0-9]{13}$/.test(cleanValue);
  
  if (!isVisa && !isMasterCard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}