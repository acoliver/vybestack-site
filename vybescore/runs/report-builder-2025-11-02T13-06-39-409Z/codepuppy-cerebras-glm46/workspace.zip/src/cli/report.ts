#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { fileURLToPath } from 'url';
import type { ReportData, ReportOptions } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

function parseArguments(args: string[]): ReportOptions & { inputFile: string } {
  const result: ReportOptions & { inputFile: string } = {
    inputFile: '',
    format: 'markdown',
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg.startsWith('--')) {
      if (arg === '--format' && i + 1 < args.length) {
        const format = args[i + 1];
        if (format !== 'markdown' && format !== 'text') {
          throw new Error(`Unsupported format: ${format}`);
        }
        result.format = format;
        i++; // Skip next argument
      } else if (arg === '--output' && i + 1 < args.length) {
        result.outputPath = args[i + 1];
        i++; // Skip next argument
      } else if (arg === '--includeTotals') {
        result.includeTotals = true;
      }
    } else if (!result.inputFile) {
      result.inputFile = arg;
    }
  }

  if (!result.inputFile) {
    throw new Error('Input file path is required');
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: title must be a string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: summary must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: entries must be an array');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry ${i} must be an object`);
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i} label must be a string`);
    }
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${i} amount must be a number`);
    }
  }

  return data as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error) {
      throw new Error(`Error reading file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const options = parseArguments(args);
    
    const data = loadReportData(options.inputFile);
    
    const formatter = options.format === 'markdown' ? markdownFormatter : textFormatter;
    const output = formatter.render(data, options.includeTotals);
    
    if (options.outputPath) {
      writeFileSync(options.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    }
    console.error('Unknown error occurred');
    process.exit(1);
  }
}

// ES module equivalent of require.main === module
if (import.meta.url === `file://${process.argv[1]}` || 
    import.meta.url === fileURLToPath(import.meta.url)) {
  main();
}