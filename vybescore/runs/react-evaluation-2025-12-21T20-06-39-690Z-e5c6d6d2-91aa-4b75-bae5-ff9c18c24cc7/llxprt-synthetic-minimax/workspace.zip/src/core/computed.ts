/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const get: GetterFn<T> = () => {
    // Temporarily set this observer as active, execute the update function,
    // then restore the previous active observer
    const previousActive = getActiveObserver()
    try {
      (observer as any).activeObserver = observer
      const newValue = updateFn(observer.value)
      observer.value = newValue
      return newValue
    } finally {
      (observer as any).activeObserver = previousActive
    }
  }

  return get
}
