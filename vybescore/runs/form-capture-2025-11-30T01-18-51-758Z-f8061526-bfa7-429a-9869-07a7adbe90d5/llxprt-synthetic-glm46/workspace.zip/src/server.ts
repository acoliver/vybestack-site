import express, { Request, Response } from 'express';
import { Server } from 'http';
import path from 'path';
import fs from 'fs/promises';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

// Get current directory for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
  sanitizedValues: FormData;
}

class FormCaptureApp {
  private app: express.Application;
  private db: Database | null = null;
  private dbPath: string;
  private server: Server | null = null;

  constructor() {
    this.app = express();
    this.dbPath = path.join(__dirname, '../data/submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.join(__dirname, '../public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private async initDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      // Try to load existing database
      let dbBuffer: Uint8Array | null = null;
      try {
        const existingDb = await fs.readFile(this.dbPath);
        dbBuffer = new Uint8Array(existingDb);
      } catch (error) {
        console.log('Creating new database...');
      }
      
      // Initialize database
      this.db = new SQL.Database(dbBuffer);
      
      // Execute schema
      const schemaFile = await fs.readFile(
        path.join(__dirname, '../db/schema.sql'),
        'utf8'
      );
      this.db.exec(schemaFile);
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      await fs.writeFile(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateForm(data: Record<string, string>): ValidationResult {
    const errors: string[] = [];
    const sanitizedValues: FormData = {};

    // Required field validation
    if (!data.firstName?.trim()) {
      errors.push('First name is required');
    } else {
      sanitizedValues.firstName = data.firstName.trim();
    }

    if (!data.lastName?.trim()) {
      errors.push('Last name is required');
    } else {
      sanitizedValues.lastName = data.lastName.trim();
    }

    if (!data.streetAddress?.trim()) {
      errors.push('Street address is required');
    } else {
      sanitizedValues.streetAddress = data.streetAddress.trim();
    }

    if (!data.city?.trim()) {
      errors.push('City is required');
    } else {
      sanitizedValues.city = data.city.trim();
    }

    if (!data.stateProvince?.trim()) {
      errors.push('State/Province/Region is required');
    } else {
      sanitizedValues.stateProvince = data.stateProvince.trim();
    }

    if (!data.postalCode?.trim()) {
      errors.push('Postal/Zip code is required');
    } else {
      sanitizedValues.postalCode = data.postalCode.trim();
    }

    if (!data.country?.trim()) {
      errors.push('Country is required');
    } else {
      sanitizedValues.country = data.country.trim();
    }

    if (!data.email?.trim()) {
      errors.push('Email is required');
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email.trim())) {
        errors.push('Please enter a valid email address');
      } else {
        sanitizedValues.email = data.email.trim();
      }
    }

    if (!data.phone?.trim()) {
      errors.push('Phone number is required');
    } else {
      const phoneRegex = /^\+?[\d\s\-()]+$/;
      if (!phoneRegex.test(data.phone.trim())) {
        errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and optional leading +');
      } else {
        sanitizedValues.phone = data.phone.trim();
      }
    }

    return {
      isValid: errors.length === 0,
      errors,
      sanitizedValues,
    };
  }

  private setupRoutes(): void {
    // GET form route
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: null,
        values: {},
      });
    });

    // POST form submission route
    this.app.post('/submit', async (req: Request, res: Response) => {
      if (!this.db) {
        return res.status(500).send('Database not available');
      }

      const validation = this.validateForm(req.body);
      
      if (!validation.isValid) {
        return res.status(400).render('form', {
          errors: validation.errors,
          values: req.body,
        });
      }

      try {
        // Insert into database
        this.db.run(
          `INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province, 
            postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            validation.sanitizedValues.firstName || '',
            validation.sanitizedValues.lastName || '',
            validation.sanitizedValues.streetAddress || '',
            validation.sanitizedValues.city || '',
            validation.sanitizedValues.stateProvince || '',
            validation.sanitizedValues.postalCode || '',
            validation.sanitizedValues.country || '',
            validation.sanitizedValues.email || '',
            validation.sanitizedValues.phone || '',
          ]
        );

        // Save database
        await this.saveDatabase();

        // Redirect to thank you page
        res.redirect(`/thank-you?firstName=${encodeURIComponent(validation.sanitizedValues.firstName || '')}`);
      } catch (error) {
        console.error('Failed to save submission:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: req.body,
        });
      }
    });

    // Thank you page route
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = (req.query.firstName as string) || 'Friend';
      res.render('thank-you', { firstName });
    });
  }

  public async start(): Promise<void> {
    // Initialize database first
    await this.initDatabase();

    const port = process.env.PORT || 3535;
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Setup graceful shutdown
    process.on('SIGTERM', () => this.shutdown());
    process.on('SIGINT', () => this.shutdown());
  }

  public async shutdown(): Promise<void> {
    console.log('Shutting down server...');
    
    if (this.db) {
      await this.saveDatabase();
      this.db.close();
    }
    
    if (this.server) {
      this.server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    }
  }
}

// Start the application
const app = new FormCaptureApp();
app.start().catch((error) => {
  console.error('Failed to start application:', error);
  process.exit(1);
});
