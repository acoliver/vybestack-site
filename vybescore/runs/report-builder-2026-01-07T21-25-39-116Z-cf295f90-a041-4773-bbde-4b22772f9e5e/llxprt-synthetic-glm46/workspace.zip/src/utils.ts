import type { ReportData } from './types.js';

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}