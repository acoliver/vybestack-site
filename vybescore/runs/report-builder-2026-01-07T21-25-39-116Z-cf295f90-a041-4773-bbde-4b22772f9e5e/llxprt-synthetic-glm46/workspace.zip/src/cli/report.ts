#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import type { ReportData, RenderOptions, ReportFormatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters: Record<string, ReportFormatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliOptions {
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(): [string, CliOptions] {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    throw new Error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
    );
  }

  const dataFile = args[0];
  
  if (args[1] !== '--format') {
    throw new Error('Expected --format argument');
  }
  
  const format = args[2];
  if (!formatters[format]) {
    throw new Error(`Unsupported format: ${format}. Supported formats: ${Object.keys(formatters).join(', ')}`);
  }

  const options: CliOptions = {
    format,
    includeTotals: false,
  };

  for (let i = 3; i < args.length; i++) {
    if (args[i] === '--output' && i + 1 < args.length) {
      options.output = args[i + 1];
      i++;
    } else if (args[i] === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  return [dataFile, options];
}

async function validateReportData(data: unknown): Promise<ReportData> {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string' || !obj.title.trim()) {
    throw new Error('Invalid JSON: title must be a non-empty string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: summary must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: entries must be an array');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i] as Record<string, unknown>;
    if (typeof entry?.label !== 'string' || !entry.label.trim()) {
      throw new Error(`Invalid JSON: entry ${i} must have a non-empty label`);
    }
    if (typeof entry?.amount !== 'number' || isNaN(entry.amount)) {
      throw new Error(`Invalid JSON: entry ${i} must have a valid amount`);
    }
  }

  return data as ReportData;
}

async function main() {
  try {
    const [dataFile, cliOptions] = parseArguments();

    const fileContent = await readFile(dataFile, 'utf8');
    let jsonData;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      throw new Error(`Invalid JSON: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    const reportData = await validateReportData(jsonData);
    const formatter = formatters[cliOptions.format];
    const renderOptions: RenderOptions = {
      includeTotals: cliOptions.includeTotals,
    };

    const output = formatter(reportData, renderOptions);

    if (cliOptions.output) {
      await writeFile(cliOptions.output, output, 'utf8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();
