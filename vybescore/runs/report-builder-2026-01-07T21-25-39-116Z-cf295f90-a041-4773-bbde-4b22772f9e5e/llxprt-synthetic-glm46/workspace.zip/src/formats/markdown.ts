import type { ReportFormatter } from '../types.js';
import { formatAmount, calculateTotal } from '../utils.js';

export const renderMarkdown: ReportFormatter = (data, options) => {
  const lines = [];

  lines.push(`# ${data.title}`);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('## Entries');
  lines.push('');

  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  if (options.includeTotals) {
    lines.push('');
    lines.push(`**Total:** ${formatAmount(calculateTotal(data.entries))}`);
  }

  return lines.join('\n');
};