import type { ReportData, RenderOptions } from '../types.js';
import { formatAmount, calculateTotal } from '../utils/validation.js';

export function renderText(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  lines.push(data.title);
  lines.push(data.summary);
  lines.push('Entries:');
  lines.push('');

  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  if (options.includeTotals) {
    lines.push('');
    lines.push(`Total: ${formatAmount(calculateTotal(data.entries))}`);
  }

  return lines.join('\n');
}
