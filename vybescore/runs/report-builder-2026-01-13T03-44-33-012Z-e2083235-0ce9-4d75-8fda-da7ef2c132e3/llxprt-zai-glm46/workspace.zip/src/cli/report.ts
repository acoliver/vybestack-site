#!/usr/bin/env node
import * as fs from 'node:fs';
import { formatters } from '../formats/index.js';
import type { ReportData, RenderOptions } from '../types.js';
import { validateReportData } from '../utils/validation.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    printUsage();
    process.exit(1);
  }

  const inputFile = args[0];
  const formatArg = args[1];
  let outputPath: string | undefined;
  let includeTotals = false;

  if (formatArg !== '--format') {
    console.error('Error: Expected --format argument');
    printUsage();
    process.exit(1);
  }

  if (args.length < 3) {
    console.error('Error: --format requires a value');
    printUsage();
    process.exit(1);
  }

  const format = args[2];

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path');
        printUsage();
        process.exit(1);
      }
      outputPath = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument "${arg}"`);
      printUsage();
      process.exit(1);
    }
  }

  return { inputFile, format, outputPath, includeTotals };
}

function printUsage(): void {
  console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('');
  console.error('Arguments:');
  console.error('  data.json       Path to the JSON file containing report data');
  console.error('  --format        Output format (markdown or text)');
  console.error('  --output        Optional path to write output (defaults to stdout)');
  console.error('  --includeTotals Optional flag to include totals in the output');
}

function main(): void {
  const args = parseArgs(process.argv.slice(2));

  const formatter = formatters[args.format];
  if (!formatter) {
    console.error(`Error: Unsupported format "${args.format}"`);
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  let inputData: unknown;
  try {
    const fileContent = fs.readFileSync(args.inputFile, 'utf-8');
    inputData = JSON.parse(fileContent);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: File not found: ${args.inputFile}`);
    } else if ((error as SyntaxError instanceof SyntaxError)) {
      console.error(`Error: Invalid JSON in file: ${args.inputFile}`);
      console.error((error as Error).message);
    } else {
      console.error(`Error: Failed to read file: ${args.inputFile}`);
      console.error((error as Error).message);
    }
    process.exit(1);
  }

  let data: ReportData;
  try {
    data = validateReportData(inputData);
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }

  const options: RenderOptions = { includeTotals: args.includeTotals };
  const output = formatter(data, options);

  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file: ${args.outputPath}`);
      console.error((error as Error).message);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
