const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate if a string is valid Base64 format.
 * @param input - The string to validate
 * @returns true if the string appears to be valid Base64
 */
function isValidBase64(input: string): boolean {
  if (input.length === 0) {
    return false;
  }
  
  // Check if the string only contains valid Base64 characters
  if (!VALID_BASE64_REGEX.test(input)) {
    return false;
  }
  
  // Check padding is only at the end and correct length
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const paddingMatch = input.match(/=+$/);
    if (!paddingMatch) {
      return false;
    }
    const paddingLength = paddingMatch[0].length;
    // Base64 padding can only be 0, 1, or 2 characters
    if (paddingLength > 2) {
      return false;
    }
    // Total length with padding must be multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
  } else {
    // Without padding, length must still be valid
    // For proper decoding, unpadded length should be handled by Buffer
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using the standard alphabet (A-Z, a-z, 0-9, +, /).
 * Padding is included when necessary to make the output length a multiple of 4.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding actually worked (invalid base64 may produce empty buffer)
    // For non-empty input, we should get non-empty output unless it was actually invalid
    if (trimmed.length > 0 && buffer.length === 0) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
