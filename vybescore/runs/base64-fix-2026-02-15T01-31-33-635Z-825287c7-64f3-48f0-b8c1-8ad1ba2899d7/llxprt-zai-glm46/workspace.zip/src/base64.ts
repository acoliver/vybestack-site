/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input string.
 * Throws an error if the input is not valid Base64.
 */
function validateBase64(input: string): void {
  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /, = for padding)
  const validPattern = /^[A-Za-z0-9+/]+={0,2}$/;
  
  if (!validPattern.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for correct padding
  // Padding (if present) must be at the end and can be 1 or 2 characters
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    
    // The total length with padding must be a multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate input first
  validateBase64(input);

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if decoding was successful by verifying the buffer is not empty
    // when input is not empty
    if (input.trim().length > 0 && buffer.length === 0) {
      throw new Error('Failed to decode Base64 input: invalid encoding');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
