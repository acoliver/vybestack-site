// Debug the abab pattern detection
const test = "Abab!12345";

for (let len = 2; len <= test.length / 2; len++) {
  console.log(`\nTesting length ${len}:`);
  for (let i = 0; i <= test.length - 2 * len; i++) {
    const sequence = test.slice(i, i + len);
    const nextSequence = test.slice(i + len, i + 2 * len);
    const match = sequence === nextSequence ? "MATCH!" : "";
    console.log(`  i=${i}: "${sequence}" vs "${nextSequence}" ${match}`);
  }
}
