const tests = [
  "Abcdab!123",
  "Abcdefghij!",
  "A1b2c3d4e5f",
  "Abc1234567!"
];

tests.forEach(pwd => {
  console.log(`\nTesting: ${pwd}`);
  console.log(`  length: ${pwd.length} >= 10: ${pwd.length >= 10}`);
  console.log(`  has whitespace: ${/\s/.test(pwd)}`);
  console.log(`  has uppercase: ${/[A-Z]/.test(pwd)}`);
  console.log(`  has lowercase: ${/[a-z]/.test(pwd)}`);
  console.log(`  has digit: ${/\d/.test(pwd)}`);
  console.log(`  has symbol: ${/[^A-Za-z0-9]/.test(pwd)}`);
  
  const lower = pwd.toLowerCase();
  console.log(`  Checking for repeated patterns...`);
  for (let len = 2; len <= lower.length / 2; len++) {
    for (let i = 0; i <= lower.length - 2 * len; i++) {
      const sequence = lower.slice(i, i + len);
      const nextSequence = lower.slice(i + len, i + 2 * len);
      if (sequence === nextSequence) {
        console.log(`    FOUND REPEAT at len=${len}, i=${i}: "${sequence}"`);
      }
    }
  }
});
