export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure: local@domain.tld
  // Local part: letters, digits, dots, hyphens, underscores, plus signs
  // Domain: letters, digits, hyphens, dots (but no leading/trailing/consecutive dots)
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  // Quick structural check
  if (!emailRegex.test(value)) {
    return false;
  }

  const [local, domain] = value.split('@');

  // Local part validations
  // No consecutive dots
  if (local.includes('..')) {
    return false;
  }
  // No leading or trailing dot
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }

  // Domain validations
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  // No consecutive dots
  if (domain.includes('..')) {
    return false;
  }
  // No leading or trailing dot
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  // Domain labels can't start or end with hyphen
  const labels = domain.split('.');
  for (const label of labels) {
    if (label.startsWith('-') || label.endsWith('-')) {
      return false;
    }
    // Each label must have at least one character
    if (label.length === 0) {
      return false;
    }
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');

  // Check length: with +1 should be 11 digits, without should be 10
  const hasCountryCode = digitsOnly.startsWith('1') && digitsOnly.length === 11;
  const isStandardLength = digitsOnly.length === 10;

  if (!hasCountryCode && !isStandardLength) {
    return false;
  }

  // Extract the actual 10-digit number
  const tenDigits = hasCountryCode ? digitsOnly.slice(1) : digitsOnly;

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = tenDigits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = tenDigits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Validate the format matches expected patterns
  // Valid formats: (212) 555-7890, 212-555-7890, 212-555-7890, 2125557890, +1-212-555-7890, etc.
  const validPatterns = [
    /^\+1[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/, // +1 (212) 555-7890
    /^\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/, // (212) 555-7890 or 212-555-7890
  ];

  const normalizedInput = value.trim();
  const isValidFormat = validPatterns.some((pattern) => pattern.test(normalizedInput));

  if (!isValidFormat) {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with various formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, and other separators for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Argentine phone regex
  // Optional +54, optional 0 trunk prefix, optional 9 for mobile
  // Area code: 2-4 digits starting with 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;

  const match = cleaned.match(argentinePhoneRegex);

  if (!match) {
    return false;
  }

  const [, areaCode, subscriberNumber] = match;

  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  // Check the original format for the "no country code means must have trunk prefix" rule
  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = areaCode.startsWith('0') || cleaned.startsWith('0') && !cleaned.startsWith('+54');

  if (!hasCountryCode && !hasTrunkPrefix) {
    // When no country code, must have trunk prefix (0 before area code)
    // But wait, our regex strips the 0 from the area code capture
    // Let's check original value
    const withoutCountry = value.replace(/\+54/, '').trim();
    if (!withoutCountry.startsWith('0')) {
      return false;
    }
  }

  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and weird characters like Æ
  const nameRegex = /^[\p{L}\p{M}'’\-\s]+$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  // No consecutive spaces or leading/trailing spaces
  const trimmed = value.trim();
  if (trimmed !== value) {
    return false;
  }

  if (/\s{2,}/.test(value)) {
    return false;
  }

  // Reject certain symbols that might pass the unicode check
  // Specifically reject Æ and similar special characters
  if (/[ÆæŒœÐðÞþ]/.test(value)) {
    return false;
  }

  // Ensure the name doesn't look like a test case (e.g., contains numbers)
  if (/\d/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Run Luhn checksum algorithm on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map((d) => parseInt(d, 10));
  let sum = 0;
  let isEven = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Card type patterns
  const patterns = [
    { prefix: /^4/, length: [13, 16] }, // Visa: 13 or 16 digits, starts with 4
    { prefix: /^5[1-5]/, length: [16] }, // Mastercard: 16 digits, starts with 51-55
    { prefix: /^2[2-7]/, length: [16] }, // Mastercard (new range): 16 digits, starts with 22-27
    { prefix: /^3[47]/, length: [15] }, // AmEx: 15 digits, starts with 34 or 37
  ];

  let validType = false;

  for (const pattern of patterns) {
    if (pattern.prefix.test(cleaned) && pattern.length.includes(cleaned.length)) {
      validType = true;
      break;
    }
  }

  if (!validType) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
