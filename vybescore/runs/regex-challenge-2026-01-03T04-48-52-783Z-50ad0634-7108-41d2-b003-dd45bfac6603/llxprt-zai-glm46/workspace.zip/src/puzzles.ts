/**
 * Find words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Regex to match words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');

  const matches = text.match(wordRegex) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map((e) => e.toLowerCase()));

  return matches
    .filter((word) => !exceptionSet.has(word.toLowerCase()))
    .map((word) => word); // Return as-is (preserving case from original text)
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Lookbehind to ensure token is preceded by a digit
  // Negative lookbehind to ensure we're not at the start of string preceded by a digit
  // Actually we want: digit + token, but not at start of string
  // Use positive lookbehind for digit, and make sure there's something before the digit (not at start)

  // Approach: find (digit)(token) where there's at least one character before the digit
  // Let's use a different approach
  const tokenWithDigitBehind = new RegExp(`(\\d)(${escapedToken})`, 'g');
  
  const results: string[] = [];
  let match: RegExpExecArray | null;

  // Reset regex state
  tokenWithDigitBehind.lastIndex = 0;

  while ((match = tokenWithDigitBehind.exec(text)) !== null) {
    const index = match.index;
    // Check that this is not at the start of the string
    if (index > 0) {
      // Return the digit + token combination (or just token based on test expectation)
      results.push(match[0]);
    }
  }

  return results;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }

  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }

  // No immediate repeated sequences (abab pattern)
  // Check for patterns of 2-4 characters that repeat anywhere in the string
  // Use case-insensitive comparison
  const lowerValue = value.toLowerCase();
  
  // Check for repeated sequences of 2-4 characters
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= lowerValue.length - len; i++) {
      const sequence = lowerValue.slice(i, i + len);
      // Look for this sequence appearing again later in the string
      for (let j = i + len; j <= lowerValue.length - len; j++) {
        const nextSequence = lowerValue.slice(j, j + len);
        if (sequence === nextSequence) {
          return false;
        }
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns (including compressed :: notation)
  // Must have at least one colon
  if (!value.includes(':')) {
    return false;
  }

  // IPv6 regex patterns
  // Full form: 8 groups of 1-4 hex digits separated by colons
  const fullIpv6 = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?:\/[0-9]+)?$/;
  
  // Compressed form with ::
  const compressedIpv6 = /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*(?:[0-9a-fA-F]{1,4})?(?:\/[0-9]+)?$/;
  
  // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  // We need to detect this but ensure pure IPv4 doesn't match
  const ipv4Embedded = /^(?:[0-9a-fA-F]{1,4}:)*::(?:ffff:)?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(?:\/[0-9]+)?$/;
  
  // Check for IPv6 patterns anywhere in the string
  const ipv6InText = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)+[0-9a-fA-F]{0,4}/;

  // First, make sure it's not just an IPv4 address
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?:\/[0-9]+)?$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }

  // Check for IPv6 patterns
  if (fullIpv6.test(value) || compressedIpv6.test(value)) {
    // Verify it has proper IPv6 structure (must have colons in the right places)
    const colonCount = (value.match(/:/g) || []).length;
    if (colonCount >= 2 && colonCount <= 7) {
      return true;
    }
  }

  // Check for IPv6 in text (embedded)
  if (ipv6InText.test(value)) {
    return true;
  }

  // Special case: ::1, ::, etc.
  if (/^::[0-9a-fA-F]{0,4}$/.test(value)) {
    return true;
  }

  // Check for IPv6 with embedded IPv4
  if (ipv4Embedded.test(value)) {
    const match = value.match(ipv4Embedded);
    if (match) {
      const ipv4Part = match[1];
      // Verify the embedded IPv4 is valid
      const octets = ipv4Part.split('.');
      const isValid = octets.every((octet) => {
        const num = parseInt(octet, 10);
        return num >= 0 && num <= 255;
      });
      if (isValid) {
        return true;
      }
    }
  }

  return false;
}
