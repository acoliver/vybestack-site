/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences even if input omitted it.
 * Collapse extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: collapse multiple spaces into one
  let normalized = text.replace(/\s+/g, ' ');

  // Insert space after sentence endings if missing (before next non-space char)
  normalized = normalized.replace(/([.!?])([A-Za-z])/g, '$1 $2');

  // Capitalize first letter of the entire text
  normalized = normalized.replace(/^\w/, (c) => c.toUpperCase());

  // Capitalize after sentence terminators (. ! ?)
  // Split into sentences and capitalize
  // Use a more sophisticated approach: look for sentence boundaries
  const sentences = normalized.split(/(?<=[.!?])\s+/);
  
  const capitalized = sentences.map((sentence, index) => {
    if (sentence.length === 0) return '';
    
    // Always capitalize the first sentence
    if (index === 0) {
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
    
    // For other sentences, capitalize first letter
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });

  // Join with single spaces
  return capitalized.join(' ').trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex
  // Matches http://, https://, www. protocols
  // Allows domains, IP addresses, ports, paths, query strings, fragments
  // Excludes trailing punctuation
  const urlRegex = /(?:(?:https?:\/\/|www\.)(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?::\d+)?(?:\/[^\s]*)?|[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?::\d+)?(?:\/[^\s]*)?)/g;

  const matches = text.match(urlRegex) || [];

  // Remove trailing punctuation from each URL
  return matches.map((url) => {
    return url.replace(/[.,;:!?(){}[\]"']+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// (but not https://)
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/
 * - Always upgrade scheme to https
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(https?):\/\/example\.com(\/[^\s]*)?/gi;

  return text.replace(urlPattern, (match, protocol, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https';

    // Check if we should skip host rewrite
    const skipHostRewrite = [
      path.includes('/cgi-bin'),
      path.includes('?'),
      path.includes('&'),
      path.includes('='),
      /\.jsp$/.test(path),
      /\.php$/.test(path),
      /\.asp$/.test(path),
      /\.aspx$/.test(path),
      /\.do$/.test(path),
      /\.cgi$/.test(path),
      /\.pl$/.test(path),
      /\.py$/.test(path),
    ].some(Boolean);

    // If path starts with /docs/ and we shouldn't skip, rewrite host
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      return `${newProtocol}://docs.example.com${path}`;
    }

    // Otherwise just upgrade the protocol
    return `${newProtocol}://example.com${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }

  // Special handling for February in non-leap years
  if (month === 2 && day === 29) {
    // Check if it's a leap year
    const yearNum = parseInt(year, 10);
    const isLeap = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeap) {
      return 'N/A';
    }
  }

  return year;
}
