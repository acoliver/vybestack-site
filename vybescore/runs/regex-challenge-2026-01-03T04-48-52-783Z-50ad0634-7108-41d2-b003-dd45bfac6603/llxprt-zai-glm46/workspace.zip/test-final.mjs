console.log("=== FINAL EDGE CASE TESTS ===\n");

const { validators, transformations, puzzles } = await import('./dist/src/index.js');

const tests = [
  // Email edge cases
  { val: 'name+tag@example.co.uk', fn: validators.isValidEmail },
  { val: 'user@example', fn: validators.isValidEmail },
  { val: '.user@example.com', fn: validators.isValidEmail },
  { val: 'user.@example.com', fn: validators.isValidEmail },
  { val: 'user..name@example.com', fn: validators.isValidEmail },
  
  // Argentine phone edge cases
  { val: '+54 9 11 1234 5678', fn: validators.isValidArgentinePhone },
  { val: '11 1234 5678', fn: validators.isValidArgentinePhone },
  { val: '+54 11 1234 5678', fn: validators.isValidArgentinePhone },
  
  // US phone edge cases
  { val: '212-555-7890', fn: validators.isValidUSPhone },
  { val: '072-555-7890', fn: validators.isValidUSPhone },
  { val: '212-055-7890', fn: validators.isValidUSPhone },
  
  // Name edge cases
  { val: "José María García López", fn: validators.isValidName },
  { val: "Mary-Jane O'Connor", fn: validators.isValidName },
  { val: "123", fn: validators.isValidName },
  { val: "X Æ A-12", fn: validators.isValidName },
  
  // Credit card edge cases
  { val: '4111 1111 1111 1111', fn: validators.isValidCreditCard },
  { val: '4111111111111112', fn: validators.isValidCreditCard },
  { val: '378282246310005', fn: validators.isValidCreditCard },
  
  // Transformations
  { val: 'hello.how are you?', fn: transformations.capitalizeSentences },
  { val: 'Visit (http://example.com/path?q=1).', fn: transformations.extractUrls },
  { val: 'http://example.com/docs/api/v1', fn: transformations.rewriteDocsUrls },
  { val: 'http://example.com/docs/login.jsp', fn: transformations.rewriteDocsUrls },
  
  // Puzzles
  { val: 'Abcdef!123', fn: puzzles.isStrongPassword },
  { val: 'Password1!', fn: puzzles.isStrongPassword },
  { val: '2001:0db8:85a3:0000:0000:8a2e:0370:7334', fn: puzzles.containsIPv6 },
  { val: '2001:db8::1', fn: puzzles.containsIPv6 },
  { val: '::1', fn: puzzles.containsIPv6 },
  { val: '192.168.1.1', fn: puzzles.containsIPv6 },
];

tests.forEach(({ val, fn }) => {
  const result = fn(val);
  const display = typeof result === 'boolean' ? result : Array.isArray(result) ? JSON.stringify(result) : `"${result}"`;
  console.log(`${fn.name}("${val}")`);
  console.log(`  → ${display}`);
});

console.log("\n=== DONE ===");
