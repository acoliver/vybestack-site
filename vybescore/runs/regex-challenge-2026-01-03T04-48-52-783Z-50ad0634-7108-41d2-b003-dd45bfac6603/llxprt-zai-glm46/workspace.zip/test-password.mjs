import { puzzles } from './dist/src/index.js';

// Test the abab pattern detection more thoroughly
console.log("=== PASSWORD PATTERN TESTS ===\n");

const testCases = [
  { pwd: "Abab!12345", expected: false, desc: "abab at start" },
  { pwd: "Abcdab!123", expected: false, desc: "ab repeated" },
  { pwd: "123abcabc!!", expected: false, desc: "abcabc" },
  { pwd: "Abcdefghij!", expected: false, desc: "no digit" },
  { pwd: "A1b2c3d4e5f", expected: false, desc: "no symbol" },
  { pwd: "1234567890!", expected: false, desc: "no letters" },
  { pwd: "Abcdef!234", expected: true, desc: "valid" },
  { pwd: "Abc1234567!", expected: true, desc: "valid with nums" },
  { pwd: "ABCDEFGHI1!", expected: false, desc: "no lowercase" },
  { pwd: "Abcdefghi!", expected: false, desc: "no digit" },
  { pwd: "Abcdefghij1", expected: false, desc: "no symbol" },
  { pwd: "Abc def!123", expected: false, desc: "has space" },
  { pwd: "Abcdefg1!A", expected: true, desc: "valid mixed" },
  { pwd: "Passw0rd!!", expected: true, desc: "valid simple" },
];

testCases.forEach(({ pwd, expected, desc }) => {
  const result = puzzles.isStrongPassword(pwd);
  const status = result === expected ? "✓" : "✗";
  console.log(`${status} ${desc}: "${pwd}" -> ${result} (expected ${expected})`);
});
