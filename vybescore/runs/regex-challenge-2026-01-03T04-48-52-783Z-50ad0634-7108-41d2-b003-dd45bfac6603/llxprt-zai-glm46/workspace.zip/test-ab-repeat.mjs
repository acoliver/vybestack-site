const pwd = "abcdab!123";
const lower = pwd.toLowerCase();
console.log("Password:", pwd);
console.log("Lowercased:", lower);
console.log("Length:", lower.length);
console.log("Max len to check:", Math.floor(lower.length / 2));

for (let len = 2; len <= Math.floor(lower.length / 2); len++) {
  console.log(`\nLength ${len}:`);
  for (let i = 0; i <= lower.length - 2 * len; i++) {
    const seq1 = lower.slice(i, i + len);
    const seq2 = lower.slice(i + len, i + 2 * len);
    const match = seq1 === seq2 ? "REPEAT!" : "";
    console.log(`  i=${i}: "${seq1}" + "${seq2}" ${match}`);
  }
}

// Now let's check character by character
console.log("\n\nCharacter breakdown:");
for (let i = 0; i < lower.length; i++) {
  console.log(`  [${i}] = "${lower[i]}"`);
}
