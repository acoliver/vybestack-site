const tests = ["A1b2c3d4e5f", "Abcdefghij!", "Abc1234567!"];

tests.forEach(pwd => {
  const hasSymbol = /[^A-Za-z0-9]/.test(pwd);
  console.log(`"${pwd}" has symbol: ${hasSymbol}`);
  console.log(`  Non-alphanumeric chars: ${pwd.replace(/[A-Za-z0-9]/g, '" "')}`);
});
