console.log("=== MANUAL TESTS ===\n");

const { validators, transformations, puzzles } = await import('./dist/src/index.js');

console.log("\n--- EMAIL VALIDATION ---");
const emailTests = [
  'name+tag@example.co.uk',
  'user@@example..com',
  'user@example',
  '.user@example.com',
  'user.@example.com',
  'user..name@example.com',
  'user@example.com',
  'user.name@example.co.uk',
  'user_name@example.com',  // underscore in local part is ok
  'user@ex_ample.com',       // underscore in domain is NOT ok
];
emailTests.forEach(email => {
  console.log(`  ${email}: ${validators.isValidEmail(email)}`);
});

console.log("\n--- US PHONE VALIDATION ---");
const usPhoneTests = [
  '(212) 555-7890',
  '212-555-7890',
  '2125557890',
  '+1-212-555-7890',
  '072-555-7890',     // bad - area code starts with 0
  '212-055-7890',     // bad - exchange starts with 0
  '212-555-789',      // too short
];
usPhoneTests.forEach(phone => {
  console.log(`  ${phone}: ${validators.isValidUSPhone(phone)}`);
});

console.log("\n--- ARGENTINE PHONE VALIDATION ---");
const arPhoneTests = [
  '+54 9 11 1234 5678',  // mobile with country code
  '011 1234 5678',       // Buenos Aires, no country code
  '+54 11 1234 5678',    // BA with country code
  '+54 341 123 4567',    // landline with country code
  '0341 4234567',        // landline, no country code
  '11 1234 5678',        // missing trunk prefix (should fail)
];
arPhoneTests.forEach(phone => {
  console.log(`  ${phone}: ${validators.isValidArgentinePhone(phone)}`);
});

console.log("\n--- NAME VALIDATION ---");
const nameTests = [
  'Jane Doe',
  "José María García López",
  "Mary-Jane O'Connor",
  '123',
  'X Æ A-12',
  'John',
  "O'Brien",
  'Anne-Marie',
];
nameTests.forEach(name => {
  console.log(`  "${name}": ${validators.isValidName(name)}`);
});

console.log("\n--- CREDIT CARD VALIDATION ---");
const ccTests = [
  '4111 1111 1111 1111',  // Visa, valid Luhn
  '4111111111111112',     // Visa, invalid Luhn
  '378282246310005',      // AmEx, valid Luhn
  '5500 0000 0000 0004',  // Mastercard, valid Luhn
];
ccTests.forEach(cc => {
  console.log(`  ${cc}: ${validators.isValidCreditCard(cc)}`);
});

console.log("\n--- SENTENCE CAPITALIZATION ---");
const capTests = [
  'hello.how are you?',
  'this is a test.another test',
  'SENTENCE one.sentence two',
];
capTests.forEach(text => {
  console.log(`  "${text}" -> "${transformations.capitalizeSentences(text)}"`);
});

console.log("\n--- URL EXTRACTION ---");
const urlTests = [
  'Visit http://example.com/path?q=1.',
  'Check out www.test.com and https://another.org',
];
urlTests.forEach(text => {
  console.log(`  "${text}"`);
  console.log(`    -> ${JSON.stringify(transformations.extractUrls(text))}`);
});

console.log("\n--- DOCS URL REWRITING ---");
const rewriteTests = [
  'http://example.com/docs/api/v1',
  'http://example.com/docs/login.jsp',
  'http://example.com/cgi-bin/script',
  'http://example.com/other/path',
];
rewriteTests.forEach(url => {
  console.log(`  ${url}`);
  console.log(`    -> ${transformations.rewriteDocsUrls(url)}`);
});

console.log("\n--- YEAR EXTRACTION ---");
const yearTests = [
  '12/25/2023',
  '02/29/2020',   // leap year
  '02/29/2021',   // not leap year
  '13/01/2023',   // invalid month
  '01/32/2023',   // invalid day
  'not a date',
];
yearTests.forEach(date => {
  console.log(`  ${date} -> ${transformations.extractYear(date)}`);
});

console.log("\n--- PREFIXED WORDS ---");
const prefixText = 'The unbreakable unbelieveable unknown unhappy unique unicorn';
const words = puzzles.findPrefixedWords(prefixText, 'un', ['unhappy']);
console.log(`  Text: "${prefixText}"`);
console.log(`  Prefix: "un", Exceptions: ["unhappy"]`);
console.log(`  Found: ${JSON.stringify(words)}`);

console.log("\n--- EMBEDDED TOKEN ---");
const tokenText = 'abc123def456ghi 123test test123 456token';
const tokens = puzzles.findEmbeddedToken(tokenText, 'token');
console.log(`  Text: "${tokenText}"`);
console.log(`  Token: "token"`);
console.log(`  Found: ${JSON.stringify(tokens)}`);

console.log("\n--- PASSWORD STRENGTH ---");
const pwdTests = [
  'Abcdef!123',       // valid
  'Password1!',       // valid
  'Abab!12345',       // abab pattern
  'abcdefghij!',      // no uppercase or digit
  'ABCDEFGHI1!',      // no lowercase
  'Abcdefghij1',      // no symbol
  'Abc def!123',      // has space
  'Passw0rd!!',       // valid
];
pwdTests.forEach(pwd => {
  console.log(`  "${pwd}": ${puzzles.isStrongPassword(pwd)}`);
});

console.log("\n--- IPV6 DETECTION ---");
const ipv6Tests = [
  '2001:0db8:85a3:0000:0000:8a2e:0370:7334',
  '2001:db8::1',
  '::1',
  '192.168.1.1',
  'fe80::1ff:fe23:4567:890a',
  '::ffff:192.168.1.1',
];
ipv6Tests.forEach(addr => {
  console.log(`  ${addr}: ${puzzles.containsIPv6(addr)}`);
});

console.log("\n=== DONE ===");
