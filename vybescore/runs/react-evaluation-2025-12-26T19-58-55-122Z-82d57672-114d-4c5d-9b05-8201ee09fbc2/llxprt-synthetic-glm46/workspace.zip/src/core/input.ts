/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (_equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (_equal === false) {
    equalFn = undefined
  } else if (typeof _equal === 'function') {
    equalFn = _equal
  }

  // Keep track of all observers dependent on this input
  const observers = new Set<ObserverR<unknown>>()
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    observers,
    // No updateFn for inputs - they are updated via setter
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    
    if (observer) {
      // Add observer as a dependent of this input
      observers.add(observer)
      
      // Establish dependency tracking - subjects keep track of their observers
      s.observer = observer
    }
    
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Clean up disposed observers first
    for (const obs of Array.from(observers)) {
      if ((obs as Observer<unknown>).disposed) {
        observers.delete(obs)
      }
    }
    
    // Notify all remaining observers of the change
    const observersCopy = Array.from(observers)
    for (const obs of observersCopy) {
      updateObserver(obs as Observer<unknown>)
    }
    
    return s.value
  }

  return [read, write]
}
