/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Keep track of all observers dependent on this computed value
  const observers = new Set<ObserverR<unknown>>()
  
  const o: Observer<T> & {observers?: Set<ObserverR<unknown>>} = {
    name: options?.name,
    value,
    updateFn,
    observers,
  }

  const getter = (): T => {
    const prevObserver = getActiveObserver()
    
    // Track this computed value with the active observer for notifications
    if (prevObserver && prevObserver !== o) {
      // Add the current observer as a dependent of this computed value
      // But only if it's not disposed
      if (!(prevObserver as Observer<unknown>).disposed) {
        observers.add(prevObserver)
      }
    }
    
    // If this is not being called during an update, compute the value
    if (prevObserver !== o) {
      updateObserver(o)
    }
    
    // Clean up disposed observers occasionally
    if (Math.random() < 0.01) { // 1% chance to clean up
      for (const obs of Array.from(observers)) {
        if ((obs as Observer<unknown>).disposed) {
          observers.delete(obs)
        }
      }
    }
    
    return o.value!
  }
  
  return getter
}
