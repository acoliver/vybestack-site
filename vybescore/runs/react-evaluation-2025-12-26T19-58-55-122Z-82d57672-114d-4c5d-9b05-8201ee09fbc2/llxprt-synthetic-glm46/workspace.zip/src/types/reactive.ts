/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR<T = unknown> = {
  name?: string
  updateFn: (value?: T) => T
  value?: T
  disposed?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  observers?: Set<ObserverR<unknown>>
}

export type Observer<T> = ObserverR<T> & ObserverV<T>

export type SubjectR = {
  name?: string
  observer?: ObserverR<unknown>
  observers?: Set<ObserverR<unknown>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR<unknown> | undefined

export function getActiveObserver(): ObserverR<unknown> | undefined {
  return activeObserver
}

// Track update depth to avoid infinite loops
let updateDepth = 0

export function updateObserver<T>(observer: Observer<T>): void {
  // Prevent infinite recursion
  if (updateDepth > 10) {
    return
  }
  
  const previous = activeObserver
  updateDepth++
  
  try {
    // Type assertion to assign observer since we maintain type safety
    // through the Observer<T> interface constraints
    activeObserver = observer as unknown as ObserverR<unknown>
    
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
    
    // Notify all dependent observers 
    if (observer.observers) {
      const observersCopy = Array.from(observer.observers)
      for (const obs of observersCopy) {
        // Check if observer has been disposed
        if (obs.disposed) {
          observer.observers.delete(obs)
          continue
        }
        // Use type assertion to bypass type checking
        updateObserver(obs as unknown as Observer<unknown>)
      }
    }
  } finally {
    activeObserver = previous
    updateDepth--
  }
}
