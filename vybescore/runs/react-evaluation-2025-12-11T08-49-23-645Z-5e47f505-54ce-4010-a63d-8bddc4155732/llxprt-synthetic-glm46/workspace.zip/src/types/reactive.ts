/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dirty?: boolean
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

export type CallbackNode<T> = {
  name?: string
  value?: T
  dependencies: Set<GetterFn<any>>
  updateFn: UpdateFn<T>
  disposed: boolean
}

export type EqualityFunction<T> = (a: T, b: T) => boolean

let activeCallback: CallbackNode<any> | undefined
let activeComputed: {
  dependencies: Set<GetterFn<any>>
  dirty: boolean
  value: any
  compute: () => any
} | undefined

// Global registries
const inputRegistry = new Map<GetterFn<any>, {
  value: any
  observers: Set<CallbackNode<any>>
}>()

const computedRegistry = new Map<GetterFn<any>, {
  value: any
  dependencies: Set<GetterFn<any>>
  dirty: boolean
  compute: () => any
}>()

export function getActiveCallback(): CallbackNode<any> | undefined {
  return activeCallback
}

export function getActiveComputed(): typeof activeComputed {
  return activeComputed
}

export function updateObserver<T>(observer: Observer<T>): void {
  observer.value = observer.updateFn(observer.value)
  observer.dirty = false
}

export function notifyObservers(getter: GetterFn<any>): void {
  const input = inputRegistry.get(getter)
  const computed = computedRegistry.get(getter)
  
  // Create a processing queue to ensure correct order
  const queue: GetterFn<any>[] = []
  const visited = new Set<GetterFn<any>>()
  const callbacksExecuted = new Set<CallbackNode<any>>()
  
  if (input) {
    queue.push(getter)
  }
  
  if (computed) {
    queue.push(getter)
  }
  
  // Process queue
  while (queue.length > 0) {
    const current = queue.shift()!
    if (visited.has(current)) continue
    visited.add(current)
    
    const currentInput = inputRegistry.get(current)
    const currentComputed = computedRegistry.get(current)
    
    if (currentInput) {
      // Execute callbacks that depend on this input directly
      currentInput.observers.forEach(callback => {
        if (!callback.disposed && !callbacksExecuted.has(callback)) {
          callback.value = callback.updateFn(callback.value)
          callbacksExecuted.add(callback)
        }
      })
    }
    
    // Update and process computed nodes that depend on this
    computedRegistry.forEach((computedNode, computedGetter) => {
      if (computedNode.dependencies.has(current)) {
        if (!visited.has(computedGetter)) {
          // Recompute this node
          computedNode.dirty = true
          const oldValue = computedNode.value
          computedNode.value = computedNode.compute()
          computedNode.dirty = false
          
          // Add to queue for processing its observers
          queue.push(computedGetter)
        }
      }
    })
  }
}

export function trackDependency(getter: GetterFn<any>): void {
  if (activeComputed) {
    activeComputed.dependencies.add(getter)
  } else if (activeCallback) {
    activeCallback.dependencies.add(getter)
    // Register callback as observer of this dependency
    const input = inputRegistry.get(getter)
    if (input) {
      input.observers.add(activeCallback)
    }
  }
}

export function pushComputed<T>(computed: typeof activeComputed): () => void {
  const prev = activeComputed
  activeComputed = computed
  return () => {
    activeComputed = prev
  }
}

export function executeWithCallback<T>(callback: CallbackNode<T>, fn: () => T): T {
  const prev = activeCallback
  activeCallback = callback
  try {
    return fn()
  } finally {
    activeCallback = prev
  }
}

export function registerInput<T>(getter: GetterFn<T>, initialValue: T): void {
  inputRegistry.set(getter, {
    value: initialValue,
    observers: new Set()
  })
}

export function registerComputed<T>(getter: GetterFn<T>, compute: () => T, initialValue?: T): void {
  const computed = {
    value: initialValue,
    dependencies: new Set<GetterFn<any>>(),
    dirty: false,
    compute
  }
  computedRegistry.set(getter, computed)
}

export function getInputValue<T>(getter: GetterFn<T>): T {
  const input = inputRegistry.get(getter)
  return input ? input.value : undefined as any
}

export function setInputValue<T>(getter: GetterFn<T>, value: T): void {
  const input = inputRegistry.get(getter)
  if (input) {
    input.value = value
  }
}

export function getComputed<T>(getter: GetterFn<T>) {
  return computedRegistry.get(getter)
}