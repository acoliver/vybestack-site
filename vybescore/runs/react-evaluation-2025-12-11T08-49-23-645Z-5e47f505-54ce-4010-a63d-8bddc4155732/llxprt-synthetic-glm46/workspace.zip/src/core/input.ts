/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  getActiveCallback,
  getActiveComputed,
  notifyObservers,
  // EqualFn,
  GetterFn,
  SetterFn,
  Options,
  EqualityFunction,
  registerInput,
  getInputValue,
  setInputValue
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualityFunction<T>,
  options?: Options
): InputPair<T> {
  // Register the input in global registry
  let getter: GetterFn<T>
  let setter: SetterFn<T>
  
  // Create getter function
  getter = () => {
    const callback = getActiveCallback()
    const computed = getActiveComputed()
    
    if (callback) {
      // Callback depends on this input
      callback.dependencies.add(getter as any)
    } else if (computed) {
      // Computed depends on this input
      computed.dependencies.add(getter as any)
    }
    
    return getInputValue(getter) as T
  }

  // Create setter function
  setter = (nextValue) => {
    const currentValue = getInputValue(getter) as T
    const equalFn: EqualityFunction<T> = _equal === true 
      ? (a, b) => a === b 
      : typeof _equal === 'function' 
        ? _equal 
        : (a, b) => a === b
    
    const shouldUpdate = !equalFn(currentValue, nextValue)
    if (shouldUpdate) {
      setInputValue(getter, nextValue)
      notifyObservers(getter as any)
    }
    return nextValue
  }

  // Register the input with initial value
  registerInput(getter, value)

  return [getter, setter]
}