/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  getActiveComputed,
  getActiveCallback,
  pushComputed,
  registerComputed,
  // trackDependency,
  getComputed
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  _options?: { name?: string }
): GetterFn<T> {
  // Create the compute function with dependency tracking
  const compute = () => {
    const restore = pushComputed({
      dependencies: new Set<GetterFn<any>>(),
      dirty: true,
      value,
      compute: () => updateFn(value)
    })
    try {
      const newValue = updateFn(value)
      value = newValue
      return value
    } finally {
      restore()
    }
  }

  // Create getter function
  const getter: GetterFn<T> = () => {
    const active = getActiveComputed()
    const callback = getActiveCallback()
    
    // Track dependencies
    if (active) {
      active.dependencies.add(getter as any)
    }
    
    if (callback) {
      callback.dependencies.add(getter as any)
    }
    
    // Get the current value from the registry
    const computed = getComputed(getter)
    return computed ? computed.value : value!
  }

  // Register the computed in global registry with initial computation
  registerComputed(getter, compute, value)

  // Run the initial computation to establish dependencies
  const initialValue = compute()
  const computed = getComputed(getter)
  if (computed) {
    computed.value = initialValue
  }
  
  return getter
}