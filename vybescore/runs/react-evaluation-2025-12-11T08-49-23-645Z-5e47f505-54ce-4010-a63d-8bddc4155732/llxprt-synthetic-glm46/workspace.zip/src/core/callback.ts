/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, CallbackNode, executeWithCallback } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: (value?: T) => T, value?: T): UnsubscribeFn {
  const callback: CallbackNode<T> = {
    value,
    dependencies: new Set(),
    updateFn,
    disposed: false
  }
  
  // Run the callback immediately to establish dependencies
  executeWithCallback(callback, () => {
    const result = updateFn(callback.value)
    callback.value = result
    return result
  })
  
  return () => {
    if (callback.disposed) return
    callback.disposed = true
    
    // Dependencies will be cleared below
    callback.dependencies.clear()
    
    // Clear the observer to stop further updates
    callback.value = undefined
    callback.updateFn = () => value!
  }
}