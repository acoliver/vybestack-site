/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

// Map to store dependencies for each computed observer
const dependencyMap = new WeakMap<Observer<unknown>, Set<Subject<unknown>>>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  initialValue?: T,
  equalFn?: EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value: initialValue,
    updateFn: (prevValue?: T) => {
      // Create a new set of dependencies for this computation
      const deps = new Set<Subject<unknown>>()
      dependencyMap.set(observer, deps)
      
      // Temporarily override getActiveObserver to track dependencies
      const originalGetActiveObserver = getActiveObserver
      
      // Create patched version that records dependencies
      function patchedGetActiveObserver() {
        return observer
      }
      
      // Override for dependency tracking
      ;(globalThis as unknown as { getActiveObserver: typeof getActiveObserver }).getActiveObserver = patchedGetActiveObserver
      
      try {
        const newValue = updateFn(prevValue)
        return newValue
      } finally {
        // Restore original getActiveObserver
        ;(globalThis as unknown as { getActiveObserver: typeof getActiveObserver }).getActiveObserver = originalGetActiveObserver
      }
    }
  }
  
  // Perform initial computation
  updateObserver(observer)
  
  // Getter function that returns the computed value
  const getter: GetterFn<T> = () => {
    // Get the current active observer (if any)
    const currentObserver = getActiveObserver()
    
    // If there's an active observer, add it as a dependent
    if (currentObserver) {
      const deps = dependencyMap.get(observer)
      if (deps) {
        // For now, we don't track what this getter depends on
        // This is a placeholder for full dependency tracking implementation
      }
    }
    
    return observer.value!
  }
  
  return getter
}