/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part of an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equalFn?: EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: equalFn || ((a, b) => a === b)
  }

  const getter: GetterFn<T> = () => {
    // When a getter is called, track the active observer 
    // if there is one (meaning the getter is called inside a computed/callback)
    const observer = getActiveObserver()
    if (observer) {
      subject.observer = observer
    }
    return subject.value
  }

  const setter: SetterFn<T> = (newValue: T) => {
    // Check if the value actually changed before triggering updates
    if (!subject.equalFn!(subject.value, newValue)) {
      subject.value = newValue
      
      // If there's a registered observer, update it
      if (subject.observer) {
        updateObserver(subject.observer as Observer<unknown>)
      }
    }
    return subject.value
  }

  return [getter, setter]
}