/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, initialValue?: T): UnsubscribeFn {
  // Track if callback has been unsubscribed
  let disposed = false
  
  const observer: Observer<T> = {
    value: initialValue,
    updateFn: (prevValue?: T) => {
      // If disposed, don't run the callback
      if (disposed) {
        return prevValue!
      }
      
      // Run the callback function with the previous value
      return updateFn(prevValue)
    }
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  // Return unsubscribe function
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => initialValue!
  }
}