import express, { Request, Response, Express } from "express";
import path from "path";
import { initializeDatabase, Database } from "./database.js";
import {
  validateSubmission,
  FormSubmissionWithErrors,
  FormSubmission,
} from "./validation.js";

export interface SubmissionResult {
  success: boolean;
  data?: FormSubmissionWithErrors;
  error?: string;
}

export class FormServer {
  private app: Express;
  private database: Database | null = null;
  private port: number;

  constructor() {
    this.app = express();
    this.port = Number(process.env.PORT) || 3535;
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    // Parse URL-encoded bodies and JSON
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());

    // Serve static files
    this.app.use(express.static(path.join(process.cwd(), "public")));

    // Set EJS as template engine
    this.app.set("view engine", "ejs");
    this.app.set("views", path.join(process.cwd(), "src", "templates"));
  }

  private setupRoutes(): void {
    // Main form page
    this.app.get("/", this.handleFormGet.bind(this));

    // Form submission
    this.app.post("/submit", this.handleSubmit.bind(this));

    // Thank you page
    this.app.get("/thank-you", this.handleThankYou.bind(this));
  }

  private async handleFormGet(req: Request, res: Response): Promise<void> {
    // Pass empty errors and empty form data for initial load
    res.render("form", {
      errors: {},
      formData: {
        firstName: "",
        lastName: "",
        streetAddress: "",
        city: "",
        stateProvince: "",
        postalCode: "",
        country: "",
        email: "",
        phone: "",
      },
    });
  }

  private async handleSubmit(req: Request, res: Response): Promise<void> {
    if (!this.database) {
      res.status(500).send("Database not initialized");
      return;
    }

    const formData: FormSubmission = {
      firstName: req.body.firstName || "",
      lastName: req.body.lastName || "",
      streetAddress: req.body.streetAddress || "",
      city: req.body.city || "",
      stateProvince: req.body.stateProvince || "",
      postalCode: req.body.postalCode || "",
      country: req.body.country || "",
      email: req.body.email || "",
      phone: req.body.phone || "",
    };

    const validatedData = validateSubmission(formData);

    // Check for validation errors
    if (Object.keys(validatedData.errors).length > 0) {
      res.render("form", {
        errors: validatedData.errors,
        formData: validatedData,
      });
      return;
    }

    // Save to database
    try {
      const stmt = this.database.db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        validatedData.firstName,
        validatedData.lastName,
        validatedData.streetAddress,
        validatedData.city,
        validatedData.stateProvince,
        validatedData.postalCode,
        validatedData.country,
        validatedData.email,
        validatedData.phone,
      ]);

      stmt.free();

      // Save database to file
      await this.database.save();

      // Redirect to thank you page
      res.redirect(302, "/thank-you");
    } catch (error) {
      console.error("Error saving submission:", error);
      res.status(500).send("Error saving submission");
    }
  }

  private async handleThankYou(req: Request, res: Response): Promise<void> {
    res.render("thank-you");
  }

  public async start(): Promise<void> {
    try {
      this.database = await initializeDatabase();
      console.log("Database initialized successfully");
    } catch (error) {
      console.error("Failed to initialize database:", error);
      process.exit(1);
    }

    this.app.listen(this.port, () => {
      console.log(`Server running on port ${this.port}`);
    });
  }

  public async stop(): Promise<void> {
    if (this.database) {
      this.database.close();
      this.database = null;
      console.log("Database closed");
    }
  }
}

// Start the server if this file is run directly
// Check if import.meta.url equals the current file path (ES module equivalent of require.main === module)
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new FormServer();

  // Handle graceful shutdown
  const shutdown = async (signal: string) => {
    console.log(`\nReceived ${signal}, shutting down gracefully...`);
    await server.stop();
    process.exit(0);
  };

  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));

  server.start();
}
