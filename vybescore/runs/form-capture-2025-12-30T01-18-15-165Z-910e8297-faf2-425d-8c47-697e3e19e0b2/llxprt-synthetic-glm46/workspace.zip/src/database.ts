import fs from "fs";
import path from "path";
import initSqlJs, { Database as SqliteDatabase } from "sql.js";

export interface Database {
  db: SqliteDatabase; // sql.js Database instance
  save: () => Promise<void>;
  close: () => void;
}

export async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  const dbPath = path.join(process.cwd(), "data", "submissions.sqlite");
  let db: SqliteDatabase;

  // Try to load existing database, otherwise create new one
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    // Initialize with schema
    const schema = fs.readFileSync(
      path.join(process.cwd(), "db", "schema.sql"),
      "utf8"
    );
    db.run(schema);
  }

  return {
    db,
    save: async (): Promise<void> => {
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    },
    close: (): void => {
      db.close();
    },
  };
}