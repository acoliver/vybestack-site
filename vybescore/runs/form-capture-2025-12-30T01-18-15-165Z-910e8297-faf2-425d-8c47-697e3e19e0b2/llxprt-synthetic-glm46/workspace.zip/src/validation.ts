export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface FormSubmissionWithErrors extends FormSubmission {
  errors: Partial<Record<keyof FormSubmission, string>>;
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhone(phone: string): boolean {
  // eslint-disable-next-line no-useless-escape
  const phoneRegex = /^\+?[0-9\s\-\(\)]+$/;
  return phoneRegex.test(phone);
}

export function validatePostalCode(postalCode: string): boolean {
  // eslint-disable-next-line no-useless-escape
  const postalCodeRegex = /^[a-zA-Z0-9\s\-]+$/;
  return postalCode.length > 0 && postalCodeRegex.test(postalCode);
}

export function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

export function validateSubmission(
  formData: FormSubmission
): FormSubmissionWithErrors {
  const errors: Partial<Record<keyof FormSubmission, string>> = {};

  if (!validateRequired(formData.firstName)) {
    errors.firstName = "First name is required";
  }

  if (!validateRequired(formData.lastName)) {
    errors.lastName = "Last name is required";
  }

  if (!validateRequired(formData.streetAddress)) {
    errors.streetAddress = "Street address is required";
  }

  if (!validateRequired(formData.city)) {
    errors.city = "City is required";
  }

  if (!validateRequired(formData.stateProvince)) {
    errors.stateProvince = "State/Province/Region is required";
  }

  if (!validateRequired(formData.postalCode)) {
    errors.postalCode = "Postal code is required";
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.postalCode = "Invalid postal code format";
  }

  if (!validateRequired(formData.country)) {
    errors.country = "Country is required";
  }

  if (!validateRequired(formData.email)) {
    errors.email = "Email is required";
  } else if (!validateEmail(formData.email)) {
    errors.email = "Invalid email format";
  }

  if (!validateRequired(formData.phone)) {
    errors.phone = "Phone number is required";
  } else if (!validatePhone(formData.phone)) {
    errors.phone = "Invalid phone number format";
  }

  return { ...formData, errors };
}