import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';

export function renderMarkdown(data: ReportData, options: ReportOptions): string {
  const lines: string[] = [];
  
  // Title
  lines.push(`# ${data.title}`);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries heading
  lines.push('## Entries');
  
  // Entries list
  for (const entry of data.entries) {
    const amount = entry.amount.toFixed(2);
    lines.push(`- **${entry.label}** — $${amount}`);
  }
  
  // Total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const totalAmount = total.toFixed(2);
    lines.push(`**Total:** $${totalAmount}`);
  }
  
  return lines.join('\n');
}

export const markdownFormatter: ReportFormatter = {
  render: renderMarkdown,
};