#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { exit } from 'node:process';
import type { ReportData, ReportOptions, ReportEntry } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const [dataFile, ...rest] = args;
  
  if (!dataFile) {
    console.error('Error: Missing data file argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }

  const options: Partial<CliArgs> = {
    dataFile,
    includeTotals: false,
  };

  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    const nextArg = rest[i + 1];

    switch (arg) {
      case '--format':
        if (!nextArg || nextArg.startsWith('--')) {
          console.error('Error: --format requires a value (markdown or text)');
          exit(1);
        }
        if (nextArg !== 'markdown' && nextArg !== 'text') {
          console.error(`Error: Unsupported format: ${nextArg}. Supported formats: markdown, text`);
          exit(1);
        }
        options.format = nextArg;
        i++;
        break;
      
      case '--output':
        if (!nextArg || nextArg.startsWith('--')) {
          console.error('Error: --output requires a file path');
          exit(1);
        }
        options.outputPath = nextArg;
        i++;
        break;
      
      case '--includeTotals':
        options.includeTotals = true;
        break;
      
      default:
        console.error(`Error: Unknown argument: ${arg}`);
        console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
        exit(1);
    }
  }

  if (!options.format) {
    console.error('Error: --format is required (markdown or text)');
    exit(1);
  }

  return options as CliArgs;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: must be an object`);
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (must be a string)`);
    }
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (must be a number)`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries as ReportEntry[],
  };
}

function main() {
  const args = process.argv.slice(2);
  const cliArgs = parseArgs(args);

  // Read and parse JSON data
  let reportData: ReportData;
  try {
    const fileContent = readFileSync(cliArgs.dataFile, 'utf-8');
    const jsonData = JSON.parse(fileContent);
    reportData = validateReportData(jsonData);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${cliArgs.dataFile}: ${error.message}`);
    } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File not found: ${cliArgs.dataFile}`);
    } else {
      console.error(`Error reading or parsing data file: ${error instanceof Error ? error.message : String(error)}`);
    }
    exit(1);
  }

  // Select formatter
  const options: ReportOptions = {
    includeTotals: cliArgs.includeTotals,
  };

  const formatter = cliArgs.format === 'markdown' ? markdownFormatter : textFormatter;
  const output = formatter.render(reportData, options);

  // Write output
  if (cliArgs.outputPath) {
    try {
      writeFileSync(cliArgs.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error writing output file: ${error instanceof Error ? error.message : String(error)}`);
      exit(1);
    }
  } else {
    console.log(output);
  }
}

main();