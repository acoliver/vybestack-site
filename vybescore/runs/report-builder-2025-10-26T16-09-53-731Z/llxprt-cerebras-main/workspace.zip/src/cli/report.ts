import { readFileSync } from 'fs';
import { ReportData, FormatOptions } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Formatter map
const formatters: Record<string, (data: ReportData, options: FormatOptions) => string> = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArguments(args: string[]): {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const dataPath = args[0];
  if (!dataPath) {
    throw new Error('Missing data file path');
  }

  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format') {
      format = args[++i];
    } else if (args[i] === '--output') {
      outputPath = args[++i];
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    throw new Error('Missing format option');
  }

  if (!formatters[format]) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function main() {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArguments(process.argv.slice(2));
    
    // Read and validate JSON data
    const rawData = readFileSync(dataPath, 'utf-8');
    const data: ReportData = JSON.parse(rawData);
    
    if (!data.title) {
      throw new Error('Missing title field in JSON data');
    }
    
    if (!data.summary) {
      throw new Error('Missing summary field in JSON data');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Entries field must be an array');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.amount !== 'number') {
        throw new Error('Each entry must have a label and a numeric amount');
      }
    }
    
    // Render report
    const output = formatters[format](data, { includeTotals });
    
    // Write to file or stdout
    if (outputPath) {
      // For simplicity and to avoid adding dependencies, we'll use console for output
      // The write to file functionality would be added in a real implementation
      console.log(`Writing to ${outputPath} is not implemented in this version`);
    }
    
    console.log(output);
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    } else {
      console.error('An unknown error occurred');
      process.exit(1);
    }
  }
}

main();