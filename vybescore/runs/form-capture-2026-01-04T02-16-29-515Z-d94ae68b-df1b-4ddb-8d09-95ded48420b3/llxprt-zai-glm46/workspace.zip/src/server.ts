import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve('public')));

app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[\d\s()+-]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode);
}

function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    const value = data[field]?.trim();
    if (!value) {
      errors.push({ field, message: `${field} is required` });
    }
  }

  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (data.phone && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +',
    });
  }

  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Postal code can only contain letters, digits, spaces, and dashes',
    });
  }

  return errors;
}

app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const validationErrors = validateFormData(formData);

  if (validationErrors.length > 0) {
    const errorMessages = validationErrors.map((e) => e.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: formData,
    });
    return;
  }

  if (!db) {
    res.status(500).send('Database not initialized');
    return;
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName!,
      formData.lastName!,
      formData.streetAddress!,
      formData.city!,
      formData.stateProvince!,
      formData.postalCode!,
      formData.country!,
      formData.email!,
      formData.phone!,
    ]);
    stmt.free();

    saveDatabase();
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('An error occurred while saving your submission');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { firstName: 'Friend' });
});

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();

    if (fs.existsSync(DB_PATH)) {
      const buffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(buffer);
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      db.run(schema);
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (!db) return;

  const data = db.export();
  const buffer = Buffer.from(data);
  const dir = path.dirname(DB_PATH);

  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  fs.writeFileSync(DB_PATH, buffer);
}

async function startServer(): Promise<void> {
  await initializeDatabase();

  const server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  setupGracefulShutdown(server);
}

function setupGracefulShutdown(server: {
  close: (callback?: () => void) => void;
}): void {
  const shutdown = (signal: string) => {
    console.log(`\n${signal} received, shutting down gracefully...`);
    
    server.close(() => {
      console.log('HTTP server closed');
      
      if (db) {
        try {
          db.close();
          console.log('Database connection closed');
        } catch (err) {
          console.error('Error closing database:', err);
        }
      }
      
      process.exit(0);
    });

    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000).unref();
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { app, initializeDatabase, saveDatabase };
