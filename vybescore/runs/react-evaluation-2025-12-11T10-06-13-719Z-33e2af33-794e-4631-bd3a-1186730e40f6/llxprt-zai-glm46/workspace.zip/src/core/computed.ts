/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  Options,
  getActiveObserver,
  subscribe,
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>, // eslint-disable-line @typescript-eslint/no-unused-vars
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      subscribe(o, observer)
    }
    
    // Only compute if value is undefined (first time)
    if (o.value === undefined) {
      o.value = o.updateFn(o.value)
    }
    return o.value!
  }
  
  // Initialize value and subscribe to dependencies
  updateObserver(o)
  
  return getter
}
