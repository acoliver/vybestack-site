/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const callbackObserver: Observer<T> = {
    value,
    updateFn,
  }
  
  // Execute the callback to establish dependencies and get initial value
  updateObserver(callbackObserver as Observer<unknown>)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // The callback will be automatically cleaned up when dependencies are garbage collected
  }
}
