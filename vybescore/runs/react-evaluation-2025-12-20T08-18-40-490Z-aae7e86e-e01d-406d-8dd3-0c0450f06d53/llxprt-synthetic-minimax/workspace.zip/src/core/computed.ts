/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let computedValue: T | undefined = value
  let observer: Observer<T> | undefined

  const getter: GetterFn<T> = () => {
    // Create or reuse the observer for this calculation
    if (!observer) {
      observer = {
        name: options?.name,
        value: computedValue,
        updateFn,
      }
    }
    
    // Execute the update function to calculate the new value
    updateObserver(observer as Observer<unknown>)
    computedValue = observer.value

    return computedValue!
  }

  return getter
}
