/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  addObserverDependency,
  notifySubject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    // If there's an active observer, register this subject as a dependency
    const observer = getActiveObserver()
    if (observer) {
      addObserverDependency(subject, observer)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    subject.value = nextValue
    // Notify all observers that depend on this subject
    notifySubject(subject)
    return subject.value
  }

  return [read, write]
}
