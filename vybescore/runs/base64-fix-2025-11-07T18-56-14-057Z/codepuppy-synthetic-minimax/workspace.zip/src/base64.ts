/**
 * Encode plain text to Base64 using the canonical RFC 4648 alphabet.
 * Uses the standard Base64 alphabet with + and / characters and includes required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and throws errors for invalid payloads.
 * Implements RFC 4648 compliant validation.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  try {
    // Reject empty input
    if (trimmed.length === 0) {
      throw new Error('Invalid Base64 input: empty string');
    }
    
    // Validate input contains only valid Base64 characters (including optional padding)
    if (!/^[A-Za-z0-9+/]*={0,2}$/.test(trimmed)) {
      throw new Error('Invalid Base64 input: contains illegal characters');
    }
    
    // Validate padding rules if padding is present
    const padIndex = trimmed.indexOf('=');
    if (padIndex !== -1) {
      const len = trimmed.length;
      const padCount = len - padIndex;
      
      // Padding can only be 1 or 2 '=' characters
      if (padCount > 2) {
        throw new Error('Invalid Base64 input: too much padding');
      }
      
      // Padding must only appear at the end
      if (!trimmed.slice(padIndex).split('').every(c => c === '=')) {
        throw new Error('Invalid Base64 input: padding not at the end');
      }
      
      // If there's padding, the total length must be a multiple of 4
      if (len % 4 !== 0) {
        throw new Error('Invalid Base64 input: padded length not a multiple of 4');
      }
    } else {
      // No padding: length should be compatible with Base64 encoding rules
      const len = trimmed.length;
      if (len % 4 === 1) {
        // Length congruent to 1 mod 4 is never valid for Base64 without padding
        throw new Error('Invalid Base64 input: length not compatible with Base64 format');
      }
    }
    
    // Try to decode using Node's Buffer - this will catch most invalid inputs
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    
    // Additional validation: ensure we didn't get empty result from non-empty input
    // (this can happen with certain invalid Base64 strings)
    if (result === '' && trimmed !== '') {
      // Check if this is actually valid empty result (e.g., decoding empty string)
      try {
        // Re-encode and compare - if they don't match, the original was invalid
        const reencoded = Buffer.from(result, 'utf8').toString('base64').replace(/=+$/, '');
        const inputWithoutPadding = trimmed.replace(/=+$/, '');
        if (reencoded !== inputWithoutPadding) {
          throw new Error('Invalid Base64 input: corrupted data');
        }
      } catch (validationError) {
        throw new Error('Invalid Base64 input: corrupted data');
      }
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && (error.message.startsWith('Invalid Base64 input:') || error.message.startsWith('Failed to decode Base64 input:'))) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
