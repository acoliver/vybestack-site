

/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Checks if a string contains only valid Base64 characters.
 */
function hasValidBase64Chars(input: string): boolean {
  return /^[A-Za-z0-9+/]*={0,2}$/.test(input);
}

/**
 * Validates Base64 padding format.
 */
function validatePadding(input: string): boolean {
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) {
    return true; // No padding is valid
  }
  
  // Padding must be at the end and limited to at most 2 characters
  const padding = input.substring(paddingIndex);
  return padding === '=' || padding === '==';
}

/**
 * Validates Base64 length requirements.
 */
function validateLength(input: string): boolean {
  // For padded input, length must be multiple of 4
  if (input.includes('=')) {
    return input.length % 4 === 0;
  }
  
  // For unpadded input, check if it can be correctly padded
  return input.length % 4 === 0 || input.length % 4 === 2 || input.length % 4 === 3;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws an error for invalid Base64 strings.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  if (!hasValidBase64Chars(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  if (!validatePadding(input)) {
    throw new Error('Invalid Base64 input: incorrect padding');
  }

  if (!validateLength(input)) {
    throw new Error('Invalid Base64 input: incorrect length');
  }

  try {
    // Normalize by adding proper padding if needed
    const normalized = input.length % 4 !== 0 
      ? input + '='.repeat(4 - (input.length % 4))
      : input;
      
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: malformed data');
  }
}
