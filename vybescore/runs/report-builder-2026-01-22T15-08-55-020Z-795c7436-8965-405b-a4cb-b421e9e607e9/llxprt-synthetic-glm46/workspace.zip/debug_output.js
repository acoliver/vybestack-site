#!/usr/bin/env node
import { writeFileSync } from 'fs';

const testContent = "This is a test file";
try {
  writeFileSync('results/test_output.md', testContent);
  console.log("File written successfully to results/test_output.md");
} catch (error) {
  console.error("Error writing file:", error);
}