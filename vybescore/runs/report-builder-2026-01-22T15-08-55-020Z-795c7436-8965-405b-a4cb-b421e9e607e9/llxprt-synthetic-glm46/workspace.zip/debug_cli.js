#!/usr/bin/env node
import { readFileSync } from 'fs';

try {
  const fileContent = readFileSync('fixtures/data.json', 'utf-8');
  const parsed = JSON.parse(fileContent);
  console.log('Input data:', parsed);
  
  const { renderMarkdown } = await import('./src/formats/markdown.js');
  const result = renderMarkdown(parsed, { format: 'markdown', includeTotals: true });
  console.log('Rendered result:');
  console.log(result);
  
  import('fs').then(fs => {
    fs.writeFileSync('results/manual_test.md', result);
    console.log('File written to results/manual_test.md');
  });
} catch (error) {
  console.error('Error:', error);
}