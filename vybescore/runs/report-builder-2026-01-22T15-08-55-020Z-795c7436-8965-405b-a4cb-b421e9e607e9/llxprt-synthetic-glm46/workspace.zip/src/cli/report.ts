#!/usr/bin/env node
import { readFileSync, writeFileSync } from 'fs';
import { ReportData, ReportOptions, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Enable debug logging
const DEBUG = process.env.REPORT_DEBUG === 'true';

/**
 * Map of format names to their respective renderer functions
 */
const FORMATTERS: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Parse command line arguments using Node's built-in parseArgs
 */
function parseArguments(): ReportOptions & { inputFile: string } {
  const args = process.argv.slice(2);
  
  // Check if input file is provided
  if (args.length === 0) {
    console.error('Error: Input file path is required');
    process.exit(1);
  }
  
  const inputFile = args[0];
  let format: 'markdown' | 'text' = 'markdown';
  let output: string | undefined;
  let includeTotals = false;
  
  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      const formatValue = args[i + 1];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Error: Unsupported format: ${formatValue}`);
        process.exit(1);
      }
      format = formatValue as 'markdown' | 'text';
      i++;
    } else if (args[i] === '--output' && i + 1 < args.length) {
      output = args[i + 1];
      i++;
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    } else if (args[i].startsWith('--')) {
      console.error(`Error: Unknown option: ${args[i]}`);
      process.exit(1);
    }
  }
  
  return {
    inputFile,
    format,
    output,
    includeTotals,
  };
}

/**
 * Validate the report data structure
 */
function validateReportData(data: unknown): asserts data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Expected an object');
  }
  
  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid report data: title must be a string');
  }
  
  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid report data: summary must be a string');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }
  
  for (const entry of reportData.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid report data: each entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid report data: entry.label must be a string');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid report data: entry.amount must be a number');
    }
  }
}

/**
 * Load and parse JSON from file
 */
function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf-8');
    const parsed = JSON.parse(fileContent) as unknown;
    validateReportData(parsed);
    return parsed;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && error.message.startsWith('Invalid report data')) {
      throw error;
    }
    if (error instanceof Error) {
      throw new Error(`Failed to read file ${filePath}: ${error.message}`);
    }
    throw new Error(`Failed to process file ${filePath}`);
  }
}

/**
 * Main application entry point
 */
function main(): void {
  try {
    const { inputFile, format, output, includeTotals } = parseArguments();
    const reportData = loadReportData(inputFile);
    const formatter = FORMATTERS[format];
    
    if (!formatter) {
      throw new Error(`Error: Unsupported format: ${format}`);
    }
    
    const renderedReport = formatter(reportData, { format, output, includeTotals });
    
    if (output) {
      if (DEBUG) console.log(`Writing report to file: ${output}`);
      if (DEBUG) console.log(`Report content preview: ${renderedReport.substring(0, 100)}...`);
      try {
        writeFileSync(output, renderedReport);
        if (DEBUG) console.log(`Successfully wrote to ${output}`);
      } catch (error) {
        if (DEBUG) console.error(`Error writing to file: ${error}`);
        throw error;
      }
    } else {
      console.log(renderedReport);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unexpected error occurred');
    }
    process.exit(1);
  }
}

// Run the application if this file is being executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
