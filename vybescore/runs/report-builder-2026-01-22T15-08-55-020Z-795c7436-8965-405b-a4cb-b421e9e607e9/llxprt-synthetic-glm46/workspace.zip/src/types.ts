/**
 * Report data entry with label and amount
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Command line options for the report CLI
 */
export interface ReportOptions {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

/**
 * Type for report rendering function
 */
export type ReportRenderer = (data: ReportData, options: ReportOptions) => string;