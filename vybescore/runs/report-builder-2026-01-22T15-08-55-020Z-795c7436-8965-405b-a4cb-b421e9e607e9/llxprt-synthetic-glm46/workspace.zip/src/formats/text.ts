import { ReportData, ReportOptions, ReportRenderer } from '../types.js';

/**
 * Format an amount with two decimal places and a dollar sign
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate total amount from all entries
 */
function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Render report data as text format
 */
export const renderText: ReportRenderer = (data: ReportData, options: ReportOptions) => {
  const lines: string[] = [];
  
  // Add title
  lines.push(data.title);
  lines.push('');
  
  // Add summary
  lines.push(data.summary);
  lines.push('');
  
  // Add entries section
  lines.push('Entries:');
  data.entries.forEach(entry => {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  });
  
  // Add total if requested
  if (options.includeTotals) {
    lines.push(`Total: ${formatAmount(calculateTotal(data.entries))}`);
  }
  
  return lines.join('\n');
};