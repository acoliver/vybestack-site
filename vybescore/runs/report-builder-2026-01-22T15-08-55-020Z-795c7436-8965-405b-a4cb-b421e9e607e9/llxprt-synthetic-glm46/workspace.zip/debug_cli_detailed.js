#!/usr/bin/env node
import { readFileSync, writeFileSync } from 'fs';

console.log('=== CLI Debug Script ===');
console.log('Working directory:', process.cwd());
console.log('Arguments:', process.argv.slice(2));

// Parse arguments like our CLI
const args = process.argv.slice(2);
const inputFile = args[0];
let format = 'markdown';
let output;
let includeTotals = false;

console.log('Input file:', inputFile);

for (let i = 1; i < args.length; i++) {
  if (args[i] === '--format' && i + 1 < args.length) {
    format = args[i + 1];
    i++;
  } else if (args[i] === '--output' && i + 1 < args.length) {
    output = args[i + 1];
    i++;
  } else if (args[i] === '--includeTotals') {
    includeTotals = true;
  }
}

console.log('Parsed options:');
console.log('  Format:', format);
console.log('  Output:', output);
console.log('  Include totals:', includeTotals);

try {
  // Load data
  const fileContent = readFileSync(inputFile, 'utf-8');
  const data = JSON.parse(fileContent);
  console.log('Data loaded successfully, title:', data.title);
  
  // Import formatter
  const { renderMarkdown } = await import('./dist/formats/markdown.js');
  console.log('Formatter imported');
  
  // Render
  const result = renderMarkdown(data, { format, output, includeTotals });
  console.log('Report rendered, length:', result.length);
  
  // Write if output specified
  if (output) {
    try {
      writeFileSync(output, result);
      console.log('File written to:', output);
    } catch (e) {
      console.error('Error writing to file:', e);
    }
  } else {
    console.log('No output file specified, showing content:');
    console.log(result);
  }
  
} catch (e) {
  console.error('Error:', e);
}