export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with common patterns.
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Basic pattern: local@domain with common features
  const emailPattern = /^[a-zA-Z0-9]([a-zA-Z0-9!#$%&'*+\-/=?^_`{|}~.]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.([a-zA-Z]{2,})([a-zA-Z]{2,})?$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional validation checks
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.trim();
  
  // Check for leading +
  const hasPlusOne = cleaned.startsWith('+1');
  const phoneNumber = hasPlusOne ? cleaned.substring(2) : cleaned;
  
  // Remove all non-digits
  const digitsOnly = phoneNumber.replace(/\D/g, '');
  
  // US phone numbers must be 10 digits (after removing +1)
  if (digitsOnly.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Must have valid format with separators or exact digits
  const validFormats = [
    /^\+?1?[. \s-]?\(?[2-9][0-9][0-9]\)?[. \s-]?[2-9][0-9][0-9][. \s-]?[0-9]{4}$/,  // with parens/separators
    /^\+?1?[2-9][0-9][0-9][2-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]$/,  // all digits
  ];
  
  return validFormats.some(pattern => pattern.test(value.trim()));
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 * Handles patterns like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9
 * Area code 2-4 digits (1-9), subscriber 6-8 digits total
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input - remove spaces, hyphens, and parentheses for validation
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Pattern to match Argentine phone numbers with proper structure
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits total
  const pattern = /^(?:\+54)?0?(?:9)?([1-9][0-9]{1,3})([0-9]{6,8})$/;
  
  const match = cleaned.match(pattern);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits starting with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Basic format check - allow single spaces or basic formatting
  const hasValidFormat = /^[+]?[0-9\s\-()]{8,25}$/.test(value);
  if (!hasValidFormat) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Empty or too short names are invalid
  if (!value || value.trim().length < 2) {
    return false;
  }
  
  // Pattern for valid names:
  // - Allow letters, spaces, hyphens, apostrophes
  // - No digits or special symbols except - and '
  // - Must start with a letter
  const namePattern = /^[a-zA-Z][a-zA-Z\s\-']{1,}[a-zA-Z]$/;
  
  if (!namePattern.test(value.trim())) {
    return false;
  }
  
  // Additional validation: reject obvious non-names
  // No digits anywhere
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with unusual symbols (other than - and ')
  if (/[^a-zA-Z\s\-']/.test(value)) {
    return false;
  }
  
  // Reject the X Æ A-12 pattern or similar
  if (/[ÆØÅ]/.test(value) && /[0-9]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers using prefix, length, and Luhn checksum.
 * Accepts Visa/Mastercard/AmEx prefixes and proper lengths
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check card type and length
  // Visa: 13, 16, or 19 digits starting with 4
  // Mastercard: 16 digits starting with 51-55 or 2221-2720
  // AmEx: 15 digits starting with 34 or 37
  const isVisa = cleaned.length >= 13 && cleaned.length <= 19 && cleaned.startsWith('4');
  const isMastercard = cleaned.length === 16 && (
    (cleaned.startsWith('51') || cleaned.startsWith('52') || cleaned.startsWith('53') || 
     cleaned.startsWith('54') || cleaned.startsWith('55')) ||
    (cleaned.startsWith('2221') || cleaned.startsWith('2222') || cleaned.startsWith('2223') ||
     cleaned.startsWith('2224') || cleaned.startsWith('2225') || cleaned.startsWith('2226') ||
     cleaned.startsWith('2227') || cleaned.startsWith('2228') || cleaned.startsWith('2229') ||
     cleaned.startsWith('223') || cleaned.startsWith('224') || cleaned.startsWith('225') ||
     cleaned.startsWith('226') || cleaned.startsWith('227') || cleaned.startsWith('228') ||
     cleaned.startsWith('229') || cleaned.startsWith('23') || cleaned.startsWith('24') ||
     cleaned.startsWith('25') || cleaned.startsWith('26') || cleaned.startsWith('270') ||
     cleaned.startsWith('271') || cleaned.startsWith('272'))
  );
  const isAmEx = cleaned.length === 15 && (cleaned.startsWith('34') || cleaned.startsWith('37'));
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

// Luhn checksum helper function
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
