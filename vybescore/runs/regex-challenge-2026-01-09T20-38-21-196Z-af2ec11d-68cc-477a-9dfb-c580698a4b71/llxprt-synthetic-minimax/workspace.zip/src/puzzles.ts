/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Create pattern to match words starting with prefix
  // Word boundaries to ensure we match whole words only
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const filtered = matches.filter(match => {
    const cleanMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === cleanMatch
    );
  });
  
  // Remove duplicates while preserving order
  const unique = filtered.filter((match, index, self) => 
    self.indexOf(match) === index
  );
  
  return unique;
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Returns the token preceded by its digit (e.g., '1foo' for token 'foo' after digit '1').
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  const matches: string[] = [];
  
  // Find all occurrences of the token
  let index = 0;
  while (index < text.length) {
    const position = text.indexOf(token, index);
    if (position === -1) break;
    
    // Check if token is preceded by a digit and not at the beginning
    if (position > 0 && /\d/.test(text[position - 1])) {
      matches.push(text[position - 1] + token);
    }
    
    index = position + 1;
  }
  
  // Remove duplicates
  const unique = matches.filter((match, index, self) => 
    self.indexOf(match) === index
  );
  
  return unique;
}



/**
 * Validates passwords according to security policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab", "1212", "xyzxyz"
  // Pattern to match repeated 2+ character sequences
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 * Returns true if IPv6 address is found, false for IPv4 or no IP address.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // First, check if there's an IPv4 pattern - if so, return false
  const ipv4Pattern = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns:
  // 1. Standard IPv6 (8 groups of 4 hex digits): 2001:0db8:0000:0000:0000:ff00:0042:7879
  const standardPattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // 2. IPv6 with :: shorthand (at least one group): 2001:db8::8a2e:370:7334
  const shorthandPattern = /\b(?:[0-9a-fA-F]{1,4}:){0,7}:(?:[0-9a-fA-F]{1,4})?\b/;
  
  // 3. IPv6 ending with :: (multiple groups): 2001:db8:: 
  const endingShorthandPattern = /\b(?:[0-9a-fA-F]{1,4}:){0,6}:$/;
  
  // 4. IPv6 starting with :: (multiple groups): ::8a2e:370:7334
  const startingShorthandPattern = /^:\b(?:[0-9a-fA-F]{1,4}:){1,7}/;
  
  // 5. IPv6 consisting only of :: (loopback or unspecified)
  const onlyShorthandPattern = /^::$/;
  
  // Check all patterns
  const hasStandardIPv6 = standardPattern.test(value);
  const hasShorthandIPv6 = shorthandPattern.test(value) && 
    // Make sure it's actually IPv6 by checking for colons and hex digits
    value.includes(':') && /[0-9a-fA-F]/.test(value);
  const hasEndingIPv6 = endingShorthandPattern.test(value);
  const hasStartingIPv6 = startingShorthandPattern.test(value);
  const hasOnlyShorthand = onlyShorthandPattern.test(value);
  
  // Also check for IPv6 in URLs or contexts
  const urlIPv6Pattern = /\[[0-9a-fA-F:]+\]/;
  const hasUrlIPv6 = urlIPv6Pattern.test(value);
  
  return hasStandardIPv6 || hasShorthandIPv6 || hasEndingIPv6 || 
         hasStartingIPv6 || hasOnlyShorthand || hasUrlIPv6;
}
