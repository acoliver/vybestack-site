/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Insert exactly one space between sentences, collapse extra spaces, leave abbreviations intact.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // Normalize spacing - replace multiple spaces with single space
  const normalized = text.replace(/[ \t]+/g, ' ').trim();
  
  // Simple approach: capitalize first letter, then after punctuation
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    
    if (capitalizeNext && /[a-z]/.test(char)) {
      result += char.toUpperCase();
      capitalizeNext = false;
    } else {
      result += char;
    }
    
    // Capitalize next letter after sentence ending punctuation followed by space
    if (/[.!?]/.test(char)) {
      // Check if next non-space character exists
      let nextIndex = i + 1;
      while (nextIndex < normalized.length && /\s/.test(normalized[nextIndex])) {
        nextIndex++;
      }
      if (nextIndex < normalized.length) {
        capitalizeNext = true;
      }
    }
  }
  
  return result;
}

/**
 * Finds all URLs in the text and returns them without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  // Pattern to match URLs with and without schemes
  // Matches http://, https://, ftp://, etc. and bare domain names
  const urlPattern = /(?:https?|ftp|file):\/\/[^\s<>"']+|(?:www\.)?[a-zA-Z0-9][a-zA-Z0-9-]*\.[a-zA-Z]{2,}(?:\/[^\s<>"']*)?/g;
  
  const matches = text.match(urlPattern);
  if (!matches) {
    return [];
  }
  
  // Clean each URL by removing trailing punctuation
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    const cleanUrl = url.replace(/[.,;:!?]+$/, '');
    
    // If it's a bare domain without scheme, don't add scheme
    // URLs starting with www. are left as-is
    if (cleanUrl.match(/^www\./i)) {
      return cleanUrl;
    }
    
    return cleanUrl;
  });
  
  // Remove duplicates while preserving order
  const uniqueUrls = cleanUrls.filter((url, index, self) => 
    self.indexOf(url) === index
  );
  
  return uniqueUrls;
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 * Replaces http:// schemes with https:// while preserving the rest of the URL.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Replace http:// with https:// but only when not already https://
  // This pattern specifically matches http:// that's not part of https://
  return text.replace(/https?:\/\//gi, (match) => {
    if (match.toLowerCase() === 'http://') {
      return 'https://';
    }
    return match; // Already https://, keep as is
  });
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to docs.example.com where applicable.
 * Always upgrades scheme to https://. When path begins with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite for dynamic paths with query strings or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // Pattern to match http URLs and capture parts
  const httpUrlPattern = /http:\/\/([^/\s]+)([^\s]*)/gi;
  
  return text.replace(httpUrlPattern, (match, host, path) => {
    // Always upgrade to https://
    let newUrl = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(\?|=|&|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
    
    // Check if path begins with /docs/
    const isDocsPath = /^\/docs\//i.test(path);
    
    if (isDocsPath && !hasDynamicHints) {
      // Rewrite host to docs.domain.com, preserving original domain
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        const domain = domainParts[domainParts.length - 2]; // Get main domain
        newUrl += 'docs.' + domain + '.com' + path;
      } else {
        newUrl += host + path;
      }
    } else {
      // Keep original host, just upgrade scheme
      newUrl += host + path;
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }
  
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic validation for days per month (not checking leap years for simplicity)
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  // Return the year as string
  return match[3];
}
