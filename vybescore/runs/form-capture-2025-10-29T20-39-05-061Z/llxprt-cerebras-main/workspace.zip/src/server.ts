import express, { Request, Response, Application } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';
import { Server } from 'http';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
export const app: Application = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname, '../public')));
app.use(express.urlencoded({ extended: true }));

// Database setup
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');
let db: Database | null = null;

async function initDB() {
  const SQL = await initSqlJs();
  let dbData: Uint8Array | null = null;
  
  try {
    dbData = fs.readFileSync(DB_PATH);
  } catch (err) {
    // If file doesn't exist, we'll create a new database
  }
  
  if (dbData) {
    db = new SQL.Database(dbData);
  } else {
    db = new SQL.Database();
    // Create table if it doesn't exist
    db.run(`
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  // Simple email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow international formats with digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings with possible spaces and dashes
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Helper function to check if a string is empty or just whitespace
function isEmpty(str: string): boolean {
  return !str || str.trim() === '';
}

// Routes
// GET / - Renders the contact form
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    formData: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    } 
  });
});

// POST /submit - Handles form submission
app.post('/submit', (req: Request, res: Response) => {
  const formData = {
    firstName: (req.body.firstName || '').trim(),
    lastName: (req.body.lastName || '').trim(),
    streetAddress: (req.body.streetAddress || '').trim(),
    city: (req.body.city || '').trim(),
    stateProvince: (req.body.stateProvince || '').trim(),
    postalCode: (req.body.postalCode || '').trim(),
    country: (req.body.country || '').trim(),
    email: (req.body.email || '').trim(),
    phone: (req.body.phone || '').trim()
  };

  // Validation
  const errors: { [key: string]: string } = {};
  
  if (isEmpty(formData.firstName)) errors.firstName = 'First name is required';
  if (isEmpty(formData.lastName)) errors.lastName = 'Last name is required';
  if (isEmpty(formData.streetAddress)) errors.streetAddress = 'Street address is required';
  if (isEmpty(formData.city)) errors.city = 'City is required';
  if (isEmpty(formData.stateProvince)) errors.stateProvince = 'State/Province is required';
  if (isEmpty(formData.postalCode)) errors.postalCode = 'Postal code is required';
  if (isEmpty(formData.country)) errors.country = 'Country is required';
  if (isEmpty(formData.email)) {
    errors.email = 'Email is required';
  } else if (!validateEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }
  if (isEmpty(formData.phone)) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(formData.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  // Validate postal code separately
  if (!isEmpty(formData.postalCode) && !validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  // If there are validation errors, re-render the form with errors and data
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, formData });
  }

  // Insert into database
  if (!db) {
    return res.status(500).send('Database not initialized');
  }
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
  stmt.free();
  
  // Write database back to file
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);

  // Redirect to thank-you page
  res.redirect(302, '/thank-you');
});

// GET /thank-you - Renders the thank-you page
app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
let server: Server | null = null;
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  
  if (db) {
    // Write database back to file before closing
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
    db.close();
    console.log('Database closed');
  }
  
  process.exit(0);
});

// Start server conditionally - only if not imported by tests
if (process.env.NODE_ENV !== 'test') {
  initDB().then(() => {
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  }).catch(err => {
    console.error('Failed to initialize database:', err);
    process.exit(1);
  });
}