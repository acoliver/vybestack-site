/**
 * Encode plain text to Base64.
 * Uses standard Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 */
export function decode(input: string): string {
  // Validate Base64 format
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Validates if a string is valid Base64.
 */
function isValidBase64(input: string): boolean {
  // Check for only Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }

  // Check for correct padding
  const padLength = input.length % 4;
  if (padLength === 1) {
    return false; // Invalid padding
  }

  // If there's padding, it must be at the end
  if (input.includes('=')) {
    const paddingIndex = input.indexOf('=');
    if (paddingIndex !== input.length - input.slice(paddingIndex).length) {
      return false;
    }
  }

  return true;
}
