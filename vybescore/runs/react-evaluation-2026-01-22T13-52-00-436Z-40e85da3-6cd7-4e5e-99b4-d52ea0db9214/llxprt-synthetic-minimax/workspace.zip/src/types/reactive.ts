/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string
}

export interface Observer<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export interface Subject<T> {
  value: T
  listeners?: Set<Observer<unknown>>
}

// Global state for dependency tracking
let activeObserver: Observer<unknown> | undefined
let updatingInProgress = false

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function isUpdating(): boolean {
  return updatingInProgress
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  const wasUpdating = updatingInProgress
  
  updatingInProgress = true
  activeObserver = observer as Observer<unknown>
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    updatingInProgress = wasUpdating
  }
}

// Subject change notification
export function notifySubjectChange<T>(subject: Subject<T>): void {
  const listeners = subject.listeners
  if (listeners && listeners.size > 0 && !updatingInProgress) {
    // Create a copy to avoid modification during iteration
    const listenersCopy = new Set(listeners)
    listenersCopy.forEach(listener => {
      // Use proper type assertion for observer
      updateObserver(listener as Observer<unknown>)
    })
  }
}

// Register listener to subject
export function registerListener<T>(subject: Subject<T>, observer: Observer<T>): void {
  if (!subject.listeners) {
    subject.listeners = new Set()
  }
  subject.listeners.add(observer as unknown as Observer<unknown>)
}
