/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Subject
} from '../types/reactive.ts'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  _value?: T,
  _options?: { name?: string }
): GetterFn<T> {
  // Initialize computed value immediately
  // If no initial value is provided, call updateFn without arguments 
  // to use the default parameter in the update function
  const initialComputedValue = _value === undefined ? updateFn() : updateFn(_value)
  
  // Create subject to track dependencies and cached value
  const subject: Subject<T> = {
    value: initialComputedValue,
    listeners: new Set(),
  }

  const computedGetter: GetterFn<T> = () => {
    // Always recompute when called, using current cached value
    // This ensures default parameters work correctly
    const newValue = _value === undefined ? updateFn() : updateFn(subject.value)
    subject.value = newValue
    
    return subject.value
  }

  return computedGetter
}
