/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifySubjectChange,
  registerListener,
  EqualFn,
  GetterFn,
  SetterFn
} from '../types/reactive.ts'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): InputPair<T> {
  const subject = {
    value,
    listeners: new Set(),
  } as Subject<T>

  // Store equality function for later use
  const equalFn = typeof _equal === 'function' ? _equal : undefined

  const read: GetterFn<T> = () => {
    // Register as listener when accessed during dependency tracking
    const observer = getActiveObserver()
    if (observer) {
      registerListener(subject, observer)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue: T) => {
    // Check if value actually changed (use equality function if provided)
    const valueChanged = !equalFn || !equalFn(subject.value, nextValue)
    
    if (valueChanged) {
      subject.value = nextValue
      // Notify all listeners that depend on this input
      notifySubjectChange(subject as Subject<T>)
    }
    
    return subject.value
  }

  return [read, write]
}
