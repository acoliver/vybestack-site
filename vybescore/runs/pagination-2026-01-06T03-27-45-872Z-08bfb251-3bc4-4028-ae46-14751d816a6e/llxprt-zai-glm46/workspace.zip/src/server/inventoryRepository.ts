import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

function validatePaginationParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): { page: number; limit: number } {
  let page: number;
  let limit: number;

  if (pageParam !== undefined) {
    const parsedPage = Number(pageParam);
    if (isNaN(parsedPage)) {
      throw new ValidationError('Invalid page parameter: must be a number');
    }
    if (parsedPage <= 0) {
      throw new ValidationError('Invalid page parameter: must be greater than 0');
    }
    if (!Number.isInteger(parsedPage)) {
      throw new ValidationError('Invalid page parameter: must be an integer');
    }
    page = Math.floor(parsedPage);
  } else {
    page = 1;
  }

  if (limitParam !== undefined) {
    const parsedLimit = Number(limitParam);
    if (isNaN(parsedLimit)) {
      throw new ValidationError('Invalid limit parameter: must be a number');
    }
    if (parsedLimit <= 0) {
      throw new ValidationError('Invalid limit parameter: must be greater than 0');
    }
    if (!Number.isInteger(parsedLimit)) {
      throw new ValidationError('Invalid limit parameter: must be an integer');
    }
    if (parsedLimit > MAX_LIMIT) {
      throw new ValidationError(`Invalid limit parameter: must not exceed ${MAX_LIMIT}`);
    }
    limit = Math.floor(parsedLimit);
  } else {
    limit = DEFAULT_LIMIT;
  }

  return { page, limit };
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { pageParam?: string; limitParam?: string }
): InventoryPage {
  const { page, limit } = validatePaginationParams(options.pageParam, options.limitParam);

  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
