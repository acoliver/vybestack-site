export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) return false;
  
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) return false;
  
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (localPart.includes('..')) return false;
  
  if (domain.includes('_')) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  if (domain.includes('..')) return false;
  
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;
  
  const tld = domainParts[domainParts.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) return false;
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  if (!options) {
    options = {};
  }
  
  const cleanNumber = value.replace(/[\s\-()]/g, '');
  
  const withCountryCode = /^(\+?1)?(\d{10})$/;
  if (!withCountryCode.test(cleanNumber)) return false;
  
  const tenDigitNumber = cleanNumber.replace(/^\+?1/, '');
  
  const areaCode = tenDigitNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers covering both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const cleanNumber = value.replace(/[\s\-()]/g, '');
  
  const argentinePhoneRegex = /^(?:(?:\+54)|0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleanNumber)) return false;
  
  const match = cleanNumber.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  if (!cleanNumber.startsWith('+54') && !cleanNumber.startsWith('0')) return false;
  
  return true;
}

/**
 * Validates names allowing Unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}\s'-]*[\p{L}\p{M}]$/u;
  
  if (!nameRegex.test(value)) return false;
  
  if (/\d/.test(value)) return false;
  
  const suspiciousChars = /[^\p{L}\p{M}\s'-]/u;
  if (suspiciousChars.test(value)) return false;
  
  const validWords = value.trim().split(/[\s'-]+/);
  
  for (const word of validWords) {
    if (!/^[\p{L}\p{M}]+(?:['-][\p{L}\p{M}]+)*$/u.test(word)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates credit card numbers for major brands using Luhn checksum.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const cleanNumber = value.replace(/[\s\-()]/g, '');
  
  if (!/^\d{13,19}$/.test(cleanNumber)) return false;
  
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleanNumber) && !mastercardRegex.test(cleanNumber) && !amexRegex.test(cleanNumber)) {
    return false;
  }
  
  return runLuhnCheck(cleanNumber);
}

function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}