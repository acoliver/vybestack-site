/**
 * Finds words starting with the given prefix but excluding the listed exceptions.
 * Uses word boundaries to ensure complete word matching.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!prefix || typeof prefix !== 'string') return [];
  
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}[\\w]*\\b`, 'gi');
  const matches = text.match(wordRegex) || [];
  
  return [...new Set(matches)]
    .filter(word => !exceptionSet.has(word.toLowerCase()))
    .sort();
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds to ensure proper positioning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!token || typeof token !== 'string') return [];
  
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  
  return [...new Set(matches)];
}

/**
 * Validates password strength according to comprehensive security rules.
 * Requires at least 10 characters with uppercase, lowercase, digit, and symbol.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  if (value.length < 10) return false;
  
  if (/\s/.test(value)) return false;
  
  if (!/[a-z]/.test(value)) return false;
  
  if (!/[A-Z]/.test(value)) return false;
  
  if (!/\d/.test(value)) return false;
  
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value)) return false;
  
  for (let i = 0; i < value.length - 3; i++) {
    const pattern = value.substring(i, i + 4);
    if (pattern[0] === pattern[2] && pattern[1] === pattern[3]) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses including shorthand notation.
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    const cleanedValue = value.replace(ipv4Regex, '').trim();
    if (!cleanedValue) return false;
  }
  
  const ipv6Regex = /(?:^|[^0-9A-Fa-f:])(?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}(?:$|[^0-9A-Fa-f:])|(?:(?:[0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})?::(?:(?:[0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})?/;
  
  return ipv6Regex.test(value);
}