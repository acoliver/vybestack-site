/**
 * Capitalizes the first character of each sentence while preserving spacing rules.
 * After .?!, inserts exactly one space between sentences and collapses extra spaces sensibly.
 * Tries to leave abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  let result = text.trim();
  
  result = result.replace(/\s+/g, ' ');
  
  result = result.replace(/([.!?])\s*([A-Z])/g, '$1 $2');
  
  const commonAbbreviations = /\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Ave|Blvd|Rd|etc|e\.g|i\.e|vs|approx|no|vol|fig|tab|app|sec)\.?\s*[a-z]/gi;
  
  if (!commonAbbreviations.test(result)) {
    result = result.toLowerCase();
    result = result.replace(/(^[a-z])|([.!?]\s+[a-z])/g, (match) => match.toUpperCase());
    result = result.charAt(0).toUpperCase() + result.slice(1);
  } else {
    result = result.replace(/(^|[.!?]\s+)([a-z])/g, (_, separator, letter) => 
      separator + letter.toUpperCase()
    );
  }
  
  return result;
}

/**
 * Extracts all URLs from the given text, removing trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => url.replace(/[.,!?;:)\]}]+$/, ''));
}

/**
 * Enforces HTTPS scheme by converting HTTP URLs to HTTPS.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * - Always upgrades scheme to HTTPS
 * - Rewrites host for /docs/ paths unless dynamic hints are present
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  const dynamicHints = /\?|&|=|cgi-bin|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/;
  
  return text.replace(/https?:\/\/([^/]+)(\/[^ \n]*)?/g, (match, host, path = '') => {
    const upgradedScheme = 'https://';
    const fullPath = path;
    
    if (fullPath.startsWith('/docs/') && !dynamicHints.test(fullPath)) {
      return `${upgradedScheme}docs.${host}${fullPath}`;
    }
    
    return `${upgradedScheme}${host}${fullPath}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format, returning 'N/A' for invalid dates.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  if (month === 2 && isLeapYear(year)) {
    if (day > 29) return 'N/A';
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}