import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
// @ts-expect-error - sql.js doesn't have TypeScript definitions
import initSqlJs, { Database } from 'sql.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormCaptureApp {
  private app: express.Application;
  private db: Database | null = null;
  private readonly dbPath: string;
  private readonly schemaPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    this.schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      const SQL = await initSqlJs();
      
      // Load existing database or create new one
      let dbData: Uint8Array | null = null;
      if (fs.existsSync(this.dbPath)) {
        dbData = fs.readFileSync(this.dbPath);
      }

      this.db = new SQL.Database(dbData);

      // Initialize schema if needed
      const schema = fs.readFileSync(this.schemaPath, 'utf8');
      this.db.run(schema);

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (this.db) {
      try {
        const data = this.db.export();
        fs.writeFileSync(this.dbPath, Buffer.from(data));
      } catch (error) {
        console.error('Failed to save database:', error);
      }
    }
  }

  private validateForm(formData: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    if (!formData.firstName.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }

    if (!formData.lastName.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }

    if (!formData.streetAddress.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }

    if (!formData.city.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }

    if (!formData.stateProvince.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }

    if (!formData.postalCode.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    }

    if (!formData.country.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }

    if (!formData.email.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    } else {
      // Email validation (simple regex)
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        errors.push({ field: 'email', message: 'Please enter a valid email address' });
      }
    }

    if (!formData.phone.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    } else {
      // Phone validation (international formats)
      const phoneRegex = /^\+?[\d\s\-()]+$/;
      if (!phoneRegex.test(formData.phone)) {
        errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
      }
    }

    // Postal code validation (alphanumeric)
  if (formData.postalCode.trim()) {
      const postalRegex = /^[\dA-Za-z\s-]+$/;
      if (!postalRegex.test(formData.postalCode)) {
        errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, spaces, and dashes' });
      }
    }

    return errors;
  }

  private setupRoutes(): void {
    // GET / - Render form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {},
        title: 'Friendly Contact Form'
      });
    });

    // POST /submit - Handle form submission
    this.app.post('/submit', (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateForm(formData);

      if (errors.length > 0) {
        // Validation failed, re-render form with errors
        const errorMessages = errors.map(error => error.message);
        res.status(400).render('form', {
          errors: errorMessages,
          values: formData,
          title: 'Friendly Contact Form - Errors'
        });
        return;
      }

      // Validation passed, save to database
      try {
        if (this.db) {
          const stmt = this.db.prepare(`
            INSERT INTO submissions (
              first_name, last_name, street_address, city, 
              state_province, postal_code, country, email, phone
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);

          stmt.run([
            formData.firstName,
            formData.lastName,
            formData.streetAddress,
            formData.city,
            formData.stateProvince,
            formData.postalCode,
            formData.country,
            formData.email,
            formData.phone
          ]);

          stmt.free();
          this.saveDatabase();
        }

        // Redirect to thank you page
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Database error:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: formData,
          title: 'Friendly Contact Form - Error'
        });
      }
    });

    // GET /thank-you - Thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      // For a simple implementation, we'll just use a generic greeting
      // In a more sophisticated app, we might pass the first name from a session
      res.render('thank-you', {
        firstName: 'friend',
        title: 'Thank You!'
      });
    });

    // Error handling middleware
    this.app.use((err: Error, req: Request, res: Response) => {
      console.error('Unhandled error:', err);
      res.status(500).render('form', {
        errors: ['An unexpected error occurred. Please try again.'],
        values: {},
        title: 'Friendly Contact Form - Error'
      });
    });
  }

  public async start(port: number = 3535): Promise<void> {
    try {
      await this.initializeDatabase();
      
      const server = this.app.listen(port, () => {
        console.log(`Server running on port ${port}`);
      });

      // Graceful shutdown
      const shutdown = () => {
        console.log('Shutting down gracefully...');
        server.close(() => {
          if (this.db) {
            this.db.close();
          }
          process.exit(0);
        });
      };

      process.on('SIGTERM', shutdown);
      process.on('SIGINT', shutdown);

    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }
}

// Start the server
const app = new FormCaptureApp();
const port = parseInt(process.env.PORT || '3535', 10);
app.start(port);
