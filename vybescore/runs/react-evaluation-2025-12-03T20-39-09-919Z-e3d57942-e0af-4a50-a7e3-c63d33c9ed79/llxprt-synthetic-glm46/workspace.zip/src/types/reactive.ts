/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  _observers?: Set<Observer<any>>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const batchedUpdates: Array<() => void> = []
let isBatching = false
let updateDepth = 0
const maxUpdateDepth = 50

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): ObserverR | undefined {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

export function updateObserver<T>(observer: Observer<T>): void {
  updateDepth++
  
  // Prevent infinite recursion
  if (updateDepth > maxUpdateDepth) {
    console.warn('Maximum update depth exceeded')
    updateDepth--
    return
  }

  if (isBatching) {
    // Batch updates to prevent infinite recursion
    batchedUpdates.push(() => {
      const previous = activeObserver
      activeObserver = observer
      try {
        observer.value = observer.updateFn(observer.value)
        
        // Notify dependents
        notifyObservers(observer)
      } finally {
        activeObserver = previous
        updateDepth--
      }
    })
  } else {
    const previous = activeObserver
    activeObserver = observer
    try {
      observer.value = observer.updateFn(observer.value)
      
      // Notify dependents
      notifyObservers(observer)
    } finally {
      activeObserver = previous
      updateDepth--
    }
  }
}

export function batchUpdate(updateFn: () => void): void {
  isBatching = true
  try {
    updateFn()
    
    // Process all batched updates
    while (batchedUpdates.length > 0) {
      const update = batchedUpdates.shift()!
      update()
    }
  } finally {
    isBatching = false
  }
}

export function registerObserver<T>(subject: ObserverR, observer: ObserverR | Observer<T>): void {
  if (!subject._observers) {
    subject._observers = new Set()
  }
  subject._observers.add(observer as Observer<any>)
}

export function notifyObservers<T>(observer: Observer<T>): void {
  if (observer._observers && observer._observers.size > 0) {
    // Create a copy to avoid issues with modification during iteration
    const observers = Array.from(observer._observers)
    for (const dependent of observers) {
      updateObserver(dependent)
    }
  }
}
