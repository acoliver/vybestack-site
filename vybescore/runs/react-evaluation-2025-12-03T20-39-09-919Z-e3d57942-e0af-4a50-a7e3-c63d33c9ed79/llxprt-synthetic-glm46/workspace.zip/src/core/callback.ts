/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Track dependencies by setting this as active observer
  const previousObserver = setActiveObserver(observer)
  
  try {
    // Execute the update function to track dependencies
    observer.value = updateFn(value)
  } finally {
    // Restore previous observer
    setActiveObserver(previousObserver)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates and prevent memory leaks
    observer.value = undefined
    observer.updateFn = () => value!
    
    // Remove this observer from all subjects it's observing
    if (observer._observers) {
      for (const subject of observer._observers) {
        if (subject._observers) {
          subject._observers.delete(observer)
        }
      }
      observer._observers.clear()
    }
  }
}
