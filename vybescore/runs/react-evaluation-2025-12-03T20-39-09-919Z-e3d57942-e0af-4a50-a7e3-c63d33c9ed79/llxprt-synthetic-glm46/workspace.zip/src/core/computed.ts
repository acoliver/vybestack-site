/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  registerObserver,
  EqualFn,
  getActiveObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? Object.is : 
    equal === false ? undefined : 
    equal;

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      registerObserver(o, observer)
    }
    
    const currentValue = o.value
    const newValue = updateFn(value)
    
    const shouldUpdate = !equalFn || !equalFn(currentValue || value!, newValue)
    if (shouldUpdate) {
      o.value = newValue
      notifyObservers(o)
    }
    
    return o.value!
  }

  return getter
}
