#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import type { ReportData, ReportOptions } from '../types.js';
import { formatters } from '../formats/index.js';

interface CliArgs {
  filePath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const filePath = args[2];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++;
    } else if (args[i] === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++;
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return {
    filePath,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  for (const entry of reportData.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid report data: entry must be an object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid report data: entry missing or invalid "label" field');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid report data: entry missing or invalid "amount" field');
    }
  }

  return data as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const resolvedPath = path.resolve(filePath);
    const fileContent = fs.readFileSync(resolvedPath, 'utf8');
    const jsonData = JSON.parse(fileContent);
    return validateReportData(jsonData);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON file: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function main() {
  try {
    const args = parseArguments(process.argv);
    const data = loadReportData(args.filePath);

    if (!(args.format in formatters)) {
      console.error(`Error: Unsupported format "${args.format}"`);
      process.exit(1);
    }

    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };

    const renderer = formatters[args.format];
    const output = renderer(data, options);

    if (args.outputPath) {
      const resolvedPath = path.resolve(args.outputPath);
      fs.writeFileSync(resolvedPath, output, 'utf8');
      console.log(`Report written to ${resolvedPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();