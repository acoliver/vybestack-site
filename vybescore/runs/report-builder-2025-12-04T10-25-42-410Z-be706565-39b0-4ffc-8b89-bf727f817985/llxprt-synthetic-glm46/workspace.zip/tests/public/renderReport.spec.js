import { describe, expect, it } from 'vitest';
describe('report CLI (public smoke)', () => {
    it('placeholder test (implementations should add real coverage)', () => {
        expect(true).toBe(true);
    });
});
//# sourceMappingURL=renderReport.spec.js.map