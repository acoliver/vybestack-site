import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const goToPreviousPage = () => {
    setCurrentPage((prev) => Math.max(1, prev - 1));
  };

  const goToNextPage = () => {
    if (data?.hasNext) {
      setCurrentPage((prev) => prev + 1);
    }
  };

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error') {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  if (!data) {
    return <p>No inventory data available.</p>;
  }

  const hasPreviousPage = currentPage > 1;
  const hasNextPage = data.hasNext;

  return (
    <section>
      <h1>Inventory</h1>
      
      {data.items.length === 0 ? (
        <p>No items found for this page.</p>
      ) : (
        <>
          <InventoryList items={data.items} />
          
          <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
            <button
              onClick={goToPreviousPage}
              disabled={!hasPreviousPage}
              aria-disabled={!hasPreviousPage}
              style={{
                opacity: hasPreviousPage ? 1 : 0.5,
                cursor: hasPreviousPage ? 'pointer' : 'not-allowed'
              }}
            >
              Previous
            </button>
            
            <span style={{ margin: '0 0.5rem' }}>
              Page {data.page} of {Math.ceil(data.total / data.limit)} (Total: {data.total} items)
            </span>
            
            <button
              onClick={goToNextPage}
              disabled={!hasNextPage}
              aria-disabled={!hasNextPage}
              style={{
                opacity: hasNextPage ? 1 : 0.5,
                cursor: hasNextPage ? 'pointer' : 'not-allowed'
              }}
            >
              Next
            </button>
          </div>
        </>
      )}
    </section>
  );
}
