import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  
  let dbInstance: Database;
  
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }
  
  return dbInstance;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, buffer);
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];
  
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];
  
  for (const field of requiredFields) {
    const value = data[field]?.trim() ?? '';
    if (!value) {
      errors.push({ field, message: `${field.replace(/([A-Z])/g, ' $1').trim()} is required` });
    }
  }
  
  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }
  
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }
  
  return errors;
}

async function startServer(): Promise<express.Express> {
  const app = express();
  
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  
  db = await initializeDatabase();
  
  app.set('view engine', 'ejs');
  app.set('views', path.join(process.cwd(), 'src', 'templates'));
  
  app.use('/public', express.static(path.join(process.cwd(), 'public')));
  
  app.get('/', (req: Request, res: Response) => {
    res.render('form.ejs', { 
      errors: [], 
      values: {} 
    });
  });
  
  app.post('/submit', (req: Request, res: Response) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };
    
    const errors = validateFormData(formData);
    
    if (errors.length > 0) {
      res.status(400);
      res.render('form.ejs', {
        errors: errors.map(e => e.message),
        values: formData
      });
      return;
    }
    
    if (!db) {
      res.status(500);
      res.render('form.ejs', {
        errors: ['Database error. Please try again.'],
        values: formData
      });
      return;
    }
    
    try {
      db.run(
        `INSERT INTO submissions 
         (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone,
        ]
      );
      
      saveDatabase(db);
      
      res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500);
      res.render('form.ejs', {
        errors: ['Failed to save submission. Please try again.'],
        values: formData
      });
    }
  });
  
  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you.ejs', { firstName: 'Friend' });
  });
  
  return app;
}

async function closeServer(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
}

function handleShutdown(signal: string): void {
  console.log(`Received ${signal}, shutting down gracefully...`);
  closeServer().then(() => {
    process.exit(0);
  }).catch((err) => {
    console.error('Error during shutdown:', err);
    process.exit(1);
  });
}

process.on('SIGTERM', () => handleShutdown('SIGTERM'));
process.on('SIGINT', () => handleShutdown('SIGINT'));

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().then((app) => {
    const server = app.listen(PORT, () => {
      console.log(`Server listening on port ${PORT}`);
    });
    
    server.on('close', async () => {
      await closeServer();
    });
  }).catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { startServer, closeServer };
