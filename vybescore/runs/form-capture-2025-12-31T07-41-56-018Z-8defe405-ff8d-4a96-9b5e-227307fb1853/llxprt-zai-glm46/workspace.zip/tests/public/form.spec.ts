import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import type express from 'express';

let server: { close: () => void } | null = null;
let app: express.Express | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const { startServer } = await import('../../dist/server.js');
  app = await startServer();
  server = (app as express.Express).listen(0) as { close: () => void };
});

afterAll(async () => {
  if (server) {
    server.close();
  }
  const { closeServer } = await import('../../dist/server.js');
  await closeServer();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app!).get('/');
    expect(response.status).toBe(200);
    
    expect(response.text).toContain('<form');
    expect(response.text).toContain('action="/submit"');
    expect(response.text).toContain('id="firstName"');
    expect(response.text).toContain('id="lastName"');
    expect(response.text).toContain('id="streetAddress"');
    expect(response.text).toContain('id="city"');
    expect(response.text).toContain('id="stateProvince"');
    expect(response.text).toContain('id="postalCode"');
    expect(response.text).toContain('id="country"');
    expect(response.text).toContain('id="email"');
    expect(response.text).toContain('id="phone"');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.doe@example.com',
      phone: '+44 20 7946 0958',
    };
    
    const response = await request(app!)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid data', async () => {
    const response = await request(app!)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: '',
        email: 'invalid-email',
        phone: 'invalid-phone!!!',
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('error-list');
  });

  it('renders thank-you page', async () => {
    const response = await request(app!).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('thankyou-card');
  });
});
