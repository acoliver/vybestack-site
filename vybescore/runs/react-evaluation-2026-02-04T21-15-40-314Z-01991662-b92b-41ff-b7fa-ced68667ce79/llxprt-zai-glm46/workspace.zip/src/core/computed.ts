/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

function normalizeEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') return undefined
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = normalizeEqualFn(_equal)
  
  // The computed acts as both an Observer (observes dependencies) and a Subject (is observed by others)
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Subject part - allows this computed to be observed by others
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn,
  }
  
  // Wrap updateObserver to also update subject value and notify subject's observers
  const wrappedUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    const newValue = updateFn(prevValue)
    subject.value = newValue
    // Notify all observers of this computed value
    subject.observers.forEach((obs) => {
      updateObserver(obs as Observer<unknown>)
    })
    return newValue
  }
  
  observer.updateFn = wrappedUpdateFn
  
  // Initial computation to establish dependencies
  updateObserver(observer)
  
  const read: GetterFn<T> = () => {
    // When this computed is accessed, register its observer as the dependency
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      subject.observers.add(activeObserver)
    }
    return subject.value
  }
  
  return read
}
