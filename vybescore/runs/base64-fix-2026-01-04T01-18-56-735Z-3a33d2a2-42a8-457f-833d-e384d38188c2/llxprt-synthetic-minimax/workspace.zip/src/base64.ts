/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts both padded and unpadded input, rejects invalid Base64.
 */
export function decode(input: string): string {
  const normalized = input.trim();
  
  // Validate input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Add padding if missing (Base64 input should be multiple of 4)
  const missingPadding = (4 - (normalized.length % 4)) % 4;
  const paddedInput = missingPadding > 0 
    ? normalized + '='.repeat(missingPadding)
    : normalized;

  try {
    const decoded = Buffer.from(paddedInput, 'base64').toString('utf8');
    // Additional validation: check if decoded string makes sense
    // Base64 decoding should produce valid UTF-8
    if (decoded.length === 0 && normalized.length > 0) {
      throw new Error('Failed to decode Base64 input');
    }
    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
