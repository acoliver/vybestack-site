import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)

console.log('=== Creating timesTwo ===')
const timesTwo = createComputed(() => input() * 2)

console.log('=== Creating timesThirty ===')
const timesThirty = createComputed(() => input() * 30)

console.log('=== Creating sum ===')
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial state:')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())
console.log('  Expected sum: 32 (1*2 + 1*30 = 32)')

console.log('\n=== Before setInput(3) ===')
console.log('About to call setInput(3)...')
setInput(3)

console.log('\nAfter setInput(3):')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())
console.log('  Expected sum: 96 (3*2 + 3*30 = 96)')

console.log('\n=== Debugging: Calling timesTwo() again ===')
const t2 = timesTwo()
console.log('  timesTwofrom second call:', t2)
