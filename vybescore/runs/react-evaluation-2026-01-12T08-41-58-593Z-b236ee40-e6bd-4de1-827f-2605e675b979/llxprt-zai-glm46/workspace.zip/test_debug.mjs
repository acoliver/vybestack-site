import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial state:')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())
console.log('  Expected sum: 32 (1*2 + 1*30 = 32)')

setInput(3)

console.log('\nAfter setInput(3):')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())
console.log('  Expected sum: 96 (3*2 + 3*30 = 96)')
