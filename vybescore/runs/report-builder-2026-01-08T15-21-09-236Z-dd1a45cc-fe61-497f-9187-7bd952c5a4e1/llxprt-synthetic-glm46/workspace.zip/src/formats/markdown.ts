import type { ReportData, RenderOptions } from '../types.js';

export function renderMarkdown(
  data: ReportData,
  options: RenderOptions = {},
): string {
  const { includeTotals = false } = options;
  let result = '';

  // Title
  result += `# ${data.title}\n`;

  // Blank line
  result += '\n';

  // Summary
  result += `${data.summary}\n`;

  // Blank line
  result += '\n';

  // Entries heading
  result += '## Entries\n';

  // Entries list
  for (const entry of data.entries) {
    result += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  }

  // Total if requested
  if (includeTotals) {
    const total = data.entries.reduce(
      (sum, entry) => sum + entry.amount,
      0,
    );
    result += `**Total:** $${total.toFixed(2)}\n`;
  }

  return result;
}