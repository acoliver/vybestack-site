#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import type { ReportData, Format } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length < 2) {
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]',
    );
    process.exit(1);
  }

  const result = {
    dataFile: '',
    format: 'markdown' as Format,
    outputPath: undefined as string | undefined,
    includeTotals: false,
  };

  // First argument should be the data file
  result.dataFile = args[0];

  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        result.format = args[++i] as Format;
        if (!['markdown', 'text'].includes(result.format)) {
          console.error(`Unsupported format: ${result.format}`);
          process.exit(1);
        }
        break;
      case '--output':
        result.outputPath = args[++i];
        break;
      case '--includeTotals':
        result.includeTotals = true;
        break;
      default:
        console.error(`Unknown argument: ${args[i]}`);
        process.exit(1);
    }
  }

  return result;
}

function validateReportData(data: unknown): data is ReportData {
  if (
    typeof data !== 'object' ||
    data === null ||
    !('title' in data) ||
    !('summary' in data) ||
    !('entries' in data)
  ) {
    return false;
  }

  const { title, summary, entries } = data as Record<string, unknown>;

  if (typeof title !== 'string' || typeof summary !== 'string') {
    return false;
  }

  if (!Array.isArray(entries)) {
    return false;
  }

  for (const entry of entries) {
    if (
      typeof entry !== 'object' ||
      entry === null ||
      !('label' in entry) ||
      !('amount' in entry)
    ) {
      return false;
    }

    const { label, amount } = entry as Record<string, unknown>;

    if (typeof label !== 'string' || typeof amount !== 'number') {
      return false;
    }
  }

  return true;
}

function renderReport(data: ReportData, format: Format, includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, { includeTotals });
    case 'text':
      return renderText(data, { includeTotals });
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = parseArguments();

    // Read and parse the JSON file
    const dataPath = resolve(args.dataFile);
    const jsonData = readFileSync(dataPath, 'utf8');
    let data: unknown;

    try {
      data = JSON.parse(jsonData);
    } catch (error) {
      console.error(`Error parsing JSON file: ${(error as Error).message}`);
      process.exit(1);
    }

    // Validate the data structure
    if (!validateReportData(data)) {
      console.error('Invalid report data structure. Expected format:');
      console.error(
        '{\n  "title": "string",\n  "summary": "string",\n  "entries": [\n    { "label": "string", "amount": number }\n  ]\n}',
      );
      process.exit(1);
    }

    // Render the report
    const output = renderReport(data, args.format, args.includeTotals);

    // Write to stdout or file
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output);
        console.log(`Report generated at ${args.outputPath}`);
      } catch (error) {
        console.error(`Error writing to file: ${(error as Error).message}`);
        process.exit(1);
      }
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
