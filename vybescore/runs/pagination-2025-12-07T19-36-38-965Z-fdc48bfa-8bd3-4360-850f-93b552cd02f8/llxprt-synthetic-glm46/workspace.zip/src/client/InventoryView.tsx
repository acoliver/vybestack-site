import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

interface PaginationControlsProps {
  currentPage: number;
  hasNext: boolean;
  onPageChange: (page: number) => void;
}

function PaginationControls({ currentPage, hasNext, onPageChange }: PaginationControlsProps): JSX.Element {
  return (
    <div>
      <button 
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage <= 1}
      >
        Previous
      </button>
      <span> Page {currentPage} </span>
      <button 
        onClick={() => onPageChange(currentPage + 1)}
        disabled={!hasNext}
      >
        Next
      </button>
    </div>
  );
}

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <div>
        Total items: {data.total}
      </div>
      {data.items.length > 0 ? (
        <>
          <InventoryList items={data.items} />
          <PaginationControls 
            currentPage={currentPage}
            hasNext={data.hasNext}
            onPageChange={setCurrentPage}
          />
        </>
      ) : (
        <p>No inventory items found.</p>
      )}
    </section>
  );
}
