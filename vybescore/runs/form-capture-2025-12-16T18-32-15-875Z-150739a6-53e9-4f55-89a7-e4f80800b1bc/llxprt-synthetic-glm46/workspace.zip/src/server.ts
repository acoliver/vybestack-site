import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;
let db: Database | null = null;

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalRegex.test(postalCode);
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!data.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!data.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!data.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!data.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  if (!data.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Invalid postal code format' });
  }
  if (!data.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!data.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Invalid email format' });
  }
  if (!data.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Invalid phone number format' });
  }

  return errors;
}

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({ locateFile: file => `node_modules/sql.js/dist/${file}` });
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    
    let dbData: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      const dbFile = fs.readFileSync(dbPath);
      dbData = new Uint8Array(dbFile);
    }
    
    db = new SQL.Database(dbData || undefined);
    
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    if (db) {
      db.exec(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (!db) return;
  
  try {
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    const data = db.export();
    
    if (!fs.existsSync(path.dirname(dbPath))) {
      fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    }
    
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);
  
  if (errors.length > 0) {
    res.status(400).render('form', { 
      errors: errors.map(e => e.message), 
      values: formData 
    });
    return;
  }

  try {
    if (!db) throw new Error('Database not initialized');
    
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', { 
      errors: ['An unexpected error occurred. Please try again.'], 
      values: formData 
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { firstName: 'Friend' });
});

async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  const gracefulShutdown = () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
      if (db) {
        db.close();
        console.log('Database connection closed');
      }
      process.exit(0);
    });
  };

  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
