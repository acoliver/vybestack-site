/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern for words starting with the prefix
  // Using word boundaries to match whole words
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  return matches.filter(match => 
    !exceptionsLower.includes(match.toLowerCase())
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use positive lookbehind to ensure the token is preceded by a digit
  // and negative lookbehind to ensure it's not at the beginning of the string
  const pattern = new RegExp(`(?<!^)(?<=\\d)${token}`, 'gi');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^a-zA-Z0-9\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences like "abab"
  // This pattern looks for any 2-character sequence that repeats immediately
  for (let i = 0; i < value.length - 3; i++) {
    const seq = value.substring(i, i + 2);
    const nextSeq = value.substring(i + 2, i + 4);
    if (seq === nextSeq) return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns
  // Standard IPv6: 8 groups of 4 hexadecimal digits separated by colons
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with shorthand :: (can appear anywhere once)
  // This handles cases like ::1, 2001:db8::, ::ffff:192.168.1.1, etc.
  const shorthandIPv6 = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with IPv4 mapped (e.g., ::ffff:192.168.1.1)
  const ipv4Mapped = /\b::ffff:(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/;
  
  // IPv6 loopback
  const ipv6Loopback = /\b::1\b/;
  
  // IPv6 unspecified
  const ipv6Unspecified = /\b::\b/;
  
  // IPv4 address pattern (to exclude from IPv6 matching)
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/;
  
  // First check if this is a pure IPv4 address
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Check for various IPv6 patterns
  return fullIPv6.test(value) || 
         shorthandIPv6.test(value) || 
         ipv4Mapped.test(value) || 
         ipv6Loopback.test(value) || 
         ipv6Unspecified.test(value);
}