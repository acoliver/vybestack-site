/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) return text;
  
  // Pattern to find sentence boundaries (after ., ?, !)
  // This regex looks for .?! followed by optional whitespace and any character
  const sentencePattern = /([.!?])\s*([^\s])/g;
  
  return text.replace(sentencePattern, (match, punctuation, nextChar) => {
    // Capitalize the first letter after punctuation
    const capitalized = nextChar.toUpperCase();
    return punctuation + ' ' + capitalized;
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http, https, www, and domain names
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s"'\)\]\},;!?]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;:!?]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's not already https
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
  const httpUrlPattern = /http:\/\/([^\/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(httpUrlPattern, (match, host, path = '') => {
    let newUrl = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /cgi-bin|\?|&|=|(\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host to docs.host
      newUrl += 'docs.' + host;
    } else {
      // Keep original host
      newUrl += host;
    }
    
    // Add the path (including /docs/ paths)
    newUrl += path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) return 'N/A';
  
  // Basic year validation (reasonable range)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1000 || yearNum > 9999) return 'N/A';
  
  return year;
}