export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Basic structure check - must have exactly one @ and one .
  const atCount = (trimmed.match(/@/g) || []).length;
  if (atCount !== 1) return false;
  
  const parts = trimmed.split('@');
  if (parts.length !== 2) return false;
  
  const [local, domain] = parts;
  
  // Local part validation
  if (!local || local.length === 0) return false;
  if (local.startsWith('.') || local.endsWith('.')) return false;
  if (local.includes('..')) return false;
  if (local.includes('@')) return false;
  
  // Domain validation
  if (!domain || domain.length === 0) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  if (domain.includes('..')) return false;
  
  // Domain must have at least one dot and valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;
  
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) return false;
  
  // Check for underscores in domain (not allowed)
  if (domain.includes('_')) return false;
  
  // Check for valid characters in domain
  const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*$/;
  if (!domainRegex.test(domain)) return false;
  
  // Check for valid characters in local part
  const localRegex = /^[a-zA-Z0-9]([a-zA-Z0-9.+_-]*[a-zA-Z0-9])?$/;
  if (!localRegex.test(local)) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove common separators and whitespace
  const cleaned = value.replace(/[\s().-]/g, '');
  
  // Check minimum length (10 digits, or 11 with country code)
  if (cleaned.length < 10 || cleaned.length > 11) return false;
  
  // If 11 digits, first digit must be 1 (country code)
  if (cleaned.length === 11 && !cleaned.startsWith('1')) return false;
  
  // Extract the 10-digit number
  const number = cleaned.length === 11 ? cleaned.substring(1) : cleaned;
  
  // Check that all remaining characters are digits
  if (!/^\d{10}$/.test(number)) return false;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = number.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for processing
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Remove common punctuation
  const processed = cleaned.replace(/[().]/g, '');
  
  // Check for valid characters (digits, +, and optional spaces/hyphens removed)
  if (!/^\+?\d+$/.test(processed)) return false;
  
  let remaining = processed;
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  let hasMobileIndicator = false;
  let areaCode = '';
  let subscriberNumber = '';
  
  // Check for country code
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.substring(3);
  }
  
  // Check for mobile indicator (9)
  if (remaining.startsWith('9')) {
    hasMobileIndicator = true;
    remaining = remaining.substring(1);
  }
  
  // Check for trunk prefix (0)
  if (remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.substring(1);
  }
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  // Extract area code (2-4 digits, first digit 1-9)
  const areaCodeMatch = remaining.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) return false;
  
  areaCode = areaCodeMatch[1];
  remaining = remaining.substring(areaCode.length);
  
  // Remaining should be subscriber number (6-8 digits)
  if (remaining.length < 6 || remaining.length > 8) return false;
  if (!/^\d+$/.test(remaining)) return false;
  
  subscriberNumber = remaining;
  
  // Validate combinations
  // If has country code and mobile indicator, no trunk prefix should follow
  if (hasCountryCode && hasMobileIndicator && hasTrunkPrefix) return false;
  
  // If has country code but no mobile indicator, should have trunk prefix
  if (hasCountryCode && !hasMobileIndicator && !hasTrunkPrefix) return false;
  
  // If no country code, should have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  // If has mobile indicator, should be after country code or trunk prefix
  if (hasMobileIndicator && !hasCountryCode && !hasTrunkPrefix) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check if empty or too short
  if (!value || value.trim().length < 2) return false;
  
  // Reject if contains digits
  if (/\d/.test(value)) return false;
  
  // Reject special symbols except apostrophes, hyphens, and spaces
  if (/[^\p{L}\p{M}\s'\-]/u.test(value)) return false;
  
  // Reject names like "X Æ A-12" - check for mixed alphanumeric sequences
  if (/[a-zA-Z]\d|\d[a-zA-Z]/.test(value)) return false;
  
  // Must contain at least one letter
  if (!/[a-zA-Z\p{L}\p{M}]/u.test(value)) return false;
  
  // Reject if starts or ends with invalid characters
  const trimmed = value.trim();
  if (/^['\-\s]|['\-\s]$/.test(trimmed)) return false;
  
  // Allow multiple spaces between words but not at the beginning/end
  if (trimmed !== value) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digits
  const cleaned = value.replace(/\D/g, '');
  
  // Check minimum length
  if (cleaned.length < 13) return false;
  
  // Check maximum length
  if (cleaned.length > 19) return false;
  
  // Check card type prefixes and lengths
  let isValidType = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (cleaned.startsWith('4') && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19)) {
    isValidType = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if ((cleaned.startsWith('51') || cleaned.startsWith('52') || cleaned.startsWith('53') || 
            cleaned.startsWith('54') || cleaned.startsWith('55') || 
            (cleaned.startsWith('2221') && cleaned.length >= 16) ||
            (cleaned.startsWith('2720') && cleaned.length <= 16)) && cleaned.length === 16) {
    isValidType = true;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}