import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

class FormServer {
  public app: express.Application;
  private db: Database | null = null;
  private server: import('http').Server | null = null;
  private readonly dbPath: string;
  private readonly schemaPath: string;
  private isStarted: boolean = false;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve('data', 'submissions.sqlite');
    this.schemaPath = path.resolve('db', 'schema.sql');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static('public'));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const fileBuffer = fs.readFileSync(this.dbPath);
        // Convert Buffer to Uint8Array for sql.js
        const uint8Array = new Uint8Array(fileBuffer);
        this.db = new SQL.Database(uint8Array);
      } else {
        this.db = new SQL.Database();
        await this.createTables();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createTables(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const schema = fs.readFileSync(this.schemaPath, 'utf8');
    this.db.run(schema);
    await this.saveDatabase();
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  private validateForm(data: FormData): { isValid: boolean; errors: FormErrors } {
    const errors: FormErrors = {};

    // Required fields
    if (!data.firstName?.trim()) {
      errors.firstName = 'First name is required';
    }
    if (!data.lastName?.trim()) {
      errors.lastName = 'Last name is required';
    }
    if (!data.streetAddress?.trim()) {
      errors.streetAddress = 'Street address is required';
    }
    if (!data.city?.trim()) {
      errors.city = 'City is required';
    }
    if (!data.stateProvince?.trim()) {
      errors.stateProvince = 'State/Province/Region is required';
    }
    if (!data.postalCode?.trim()) {
      errors.postalCode = 'Postal/Zip code is required';
    }
    if (!data.country?.trim()) {
      errors.country = 'Country is required';
    }
    if (!data.email?.trim()) {
      errors.email = 'Email is required';
    }
    if (!data.phone?.trim()) {
      errors.phone = 'Phone number is required';
    }

    // Email validation (simple regex)
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    // Phone validation (international formats allowed)
    if (data.phone && !/^\+?[\d\s()\-]+$/.test(data.phone)) {
      errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
    }

    // Postal code validation (alphanumeric, supports formats like "SW1A 1AA", "C1000", "B1675")
    if (data.postalCode && !/^[A-Za-z0-9\s-]{1,10}$/.test(data.postalCode)) {
      errors.postalCode = 'Postal code can contain letters, digits, spaces, and dashes';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  private setupRoutes(): void {
    // GET / -Render form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // POST /submit -Process form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      try {
        const formData: FormData = {
          firstName: req.body.firstName || '',
          lastName: req.body.lastName || '',
          streetAddress: req.body.streetAddress || '',
          city: req.body.city || '',
          stateProvince: req.body.stateProvince || '',
          postalCode: req.body.postalCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };

        const validation = this.validateForm(formData);
        
        if (!validation.isValid) {
          const errorMessages = Object.entries(validation.errors).map(([, message]) => message);
          return res.status(400).render('form', {
            errors: errorMessages,
            values: formData
          });
        }

        // Insert into database
        if (!this.db) {
          throw new Error('Database not initialized');
        }

        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);

        stmt.free();
        await this.saveDatabase();

        // Redirect to thank you page
        res.redirect(302, '/thank-you');
      } catch (error) {
        console.error('Error processing submission:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while processing your submission. Please try again.'],
          values: req.body
        });
      }
    });

    // GET /thank-you -Thank you page
    this.app.get('/thank-you', async (req: Request, res: Response) => {
      try {
        // Get the most recent submission to display first name
        if (!this.db) {
          throw new Error('Database not initialized');
        }

        // Use exec() to get the most recent submission
        const results = this.db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
        const firstName = (results.length > 0 && results[0].values.length > 0) 
          ? results[0].values[0][0] as string 
          : 'Friend';
        
        res.render('thank-you', { firstName });
      } catch (error) {
        console.error('Error loading thank you page:', error);
        res.render('thank-you', { firstName: 'Friend' });
      }
    });
  }

  public async start(): Promise<void> {
    if (this.isStarted) {
      console.log('Server is already started');
      return;
    }
    
    await this.initializeDatabase();
    
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    
    return new Promise<void>((resolve) => {
      this.server = this.app.listen(port, () => {
        console.log(`Server running on port ${port}`);
        this.isStarted = true;
        
        // Graceful shutdown
        process.on('SIGTERM', () => this.gracefulShutdown());
        process.on('SIGINT', () => this.gracefulShutdown());
        
        resolve();
      });
    });
  }

  private gracefulShutdown(): void {
    console.log('Shutting down gracefully...');
    
    if (this.server) {
      this.server.close(() => {
        console.log('HTTP server closed');
        
        if (this.db) {
          this.db.close();
          console.log('Database closed');
        }
        
        process.exit(0);
      });
    } else {
      process.exit(0);
    }
  }

  public close(): void {
    if (this.server) {
      this.server.close();
    }
    if (this.db) {
      this.db.close();
    }
    this.isStarted = false;
  }
}

// Start server if this file is run directly
if (require.main === module) {
  const server = new FormServer();
  server.start().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default FormServer;