#!/usr/bin/env node

import { readFileSync } from "fs";
import { writeFile } from "fs/promises";

import type { ReportData, ReportOptions, ReportFormat, ReportRenderer } from "../types.js";
import { renderMarkdown } from "../formats/markdown.js";
import { renderText } from "../formats/text.js";

const RENDERERS: Record<ReportFormat, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArguments(): {
  inputFile: string;
  format: ReportFormat;
  outputFile?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error("Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]");
    process.exit(1);
  }
  
  const inputFile = args[0];
  
  let format: ReportFormat | undefined;
  let outputFile: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === "--format" && i + 1 < args.length) {
      const formatValue = args[i + 1];
      if (formatValue === "markdown" || formatValue === "text") {
        format = formatValue;
      } else {
        console.error(`Unsupported format: ${formatValue}`);
        process.exit(1);
      }
      i++;
    } else if (arg === "--output" && i + 1 < args.length) {
      outputFile = args[i + 1];
      i++;
    } else if (arg === "--includeTotals") {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error("Error: --format is required and must be 'markdown' or 'text'");
    process.exit(1);
  }
  
  return { inputFile, format, outputFile, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== "object") {
    throw new Error("Invalid JSON: expected an object");
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== "string") {
    throw new Error("Invalid report data: missing or invalid 'title' field (expected string)");
  }
  
  if (typeof obj.summary !== "string") {
    throw new Error("Invalid report data: missing or invalid 'summary' field (expected string)");
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error("Invalid report data: missing or invalid 'entries' field (expected array)");
  }
  
  for (const entry of obj.entries) {
    if (!entry || typeof entry !== "object") {
      throw new Error("Invalid entry: expected object");
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== "string") {
      throw new Error("Invalid entry: missing or invalid 'label' field (expected string)");
    }
    
    if (typeof entryObj.amount !== "number") {
      throw new Error("Invalid entry: missing or invalid 'amount' field (expected number)");
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const { inputFile, format, outputFile, includeTotals } = parseArguments();
    
    let fileContent: string;
    try {
      fileContent = readFileSync(inputFile, "utf-8");
    } catch (error) {
      console.error(`Error reading file ${inputFile}: ${error instanceof Error ? error.message : "Unknown error"}`);
      process.exit(1);
    }
    
    let jsonData: ReportData;
    try {
      const parsed = JSON.parse(fileContent);
      jsonData = validateReportData(parsed);
    } catch (error) {
      console.error(`Error parsing JSON data: ${error instanceof Error ? error.message : "Unknown error"}`);
      process.exit(1);
    }
    
    const options: ReportOptions = { includeTotals };
    const renderer = RENDERERS[format];
    const output = renderer.render(jsonData, options);
    
    if (outputFile) {
      writeFile(outputFile, output, "utf-8")
        .then(() => {
          console.error(`Report written to ${outputFile}`);
        })
        .catch((error) => {
          console.error(`Error writing to file ${outputFile}: ${error instanceof Error ? error.message : "Unknown error"}`);
          process.exit(1);
        });
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : "Unknown error"}`);
    process.exit(1);
  }
}

main();
