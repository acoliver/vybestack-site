/**
 * Validate whether a string contains only valid Base64 characters.
 */
function isValidBase64Characters(input: string): boolean {
  return /^[A-Za-z0-9+/]*={0,2}$/.test(input);
}

/**
 * Validate the structure of a Base64 string (only valid characters and proper padding).
 */
function validateBase64Structure(input: string): void {
  if (!isValidBase64Characters(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }
  
  // Only validate clearly invalid inputs - strings with bad padding structure
  // For valid Base64, let Buffer.from() handle the detailed validation
}

/**
 * Encode plain text to standard Base64.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Rejects invalid Base64 input by throwing an error.
 */
export function decode(input: string): string {
  validateBase64Structure(input);
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: malformed data');
  }
}
