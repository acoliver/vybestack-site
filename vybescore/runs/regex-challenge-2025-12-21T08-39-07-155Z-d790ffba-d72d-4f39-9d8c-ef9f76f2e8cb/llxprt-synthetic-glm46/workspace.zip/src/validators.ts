export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with strict constraints.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex with constraints
  const emailRegex = /^[a-zA-Z0-9]+([+._%+-][a-zA-Z0-9]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,})+$/;
  
  // Check for invalid patterns
  const invalidPatterns = [
    /\.\./,           // Double dots
    /^\./,            // Leading dot
    /\.$/,            // Trailing dot
    /@.*_/,           // Underscore in domain
    /\..*\./,         // Dot immediately after @
  ];
  
  // Return false if any invalid patterns are found
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  // Return true if email matches the basic pattern
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common formats and optional +1 prefix.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Check for extensions if allowed
  if (options?.allowExtensions) {
    const extensionRegex = /#\d+$/;
    if (extensionRegex.test(value)) {
      value = value.replace(extensionRegex, '');
    }
  }
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (at least area code + exchange + subscriber)
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // If 11 digits, first must be 1 (country code)
  if (digits.length === 11 && digits[0] !== '1') {
    return false;
  }
  
  // Extract the 10-digit number (with or without country code)
  const phoneNumber = digits.length === 10 ? digits : digits.substring(1);
  
  // Check area code (first digit cannot be 0 or 1)
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') {
    return false;
  }
  
  // Check if the format matches allowed patterns
  const patterns = [
    /^\+?1?\s*\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/, // Full format
    /^\+?1?\s*([2-9]\d{2})[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/, // No parentheses
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 * Allow spaces or hyphens as separators.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for easier validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Try to match various patterns for Argentine phone numbers
  // Format 1: With country code +54
  // +54[9]XXXXXXXXXX where area code is 2-4 digits and subscriber is 6-8 digits
  const withCountryRegex = /^\+54(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const withCountryMatch = cleaned.match(withCountryRegex);
  
  if (withCountryMatch) {
    const areaCode = withCountryMatch[2];
    const subscriber = withCountryMatch[3];
    
    // Verify area code is valid (2-4 digits, first digit 1-9)
    if (/^[1-9]\d{1,3}$/.test(areaCode) && /^\d{6,8}$/.test(subscriber)) {
      // If no mobile prefix, this is a landline, which is fine
      return true;
    }
  }
  
  // Format 2: Local format with trunk prefix 0
  // 0XXXXXXXX where area code is 2-4 digits and subscriber is 6-8 digits
  const withTrunkRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  const withTrunkMatch = cleaned.match(withTrunkRegex);
  
  if (withTrunkMatch) {
    const areaCode = withTrunkMatch[1];
    const subscriber = withTrunkMatch[2];
    
    // Verify area code and subscriber
    if (/^[1-9]\d{1,3}$/.test(areaCode) && /^\d{6,8}$/.test(subscriber)) {
      return true;
    }
  }
  
  return false;
}

/**
 * Validates personal names supporting international characters.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Name should contain at least one character
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Pattern allows:
  // - Unicode letters (\p{L})
  // - Accents and marks (\p{M})
  // - Apostrophes and hyphens
  // - Spaces
  // - Periods (for initials)
  const namePattern = /^[\p{L}\p{M}'\-\.\s]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject unusual symbol combinations (like X Æ A-12)
  const unusualPattern = /[ÆæØøÅå]/;
  if (unusualPattern.test(value) && /[0-9]/.test(value)) {
    return false;
  }
  
  // Ensure at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for major cards (Visa, Mastercard, AmEx).
 * Checks length/prefix constraints and performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const digits = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Check card patterns and lengths
  const visaPattern = /^4\d{12}(\d{3})?$/; // 13 or 16 digits starting with 4
  const mastercardPattern = /^5[1-5]\d{14}$/; // 16 digits starting with 51-55
  const mastercardPattern2 = /^2(2[2-9]\d|3[0-5]\d|[4-6]\d{2}|7[01]\d|720)\d{12}$/; // New Mastercard ranges
  const amexPattern = /^3[47]\d{13}$/; // 15 digits starting with 34 or 37
  
  const isValidPattern = visaPattern.test(digits) ||
                         mastercardPattern.test(digits) ||
                         mastercardPattern2.test(digits) ||
                         amexPattern.test(digits);
  
  if (!isValidPattern) {
    return false;
  }
  
  // Perform Luhn checksum
  return runLuhnCheck(digits);
}

/**
 * Helper function to perform Luhn algorithm validation
 * @param cardNumber The credit card number as string of digits
 * @returns True if valid per Luhn algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
