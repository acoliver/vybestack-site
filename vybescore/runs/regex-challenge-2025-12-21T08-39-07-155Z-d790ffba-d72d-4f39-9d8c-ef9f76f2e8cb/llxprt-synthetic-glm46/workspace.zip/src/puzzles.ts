/**
 * Finds words that begin with the specified prefix, excluding any words in the exceptions list.
 * @param text Input text to search
 * @param prefix The prefix to match against
 * @param exceptions Array of words to exclude from results
 * @returns Array of matching words
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a word boundary pattern with the prefix
  const wordPattern = new RegExp(`\\b${prefix}\\w+\\b`, 'gi');
  
  // Find all words starting with the prefix
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive comparison)
  const filteredWords = matches.filter(word => {
    const lowerCaseWord = word.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === lowerCaseWord
    );
  });
  
  // Return unique words
  return Array.from(new Set(filteredWords));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookbehind to ensure the token is preceded by a digit.
 * @param text Input text to search
 * @param token The token to find
 * @returns Array of matching token occurrences
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token only after digit (including the digit in the result)
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(tokenPattern) || [];
  
  return matches;
}

/**
 * Validates passwords against strong security requirements.
 * Requires at least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * Disallows whitespace and immediate repeated sequences (e.g., 'abab').
 * @param value Password string to validate
 * @returns True if password meets all requirements
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated patterns (like abab, abcabc)
  // We'll check for patterns where a sequence of 2-4 characters is repeated
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const pattern = value.substr(i, len);
      const nextPattern = value.substr(i + len, len);
      if (pattern === nextPattern) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses including shorthand notation while excluding IPv4 addresses.
 * @param value Input text to check
 * @returns True if IPv6 address is found
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns (various formats)
  
  // Full notation: 8 groups of 4 hex digits
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // With :: shorthand (0 or more groups on either side)
  const shorthandIPv6 = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*[0-9a-fA-F]{1,4}/;
  
  // IPv4-mapped IPv6: ::ffff:192.0.2.128
  const mappedIPv6 = /::(?:ffff:)?(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Combined pattern to match any IPv6 address
  const ipv6Pattern = new RegExp(`\\b(?:${fullIPv6.source}|${shorthandIPv6.source}|${mappedIPv6.source})\\b`);
  
  // Find matches
  const matches = value.match(ipv6Pattern);
  if (!matches) {
    return false;
  }
  
  // For each match, verify it's not actually an IPv4 address
  for (const match of matches) {
    // Check if this is not IPv4
    const isIPv4 = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(match.trim());
    
    if (!isIPv4) {
      return true; // Found at least one valid IPv6 address
    }
  }
  
  return false;
}
