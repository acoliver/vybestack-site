/**
 * Capitalizes the first character of each sentence while handling abbreviations.
 * After punctuation (.?!), ensures exactly one space between sentences.
 * Collapses extra spaces while preserving abbreviations when possible.
 * @param text Input text to transform
 * @returns Text with properly capitalized sentences
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Replace common abbreviations with a temporary marker
  let processedText = text;
  const abbreviations = ['Mr.', 'Mrs.', 'Dr.', 'Prof.', 'St.', 'Ave.', 'Blvd.', 'Rd.', 'etc.', 'e.g.', 'i.e.'];
  
  for (const abbr of abbreviations) {
    processedText = processedText.replace(new RegExp(abbr.replace('.', '\\.'), 'g'), abbr.replace('.', '\x01'));
  }
  
  // Split text into sentences using common punctuation marks
  const sentences = processedText.split(/([.?!]+)/);
  
  // Process each sentence
  const processedSentences: string[] = [];
  let isStartOfText = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    // If this is punctuation, keep it as is
    if (/[.!?]+/.test(segment)) {
      processedSentences.push(segment);
      continue;
    }
    
    // If this is text segment, handle capitalization
    if (segment.trim()) {
      // If this is the start of the text or follows punctuation
      if (isStartOfText || (i > 0 && /[.!?]+/.test(sentences[i-1]))) {
        // Capitalize first letter
        const trimmed = segment.trim();
        const firstChar = trimmed[0].toUpperCase();
        const rest = trimmed.slice(1);
        processedSentences.push(firstChar + rest);
      } else {
        // Keep as is
        processedSentences.push(segment);
      }
    } else {
      processedSentences.push(segment);
    }
    
    isStartOfText = false;
  }
  
  // Join sentences and restore abbreviations
  let result = processedSentences.join('').replace(/\x01/g, '.');
  
  // Clean up any double spaces that might have been created
  result = result.replace(/ +/g, ' ');
  
  // Ensure exactly one space after punctuation if not followed by punctuation or end-of-string
  result = result.replace(/([.!?])([^.!\s])/g, '$1 $2');
  
  return result;
}

/**
 * Extracts all URLs from the given text without trailing punctuation.
 * @param text Input text to search for URLs
 * @returns Array of URLs found in the text
 */
export function extractUrls(text: string): string[] {
  // Pattern for matching URLs (http, https, ftp)
  const urlRegex = /\b((https?|ftp):\/\/[^\s/$.?#].[^\s]*)/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean each URL by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing non-URL characters (punctuation)
    return url.replace(/[.,;:!?)\]\}]+$/, '');
  });
}

/**
 * Upgrades all HTTP schemes to HTTPS while leaving existing HTTPS URLs unchanged.
 * @param text Input text containing URLs
 * @returns Text with all URLs using HTTPS scheme
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not if already https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * - Always upgrades to HTTPS
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic paths with cgi-bin, query params, or legacy extensions
 * @param text Input text containing URLs
 * @returns Text with documentation URLs rewritten
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match HTTP/HTTPS URLs with example.com host
  const urlRegex = /(https?:\/\/)([^\/\s]+)(\/[^\s]*)?/g;
  
  return text.replace(urlRegex, (match, protocol, host, path = '') => {
    // Always upgrade to HTTPS
    const newProtocol = 'https://';
    
    // Only process example.com URLs
    if (!host.includes('example.com')) {
      return `${newProtocol}${host}${path}`;
    }
    
    // Skip host rewrite for dynamic paths
    const skipPatterns = [
      /cgi-bin/i,
      /\?/,   // Query parameters
      /&/,    // Additional query parameters
      /=/,    // Query assignment
      /\.jsp$/i, 
      /\.php$/i, 
      /\.asp$/i, 
      /\.aspx$/i, 
      /\.do$/i, 
      /\.cgi$/i, 
      /\.pl$/i, 
      /\.py$/i
    ];
    
    const shouldSkipHostRewrite = skipPatterns.some(pattern => pattern.test(path));
    
    // For /docs/ paths, rewrite to docs.example.com unless skipping
    if (path.startsWith('/docs/') && !shouldSkipHostRewrite) {
      return `${newProtocol}docs.example.com${path}`;
    }
    
    // Default: just upgrade to HTTPS
    return `${newProtocol}${host}${path}`;
  });
}

/**
 * Extracts the year from a date string in mm/dd/yyyy format.
 * Returns "N/A" if the string doesn't match or month/day are invalid.
 * @param value Date string to parse
 * @returns The four-digit year or "N/A"
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return "N/A";
  }
  
  const year = match[3];
  return year;
}
