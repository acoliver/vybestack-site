console.log('Testing basic functionality...');
const { createInput } = require('./src/index.ts');
const [getter, setter] = createInput(1);
console.log('Initial value:', getter());
setter(2);
console.log('After setting to 2:', getter());

