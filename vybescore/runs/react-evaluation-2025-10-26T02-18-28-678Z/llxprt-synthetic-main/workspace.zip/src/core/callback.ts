/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Store all active callbacks to manage subscription lifecycle
const callbacks = new Set<Observer<any>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      // Execute the side effect
      const result = updateFn(prevValue)
      return result !== undefined ? result : prevValue as T
    },
  }
  
  // Register observer to track dependencies
  callbacks.add(observer)
  
  // Register with the reactive system to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from callbacks set to stop further updates
    callbacks.delete(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}