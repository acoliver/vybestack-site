/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Convert boolean to equality function or use provided function
  const equalFn: EqualFn<T> | undefined = 
    equal === false ? () => false :
    equal === true || equal === undefined ? (lhs, rhs) => lhs === rhs :
    typeof equal === 'function' ? equal : undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // Track all observers that depend on this input
  const observers: Set<Observer<any>> = new Set()

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add to our observer tracking set
      observers.add(observer as Observer<unknown>)
      // Also set as the single observer for backward compatibility
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }

    s.value = nextValue
    
    // Notify the single observer (backward compatibility)
    if (s.observer) {
      updateObserver(s.observer as Observer<unknown>)
    }
    
    // Also notify all observers in our set
    for (const observer of observers) {
      updateObserver(observer)
    }
    
    return s.value
  }

  return [read, write]
}