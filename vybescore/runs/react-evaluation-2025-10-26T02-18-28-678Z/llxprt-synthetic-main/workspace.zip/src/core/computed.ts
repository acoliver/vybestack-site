/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Store a reference to this observer that we can use for notifications
  const selfObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      return updateFn(prevValue)
    },
  }
  
  // Initialize by computing the value
  updateObserver(selfObserver)
  
  // Return getter function that recomputes when dependencies change
  return (): T => {
    const currentObserver = getActiveObserver()
    
    // If we have an active observer, make it observe this computed value
    if (currentObserver) {
      // This is the critical part: the currentObserver needs to be stored
      // so this computed value can notify it when its dependencies change
      (selfObserver as any).observer = currentObserver
    }
    
    // If value hasn't been initialized, compute it now
    if (selfObserver.value === undefined) {
      updateObserver(selfObserver)
    }
    
    return selfObserver.value!
  }
}