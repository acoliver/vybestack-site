import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;

function validatePaginationParams(req: Request, res: Response, nextPage: () => void): void {
  const pageParam = req.query.page as string | undefined;
  const limitParam = req.query.limit as string | undefined;

  if (pageParam !== undefined) {
    const page = Number(pageParam);
    if (isNaN(page) || !Number.isInteger(page) || page < 1) {
      res.status(400).json({ error: 'Invalid page parameter: must be a positive integer' });
      return;
    }
  }

  if (limitParam !== undefined) {
    const limit = Number(limitParam);
    if (isNaN(limit) || !Number.isInteger(limit) || limit < 1) {
      res.status(400).json({ error: 'Invalid limit parameter: must be a positive integer' });
      return;
    }
    if (limit > MAX_LIMIT) {
      res.status(400).json({ error: `Invalid limit parameter: maximum is ${MAX_LIMIT}` });
      return;
    }
  }

  nextPage();
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', validatePaginationParams, (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
