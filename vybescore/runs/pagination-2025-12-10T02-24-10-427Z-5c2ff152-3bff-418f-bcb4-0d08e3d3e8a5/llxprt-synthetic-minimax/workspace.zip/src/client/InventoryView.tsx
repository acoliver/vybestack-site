import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }
  
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  currentPage, 
  hasNext, 
  onPageChange 
}: { 
  currentPage: number; 
  hasNext: boolean; 
  onPageChange: (page: number) => void;
}): JSX.Element {
  return (
    <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
      <button 
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage <= 1}
        type="button"
      >
        Previous
      </button>
      <span>Page {currentPage}</span>
      <button 
        onClick={() => onPageChange(currentPage + 1)}
        disabled={!hasNext}
        type="button"
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return (
      <section>
        <h1>Inventory</h1>
        <p role="alert">{error ?? 'Unable to load inventory.'}</p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <p>Showing {data.items.length} of {data.total} items (limit: {data.limit} per page)</p>
      <InventoryList items={data.items} />
      <PaginationControls
        currentPage={data.page}
        hasNext={data.hasNext}
        onPageChange={setCurrentPage}
      />
    </section>
  );
}
