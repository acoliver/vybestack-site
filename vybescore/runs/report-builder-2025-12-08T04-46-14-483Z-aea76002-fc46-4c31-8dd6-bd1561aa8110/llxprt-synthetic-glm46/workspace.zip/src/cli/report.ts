#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

import type { ReportData, RenderOptions, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliArgs {
  dataFile: string;
  format: FormatType;
  output?: string;
  includeTotals: boolean;
}

const parseArgs = (): CliArgs => {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]',
    );
    process.exit(1);
  }

  const dataFile = args[0];

  if (!args.includes('--format')) {
    console.error('Missing required argument: --format');
    process.exit(1);
  }

  const formatIndex = args.indexOf('--format');
  const format = args[formatIndex + 1] as FormatType;

  if (!format || !['markdown', 'text'].includes(format)) {
    console.error('Unsupported format');
    process.exit(1);
  }

  const outputIndex = args.indexOf('--output');
  const output = outputIndex !== -1 ? args[outputIndex + 1] : undefined;

  const includeTotals = args.includes('--includeTotals');

  return {
    dataFile,
    format,
    output,
    includeTotals,
  };
};

const validateReportData = (data: unknown): ReportData => {
  if (
    typeof data !== 'object' ||
    data === null ||
    !('title' in data) ||
    !('summary' in data) ||
    !('entries' in data)
  ) {
    throw new Error('Invalid report data structure');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Title must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Summary must be a string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Entries must be an array');
  }

  const entries = reportData.entries;

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (
      typeof entry !== 'object' ||
      entry === null ||
      !('label' in entry) ||
      !('amount' in entry)
    ) {
      throw new Error(`Entry ${i} must have label and amount`);
    }

    const entryRecord = entry as Record<string, unknown>;

    if (typeof entryRecord.label !== 'string') {
      throw new Error(`Entry ${i} label must be a string`);
    }

    if (typeof entryRecord.amount !== 'number') {
      throw new Error(`Entry ${i} amount must be a number`);
    }
  }

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries: entries as ReportData['entries'],
  };
};

const main = () => {
  try {
    const { dataFile, format, output, includeTotals } = parseArgs();

    const dataPath = resolve(__dirname, '..', '..', dataFile);
    const rawData = readFileSync(dataPath, 'utf-8');
    const jsonData = JSON.parse(rawData);
    const reportData = validateReportData(jsonData);

    const renderOptions: RenderOptions = { includeTotals };
    const renderer = formatRenderers[format];
    const renderedReport = renderer(reportData, renderOptions);

    if (output) {
      writeFileSync(output, renderedReport, 'utf-8');
      console.log(`Report written to ${output}`);
    } else {
      console.log(renderedReport);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
};

main();