#!/usr/bin/env node

import { readFileSync, writeFile } from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { formatters, isSupportedFormat } from '../formats/index.js';

/**
 * CLI arguments structure
 */
interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parse command line arguments
 */
function parseArgs(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[0];
  const formatIndex = args.findIndex(arg => arg === '--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  const format = args[formatIndex + 1];

  if (!isSupportedFormat(format)) {
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
  }

  const outputIndex = args.findIndex(arg => arg === '--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1
    ? args[outputIndex + 1]
    : undefined;

  const includeTotals = args.includes('--includeTotals');

  return {
    dataPath,
    format,
    outputPath,
    includeTotals,
  };
}

/**
 * Read and parse JSON data from file
 */
function readDataFile(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }

    // Validate entries
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Entry missing or invalid "label" field');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Entry missing or invalid "amount" field');
      }
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}"`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Failed to read file "${filePath}"`);
    }
    process.exit(1);
  }
}

/**
 * Write output to file or stdout
 */
function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFile(outputPath, content, (err) => {
        if (err) {
          console.error(`Error writing to file "${outputPath}": ${err.message}`);
          process.exit(1);
        }
      });
    } catch (error) {
      console.error(`Error writing to file "${outputPath}": ${error}`);
      process.exit(1);
    }
  } else {
    console.log(content);
  }
}

/**
 * Main entry point
 */
function main(): void {
  const { dataPath, format, outputPath, includeTotals } = parseArgs();
  
  const data = readDataFile(dataPath);
  const options: RenderOptions = { includeTotals };
  
  const formatter = formatters[format];
  const output = formatter(data, options);
  
  writeOutput(output, outputPath);
}

// Run the CLI
main();