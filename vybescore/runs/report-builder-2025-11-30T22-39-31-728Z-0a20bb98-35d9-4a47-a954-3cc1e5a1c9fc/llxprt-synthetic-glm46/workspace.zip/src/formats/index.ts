import type { Formatter } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Registry of available formatters
 */
export const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Check if a format is supported
 */
export function isSupportedFormat(format: string): format is keyof typeof formatters {
  return format in formatters;
}