#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { parseArgs } from './args.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData } from '../formats/types.js';

function loadDataFromFile(filePath: string): ReportData {
  const rawData = readFileSync(filePath, 'utf-8');
  
  let data: ReportData;
  try {
    data = JSON.parse(rawData);
  } catch (error) {
    throw new Error(`Invalid JSON in data file: ${filePath}`);
  }
  
  // Validate required fields
  if (!data.title || typeof data.title !== 'string') {
    throw new Error('Missing or invalid title in data file');
  }
  
  if (!data.summary || typeof data.summary !== 'string') {
    throw new Error('Missing or invalid summary in data file');
  }
  
  if (!Array.isArray(data.entries)) {
    throw new Error('Missing or invalid entries in data file');
  }
  
  for (const entry of data.entries) {
    if (!entry.label || typeof entry.label !== 'string') {
      throw new Error('Missing or invalid label in entry');
    }
    
    if (typeof entry.amount !== 'number') {
      throw new Error('Missing or invalid amount in entry');
    }
  }
  
  return data;
}

function main() {
  try {
    const args = parseArgs(process.argv.slice(2));
    const data = loadDataFromFile(args.dataFile);
    
    const options = {
      includeTotals: args.includeTotals
    };
    
    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(data, options);
        break;
      case 'text':
        output = renderText(data, options);
        break;
      default:
        throw new Error(`Unsupported format: ${args.format}`);
    }
    
    if (args.outputFile) {
      writeFileSync(args.outputFile, output);
      console.log(`Report written to ${args.outputFile}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'An unknown error occurred');
    process.exit(1);
  }
}

main();