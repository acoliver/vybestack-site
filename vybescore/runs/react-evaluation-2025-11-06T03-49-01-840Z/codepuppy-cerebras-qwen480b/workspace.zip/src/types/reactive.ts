/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Simple reactive system based on Exercism patterns
export interface Observer {
  _callback: () => void
}

export interface Subject<T> {
  _value: T
  _observers: Set<Observer>
  _equalFn?: EqualFn<T>
}

let activeObserver: Observer | undefined
const updateQueue: Set<Observer> = new Set()
let isScheduled = false

declare global {
  let __dependencyCollection: Set<Subject<unknown>> | undefined
}

export function getActiveObserver(): Observer | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer | undefined): void {
  activeObserver = observer
}

export function addObserver(subject: Subject<unknown>, observer: Observer): void {
  subject._observers.add(observer)
  
  // If we're in dependency collection mode, track the dependency
  if (globalThis.__dependencyCollection) {
    globalThis.__dependencyCollection.add(subject)
  }
}

export function removeObserver(subject: Subject<unknown>, observer: Observer): void {
  subject._observers.delete(observer)
}

export function scheduleUpdate(observer: Observer): void {
  updateQueue.add(observer)
  if (!isScheduled) {
    isScheduled = true
    queueMicrotask(() => {
      const observers = Array.from(updateQueue)
      updateQueue.clear()
      isScheduled = false
      
      for (const obs of observers) {
        obs._callback()
      }
    })
  }
}

export function getValue<T>(subject: Subject<T>): T {
  const observer = getActiveObserver()
  if (observer) {
    addObserver(subject, observer)
  }
  return subject._value
}

export function setValue<T>(subject: Subject<T>, newValue: T): T {
  if (subject._equalFn && subject._equalFn(subject._value, newValue)) {
    return subject._value
  }
  
  subject._value = newValue
  
  for (const observer of subject._observers) {
    scheduleUpdate(observer)
  }
  
  return subject._value
}
