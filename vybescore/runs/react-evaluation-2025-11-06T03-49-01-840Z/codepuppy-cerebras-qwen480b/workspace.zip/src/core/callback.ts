/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, setActiveObserver, UpdateFn } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create an observer for this callback
  const callbackObserver: Observer = {
    _callback: () => {
      // Set this as the active observer to track dependencies
      setActiveObserver(callbackObserver)
      
      try {
        // Execute the callback function (side effects)
        updateFn(value)
      } finally {
        setActiveObserver(undefined)
      }
    }
  }
  
  // Initial callback execution
  callbackObserver._callback()
  
  let disposed = false
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // In a more complete implementation, we would clean up dependencies
    // For this exercise, we just mark as disposed
  }
  
  return unsubscribe
}