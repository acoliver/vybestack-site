/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  getActiveObserver,
  setActiveObserver,
  removeObserver,
  addObserver,
  scheduleUpdate,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = equal === true 
    ? ((a, b) => a === b) 
    : equal === false || equal === undefined 
      ? undefined 
      : equal

  // Track dependencies separately from observers
  const dependencies = new Set<Subject<unknown>>()
  
  // Create an observer for this computed value
  const computedObserver: Observer = {
    _callback: () => recompute()
  }

  // Create a subject to represent this computed value (for other computed values that depend on this)
  const subject: Subject<T> = {
    _value: value as T,
    _observers: new Set(),
    _equalFn: equalFn,
  }

  function recompute(): void {
    // Remove old dependencies
    for (const dep of dependencies) {
      removeObserver(dep, computedObserver)
    }
    dependencies.clear()
    
    // Set up dependency collection
    globalThis.__dependencyCollection = dependencies
    
    try {
      // Set this as the active observer to track new dependencies
      setActiveObserver(computedObserver)
      
      // Compute new value - this will track dependencies via getValue calls
      const newValue = updateFn(subject._value)
      
      // Register this observer with any dependencies that were collected
      for (const dep of dependencies) {
        addObserver(dep, computedObserver)
      }
      
      // Check if value actually changed
      if (!equalFn || !equalFn(subject._value, newValue)) {
        subject._value = newValue
        
        // Notify our own observers (computed values that depend on this)
        for (const obs of subject._observers) {
          scheduleUpdate(obs)
        }
      }
    } finally {
      setActiveObserver(undefined)
      globalThis.__dependencyCollection = undefined
    }
  }

  const computed: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register this computed as a dependency
      addObserver(subject, activeObserver)
    }
    return subject._value
  }

  // Initial computation
  recompute()

  return computed
}