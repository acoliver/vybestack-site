/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  getValue,
  setValue,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = equal === true 
    ? ((a, b) => a === b) 
    : equal === false || equal === undefined 
      ? undefined 
      : equal

  const subject: Subject<T> = {
    _value: value,
    _observers: new Set(),
    _equalFn: equalFn,
  }

  const read: GetterFn<T> = () => getValue(subject)

  const write: SetterFn<T> = (nextValue) => setValue(subject, nextValue)

  return [read, write]
}
