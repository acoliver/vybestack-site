import { createInput, createComputed } from './dist/src/index.js';

console.log('=== Testing reactive system ===');

const [input, setInput] = createInput(1);
console.log('Created input with value:', input());

const timesTwo = createComputed(() => {
  console.log('Computing timesTwo, input =', input());
  return input() * 2;
});
console.log('Created timesTwo with value:', timesTwo());

const timesThirty = createComputed(() => {
  console.log('Computing timesThirty, input =', input());
  return input() * 30;
});
console.log('Created timesThirty with value:', timesThirty());

const sum = createComputed(() => {
  console.log('Computing sum, timesTwo =', timesTwo(), 'timesThirty =', timesThirty());
  return timesTwo() + timesThirty();
});
console.log('Created sum with value:', sum());

console.log('\n=== Changing input to 3 ===');
setInput(3);

console.log('\n=== Final values ===');
console.log('input:', input());
console.log('timesTwo:', timesTwo());
console.log('timesThirty:', timesThirty());
console.log('sum:', sum());