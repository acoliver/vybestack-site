import { ReportData, ReportOptions, ReportRenderer } from "../types.js";

export function renderText(data: ReportData, options: ReportOptions): string {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push("");
  
  // Summary
  lines.push(data.summary);
  lines.push("");
  
  // Entries section
  lines.push("Entries:");
  
  // Format each entry as a bullet item
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }
  
  // Add total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: $${total.toFixed(2)}`);
  }
  
  return lines.join("\n");
}

// Export as a renderer object for consistency with the interface
export const textRenderer: ReportRenderer = {
  render: renderText,
};