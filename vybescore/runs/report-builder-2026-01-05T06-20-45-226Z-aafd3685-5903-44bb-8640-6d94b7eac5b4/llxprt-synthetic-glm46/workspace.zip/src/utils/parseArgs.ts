import { ReportFormat } from "../types.js";

export interface CliArgs {
  dataFile: string;
  format: ReportFormat;
  outputPath: string | null;
  includeTotals: boolean;
}

function detectFormat(formatString: string): ReportFormat {
  const format = formatString.toLowerCase() as ReportFormat;
  if (format !== "markdown" && format !== "text") {
    throw new Error(`Unsupported format: ${formatString}`);
  }
  return format;
}

export function parseCliArgs(args: string[]): CliArgs {
  // Skip the first two args (node and script path)
  const processArgs = args.slice(2);
  
  if (processArgs.length < 2) {
    throw new Error("Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]");
  }
  
  const dataFile = processArgs[0];
  let format: ReportFormat | null = null;
  let outputPath: string | null = null;
  let includeTotals = false;
  
  // Parse arguments
  for (let i = 1; i < processArgs.length; i++) {
    const arg = processArgs[i];
    
    if (arg === "--format") {
      if (i + 1 >= processArgs.length) {
        throw new Error("--format requires a value");
      }
      format = detectFormat(processArgs[i + 1]);
      i++;
    } else if (arg === "--output") {
      if (i + 1 >= processArgs.length) {
        throw new Error("--output requires a value");
      }
      outputPath = processArgs[i + 1];
      i++;
    } else if (arg === "--includeTotals") {
      includeTotals = true;
    } else if (arg.startsWith("--")) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }
  
  if (!format) {
    throw new Error("--format is required");
  }
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}