#!/usr/bin/env node

import fs from "fs";
import { parseCliArgs } from "../utils/parseArgs.js";
import { ReportData, ReportOptions } from "../types.js";
import { markdownRenderer } from "../formats/markdown.js";
import { textRenderer } from "../formats/text.js";

function validateReportData(data: unknown): ReportData {
  if (typeof data !== "object" || data === null) {
    throw new Error("Invalid data: expected object");
  }
  
  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== "string") {
    throw new Error("Invalid data: missing or invalid title");
  }
  
  if (typeof reportData.summary !== "string") {
    throw new Error("Invalid data: missing or invalid summary");
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error("Invalid data: missing or invalid entries array");
  }
  
  const entries = reportData.entries.map((entry, index) => {
    if (typeof entry !== "object" || entry === null) {
      throw new Error(`Invalid entry at index ${index}: expected object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== "string") {
      throw new Error(`Invalid entry at index ${index}: missing or invalid label`);
    }
    
    if (typeof entryObj.amount !== "number") {
      throw new Error(`Invalid entry at index ${index}: missing or invalid amount`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });
  
  return {
    title: reportData.title,
    summary: reportData.summary,
    entries,
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, "utf-8");
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

function writeOutput(content: string, outputPath: string | null): void {
  if (outputPath) {
    fs.writeFileSync(outputPath, content);
  } else {
    console.log(content);
  }
}

function main(): void {
  try {
    const args = parseCliArgs(process.argv);
    const reportData = loadReportData(args.dataFile);
    
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };
    
    const content = 
      args.format === "markdown"
        ? markdownRenderer.render(reportData, options)
        : textRenderer.render(reportData, options);
    
    writeOutput(content, args.outputPath);
  } catch (error) {
    console.error(error instanceof Error ? error.message : "Unknown error");
    process.exit(1);
  }
}

main();
