const STANDARD_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const BASE64_URL_REGEX = /^[A-Za-z0-9_-]*$/;

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Input is empty');
  }

  // Check if input is valid standard Base64 or URL-safe Base64
  const isStandardBase64 = STANDARD_BASE64_REGEX.test(input);
  const isBase64Url = BASE64_URL_REGEX.test(input);
  
  if (!isStandardBase64 && !isBase64Url) {
    throw new Error('Invalid Base64 input');
  }

  // Normalize URL-safe Base64 to standard Base64 if needed
  let normalizedInput = input;
  if (isBase64Url) {
    normalizedInput = input.replace(/-/g, '+').replace(/_/g, '/');
    
    // Add padding if missing
    const paddingLength = (4 - (normalizedInput.length % 4)) % 4;
    normalizedInput += '='.repeat(paddingLength);
  }

  try {
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
