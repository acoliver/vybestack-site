import initSqlJs from 'sql.js';
import fs from 'fs/promises';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

let SQL: initSqlJs.SqlJsStatic | null = null;
let db: initSqlJs.Database | null = null;

// Form data interface matching server.ts
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export async function initDatabase(): Promise<void> {
  if (!SQL) {
    SQL = await initSqlJs({
      locateFile: (file) => {
        // This ensures sql.js can find its WASM file
        return path.join(process.cwd(), 'public', file);
      }
    });
  }

  try {
    // Try to load existing database
    const dbBuffer = await fs.readFile(DB_PATH);
    db = new SQL.Database(dbBuffer);
  } catch (error) {
    // If file doesn't exist, create new database
    if (!SQL) {
      throw new Error('SQL not initialized');
    }
    db = new SQL.Database();
    
    // Create submissions table
    db.run(`
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `);
    
    // Save the new database
    await saveDatabase();
  }
}

export async function saveSubmission(formData: FormData): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);

  stmt.free();
  await saveDatabase();
}

async function saveDatabase(): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }

  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  try {
    await fs.access(dataDir);
  } catch {
    await fs.mkdir(dataDir, { recursive: true });
  }

  const binaryData = db.export();
  await fs.writeFile(DB_PATH, Buffer.from(binaryData));
}

export async function closeDatabase(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
}