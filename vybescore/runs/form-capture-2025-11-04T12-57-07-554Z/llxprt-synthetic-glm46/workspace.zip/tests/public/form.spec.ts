import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, startServer } from '../../src/server.js';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let server: any;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Start the server before running tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  server = await startServer();
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check that form exists
    expect($('form[action="/submit"]').length).toBe(1);
    
    // Check that all required fields exist
    const requiredFields = [
      '#firstName',
      '#lastName', 
      '#streetAddress',
      '#city',
      '#stateProvince',
      '#postalCode',
      '#country',
      '#email',
      '#phone'
    ];
    
    requiredFields.forEach(selector => {
      expect($(selector).length).toBe(1);
      expect($(selector).attr('required')).toBeDefined();
    });
    
    // Check that labels are properly associated
    expect($('label[for="firstName"]').text()).toContain('First Name');
    expect($('label[for="email"]').text()).toContain('Email');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '123 Test St',
      city: 'Testville',
      stateProvince: 'Test State',
      postalCode: 'TS1 2AB',
      country: 'Testland',
      email: 'test@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit the form
    const submitResponse = await request(app)
      .post('/submit')
      .send(formData);
    
    // Should redirect to thank-you page
    expect(submitResponse.status).toBe(302);
    expect(submitResponse.headers.location).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Follow the redirect and check thank-you page
    const thankYouResponse = await request(app)
      .get('/thank-you')
      .set('Cookie', submitResponse.headers['set-cookie']);
    
    expect(thankYouResponse.status).toBe(200);
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank You, Test!');
  });

  it('handles invalid form submission', async () => {
    const invalidFormData = {
      firstName: '', // Empty field
      lastName: 'User',
      email: 'invalid-email', // Invalid format
      // Missing other required fields
    };
    
    const response = await request(app)
      .post('/submit')
      .send(invalidFormData);
    
    // Should show form with errors (not redirect)
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('.alert.error').length).toBe(1);
  });
});
