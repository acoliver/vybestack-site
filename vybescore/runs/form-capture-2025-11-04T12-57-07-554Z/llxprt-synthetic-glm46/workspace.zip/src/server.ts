import express from 'express';
import path from 'node:path';
import fs from 'node:fs';

// Type imports
// We'll use any for sql.js types to avoid complex setup

// Sql.JS dynamic import
const initSqlJs = async () => (await import('sql.js')).default;

// We'll simplify and use any for the whole server to avoid complex type issues

// Simple in-memory session store for this small app
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sessionStore: Record<string, any> = {};
let nextSessionId = 1;

// Custom session middleware
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function sessionMiddleware(req: any, res: any, next: any) {
  const sessionId = req.headers?.cookie?.match(/sessionId=([^;]+)/)?.[1];
  
  if (!sessionId) {
    req.session = {} as Record<string, unknown>;
    req.sessionId = `session-${nextSessionId++}`;
    sessionStore[req.sessionId] = req.session;
    
    // Set session cookie
    const cookie = `sessionId=${req.sessionId}; HttpOnly; Path=/; SameSite=Strict`;
    res.setHeader('Set-Cookie', cookie);
  } else {
    req.sessionId = sessionId;
    req.session = sessionStore[sessionId] || {};
  }
  
  next();
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any;

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    // Make sure the data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load sql.js
    const sqlJsModule = await initSqlJs();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SQL = await (sqlJsModule as any)({
      locateFile: () => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm')
    });

    // Try to load existing database or create a new one
    let dbBytes: Uint8Array;
    if (fs.existsSync(DB_PATH)) {
      dbBytes = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbBytes);
    } else {
      db = new SQL.Database();
      
      // Create the tables using schema.sql
      const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      const schemaSql = fs.readFileSync(schemaPath, 'utf8');
      db.run(schemaSql);
      
      // Save to disk
      saveDatabase(db);
    }
    
    console.log('Database initialized');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function saveDatabase(database: any): void {
  try {
    const data = database.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));
// eslint-disable-next-line @typescript-eslint/no-explicit-any
app.use(sessionMiddleware as any);
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length > 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[a-z0-9\s-]+$/i;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!formData.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!formData.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!formData.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!formData.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!formData.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!formData.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/ZIP code is required' });
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal/ZIP code' });
  }

  if (!formData.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!formData.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!formData.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  return errors;
}

// Route handlers
// eslint-disable-next-line @typescript-eslint/no-explicit-any
app.get('/', (req: any, res: any) => {
  res.render('form', { 
    errors: [], 
    formData: {} 
  });
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
app.post('/submit', (req: any, res: any) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    // Render form with errors and entered data
    res.status(400).render('form', { 
      errors, 
      formData 
    });
    return;
  }

  // Insert into database
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
    saveDatabase(db);

    // Store first name for thank you page
    req.session!.firstName = formData.firstName;

    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: [{ field: 'general', message: 'Something went wrong. Please try again.' }],
      formData
    });
  }
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
app.get('/thank-you', (req: any, res: any) => {
  // For simplicity, we'll just use a default greeting,
  // in a real app you might use a session or query param
  res.render('thank-you', { 
    firstName: req.session?.firstName || 'Friend' 
  });
});

// Graceful shutdown
function shutdown() {
  console.log('Shutting down gracefully...');
  if (db) {
    db.close();
    console.log('Database connection closed');
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer() {
  try {
    await initializeDatabase();
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

// Export the app for testing
export { app, startServer };