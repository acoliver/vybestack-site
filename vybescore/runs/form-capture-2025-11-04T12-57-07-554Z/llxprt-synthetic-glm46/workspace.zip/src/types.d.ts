// eslint-disable-next-line @typescript-eslint/no-explicit-any
declare module 'sql.js' {
  export function init(options?: { locateFile?: (file: string) => string }): Promise<typeof Database>;
  
  export class Database {
    constructor(data?: Uint8Array);
    
    run(sql: string, ...params: unknown[]): unknown;
    
    exec(sql: string): unknown[];
    
    prepare(sql: string): Statement;
    
    export(): Uint8Array;
    
    close(): void;
  }
  
  export class Statement {
    run(...params: unknown[]): unknown;
    
    get(...params: unknown[]): unknown;
    
    all(...params: unknown[]): unknown[];
    
    free(): void;
  }
}

declare module 'express-serve-static-core' {
  interface Request {
    session?: Record<string, unknown>;
    sessionId?: string;
    body: Record<string, unknown>;
  }
}