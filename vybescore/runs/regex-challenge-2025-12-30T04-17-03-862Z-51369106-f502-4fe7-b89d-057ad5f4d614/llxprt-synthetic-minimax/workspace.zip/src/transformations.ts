/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to match sentence boundaries (after .?! followed by space and capital or lowercase)
  return text.replace(
    /([.!?]\s+)([a-z])/g,
    (_match, punctuation, letter) => punctuation + letter.toUpperCase()
  ).replace(
    /^([a-z])/,
    (_match, letter) => letter.toUpperCase()
  ).replace(
    /^\s+/g,
    () => ' '
  );
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern - matches http/https URLs with domain and path
  const urlRegex = /https?:\/\/[^\s.,!?]+/g;

  // Get matches first
  const urls = text.match(urlRegex) || [];

  // For each match, extend it to capture the full domain (including dots and path)
  return urls.map(url => {
    // Find the full URL in the original text
    const fullMatch = text.slice(text.indexOf(url)).match(/https?:\/\/[^\s.,!?]+(?:\.[^\s.,!?]+)*[^\s.,!?]*/);
    return fullMatch ? fullMatch[0] : url;
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs and rewrite them
  return text.replace(
    /http:\/\/([^\/\s]+)(\/docs\/[^\s]*)/g,
    (_match, host, path) => {
      // Check for dynamic hints or query strings that should skip host rewrite
      if (path.match(/(cgi-bin|[\$&]|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i)) {
        // Still upgrade to https but keep original host
        return 'https://' + host + path;
      } else {
        // For docs paths, rewrite host to docs.example.com
        return 'https://docs.' + host + path;
      }
    }
  ).replace(
    /http:\/\/([^\/\s]+)(?!\/docs\/)/g,
    (_match, host) => 'https://' + host // Simple http->https for non-docs paths
  );
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Extract mm/dd/yyyy pattern and validate month/day
  const match = value.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31 for simplicity)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional simple day validation (ignoring leap years, etc.)
  if ((month === 2 && day > 29) || 
      ([4, 6, 9, 11].includes(month) && day > 30)) {
    return 'N/A';
  }
  
  return year;
}