export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for obvious patterns: must contain @ and valid domain structure
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+~-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Basic validation: must have @ and not start/end with @, dots
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for patterns that might pass the above regex
  // No consecutive dots, no leading/trailing dots in local or domain
  if (value.includes('..') || 
      value.split('@')[0].endsWith('.') || 
      value.split('@')[1].startsWith('.') ||
      value.split('@')[1].includes('._')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters to work with raw numbers
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length: should be 10 digits (+ optionally 1 for country code)
  if (digitsOnly.length !== 10 && digitsOnly.length !== 11) {
    return false;
  }
  
  // If 11 digits, first should be 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Check area code (first 3 digits of the phone number)
  // Must not start with 0 or 1 (no leading 0/1 in area code)
  const areaCode = digitsOnly.substring(digitsOnly.length - 10, digitsOnly.length - 7);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Format validation - check if original input matches expected patterns
  // Allow formats: (212) 555-7890, 212-555-7890, 2125557890, +1 212-555-7890, etc.
  const phoneRegex = /^(\+?1[\s.-]?)?(\(?[2-9][0-9][0-9]\)?[\s.-]?)?[2-9][0-9]{2}[\s.-]?[0-9]{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Must start with +54 or 0
  if (!value.match(/^(\+54)?/)) {
    return false;
  }
  
  // Basic pattern: must contain digits only for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Total length check: should be 8-13 digits
  if (digitsOnly.length < 8 || digitsOnly.length > 13) {
    return false;
  }
  
  // Additional validation: ensure proper structure
  // Remove all separators and check the raw number structure
  const cleanNumber = value.replace(/[\s.-]/g, '');
  
  // Must be a valid Argentine number format
  // Either starts with +54 followed by 7-12 more digits
  // OR starts with 0 followed by 7-12 more digits
  if (cleanNumber.startsWith('+54')) {
    const withoutCC = cleanNumber.substring(3);
    return /^[1-9]\d{5,11}$/.test(withoutCC);
  } else {
    return /^[1-9]\d{5,11}$/.test(cleanNumber.substring(1));
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty or only spaces
  if (!value || !value.trim()) {
    return false;
  }
  
  // Must contain at least one letter
  if (!value.match(/\p{L}/u)) {
    return false;
  }
  
  // Reject if contains digits or certain symbols
  if (value.match(/\d/)) {
    return false;
  }
  
  // Reject specific patterns like "X Æ A-12"
  if (value.match(/[Æ]/)) {
    return false;
  }
  
  // Pattern: Allow unicode letters, apostrophes, hyphens, spaces
  // Must not contain digits or disallowed symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  return nameRegex.test(value);
}

/**
 * Helper function to run Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check prefixes for major card types
  const isVisa = /^4\d{12}(\d{3})?(\d{3})?$/;
  const isMasterCard = /^5[1-5]\d{14}$/;
  const isAmEx = /^3[47]\d{13}$/;
  
  const validPrefix = isVisa.test(digitsOnly) || 
                     isMasterCard.test(digitsOnly) || 
                     isAmEx.test(digitsOnly);
  
  if (!validPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
