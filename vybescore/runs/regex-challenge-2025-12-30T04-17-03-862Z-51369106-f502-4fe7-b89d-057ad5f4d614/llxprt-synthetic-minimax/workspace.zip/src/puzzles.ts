/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Split text into words and check each word individually
  const words = text.split(/\s+/);
  const results: string[] = [];
  
  for (const word of words) {
    // Check if word starts with prefix (case insensitive)
    if (word.toLowerCase().startsWith(prefix.toLowerCase())) {
      // Check if this word is in exceptions
      const isException = exceptions.some(exception => 
        word.toLowerCase() === exception.toLowerCase()
      );
      
      if (!isException) {
        results.push(word);
      }
    }
  }
  
  return results;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find token that appears after a digit and ensure it's not at the start of string
  // We need to check that there's a digit before the token and that the position isn't 0
  const matches: string[] = [];
  
  // Find all positions where the token appears
  let pos = 0;
  while ((pos = text.indexOf(token, pos)) !== -1) {
    // Check if there's a digit before this token and it's not at the beginning
    if (pos > 0 && /\d/.test(text[pos - 1])) {
      matches.push(text[pos - 1] + token); // Push full context (digit + token)
    }
    pos += token.length;
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) return false; // At least one uppercase
  if (!/[a-z]/.test(value)) return false; // At least one lowercase
  if (!/[0-9]/.test(value)) return false; // At least one digit
  if (!/[^A-Za-z0-9]/.test(value)) return false; // At least one symbol
  
  // Check for immediate repeated sequences (like "abab")
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Look for IPv6 address patterns anywhere in the text
  // IPv6 shorthand patterns with ::
  if (value.includes('::')) {
    // Check for valid IPv6 shorthand pattern within the text
    const ipv6Pattern = /[0-9a-fA-F]{0,4}::[0-9a-fA-F:]*$/;
    if (ipv6Pattern.test(value)) {
      return true;
    }
  }
  
  // Check for full IPv6 pattern like 2001:db8:1234:5678:abcd:ef01:2345:6789
  const fullPattern = /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Check for any IPv6-like pattern (not full IPv4)
  if (fullPattern.test(value)) {
    return true;
  }
  
  // More flexible pattern: hex digits with colons
  if (/[0-9a-fA-F]*:[0-9a-fA-F:]+/.test(value)) {
    // Make sure it's not a mixed format with IPv4
    if (/[a-fA-F]:\d+\.\d+/.test(value)) {
      return false;
    }
    
    // Make sure it's not pure IPv4
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(value)) {
      return false;
    }
    
    return true;
  }
  
  return false;
}
