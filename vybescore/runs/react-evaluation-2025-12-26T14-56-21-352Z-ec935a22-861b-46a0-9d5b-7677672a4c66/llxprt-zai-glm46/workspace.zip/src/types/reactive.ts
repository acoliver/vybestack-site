/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Subject: An input value that can be read and written
export type Subject<T> = {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers: Set<Observer<any>>
}

// Observer: A computed value or callback that depends on subjects
export type Observer<T> = {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  subjects: Set<Subject<any>>  // The subjects this observer reads from
  getter?: GetterFn<T>          // For computed observers, the getter function
}

let activeObserver: Observer<any> | undefined

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<any> | undefined): Observer<any> | undefined {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Remove observer from all current subjects
  for (const subject of observer.subjects) {
    subject.observers.delete(observer)
  }
  observer.subjects.clear()
  
  const previous = setActiveObserver(observer)
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(previous)
  }
}

// When a subject's value changes, propagate to all dependent observers
export function notifyObservers(subject: Subject<any>): void {
  const observers = Array.from(subject.observers)
  for (const observer of observers) {
    updateObserver(observer)
  }
}
