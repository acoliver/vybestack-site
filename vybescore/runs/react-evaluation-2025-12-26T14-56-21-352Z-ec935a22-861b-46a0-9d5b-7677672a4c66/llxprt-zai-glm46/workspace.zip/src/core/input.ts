/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<Observer<any>>(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this subject as a dependency of the active observer
      observer.subjects.add(s)
      // Register the observer as a dependent of this subject
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    const equalFn = s.equalFn || ((a: T, b: T) => a === b)
    if (equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    // Notify all observers that depend on this subject
    notifyObservers(s)
    return s.value
  }

  return [read, write]
}
