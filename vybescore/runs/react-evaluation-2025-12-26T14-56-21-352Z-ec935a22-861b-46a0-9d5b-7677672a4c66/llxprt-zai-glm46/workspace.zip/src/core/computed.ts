/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  Subject,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: new Set<Subject<any>>(),
  }
  
  const getter: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    if (activeObs) {
      // If there's an active observer, it now depends on everything this computed depends on
      for (const subject of o.subjects) {
        activeObs.subjects.add(subject)
        subject.observers.add(activeObs)
      }
    }
    return o.value as T
  }
  
  o.getter = getter
  
  // Initialize the value by running the update function
  updateObserver(o)
  
  return getter
}
