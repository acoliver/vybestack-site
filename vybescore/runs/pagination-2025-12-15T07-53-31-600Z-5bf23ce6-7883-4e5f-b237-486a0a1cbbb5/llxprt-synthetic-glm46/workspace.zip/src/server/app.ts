import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePaginationParams(pageParam: string | undefined, limitParam: string | undefined): { page: number; limit: number } {
  const page = pageParam ? Number(pageParam) : 1;
  const limit = limitParam ? Number(limitParam) : 5;
  
  // Check for non-numeric values
  if (pageParam !== undefined && isNaN(page)) {
    throw new Error('Page must be a valid number');
  }
  if (limitParam !== undefined && isNaN(limit)) {
    throw new Error('Limit must be a valid number');
  }
  
  // Check for negative or zero values
  if (page < 1) {
    throw new Error('Page must be greater than 0');
  }
  if (limit < 1) {
    throw new Error('Limit must be greater than 0');
  }
  
  // Set reasonable upper limits
  if (page > 1000) {
    throw new Error('Page number too large');
  }
  if (limit > 100) {
    throw new Error('Limit number too large');
  }
  
  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      const { page, limit } = validatePaginationParams(pageParam, limitParam);

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Invalid pagination parameters';
      res.status(400).json({ error: errorMessage });
    }
  });

  return app;
}
