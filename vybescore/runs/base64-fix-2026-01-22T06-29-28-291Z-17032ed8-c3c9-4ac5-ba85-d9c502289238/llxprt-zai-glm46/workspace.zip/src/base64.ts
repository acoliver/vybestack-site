/**
 * Checks if a string is valid Base64 (with or without padding).
 * Base64 format: groups of 4 characters, where padding (=) only appears at the end
 * and there can be 0, 1, or 2 padding characters.
 */
function isValidBase64(input: string): boolean {
  // Check if string contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    return false;
  }

  // Check that padding only appears at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Ensure all characters after the first '=' are also '='
    const paddingOnly = input.slice(paddingIndex);
    if (!/^=+$/.test(paddingOnly)) {
      return false;
    }
    // Padding can only be 1 or 2 characters
    if (paddingOnly.length > 2) {
      return false;
    }
    
    // With padding, the total length must be a multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
    
    // Calculate how many non-padding chars should be in the last group
    const lastGroupPadding = paddingOnly.length;
    const lastGroupNonPadding = 4 - lastGroupPadding;
    const lastGroupStart = input.length - 4;
    
    // Check that the last group has exactly the right number of non-padding chars
    // e.g., "YQ=" has 2 non-padding, "YWI=" has 3 non-padding
    const lastGroupUnpadded = input.slice(lastGroupStart, input.length - lastGroupPadding).length;
    if (lastGroupUnpadded !== lastGroupNonPadding) {
      return false;
    }
  }

  // Check that the unpadded length is valid (not a single extra character)
  const unpaddedLength = input.replace(/=+$/, '').length;
  return !(unpaddedLength % 4 === 1 && unpaddedLength > 0);
}

/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) and includes padding (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Rejects invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  if (!input || input.trim() === '') {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Validate the input string
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters or malformed structure');
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if decoding actually worked (invalid base64 will create empty buffer)
    if (buffer.length === 0 && input.length > 0) {
      throw new Error('Failed to decode Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
