/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Import reactive signal functions and types
import {
  createSignal
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const signal = createSignal(value)

  const read: GetterFn<T> = () => {
    return signal.get()
  }

  const write: SetterFn<T> = (nextValue) => {
    signal.set(nextValue)
    return signal.get()
  }

  return [read, write]
}
