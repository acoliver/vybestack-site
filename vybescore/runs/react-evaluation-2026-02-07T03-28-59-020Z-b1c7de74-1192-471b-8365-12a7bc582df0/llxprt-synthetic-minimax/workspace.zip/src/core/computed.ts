/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn,
  createComputedSignal
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  _options?: { name?: string }
): GetterFn<T> {
  const computed = createComputedSignal(updateFn, value)

  const read: GetterFn<T> = () => {
    // Force recomputation on first access if no value exists
    if (computed.value === undefined) {
      computed.recompute()
    }
    return computed.get()
  }

  return read
}
