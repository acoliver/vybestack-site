/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn,
  getActiveComputation,
  ExtendedSignal
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(
  updateFn: UpdateFn<T>, 
  value?: T
): UnsubscribeFn {
  // Store callback registrations for cleanup
  const registrations: Array<{ signal: ExtendedSignal<unknown>, callback: () => void }> = []
  
  // Create the callback execution that tracks dependencies
  const executeCallback = () => {
    try {
      // Execute the update function, which will track dependencies
      const result = updateFn(value)
      return result
    } catch (e) {
      // Ignore callback errors to prevent breaking the reactive system
    }
  }
  
  // Get active computation to register with
  const activeComputation = getActiveComputation()
  
  if (activeComputation) {
    // Register callback with the active computation
    activeComputation.callbacks.add(executeCallback)
    registrations.push({ signal: activeComputation, callback: executeCallback })
  }
  
  // Return unsubscribe function that cleans up registrations
  const unsubscribe = () => {
    for (const reg of registrations) {
      if (reg.signal.callbacks) {
        reg.signal.callbacks.delete(reg.callback)
      }
    }
  }

  return unsubscribe
}
