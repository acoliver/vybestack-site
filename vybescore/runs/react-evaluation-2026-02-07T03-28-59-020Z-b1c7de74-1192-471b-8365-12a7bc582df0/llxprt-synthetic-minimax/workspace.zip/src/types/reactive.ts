/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Core signal interface
export interface Signal<T> {
  value: T
  get(): T
  set(value: T): void
  notify(): void
  recompute(): void
}

// Extended signal interface with callbacks and dependents
export interface ExtendedSignal<T> extends Signal<T> {
  callbacks: Set<() => void>
  dependents: Set<ExtendedSignal<unknown>>
  dependencies?: Set<ExtendedSignal<unknown>>
  updateFn?: UpdateFn<T>
  isComputing?: boolean
}

// Legacy compatibility types
export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<Observer<unknown>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Global reactive computation state
type ActiveComputation = ExtendedSignal<unknown> | null

let activeComputation: ActiveComputation = null

export function getActiveComputation(): ActiveComputation {
  return activeComputation
}

// Signal implementation with proper dependency tracking
export function createSignal<T>(initial: T): Signal<T> {
  const signal: ExtendedSignal<T> = {
    value: initial,
    callbacks: new Set<() => void>(),
    dependents: new Set<ExtendedSignal<unknown>>(),
    get() {
      // Track dependency when accessed during computation
      const current = getActiveComputation()
      if (current && current !== signal) {
        // Add this signal as dependency of current computation
        if (!current.dependencies) {
          current.dependencies = new Set()
        }
        current.dependencies.add(signal as any)
        
        // Add current computation as dependent of this signal
        if (!signal.dependents) {
          signal.dependents = new Set()
        }
        signal.dependents.add(current as any)
      }
      
      // Trigger recomputation if value hasn't been computed yet
      if (!signal.value && signal.updateFn) {
        signal.recompute()
      }
      
      return signal.value
    },
    set(value: T) {
      if (signal.value !== value) {
        signal.value = value
        signal.notify()
      }
    },
    notify() {
      // Notify all dependent computations to recompute
      if (signal.dependents) {
        for (const dependent of signal.dependents) {
          if (dependent !== signal && 'recompute' in dependent) {
            dependent.recompute()
          }
        }
      }
      
      // Notify all direct callbacks
      for (const callback of signal.callbacks) {
        try {
          callback()
        } catch (e) {
          // Ignore callback errors
        }
      }
    },
    recompute() {
      // Basic signals don't recompute
    }
  }
  return signal
}

export function createComputedSignal<T>(
  updateFn: UpdateFn<T>,
  initial?: T
): ExtendedSignal<T> {
  const computed: ExtendedSignal<T> = {
    value: initial as T,
    updateFn,
    dependencies: new Set<ExtendedSignal<unknown>>(),
    dependents: new Set<ExtendedSignal<unknown>>(),
    callbacks: new Set<() => void>(),
    isComputing: false,
    get() {
      return computed.value
    },
    set(value: T) {
      computed.value = value
      computed.notify()
    },
    recompute() {
      if (computed.isComputing) return
      
      computed.isComputing = true
      const previous = activeComputation
      activeComputation = computed
      
      try {
        // Store current callbacks before recomputation
        const currentCallbacks = new Set(computed.callbacks)
        
        // Clear dependencies to track new ones during recomputation
        if (computed.dependencies) {
          computed.dependencies.clear()
        } else {
          computed.dependencies = new Set()
        }
        
        // Execute the computation function, which will track new dependencies
        const newValue = computed.updateFn!(computed.value)
        const valueChanged = newValue !== computed.value
        
        computed.value = newValue
        computed.isComputing = false
        
        if (valueChanged) {
          // Notify all dependent computations
          const currentDependents = new Set(computed.dependents)
          for (const dependent of currentDependents) {
            if (dependent !== computed && 'recompute' in dependent) {
              (dependent as any).recompute()
            }
          }
          
          // Notify all callbacks (keeping existing ones)
          for (const callback of currentCallbacks) {
            try {
              callback()
            } catch (e) {
              // Ignore callback errors
            }
          }
        }
      } catch (e) {
        computed.isComputing = false
        throw e
      } finally {
        activeComputation = previous
      }
    },
    notify() {
      // Force recomputation of all dependent signals
      if (computed.dependents) {
        for (const dependent of computed.dependents) {
          if (dependent !== computed && 'recompute' in dependent) {
            (dependent as any).recompute()
          }
        }
      }
    }
  }
  
  // Initial computation to establish dependencies
  recompute(computed as any)
  
  return computed
}

export function recompute(computed: ExtendedSignal<unknown>) {
  if (computed.recompute) {
    computed.recompute()
  }
}

// Legacy compatibility functions
export function getActiveObserver(): Observer<unknown> | null {
  return null
}

export function updateObserver<T>(_observer: Observer<T>): T {
  const result = _observer.updateFn(_observer.value)
  _observer.value = result
  return result
}

export function registerSubject<T>(subject: Subject<T>): Subject<T> {
  return subject
}

export function addObserverSubject<T>(_observer: Observer<T>, _subject: Subject<T>): void {
  // Legacy function for compatibility
}

export function notifySubjects<T>(_subject: Subject<T>): void {
  // Legacy function for compatibility
}
