export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses according to common patterns.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9]+([.-]?[a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  const [localPart, domain] = value.split('@');
  
  // Reject double dots
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject leading dots
  if (localPart.startsWith('.')) {
    return false;
  }
  
  // Reject domain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Ensure domain doesn't start or end with hyphen/dot
  if (domain.startsWith('-') || domain.startsWith('.') || domain.endsWith('-')) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except +
  let cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 country code
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length === 11) {
    cleaned = cleaned.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (cleaned.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = cleaned.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = cleaned.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Supports formats like:
 * +54 9 11 1234 5678 (mobile with country code)
 * 011 1234 5678 (landline with trunk prefix)
 * +54 341 123 4567 (landline with country code)
 * 0341 4234567 (landline with trunk prefix)
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // Optional +54 country code, OR trunk prefix 0 when no country code
  // Optional 9 for mobile after country code or trunk
  // Area code: 2-4 digits, must start with 1-9
  // Subscriber number: 6-8 digits
  
  // Try to match the pattern
  const match = cleaned.match(/^(\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, , trunkPrefix, areaCode, subscriber] = match;
  
  // If country code is omitted, trunk prefix must be present
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Area code validation: 2-4 digits, starts with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number: 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accents), apostrophes, hyphens, and spaces
  // Must have at least 2 characters
  // Cannot contain digits, special symbols, or multiple consecutive special chars
  const nameRegex = /^[\p{L}]+(?:['\s-][\p{L}]+)*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with special symbols other than apostrophe, hyphen, space
  const anySpecial = /[^\p{L}'\s-]/u;
  if (anySpecial.test(value)) {
    return false;
  }
  
  // Reject consecutive special characters
  if (/['\s-]{2,}/.test(value)) {
    return false;
  }
  
  // Must be at least 2 characters
  if (value.trim().length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn algorithm checksum.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa, Mastercard, AmEx).
 * Validates prefixes, lengths, and performs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be numeric only
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][2-2][0-1]\d{12})$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Perform Luhn checksum
  return runLuhnCheck(cleaned);
}
