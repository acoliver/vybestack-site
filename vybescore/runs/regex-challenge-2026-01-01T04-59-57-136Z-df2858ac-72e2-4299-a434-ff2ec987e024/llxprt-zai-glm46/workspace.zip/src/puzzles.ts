/**
 * Find words starting with the prefix but excluding banned words.
 * Uses regex to find word boundaries and filter exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  return matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Returns the full match including the digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find token preceded by a digit, capturing the digit as well
  // Use word boundary to ensure we match whole words
  const pattern = new RegExp(`\\d${escapedToken}\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out cases where the match is at the start of the string
  return matches.filter(match => {
    const index = text.indexOf(match);
    return index > 0;
  });
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (2-4 character patterns)
  // E.g., "abab" or "123123" should fail
  for (let i = 2; i <= 4; i++) {
    const repeatPattern = new RegExp(`(.{${i}})\\1`, 'g');
    if (repeatPattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 * Returns true if IPv6 is detected, false if only IPv4 or no valid IP is found.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 regex (to exclude)
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // IPv6 regex patterns
  // Full IPv6 with all 8 groups of 1-4 hex digits
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand (can be at various positions)
  const shorthandIPv6 = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // IPv6 with embedded IPv4 (::ffff:192.168.1.1 format)
  const ipv6WithIPv4 = /\b(?:[0-9a-fA-F]{1,4}:)*:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Check if value contains an IPv6-like pattern
  const hasIPv6Pattern = fullIPv6.test(value) || shorthandIPv6.test(value) || ipv6WithIPv4.test(value);
  
  // Also check if it's purely IPv4
  const hasOnlyIPv4 = ipv4Regex.test(value) && !hasIPv6Pattern;
  
  // Return true if IPv6 pattern is found and it's not just an IPv4 address
  if (hasOnlyIPv4) {
    return false;
  }
  
  return hasIPv6Pattern;
}
