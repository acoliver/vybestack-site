/**
 * Capitalize the first character of each sentence.
 * After .?! sentence terminators, inserts exactly one space and capitalizes.
 * Collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces - collapse multiple spaces to one
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Insert a space after sentence terminators if missing
  // But be careful with abbreviations (e.g., "Mr." or "Dr.")
  // For simplicity, we'll just capitalize after . ? ! followed by space or end
  normalized = normalized.replace(/([.!?])(\S)/g, '$1 $2');
  
  // Capitalize first character
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Capitalize after sentence terminators
  // Use a callback to capitalize the letter after .!? (and optional space)
  normalized = normalized.replace(/([.!?])\s*([a-z])/g, (_, terminator, letter) => {
    return terminator + ' ' + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex matching http, https, www domains
  // Allows domain, path, query params, fragments
  // Excludes trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+[^\s<>"'.,!?;:)]/gi;
  
  const matches = text.match(urlRegex);
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[.,!?;:)]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Always upgrades scheme to https.
 * When path begins with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite when path contains dynamic hints: cgi-bin, query strings, legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // Capture: scheme, domain, path (including query/fragment)
  const urlPattern = /(http?:\/\/)(example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, scheme, domain, path) => {
    // Always upgrade scheme
    const newScheme = 'https://';
    
    // Check if we should skip host rewrite
    // Skip if path contains: cgi-bin, ?, &, =, or legacy extensions
    const skipHostRewrite = /\/cgi-bin\/|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(path);
    
    // Check if path starts with /docs/
    const isDocsPath = /^\/docs\//i.test(path);
    
    if (isDocsPath && !skipHostRewrite) {
      // Rewrite to docs.example.com
      return newScheme + 'docs.example.com' + path;
    } else {
      // Just upgrade scheme
      return newScheme + domain + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = Number.parseInt(monthStr, 10);
  const day = Number.parseInt(dayStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return yearStr;
}
