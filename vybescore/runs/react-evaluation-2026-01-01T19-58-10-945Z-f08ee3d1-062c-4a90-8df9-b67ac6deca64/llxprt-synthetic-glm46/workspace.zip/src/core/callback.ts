/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn: (prevValue?: T) => {
      // Execute the update function
      const newValue = updateFn(prevValue)
      observer.value = newValue
      return newValue
    },
  }
  
  // Register observer to track dependencies and execute immediately
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Mark observer as disposed
    observer.isDisposed = true
    
    // Clean up from all subjects that reference this observer
    observer.value = undefined
    observer.updateFn = () => value!
    
    // Remove this observer from all dependents sets
    if (observer.dependents) {
      for (const dependent of observer.dependents) {
        dependent.dependents?.delete(observer)
      }
      observer.dependents.clear()
    }
  }
}
