/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Convert boolean equal flag to comparison function or use default strict equality
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? Object.is : 
    equal === false ? undefined : 
    typeof equal === 'function' ? equal : undefined;

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !observer.isDisposed) {
      // Set up the relationship: this input is observed by the current observer
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has changed
    const hasChanged = !equalFn || !equalFn(s.value, nextValue)
    if (hasChanged) {
      s.value = nextValue
      // Notify all dependent observers of the change
      const observersToNotify = Array.from(s.observers).filter(obs => !obs.isDisposed)
      for (const obs of observersToNotify) {
        const observer = obs as Observer<unknown>
        updateObserver(observer)
      }
    }
    return s.value
  }

  return [read, write]
}
