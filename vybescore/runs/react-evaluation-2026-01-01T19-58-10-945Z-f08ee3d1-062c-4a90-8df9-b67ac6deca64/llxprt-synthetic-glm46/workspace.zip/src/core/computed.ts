/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Convert boolean equal flag to comparison function or use default strict equality
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? Object.is : 
    equal === false ? undefined : 
    typeof equal === 'function' ? equal : undefined;

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // Execute the update function (which reads the inputs)
      const newValue = updateFn(prevValue)
      
      // Only update if value has changed
      const hasChanged = !equalFn || !equalFn(o.value!, newValue)
      if (hasChanged) {
        o.value = newValue
      }
      
      return o.value!
    },
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  return (): T => {
    // When accessed, register this computed value as a dependency of the current observer
    const observer = getActiveObserver()
    if (observer && !observer.isDisposed) {
      // Track the dependency relationship - this observer depends on this computed value
      if (!o.dependents) {
        o.dependents = new Set()
      }
      o.dependents.add(observer)
    }
    return o.value!
  }
}
