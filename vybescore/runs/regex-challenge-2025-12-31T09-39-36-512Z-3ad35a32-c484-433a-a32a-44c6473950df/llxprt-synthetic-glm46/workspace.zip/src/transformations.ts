/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Capitalizes after .?! punctuation, inserts exactly one space between sentences, and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // Split the text into sentences using regex that handles sentence boundaries
  // This approach preserves punctuation and spacing better
  const sentences = text.split(/([.!?]\s*)/);
  
  // Process each sentence chunk
  const processedChunks = sentences.map((chunk, index) => {
    // If this is punctuation followed by whitespace, keep it as is
    if (chunk.match(/^[.!?]\s*$/)) return chunk;
    
    // Trim the chunk for processing
    const trimmed = chunk.trim();
    
    // Skip empty chunks
    if (trimmed === '') return chunk;
    
    // If this is the first chunk or follows punctuation, capitalize it
    if (index === 0 || (index > 0 && sentences[index - 1] && sentences[index - 1].match(/[.!?]\s*$/))) {
      // Capitalize first letter
      if (trimmed.length > 0) {
        return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
      }
    }
    
    return chunk;
  });
  
  // Join the chunks
  let result = processedChunks.join('');
  
  // Ensure there's exactly one space after punctuation if followed by a letter
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Clean up any double spaces while preserving sentence structure
  result = result.replace(/  +/g, ' ');
  
  return result.trim();
}

/**
 * Finds URLs in the text and returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Match URLs starting with http:// or https:// or www.
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"']+/gi;
  
  // Extract URLs using regex
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?)]+$/, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// globally
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Step 1: Force all http URLs to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Step 2: Handle docs.example.com rewriting
  // Pattern to match URLs starting with https://example.com/docs/ and capture the full path
  const docsUrlRegex = /(https:\/\/example\.com\/docs\/([^?\s&]+))/g;
  
  result = result.replace(docsUrlRegex, 'https://docs.example.com/docs/$2');
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (match) {
    // Extract the year from the third capture group
    return match[3];
  }
  
  return 'N/A';
}
