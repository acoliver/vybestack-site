export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and invalid formats
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check with comprehensive regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick structural validation
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for invalid patterns
  
  // No double dots in local part or domain
  if (value.includes('..')) return false;
  
  // No leading or trailing dots in local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // No underscores in domain
  if (domain.includes('_')) return false;
  
  // No domain starting or ending with hyphen or dot
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) return false;
  }
  
  // No trailing dot in entire email
  if (value.endsWith('.')) return false;
  
  return true;
}

/**
 * Validates US phone numbers with various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix
 * Rejects impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all common separators and spaces for validation
  const cleanNumber = value.replace(/[\s\-().+]/g, '');
  
  // Check if it has optional country code
  const withCountryCode = cleanNumber.startsWith('+1') ? cleanNumber.substring(2) : cleanNumber;
  
  // Must be exactly 10 digits for US numbers
  if (!/^\d{10}$/.test(withCountryCode)) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = withCountryCode.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Full format validation to ensure proper structure
  // Accept patterns like: +1 (212) 555-7890, (212) 555-7890, 212-555-7890, 2125557890
  const phoneRegex = /^(?:\+1[\s\-().+]+|\(\d{3}\)[\s\-]*|\d{3}[\s\-]*)\d{3}[\s\-]*\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers with complex format rules.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation but keep structure intact
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Start with basic validation patterns
  
  // Pattern 1: +54 X XXXX XXXX (with country code)
  // Pattern 2: 0XXX XXXX XXXX (with trunk prefix)
  const phoneRegex = /^(?:\+54[0-9]{10,12}|0[1-9]\d{7,10})$/;
  
  if (!phoneRegex.test(cleanValue)) return false;
  
  // Extract parts for validation
  let areaCode: string;
  let subscriberNumber: string;
  
  if (cleanValue.startsWith('+54')) {
    // Has country code, remove it
    const afterCountry = cleanValue.substring(3);
    
    // Optional mobile indicator 9
    const afterMobile = afterCountry.startsWith('9') ? afterCountry.substring(1) : afterCountry;
    
    // Extract area code (2-4 digits, starting with 1-9)
    let areaCodeEnd = 2;
    while (areaCodeEnd <= 4 && areaCodeEnd < afterMobile.length) {
      areaCodeEnd++;
    }
    
    areaCode = afterMobile.substring(0, Math.min(areaCodeEnd, 4));
    subscriberNumber = afterMobile.substring(areaCode.length);
  } else if (cleanValue.startsWith('0')) {
    // Has trunk prefix but no country code
    const afterTrunk = cleanValue.substring(1);
    
    // Optional mobile indicator 9
    const afterMobile = afterTrunk.startsWith('9') ? afterTrunk.substring(1) : afterTrunk;
    
    // Extract area code (2-4 digits, starting with 1-9)
    let areaCodeEnd = 2;
    while (areaCodeEnd <= 4 && areaCodeEnd < afterMobile.length) {
      areaCodeEnd++;
    }
    
    areaCode = afterMobile.substring(0, Math.min(areaCodeEnd, 4));
    subscriberNumber = afterMobile.substring(areaCode.length);
  } else {
    return false; // Must have country code or trunk prefix
  }
  
  // Area code validation (2-4 digits, starting with non-zero)
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Using a simpler approach that works with Rollup build
  const nameRegex = /^[a-zA-Z\u00C0-\u024F\s'\-]+$/;
  
  // Quick regex check
  if (!nameRegex.test(value)) return false;
  
  // No digits allowed
  if (/\d/.test(value)) return false;
  
  // No consecutive spaces or punctuation (except apostrophes/hyphens within words)
  if (/\s{2,}|'{2,}|-{2,}/.test(value)) return false;
  
  // Must have at least one letter
  if (!/[a-zA-Z\u00C0-\u024F]/.test(value)) return false;
  
  return true;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes from the card number
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits and reasonable length (13-19 digits)
  if (!/^\d{13,19}$/.test(cleanNumber)) return false;
  
  // Card prefix patterns for Visa, Mastercard, and AmEx
  const visaRegex = /^4\d{12,18}$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any supported card type
  if (!visaRegex.test(cleanNumber) && !mastercardRegex.test(cleanNumber) && !amexRegex.test(cleanNumber)) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanNumber);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    const digit = parseInt(number[i], 10);
    
    if (isEven) {
      const doubled = digit * 2;
      sum += doubled > 9 ? doubled - 9 : doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}