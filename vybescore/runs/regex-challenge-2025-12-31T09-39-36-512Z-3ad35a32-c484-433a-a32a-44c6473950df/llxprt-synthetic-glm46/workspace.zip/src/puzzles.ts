/**
 * Finds words starting with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex use
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to find words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches
  const allMatches = text.match(wordRegex) || [];
  
  // Filter out the exceptions
  const filteredMatches = allMatches.filter(word => 
    !exceptions.includes(word.toLowerCase())
  );
  
  // Remove duplicates and return
  return [...new Set(filteredMatches)];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex use
  const escapedToken = token.replace(/[.*+?^${}()|[\]]/g, '\\$&');
  
  // Create regex pattern to find token preceded by a digit (but not at the start)
  // Use a simpler approach: capture the digit + token, then just return the digit+token
  const tokenRegex = new RegExp(`(\\d${escapedToken})`, 'g');
  
  // Find all matches
  const matches = text.match(tokenRegex) || [];
  
  // Filter out matches at the beginning of the string
  const filteredMatches = matches.filter(match => {
    const index = text.indexOf(match);
    return index > 0; // Not at position 0
  });
  
  return [...new Set(filteredMatches)];
}

/**
 * Validates passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Length check: at least 10 characters
  if (value.length < 10) return false;
  
  // Character type checks using regex
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSpecialChar = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?.]/.test(value);
  
  // No whitespace allowed
  const hasWhitespace = /\s/.test(value);
  
  // Check for immediate repeated sequences (like 'abab')
  const repeatedSequences = /(.)\1+/;
  const hasRepeatedChars = repeatedSequences.test(value);
  
  // Check for repeated patterns of length 2-4
  const repeatedPatterns = /(.{2,4})\1+/;
  const hasRepeatedPatterns = repeatedPatterns.test(value);
  
  return hasUppercase && hasLowercase && hasDigit && hasSpecialChar && !hasWhitespace && !hasRepeatedPatterns && !hasRepeatedChars;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, ensure it's not an IPv4 address
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  if (ipv4Regex.test(value.trim())) return false;
  
  // Look for IPv6 patterns anywhere in the text
  // Basic IPv6 pattern with :: shorthand support
  const ipv6Pattern = /([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}|::([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|:[0-9a-fA-F]{1,4}/;
  
  return ipv6Pattern.test(value.trim());
}
