/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    observers: new Set(), // Add observers set for consistency with computed values
  }
  
  let disposed = false
  
  const runUpdate = () => {
    if (disposed) return
    updateObserver(observer)
  }
  
  // Initial run to set up dependencies
  runUpdate()
  
  return () => {
    if (disposed) return
    disposed = true
    // Clear the update function to prevent further execution
    observer.updateFn = () => value!
  }
}
