/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(), // Add observers set for computed values
  }
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      observer.observers!.add(activeObserver)
    }
    
    // Store the previous value to check if it changed
    const previousValue = observer.value
    
    // Update the observer, which will:
    // 1. Set this observer as the active observer during the update
    // 2. Call the updateFn
    // 3. Set the result as the observer's value
    // 4. Restore the previous active observer
    updateObserver(observer)
    
    // Check if the value changed and notify observers if it did
    if (previousValue !== observer.value && observer.observers) {
      observer.observers.forEach(obs => updateObserver(obs as Observer<unknown>))
    }
    
    // Return the updated value
    return observer.value as T
  }
  
  return getter
}
