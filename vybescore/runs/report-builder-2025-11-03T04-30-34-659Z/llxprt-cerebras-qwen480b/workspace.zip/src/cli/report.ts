import { readFileSync } from 'fs';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Define supported formats
const FORMATTERS = {
  markdown: renderMarkdown,
  text: renderText,
};

// Parse command line arguments
function parseArgs(): { 
  dataFile: string; 
  format: string; 
  outputFile?: string; 
  includeTotals: boolean 
} {
  const args = process.argv.slice(2);
  const dataFile = args[0];
  
  if (!dataFile) {
    throw new Error('Missing data file argument');
  }
  
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    throw new Error('Missing format argument');
  }
  const format = args[formatIndex + 1];
  
  const outputFileIndex = args.indexOf('--output');
  const outputFile = outputFileIndex !== -1 && outputFileIndex + 1 < args.length 
    ? args[outputFileIndex + 1] 
    : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return { dataFile, format, outputFile, includeTotals };
}

// Validate report data
function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid data: not an object');
  }
  
  if (!('title' in data) || typeof data.title !== 'string') {
    throw new Error('Invalid data: missing or invalid title');
  }
  
  if (!('summary' in data) || typeof data.summary !== 'string') {
    throw new Error('Invalid data: missing or invalid summary');
  }
  
  if (!('entries' in data) || !Array.isArray(data.entries)) {
    throw new Error('Invalid data: missing or invalid entries');
  }
  
  for (const entry of data.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid data: entry is not an object');
    }
    
    if (!('label' in entry) || typeof entry.label !== 'string') {
      throw new Error('Invalid data: missing or invalid label in entry');
    }
    
    if (!('amount' in entry) || typeof entry.amount !== 'number') {
      throw new Error('Invalid data: missing or invalid amount in entry');
    }
  }
}

// Main function
function main() {
  try {
    const { dataFile, format, outputFile, includeTotals } = parseArgs();
    
    if (!(format in FORMATTERS)) {
      throw new Error(`Unsupported format: ${format}`);
    }
    
    const jsonData = readFileSync(dataFile, 'utf8');
    const data: unknown = JSON.parse(jsonData);
    
    validateReportData(data);
    
    const formatter = FORMATTERS[format as keyof typeof FORMATTERS];
    const output = formatter(data, { includeTotals });
    
    if (outputFile) {
      // Using built-in Node.js writeFile (would need to be imported from fs)
      throw new Error('--output option is not implemented since we only use built-in Node.js APIs');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    } else {
      console.error('Unknown error occurred');
      process.exit(1);
    }
  }
}

main();