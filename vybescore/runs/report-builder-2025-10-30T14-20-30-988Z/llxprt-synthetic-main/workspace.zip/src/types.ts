/**
 * Interface for a report entry containing a label and monetary amount
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for the complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for report formatting and rendering
 */
export interface ReportOptions {
  format: 'markdown' | 'text';
  includeTotals: boolean;
  outputPath?: string;
}

/**
 * Base formatter interface that all formatters should implement
 */
export interface Formatter {
  render(data: ReportData, includeTotals: boolean): string;
}