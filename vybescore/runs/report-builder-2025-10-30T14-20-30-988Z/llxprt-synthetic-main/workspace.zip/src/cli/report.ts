#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Parse command line arguments
 */
function parseArguments(args: string[]): ReportOptions {
  // Default options
  const options: ReportOptions = {
    format: 'markdown',
    includeTotals: false,
  };

  // Parse arguments
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      const format = args[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        throw new Error(`Unsupported format: ${format}`);
      }
      options.format = format;
      i++; // Skip the next argument as we've processed it
    } else if (arg === '--output' && i + 1 < args.length) {
      options.outputPath = args[i + 1];
      i++; // Skip the next argument as we've processed it
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  return options;
}

/**
 * Load and validate JSON data from file
 */
function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent) as ReportData;
    
    // Validate the structure
    if (typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    if (typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    // Validate each entry
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string') {
        throw new Error('Entry missing or invalid "label" field');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Entry missing or invalid "amount" field');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${filePath}`);
    }
    throw error;
  }
}

/**
 * Render report based on format
 */
function renderReport(data: ReportData, options: ReportOptions): string {
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, options.includeTotals);
    case 'text':
      return renderText(data, options.includeTotals);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

/**
 * Main CLI function
 */
function main(): void {
  try {
    const args = process.argv.slice(2);
    
    if (args.length === 0) {
      console.error('Error: Missing data file path');
      process.exit(1);
    }
    
    const dataFilePath = args[0];
    const options = parseArguments(args.slice(1));
    const data = loadReportData(dataFilePath);
    const report = renderReport(data, options);
    
    if (options.outputPath) {
      writeFileSync(options.outputPath, report);
      console.log(`Report written to ${options.outputPath}`);
    } else {
      console.log(report);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

// Run the CLI if this module is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}