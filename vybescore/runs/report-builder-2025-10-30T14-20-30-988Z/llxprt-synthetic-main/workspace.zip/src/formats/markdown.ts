import type { ReportData, Formatter } from '../types.js';

/**
 * Markdown formatter implementation
 */
export class MarkdownFormatter implements Formatter {
  render(data: ReportData, includeTotals: boolean): string {
    const { title, summary, entries } = data;
    
    // Start with title as H1
    let result = `# ${title}\n\n`;
    
    // Add summary
    result += `${summary}\n\n`;
    
    // Add entries section
    result += '## Entries\n';
    
    // Add each entry as a bullet list
    for (const entry of entries) {
      result += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
    }
    
    // Add total if requested
    if (includeTotals) {
      const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
      result += `\n**Total:** $${total.toFixed(2)}`;
    }
    
    return result;
  }
}

/**
 * Function to render markdown format
 */
export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  const formatter = new MarkdownFormatter();
  return formatter.render(data, includeTotals);
}