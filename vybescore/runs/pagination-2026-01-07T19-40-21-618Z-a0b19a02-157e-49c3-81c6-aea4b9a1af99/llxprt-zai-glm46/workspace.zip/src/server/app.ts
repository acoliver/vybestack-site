import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;

function validatePageLimit(pageParam: string | undefined, limitParam: string | undefined): { error?: string; page?: number; limit?: number } {
  const page = pageParam ? Number(pageParam) : 1;
  const limit = limitParam ? Number(limitParam) : 5;

  if (pageParam !== undefined && (Number.isNaN(page) || !Number.isFinite(page))) {
    return { error: 'Invalid page parameter: must be a number' };
  }

  if (limitParam !== undefined && (Number.isNaN(limit) || !Number.isFinite(limit))) {
    return { error: 'Invalid limit parameter: must be a number' };
  }

  if (page < 1) {
    return { error: 'Invalid page parameter: must be greater than 0' };
  }

  if (limit < 1) {
    return { error: 'Invalid limit parameter: must be greater than 0' };
  }

  if (limit > MAX_LIMIT) {
    return { error: `Invalid limit parameter: must not exceed ${MAX_LIMIT}` };
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validatePageLimit(pageParam, limitParam);

    if (validation.error) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
