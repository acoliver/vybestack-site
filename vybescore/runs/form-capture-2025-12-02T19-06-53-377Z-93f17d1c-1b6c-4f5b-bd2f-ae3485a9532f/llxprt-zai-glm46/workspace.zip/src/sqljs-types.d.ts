declare module 'sql.js' {
  interface QueryResult {
    columns: string[];
    values: unknown[][];
  }
  
  export class Database {
    constructor(data?: ArrayBuffer);
    
    run(sql: string, ...params: unknown[]): void;
    exec(sql: string, ...params: unknown[]): QueryResult[];
    prepare(sql: string): Statement;
    export(): ArrayBuffer;
    close(): void;
  }
  
  export class Statement {
    run(...params: unknown[]): { changes: number; lastInsertRowid: number };
    get(...params: unknown[]): Record<string, unknown> | undefined;
    all(...params: unknown[]): Record<string, unknown>[];
    free(): void;
  }
  
  const sql: {
    Database: typeof Database;
  };
  
  export default sql;
}