import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

let db: import('sql.js').Database | null = null;

async function initializeDatabase(): Promise<void> {
  try {
    const initSql = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    
    const SQL = await import('sql.js');
    
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    
    const sqlJsModule = await (SQL.default as unknown as () => Promise<typeof import('sql.js')>)();
    
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      db = new sqlJsModule.Database(dbBuffer.buffer as ArrayBuffer);
      console.log('Database loaded from existing file');
    } else {
      db = new sqlJsModule.Database();
      if (db) {
        db.run(initSql);
        console.log('Database created with new schema');
      }
    }
    
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
  console.log('Database saved to disk');
}

function validateFormData(data: Partial<FormData>): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};
  
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!/^[+]?\d[\d\s\-()]*$/.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

const app = express();
const PORT = process.env.PORT || 3535;

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates'));

app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    formData: {},
    errors: {},
    success: false
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      formData,
      errors: validation.errors,
      success: false
    });
  }
  
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    console.log('Attempting to save submission...');
    stmt.run(
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    );
    console.log('Submission inserted into database');
    
    stmt.free();
    
    try {
      saveDatabase();
      console.log('Database saved successfully, redirecting...');
      res.redirect('/thank-you');
    } catch (saveError) {
      console.error('Failed to save database:', saveError);
      res.status(500).render('form', {
        formData,
        errors: { general: 'Failed to save submission. Please try again.' },
        success: false
      });
    }
    
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      formData,
      errors: { general: 'Failed to save submission. Please try again.' },
      success: false
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  
  const gracefulShutdown = (signal: string) => {
    console.log(`
Received ${signal}. Shutting down gracefully...`);
    
    server.close(() => {
      console.log('HTTP server closed');
      
      if (db) {
        db.close();
        console.log('Database connection closed');
      }
      
      process.exit(0);
    });
    
    setTimeout(() => {
      console.error('Could not close connections in time, forcefully shutting down');
      process.exit(1);
    }, 5000);
  };
  
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
