/**
 * Capitalize sentences in text
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing by replacing multiple spaces with single spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Capitalize first character of each sentence
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, start, letter) => {
    return start + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Extract URLs from text
 */
export function extractUrls(text: string): string[] {
  // Match URLs, then trim trailing punctuation
  const urlRegex = /\bhttps?:\/\/\S+/g;
  const matches = text.match(urlRegex) || [];
  
  // Trim trailing punctuation
  const cleanedMatches = matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;:!?)]*$/, '');
  });
  
  return cleanedMatches;
}

/**
 * Replace http:// with https://
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite docs URLs
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/]+)(\/docs\/[^\s.,;:!?)]+[^.,;:!?)]?)/g, (match, host, path) => {
    // Check for dynamic hints or legacy extensions
    const hasDynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
    
    if (!hasDynamicHints && path.startsWith('/docs/')) {
      // Rewrite to docs subdomain
      const newHost = `docs.${host}`;
      return `https://${newHost}${path}`;
    }
    
    // Just upgrade to https
    return `https://${host}${path}`;
  });
}

/**
 * Extract year from mm/dd/yyyy format
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}
