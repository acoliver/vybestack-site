/**
 * Find words starting with prefix but excluding exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with prefix
  const regex = new RegExp(`\\b${escapedPrefix}\\w*`, 'g');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of token after a digit and not at start
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Return the full match including the digit
  const fullMatchRegex = new RegExp(`\\d${escapedToken}`, 'g');
  const fullMatches = text.match(fullMatchRegex) || [];
  
  return fullMatches;
}

/**
 * Check if password meets strong password requirements
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 123123)
  // This regex looks for any 2+ character sequence that's repeated immediately
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4
 */
export function containsIPv6(value: string): boolean {
  // First, rule out IPv4 addresses
  // IPv4 pattern: 4 groups of 1-3 digits separated by dots
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns to match various formats
  // Pattern 1: Full IPv6 with 8 groups (some may be :: shorthand)
  const fullIpv6Pattern = /(?<![:\w])([a-f0-9]{0,4}:){0,7}(:[a-f0-9]{0,4}){0,7}([a-f0-9]{0,4})?(?![:\w])/i;
  
  // Pattern 2: Shorthand notation like ::1 or ::
  const shorthandPattern = /(?<![:\w])::(?![:\w])/;
  
  // Check for either pattern
  return fullIpv6Pattern.test(value) || shorthandPattern.test(value);
}