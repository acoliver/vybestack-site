export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email address
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that accepts typical addresses like name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  return emailRegex.test(value);
}

/**
 * Validate US phone number
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except optional leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1 (optional)
  let remaining = cleaned;
  if (remaining.startsWith('+1')) {
    remaining = remaining.substring(2);
  } else if (remaining.startsWith('+')) {
    return false; // + without 1 is not valid for US
  }
  
  // Check length (10 digits)
  if (!/^\d{10}$/.test(remaining)) {
    return false;
  }
  
  // Check area code (first digit cannot be 0 or 1)
  const areaCode = remaining.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone number
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters and spaces/hyphens, keep + sign
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Optional country code +54
  let remaining = cleaned;
  let hasCountryCode = false;
  
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.substring(3);
  }
  
  // Optional trunk prefix 0 (only if no country code)
  let hasTrunkPrefix = false;
  if (!hasCountryCode && remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.substring(1);
  }
  
  // Optional mobile indicator 9 (only if we had a country code)
  let hasMobileIndicator = false;
  if (hasCountryCode && remaining.startsWith('9')) {
    hasMobileIndicator = true;
    remaining = remaining.substring(1);
  }
  
  // At this point, remaining should be: areaCode + subscriberNumber
  // areaCode: 2-4 digits starting with 1-9
  // subscriberNumber: 6-8 digits
  
  if (remaining.length < 8 || remaining.length > 12) {
    return false;
  }
  
  // Try to extract area code (2-4 digits)
  let areaCodeLength = 0;
  for (let len = 4; len >= 2; len--) {
    if (remaining.length >= len + 6) {
      const areaCode = remaining.substring(0, len);
      if (/^[1-9]\d{1,3}$/.test(areaCode)) {
        areaCodeLength = len;
        break;
      }
    }
  }
  
  if (areaCodeLength === 0) {
    return false;
  }
  
  const areaCode = remaining.substring(0, areaCodeLength);
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  const subscriber = remaining.substring(areaCodeLength);
  
  // Check subscriber number (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  if (!/^\d{6,8}$/.test(subscriber)) {
    return false;
  }
  
  // When country code is omitted, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal name
 */
export function isValidName(value: string): boolean {
  // Reject names with digits or special symbols
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  // Reject exotic symbols like X Æ A-12
  if (/[^\p{L}\p{M}\s'-]/u.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  // Must not be empty or only whitespace
  if (value.trim().length === 0) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to run Luhn checksum
 */
function runLuhnCheck(cardNumber: string): boolean {
  // Remove all non-digit characters
  const digits = cardNumber.replace(/\D/g, '');
  
  if (digits.length === 0) {
    return false;
  }
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card number
 */
export function isValidCreditCard(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  // Check Visa (starts with 4, 16 digits)
  if (/^4\d{15}$/.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  // Check Mastercard (starts with 5[1-5] or 2[2-7], 16 digits)
  if (/^(5[1-5]\d{14}|2[2-7]\d{14})$/.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  // Check AmEx (starts with 34 or 37, 15 digits)
  if (/^(34|37)\d{13}$/.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  return false;
}
