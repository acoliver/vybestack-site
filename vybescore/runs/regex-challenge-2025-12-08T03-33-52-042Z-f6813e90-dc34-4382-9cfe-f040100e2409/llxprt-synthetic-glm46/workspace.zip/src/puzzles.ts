/**
 * Find words starting with a specific prefix, excluding specified exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix and exceptions
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(word => 
    word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  );
  
  // Create negative lookahead for exceptions
  const exceptionsPattern = escapedExceptions.length > 0 
    ? `(?!${escapedExceptions.join('|')})` 
    : '';
  
  // Pattern: words starting with prefix, but not matching exceptions
  // \b matches word boundary
  const wordRegex = new RegExp(`\\b${exceptionsPattern}${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex);
  return matches ? [...new Set(matches)] : [];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: token preceded by a digit, but not at the beginning of the string
  // (?<=\d) is a positive lookbehind that requires a digit before the token
  // (?!^) is a negative lookahead that prevents matching at the beginning
  const tokenRegex = new RegExp(`(?<!^)(?<=\\d)${escapedToken}`, 'g');
  
  try {
    const matches = text.match(tokenRegex);
    // If lookbehind is supported, we need to combine the digit and token
    // to match the expected output format
    if (matches) {
      // Create a fallback regex to capture the digit+token pairs
      const fallbackRegex = new RegExp(`(\\d)(${escapedToken})`, 'g');
      const results: string[] = [];
      let match;
      
      while ((match = fallbackRegex.exec(text)) !== null) {
        results.push(match[1] + match[2]);
      }
      
      return results;
    }
    return [];
  } catch (e) {
    // Fallback if lookbehind is not supported
    // Match token after digit without using lookbehind
    const fallbackRegex = new RegExp(`(\\d)(${escapedToken})`, 'g');
    const results: string[] = [];
    let match;
    
    while ((match = fallbackRegex.exec(text)) !== null) {
      results.push(match[1] + match[2]);
    }
    
    return results;
  }
}

/**
 * Check if a password meets strong criteria
 */
export function isStrongPassword(value: string): boolean {
  // Password must:
  // - Be at least 10 characters
  // - Contain at least one uppercase letter
  // - Contain at least one lowercase letter
  // - Contain at least one digit
  // - Contain at least one symbol
  // - Not contain any whitespace
  // - Not contain immediate repeated sequences (e.g., 'abab', '1212')
  
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase, one lowercase, one digit, one symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^\w\s]/.test(value); // Non-word, non-space characters
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  // This regex detects patterns where a 2-character sequence repeats immediately
  // (\w) captures any word character, (\d) captures any digit
  // (\w{2}) captures 2 consecutive characters
  // \1 matches the same 2-character sequence again
  const repeatedPattern = /(\w{2})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses and ensure IPv4 addresses don't trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns must be detected
  // IPv4 addresses must NOT trigger a positive result
  
  // Full form: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  const fullForm = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Short form with :: compression at the end
  const endCompressed = /\b(?:[0-9a-fA-F]{1,4}:){1,7}:/;
  
  // Short form with :: compression at the beginning
  const beginCompressed = /\b::(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b/;
  
  // Short form with :: compression in the middle
  const middleCompressed = /\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b/;
  
  // Simple :: with one group
  const simpleCompressed = /\b::[0-9a-fA-F]{1,4}\b/;
  
  // Just ::
  const justCompressed = /\b::\b/;
  
  // Leading :
  const leadingColon = /\b:(?::[0-9a-fA-F]{1,4}){1,7}\b/;
  
  // Check for IPv6 matches
  if (fullForm.test(value) || 
      endCompressed.test(value) || 
      beginCompressed.test(value) || 
      middleCompressed.test(value) || 
      simpleCompressed.test(value) || 
      justCompressed.test(value) || 
      leadingColon.test(value)) {
    return true;
  }
  
  // Additional check for IPv6 with embedded IPv4
  const ipv6WithIPv4Regex = /\b(?:[0-9a-fA-F]{1,4}:){5}(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv6WithIPv4Regex.test(value)) {
    return true;
  }
  
  // If no IPv6 match, return false
  // (This also ensures plain IPv4 addresses don't trigger a positive result)
  return false;
}