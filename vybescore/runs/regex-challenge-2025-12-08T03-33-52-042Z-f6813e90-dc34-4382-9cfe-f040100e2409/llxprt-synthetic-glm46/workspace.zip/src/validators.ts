export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper format rules
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // - User part: allows letters, numbers, dots, hyphens, plus, apostrophes
  // - Domain part: allows letters, numbers, hyphens but not underscores
  // - TLD: 2-63 letters
  // Rejects: double dots, trailing dots, leading/trailing hyphens in domain parts
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,63}$/;
  
  // Additional checks for specific edge cases
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject emails with consecutive dots in local part
  if (value.split('@')[0].includes('..')) {
    return false;
  }
  
  // Reject emails with domain containing underscores
  if (value.split('@')[1].includes('_')) {
    return false;
  }
  
  // Reject emails with trailing dots or hyphens in domain parts
  const domain = value.split('@')[1];
  if (domain.endsWith('.') || domain.endsWith('-')) {
    return false;
  }
  
  // Reject emails with leading dots or hyphens in domain parts
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.startsWith('.') || part.endsWith('-') || part.endsWith('.')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate US phone numbers
 */
export function isValidUSPhone(value: string): boolean {
  // Remove common separators
  const cleanValue = value.replace(/[\s-()]/g, '');
  
  // Check if string contains only digits now
  if (!/^\+?\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Remove +1 country code if present
  let digits = cleanValue;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length > 10) {
    digits = digits.substring(1);
  }
  
  // Must be exactly 10 digits for standard US numbers
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (digits[0] === '0' || digits[0] === '1') {
    return false;
  }
  
  // Exchange code cannot start with 0 or 1
  if (digits[3] === '0' || digits[3] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove common separators (spaces, hyphens, parentheses)
  const cleanValue = value.replace(/[\s-()]/g, '');
  
  // Check if string contains only digits and optional leading +
  if (!/^\+?\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Extract components
  let digits = cleanValue;
  let hasCountryCode = false;
  
  // Check for country code +54
  if (digits.startsWith('+54')) {
    hasCountryCode = true;
    digits = digits.substring(3); // Remove +54
  }
  
  // Check for trunk prefix 0 (required when no country code)
  let hasTrunkPrefix = false;
  if (digits.startsWith('0')) {
    hasTrunkPrefix = true;
    digits = digits.substring(1); // Remove 0
  }
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check for mobile indicator 9
  if (digits.startsWith('9')) {
    digits = digits.substring(1); // Remove 9
  }
  
  // Area code parsing
  // Area codes in Argentina are 2-4 digits, starting with 1-9
  let areaCode = '';
  
  // Try 2-digit area code first (for Buenos Aires 11)
  if (digits.length >= 8) {
    areaCode = digits.substring(0, 2);
    const subscriberNumber = digits.substring(2);
    
    // Check if the remaining digits form a valid subscriber number (6-8 digits)
    if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
      // Valid area code should not start with 0
      return areaCode.length >= 2 && areaCode.length <= 4 && !areaCode.startsWith('0');
    }
  }
  
  // Try 3-digit area code
  if (digits.length >= 9) {
    areaCode = digits.substring(0, 3);
    const subscriberNumber = digits.substring(3);
    
    if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
      return areaCode.length >= 2 && areaCode.length <= 4 && !areaCode.startsWith('0');
    }
  }
  
  // Try 4-digit area code
  if (digits.length >= 10) {
    areaCode = digits.substring(0, 4);
    const tempSubscriberNumber = digits.substring(4);
    
    if (tempSubscriberNumber.length >= 6 && tempSubscriberNumber.length <= 8) {
      return areaCode.length >= 2 && areaCode.length <= 4 && !areaCode.startsWith('0');
    }
  }
  
  return false;
}

/**
 * Validate names with proper character rules
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Minimum 2 characters (to accommodate initials like "J. K.")
  if (value.length < 2) {
    return false;
  }
  
  // Reject names that contain digits or symbols other than allowed ones
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  return nameRegex.test(value);
}

/**
 * Luhn algorithm implementation for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Starting from the rightmost digit, double every second digit
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit cards based on format and Luhn algorithm
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens from card number
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if card number contains only digits
  if (!/^\d+$/.test(cleanNumber)) {
    return false;
  }
  
  // Check for valid prefixes and lengths
  const visa = /^4\d{12}(\d{3})?$/; // 13 or 16 digits starting with 4
  const mastercard = /^5[1-5]\d{14}$/; // 16 digits, prefix 51-55
  const mastercard2 = /^2(22[2-9]\d|2[3-9]\d{2}|[3-6]\d{3}|7([01]\d|20)\d)\d{12}$/; // New Mastercard ranges
  const amex = /^3[47]\d{13}$/; // 15 digits, prefix 34 or 37
  
  // Check card number format
  const isValidFormat = visa.test(cleanNumber) ||
    mastercard.test(cleanNumber) ||
    mastercard2.test(cleanNumber) ||
    amex.test(cleanNumber);
    
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanNumber);
}