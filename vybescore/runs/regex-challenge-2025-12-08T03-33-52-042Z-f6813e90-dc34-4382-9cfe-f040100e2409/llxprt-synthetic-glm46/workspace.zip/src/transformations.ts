/**
 * Capitalize the first character of each sentence with proper spacing
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split text by sentence delimiters (.!?), keeping the delimiters
  const sentences = text.split(/([.!?])/);
  let result = '';
  let i = 0;
  
  while (i < sentences.length) {
    // Process a complete sentence (text + delimiter)
    if (sentences[i]) {
      let sentence = sentences[i];
      
      // Remove extra spaces at the beginning
      sentence = sentence.replace(/^\s+/, '');
      
      // Capitalize the first character of the sentence
      if (sentence.length > 0) {
        sentence = sentence[0].toUpperCase() + sentence.substr(1);
      }
      
      result += sentence;
    }
    
    // Add delimiter if exists
    if (i + 1 < sentences.length && sentences[i + 1]) {
      result += sentences[i + 1];
      i++; // Skip the delimiter in the next iteration
    }
    
    // Add exactly one space after delimiter if there's more content
    if (i + 1 < sentences.length && sentences[i + 1] && /^\s*$/.test(sentences[i + 1]) === false) {
      result += ' ';
    }
    
    i++;
  }
  
  return result;
}

/**
 * Extract all URLs from text, without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex that captures http/https/ftp and www URLs
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"'{}|^`[\]]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation: .,?!;:)]}
    return url.replace(/[.,?!;:)\]}}]+$/, '');
  });
}

/**
 * Replace all http:// URLs with https://
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite documentation URLs with special rules
 */
export function rewriteDocsUrls(text: string): string {
  // Match http and https URLs
  return text.replace(
    /(https?):\/\/([^/]+)(\/[^?#]*)?(\?[^#]*)?(#.*)?/gi,
    (match, scheme, host, path, query, fragment) => {
      // Always upgrade to https
      scheme = 'https';
      
      // Default to root path if none provided
      path = path || '/';
      
      // Check if we should rewrite the host
      let shouldRewriteHost = false;
      
      // Rewrite if path starts with /docs/
      if (path.startsWith('/docs/')) {
        shouldRewriteHost = true;
      }
      
      // Skip rewrite if path contains dynamic hints or legacy extensions
      const dynamicPatterns = [
        '/cgi-bin',
        '.jsp',
        '.php',
        '.asp',
        '.aspx',
        '.do',
        '.cgi',
        '.pl',
        '.py'
      ];
      
      // Check if path contains any dynamic patterns
      for (const pattern of dynamicPatterns) {
        if (path.includes(pattern)) {
          shouldRewriteHost = false;
          break;
        }
      }
      
      // If path has query string parameters, don't rewrite host
      if (query) {
        shouldRewriteHost = false;
      }
      
      // Perform host rewrite if needed
      if (shouldRewriteHost) {
        host = 'docs.' + host;
      }
      
      // Construct final URL
      return scheme + '://' + host + path + (query || '') + (fragment || '');
    }
  );
}

/**
 * Extract year from date string in mm/dd/yyyy format
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format specifically
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (match) {
    const month = parseInt(match[1], 10);
    const day = parseInt(match[2], 10);
    
    // Validate day based on month
    const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Using 29 for February to handle leap years
    if (day <= daysInMonth[month - 1]) {
      return match[3]; // Return the year
    }
  }
  
  return 'N/A';
}