#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, ReportOptions, ReportRenderer } from '../index.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Parse command line arguments
 */
function parseArguments(): { filePath: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const filePath = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return { filePath, format, outputPath, includeTotals };
}

/**
 * Load and validate JSON data
 */
function loadData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data: ReportData = JSON.parse(fileContent);
    
    // Validate data structure
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field in JSON data');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field in JSON data');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field in JSON data');
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error loading data: ${error.message}`);
    } else {
      console.error('Unknown error loading data');
    }
    process.exit(1);
  }
}

/**
 * Get the appropriate renderer for the requested format
 */
function getRenderer(format: string): ReportRenderer {
  const formatters: Record<string, ReportRenderer> = {
    markdown: renderMarkdown,
    text: renderText
  };
  
  const renderer = formatters[format];
  if (!renderer) {
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
  }
  
  return renderer;
}

/**
 * Main function
 */
function main(): void {
  const { filePath, format, outputPath, includeTotals } = parseArguments();
  
  const data = loadData(filePath);
  const options: ReportOptions = { includeTotals };
  const renderer = getRenderer(format);
  
  const output = renderer(data, options);
  
  if (outputPath) {
    writeFileSync(outputPath, output);
    console.log(`Report saved to ${outputPath}`);
  } else {
    console.log(output);
  }
}

// Run the CLI
main();