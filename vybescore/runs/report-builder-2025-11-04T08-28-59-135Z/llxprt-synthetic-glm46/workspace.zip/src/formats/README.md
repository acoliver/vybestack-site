# Report Formatters

This directory contains formatter modules for different output formats.

Each formatter module should export a `render` function with the following signature:

```typescript
export const render: ReportRenderer = (data: ReportData, options: ReportOptions): string => {
  // Implementation here
};
```

Available formatters:

1. **markdown.ts** - Renders reports in Markdown format
2. **text.ts** - Renders reports in plain text format