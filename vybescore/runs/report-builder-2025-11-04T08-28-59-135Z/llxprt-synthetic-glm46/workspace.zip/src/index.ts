/**
 * Report data interface
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Report formatting options
 */
export interface ReportOptions {
  includeTotals: boolean;
}

/**
 * Report renderer function signature
 */
export type ReportRenderer = (data: ReportData, options: ReportOptions) => string;