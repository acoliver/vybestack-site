#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * CLI arguments interface
 */
interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parse command line arguments
 */
function parseArgs(argv: string[]): CliArgs {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: CliArgs = {
    dataFile: args[0],
    format: '',
    includeTotals: false,
  };
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      result.format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      result.outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      console.error(`Error: Unknown option ${arg}`);
      process.exit(1);
    }
  }
  
  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return result;
}

/**
 * Validate report data structure
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (string expected)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (string expected)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (array expected)');
  }
  
  const entries = obj.entries as unknown[];
  
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
      throw new Error(`Invalid JSON: entry ${i} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid "label" field (string expected)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid "amount" field (number expected)`);
    }
  }
  
  return obj as unknown as ReportData;
}

/**
 * Main function
 */
function main(): void {
  try {
    const args = parseArgs(process.argv);
    
    // Load and validate JSON data
    let jsonData: unknown;
    try {
      const jsonContent = readFileSync(args.dataFile, 'utf-8');
      jsonData = JSON.parse(jsonContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in ${args.dataFile}: ${error.message}`);
      } else if (error instanceof Error) {
        console.error(`Error: Failed to read ${args.dataFile}: ${error.message}`);
      } else {
        console.error(`Error: Failed to read ${args.dataFile}`);
      }
      process.exit(1);
    }
    
    const reportData = validateReportData(jsonData);
    
    // Select renderer based on format
    let output: string;
    switch (args.format.toLowerCase()) {
      case 'markdown':
        output = renderMarkdown.render(reportData, { includeTotals: args.includeTotals });
        break;
      case 'text':
        output = renderText.render(reportData, { includeTotals: args.includeTotals });
        break;
      default:
        console.error(`Error: Unsupported format "${args.format}"`);
        process.exit(1);
    }
    
    // Write output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error: Failed to write to ${args.outputPath}: ${error instanceof Error ? error.message : error}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : error}`);
    process.exit(1);
  }
}

// Run the CLI
main();