/**
 * Interface for a single report entry
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for the report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Interface for rendering options
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Interface for format renderers
 */
export interface Renderer {
  render(data: ReportData, options: RenderOptions): string;
}