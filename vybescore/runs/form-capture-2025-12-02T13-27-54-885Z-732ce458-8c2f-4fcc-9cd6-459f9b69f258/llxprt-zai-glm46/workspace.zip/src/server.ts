import express from 'express';
import path from 'path';
import fs from 'fs/promises';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const port = process.env.PORT || 3535;
let db: Database | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates'));

// Database initialization
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Try to load existing database file
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    let dbFile: Uint8Array | null = null;
    
    try {
      const fileData = await fs.readFile(dbPath);
      dbFile = new Uint8Array(fileData);
    } catch (error) {
      // File doesn't exist, create a new database
      console.log('No existing database found, creating new one');
    }
    
    db = new SQL.Database(dbFile);
    
    // Create table if it doesn't exist
    const schema = await fs.readFile(path.join(__dirname, '../db/schema.sql'), 'utf-8');
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
async function saveDatabase(): Promise<void> {
  if (!db) return;
  
  try {
    const data = db.export();
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    // Ensure data directory exists
    await fs.mkdir(path.dirname(dbPath), { recursive: true });
    
    await fs.writeFile(dbPath, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode.trim()) && postalCode.trim().length > 0;
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
      });
    }
  }
  
  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }
  
  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number (digits, spaces, parentheses, dashes, and optional leading +)'
    });
  }
  
  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code (letters, numbers, spaces, and dashes allowed)'
    });
  }
  
  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', async (req, res) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const errors = validateFormData(formData);
    
    if (errors.length > 0) {
      // Return form with errors and previously entered values
      res.status(400).render('form', {
        errors: errors.map(error => error.message),
        values: formData
      });
      return;
    }
    
    // Insert into database
    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      
      // Save database to disk
      await saveDatabase();
    }
    
    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
    
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('form', {
      errors: ['An unexpected error occurred. Please try again.'],
      values: req.body
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
async function gracefulShutdown(signal: string): Promise<void> {
  console.log(`Received ${signal}, shutting down gracefully...`);
  
  if (db) {
    await saveDatabase();
    db.close();
    db = null;
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

startServer().catch(console.error);