/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * Capitalizes first character of each sentence (after .?!), inserts exactly one space
 * between sentences even if input omitted it, collapses extra spaces sensibly
 * while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  let result = text.trim();
  
  result = result.replace(/\s+([.!?])/g, '$1');
  result = result.replace(/([.!?])\s*/g, '$1 ');
  
  result = result.replace(/\s{2,}/g, ' ');
  result = result.trim();
  
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/[^\s<>"{}|\\^`[\]]+[^\s<>"{}|\\^`[\].,!?;:]/g;
  const matches = text.match(urlRegex);
  return matches || [];
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\/([^/\s]+)/gi, 'https://$1');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com(\/[^\s<>"{}|\\^`[\]]*)/gi, (match, path) => {
    if (!path.startsWith('/docs/')) {
      return `https://example.com${path}`;
    }
    
    const hasDynamicHint = /[?&=]|\/(cgi-bin|.*\.jsp|.*\.php|.*\.asp|.*\.aspx|.*\.do|.*\.cgi|.*\.pl|.*\.py)/.test(path);
    
    if (hasDynamicHint) {
      return `https://example.com${path}`;
    }
    
    return `https://docs.example.com${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  if (month < 1 || month > 12) return 'N/A';
  
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) return 'N/A';
  
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    const isLeap = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeap) return 'N/A';
  }
  
  return year;
}
