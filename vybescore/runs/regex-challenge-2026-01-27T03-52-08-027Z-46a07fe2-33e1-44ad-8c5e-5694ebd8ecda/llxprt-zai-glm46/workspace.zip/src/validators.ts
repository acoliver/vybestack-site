export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation using regex.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (/\.\.|^\.|\.$|\._|_\./.test(value)) return false;
  
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * US phone number validation supporting common separators and optional +1.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  const cleaned = value.replace(/[\s\-()]/g, '');
  const digits = cleaned.replace(/^\+1/, '');
  
  if (digits.length !== 10) return false;
  if (!/^\d{10}$/.test(digits)) return false;
  
  const areaCode = digits.substring(0, 3);
  const exchangeCode = digits.substring(3, 6);
  
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  return true;
}

/**
 * Argentine phone number validation covering mobile/landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  const argentinePhoneRegex = /^(\+54)?0?(\d{2,4})(\d{6,8})$/;
  const match = cleaned.match(argentinePhoneRegex);
  
  if (!match) return false;
  
  const hasCountryCode = match[1] !== undefined;
  const areaCode = match[2];
  const subscriberNumber = match[3];
  
  if (!/^[1-9]/.test(areaCode)) return false;
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  if (!hasCountryCode && !cleaned.startsWith('0')) return false;
  
  const totalDigits = areaCode.length + subscriberNumber.length;
  if (totalDigits < 10) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\u0400-\u04FF]([a-zA-Z\u00C0-\u017F\u0400-\u04FF\s'-]*[a-zA-Z\u00C0-\u017F\u0400-\u04FF])?$/;
  return nameRegex.test(value);
}

/**
 * Helper function to run Luhn checksum for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa/Mastercard/AmEx prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/[\s-]/g, '');
  
  const cardRegex = /^(?:4\d{12}(\d{3})?|5[1-5]\d{14}|2[2-7]\d{14}|3[47]\d{13})$/;
  if (!cardRegex.test(cleaned)) return false;
  
  return runLuhnCheck(cleaned);
}
