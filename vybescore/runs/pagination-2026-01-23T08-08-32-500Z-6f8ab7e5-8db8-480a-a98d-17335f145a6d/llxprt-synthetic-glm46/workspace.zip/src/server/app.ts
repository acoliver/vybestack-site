import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory, validatePaginationParams } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const validation = validatePaginationParams(req.query.page as string | string[] | undefined, req.query.limit as string | string[] | undefined);
    
    if ('error' in validation) {
      return res.status(400).json({ error: validation.error });
    }
    
    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
