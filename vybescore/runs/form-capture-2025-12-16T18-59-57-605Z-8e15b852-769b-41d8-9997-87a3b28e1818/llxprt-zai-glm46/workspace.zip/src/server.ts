import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { Server } from 'http';

// Initialize sql.js
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Type declarations for sql.js
interface Database {
  exec(sql: string): QueryResult[];
  run(sql: string, ...params: unknown[]): RunResult;
  export(): Uint8Array;
  close(): void;
}

interface QueryResult {
  columns: string[];
  values: unknown[][];
}

interface RunResult {
  insertId: number | undefined;
  rowsAffected: number;
}

interface SqlJsStatic {
  Database: new (data?: Uint8Array | ArrayBuffer) => Database;
}

// Overwrite the imported initSqlJs with our typed version
const typedInitSqlJs = initSqlJs as (config?: Record<string, unknown>) => Promise<SqlJsStatic>;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: express.Application;
  private db: Database | null = null;
  private server: Server | null = null;
  private port: number;

  constructor() {
    this.app = express();
    this.port = parseInt(process.env.PORT || '3535', 10);
    this.setupMiddleware();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private validatePhone(phone: string): boolean {
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.length >= 7;
  }

  private validatePostalCode(postalCode: string): boolean {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    return postalRegex.test(postalCode);
  }

  private validateFormData(formData: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields validation
    if (!formData.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }
    if (!formData.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }
    if (!formData.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }
    if (!formData.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }
    if (!formData.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }
    if (!formData.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    }
    if (!formData.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }
    if (!formData.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    }
    if (!formData.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    }

    // Format validation
    if (formData.email && !this.validateEmail(formData.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    if (formData.phone && !this.validatePhone(formData.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }

    if (formData.postalCode && !this.validatePostalCode(formData.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal/zip code' });
    }

    return errors;
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await typedInitSqlJs();
      const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
      const dataDir = path.dirname(dbPath);

      // Create data directory if it doesn't exist
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      let dbArray: Uint8Array;
      if (fs.existsSync(dbPath)) {
        const dbFile = fs.readFileSync(dbPath);
        dbArray = new Uint8Array(dbFile);
      } else {
        dbArray = new Uint8Array([]);
      }

      this.db = new SQL.Database(dbArray);

      // Create table if it doesn't exist
      const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      this.db.run(schema);

    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;

    try {
      const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
      const data = this.db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private setupRoutes(): void {
    // Home page - form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        title: 'International Contact Form',
        errors: [],
        formData: {}
      });
    });

    // Form submission
    this.app.post('/submit', (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateFormData(formData);

      if (errors.length > 0) {
        // Validation failed, show form with errors
        res.render('form', {
          title: 'International Contact Form - Error',
          errors,
          formData
        });
        return;
      }

      // Validation passed, save to database
      if (this.db) {
        try {
          this.db.run(`
            INSERT INTO submissions (
              first_name, last_name, street_address, city, state_province,
              postal_code, country, email, phone
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `, [
            formData.firstName,
            formData.lastName,
            formData.streetAddress,
            formData.city,
            formData.stateProvince,
            formData.postalCode,
            formData.country,
            formData.email,
            formData.phone
          ]);
          this.saveDatabase();
        } catch (error) {
          console.error('Failed to save submission:', error);
          res.status(500).render('form', {
            title: 'International Contact Form - Error',
            errors: [{ field: 'general', message: 'Failed to save submission. Please try again.' }],
            formData
          });
          return;
        }
      }

      // Redirect to thank you page
      res.redirect(302, '/thank-you');
    });

    // Thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      res.render('thank-you', {
        title: 'Thank You!'
      });
    });
  }

  async start(): Promise<Server> {
    await this.initializeDatabase();
    this.setupRoutes();

    return new Promise((resolve, reject) => {
      this.server = this.app.listen(this.port, () => {
        console.log(`Server running on port ${this.port}`);
        resolve(this.server!);
      }).on('error', reject);
    });
  }

  async close(): Promise<void> {
    if (this.server) {
      return new Promise((resolve) => {
        this.server!.close(() => {
          console.log('Server closed');
          resolve();
        });
      });
    }
  }
}

// Export the FormServer class for direct import if needed
export { FormServer };

// Auto-start server if this file is run directly (but not when imported)
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new FormServer();
  server.start().catch(console.error);
}