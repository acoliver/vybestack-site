// TypeScript declaration for sql.js
declare module 'sql.js' {
  export interface Database {
    exec(sql: string): QueryResult[];
    run(sql: string, ...params: unknown[]): RunResult;
    export(): Uint8Array;
    close(): void;
  }

  export interface QueryResult {
    columns: string[];
    values: unknown[][];
  }

  export interface RunResult {
    insertId: number | undefined;
    rowsAffected: number;
  }

  export default function initSqlJs(config?: Record<string, unknown>): Promise<SqlJsStatic>;
  
  export interface SqlJsStatic {
    Database: {
      new(data?: Uint8Array | ArrayBuffer): Database;
    };
  }

  export function Database(data?: Uint8Array | ArrayBuffer): Database;
}