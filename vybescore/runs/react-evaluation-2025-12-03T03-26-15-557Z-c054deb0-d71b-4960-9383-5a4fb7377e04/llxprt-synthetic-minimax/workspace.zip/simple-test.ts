import { createInput, createComputed } from './src/index.js'

// Test case 1: Basic dependency
const [input, setInput] = createInput(1)
console.log('Input value:', input())

const double = createComputed(() => {
  const val = input()
  console.log('Computing double, input is:', val)
  return val * 2
})

console.log('Double value:', double())

// Change input and check if double updates
console.log('=== Changing input to 3 ===')
setInput(3)
console.log('Input value:', input())
console.log('Double value after change:', double())