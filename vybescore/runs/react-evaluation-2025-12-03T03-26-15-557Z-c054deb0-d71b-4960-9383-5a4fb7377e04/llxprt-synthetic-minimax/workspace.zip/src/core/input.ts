/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: typeof equal === 'function' ? equal : 
             equal === false ? undefined : 
             undefined, // For boolean true, we'll use reference equality
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    s.value = nextValue
    
    // Only notify if values are actually different
    const shouldUpdate = !s.equalFn || !s.equalFn(oldValue, nextValue)
    
    if (shouldUpdate) {
      notifyObservers(s)
    }
    
    return s.value
  }

  return [read, write]
}