/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  getActiveObserver,
  setActiveObserver,
  notifyObservers,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let cachedValue = value
  let isDirty = true
  
  // Create a subject to hold observers and manage notifications
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: cachedValue!,
    equalFn: typeof equal === 'function' ? equal : 
             equal === false ? undefined : 
             undefined, // For boolean true, we'll use reference equality
  }
  
  const observer: Observer<T> = {
    name: options?.name,
    value: cachedValue,
    updateFn: (_oldValue) => {
      // When this observer is updated by a dependency, mark as dirty
      // The next time the getter is called, it will recalculate
      isDirty = true
      return cachedValue as T
    },
  }

  const computeValue = (): void => {
    const previousObserver = getActiveObserver()
    
    // Set this computed's observer as the active one during computation
    // This allows any input() calls in the updateFn to register this observer
    setActiveObserver(observer)
    
    try {
      // Re-compute the value
      // During this call, any input() calls will register this observer
      cachedValue = updateFn(cachedValue)
      isDirty = false
      subject.value = cachedValue
    } finally {
      // Restore the previous active observer
      setActiveObserver(previousObserver)
    }
  }

  const getter: GetterFn<T> = () => {
    // If we're being called from within a reactive context,
    // register this computed as an observer
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== observer) {
      subject.observers.add(activeObserver)
    }
    
    if (isDirty) {
      computeValue()
      // Notify observers that this computed value has changed
      notifyObservers(subject)
    }
    
    return cachedValue as T
  }

  return getter
}