/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (oldValue) => {
      if (disposed) return oldValue!
      
      // Execute the side effect
      const result = updateFn(oldValue)
      return result
    },
  }

  // Register the observer to track dependencies
  // This needs to happen after the observer is created
  const observerRef = observer as unknown as { _disposed?: boolean }
  observerRef._disposed = false

  // Force initial evaluation to establish dependencies
  updateObserver(observer)

  return () => {
    if (disposed) return
    disposed = true
    observerRef._disposed = true
    
    // Clear references to help with garbage collection
    observer.value = undefined
  }
}
