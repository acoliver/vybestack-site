/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Global variable to store active observer for dependency tracking
let _activeObserver: ObserverR | undefined = undefined

export function getActiveObserver(): ObserverR | undefined {
  return _activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  _activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = _activeObserver
  _activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    _activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  // Create a copy of the observers to avoid modification during iteration
  const observers = new Set(subject.observers)
  for (const observer of observers) {
    if (subject.observers.has(observer)) {
      // Update each observer and make them dirty if needed
      updateObserver(observer as Observer<unknown>)
    }
  }
}

// Generic function to register an observer with a subject
export function registerObserver<T>(subject: Subject<T>, observer: Observer<T>): void {
  subject.observers.add(observer as ObserverR)
}

export function subscribeObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.observers.add(observer)
}

export function unsubscribeObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.observers.delete(observer)
}
