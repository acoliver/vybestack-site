// Debug script to understand the reactive behavior
import { createInput, createComputed } from './dist/index.js'

const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const timesTwo = createComputed(() => {
  console.log('Computing timesTwo, input is:', input())
  return input() * 2
})

const timesThirty = createComputed(() => {
  console.log('Computing timesThirty, input is:', input())
  return input() * 30
})

const sum = createComputed(() => {
  console.log('Computing sum, timesTwo is:', timesTwo(), 'timesThirty is:', timesThirty())
  return timesTwo() + timesThirty()
})

console.log('Initial sum:', sum())
console.log('=== Setting input to 3 ===')
setInput(3)
console.log('New sum:', sum())