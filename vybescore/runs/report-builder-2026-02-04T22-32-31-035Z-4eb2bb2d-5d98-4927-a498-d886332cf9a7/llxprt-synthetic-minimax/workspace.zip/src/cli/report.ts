#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, CLIOptions } from '../types.js';

function parseArgs(args: string[]): CLIOptions & { dataFile: string } {
  if (args.length < 3) {
    throw new Error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[2];
  let format: 'markdown' | 'text' | null = null;
  let output: string | undefined;
  let includeTotals = false;

  // Parse arguments starting from index 3
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      const formatValue = args[i + 1];
      if (formatValue === 'markdown' || formatValue === 'text') {
        format = formatValue;
      } else {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
      i++; // Skip next argument since it's the format value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a path');
      }
      output = args[i + 1];
      i++; // Skip next argument since it's the output path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { dataFile, format, output, includeTotals };
}

function readAndValidateData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContent) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: title must be a non-empty string');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary must be a non-empty string');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }
    
    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entry ${i + 1} must have a non-empty string 'label'`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid data: entry ${i + 1} must have a valid 'amount' number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, 'utf-8');
  } else {
    process.stdout.write(content);
  }
}

function main(): void {
  try {
    const args = process.argv;
    const options = parseArgs(args);
    
    // Read and validate data
    const data = readAndValidateData(options.dataFile);
    
    // Render based on format
    let rendered: string;
    switch (options.format) {
      case 'markdown':
        rendered = renderMarkdown(data, options.includeTotals);
        break;
      case 'text':
        rendered = renderText(data, options.includeTotals);
        break;
      default:
        throw new Error(`Unsupported format: ${options.format}`);
    }
    
    // Output result
    writeOutput(rendered, options.output);
    
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
