import { ReportData } from '../types.js';

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  // Title with heading
  lines.push(`# ${data.title}`);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries section
  lines.push('## Entries');
  
  // Add each entry as bullet point
  data.entries.forEach(entry => {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    lines.push(`- **${entry.label}** — ${formattedAmount}`);
  });
  
  // Add total if requested
  if (includeTotals) {
    lines.push('');
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`**Total:** $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}