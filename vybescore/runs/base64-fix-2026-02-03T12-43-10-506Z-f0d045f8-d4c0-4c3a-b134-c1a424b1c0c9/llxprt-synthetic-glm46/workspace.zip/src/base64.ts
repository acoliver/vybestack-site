/**
 * Encode plain text to Base64 using the canonical Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using the canonical Base64 alphabet.
 * Accepts inputs with or without padding and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  if (typeof input !== 'string' || input.length === 0) {
    throw new Error('Invalid Base64 input: empty or not a string');
  }
  
  // Basic validation: check for invalid Base64 characters
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
