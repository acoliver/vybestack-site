#!/usr/bin/env node

import fs from 'node:fs';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const cliArgs: CliArgs = {
    dataFile: args[0],
    format: '',
    includeTotals: false,
  };

  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      cliArgs.format = args[i + 1];
      i += 2;
    } else if (arg === '--output' && i + 1 < args.length) {
      cliArgs.output = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      cliArgs.includeTotals = true;
      i += 1;
    } else {
      console.error(`Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!cliArgs.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return cliArgs;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid data: expected an object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }

  for (const entry of reportData.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid entry: must be an object');
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: label must be a string');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid entry: amount must be a number');
    }
  }

  return reportData as unknown as ReportData;
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));
    
    // Load and validate JSON data
    let rawData: unknown;
    try {
      const fileContent = fs.readFileSync(args.dataFile, 'utf-8');
      rawData = JSON.parse(fileContent) as unknown;
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error parsing JSON file: ${error.message}`);
        process.exit(1);
      }
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error(`Error: File not found: ${args.dataFile}`);
        process.exit(1);
      }
      throw error;
    }

    const data = validateReportData(rawData);
    
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };

    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(data, options);
        break;
      case 'text':
        output = renderText(data, options);
        break;
      default:
        console.error(`Unsupported format: ${args.format}`);
        console.error('Supported formats: markdown, text');
        process.exit(1);
    }

    if (args.output) {
      fs.writeFileSync(args.output, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

main();
