import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(argv: string[]): CliOptions {
  if (argv.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = argv[2];
  let format: 'markdown' | 'text' | null = null;
  let output: string | undefined;
  let includeTotals = false;

  // Parse flags
  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      const nextArg = argv[i + 1];
      if (!nextArg || nextArg.startsWith('--')) {
        throw new Error('--format requires a value');
      }
      if (nextArg !== 'markdown' && nextArg !== 'text') {
        throw new Error(`Unsupported format: ${nextArg}`);
      }
      format = nextArg as 'markdown' | 'text';
      i++; // Skip next argument as it's the format value
    } else if (arg === '--output') {
      const nextArg = argv[i + 1];
      if (!nextArg || nextArg.startsWith('--')) {
        throw new Error('--output requires a value');
      }
      output = nextArg;
      i++; // Skip next argument as it's the output path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('--')) {
      throw new Error(`Unknown option: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return {
    dataFile,
    format,
    output,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const reportData = data as Record<string, unknown>;

  // Check required fields
  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: "title" field is required and must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" field is required and must be a string');
  }

  if (typeof reportData.entries !== 'object' || !Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: "entries" field is required and must be an array');
  }

  // Validate entries
  const entries = reportData.entries as unknown[];
  const validatedEntries = entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${index}] must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${index}].label must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${index}].amount must be a number`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries: validatedEntries
  };
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, includeTotals);
    case 'text':
      return renderText(data, includeTotals);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const options = parseArguments(process.argv);
    
    // Load and validate JSON data
    let rawData: string;
    try {
      rawData = readFileSync(options.dataFile, 'utf-8');
    } catch (error) {
      throw new Error(`Failed to read file "${options.dataFile}": ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    let parsedData: unknown;
    try {
      parsedData = JSON.parse(rawData);
    } catch (error) {
      throw new Error(`Failed to parse JSON: ${error instanceof Error ? error.message : 'Invalid JSON'}`);
    }

    const reportData = validateReportData(parsedData);
    
    // Render report
    const output = renderReport(reportData, options.format, options.includeTotals);
    
    // Output result
    if (options.output) {
      try {
        writeFileSync(options.output, output, 'utf-8');
      } catch (error) {
        throw new Error(`Failed to write output file "${options.output}": ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    } else {
      process.stdout.write(output + '\n');
    }
    
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
}

main();
