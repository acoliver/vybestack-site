import { ReportData } from '../types.js';

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  // Title with markdown heading
  lines.push(`# ${data.title}`);
  lines.push(''); // Blank line
  
  // Summary
  lines.push(data.summary);
  lines.push(''); // Blank line
  
  // Entries section
  lines.push('## Entries');
  
  // Bullet list for entries
  data.entries.forEach(entry => {
    const formattedAmount = entry.amount.toFixed(2);
    lines.push(`- **${entry.label}** — $${formattedAmount}`);
  });
  
  // Optional totals
  if (includeTotals) {
    lines.push(''); // Blank line before total
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = total.toFixed(2);
    lines.push(`**Total:** $${formattedTotal}`);
  }
  
  return lines.join('\n');
}