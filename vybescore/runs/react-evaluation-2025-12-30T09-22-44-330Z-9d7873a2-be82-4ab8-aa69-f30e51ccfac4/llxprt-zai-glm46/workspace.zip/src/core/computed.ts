/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  EqualFn,
  ObserverR
} from "../types/reactive.js"

type ComputedObserver<T> = Observer<T> & { observers: Set<ObserverR>; _lastValue?: T }

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: ComputedObserver<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
    _lastValue: undefined,
  }

  const getter = (): T => {
    const globalWindow = globalThis as unknown as { __activeObserver?: ObserverR }
    const activeObserver = globalWindow.__activeObserver
    if (activeObserver) {
      o.observers.add(activeObserver)
    }
    
    // Re-evaluate to get the current value
    const previous = globalWindow.__activeObserver
    globalWindow.__activeObserver = undefined  // Don't track computed's own updates
    try {
      const newValue = updateFn(o.value)
      o.value = newValue
      
      // Notify observers if value changed
      if (o._lastValue !== newValue) {
        o._lastValue = newValue
        // Create a copy to avoid issues with mutation during iteration
        const observers = Array.from(o.observers)
        for (const obs of observers) {
          if (obs.disposed) {
            o.observers.delete(obs)
            continue
          }
          // For callbacks, we need to run them
          const obsWithRun = obs as unknown as { _run?: () => void }
          if (obsWithRun._run) {
            obsWithRun._run()
          } else {
            updateObserver(obs as Observer<unknown>)
          }
        }
      }
      
      return o.value as T
    } finally {
      globalWindow.__activeObserver = previous
    }
  }

  // Only evaluate once if no dependencies - this makes createComputed((x: number = 3) => x * 2)() === 6
  // When there are dependencies, the getter will handle re-evaluation
  const hasNoDependencies = value !== undefined
  if (hasNoDependencies) {
    // Set the value directly for computed with initial value
    o.value = updateFn(value)
    o._lastValue = o.value
  }

  return getter
}