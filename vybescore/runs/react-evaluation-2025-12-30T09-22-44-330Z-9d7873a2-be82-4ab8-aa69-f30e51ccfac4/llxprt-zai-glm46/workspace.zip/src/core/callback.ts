/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, ObserverR } from "../types/reactive.js"

type CallbackObserver<T> = Observer<T> & { observers: Set<ObserverR>; _run: () => void }

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: CallbackObserver<T> = {
    value,
    updateFn,
    observers: new Set(),
    _run: () => {
      // Check if disposed before running
      if (observer.disposed) return
      updateObserver(observer)
    },
  }
  
  // Track dependencies and run effect initially
  updateObserver(observer)
  
  const unsubscribe = () => {
    observer.disposed = true
    // Clean up: remove this observer from all its dependencies
    for (const dep of observer.observers) {
      const deps = (dep as unknown as { observers?: Set<ObserverR> }).observers
      if (deps) {
        deps.delete(observer)
      }
    }
    observer.observers.clear()
  }
  
  return unsubscribe
}