export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex that handles common cases
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for specific invalid patterns
  const hasDoubleDots = /\.\./.test(value);
  const hasTrailingDot = /\.$/.test(value);
  const hasDomainUnderscore = /@.*_/.test(value);
  const hasConsecutiveDotsAtStart = /^\./.test(value);
  const hasConsecutiveDotsAfterAt = /@\./.test(value);
  
  return emailRegex.test(value) && 
         !hasDoubleDots && 
         !hasTrailingDot && 
         !hasDomainUnderscore &&
         !hasConsecutiveDotsAtStart &&
         !hasConsecutiveDotsAfterAt;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except + at the beginning
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Must have exactly 10 digits after cleaning
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if the original format matches valid US phone patterns
  const usPhoneRegex = /^(\+?1[\s-]?)?(\(?\d{3}\)?[\s-]?)?\d{3}[\s-]?\d{4}$/;
  return usPhoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54, optional 0 before area code, optional 9 for mobile
  // Area code: 2-4 digits (leading digit 1-9)
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?9?(0?[2-9]\d{1,3})(\d{6,8})$/;
  
  // If no country code, must start with 0 before area code
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  const match = argentinePhoneRegex.exec(cleaned);
  if (!match) {
    return false;
  }
  
  const areaCode = match[2];
  const subscriber = match[3];
  
  // Area code must be 2-4 digits, subscriber 6-8 digits
  return areaCode.length >= 2 && areaCode.length <= 4 && 
         subscriber.length >= 6 && subscriber.length <= 8;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and unusual patterns like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}'’\-\s]+$/u;
  
  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for excessive symbols (reject things like "X Æ A-12")
  const symbolCount = (value.match(/[Ææ]/g) || []).length;
  const letterCount = (value.match(/[\p{L}\p{M}]/gu) || []).length;
  
  // If there are special symbols like Æ/æ, make sure there are enough regular letters
  if (symbolCount > 0 && letterCount < 3) {
    return false;
  }
  
  return nameRegex.test(value) && value.trim().length > 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check valid lengths and prefixes for major credit cards
  const visaRegex = /^4(\d{12}|\d{15})$/;           // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$/;         // 16 digits, starts with 51-55
  const amexRegex = /^3[47]\d{13}$/;                // 15 digits, starts with 34 or 37
  
  const validFormat = visaRegex.test(digits) || 
                     mastercardRegex.test(digits) || 
                     amexRegex.test(digits);
  
  if (!validFormat) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(digits);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}
