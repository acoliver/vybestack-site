/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence-ending punctuation (.?!)
  return text.replace(/([.!?])(\s*)([a-z])/g, (match, punctuation, spaces, letter) => {
    // Ensure exactly one space between sentences
    return punctuation + ' ' + letter.toUpperCase();
  }).replace(/^\s*([a-z])/g, (match, letter) => {
    // Capitalize first letter of the text
    return letter.toUpperCase();
  }).replace(/\s+/g, ' ')  // Collapse multiple spaces to single
   .trim();  // Remove leading/trailing spaces
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches http/https URLs with optional www,
  // domain names, paths, query strings, and fragments
  const urlRegex = /\bhttps?:\/\/[^\s/$.?#].[^\s]*\b/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation if present
  return matches.map(url => url.replace(/[.,;:!?)\]\}]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but leave https:// unchanged
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Complex URL rewriting logic
  // First upgrade all http to https
  let result = text.replace(/\bhttp:\/\//g, 'https://');
  
  // Then handle docs.example.com rewriting
  result = result.replace(
    // Match https://example.com/docs/... but exclude dynamic content
    /https:\/\/example\.com(\/docs\/[^\s?#]*?)(?=\s|$|[?&]|\.(jsp|php|asp|aspx|do|cgi|pl|py))/gi,
    (match, path) => {
      // Check if path contains dynamic indicators
      const hasDynamicIndicators = /\/cgi-bin|[?&]/.test(path) || 
                                  /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
      
      if (hasDynamicIndicators) {
        return match; // Don't rewrite host part for dynamic content
      }
      
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
  );
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Basic validation for days per month (simplified)
  const maxDaysPerMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day > maxDaysPerMonth[month - 1]) {
    return 'N/A';
  }
  
  return year.toString();
}
