/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Simple approach: split by spaces and check each word
  const words = text.split(/\s+/);
  
  // Filter words that start with the prefix and are not in exceptions
  return words.filter(word => {
    return word.startsWith(prefix) && !exceptions.includes(word);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Simple approach: find all occurrences and filter
  const results: string[] = [];
  const parts = text.split(/\s+/);
  
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    // Check if part ends with token and has a digit before token
    if (part.includes(token) && !part.startsWith(token)) {
      const match = part.match(/\d+/);
      if (match && part.includes(match[0] + token)) {
        results.push(match[0] + token);
      }
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (like 'abab', '1212')
  // Check for any 2-character sequence repeated immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  // Check for any 3-character sequence repeated immediately
  if (/(...).\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that includes shorthand ::
  // but excludes IPv4 addresses
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/g;
  
  // First check for IPv4 patterns to exclude them
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g;
  
  // Remove IPv4 addresses from consideration
  const textWithoutIPv4 = value.replace(ipv4Regex, '');
  
  // Check for IPv6 in the remaining text
  return ipv6Regex.test(textWithoutIPv4);
}
