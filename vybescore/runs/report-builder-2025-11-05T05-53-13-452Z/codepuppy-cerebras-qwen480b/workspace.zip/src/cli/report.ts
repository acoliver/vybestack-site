#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CLIOptions {
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(): { dataPath: string; options: CLIOptions } {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataPath = args[0];
  
  const options: CLIOptions = {
    format: '',
    includeTotals: false,
  };
  
  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      options.format = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--output' && i + 1 < args.length) {
      options.output = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }
  
  if (!options.format) {
    throw new Error('--format is required');
  }
  
  return { dataPath, options };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid "title" field (expected string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (expected string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid "entries" field (expected array)');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (expected string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`);
    }
  }
  
  return obj as unknown as ReportData;
}

function loadReportData(path: string): ReportData {
  try {
    const content = readFileSync(path, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${path}: ${error.message}`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, options: CLIOptions): string {
  const reportOptions: ReportOptions = {
    includeTotals: options.includeTotals,
  };
  
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, reportOptions);
    case 'text':
      return renderText(data, reportOptions);
    default:
      throw new Error(`Unsupported format: ${options.format}. Supported formats: markdown, text`);
  }
}

function main(): void {
  try {
    const { dataPath, options } = parseArguments();
    const data = loadReportData(dataPath);
    const output = renderReport(data, options);
    
    if (options.output) {
      writeFileSync(options.output, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();