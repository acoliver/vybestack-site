import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';

class MarkdownFormatter implements ReportFormatter {
  render(data: ReportData, options: ReportOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(`# ${data.title}`);
    lines.push('');
    
    // Summary  
    lines.push(data.summary);
    lines.push('');
    
    // Entries heading
    lines.push('## Entries');
    
    // Entry list
    for (const entry of data.entries) {
      const formattedAmount = this.formatAmount(entry.amount);
      lines.push(`- **${entry.label}** — ${formattedAmount}`);
    }
    
    // Total if requested
    if (options.includeTotals) {
      const total = this.calculateTotal(data.entries);
      const formattedTotal = this.formatAmount(total);
      lines.push(`\n**Total:** ${formattedTotal}`);
    }
    
    return lines.join('\n');
  }
  
  private formatAmount(amount: number): string {
    return `$${amount.toFixed(2)}`;
  }
  
  private calculateTotal(entries: ReportData['entries']): number {
    return entries.reduce((sum, entry) => sum + entry.amount, 0);
  }
}

export const renderMarkdown = (data: ReportData, options: ReportOptions): string => {
  const formatter = new MarkdownFormatter();
  return formatter.render(data, options);
};

export { MarkdownFormatter };