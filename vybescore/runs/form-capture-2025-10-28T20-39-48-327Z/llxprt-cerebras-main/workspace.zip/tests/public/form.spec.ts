import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import serverImport from '../../src/server.js';
import type { Server } from 'http';

let server: Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  server = serverImport;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Street address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State / Province / Region');
    expect(response.text).toContain('Postal / Zip code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'Country',
        email: 'john@example.com',
        phone: '+1 555 123 4567'
      })
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');

    // Check that data was persisted
    const exists = fs.existsSync(dbPath);
    expect(exists).toBe(true);
  });
});