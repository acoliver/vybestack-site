import express, { Express, Request, Response } from 'express';
import type { Server } from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeDatabase, saveDatabase, closeDatabase } from './database.js';
import type { Database } from 'sql.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app: Express = express();
const port = process.env.PORT || 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

// Initialize database
let db: Database | null = null;
initializeDatabase().then(database => {
  db = database;
});

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: {}, data: {} });
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[\d\s-()+]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric postal codes with spaces and dashes
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode);
}

// Error messages
const errorMessages = {
  firstName: 'First name is required',
  lastName: 'Last name is required',
  streetAddress: 'Street address is required',
  city: 'City is required',
  stateProvince: 'State/Province is required',
  postalCode: 'Postal code is required and must be alphanumeric',
  country: 'Country is required',
  email: 'Email is required and must be valid',
  phone: 'Phone number is required and can contain digits, spaces, parentheses, dashes, and a leading +'
};

app.post('/submit', (req: Request, res: Response) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  } = req.body;
  
  const errors: Record<string, string> = {};
  
  // Validation checks
  if (!firstName) errors.firstName = errorMessages.firstName;
  if (!lastName) errors.lastName = errorMessages.lastName;
  if (!streetAddress) errors.streetAddress = errorMessages.streetAddress;
  if (!city) errors.city = errorMessages.city;
  if (!stateProvince) errors.stateProvince = errorMessages.stateProvince;
  if (!postalCode) {
    errors.postalCode = errorMessages.postalCode;
  } else if (!validatePostalCode(postalCode)) {
    errors.postalCode = errorMessages.postalCode;
  }
  if (!country) errors.country = errorMessages.country;
  if (!email) {
    errors.email = errorMessages.email;
  } else if (!validateEmail(email)) {
    errors.email = errorMessages.email;
  }
  if (!phone) {
    errors.phone = errorMessages.phone;
  } else if (!validatePhone(phone)) {
    errors.phone = errorMessages.phone;
  }
  
  // If there are validation errors, re-render form with errors and data
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, data: req.body });
  }
  
  // Insert data into database
  try {
    const stmt = db!.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      firstName,
      lastName,
      streetAddress,
      city,
      stateProvince,
      postalCode,
      country,
      email,
      phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('Internal server error');
  }
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  closeDatabase();
  process.exit(0);
});

// Start server
const server: Server = app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

export default server;