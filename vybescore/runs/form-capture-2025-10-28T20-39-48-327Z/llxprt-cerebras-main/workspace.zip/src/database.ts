import fs from 'fs';
import path from 'path';
import initSqlJs, { Database } from 'sql.js';

// Ensure data directory exists
const dataDir = path.resolve('data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir);
}

// Database file path
const dbPath = path.resolve(dataDir, 'submissions.sqlite');

// Initialize database
let db: Database | null = null;

export async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs({ 
    locateFile: (filename: string) => `node_modules/sql.js/dist/${filename}` 
  });
  
  // Load existing database or create a new one
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.resolve('db', 'schema.sql'), 'utf8');
    db.run(schema);
    saveDatabase();
  }
  
  return db;
}

export function saveDatabase(): void {
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, data);
  }
}

export function closeDatabase(): void {
  if (db) {
    db.close();
  }
}