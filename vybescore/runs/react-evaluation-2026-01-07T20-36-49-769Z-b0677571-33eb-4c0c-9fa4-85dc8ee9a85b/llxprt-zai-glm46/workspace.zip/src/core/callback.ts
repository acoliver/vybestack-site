/**
 * Callback closure implementation for reactive side effects.
 */

import type { UnsubscribeFn, UpdateFn, Observer } from '../types/reactive.js'
import { updateObserver } from '../types/reactive.js'

// Map to track subjects each callback observer depends on
const callbackDependencies = new WeakMap<Observer<unknown>, Set<unknown>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Track dependencies for this callback
  const dependencies = new Set<unknown>()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  callbackDependencies.set(observer as any, dependencies)
  
  // Register observer to track dependencies by running updateFn
  // This will cause dependencies to register themselves
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  updateObserver(observer as any)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    
    // Clean up dependencies
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    callbackDependencies.delete(observer as any)
  }
}
