/**
 * Computed closure implementation for derived values.
 */

import type { GetterFn, UpdateFn, EqualFn, Options, Observer, ObserverR, SubjectR } from '../types/reactive.js'
import { updateObserver, getActiveObserver, addObserver, setActiveObserver, removeObserver } from '../types/reactive.js'

// Map to track observers of each computed value
const computedObservers = new WeakMap<ObserverR, Set<ObserverR>>()
// Map to track the subject associated with each computed observer
const computedSubjects = new WeakMap<ObserverR, SubjectR>()
// Map to track dependencies of each computed observer
const computedDependencies = new WeakMap<ObserverR, Set<SubjectR>>()

// Track which observers are currently updating to prevent cycles
const updatingObservers = new Set<ObserverR>()

/**
 * Helper to notify all observers of a computed value
 */
function notifyComputedObservers(notifier: ObserverR): void {
  // Don't notify if currently updating this observer (prevents cycles)
  if (updatingObservers.has(notifier)) {
    return
  }
  
  // Use the computedObservers map to notify all observers directly
  const observers = computedObservers.get(notifier)
  if (observers) {
    const observersCopy = new Set(observers)
    for (const obs of observersCopy) {
      // Don't notify the observer itself
      if (obs !== notifier) {
        updateObserver(obs as Observer<unknown>)
      }
    }
  }
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Create a subject for this computed so others can observe it
  const subject: SubjectR = {
    observers: new Set(),
    name: options?.name,
  }
  
  let isFirstUpdate = true
  
  // Create the observer for this computed
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // Check for cycles
      if (updatingObservers.has(observer)) {
        // Already updating, return current value
        return observer.value!
      }
      
      const wasFirstUpdate = isFirstUpdate
      isFirstUpdate = false
      
      updatingObservers.add(observer)
      
      try {
        // Clear previous dependencies and unregister from them
        const oldDependencies = computedDependencies.get(observer)
        if (oldDependencies) {
          for (const dep of oldDependencies) {
            removeObserver(dep, observer)
          }
          oldDependencies.clear()
        }
        
        // Create new dependencies set
        const dependencies = new Set<SubjectR>()
        computedDependencies.set(observer, dependencies)
        
        // Set this computed as the active observer so dependencies can register themselves
        const prevActiveObserver = getActiveObserver()
        setActiveObserver(observer)
        
        try {
          // Recompute the value by calling the update function
          // The update function will access its dependencies, which will register this observer
          const newValue = updateFn(prevValue)
          
          // Update the observer's value
          observer.value = newValue
          
          return newValue
        } finally {
          // Restore the previous active observer
          setActiveObserver(prevActiveObserver)
        }
      } finally {
        // Mark that we're done updating
        updatingObservers.delete(observer)
        
        // Notify observers AFTER we're done updating
        // Only notify after the first update (not during initialization)
        if (!wasFirstUpdate) {
          notifyComputedObservers(observer)
        }
      }
    },
  }
  
  // Initialize observers set for this computed
  computedObservers.set(observer, new Set())
  // Store the subject for this computed
  computedSubjects.set(observer, subject)
  
  // Perform initial computation
  updateObserver(observer)
  
  // When this computed is accessed during another observer's computation,
  // register the accessor as an observer of this computed
  const getter: GetterFn<T> = (): T => {
    const activeObs = getActiveObserver()
    if (activeObs) {
      // Add the active observer to this computed's subject
      addObserver(subject, activeObs)
      
      // Also track in our computedObservers map for direct notification
      let observers = computedObservers.get(observer)
      if (!observers) {
        observers = new Set()
        computedObservers.set(observer, observers)
      }
      observers.add(activeObs)
    }
    return observer.value!
  }
  
  return getter
}
