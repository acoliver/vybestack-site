import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js types are not available
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize sql.js
interface Database {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): PreparedStatement;
  export(): Uint8Array;
  close(): void;
}

interface PreparedStatement {
  run(...params: unknown[]): void;
  free(): void;
}

let Database: new (data?: Uint8Array | null) => Database;
let db: Database;

async function initializeDatabase() {
  try {
    const SQL = await initSqlJs();
    Database = SQL.Database;
    
    const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
    const dataDir = path.dirname(dbPath);
    
    // Ensure data directory exists
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load or create database
    let dbData: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      dbData = fs.readFileSync(dbPath);
    }
    
    db = new Database(dbData);
    
    // Read and execute schema
    const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase() {
  try {
    const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation types
interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Validation functions
function validateForm(values: FormValues): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields
  if (!values.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!values.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!values.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!values.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!values.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  if (!values.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else {
    // Postal code can be alphanumeric (UK: SW1A 1AA, Argentina: C1000, B1675)
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(values.postalCode.trim())) {
      errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, spaces, and hyphens' });
    }
  }
  
  if (!values.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!values.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else {
    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(values.email.trim())) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }
  }
  
  if (!values.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else {
    // Phone validation: digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^[+]?[0-9\s\-()]+$/;
    if (!phoneRegex.test(values.phone.trim())) {
      errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
    }
  }
  
  return errors;
}

// Express app setup
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formValues: FormValues = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };
  
  const errors = validateForm(formValues);
  
  if (errors.length > 0) {
    return res.render('form', {
      errors: errors.map(e => e.message),
      values: formValues
    });
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run(
      formValues.firstName?.trim(),
      formValues.lastName?.trim(),
      formValues.streetAddress?.trim(),
      formValues.city?.trim(),
      formValues.stateProvince?.trim(),
      formValues.postalCode?.trim(),
      formValues.country?.trim(),
      formValues.email?.trim(),
      formValues.phone?.trim()
    );
    
    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you?firstName=' + encodeURIComponent(formValues.firstName || ''));
    
  } catch (error) {
    console.error('Database error:', error);
    return res.render('form', {
      errors: ['An error occurred while submitting the form. Please try again.'],
      values: formValues
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Start server
type Server = {
  close(callback?: () => void): void;
  listen(port: number, callback?: () => void): void;
};

let server: Server;

async function startServer() {
  try {
    await initializeDatabase();
    
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
function shutdown() {
  console.log('Shutting down gracefully...');
  
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  
  if (db) {
    saveDatabase(); // Final save
    db.close();
    console.log('Database closed');
  }
  
  process.exit(0);
}

// Handle shutdown signals
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Handle unhandled rejections
process.on('unhandledRejection', (reason: unknown, promise: Promise<unknown>) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  shutdown();
});

// Start the server
startServer();

// Export for testing
export { app, startServer, shutdown };