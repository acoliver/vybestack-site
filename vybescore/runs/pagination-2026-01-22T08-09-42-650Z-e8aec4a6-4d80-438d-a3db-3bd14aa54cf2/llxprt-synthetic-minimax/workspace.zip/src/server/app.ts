import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    let page: number | undefined;
    let limit: number | undefined;

    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (!Number.isFinite(pageNum) || pageNum <= 0) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive number.' });
      }
      page = Math.floor(pageNum);
    }

    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (!Number.isFinite(limitNum) || limitNum <= 0) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive number.' });
      }
      limit = Math.floor(limitNum);
    }

    // Optional: Reject excessive values (example: limit > 100)
    if (limit && limit > 100) {
      return res.status(400).json({ error: 'Invalid limit parameter. Must be 100 or less.' });
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
