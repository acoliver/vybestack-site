/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create pattern to match words starting with the prefix
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => {
    const lowercaseWord = word.toLowerCase();
    return !exceptions.some(exception => 
      lowercaseWord.includes(exception.toLowerCase())
    );
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Simple pattern to find token that appears after a digit
  const pattern = new RegExp(`\\d${token}`, 'g');
  const matches: string[] = [];
  
  let match;
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches; // Return all matches
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // One uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // One lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // One digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // One symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  for (let i = 0; i < value.length - 2; i++) {
    const char = value[i];
    if (value[i + 1] === char && value[i + 2] === char) {
      return false;
    }
    
    // Check for alternating patterns like abab
    if (i < value.length - 3 && 
        value[i] === value[i + 2] && 
        value[i + 1] === value[i + 3]) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if it looks like an IPv4 address (should not match)
  const ipv4Pattern = /\b(\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns to match various formats
  const patterns = [
    // Full format with 8 groups of 4 hex digits (separated by colons)
    /\b(?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}\b/i,
    // IPv6 with :: shorthand notation
    /\b(?:[0-9A-Fa-f]{1,4}:)*(?:[0-9A-Fa-f]{1,4})?::(?:[0-9A-Fa-f]{1,4}:)*[0-9A-Fa-f]{1,4}\b/i,
    // IPv6 with embedded IPv4 notation at end
    /\b(?:[0-9A-Fa-f]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}\b/i,
  ];
  
  // Test against all patterns
  for (const pattern of patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
