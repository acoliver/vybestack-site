/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to identify sentence endings followed by potential sentence start
  const sentencePattern = /([.!?])\s*([A-Za-z])/g;
  
  // First, ensure there's exactly one space after sentence endings
  let result = text.replace(/\s+/g, ' ');
  
  // Then capitalize first letter of each sentence
  result = result.replace(sentencePattern, (match, p1, p2) => {
    return p1 + ' ' + p2.toUpperCase();
  });
  
  // Also handle the very first character
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern to match http/https URLs
  const urlPattern = /https?:\/\/[^\s"';,]+[^\s"';,.)]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;!?]+$/g, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave https:// untouched
  const httpsPattern = /https?:\/\//g;
  return text.replace(httpsPattern, (match) => {
    if (match === 'http://') {
      return 'https://';
    }
    return match; // Already https://
  });
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs
  const urlPattern = /https?:\/\/[^\s"';,]+[^\s"';,.)]/gi;
  
  return text.replace(urlPattern, (match) => {
    // Remove trailing punctuation from the URL
    let url = match.replace(/[.,;!?]+$/g, '');
    
    // Always upgrade scheme to https://
    if (url.startsWith('http://')) {
      url = 'https://' + url.substring(7);
    }
    
    // Check if it's a docs path that needs host rewriting
    const docsMatch = url.match(/^https:\/\/([^/]+)(\/docs\/.*)$/);
    
    if (docsMatch) {
      const [, host, path] = docsMatch;
      
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /(\?|cgi-bin|&|=)/i.test(url);
      const hasLegacyExtensions = /(\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(url);
      
      if (!hasDynamicHints && !hasLegacyExtensions && path.startsWith('/docs/')) {
        // Rewrite host to docs subdomain
        const domainParts = host.split('.');
        if (domainParts.length >= 2) {
          const domain = domainParts.slice(-2).join('.');
          url = 'https://docs.' + domain + path;
        }
      }
    }
    
    // Replace the match in the original text with the transformed URL
    return url;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (1-12)
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31 depending on month)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (dayNum < 1 || dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }
  
  // Check for February 29th in non-leap years
  if (monthNum === 2 && dayNum === 29) {
    const yearNum = parseInt(year, 10);
    if (yearNum % 4 !== 0 || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
      return 'N/A';
    }
  }
  
  return year;
}
