export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(_value: string): boolean {
  // Pattern for typical email addresses
  // Local part: letters, numbers, dots, underscores, plus, hyphens
  // Domain: letters, numbers, dots, hyphens with TLD
  const emailPattern = /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9.-]{2,}$/;
  
  // Check basic pattern
  if (!emailPattern.test(_value)) {
    return false;
  }
  
  // Reject double dots
  if (_value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (_value.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  const domain = _value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check for +1 prefix
  if (digits.startsWith('1') && digits.length === 11) {
    return isValidUSPhone(digits.substring(1));
  }
  
  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check if original format is valid - simplified pattern
  const simplePattern = /^[0-9]{3}[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}$/;
  if (simplePattern.test(value)) {
    return true;
  }
  
  // Check with parentheses format
  const parenPattern = /^\([0-9]{3}\)[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}$/;
  if (parenPattern.test(value)) {
    return true;
  }
  
  // Check with +1 prefix
  const plusOnePattern = /^\+1[-.\s]?[0-9]{3}[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}$/;
  if (plusOnePattern.test(value)) {
    return true;
  }
  
  return false;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Simple patterns to handle common formats
  const patterns = [
    // +54 341 123 4567 (country code + area + numbers)
    /^\+54\s*(\d{3,4})\s*(\d{3,4})\s*(\d{3,4})$/,
    // 011 1234 5678 (trunk + area + numbers)
    /^0\s*(\d{3,4})\s*(\d{3,4})\s*(\d{3,4})$/,
    // 341 123 4567 (area + numbers)
    /^(\d{3,4})\s*(\d{3,4})\s*(\d{3,4})$/,
  ];
  
  // Check against patterns
  for (const pattern of patterns) {
    const match = value.match(pattern);
    if (match) {
      const parts = match.slice(1).filter(p => p); // Remove empty parts
      if (parts.length >= 2) {
        const areaCode = parts[0];
        const subscriberParts = parts.slice(1);
        const subscriberNumber = subscriberParts.join('');
        
        // Validate area code (2-4 digits)
        if (areaCode.length >= 2 && areaCode.length <= 4 && areaCode[0] !== '0') {
          // Validate total subscriber length (6-8 digits)
          if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
            // When no country code and no trunk prefix, need trunk 0
            if (!value.startsWith('+54') && !value.trim().startsWith('0')) {
              return false;
            }
            return true;
          }
        }
      }
    }
  }
  
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with symbols other than apostrophe and hyphen
  if (/[^A-Za-zÀ-ÿ\s'-]/.test(value)) {
    return false;
  }
  
  // Must not be empty or only whitespace
  if (!value.trim()) {
    return false;
  }
  
  // Check for Unicode letters and accents
  const unicodePattern = /^[\p{L}\p{M}\s'-]+$/u;
  if (!unicodePattern.test(value)) {
    return false;
  }
  
  // Valid name format
  return true;
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check card length (13-19 digits for major cards)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check for Visa (starts with 4)
  if (/^4/.test(digits) && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    return runLuhnCheck(digits);
  }
  
  // Check for Mastercard (starts with 51-55 or 2221-2720)
  if (/^(51|52|53|54|55)/.test(digits) && digits.length === 16) {
    return runLuhnCheck(digits);
  }
  
  // Check for Mastercard (2221-2720 range)
  if (digits.length === 16) {
    const firstFour = parseInt(digits.substring(0, 4), 10);
    if (firstFour >= 2221 && firstFour <= 2720) {
      return runLuhnCheck(digits);
    }
  }
  
  // Check for American Express (starts with 34 or 37)
  if (/^(34|37)/.test(digits) && digits.length === 15) {
    return runLuhnCheck(digits);
  }
  
  // Not a recognized card type
  return false;
}
