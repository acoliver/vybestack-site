#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(args: string[]) {
  const result = {
    dataJsonPath: '',
    format: '',
    outputPath: '',
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--format' && i + 1 < args.length) {
      i++;
      result.format = args[i];
    } else if (arg === '--output' && i + 1 < args.length) {
      i++;
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!result.dataJsonPath) {
      result.dataJsonPath = arg;
    }
  }

  return result;
}

function loadData(jsonPath: string): ReportData {
  try {
    const fileContent = readFileSync(jsonPath, 'utf8');
    const data = JSON.parse(fileContent) as ReportData;

    if (data.title === undefined) {
      throw new Error('Missing required field: title');
    }
    if (data.summary === undefined) {
      throw new Error('Missing required field: summary');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing required field: entries');
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    throw error;
  }
}

function render(data: ReportData, format: string, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main() {
  try {
    const args = process.argv.slice(2);
    if (args.length < 1) {
      console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    const parsedArgs = parseArgs(args);
    if (!parsedArgs.dataJsonPath) {
      console.error('Error: data file path is required');
      process.exit(1);
    }
    if (!parsedArgs.format) {
      console.error('Error: --format is required');
      process.exit(1);
    }

    const data = loadData(parsedArgs.dataJsonPath);
    const options = { includeTotals: parsedArgs.includeTotals };
    const output = render(data, parsedArgs.format, options);

    if (parsedArgs.outputPath) {
      try {
        writeFileSync(parsedArgs.outputPath, output);
      } catch (error) {
        console.error(`Error writing output file: ${error}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
