/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with prefix
  // Word boundary ensures we match whole words
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const filtered = matches.filter(word => 
    !exceptions.some(exception => exception.toLowerCase() === word.toLowerCase())
  );
  
  // Return unique matches preserving case
  return Array.from(new Set(filtered));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match the digit followed by token (return the full match)
  // Use word boundary or lookahead to ensure we're matching the right thing
  const pattern = new RegExp(`\\d${escapedToken}`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, abcabc)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment = value.substr(i, len);
      const nextSegment = value.substr(i + len, len);
      if (segment === nextSegment) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address pattern (not perfect but covers most cases)
  // Supports:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed zeros with :: : 2001:db8::1
  // - Embedded IPv4: ::ffff:192.0.2.1
  // Excludes:
  // - Pure IPv4 addresses
  // - Invalid formats
  
  // First, check if it looks like pure IPv4 and exclude those
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 patterns
  // Full 8 groups of 1-4 hex digits separated by colons
  const fullIpv6Pattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // Compressed with ::
  const compressedIpv6Pattern = /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}$/;
  
  // IPv6 with embedded IPv4 (e.g., ::ffff:192.0.2.1)
  const ipv4EmbeddedPattern = /^(?:[0-9a-fA-F]{1,4}:)*:(?:[0-9a-fA-F]{1,4}:)*:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // Also check for IPv6 pattern within text
  const ipv6InTextPattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}/;
  
  return fullIpv6Pattern.test(value.trim()) || 
         compressedIpv6Pattern.test(value.trim()) || 
         ipv4EmbeddedPattern.test(value.trim()) ||
         ipv6InTextPattern.test(value);
}
