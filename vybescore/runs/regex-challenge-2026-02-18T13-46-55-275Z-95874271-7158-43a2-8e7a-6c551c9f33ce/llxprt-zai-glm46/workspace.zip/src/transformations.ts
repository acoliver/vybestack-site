/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences even if input omitted it.
 * Collapse extra spaces sensibly while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence endings
  // Ensure exactly one space after .!? when followed by a letter
  let normalized = text.replace(/([.!?])\s*([a-zA-Z])/g, '$1 $2');
  
  // Collapse multiple spaces into one
  normalized = normalized.replace(/\s+/g, ' ');
  
  // Trim leading/trailing whitespace
  normalized = normalized.trim();
  
  // Capitalize first character of text
  if (normalized.length > 0) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize after sentence endings
  // Split into sentences and capitalize
  const sentences = normalized.split(/(?<=[.!?])\s+/);
  const capitalized = sentences.map((sentence, index) => {
    if (index === 0) return sentence; // Already capitalized first sentence
    
    if (sentence.length > 0) {
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
    return sentence;
  });
  
  return capitalized.join(' ');
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches http://, https://, and www. URLs
  // Captures the URL but excludes trailing punctuation
  const urlRegex = /(https?:\/\/[^\s<>"()]+|www\.[^\s<>"()]+)/gi;
  
  const urls: string[] = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?)\]"']+$/, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * Always upgrade scheme to https://.
 * When path begins with /docs/, rewrite host to docs.example.com.
 * Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(https?):\/\/example\.com([^\s<>"()]+)/gi;
  
  return text.replace(urlPattern, (match, protocol, pathAndQuery) => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Check if we should skip host rewrite
    const skipHostRewrite = /\/(cgi-bin|.*\?.*=|.*\.jsp|.*\.php|.*\.asp|.*\.aspx|.*\.do|.*\.cgi|.*\.pl|.*\.py)/.test(pathAndQuery);
    
    if (skipHostRewrite) {
      // Just upgrade the scheme
      return `${newProtocol}://example.com${pathAndQuery}`;
    }
    
    // Check if path starts with /docs/
    if (pathAndQuery.startsWith('/docs/')) {
      // Rewrite to docs.example.com
      return `${newProtocol}://docs.example.com${pathAndQuery}`;
    }
    
    // Just upgrade the scheme
    return `${newProtocol}://example.com${pathAndQuery}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // February allows 29 for leap years
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
