export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant but simplified for practical use
  // Supports multi-part local addresses like name@tag@example.co.uk
  // Local part: letters, digits, and special characters . _ % + - but no consecutive dots
  // Domain: letters, digits, hyphens, and dots (no underscores, no leading/trailing dots)
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(?:\.(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,})*$/;
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for domain underscores
  const parts = value.split('@');
  // Check all parts except the first (local part can have underscores)
  for (let i = 1; i < parts.length; i++) {
    if (parts[i] && parts[i].includes('_')) {
      return false;
    }
    // Check for trailing dot in each domain part
    if (parts[i] && parts[i].endsWith('.')) {
      return false;
    }
  }
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Minimum length is 10 digits
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // If longer than 11 digits, it's invalid
  if (digitsOnly.length > 11) {
    return false;
  }
  
  // Extract the 10-digit phone number (last 10 digits)
  const phoneNumber = digitsOnly.slice(-10);
  
  // Check area code (first digit cannot be 0 or 1)
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check exchange code (second digit cannot be 0 or 1)
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // If we have 11 digits, the first must be 1 (country code)
  if (digitsOnly.length === 11 && digitsOnly[0] !== '1') {
    return false;
  }
  
  // Validate format with optional separators
  const formatRegex = /^(?:\+?1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/;
  
  return formatRegex.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, keep track of structure
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex:
  // Optional +54 country code
  // Optional 0 trunk prefix (required if no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits (leading digit 1-9)
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:(?:\+54)|(?:54))?(?:0)?(?:9)?(\d{2,4})(\d{6,8})$/;
  const match = cleaned.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits with leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // If no country code, must have trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  const hasTrunkPrefix = cleaned.includes('0') && cleaned.indexOf('0') < cleaned.indexOf(areaCode);
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (value.trim().length === 0) {
    return false;
  }
  
  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Also allow some special characters like Æ (ae ligature)
  const nameRegex = /^[\p{L}\p{M}'\-\sÆæ]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that are just symbols or have too many special characters
  const letterCount = (value.match(/[\p{L}\p{M}]/gu) || []).length;
  if (letterCount === 0) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm helper for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths. Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 13-16 digits, starts with 4
  const visaRegex = /^4\d{12}(\d{3})?$/;
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(?:5[1-5]\d{2}|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{12}$/;
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  const validFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!validFormat) {
    return false;
  }
  
  return runLuhnCheck(cleaned);
}
