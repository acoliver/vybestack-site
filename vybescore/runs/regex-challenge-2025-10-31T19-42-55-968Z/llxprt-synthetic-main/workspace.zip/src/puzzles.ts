/**
 * Matches words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create escaped prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match words starting with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z0-9]*\\b`, 'g');
  
  // Find all matches
  const allMatches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  return allMatches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use pattern to match the digit and token together
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  return text.match(pattern) || [];
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - One uppercase
 * - One lowercase
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 123123)
  for (let patternLength = 2; patternLength <= value.length / 2; patternLength++) {
    for (let i = 0; i <= value.length - patternLength * 2; i++) {
      const pattern = value.substring(i, i + patternLength);
      const nextPattern = value.substring(i + patternLength, i + patternLength * 2);
      
      if (pattern === nextPattern) {
        return false;
      }
    }
  }
  
  // All checks passed
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address pattern (non-comprehensive but covers most common formats)
  // This pattern looks for 8 groups of 1-4 hex digits, separated by colons
  // with special handling for :: shorthand
  const ipv6Regex = /(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,6}:|([0-9a-fA-F]{1,4}:){6}:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})/;
  
  // IPv4 pattern to exclude
  const ipv4Regex = /\b([0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  // If it's an IPv4 address, don't match
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Check if it contains an IPv6 address
  return ipv6Regex.test(value);
}