/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * After sentence punctuation (.?!), exactly one space should be inserted.
 * Extra spaces should be collapsed while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // Common US abbreviations to avoid capitalizing after
  const abbreviations = ["Mr", "Mrs", "Ms", "Dr", "Prof", "Sr", "Jr", "St", "Ave", "Blvd", "Rd", "etc", "e.g", "i.e"];
  const abbrPattern = abbreviations.join("|");
  
  // Split into sentences, preserving punctuation
  return text.replace(/([.?!])(\s*)/g, (match, punctuation, spaces, offset, original) => {
    // Check if this might be an abbreviation (letter abbreviation + .)
    const beforePunctuation = original.substring(offset - 3, offset);
    const isAbbreviation = new RegExp(`\\b(${abbrPattern})\\.$`, "i").test(original.substring(offset - beforePunctuation.length - 1, offset));
    
    // If it's an abbreviation, don't capitalize the next character
    if (isAbbreviation) {
      return match;
    }
    
    // Normal sentence - add a single space and prepare to capitalize next word
    return punctuation + " ";
  }).replace(/(^|[.?!]\s+)([a-z])/g, (_, before, letter) => {
    // Capitalize the first letter of each sentence
    return before + letter.toUpperCase();
  }).replace(/\s+/g, " ") // Collapse multiple spaces to one
  .trim(); // Remove leading/trailing spaces
}

/**
 * Finds URLs in the text. Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http/https protocols and common domains
  const urlPattern = /https?:\/\/[^\s\/$.?#].[^\s\n]*/gi;
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation (.,!?;:) from each match
  return matches.map(url => url.replace(/[.,!?;:)]+$/, ""));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, "https://");
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with example.com domain
  return text.replace(/https?:\/\/example\.com(\/[^\s]*)/gi, (match, path) => {
    // Always upgrade to https
    const newScheme = "https://";
    
    // Check if path starts with /docs/
    if (path.startsWith("/docs/")) {
      // Check for dynamic hints that should prevent host rewrite
      const hasDynamicHint = /\/(cgi-bin|.*\?.*|.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
      
      if (hasDynamicHint) {
        // Just upgrade the scheme, keep the original host
        return newScheme + "example.com" + path;
      } else {
        // Rewrite to docs subdomain
        return newScheme + "docs.example.com" + path;
      }
    } else {
      // Just upgrade the scheme, keep the original host
      return newScheme + "example.com" + path;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return "N/A";
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const yearNum = parseInt(match[3], 10);
  
  // Validate day against month (simplified)
  const daysInMonth = [
    31, // January
    (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0 ? 29 : 28, // February (leap year)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (day > daysInMonth[month - 1]) {
    return "N/A";
  }
  
  return match[3];
}