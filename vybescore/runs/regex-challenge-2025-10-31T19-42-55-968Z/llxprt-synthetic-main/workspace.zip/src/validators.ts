export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn algorithm checksum.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Implements robust email validation.
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic pattern that covers most valid email formats
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // If it fails the basic pattern, it's invalid
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  // Reject double dots in local part
  if (value.split('@')[0].includes('..')) {
    return false;
  }
  
  // Reject domains with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Reject trailing dots in local part or domain
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject leading dots in local part
  if (value.startsWith('.')) {
    return false;
  }
  
  // All checks passed
  return true;
}

/**
 * Implements US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove common separators and whitespace
  const cleaned = value.replace(/[\s\-.()]/g, '');
  
  // Check if it starts with optional +1
  const hasCountryCode = cleaned.startsWith('+1');
  const phoneDigits = hasCountryCode ? cleaned.substring(2) : cleaned;
  
  // Validate length (should be 10 digits for standard US numbers)
  if (phoneDigits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneDigits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if all characters are digits
  if (!/^\d+$/.test(phoneDigits)) {
    return false;
  }
  
  // If extensions are allowed, check for them
  if (options?.allowExtensions) {
    const extensionMatch = value.match(/(?:ext\.?|extension|x)\s*(\d+)$/i);
    if (extensionMatch) {
      return /^\d+$/.test(extensionMatch[1]);
    }
  }
  
  return true;
}

/**
 * Implements Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  const argentinePhoneRegex = /^(\+54)?(0?)(9?)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const countryCode = match[1];  // +54 or undefined
  const trunkPrefix = match[2];  // 0 or undefined
  // const mobileIndicator = match[3];  // 9 or undefined - not used in validation
  const areaCode = match[4];  // 2-4 digits, not starting with 0
  const subscriberNumber = match[5];  // 6-8 digits
  
  // If country code is omitted, trunk prefix must be present
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Area code must be 2-4 digits and start with 1-9
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (!subscriberNumber || subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Regex that allows unicode letters, accents, apostrophes, hyphens, and spaces
  // Rejects digits, symbols, and X Æ A-12 style names
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check if the name contains any digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check against the name regex
  return nameRegex.test(value);
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 13 or 16 digits starting with 4
  if (/^4(\d{12}|\d{15})$/.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  // Mastercard: 16 digits starting with 51-55 or 2221-2720
  if (/^(5[1-5]\d{14}|2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12})$/.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  // American Express: 15 digits starting with 34 or 37
  if (/^3[47]\d{13}$/.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  // No valid format found
  return false;
}
