#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { exit, argv } from 'node:process';
import type { ReportData, RenderOptions, Format, ReportRenderer } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }
  
  const inputFile = args[0];
  let format: Format | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format') {
      const formatValue = args[i + 1];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error('Error: Unsupported format. Supported formats: markdown, text');
        exit(1);
      }
      format = formatValue as Format;
      i++; // Skip the format value
    } else if (args[i] === '--output') {
      outputPath = args[i + 1];
      i++; // Skip the output path
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    exit(1);
  }
  
  return { inputFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (must be a string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (must be a string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (must be an array)');
  }
  
  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${index}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "label" field (must be a string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "amount" field (must be a number)`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file "${filePath}": ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: "${filePath}"`);
    }
    throw error;
  }
}

function getRenderer(format: Format): ReportRenderer {
  const renderers = {
    markdown: markdownRenderer,
    text: textRenderer,
  };
  
  return renderers[format];
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Error writing to file "${outputPath}":`, error);
      exit(1);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  try {
    const args = parseArguments();
    const reportData = loadReportData(args.inputFile);
    const renderer = getRenderer(args.format);
    const options: RenderOptions = { includeTotals: args.includeTotals };
    
    const output = renderer.render(reportData, options);
    writeOutput(output, args.outputPath);
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : 'Unknown error');
    exit(1);
  }
}

main();
