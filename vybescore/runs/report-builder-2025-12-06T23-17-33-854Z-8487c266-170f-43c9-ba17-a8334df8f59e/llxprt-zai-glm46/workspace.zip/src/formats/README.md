# Report Formatters

This directory contains format implementations for the report builder CLI.

## Interface

All formatters must implement the `ReportRenderer` interface defined in `../types.js`:

```typescript
interface ReportRenderer {
  render(data: ReportData, options: RenderOptions): string;
}
```

## Available Formatters

### markdown.ts
Renders reports in Markdown format with:
- `# <title>` heading
- Summary text
- `## Entries` section with bullet list using `- **<label>** — $<amount>`
- Optional total with `**Total:** $<amount>` when `includeTotals` is true

### text.ts
Renders reports in plain text format with:
- Title as plain text
- Summary text  
- `Entries:` heading with bullet list using `- <label>: $<amount>`
- Optional total with `Total: $<amount>` when `includeTotals` is true

## Usage

Formatters are imported by the CLI and used via a format map:

```typescript
import { markdownRenderer } from './formats/markdown.js';
import { textRenderer } from './formats/text.js';

const formatters = {
  markdown: markdownRenderer,
  text: textRenderer,
};
```

## Adding New Formats

To add a new format:

1. Create a new file in this directory (e.g., `html.ts`)
2. Implement the `ReportRenderer` interface
3. Export a renderer instance
4. Add the formatter to the CLI's format map
5. Update the `Format` type in `../types.js` to include the new format
