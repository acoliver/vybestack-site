import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT || '3535';
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;
const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.resolve('views'));

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[@+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postal: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postal);
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!formData.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!formData.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!formData.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!formData.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!formData.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  if (!formData.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, digits, spaces, and hyphens' });
  }
  if (!formData.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!formData.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  if (!formData.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Phone number may contain digits, spaces, parentheses, dashes, and a leading @' });
  }

  return errors;
}

async function initDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  let database: Database;

  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    database = new SQL.Database(buffer);
  } else {
    database = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    database.run(schema);
    saveDatabase(database);
  }

  return database;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  const dataDir = path.dirname(DB_PATH);
  
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  fs.writeFileSync(DB_PATH, buffer);
}

app.get('/', (req: Request, res: Response) => {
  const errors: ValidationError[] = [];
  const formData: FormData = {};
  res.render('index', { errors, formData });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    res.status(400);
    return res.render('index', { errors, formData });
  }

  if (db) {
    db.run(
      `INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName!.trim(),
        formData.lastName!.trim(),
        formData.streetAddress!.trim(),
        formData.city!.trim(),
        formData.stateProvince!.trim(),
        formData.postalCode!.trim(),
        formData.country!.trim(),
        formData.email!.trim(),
        formData.phone!.trim(),
      ]
    );
    saveDatabase(db);
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

async function startServer(): Promise<void> {
  db = await initDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  const gracefulShutdown = (signal: string): void => {
    console.log(`Received ${signal}, closing server gracefully...`);
    server.close(() => {
      if (db) {
        db.close();
        db = null;
      }
      console.log('Server closed');
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

export { app, startServer };
