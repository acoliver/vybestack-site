/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies
  getActiveObserver()
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Mark observer as disposed to stop further updates
    observer.disposed = true
    observer.value = undefined
    observer.updateFn = () => value!
    observer.dependents = []
    
    // Remove from dependency chains
    if (observer.nextObserver) {
      observer.nextObserver = undefined
    }
  }
}
