/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Compute initial value
  updateObserver(o)
  
  return (): T => {
    // Register this computed as a dependency
    const observer = getActiveObserver()
    if (observer) {
      // Store the observer to notify when dependencies change
      if (!o.dependents) {
        o.dependents = []
      }
      if (!o.dependents.includes(observer)) {
        o.dependents.push(observer)
      }
    }
    
    return o.value!
  }
}
