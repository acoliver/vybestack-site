#!/usr/bin/env node

import fs from 'node:fs';
import { formatters } from '../formats/index.js';
import type { ReportData, RenderOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  if (args.length < 4) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const result: CliArgs = {
    dataFile: args[2],
    format: '',
    includeTotals: false,
  };

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument ${arg}`);
      process.exit(1);
    }
  }

  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field`);
    }
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field`);
    }
  }

  return data as ReportData;
}

function main() {
  try {
    const args = parseArguments(process.argv);

    // Check if format is supported
    if (!formatters[args.format]) {
      console.error(`Error: Unsupported format "${args.format}"`);
      process.exit(1);
    }

    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = fs.readFileSync(args.dataFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file "${args.dataFile}"`);
      } else if (error instanceof Error) {
        console.error(`Error reading file "${args.dataFile}": ${error.message}`);
      } else {
        console.error(`Error reading file "${args.dataFile}"`);
      }
      process.exit(1);
    }

    // Validate report data
    const reportData = validateReportData(jsonData);

    // Render report
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    const output = formatters[args.format](reportData, options);

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();