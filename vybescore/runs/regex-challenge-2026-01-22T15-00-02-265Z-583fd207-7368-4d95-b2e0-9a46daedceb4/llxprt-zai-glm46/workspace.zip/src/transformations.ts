/**
 * Capitalize the first character of each sentence.
 * - Capitalize after sentence-ending punctuation (.!?), properly handling multiple punctuation.
 * - Insert exactly one space between sentences even if input omitted it.
 * - Collapse extra spaces within text to single spaces.
 * - Preserve abbreviations when possible (e.g., Mr., Dr., etc. after a word).
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces into single spaces
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Insert space after sentence endings if missing (before lowercase letter)
  normalized = normalized.replace(/([.!?])([a-z])/g, '$1 $2');
  
  // Insert space after sentence endings if missing (before uppercase letter)
  normalized = normalized.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  // Capitalize first letter of sentences
  // Match start of string or after sentence-ending punctuation
  let result = normalized.replace(/(^|[.!?]\s+)([a-z])/g, (_, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Capitalize first letter of string if lowercase
  result = result.replace(/^[a-z]/, letter => letter.toUpperCase());
  
  return result;
}

/**
 * Extract all URLs from text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Match http:// or https:// followed by non-whitespace
  // Include word characters, dots, slashes, etc. for domain and path
  const urlRegex = /https?:\/\/[^\s<]+/gi;
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?\]"']+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints: cgi-bin, query strings, legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, protocol, host, path) => {
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // Check if path has dynamic hints that should prevent host rewrite
    const dynamicHints = [
      /\/cgi-bin\//i,
      /[?&=]/,      // Query string params
      /\.jsp$/i,
      /\.php$/i,
      /\.asp$/i,
      /\.aspx$/i,
      /\.do$/i,
      /\.cgi$/i,
      /\.pl$/i,
      /\.py$/i
    ];
    
    const shouldSkipRewrite = dynamicHints.some(hint => hint.test(path));
    
    // Check if path starts with /docs/
    const isDocsPath = /^\/docs\//.test(path);
    
    if (isDocsPath && !shouldSkipRewrite) {
      // Rewrite to docs.example.com
      return secureProtocol + 'docs.example.com' + path;
    } else {
      // Just upgrade protocol
      return secureProtocol + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Days per month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Validate day based on month
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
