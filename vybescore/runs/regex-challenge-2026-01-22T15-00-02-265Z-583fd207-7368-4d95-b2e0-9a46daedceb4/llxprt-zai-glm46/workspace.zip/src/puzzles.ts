/**
 * Find all words beginning with the prefix, excluding listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match words starting with prefix (word boundary at start)
  const wordRegex = new RegExp(`\\b(${escapedPrefix}\\w+)`, 'gi');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches
    .map(word => word)
    .filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * Find occurrences of token that appear after a digit and not at the start of the string.
 * Uses lookahead/lookbehind to ensure token is preceded by a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit+token combination (lookbehind not available in all JS contexts)
  // Match token that is preceded by a digit
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches including the digit
  const matches = text.match(tokenRegex) || [];
  
  return matches;
}

/**
 * Validate passwords according to strong policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter  
 * - One digit
 * - One symbol (non-alphanumeric, non-whitespace)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab, 1212)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, 1212)
  // This pattern looks for any 2-4 character sequence that repeats immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const seq = value.slice(i, i + len);
      const nextSeq = value.slice(i + len, i + len * 2);
      if (seq === nextSeq) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses don't match.
 * Supports:
 * - Full form: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
 * - Compressed zeros: 2001:db8:85a3::8a2e:370:7334
 * - Loopback: ::1
 * - Leading zeros compressed: 2001:db8::1
 * 
 * Rejects IPv4 addresses and mixed IPv6 notations.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that handles various formats
  // Supports full notation and compressed :: notation
  const ipv6Regex = /(?:^|(?<=\s))(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?::[0-9a-fA-F]{1,4}){1,7}|::)(?:$|(?=\s))/;
  
  // IPv4 pattern to exclude
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check for IPv6
  const hasIPv6 = ipv6Regex.test(value);
  
  // Make sure it's not actually an IPv4 address
  const hasIPv4 = ipv4Regex.test(value);
  
  return hasIPv6 && !hasIPv4;
}
