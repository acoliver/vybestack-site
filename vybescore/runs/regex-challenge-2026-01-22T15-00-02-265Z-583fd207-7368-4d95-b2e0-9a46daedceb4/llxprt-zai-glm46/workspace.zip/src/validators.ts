export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses according to RFC standards with additional constraints.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for invalid patterns
  // No consecutive dots
  if (/\.\./.test(value)) {
    return false;
  }

  // No trailing dot in local part or domain
  if (/\.$/.test(value)) {
    return false;
  }

  // No leading dot in local part
  if (/^\./.test(value)) {
    return false;
  }

  // Domain cannot contain underscores
  const domain = value.split('@')[1];
  if (domain && /_/.test(domain)) {
    return false;
  }

  // Domain must have at least one dot and valid TLD (min 2 chars)
  if (!domain || !/\.[a-zA-Z]{2,}$/.test(domain)) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all whitespace and separators
  const cleaned = value.replace(/[\s.]/g, '');
  
  // Handle optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && cleaned.length > 10) {
    // If there's a leading 1 that's not part of +1 format
    digits = digits.slice(1);
  }

  // Extract digits only
  const digitOnly = digits.replace(/\D/g, '');

  // Must be exactly 10 digits for US numbers

  // Must be exactly 10 digits for US numbers
  if (digitOnly.length !== 10) {
    return false;
  }

  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digitOnly.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) - cannot start with 0 or 1
  const exchangeCode = digitOnly.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * 
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits total
 * - Without country code, must begin with trunk prefix 0
 * - Allow single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators but keep structure
  const normalized = value.replace(/[-\s]/g, '');
  
  // Pattern: [+]54 [0] [9] area_code subscriber
  // area_code: 2-4 digits, leading 1-9
  // subscriber: 6-8 digits
  
  // Build regex with all components
  const argentinePhoneRegex = /^(?:\+54)?0?9?[1-9]\d{1,3}\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(normalized)) {
    return false;
  }

  // Extract digits without country code
  let digits = normalized;
  if (digits.startsWith('+54')) {
    digits = digits.slice(3);
  }

  // If no country code, must start with trunk prefix 0
  if (!value.includes('+54')) {
    if (!digits.startsWith('0')) {
      return false;
    }
  }

  // Remove optional trunk prefix 0 and mobile indicator 9
  if (digits.startsWith('0')) {
    digits = digits.slice(1);
  }
  if (digits.startsWith('9')) {
    digits = digits.slice(1);
  }

  // Now digits should be: area_code (2-4 digits) + subscriber (6-8 digits)
  // Total: 8-12 digits minimum
  const allDigits = normalized.replace(/\D/g, '');
  
  // Must have reasonable total length
  if (allDigits.length < 8 || allDigits.length > 13) {
    return false;
  }

  // Validate area code is 2-4 digits
  // After removing country code (+54), trunk prefix (0), and mobile indicator (9)
  // The next 2-4 digits are the area code
  const remainingDigits = normalized.replace(/\+54/g, '').replace(/^0/, '').replace(/^9/, '');
  const areaCode = remainingDigits.match(/^[1-9]\d{1,3}/)?.[0];
  
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Validate subscriber number length (remaining digits after area code)
  const subscriber = remainingDigits.slice(areaCode.length);
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Accepts: José, O'Brien, Mary-Jane, François
 * Rejects: X Æ A-12, names with digits or symbols
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Must have at least one letter
  // Cannot start/end with hyphen, apostrophe, or space
  // No consecutive spaces or special chars
  
  const nameRegex = /^[\p{L}]+(?:[-'\s][\p{L}]+)*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }

  // Must contain at least two letters (first and last name, or at least 2 chars)
  const letterCount = (value.match(/[\p{L}]/gu) || []).length;
  if (letterCount < 2) {
    return false;
  }

  // Cannot contain digits or other symbols
  if (/\d/.test(value) || /[^\p{L}\s\-']/u.test(value)) {
    return false;
  }

  return true;
}

/**
 * Luhn algorithm for credit card checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa, Mastercard, and AmEx formats.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: 13-16 digits, starts with 4
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(?:5[1-5]\d{2}|2[2-7][0-2]\d)\d{12}$/;
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;

  const validLength = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);

  if (!validLength) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
