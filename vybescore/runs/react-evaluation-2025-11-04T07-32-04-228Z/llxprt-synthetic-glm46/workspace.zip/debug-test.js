import { createInput, createComputed, createCallback } from './dist/index.js'

console.log('Debugging the failing test...')

const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => values1.push(output()))
const values2 = []
createCallback(() => values2.push(output()))

console.log('Initial values after creation:', values1, values2)

setInput(31)
console.log('After setting input to 31:', values1, values2)

unsubscribe1()
console.log('After unsubscribe1:', values1, values2)

setInput(41)
console.log('After setting input to 41:', values1, values2)

console.log('Final lengths:', values1.length, values2.length)
console.log('values2 length > values1 length?', values2.length > values1.length)