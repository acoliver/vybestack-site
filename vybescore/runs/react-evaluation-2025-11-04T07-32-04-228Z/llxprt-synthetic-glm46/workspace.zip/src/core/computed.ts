/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  getActiveObserver,
  _setActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Determine equality function
  let equalFn: EqualFn<T>
  if (_equal === false) {
    equalFn = () => false
  } else if (_equal === true || _equal === undefined) {
    equalFn = (a, b) => a === b
  } else {
    equalFn = _equal
  }
  
  // Create subject to track dependencies
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: new Set(),
    value: value as T,
    equalFn,
  }
  
  // Create observer with update function
  const observer: Observer<T> = {
    name: options?.name,
    value: subject.value,
    updateFn: (prev: T | undefined) => {
      // Compute new value by executing update function
      // This will register dependencies
      const newValue = updateFn(prev)
      
      // Update subject's value if it changed
      if (!equalFn(prev || null as T, newValue)) {
        subject.value = newValue
        observer.value = newValue
        
        // Notify all dependent observers
        subject.observers!.forEach(obs => {
          updateObserver(obs)
        })
      }
      
      return newValue
    }
  }
  
  subject.observer = observer
  
  // Compute initial value
  _setActiveObserver(observer)
  try {
    observer.value = updateFn(observer.value)
    subject.value = observer.value
  } finally {
    _setActiveObserver(undefined)
  }
  
  // Create getter function
  const getter: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    
    // Register this computed as a dependency for the active observer
    if (activeObs) {
      subject.observers!.add(activeObs as Observer<unknown>)
    }
    
    return subject.value
  }
  
  return getter
}