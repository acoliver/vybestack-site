/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create observer with update function that performs side effects
  let active = true
  const observer: Observer<T> = {
    value,
    updateFn: (prev: T | undefined) => {
      if (!active) return value as T
      // Execute the callback with side effects
      return updateFn(prev)
    }
  }
  
  // Track all subjects this callback depends on
  const dependentSubjects = new Set<Subject<unknown>>()
  
  // Attach the tracking set to the observer for cleanup
  ;(observer as Observer<T> & { _dependentSubjects: Set<Subject<unknown>> })._dependentSubjects = dependentSubjects
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  return () => {
    if (!active) return
    active = false
    
    // Remove this observer from all dependent subjects' observer sets
    dependentSubjects.forEach(subject => {
      if (subject.observers && subject.observers.has(observer as Observer<unknown>)) {
        subject.observers.delete(observer as Observer<unknown>)
      }
      // Clear the subject's observer if it matches this observer
      if (subject.observer === observer) {
        subject.observer = undefined
      }
    })
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}