/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Determine the equality function
  let equalFn: EqualFn<T>
  if (_equal === false) {
    // No equality - always notify changes
    equalFn = () => false
  } else if (_equal === true || _equal === undefined) {
    // Default strict equality
    equalFn = (a, b) => a === b
  } else {
    // Custom equality function
    equalFn = _equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      // Add as a dependent observer
      s.observers!.add(observer as Observer<unknown>)
      
      // For callback observers, always add this subject to their tracking set
      // Initialize the tracking set if it doesn't exist
      const observerWithTracking = observer as Observer<T> & { _dependentSubjects?: Set<Subject<unknown>> }
      if (!observerWithTracking._dependentSubjects) {
        observerWithTracking._dependentSubjects = new Set()
      }
      observerWithTracking._dependentSubjects.add(s as Subject<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const previousValue = s.value
    s.value = nextValue
    
    // Notify all dependent observers if value changed
    if (!equalFn(previousValue, nextValue)) {
      // Notify all dependent observers (this includes the subject's observer)
      s.observers!.forEach(observer => {
        updateObserver(observer)
      })
    }
    
    return s.value
  }

  return [read, write]
}