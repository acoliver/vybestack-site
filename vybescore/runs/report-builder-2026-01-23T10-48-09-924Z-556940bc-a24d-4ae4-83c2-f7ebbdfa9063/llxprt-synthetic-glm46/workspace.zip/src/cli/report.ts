#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import process from 'node:process';
import type { Args, ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(): Args {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  let dataFile: string | undefined;
  let format: 'markdown' | 'text' | null = null;
  let output: string | undefined;
  let includeTotals = false;
  
  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        format = args[++i] as 'markdown' | 'text';
        break;
      case '--output':
        output = args[++i];
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (args[i].startsWith('--')) {
          console.error(`Unknown option: ${args[i]}`);
          process.exit(1);
        }
        if (dataFile) {
          console.error('Multiple data files specified');
          process.exit(1);
        }
        dataFile = args[i];
        break;
    }
  }
  
  if (!dataFile) {
    console.error('Data file is required');
    process.exit(1);
  }
  
  if (!format) {
    console.error('Format is required (--format markdown|text)');
    process.exit(1);
  }
  
  if (format !== 'markdown' && format !== 'text') {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }
  
  return {
    dataFile,
    format,
    output,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: title must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: summary must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: entries must be an array');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry ${i} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i} must have a string label`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${i} must have a number amount`);
    }
  }
  
  return obj as unknown as ReportData;
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  if (format === 'markdown') {
    return renderMarkdown(data, { includeTotals });
  } else {
    return renderText(data, { includeTotals });
  }
}

function main(): void {
  try {
    const args = parseArgs();
    
    let data: unknown;
    try {
      const fileContents = readFileSync(args.dataFile, 'utf8');
      data = JSON.parse(fileContents);
    } catch (error) {
      console.error(`Error reading or parsing ${args.dataFile}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
    
    const reportData = validateReportData(data);
    const output = renderReport(reportData, args.format, args.includeTotals || false);
    
    if (args.output) {
      writeFileSync(args.output, output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}` || process.argv[1].endsWith('cli/report.js')) {
  main();
}
