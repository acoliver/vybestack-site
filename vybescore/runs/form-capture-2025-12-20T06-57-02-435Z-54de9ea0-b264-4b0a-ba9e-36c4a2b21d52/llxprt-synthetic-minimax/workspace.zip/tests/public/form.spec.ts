import { describe, it, expect } from 'vitest';

describe('Form Validation', () => {
  it('should validate required fields', () => {
    const requiredFields = ['firstName', 'lastName', 'streetAddress', 'city', 'stateProvince', 'postalCode', 'country', 'email', 'phone'];
    
    requiredFields.forEach(field => {
      expect(field).toBeTruthy();
    });
    
    expect(requiredFields.length).toBe(9);
  });
  
  it('should have email validation regex', () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    expect(emailRegex.test('test@example.com')).toBe(true);
    expect(emailRegex.test('invalid-email')).toBe(false);
  });
  
  it('should have phone validation regex', () => {
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    expect(phoneRegex.test('+1 555-123-4567')).toBe(true);
    expect(phoneRegex.test('5551234567')).toBe(true);
  });
  
  it('should have postal code validation', () => {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    expect(postalRegex.test('10001')).toBe(true);
    expect(postalRegex.test('SW1A 1AA')).toBe(true);
    expect(postalRegex.test('C1000')).toBe(true);
  });
});

describe('Server Routes', () => {
  it('should have defined routes', () => {
    const routes = ['/', '/submit', '/thank-you'];
    
    routes.forEach(route => {
      expect(route).toBeTruthy();
    });
    
    expect(routes.length).toBe(3);
  });
});