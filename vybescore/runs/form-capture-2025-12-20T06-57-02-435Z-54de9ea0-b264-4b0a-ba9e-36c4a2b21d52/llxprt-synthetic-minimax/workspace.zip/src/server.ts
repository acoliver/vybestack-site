import express, { Request, Response } from "express";
import path from "path";
import { Database } from "sql.js";

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("public"));

// Set view engine
app.set("views", path.join(__dirname, "../views"));
app.set("view engine", "ejs");

// Initialize SQL.js
let db: Database;

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, "").length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

function validateRequired(field: string): boolean {
  return field.trim().length > 0;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

function validateFormData(data: FormData): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  if (!validateRequired(data.firstName)) {
    errors.firstName = "First name is required";
  }
  if (!validateRequired(data.lastName)) {
    errors.lastName = "Last name is required";
  }
  if (!validateRequired(data.streetAddress)) {
    errors.streetAddress = "Street address is required";
  }
  if (!validateRequired(data.city)) {
    errors.city = "City is required";
  }
  if (!validateRequired(data.stateProvince)) {
    errors.stateProvince = "State/Province/Region is required";
  }
  if (!validateRequired(data.postalCode) || !validatePostalCode(data.postalCode)) {
    errors.postalCode = "Valid postal code is required";
  }
  if (!validateRequired(data.country)) {
    errors.country = "Country is required";
  }
  if (!validateRequired(data.email) || !validateEmail(data.email)) {
    errors.email = "Valid email address is required";
  }
  if (!validateRequired(data.phone) || !validatePhone(data.phone)) {
    errors.phone = "Valid phone number is required";
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get("/", (req: Request, res: Response) => {
  res.render("form", { 
    errors: {}, 
    formData: {},
    title: "Contact Us"
  });
});

app.post("/submit", (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || "",
    lastName: req.body.lastName || "",
    streetAddress: req.body.streetAddress || "",
    city: req.body.city || "",
    stateProvince: req.body.stateProvince || "",
    postalCode: req.body.postalCode || "",
    country: req.body.country || "",
    email: req.body.email || "",
    phone: req.body.phone || ""
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    return res.status(400).render("form", {
      errors: validation.errors,
      formData,
      title: "Contact Us - Please Fix Errors"
    });
  }

  try {
    db.run(
      `INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );
    
    // Save database to file
    db.export();
    // Note: In a real application, you would write this to the file system
    console.log("Database saved");
    
    return res.redirect(302, "/thank-you");
  } catch (error) {
    console.error("Error saving to database:", error);
    return res.status(500).render("form", {
      errors: { general: "Internal server error. Please try again." },
      formData,
      title: "Contact Us - Error"
    });
  }
});

app.get("/thank-you", (req: Request, res: Response) => {
  res.render("thank-you", { title: "Thank You!" });
});

// Database initialization
async function initDatabase() {
  try {
    // Initialize database from schema
    const fs = await import("fs");
    const sqlJs = await import("sql.js");
    
    // Create new database instance
    db = new sqlJs.Database();
    
    // Load schema
    const schema = fs.readFileSync(path.join(__dirname, "../data/schema.sql"), "utf8");
    db.exec(schema);
    
    console.log("Database initialized successfully");
  } catch (error) {
    console.error("Failed to initialize database:", error);
    process.exit(1);
  }
}

// Graceful shutdown
function gracefulShutdown() {
  console.log("Shutting down gracefully...");
  if (db) {
    db.close();
  }
  process.exit(0);
}

process.on("SIGTERM", gracefulShutdown);
process.on("SIGINT", gracefulShutdown);

// Start server
async function startServer() {
  await initDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
}

startServer();
