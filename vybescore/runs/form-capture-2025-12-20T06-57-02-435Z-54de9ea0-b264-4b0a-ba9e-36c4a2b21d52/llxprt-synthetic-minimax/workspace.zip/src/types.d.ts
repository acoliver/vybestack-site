declare module "sql.js" {
  export class Database {
    exec(sql: string): void;
    run(sql: string, params?: Array<unknown>): void;
    export(): Uint8Array;
    close(): void;
  }
}
