import express from 'express';
import path from 'path';
import { dbManager } from './db.js';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
  values: FormData;
}

function validateFormData(data: FormData): ValidationResult {
  const errors: string[] = [];
  const values: FormData = { ...data };

  // Required field validation
  if (!data.firstName?.trim()) errors.push('First name is required');
  if (!data.lastName?.trim()) errors.push('Last name is required');
  if (!data.streetAddress?.trim()) errors.push('Street address is required');
  if (!data.city?.trim()) errors.push('City is required');
  if (!data.stateProvince?.trim()) errors.push('State / Province / Region is required');
  if (!data.postalCode?.trim()) errors.push('Postal / Zip code is required');
  if (!data.country?.trim()) errors.push('Country is required');
  if (!data.email?.trim()) errors.push('Email is required');
  if (!data.phone?.trim()) errors.push('Phone number is required');

  // Email validation
  if (data.email?.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.push('Please enter a valid email address');
    }
  }

  // Phone number validation (international formats allowed)
  if (data.phone?.trim()) {
    const phoneRegex = /^[+]?[\d\s()\-@]+$/;
    if (!phoneRegex.test(data.phone.trim())) {
      errors.push('Please enter a valid phone number');
    }
  }

  // Postal code validation (alphanumeric strings)
  if (data.postalCode?.trim()) {
    const postalRegex = /^[A-Za-z0-9\s\-@]+$/;
    if (!postalRegex.test(data.postalCode.trim())) {
      errors.push('Please enter a valid postal code');
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    values
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    // Validation failed, re-render form with errors
    res.status(400).render('form', {
      errors: validation.errors,
      values: validation.values
    });
  } else {
    // Validation passed, save to database
    const submission = {
      first_name: formData.firstName!.trim(),
      last_name: formData.lastName!.trim(),
      street_address: formData.streetAddress!.trim(),
      city: formData.city!.trim(),
      state_province: formData.stateProvince!.trim(),
      postal_code: formData.postalCode!.trim(),
      country: formData.country!.trim(),
      email: formData.email!.trim(),
      phone: formData.phone!.trim()
    };

    dbManager.insertSubmission(submission)
      .then(() => {
        res.redirect('/thank-you');
      })
      .catch((error) => {
        console.error('Database error:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: validation.values
        });
      });
  }
});

app.get('/thank-you', (req, res) => {
  // In a real app, you might fetch the most recent submission
  // For now, we'll use the firstName from the form data if available
  res.render('thank-you', {
    firstName: 'friend'
  });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to access the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
