/**
 * Utility functions for report processing.
 */

import type { ReportData, ReportEntry, RenderOptions } from './types.js';

/**
 * Validates and parses report data from an unknown object.
 * Throws an error with a helpful message if validation fails.
 */
export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  const entries: ReportEntry[] = [];
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: entry at index ${i} missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: entry at index ${i} missing or invalid "amount" field (expected number)`);
    }

    entries.push({ label: entryObj.label, amount: entryObj.amount });
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

/**
 * Formats a number as a currency string with exactly two decimal places.
 */
export function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Computes the total amount from all entries.
 */
export function computeTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

// Re-export types for convenience
export type { ReportData, ReportEntry, RenderOptions };
