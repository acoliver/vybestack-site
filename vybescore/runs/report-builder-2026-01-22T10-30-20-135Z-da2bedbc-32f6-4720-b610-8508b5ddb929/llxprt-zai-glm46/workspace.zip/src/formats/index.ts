/**
 * Format registry and exports.
 */

import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type FormatterFn = (data: ReportData, options: RenderOptions) => string;

export const formatters: Record<string, FormatterFn> = {
  markdown: renderMarkdown,
  text: renderText,
};

export { renderMarkdown, renderText };
