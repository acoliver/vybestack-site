#!/usr/bin/env node

/**
 * Report Builder CLI
 * Renders reports from JSON input in various formats.
 */

import * as fs from 'node:fs';
import { formatters } from '../formats/index.js';
import { validateReportData, type RenderOptions } from '../utils.js';

/**
 * Parses CLI arguments from process.argv.
 * Returns an object with the input file path, format, output path (optional), and options.
 */
function parseArgs(args: string[]): {
  inputFile: string;
  format: string;
  outputPath: string | undefined;
  options: RenderOptions;
} {
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  // Skip node executable and script path
  const positionalArgs: string[] = [];
  const flags: Record<string, string> = {};
  let outputFile: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 2; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path argument');
        process.exit(1);
      }
      outputFile = args[++i];
    } else if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a format argument');
        process.exit(1);
      }
      flags.format = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('--')) {
      console.error(`Error: unknown flag ${arg}`);
      process.exit(1);
    } else {
      positionalArgs.push(arg);
    }
  }

  if (positionalArgs.length < 1) {
    console.error('Error: missing input file path');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (!flags.format) {
    console.error('Error: --format is required');
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  return {
    inputFile: positionalArgs[0],
    format: flags.format,
    outputPath: outputFile,
    options: { includeTotals },
  };
}

/**
 * Reads and parses JSON from a file.
 * Throws a helpful error if the file cannot be read or parsed.
 */
function readJsonFile(filePath: string): unknown {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file '${filePath}': ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: '${filePath}'`);
    }
    throw error;
  }
}

/**
 * Main CLI entry point.
 */
function main(): void {
  try {
    const { inputFile, format, outputPath, options } = parseArgs(process.argv);

    // Check if format is supported
    if (!formatters[format]) {
      console.error(`Unsupported format: '${format}'`);
      console.error('Supported formats: markdown, text');
      process.exit(1);
    }

    // Read and validate input data
    const rawData = readJsonFile(inputFile);
    const reportData = validateReportData(rawData);

    // Render the report
    const formatter = formatters[format];
    const output = formatter(reportData, options);

    // Write to file or stdout
    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf-8');
      console.error(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
