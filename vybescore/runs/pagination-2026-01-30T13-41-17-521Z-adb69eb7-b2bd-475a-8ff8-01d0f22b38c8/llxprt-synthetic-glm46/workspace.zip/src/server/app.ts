import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validateQueryParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): { page?: number; limit?: number; error?: string } {
  // Default values
  const page = pageParam ? Number(pageParam) : 1;
  const limit = limitParam ? Number(limitParam) : 5;

  // Validate page parameter
  if (pageParam !== undefined) {
    if (isNaN(page)) {
      return { error: 'Page parameter must be a number' };
    }
    if (page <= 0) {
      return { error: 'Page parameter must be greater than 0' };
    }
    // Set a reasonable upper limit for page to prevent excessive requests
    if (page > 1000) {
      return { error: 'Page parameter is too large' };
    }
  }

  // Validate limit parameter
  if (limitParam !== undefined) {
    if (isNaN(limit)) {
      return { error: 'Limit parameter must be a number' };
    }
    if (limit <= 0) {
      return { error: 'Limit parameter must be greater than 0' };
    }
    // Set a reasonable upper limit to prevent excessive data retrieval
    if (limit > 100) {
      return { error: 'Limit parameter is too large' };
    }
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validateQueryParams(pageParam, limitParam);

    if (validation.error) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
