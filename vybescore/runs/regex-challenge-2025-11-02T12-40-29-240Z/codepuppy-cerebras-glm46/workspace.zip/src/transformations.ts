/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First normalize extra spaces - collapse multiple spaces to single space
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  if (normalized.length === 0) return normalized;
  
  // Capitalize first letter of the text
  normalized = normalized[0].toUpperCase() + normalized.slice(1);
  
  // Find sentence boundaries and capitalize
  // Sentence ends with ., ?, or ! followed by optional quotes/brackets and then space or end
  const sentenceEndRegex = /([.!?])(["'\)\]]*)(\s+|$)/g;
  
  let lastIndex = 0;
  let result = '';
  let match;
  
  while ((match = sentenceEndRegex.exec(normalized)) !== null) {
    // Add content up to and including the sentence end
    result += normalized.slice(lastIndex, match.index + match[0].length);
    
    // Find the next non-space character after the sentence end
    const nextCharIndex = match.index + match[0].length;
    
    if (nextCharIndex < normalized.length) {
      // Ensure exactly one space after sentence end (if there are spaces)
      if (match[3].length > 1) {
        // Replace multiple spaces with single space
        result = result.slice(0, -match[3].length) + ' ';
      }
      
      // Capitalize the next character
      const nextChar = normalized[nextCharIndex];
      const capitalizedNext = nextChar.toUpperCase();
      result += capitalizedNext;
      
      lastIndex = nextCharIndex + 1;
    } else {
      lastIndex = nextCharIndex;
    }
  }
  
  // Add any remaining text
  if (lastIndex < normalized.length) {
    result += normalized.slice(lastIndex);
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http/https protocols and domain patterns
  // Captures URLs but excludes trailing punctuation
  const urlRegex = /\bhttps?:\/\/[^\s/$.?#].[^\s]*\b(?![\]\).,;:'"])/gi;
  
  const matches = text.match(urlRegex);
  
  if (!matches) return [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that might have been caught
    return url.replace(/[\]\).,;:'"]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  const httpsRegex = /http:\/\//g;
  
  return text.replace(httpsRegex, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First upgrade all http to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Handle example.com specific rewriting for docs paths
  // Pattern: https://example.com/docs/...
  // Exclude: paths with cgi-bin, query strings (?&=), or legacy extensions
  const docsUrlRegex = /(https:\/\/example\.com)(\/docs\/[^\s?]*?)(?![?&]?(?:.{0,200})(?:\.(jsp|php|asp|aspx|do|cgi|pl|py)|cgi-bin))/gi;
  
  result = result.replace(docsUrlRegex, (match, domain, path) => {
    // Check if path contains excluded patterns
    const hasExcludedPattern = /cgi-bin|[?&=]|\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    if (!hasExcludedPattern) {
      // Rewrite to docs.example.com
      return 'https://docs.example.com' + path;
    }
    
    return match; // Keep original if excluded
  });
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regex for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate day based on month (simplified validation)
  const daysInMonth = [
    31, // January
    (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0 ? 29 : 28, // February (leap year)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (day > daysInMonth[month - 1]) return 'N/A';
  
  return yearStr;
}
