
/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Split text into words and filter manually
  const words = text.match(/\b\w+\b/g) || [];
  
  // Filter words that start with the prefix (case-insensitive)
  const prefixedWords = words.filter(word => 
    word.toLowerCase().startsWith(prefix.toLowerCase())
  );
  
  // Filter out exceptions (case-insensitive)
  const lowerExceptions = exceptions.map(e => e.toLowerCase());
  
  return prefixedWords
    .map(word => word.toLowerCase())
    .filter(word => !lowerExceptions.includes(word))
    .filter((word, index, arr) => arr.indexOf(word) === index) // Remove duplicates
    .sort();
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Manual approach to avoid regex escaping issues
  const results: string[] = [];
  
  for (let i = 0; i < text.length; i++) {
    // Skip if at start of string
    if (i === 0) continue;
    
    // Check if current position starts with token and previous character is a digit
    if (text[i] === token[0] && 
        text.substring(i, i + token.length) === token &&
        text[i - 1] >= '0' && text[i - 1] <= '9') {
      
      // Include the preceding digit in the result
      const startIndex = i - 1;
      results.push(text.substring(startIndex, i + token.length));
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // No immediate repeated sequences (like abab, abcabc, etc.)
  // Check for patterns where a sequence of 2+ chars is repeated immediately
  const repeatedSequenceRegex = /(..+?)\1+/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  // Additional check for character repetition (like aaabbb)
  // No more than 2 identical characters in a row
  const excessiveRepetitionRegex = /(.)\1{2,}/;
  if (excessiveRepetitionRegex.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address regex that captures all valid forms
  // Including shorthand with :: 
  // Should not match IPv4 addresses
  
  // Check for IPv6 patterns - look for hex groups separated by colons
  const ipv6WithShorthand = /\b(?:[0-9a-fA-F]{1,4}:){1,7}:?[0-9a-fA-F]{1,4}\b/g;
  const ipv6Full = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/g;
  
  // Test both patterns
  if (ipv6Full.test(value)) return true;
  
  // Reset lastIndex for the second regex test
  ipv6WithShorthand.lastIndex = 0;
  if (ipv6WithShorthand.test(value)) return true;
  
  // Also check for :: shorthand specifically
  return /::/.test(value) && /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}/.test(value);
}