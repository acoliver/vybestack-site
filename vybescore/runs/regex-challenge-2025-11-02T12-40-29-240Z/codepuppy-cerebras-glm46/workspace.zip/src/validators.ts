export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that handles typical formats and rejects invalid ones
  // Local part: letters, digits, dots, hyphens, plus, apostrophes
  // No double dots, no trailing dots, no consecutive dots
  // Domain: no underscores, valid domain structure
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional validation for common issues
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots
  if (value.includes('..')) return false;
  
  // Reject trailing dot in local part or domain
  const [localPart, domain] = value.split('@');
  if (localPart.endsWith('.') || domain.endsWith('.')) return false;
  
  // Reject leading dot in local part
  if (localPart.startsWith('.')) return false;
  
  // Reject underscores in domain
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except + at the start
  const cleaned = value.replace(/[^0-9+]/g, '');
  
  // Must be at least 10 digits (without extension)
  if (cleaned.length < 10) return false;
  
  // Handle optional +1 country code
  let digits = cleaned;
  if (cleaned.startsWith('+1')) {
    digits = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length >= 11) {
    digits = cleaned.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (digits.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Area code cannot be 555 (except for 555-XXXX which are fictional)
  if (areaCode === '555') return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code
  // Optional 0 trunk prefix (required if no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, starting with 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(0?[1-9]\d{1,3})(9)?([1-9]\d{5,7})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) return false;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, areaCodeWithTrunk, , subscriberNumber] = match;
  
  // If no country code, must have trunk prefix starting with 0
  if (!countryCode && !areaCodeWithTrunk.startsWith('0')) return false;
  
  // Extract area code (remove trunk prefix if present)
  const areaCode = areaCodeWithTrunk.startsWith('0') 
    ? areaCodeWithTrunk.substring(1) 
    : areaCodeWithTrunk;
  
  // Area code must be 2-4 digits, leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber number must be 6-8 digits
  if (!/^[1-9]\d{5,7}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name should contain unicode letters, accents, apostrophes, hyphens, spaces
  // Should reject digits, symbols, and special characters like X Æ A-12 patterns
  const nameRegex = /^[\p{L}\p{M}'’\-\s]+$/u;
  
  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  
  // Reject if contains digits
  const hasDigit = /\d/.test(value);
  
  // Reject multiple consecutive non-letter characters that suggest artificial names
  const hasSuspiciousPattern = /[Xx]\s*[Æææ]\s*[Aa]\s*-?\s*\d+/.test(value);
  
  // Too many special characters relative to letters
  const specialCharCount = (value.match(/[’'\-]/g) || []).length;
  const letterCount = (value.match(/[\p{L}\p{M}]/gu) || []).length;
  
  return nameRegex.test(value) && 
         hasLetter && 
         !hasDigit && 
         !hasSuspiciousPattern &&
         specialCharCount <= letterCount;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check length and prefixes for major card types
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
