/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and throws an error
 * for clearly invalid payloads.
 */
export function decode(input: string): string {
  const normalized = normalizeInput(input);

  if (!isValidBase64(normalized)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Normalize input by removing whitespace and ensuring consistent format.
 */
function normalizeInput(input: string): string {
  return input.replace(/\s+/g, '');
}

/**
 * Validate that the input conforms to Base64 character set requirements.
 * Allows both padded and unpadded input.
 */
function isValidBase64(input: string): boolean {
  if (input.length === 0) {
    return false;
  }

  // Base64 strings must have length divisible by 4 (after padding normalization)
  const paddedLength = Math.ceil(input.length / 4) * 4;
  if (input.length % 4 !== 0 && paddedLength - input.length > 2) {
    return false;
  }

  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /, =)
  // and ensure padding (=) only appears at the end
  const base64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }

  // Ensure padding is only at the end and there are at most 2 padding chars
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingPart = input.slice(paddingIndex);
    if (!/^={1,2}$/.test(paddingPart)) {
      return false;
    }
    // Ensure there's no non-padding content after padding starts
    if (paddingPart.length > input.length - paddingIndex) {
      return false;
    }
  }

  return true;
}
