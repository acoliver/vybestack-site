/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary pattern with prefix
  const words = text.match(/\b[\w']+\b/g) || [];
  const result: string[] = [];
  
  for (const word of words) {
    if (word.startsWith(prefix) && !exceptions.includes(word)) {
      result.push(word);
    }
  }
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where token appears after a digit and not at start
  // Return the full occurrence (digit + token)
  
  const occurrences: string[] = [];
  
  // Find all positions where token appears
  let pos = 0;
  while ((pos = text.indexOf(token, pos)) !== -1) {
    // Check if token appears after a digit and not at start
    if (pos > 0) {
      const charBefore = text.charAt(pos - 1);
      if (charBefore >= '0' && charBefore <= '9') {
        // This is an occurrence after a digit
        const digit = charBefore;
        occurrences.push(digit + token);
      }
    }
    pos += token.length;
  }
  
  return occurrences;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length - at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check one symbol - remove unnecessary escapes
  if (!/[!@#$%^&*()_+\-={}[\]{};':"\\|,.<>?]/.test(value)) {
    return false;
  }
  
  // Check no immediate repeated sequences like "abab"
  // Look for patterns where 2 characters repeat immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, rule out pure IPv4 addresses
  const ipv4Pattern = /^\s*\b(?:\d{1,3}\.){3}\d{1,3}\b\s*$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns (comprehensive):
  // 1. Full format: 8 groups of 1-4 hex digits separated by :
  // 2. Shorthand with :: (can appear at start, middle, or end)
  // 3. Mixed notation
  
  // Comprehensive IPv6 regex patterns
  const ipv6Patterns = [
    // Standard full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
    /\b(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}\b/gi,
    
    // Leading double colon: ::1, ::ffff:192.168.1.1
    /\b::(?:[a-f0-9]{1,4}:){0,6}[a-f0-9]{1,4}\b/gi,
    
    // Trailing double colon: 2001:db8::
    /\b(?:[a-f0-9]{1,4}:){1,7}::\b/gi,
    
    // Middle double colon: 2001:db8::8a2e:370:7334
    /\b(?:[a-f0-9]{1,4}:){1,6}::(?::[a-f0-9]{1,4}){1,6}\b/gi,
    
    // Compressed format: 2001:db8:0:0:0:0:0:0:1
    /\b(?:[a-f0-9]{1,4}:){1,6}[a-f0-9]{0,4}\b/gi,
    
    // Double colon shorthand anywhere: ::, ::1, 2001::1
    /\b::(?::[a-f0-9]{1,4}){0,7}\b/gi,
    
    // IPv4-mapped IPv6: ::ffff:192.168.1.1
    /\b::(?:ffff:)?(?:\d{1,3}\.){3}\d{1,3}\b/gi,
    
    // Zero compression: any combination of groups with ::
    /\b(?:[a-f0-9]{1,4}:){0,7}::(?:[a-f0-9]{1,4}:){0,7}\b/gi
  ];
  
  // Test against all IPv6 patterns
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
