/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences based on . ? !
  // Use regex to match sentence endings followed by optional whitespace
  const sentences = text.split(/([.!?]\s*)/);
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    // If this looks like a sentence (has letters and isn't just punctuation/whitespace)
    if (sentence.match(/[a-zA-Z]/)) {
      // Capitalize first letter
      sentences[i] = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
  }
  
  return sentences.join('');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Basic URL regex - look for http(s):// followed by domain/path
  const urlRegex = /https?:\/\/[^\s]+(?=\s|$)/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?;]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const urlRegex = /http:\/\/([^\s/]+)(\/[^\s]*)?/g;
  
  return text.replace(urlRegex, (match, host, path = '') => {
    let result = '';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /cgi-bin|[&=]|\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    if (path.startsWith('/docs/')) {
      // This is a docs path, rewrite host to docs.hostname
      let docsHost;
      if (host.startsWith('docs.')) {
        // Already a docs subdomain, just upgrade scheme
        result = `https://${host}${path}`;
        return result;
      } else {
        // Convert regular host to docs.host
        docsHost = `docs.${host}`;
        result = `https://${docsHost}${path}`;
      }
    } else {
      // For non-docs paths, just upgrade scheme unless it has dynamic hints
      if (!hasDynamicHints) {
        // Just upgrade scheme
        result = `https://${host}${path}`;
      } else {
        // Has dynamic hints, upgrade scheme but keep original host
        result = `https://${host}${path}`;
      }
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Validate month and day
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic month/day validation
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  if (month === 2) {
    // Check for leap year
    const year = parseInt(match[3], 10);
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    
    if ((isLeapYear && day > 29) || (!isLeapYear && day > 28)) {
      return 'N/A';
    }
  }
  
  return match[3]; // Return the year
}
