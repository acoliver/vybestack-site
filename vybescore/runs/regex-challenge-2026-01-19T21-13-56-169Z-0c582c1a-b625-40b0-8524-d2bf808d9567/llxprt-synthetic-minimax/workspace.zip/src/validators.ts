export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Allow letters, numbers, dots, underscores, hyphens in local part
  // Allow letters, numbers, hyphens in domain (with at least one dot)
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots and trailing dots
  if (value.includes('..') || value.endsWith('.')) {
    return false;
  }
  
  // Check domain doesn't have underscores
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const domain = parts[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Check that local part doesn't end with dot
  const localPart = parts[0];
  if (localPart.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must have 10 or 11 digits (with country code)
  if (digits.length === 11 && digits.startsWith('1')) {
    // Remove country code for validation
    return isValidUSPhone(digits.substring(1), options);
  }
  
  if (digits.length !== 10) {
    return false;
  }
  
  // Check area code (first digit can't be 0 or 1)
  const areaCode = parseInt(digits.substring(0, 1), 10);
  if (areaCode === 0 || areaCode === 1) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators and spaces, but keep the structure for validation
  const cleaned = value.replace(/[\s\-().+]/g, '');
  
  // Must handle optional +54 country code
  let number = cleaned;
  if (number.startsWith('54')) {
    number = number.substring(2); // Remove country code
  }
  
  // Check if the number starts with trunk prefix 0 (for landlines without country code)
  let areaCode = '';
  let subscriber = '';
  
  if (number.startsWith('0')) {
    // Remove trunk prefix for parsing
    number = number.substring(1);
    
    // Check if followed by mobile indicator 9
    if (number.startsWith('9')) {
      number = number.substring(1); // Remove mobile indicator
    }
    
    // Extract area code (2-4 digits) and subscriber (6-8 digits total)
    const match = number.match(/^(\d{2,4})(\d{4,8})$/);
    if (match) {
      areaCode = match[1];
      subscriber = match[2];
    }
  } else {
    // Direct format without trunk prefix - check if it starts with mobile indicator 9
    if (number.startsWith('9')) {
      number = number.substring(1); // Remove mobile indicator
    }
    
    // Extract area code (2-4 digits) and subscriber (6-8 digits total)
    const match = number.match(/^(\d{2,4})(\d{4,8})$/);
    if (match) {
      areaCode = match[1];
      subscriber = match[2];
    }
  }
  
  // Validate area code and subscriber
  if (areaCode && subscriber) {
    // Area code must be 2-4 digits with first digit 1-9
    if (areaCode.length >= 2 && areaCode.length <= 4 && 
        /^[1-9]\d{1,3}$/.test(areaCode)) {
      // Subscriber must be 4-8 digits (total with area code should be 6-8)
      if (subscriber.length >= 4 && subscriber.length <= 8) {
        return true;
      }
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, spaces, apostrophes, hyphens
  // Reject digits and symbols
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must not be empty or just spaces
  if (value.trim().length === 0) {
    return false;
  }
  
  // Reject names with consecutive characters that might be like "X Æ A-12"
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length and prefix
  let isValid = false;
  
  // Visa: 16 digits starting with 4
  if (digits.length === 16 && digits.startsWith('4')) {
    isValid = true;
  }
  // Mastercard: 16 digits starting with 51-55
  else if (digits.length === 16 && /^5[1-5]/.test(digits)) {
    isValid = true;
  }
  // American Express: 15 digits starting with 34 or 37
  else if (digits.length === 15 && /^(34|37)/.test(digits)) {
    isValid = true;
  }
  
  if (!isValid) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
