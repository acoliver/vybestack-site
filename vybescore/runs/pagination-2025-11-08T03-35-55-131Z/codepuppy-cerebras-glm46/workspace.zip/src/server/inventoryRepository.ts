import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function validatePaginationParams(page?: number, limit?: number): { valid: boolean; error?: string; page: number; limit: number } {
  const parsedPage = page !== undefined ? page : 1;
  const parsedLimit = limit !== undefined ? limit : DEFAULT_LIMIT;

  // Validate page parameter
  if (isNaN(parsedPage) || parsedPage <= 0 || !Number.isInteger(parsedPage)) {
    return { valid: false, error: 'Page must be a positive integer', page: 1, limit: DEFAULT_LIMIT };
  }

  // Validate limit parameter
  if (isNaN(parsedLimit) || parsedLimit <= 0 || !Number.isInteger(parsedLimit)) {
    return { valid: false, error: 'Limit must be a positive integer', page: 1, limit: DEFAULT_LIMIT };
  }

  // Prevent excessive limit values that could cause performance issues
  if (parsedLimit > 100) {
    return { valid: false, error: 'Limit must be less than or equal to 100', page: 1, limit: DEFAULT_LIMIT };
  }

  return { valid: true, page: parsedPage, limit: parsedLimit };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const validation = validatePaginationParams(options.page, options.limit);
  
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = validation.page;
  const limit = validation.limit;

  // Fixed: offset should be (page - 1) * limit to correctly paginate
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = offset + limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
