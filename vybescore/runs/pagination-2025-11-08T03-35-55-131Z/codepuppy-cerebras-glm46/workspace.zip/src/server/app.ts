import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory, validatePaginationParams } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Parse and validate parameters
      const page = pageParam !== undefined ? Number(pageParam) : undefined;
      const limit = limitParam !== undefined ? Number(limitParam) : undefined;

      const validation = validatePaginationParams(page, limit);
      
      if (!validation.valid) {
        return res.status(400).json({ error: validation.error });
      }

      const payload = listInventory(db, { page: validation.page, limit: validation.limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Internal server error';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
