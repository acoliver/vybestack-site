import { describe, expect, it, beforeAll } from 'vitest';
import request from 'supertest';
import type { Database } from 'sql.js';
import type { Express } from 'express';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;
  
  beforeAll(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows with default pagination', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
    
    // Verify pagination metadata structure
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(typeof response.body.total).toBe('number');
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('paginates correctly across pages', async () => {
    // Test first page
    const page1Response = await request(app).get('/inventory?page=1&limit=3');
    expect(page1Response.status).toBe(200);
    expect(page1Response.body.items.length).toBe(3);
    expect(page1Response.body.page).toBe(1);
    expect(page1Response.body.limit).toBe(3);
    expect(page1Response.body.hasNext).toBe(true);
    
    const firstPageIds = page1Response.body.items.map((item: { id: number }) => item.id);
    
    // Test second page
    const page2Response = await request(app).get('/inventory?page=2&limit=3');
    expect(page2Response.status).toBe(200);
    expect(page2Response.body.items.length).toBe(3);
    expect(page2Response.body.page).toBe(2);
    expect(page2Response.body.limit).toBe(3);
    
    const secondPageIds = page2Response.body.items.map((item: { id: number }) => item.id);
    
    // Verify no overlap between pages
    const overlappingIds = firstPageIds.filter((id: number) => secondPageIds.includes(id));
    expect(overlappingIds.length).toBe(0);
  });

  it('validates invalid page parameters', async () => {
    // Test negative page
    const negativePageResponse = await request(app).get('/inventory?page=-1');
    expect(negativePageResponse.status).toBe(400);
    expect(negativePageResponse.body.error).toContain('Page must be a positive integer');
    
    // Test zero page
    const zeroPageResponse = await request(app).get('/inventory?page=0');
    expect(zeroPageResponse.status).toBe(400);
    expect(zeroPageResponse.body.error).toContain('Page must be a positive integer');
    
    // Test non-numeric page
    const nonNumericPageResponse = await request(app).get('/inventory?page=abc');
    expect(nonNumericPageResponse.status).toBe(400);
    expect(nonNumericPageResponse.body.error).toContain('Page must be a positive integer');
  });

  it('validates invalid limit parameters', async () => {
    // Test negative limit
    const negativeLimitResponse = await request(app).get('/inventory?limit=-5');
    expect(negativeLimitResponse.status).toBe(400);
    expect(negativeLimitResponse.body.error).toContain('Limit must be a positive integer');
    
    // Test zero limit
    const zeroLimitResponse = await request(app).get('/inventory?limit=0');
    expect(zeroLimitResponse.status).toBe(400);
    expect(zeroLimitResponse.body.error).toContain('Limit must be a positive integer');
    
    // Test excessive limit
    const excessiveLimitResponse = await request(app).get('/inventory?limit=101');
    expect(excessiveLimitResponse.status).toBe(400);
    expect(excessiveLimitResponse.body.error).toContain('Limit must be less than or equal to 100');
  });

  it('handles last page correctly', async () => {
    // There are 15 items total, so with limit=10, page 2 should have 5 items and no next
    const lastPageResponse = await request(app).get('/inventory?page=2&limit=10');
    expect(lastPageResponse.status).toBe(200);
    expect(lastPageResponse.body.hasNext).toBe(false);
  });

  it('returns empty items when page beyond data range', async () => {
    // Page 100 with limit 5 should return empty items but valid metadata
    const farPageResponse = await request(app).get('/inventory?page=100&limit=5');
    expect(farPageResponse.status).toBe(200);
    expect(farPageResponse.body.items.length).toBe(0);
    expect(farPageResponse.body.hasNext).toBe(false);
  });
});
