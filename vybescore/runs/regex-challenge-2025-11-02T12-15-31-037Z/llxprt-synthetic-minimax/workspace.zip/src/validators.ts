export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern for email validation
  // Local part: letters, numbers, +, -, ., _ (but not starting/ending with . or having double dots)
  // Domain part: letters, numbers, -, . (but not starting/ending with - or . or having double dots)
  // No underscores in domain
  const emailPattern = /^[a-zA-Z0-9]([a-zA-Z0-9!#$%&'*+/=?^_`{}~-]*\.?[a-zA-Z0-9!#$%&'*+/=?^_`{}~-]*)*@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  // Additional checks
  // 1. No double dots anywhere
  if (value.includes('..')) return false;
  
  // 2. No trailing dot at the end of local or domain part
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  if (parts[0].endsWith('.') || parts[1].endsWith('.')) return false;
  
  // 3. No underscores in domain
  if (parts[1].includes('_')) return false;
  
  return emailPattern.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.trim();
  
  // Check if starts with +1 (optional)
  const hasCountryCode = cleaned.startsWith('+1');
  const phonePart = hasCountryCode ? cleaned.slice(2) : cleaned;
  
  // Remove leading + if present
  const digitsOnly = phonePart.replace(/[^\d]/g, '');
  
  // Check length - should be 10 digits for US phone
  if (digitsOnly.length !== 10) return false;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Format patterns:
  // (212) 555-7890
  // 212-555-7890
  // 2125557890
  // +1 212-555-7890
  // +12125557890
  const patterns = [
    /^\+1\d{10}$/,                    // +12125557890
    /^1\d{10}$/,                      // 12125557890 (without +)
    /^\d{3}-\d{3}-\d{4}$/,           // 212-555-7890
    /^\d{3}\s\d{3}-\d{4}$/,          // 212 555-7890
    /^\(\d{3}\)\s?\d{3}-\d{4}$/,     // (212) 555-7890
    /^\d{10}$/,                       // 2125557890
  ];
  
  // Also check with spaces and formatting
  const formattedPatterns = [
    /^\+1\s?\(\d{3}\)\s?\d{3}-\d{4}$/, // +1 (212) 555-7890
    /^\+1\s\d{3}-\d{3}-\d{4}$/,        // +1 212-555-7890
  ];
  
  const allPatterns = [...patterns, ...formattedPatterns];
  
  return allPatterns.some(pattern => pattern.test(cleaned));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-space/hyphen characters for validation
  const cleaned = value.trim().replace(/[\s-]+/g, ' ');
  
  // Check for valid structure
  // Pattern: [+54][ ][9][ ][area_code][ ][subscriber]
  // or: [0][area_code][ ][subscriber]
  
  // With country code +54
  const withCountryCodePattern = /^\+54(?:\s9)?\s(\d{2,4})\s(\d{6,8})$/;
  
  // Without country code but with trunk prefix 0
  const withTrunkPrefixPattern = /^0(\d{2,4})\s(\d{6,8})$/;
  
  const match1 = cleaned.match(withCountryCodePattern);
  const match2 = cleaned.match(withTrunkPrefixPattern);
  
  if (match1) {
    const areaCode = match1[1];
    const subscriber = match1[2];
    // Area code must be 2-4 digits, leading digit must be 1-9
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    if (!/^[1-9]/.test(areaCode)) return false;
    // Subscriber must be 6-8 digits
    if (subscriber.length < 6 || subscriber.length > 8) return false;
    return true;
  }
  
  if (match2) {
    const areaCode = match2[1];
    const subscriber = match2[2];
    // Area code must be 2-4 digits, leading digit must be 1-9
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    if (!/^[1-9]/.test(areaCode)) return false;
    // Subscriber must be 6-8 digits
    if (subscriber.length < 6 || subscriber.length > 8) return false;
    return true;
  }
  
  // Try without spaces (just digits)
  const digitsOnly = value.replace(/\D/g, '');
  
  // With country code
  if (digitsOnly.startsWith('54')) {
    const rest = digitsOnly.substring(2);
    // Optional 9 for mobile
    if (rest.startsWith('9')) {
      const areaAndSub = rest.substring(1);
      if (areaAndSub.length >= 8 && areaAndSub.length <= 12) {
        const areaCode = areaAndSub.substring(0, Math.min(4, areaAndSub.length - 6));
        if (areaCode.length >= 2 && areaCode.length <= 4 && /^[1-9]/.test(areaCode)) {
          return true;
        }
      }
    } else {
      // Direct area code
      if (rest.length >= 8 && rest.length <= 12) {
        const areaCode = rest.substring(0, Math.min(4, rest.length - 6));
        if (areaCode.length >= 2 && areaCode.length <= 4 && /^[1-9]/.test(areaCode)) {
          return true;
        }
      }
    }
  }
  
  // Without country code but starts with 0
  if (digitsOnly.startsWith('0')) {
    const areaAndSub = digitsOnly.substring(1);
    if (areaAndSub.length >= 8 && areaAndSub.length <= 12) {
      const areaCode = areaAndSub.substring(0, Math.min(4, areaAndSub.length - 6));
      if (areaCode.length >= 2 && areaCode.length <= 4 && /^[1-9]/.test(areaCode)) {
        return true;
      }
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!value.trim()) return false;
  
  // Check for digits
  if (/\d/.test(value)) return false;
  
  // Check for symbols (except allowed ones: apostrophe, hyphen, space)
  // Allow unicode letters, apostrophes, hyphens, and spaces
  // The pattern allows: letters (including accents), spaces, apostrophes ('), hyphens (-)
  const validPattern = /^[\p{L}\s'-]+$/u;
  
  if (!validPattern.test(value)) return false;
  
  // Additional check for "X Æ A-12" style names (special characters in sequence)
  // Reject if contains non-alphabetic symbols in odd combinations
  if (/[ÆØÅæøå]/.test(value)) {
    // Allow single character like "Ø" but not combinations like "X Æ A-12"
    const specialCharPattern = /[ÆØÅæøå]/g;
    const matches = value.match(specialCharPattern);
    if (matches && matches.length > 1) return false;
  }
  
  // Must have at least one letter character
  if (!/[\p{L}]/u.test(value)) return false;
  
  return true;
}

/**
 * Helper function to run Luhn checksum validation
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Traverse from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check card type by prefix
  let isValidType = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (digitsOnly.startsWith('4')) {
    if (digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19) {
      isValidType = true;
    }
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if (digitsOnly.startsWith('51') || digitsOnly.startsWith('52') || 
      digitsOnly.startsWith('53') || digitsOnly.startsWith('54') || 
      digitsOnly.startsWith('55') || 
      (digitsOnly.startsWith('222') && parseInt(digitsOnly.substring(0, 4)) >= 2221 && parseInt(digitsOnly.substring(0, 4)) <= 2720)) {
    if (digitsOnly.length === 16) {
      isValidType = true;
    }
  }
  
  // American Express: starts with 34 or 37, length 15
  if (digitsOnly.startsWith('34') || digitsOnly.startsWith('37')) {
    if (digitsOnly.length === 15) {
      isValidType = true;
    }
  }
  
  // Discover: starts with 6011, 622126-622925, 644, 645, 646, 647, 648, 649, or 65
  if (digitsOnly.startsWith('6011') || digitsOnly.startsWith('65') || 
      digitsOnly.startsWith('644') || digitsOnly.startsWith('645') || 
      digitsOnly.startsWith('646') || digitsOnly.startsWith('647') || 
      digitsOnly.startsWith('648') || digitsOnly.startsWith('649')) {
    if (digitsOnly.length === 16 || digitsOnly.length === 19) {
      isValidType = true;
    }
  }
  
  // Check for other common prefixes if none matched yet
  if (!isValidType) {
    // Allow other valid card types with standard lengths
    if ((digitsOnly.length >= 13 && digitsOnly.length <= 19) &&
        (digitsOnly.startsWith('3') || digitsOnly.startsWith('4') || 
         digitsOnly.startsWith('5') || digitsOnly.startsWith('6'))) {
      isValidType = true;
    }
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
