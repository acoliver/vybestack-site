import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { Database } from 'sql.js';

// Define __dirname in ES module scope
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Types
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static files
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set EJS as templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup
let db: Database;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
async function initializeDatabase() {
  try {
    const dbFileExists = fs.existsSync(dbPath);
    
    // Initialize sql.js
    const SQL = await import('sql.js');
    const SQLModule = await SQL.default();
    
    // Load or create database
    if (dbFileExists) {
      const dbBuffer = fs.readFileSync(dbPath);
      db = new SQLModule.Database(dbBuffer);
    } else {
      db = new SQLModule.Database();
      
      // Create tables using schema
      const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
      db.run(schema);
      
      // Save the initialized database
      saveDatabase();
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase() {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Write database to file
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings, spaces, hyphens
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalRegex.test(postalCode);
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields
  if (!data.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!data.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!data.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!data.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!data.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  if (!data.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code format is invalid' });
  }
  
  if (!data.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!data.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Email format is invalid' });
  }
  
  if (!data.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number format is invalid' });
  }
  
  return errors;
}

// Routes
// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateFormData(formData);
  
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors: errors.map(error => error.message),
      values: formData
    });
  }
  
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your information. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {});
});

// Server startup
async function startServer() {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  
  // Graceful shutdown
  const gracefulShutdown = (signal: string) => {
    console.log(`Received ${signal}, shutting down gracefully`);
    
    server.close(() => {
      console.log('HTTP server closed');
      
      if (db) {
        saveDatabase();
        db.close();
        console.log('Database connection closed');
      }
      
      process.exit(0);
    });
    
    // Force close after 10 seconds
    setTimeout(() => {
      console.error('Could not close connections in time, forcefully shutting down');
      process.exit(1);
    }, 10000);
  };
  
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  if (db) db.close();
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

// Start the server
startServer();
