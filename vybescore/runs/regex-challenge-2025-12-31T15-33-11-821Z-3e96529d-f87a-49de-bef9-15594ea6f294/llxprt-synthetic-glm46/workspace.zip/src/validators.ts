export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation implementing typical address patterns while rejecting invalid forms.
 * Accepts formats like name+tag@example.co.uk but rejects double dots, trailing dots,
 * domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern with more specific validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for invalid patterns
  const invalidPatterns = [
    /\.\./,        // double dots
    /\.$/,        // trailing dot
    /@.*_/,       // underscore in domain
    /\.@/,        // dot right before @
    /@\./,        // dot right after @
    /@\./,        // dot immediately after @
  ];
  
  // Check basic format first
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * US phone number validation supporting formats like (212) 555-7890, 212-555-7890, 2125557890
 * with optional +1 prefix. Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  const normalizedDigits = digitsOnly.startsWith('1') && digitsOnly.length === 11 
    ? digitsOnly.slice(1) 
    : digitsOnly;
  
  // Must be exactly 10 digits after removing country code
  if (normalizedDigits.length !== 10) {
    return false;
  }
  
  // Area code validation - cannot start with 0 or 1
  const areaCode = normalizedDigits.substring(0, 3);
  if (areaCode.charAt(0) === '0' || areaCode.charAt(0) === '1') {
    return false;
  }
  
// Basic pattern validation for common US phone formats
  const phonePatterns = [
    /^\+1?\s*\(\d{3}\)\s*\d{3}[-. ]?\d{4}$/,  // (123) 456-7890
    /^\+1?\s*\d{3}[-. ]?\d{3}[-. ]?\d{4}$/,   // 123-456-7890, 123.456.7890
    /^\+1?\s*\d{10}$/,                          // 1234567890
    /^\d{3}[-.]\d{3}[-.]\d{4}$/,               // 212-555-7890
  ];

  return phonePatterns.some(pattern => pattern.test(value));
}

/**
 * Argentine phone number validation supporting landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber: 6-8 digits total after area code
 * - When country code omitted, must begin with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Patterns for different Argentine phone formats
  const patterns = [
    // With +54 country code: +54[9]XXXXX...
    /^\+549?\d{2,4}\d{6,8}$/,
    // Without country code (must start with 0): 0XXXXXXXX...
    /^0\d{2,4}\d{6,8}$/
  ];
  
  // Check if it matches any basic pattern
  const isValidFormat = patterns.some(pattern => pattern.test(cleanValue));
  if (!isValidFormat) {
    return false;
  }
  
  // Extract components for detailed validation
  let remaining = cleanValue;
  let areaCode = '';
  let subscriberNumber = '';
  
  // Check for country code +54
  if (remaining.startsWith('+54')) {
    // Check for mobile indicator 9
    if (remaining.charAt(3) === '9') {
      remaining = remaining.slice(4);
    } else {
      remaining = remaining.slice(3);
    }
  } else {
    // Country code omitted - must start with 0
    if (!remaining.startsWith('0')) {
      return false;
    }
  }
  
  
  
  // Extract area code (2-4 digits, leading digit 1-9)
  const areaCodeMatch = remaining.match(/^(\d{2,4})(\d+)$/);
  if (!areaCodeMatch) {
    return false;
  }
  
  areaCode = areaCodeMatch[1];
  subscriberNumber = areaCodeMatch[2];
  remaining = '';
  
// Validate area code: leading digit 1-9
  if (areaCode.charAt(0) === '0') {
    return false;
  }

  // Validate subscriber number: 6-8 digits total after area code
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols
  const nameRegex = /^[\p{L}\p{M}'’\-\s]+$/u;
  return nameRegex.test(value) && value.trim().length > 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Clean input to digits only
  const digitsOnly = value.replace(/\D/g, '');
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if card number matches any supported card type
  const isValidCardType = visaRegex.test(digitsOnly) || 
                          mastercardRegex.test(digitsOnly) || 
                          amexRegex.test(digitsOnly);
  
  if (!isValidCardType) {
    return false;
  }
  
  // Perform Luhn checksum check
  return runLuhnCheck(digitsOnly);
}

function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = digit.toString().split('').reduce((sum: number, digitChar: string) => sum + parseInt(digitChar, 10), 0);
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
