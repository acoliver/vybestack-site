/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with prefix
  const wordPattern = new RegExp(`\\b${escapeRegExp(prefix)}\\w+\\b`, 'gi');
  const matches: string[] = [];
  let match;
  
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[0];
    
    // Check if word is not in exceptions list (case insensitive)
    if (!exceptions.some(exception => 
      exception.toLowerCase() === word.toLowerCase())) {
      matches.push(word);
    }
  }
  
  return matches;
}

// Helper function to escape special characters in prefix
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use a two-step approach to capture the digit with the token
  // First find all tokens that come after digits
  const fullTokenPattern = new RegExp(`\\d${escapeRegExp(token)}`, 'g');
  const matches: string[] = [];
  let match;
  
  while ((match = fullTokenPattern.exec(text)) !== null) {
    // Return the full matched string (digit + token)
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates password strength according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for forbidden characters (whitespace)
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, abcabc)
  // Look for sequences that repeat at least twice
  const repeatedSequencePattern = /(.{3,})\1+/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and ensures IPv4 addresses do not trigger positive.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern (to exclude these)
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 pattern (including shorthand with ::)
  const ipv6Pattern = /(?:^|[\s[\]:])(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/;
  
  // Check if contains IPv6 but not IPv4
  return !ipv4Pattern.test(value) && ipv6Pattern.test(value);
}
