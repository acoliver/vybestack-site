/**
 * Capitalizes the first character of each sentence while handling spacing and abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // Process the text to normalize spacing and capitalize sentences
  const processedText = text
    // Replace multiple spaces with single space
    .replace(/\s+/g, ' ')
    // Ensure sentences are properly separated with a single space after punctuation
    .replace(/([.?!])\s*([A-Za-z])/g, '$1 $2');
  
  // Use regex to find sentence boundaries and capitalize first letter
  return processedText.replace(/(^|[.?!]\s+)([a-z])/g, (match, delimiter, letter) => {
    return delimiter + letter.toUpperCase();
  });
}

/**
 * Extracts all URLs from the given text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const matches: string[] = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation but not part of the URL
    url = url.replace(/[.,!?;:)]+$/g, '');
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't touch https://
  return text.replace(/^http:\/\//gm, 'https://');
}

/**
 * Rewrites http://example.com/... URLs according to rules:
 * - Always upgrade to https
 * - Move /docs/ paths to docs.example.com host
 * - Skip host rewrite for dynamic URLs (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/(example\.com)(\/[^\s]*)/g, (match, hostname, path) => {
    // Always upgrade to https
    let newUrl = `https://`;
    
    // Check if we should rewrite the host based on path rules
    const shouldRewriteHost = ShouldRewriteHost(path);
    
    if (shouldRewriteHost && path.startsWith('/docs/')) {
      // Change host to docs.example.com
      newUrl += 'docs.example.com';
      newUrl += path;
    } else {
      // Keep original host, just upgrade scheme
      newUrl += hostname;
      newUrl += path;
    }
    
    return newUrl;
  });
}

// Helper function to determine if host should be rewritten
function ShouldRewriteHost(path: string): boolean {
  // Don't rewrite if path contains dynamic hints
  const dynamicPatterns = [
    /cgi-bin/,
    /[?&=]/,      // query string parameters
    /\/(jsp|php|asp|aspx|do|cgi|pl|py)$/  // legacy extensions
  ];
  
  return !dynamicPatterns.some(pattern => pattern.test(path));
}

/**
 * Extracts the four-digit year from mm/dd/yyyy formatted dates.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Basic day validation (simplified - doesn't account for all month-specific limits)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Check February day limits
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  // Check months with 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  return year;
}
