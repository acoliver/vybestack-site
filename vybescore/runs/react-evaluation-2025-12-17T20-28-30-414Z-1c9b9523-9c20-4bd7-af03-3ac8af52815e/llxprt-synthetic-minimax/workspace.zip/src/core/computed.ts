/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn,
  notifySubjects,
  Subject,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = typeof equal === 'function' ? equal : 
                  equal === true ? ((a: T, b: T) => a === b) : 
                  undefined

  // Create a subject that can notify observers
  const subject: Subject<T> = {
    name: options?.name,
    value: value as T,
    equalFn,
    observers: new Set(),
  }

  // Initial evaluation - compute the initial result
  // Pass subject.value (which may be undefined) to allow default parameter behavior
  const currentValue = updateFn(subject.value)
  subject.value = currentValue

  return (): T => {
    // When the getter is called, we need to set up the active observer context
    // so that any dependencies we read will subscribe to us
    const previous = getActiveObserver()
    try {
      // Re-evaluate the computation without passing current value to preserve default parameter behavior
      const newValue = updateFn()
      
      // Check if the value actually changed
      const oldValue = subject.value
      const valuesEqual = equalFn ? equalFn(oldValue, newValue) : oldValue === newValue
      
      if (!valuesEqual) {
        // Update the value and notify observers
        subject.value = newValue
        notifySubjects(subject)
      }
      
      return newValue
} finally {
      // Restore the previous active observer
      setActiveObserver(previous)
    }
  }
}