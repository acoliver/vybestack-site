/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: () => {
      // Execute the side effect function - this is the core of the callback
      updateFn()
      return value as T
    },
    subjects: new Set(),
  }
  
  let disposed = false

  // Register observer to track dependencies by executing it initially
  updateObserver(observer)

  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subject's observer sets
    observer.subjects.forEach(subject => {
      subject.observers.delete(observer as Observer<unknown>)
    })
    
    // Clear dependencies
    observer.subjects.clear()
  }
}
