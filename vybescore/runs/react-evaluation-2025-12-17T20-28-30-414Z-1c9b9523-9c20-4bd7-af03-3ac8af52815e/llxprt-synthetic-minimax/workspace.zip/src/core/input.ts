/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  subscribeToSubject,
  notifySubjects,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = typeof equal === 'function' ? equal : 
                  equal === true ? ((a: T, b: T) => a === b) : 
                  undefined

  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn,
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      subscribeToSubject(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    s.value = nextValue
    
    // Only notify if value actually changed (no equal function or values are different)
    const hasEqualFn = s.equalFn !== undefined
    const valuesEqual = hasEqualFn ? s.equalFn!(oldValue, nextValue) : oldValue === nextValue
    
    if (!valuesEqual) {
      notifySubjects(s)
    }
    
    return s.value
  }

  return [read, write]
}
