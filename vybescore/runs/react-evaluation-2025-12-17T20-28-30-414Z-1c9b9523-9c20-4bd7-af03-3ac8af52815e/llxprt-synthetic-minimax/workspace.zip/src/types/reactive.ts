/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer<T> {
  name?: string
  value?: T | undefined
  updateFn: UpdateFn<T>
  subjects: Set<Subject<unknown>>
}

export interface Subject<T> {
  name?: string
  value: T
  equalFn?: EqualFn<T> | undefined
  observers: Set<Observer<unknown>>
}

let activeObserver: Observer<unknown> | undefined = undefined
let isUpdating = false

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): Observer<unknown> | undefined {
  const old = activeObserver
  activeObserver = observer
  return old
}

export function updateObserver<T>(observer: Observer<T>): T | undefined {
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  try {
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
    
    // After updating, notify all observers that depend on this observer's computed value
    // We don't notify subjects here because we're an observer, not a subject
    
    return observer.value
  } finally {
    activeObserver = previous
  }
}

export function subscribeToSubject<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  subject.observers.add(observer as Observer<unknown>)
  observer.subjects.add(subject as Subject<unknown>)
}

export function notifySubjects<T>(subject: Subject<T>): void {
  if (isUpdating) return
  
  isUpdating = true
  try {
    // Create a copy to avoid modification during iteration
    const observers = new Set(subject.observers)
    observers.forEach(observer => {
      // Always call updateObserver, even if value doesn't change
      // This ensures side effects (like callbacks) are executed
      updateObserver(observer as Observer<unknown>)
    })
  } finally {
    isUpdating = false
  }
}

export function createSubject<T>(value: T, equalFn?: EqualFn<T>, name?: string): Subject<T> {
  return {
    name,
    value,
    equalFn,
    observers: new Set()
  }
}
