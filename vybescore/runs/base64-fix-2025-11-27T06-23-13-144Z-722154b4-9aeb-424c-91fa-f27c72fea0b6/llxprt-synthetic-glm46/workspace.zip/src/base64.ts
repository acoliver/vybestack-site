/**
 * Encode plain text to Base64 using the standard alphabet.
 * Returns properly padded Base64 output.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 with or without padding and rejects invalid input.
 */
export function decode(input: string): string {
  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /, and optional padding =)
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for invalid padding (padding can only appear at the end and must be 0, 1, or 2 = characters)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = input.substring(paddingIndex);
    // Padding can only be 1 or 2 = characters, and must be at the end
    if (!/^={1,2}$/.test(padding) || paddingIndex + padding.length !== input.length) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
    
    // Check if padding length is correct based on total length
    // Base64 strings must have a length that's a multiple of 4
    const totalLength = input.length;
    const mod4 = totalLength % 4;
    
    // If the string isn't a multiple of 4, the padding should make it so
    if (mod4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    const normalizedInput = input.replace(/=+$/, '');
    
    if (buffer.length === 0 && normalizedInput.length > 0) {
      throw new Error('Invalid Base64 input: cannot decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}