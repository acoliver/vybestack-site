const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Validate that a string is valid Base64.
 * Valid Base64 contains only A-Z, a-z, 0-9, +, /, and optional padding =.
 */
function isValidBase64(input: string): boolean {
  // Empty string is invalid
  if (input.length === 0) {
    return false;
  }

  // Check that the string only contains valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }

  // Padding must only appear at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Everything after the first = must be =
    const paddingSection = input.slice(paddingIndex);
    if (!/^=+$/.test(paddingSection)) {
      return false;
    }
    // Padding can only be 1 or 2 characters
    if (paddingSection.length > 2) {
      return false;
    }
  }

  // Length without padding must be multiple of 4 characters
  // Unpadded base64 is valid, so we don't strictly enforce this

  return true;
}

/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error if the input is invalid Base64.
 */
export function decode(input: string): string {
  // Validate input format
  if (!isValidBase64(input)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if decoding actually worked (Buffer doesn't throw for invalid base64)
    // If the input was invalid, the buffer might be empty or corrupted
    // A valid base64 string should produce meaningful output
    if (input.length > 0 && buffer.length === 0) {
      throw new Error(INVALID_BASE64_ERROR);
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
