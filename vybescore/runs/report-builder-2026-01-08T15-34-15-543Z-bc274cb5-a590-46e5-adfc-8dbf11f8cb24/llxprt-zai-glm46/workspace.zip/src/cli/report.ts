#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, RenderOptions, Formatter } from '../types/index.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const inputFile = args[0];
  if (!inputFile) {
    console.error('Error: Input file is required');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--format') {
      i++;
      format = args[i];
    } else if (arg === '--output') {
      i++;
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`);
    }
  }

  return data as ReportData;
}

function getFormatter(format: string): Formatter {
  const formatters: Record<string, Formatter> = {
    markdown: renderMarkdown,
    text: renderText,
  };

  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}. Supported formats: ${Object.keys(formatters).join(', ')}`);
  }

  return formatter;
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const inputPath = path.resolve(args.inputFile);
    let inputContent: string;

    try {
      inputContent = fs.readFileSync(inputPath, 'utf-8');
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        console.error(`Error: Input file not found: ${args.inputFile}`);
      } else {
        console.error(`Error reading input file: ${(error as Error).message}`);
      }
      process.exit(1);
      return;
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(inputContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in input file: ${(error as Error).message}`);
      process.exit(1);
      return;
    }

    const reportData = validateReportData(jsonData);

    const formatter = getFormatter(args.format);
    const options: RenderOptions = { includeTotals: args.includeTotals };
    const output = formatter(reportData, options);

    if (args.outputPath) {
      const outputPath = path.resolve(args.outputPath);
      fs.writeFileSync(outputPath, output, 'utf-8');
      console.log(`Report written to: ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }
}

main();
