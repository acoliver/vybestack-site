const regex = /(.{2,4})\1/;
console.log("Testing abab:", regex.test(""));
console.log("Testing abcabc:", regex.test(""));  
console.log("Testing 123123:", regex.test(""));
console.log("Testing AAA:", regex.test(""));
