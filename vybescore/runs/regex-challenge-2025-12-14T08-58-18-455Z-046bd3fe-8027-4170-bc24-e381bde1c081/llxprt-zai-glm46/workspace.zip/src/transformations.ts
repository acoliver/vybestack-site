/**
 * Capitalize the first character of each sentence.
 * Sentences are separated by .!? with proper spacing.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First normalize whitespace: collapse multiple spaces and ensure proper spacing after punctuation
  const normalized = text
    .replace(new RegExp('\\s+', 'g'), ' ')  // Collapse multiple spaces
    .replace(new RegExp('([.!?])\\s*', 'g'), '$1 ')  // Ensure space after punctuation
    .trim();

  // Split into sentences, keeping the delimiters
  const sentences = normalized.split(new RegExp('([.!?])'));
  
  const result: string[] = [];
  let currentSentence = '';
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    currentSentence += part;
    
    // If we have a complete sentence (text + delimiter)
    if (new RegExp('[.!?]').test(part) || i === sentences.length - 1) {
      if (currentSentence.trim()) {
        // Capitalize the first letter if it exists
        const trimmed = currentSentence.trim();
        if (trimmed.length > 0) {
          const firstChar = trimmed.charAt(0).toUpperCase();
          const rest = trimmed.slice(1);
          result.push(firstChar + rest);
        }
      }
      currentSentence = '';
    }
  }
  
  return result.join(' ').replace(/\s+/g, ' ').trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches common URL formats
  const urlRegex = new RegExp('https?://(?:www\\.)?[-a-zA-Z0-9@:%._+~=]{1,256}\\.[a-zA-Z0-9()]{1,6}\\b(?:[-a-zA-Z0-9()@:%_+.~#?&//=]*)', 'g');
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(new RegExp('[.,;:!?]+$'), ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(new RegExp('http://', 'g'), 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Skips host rewrite for dynamic hints like cgi-bin, query strings, or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(new RegExp('https?://([^/]+)(/[^\\s]*)', 'g'), (match, host, path) => {
    // Always upgrade to https
    const protocol = 'https://';
    
// Check if path contains dynamic hints or legacy extensions
  const hasDynamicHints = new RegExp('/(cgi-bin|[\\w.-]+\\.(jsp|php|asp|aspx|do|cgi|pl|py)([?&]|$))', 'i').test(path);
  const hasQueryString = path.includes('?');
    
    // Check if path starts with /docs/ and doesn't have dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHints && !hasQueryString) {
      // Rewrite to docs.example.com
      return protocol + 'docs.' + host + path;
    }
    
    // Just upgrade the protocol
    return protocol + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = new RegExp('^(0[1-9]|1[0-2])/(0[1-9]|[12]\\d|3[01])/(\\d{4})$');
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day/month combinations
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (simplified)
  const leapYear = (parseInt(year) % 4 === 0 && parseInt(year) % 100 !== 0) || (parseInt(year) % 400 === 0);
  if (leapYear) {
    daysInMonth[1] = 29;
  }
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
