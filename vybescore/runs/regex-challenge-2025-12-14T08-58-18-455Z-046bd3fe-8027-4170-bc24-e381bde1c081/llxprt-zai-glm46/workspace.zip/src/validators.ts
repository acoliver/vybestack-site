export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Luhn checksum algorithm for credit card validation.
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email addresses with proper format checking.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = new RegExp('^[a-zA-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$');
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in the entire email
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  const [, domain] = value.split('@');
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Domain cannot start or end with dot or hyphen
  if (domain && (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-'))) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers with optional +1 prefix.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  const cleanPhone = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  let digits = cleanPhone;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.slice(1);
  }
  
  // Must be exactly 10 digits for standard US phone number
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (digits.startsWith('0') || digits.startsWith('1')) {
    return false;
  }
  
  // Exchange code (4th digit) cannot start with 0 or 1
  const exchangeCode = digits.charAt(3);
  if (exchangeCode === '0' || exchangeCode === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleanPhone = value.replace(/\D/g, '');
  
  // Check for country code +54
  let digits = cleanPhone;
  if (cleanPhone.startsWith('54')) {
    digits = cleanPhone.slice(2);
  }
  
  // If no country code, must have trunk prefix 0
  if (!cleanPhone.startsWith('54') && !digits.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix if present
  if (digits.startsWith('0')) {
    digits = digits.slice(1);
  }
  
  // Check for mobile indicator 9
  if (digits.startsWith('9')) {
    digits = digits.slice(1);
  }
  
  // At this point, digits should contain area code + subscriber number
  if (digits.length < 8 || digits.length > 12) {
    return false;
  }
  
  // Area code must be 2-4 digits starting with 1-9 (not 0)
  const remainingLength = digits.length;
  
  let areaCodeLength = 2;
  if (remainingLength >= 8 && remainingLength <= 9) {
    areaCodeLength = 2;
  } else if (remainingLength >= 9 && remainingLength <= 10) {
    areaCodeLength = 3;
  } else if (remainingLength >= 10 && remainingLength <= 11) {
    areaCodeLength = 4;
  } else {
    return false;
  }
  
  const areaCode = digits.slice(0, areaCodeLength);
  const subscriberNumber = digits.slice(areaCodeLength);
  
  // Area code validation - must start with 1-9 (not 0)
  if (!new RegExp('^[1-9]\\d{1,3}$').test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (!new RegExp('^\\d{6,8}$').test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and unusual names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, spaces, apostrophes, hyphens, and common name characters
  // Reject digits and most symbols
  const namePattern = String.raw`^[\p{L}\p{M}][\p{L}\p{M}\s'-]*[\p{L}\p{M}]$`;
  const nameRegex = new RegExp(namePattern, 'u');
  
  if (!nameRegex.test(value.trim())) {
    return false;
  }
  
  // Additional checks for obviously invalid names
  if (new RegExp(String.raw`\d`).test(value)) {
    return false;
  }
  
  // Reject names with too many special characters
  const specialChars = value.match(/['-]/g);
  if (specialChars && specialChars.length > 3) {
    return false;
  }
  
  // Reject obviously problematic patterns
  if (/\s{2,}/.test(value) || /['-]{2,}/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!new RegExp(String.raw`\p{L}`, 'u').test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers for Visa, Mastercard, and American Express.
 * Performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  const cleanCard = value.replace(/\D/g, '');
  
  // Check length based on card type
  if (cleanCard.length < 13 || cleanCard.length > 19) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  if (cleanCard.startsWith('4')) {
    if (cleanCard.length !== 13 && cleanCard.length !== 16) {
      return false;
    }
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if (cleanCard.length === 16) {
    const secondDigit = cleanCard.charAt(1);
    if (cleanCard.startsWith('5') && secondDigit >= '1' && secondDigit <= '5') {
      // Valid Mastercard prefix
    } else if (cleanCard.startsWith('2')) {
      // 2221-2720 range
      const prefix = parseInt(cleanCard.slice(0, 4), 10);
      if (prefix < 2221 || prefix > 2720) {
        return false;
      }
    } else {
      return false;
    }
  }
  // American Express: starts with 34 or 37, length 15
  else if (cleanCard.length === 15 && (cleanCard.startsWith('34') || cleanCard.startsWith('37'))) {
    // Valid Amex
  }
  // If it doesn't match any known card type
  else {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleanCard);
}