/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex and create word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with prefix
  const wordRegex = new RegExp('\\b' + escapedPrefix + '[a-zA-Z]*\\b', 'g');
  
  const foundWords = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  return foundWords.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find token after a digit (not at start)
  // Also use word boundary to ensure we match the complete token
  const embeddedRegex = new RegExp('\\d' + escapedToken + '\\b', 'g');
  
  return text.match(embeddedRegex) || [];
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for required character classes
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  // Must have all required character classes
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, AAA, etc.)
  // This pattern looks for any 2-4 character sequence that repeats immediately
  const repeatedPattern = /(.{2,4})\1/;
  
  return !repeatedPattern.test(value);
}

/**
 * Detect IPv6 addresses while ensuring IPv4 addresses don't trigger positive results.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern to exclude pure IPv4 addresses
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // If the input is a pure IPv4 address, return false
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Check if the input contains IPv6 addresses
  // We need to search for IPv6 patterns within the text, not just match the whole string
  const allIpv6Patterns = [
    // Standard IPv6 segments (1-4 hex digits followed by :)
    /([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}/g,
    // IPv6 with :: compression
    /([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*/g,
    // IPv6 starting with ::
    /::([0-9a-fA-F]{1,4}:)*/g,
    // IPv6 ending with ::
    /([0-9a-fA-F]{1,4}:)*::/g,
    // IPv6 loopback
    /::1\b/g,
    // IPv6 with IPv4 embedded
    /([0-9a-fA-F]{1,4}:)*:(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/g
  ];
  
  // If it contains an IPv4 address, check if it ALSO contains IPv6
  // Remove the IPv4 part and check the rest
  const withoutIPv4 = value.replace(ipv4Pattern, '');
  const searchValue = withoutIPv4.trim() || value;
  
  // Test each pattern
  for (const pattern of allIpv6Patterns) {
    if (pattern.test(searchValue)) {
      return true;
    }
  }
  
  return false;
}