console.log("abab:", /(.{2,4})\1/.test("")); console.log("abcabc:", /(.{2,4})\1/.test("")); console.log("123123:", /(.{2,4})\1/.test(""))
