/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  disposed?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

let activeObserver: ObserverR | undefined

// Global notification stack to prevent circular dependencies
const notificationStack = new Set<ObserverR>()
export type Subject<T> = SubjectR & SubjectV<T>

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Global registry to track dependencies
export const dependencies = new Map<Subject<unknown>, Set<ObserverR>>()
export const reverseDependencies = new Map<ObserverR, Set<Subject<unknown>>>()

export function trackDependency(subject: Subject<unknown>, observer: ObserverR): void {
  // Prevent circular dependencies
  if (subject.observer === observer) {
    return
  }
  
  // Track subject -> observer
  if (!dependencies.has(subject)) {
    dependencies.set(subject, new Set())
  }
  dependencies.get(subject)!.add(observer)
  
  // Track observer -> subject  
  if (!reverseDependencies.has(observer)) {
    reverseDependencies.set(observer, new Set())
  }
  reverseDependencies.get(observer)!.add(subject as Subject<unknown>)
}

export function notifyObservers(subject: Subject<unknown>): void {
  const observers = dependencies.get(subject)
  
  if (!observers || observers.size === 0) return
  
  // Convert to array to avoid issues with Set modifications during iteration
  const observersArray = Array.from(observers)
  
  for (const observer of observersArray) {
    // Skip disposed observers
    if (observer.disposed) {
      dependencies.get(subject)?.delete(observer)
      continue
    }
    
    // Skip if already in notification stack (prevents circular dependencies)
    if (notificationStack.has(observer)) {
      continue
    }
    
    // Add to notification stack
    notificationStack.add(observer)
    
    try {
      if ('updateFn' in observer) {
        updateObserver(observer as Observer<unknown>)
        
        // After updating, notify any observers that depend on this computed value
        const computedSubjects = reverseDependencies.get(observer)
        if (computedSubjects) {
          for (const computedSubject of computedSubjects) {
            notifyObservers(computedSubject)
          }
        }
      }
    } finally {
      // Remove from notification stack
      notificationStack.delete(observer)
    }
  }
}

// Function to remove observer from collections
export function disposeObserver(observer: ObserverR): void {
  observer.disposed = true
  
  // Remove observer from all tracked subjects
  const subjects = reverseDependencies.get(observer)
  if (subjects) {
    for (const subject of subjects) {
      const observers = dependencies.get(subject)
      if (observers) {
        observers.delete(observer)
      }
    }
  }
}