/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  trackDependency,
  notifyObservers,
  Subject,
  EqualFn,
  dependencies,
  reverseDependencies
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name || 'computed',
    value,
    updateFn,
  }
  
  const getter: GetterFn<T> = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== o) {
      // Create a subject for this computed value
      const computedSubject: Subject<T> = {
        name: options?.name || 'computed',
        observer: o,
        value: o.value as T,
      }
      
      // Track that the active observer depends on this computed value
      trackDependency(computedSubject as Subject<unknown>, activeObserver)
    }
    
    // Set this observer as active to track dependencies during computation
    const previousObserver = getActiveObserver()
    setActiveObserver(o)
    try {
      const previousValue = o.value
      updateObserver(o)
      
      // If value changed, notify observers that depend on this computed value
      if (previousValue !== o.value) {
        const computedSubjects = reverseDependencies.get(o)
        if (computedSubjects) {
          for (const computedSubject of computedSubjects) {
            notifyObservers(computedSubject)
          }
        }
      }
    } finally {
      setActiveObserver(previousObserver)
    }
    
    return o.value!
  }
  
  // Initialize the computed value by tracking dependencies
  setActiveObserver(o)
  try {
    updateObserver(o)
  } finally {
    setActiveObserver(undefined)
  }
  
  return getter
}