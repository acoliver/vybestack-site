/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, disposeObserver } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn,
    disposed: false,
  }
  
  // Execute the callback immediately to track dependencies
  updateObserver(observer)
  
  return () => {
    if (observer.disposed) return
    
    // Use disposeObserver to properly clean up
    disposeObserver(observer)
  }
}