/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let currentValue = value
  
  const observer: Observer<T> = {
    name: options?.name,
    value: value,
    updateFn: () => {
      // Always recompute with fresh dependencies
      // Don't pass previous value to allow default parameters to work
      const result = updateFn(undefined)
      currentValue = result
      observer.value = result
      return result
    }
  }
  
  // Initial computation to establish dependencies
  updateObserver(observer)
  
  return (): T => {
    // Re-compute and establish fresh dependencies when getter is called
    // This is the key to making reactive updates work
    currentValue = updateObserver(observer)
    return currentValue!
  }
}
