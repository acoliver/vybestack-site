export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Basic structure check: local@domain
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmed)) {
    return false;
  }
  
  // Check for invalid patterns
  const [local, domain] = trimmed.split('@');
  
  // No double dots in local part
  if (local.includes('..')) {
    return false;
  }
  
  // Domain shouldn't have underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // No trailing dots in domain
  if (domain.endsWith('.')) {
    return false;
  }
  
  // Domain should have at least one dot
  if (!domain.includes('.')) {
    return false;
  }
  
  // Local part shouldn't be empty or start/end with dots
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  return true;
}

export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except the leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // If it's too short (without country code and area code)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Must have exactly 10 digits remaining
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (digits.charAt(0) === '0' || digits.charAt(0) === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  if (digits.charAt(3) === '0' || digits.charAt(3) === '1') {
    return false;
  }
  
  return true;
}

export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except the leading +
  const cleaned = value.trim();
  
  // Check for country code pattern - allow spaces between country code and digits
  const countryCodePattern = /^\+?54\s*([\d\s]{8,})$/;
  const withCountryCode = cleaned.match(countryCodePattern);
  
  if (withCountryCode) {
    // Handle +54 prefix
    let digits = withCountryCode[1];
    
    // Remove common separators and punctuation
    digits = digits.replace(/[\s\-().]/g, '');
    
    // Check for optional mobile indicator '9'
    if (digits.startsWith('9')) {
      digits = digits.substring(1);
    }
    
    // Now we should have area code + subscriber number
    if (digits.length < 8 || digits.length > 12) {
      return false;
    }
    
    // Area code should be first 2-4 digits (must start with 1-9)
    const areaCodeLength = digits.length - 6; // subscriber is 6-8 digits
    if (areaCodeLength < 2 || areaCodeLength > 4) {
      return false;
    }
    
    // Area code must start with 1-9
    if (areaCodeLength >= 1 && digits.charAt(0) === '0') {
      return false;
    }
    
    // Subscriber number (remaining digits) must be 6-8 digits
    const subscriberNumber = digits.substring(areaCodeLength);
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }
    
    return true;
  }
  
  // Check for domestic pattern (starting with 0)
  const domesticPattern = /^0(\d{8,12})$/;
  const withDomestic = cleaned.match(domesticPattern);
  
  if (withDomestic) {
    let digits = withDomestic[1];
    
    // Remove common separators and punctuation
    digits = digits.replace(/[\s\-().]/g, '');
    
    // Check for optional mobile indicator '9'
    if (digits.startsWith('9')) {
      digits = digits.substring(1);
    }
    
    // Now we should have area code + subscriber number
    if (digits.length < 8 || digits.length > 12) {
      return false;
    }
    
    // Area code should be first 2-4 digits (must start with 1-9)
    const areaCodeLength = digits.length - 6; // subscriber is 6-8 digits
    if (areaCodeLength < 2 || areaCodeLength > 4) {
      return false;
    }
    
    // Area code must start with 1-9
    if (areaCodeLength >= 1 && digits.charAt(0) === '0') {
      return false;
    }
    
    // Subscriber number (remaining digits) must be 6-8 digits
    const subscriberNumber = digits.substring(areaCodeLength);
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }
    
    return true;
  }
  
  return false;
}

export function isValidName(value: string): boolean {
  // Trim whitespace
  const trimmed = value.trim();
  
  if (trimmed.length === 0) {
    return false;
  }
  
  // Check for invalid patterns: digits or numbers
  if (/\d/.test(trimmed)) {
    return false;
  }
  
  // Check for symbols (excluding valid name characters)
  // Allow unicode letters, spaces, apostrophes, hyphens, and accented characters
  const namePattern = /^[a-zA-ZÀ-ÿ\u00C0-\u024F\s'-]+$/;
  
  if (!namePattern.test(trimmed)) {
    return false;
  }
  
  // Must not be all spaces or punctuation
  if (/^[\s'-]+$/.test(trimmed)) {
    return false;
  }
  
  // Exclude obviously fake patterns like "X Æ A-12" style names
  if (/^[xX]\s*[Ææ]\s*[aA]\s*[-‑]\s*\d+$/.test(trimmed)) {
    return false;
  }
  
  return true;
}

// Helper function for Luhn checksum validation
function luhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i));

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9; // Sum digits for numbers > 9
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check card type patterns
  // Visa: starts with 4, 13-19 digits
  const isVisa = /^4\d{12,18}$/.test(cleaned);
  
  // Mastercard: starts with 51-55, exactly 16 digits
  const isMastercard = /^5[1-5]\d{14}$/.test(cleaned);
  
  // AmEx: starts with 34 or 37, exactly 15 digits
  const isAmex = /^3[47]\d{13}$/.test(cleaned);
  
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Validate using Luhn checksum
  return luhnCheck(cleaned);
}
