export function capitalizeSentences(text: string): string {
  // First collapse multiple spaces into single spaces
  const collapsed = text.replace(/\s+/g, ' ');
  
  // Split by sentence endings but preserve the punctuation
  const sentences = collapsed.match(/[^.!?]+[.!?]*/g) || [];
  
  // Capitalize first letter of each sentence
  const capitalized = sentences.map(sentence => {
    if (sentence.length === 0) return sentence;
    
    // Find the first letter and capitalize it
    const firstLetterMatch = sentence.match(/[a-zA-Z]/);
    if (!firstLetterMatch) return sentence;
    
    const firstLetterIndex = firstLetterMatch.index!;
    const firstLetter = sentence.charAt(firstLetterIndex);
    const rest = sentence.substring(firstLetterIndex + 1);
    
    return sentence.substring(0, firstLetterIndex) + 
           firstLetter.toUpperCase() + 
           rest;
  });
  
  // Join sentences with exactly one space
  return capitalized.join(' ').replace(/\s+/g, ' ').trim();
}

export function extractUrls(text: string): string[] {
  // URL pattern matching common URL formats
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"'()]+[^\s<>"'.,!?;:)]*/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that commonly follows URLs
    return url.replace(/[.,!?;]+$/, '');
  });
}

export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving existing https URLs untouched
  return text.replace(/http:\/\//gi, 'https://');
}

export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
  const httpUrlRegex = /http:\/\/[^\s<>"'()]+\/?[^\s<>"'(),]*/gi;
  
  return text.replace(httpUrlRegex, (match) => {
    try {
      // Parse the URL
      const url = new URL(match);
      
      // Always upgrade scheme to https
      let resultUrl = `https://${url.host}${url.pathname}${url.search}${url.hash}`;
      
      // Check if path begins with /docs/ and has no dynamic hints
      if (url.pathname.startsWith('/docs/')) {
        // Check for dynamic hints in the path
        const pathHasDynamicHints = /cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/i.test(url.pathname) ||
                                   /[?&]/.test(url.search);
        
        if (!pathHasDynamicHints) {
          // Rewrite host to docs.originalhost
          const newHost = `docs.${url.host}`;
          resultUrl = `https://${newHost}${url.pathname}${url.search}${url.hash}`;
        }
      }
      
      return resultUrl;
    } catch {
      // If URL parsing fails, just upgrade scheme to https
      return match.replace(/^http:\/\//i, 'https://');
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.trim().match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Special case for February (handle leap years)
  if (month === 2) {
    const yearNum = parseInt(year);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    
    if (!isLeapYear && day > 28) {
      return 'N/A';
    }
  }
  
  return year;
}
