/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words starting with the prefix
  // But we need to exclude the exceptions
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Filter out the exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  const result = matches.filter(match => {
    const matchLower = match.toLowerCase();
    return !exceptionsLower.includes(matchLower);
  });
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find the full context where the token appears after a digit
  const contextPattern = new RegExp(`(\\d)(?!^)${token}`, 'gi');
  const contextMatches = text.match(contextPattern) || [];
  
  // Extract the full context from matches
  const results = contextMatches.map(match => {
    return match;
  });
  
  // Remove duplicates
  return [...new Set(results)];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Must have at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must have at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must have at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>?~`]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  const pattern = /(..).*\1/;
  if (pattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, ensure we're not matching IPv4 addresses
  const ipv4Pattern = /\b(\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 address pattern (including shorthand ::)
  // This pattern matches various IPv6 formats including the shorthand notation
  const ipv6Pattern = /\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b|\b(?:[a-fA-F0-9]{1,4}:){1,7}:|\b(?:[a-fA-F0-9]{1,4}:){1,6}:[a-fA-F0-9]{1,4}\b|\b(?:[a-fA-F0-9]{1,4}:){1,5}(?::[a-fA-F0-9]{1,4}){1,2}\b|\b(?:[a-fA-F0-9]{1,4}:){1,4}(?::[a-fA-F0-9]{1,4}){1,3}\b|\b(?:[a-fA-F0-9]{1,4}:){1,3}(?::[a-fA-F0-9]{1,4}){1,4}\b|\b(?:[a-fA-F0-9]{1,4}:){1,2}(?::[a-fA-F0-9]{1,4}){1,5}\b|\b[a-fA-F0-9]{1,4}:(?:(?::[a-fA-F0-9]{1,4}){1,6})\b|\b:(?:(?::[a-fA-F0-9]{1,4}){1,6}|:)\b|\b(?:[a-fA-F0-9]{1,4}:){1,5}:[a-fA-F0-9]{1,4}\b|\b(?:[a-fA-F0-9]{1,4}:){1,4}:[a-fA-F0-9]{1,4}\b|\b(?:[a-fA-F0-9]{1,4}:){1,3}:[a-fA-F0-9]{1,4}\b|\b(?:[a-fA-F0-9]{1,4}:){1,2}:[a-fA-F0-9]{1,4}\b|\b[a-fA-F0-9]{1,4}:(?:[a-fA-F0-9]{1,4}:){1,3}\b|\b(?::[a-fA-F0-9]{1,4}:){1,4}\b|\b(?:[a-fA-F0-9]{1,4}:){1,5}:\b|\b(?:[a-fA-F0-9]{1,4}:){1,6}:\b|\b:(?:(?::[a-fA-F0-9]{1,4}){1,7}|:)\b/;
  
  return ipv6Pattern.test(value);
}
