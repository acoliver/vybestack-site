import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }
  
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePreviousPage = (): void => {
    setCurrentPage((page) => Math.max(1, page - 1));
  };

  const handleNextPage = (): void => {
    setCurrentPage((page) => page + 1);
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const hasPreviousPage = currentPage > 1;
  const hasNextPage = data.hasNext;

  return (
    <section>
      <h1>Inventory</h1>
      <p>
        Page {data.page} of {Math.ceil(data.total / data.limit)} ({data.total} total items)
      </p>
      <InventoryList items={data.items} />
      <nav aria-label="Inventory pagination">
        <button
          onClick={handlePreviousPage}
          disabled={!hasPreviousPage}
          aria-label="Previous page"
        >
          Previous
        </button>
        <button
          onClick={handleNextPage}
          disabled={!hasNextPage}
          aria-label="Next page"
        >
          Next
        </button>
      </nav>
    </section>
  );
}
