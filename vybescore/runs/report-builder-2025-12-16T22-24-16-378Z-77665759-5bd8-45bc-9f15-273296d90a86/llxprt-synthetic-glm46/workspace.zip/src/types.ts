export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export type ReportFormat = 'markdown' | 'text';

export interface ReportOptions {
  format: ReportFormat;
  output?: string;
  includeTotals?: boolean;
}