import { ReportData, ReportFormat, ReportOptions } from './types.js';
import { MarkdownFormatter } from './formats/markdown.js';
import { TextFormatter } from './formats/text.js';

export interface ReportFormatter {
  render(data: ReportData, options: Pick<ReportOptions, 'includeTotals'>): string;
}

export const formatToRenderer = new Map<ReportFormat, () => ReportFormatter>([
  ['markdown', () => new MarkdownFormatter()],
  ['text', () => new TextFormatter()]
]);