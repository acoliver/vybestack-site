#!/usr/bin/env node

import fs from 'node:fs';
import { formatToRenderer } from '../formatters.js';
import type { ReportData, ReportOptions, ReportFormat } from '../types.js';

function parseArguments(): { inputFile: string; options: ReportOptions } {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> [--format <format>] [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  let format: ReportFormat = 'markdown';
  let output: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        i++;
        if (i >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = args[i] as ReportFormat;
        if (format !== 'markdown' && format !== 'text') {
          console.error('Error: Unsupported format');
          process.exit(1);
        }
        break;
      case '--output':
        i++;
        if (i >= args.length) {
          console.error('Error: --output requires a path');
          process.exit(1);
        }
        output = args[i];
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument ${args[i]}`);
        process.exit(1);
    }
  }
  
  return { inputFile, options: { format, output, includeTotals } };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(content);
    
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Missing or invalid "label" field in entry');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Missing or invalid "amount" field in entry');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${filePath}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Failed to load report data from ${filePath}`);
    }
    process.exit(1);
  }
}

function main(): void {
  const { inputFile, options } = parseArguments();
  
  if (!fs.existsSync(inputFile)) {
    console.error(`Error: File not found: ${inputFile}`);
    process.exit(1);
  }
  
  const data = loadReportData(inputFile);
  
  const rendererFactory = formatToRenderer.get(options.format);
  if (!rendererFactory) {
    console.error(`Error: Unsupported format`);
    process.exit(1);
  }
  
  const renderer = rendererFactory();
  const output = renderer.render(data, { includeTotals: options.includeTotals });
  
  if (options.output) {
    try {
      fs.writeFileSync(options.output, output);
      console.log(`Report written to ${options.output}`);
    } catch (error) {
      console.error(`Error: Failed to write to ${options.output}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
