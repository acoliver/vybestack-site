#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions, FormatRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  const parsed: CliArgs = {
    dataFile: '',
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      parsed.format = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--output' && i + 1 < args.length) {
      parsed.outputPath = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else if (!arg.startsWith('--') && !parsed.dataFile) {
      parsed.dataFile = arg;
    }
  }

  return parsed;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid required field: title (string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid required field: summary (string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid required field: entries (array)');
  }

  for (const [index, entry] of obj.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid label (string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid amount (number)`);
    }
  }

  return data as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && error.message.includes('ENOENT')) {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function getFormatRenderer(format: string): FormatRenderer {
  const formatMap: Record<string, FormatRenderer> = {
    markdown: renderMarkdown,
    text: renderText,
  };

  const renderer = formatMap[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}. Supported formats: ${Object.keys(formatMap).join(', ')}`);
  }

  return renderer;
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const cliArgs = parseArguments(args);

    if (!cliArgs.dataFile) {
      console.error('Error: Missing data file argument');
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    if (!cliArgs.format) {
      console.error('Error: Missing --format argument');
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    const reportData = loadReportData(cliArgs.dataFile);
    const renderer = getFormatRenderer(cliArgs.format);

    const options: ReportOptions = {
      includeTotals: cliArgs.includeTotals,
    };

    const output = renderer(reportData, options);

    if (cliArgs.outputPath) {
      writeFileSync(cliArgs.outputPath, output, 'utf-8');
      console.error(`Report written to: ${cliArgs.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}