/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Observer types
export type ObserverR = {
  name?: string
  dirty?: boolean
  disposed?: boolean
  sources?: Set<Subject<unknown>>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

// Subject types
export type SubjectR = {
  name?: string
  observers?: Set<Observer<unknown>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(
  observer: Observer<unknown> | undefined
): Observer<unknown> | undefined {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (observer.disposed) return

  const previous = setActiveObserver(observer as Observer<unknown>)

  try {
    // Clear previous sources - we'll rebuild them
    observer.sources = new Set()
    observer.value = observer.updateFn(observer.value)
    observer.dirty = false
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(subject: Subject<unknown>): void {
  if (subject.observers) {
    // Create a copy to avoid issues if the set is modified during iteration
    const observers = Array.from(subject.observers)
    for (const obs of observers) {
      if (!obs.disposed && !obs.dirty) {
        obs.dirty = true
        // Update immediately
        updateObserver(obs)
      }
    }
  }
}

export function linkObserverToSubject(
  observer: Observer<unknown>,
  subject: Subject<unknown>
): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  if (!subject.observers.has(observer)) {
    subject.observers.add(observer)
  }
  
  if (!observer.sources) {
    observer.sources = new Set()
  }
  if (!observer.sources.has(subject)) {
    observer.sources.add(subject)
  }
}

export function unlinkObserverFromSubject(
  observer: Observer<unknown>,
  subject: Subject<unknown>
): void {
  if (subject.observers) {
    subject.observers.delete(observer)
  }
  if (observer.sources) {
    observer.sources.delete(subject)
  }
}

export function disposeObserver(observer: Observer<unknown>): void {
  observer.disposed = true
  // Unlink from all sources
  if (observer.sources) {
    for (const source of observer.sources) {
      if (source.observers) {
        source.observers.delete(observer)
      }
    }
    observer.sources.clear()
  }
}
