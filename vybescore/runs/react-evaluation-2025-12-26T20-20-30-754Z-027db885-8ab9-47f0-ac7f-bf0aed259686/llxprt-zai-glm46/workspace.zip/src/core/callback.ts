/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, disposeObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    disposed: false,
    dirty: true,
    sources: new Set(),
  }
  
  // Initial execution to track dependencies
  updateObserver(observer as Observer<unknown>)
  
  return () => {
    disposeObserver(observer as Observer<unknown>)
  }
}
