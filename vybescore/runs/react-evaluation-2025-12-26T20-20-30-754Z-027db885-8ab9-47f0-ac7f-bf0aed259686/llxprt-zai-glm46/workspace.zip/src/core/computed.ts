/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  linkObserverToSubject,
  EqualFn,
  Subject,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create the subject first - this is what other observers subscribe to
  const computedSubject: Subject<unknown> = {
    name: options?.name,
    observers: new Set(),
    value: value,
  }
  
  // Create the observer that will track dependencies
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    disposed: false,
    dirty: true,
    sources: new Set(),
  }
  
  // Custom update function that updates both the observer and its subject
  const computedUpdateFn: UpdateFn<T> = (v) => {
    const result = updateFn(v)
    computedSubject.value = result
    
    // Notify all observers of this computed subject
    if (computedSubject.observers) {
      const observers = Array.from(computedSubject.observers)
      for (const obs of observers) {
        if (!obs.disposed && !obs.dirty) {
          obs.dirty = true
          updateObserver(obs)
        }
      }
    }
    
    return result
  }
  
  o.updateFn = computedUpdateFn
  
  // Initial update to establish dependencies and compute value
  const previous = setActiveObserver(o as Observer<unknown>)
  try {
    o.sources = new Set()
    o.value = computedUpdateFn(value)
    o.dirty = false
  } finally {
    setActiveObserver(previous)
  }
  
  return (): T => {
    const currentObserver = getActiveObserver()
    
    // If accessed within another observer, link them
    if (currentObserver && currentObserver !== (o as Observer<unknown>)) {
      linkObserverToSubject(currentObserver, computedSubject)
    }
    
    return computedSubject.value as T
  }
}
