#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

interface CliOptions {
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function main(): void {
  const args = process.argv.slice(2);

  if (args.length < 2) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const options = parseArguments(args);
  const dataJsonPath = getDataJsonPath(args);

  try {
    const reportData = loadAndValidateData(dataJsonPath);
    const renderOptions: RenderOptions = {
      includeTotals: options.includeTotals,
    };

    const output = generateReport(reportData, options.format, renderOptions);

    if (options.outputPath) {
      writeFileSync(options.outputPath, output, 'utf8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error((error as Error).message);
    process.exit(1);
  }
}

function parseArguments(args: string[]): CliOptions {
  const options: CliOptions = {
    format: '',
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      options.format = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a path');
      }
      options.outputPath = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  if (!options.format) {
    throw new Error('--format is required');
  }

  return options;
}

function getDataJsonPath(args: string[]): string {
  // Find the first argument that doesn't start with '--'
  for (const arg of args) {
    if (!arg.startsWith('--')) {
      return arg;
    }
  }
  throw new Error('Data JSON file path is required');
}

function loadAndValidateData(dataJsonPath: string): ReportData {
  let content: string;
  try {
    content = readFileSync(dataJsonPath, 'utf8');
  } catch (error) {
    throw new Error(`Failed to read file: ${dataJsonPath}`);
  }

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (error) {
    throw new Error(`Invalid JSON in file: ${dataJsonPath}`);
  }

  return validateReportData(data);
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Report data must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid "entries" field (must be an array)');
  }

  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Entry ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Entry ${i} has missing or invalid "label" field (must be a string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Entry ${i} has missing or invalid "amount" field (must be a number)`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: entries as Array<{ label: string; amount: number }>,
  };
}

function generateReport(data: ReportData, format: string, options: RenderOptions): string {
  switch (format.toLowerCase()) {
    case 'markdown':
      return markdownRenderer.render(data, options);
    case 'text':
      return textRenderer.render(data, options);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}