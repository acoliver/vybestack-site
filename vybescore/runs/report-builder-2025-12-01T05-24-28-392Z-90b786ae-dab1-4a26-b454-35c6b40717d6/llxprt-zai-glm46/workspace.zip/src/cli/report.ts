#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions, Format } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: Format;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliOptions {
  const options: CliOptions = {
    format: 'markdown',
    includeTotals: false,
  };

  let i = 3; // Skip node, script name, and input file
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing format value after --format');
      }
      const format = args[i] as Format;
      if (format !== 'markdown' && format !== 'text') {
        throw new Error(`Unsupported format: ${format}`);
      }
      options.format = format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing output path after --output');
      }
      options.output = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
    i++;
  }

  return options;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  const entries = obj.entries as unknown[];
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: entry ${i} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: entry ${i} has missing or invalid "label" field`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: entry ${i} has missing or invalid "amount" field`);
    }
  }

  return data as ReportData;
}

function main(): void {
  try {
    const args = process.argv;
    
    if (args.length < 4) {
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    const inputFile = args[2];
    
    // Parse CLI options
    const cliOptions = parseArguments(args);
    
    // Read and parse JSON input
    let jsonData: unknown;
    try {
      const jsonContent = readFileSync(inputFile, 'utf-8');
      jsonData = JSON.parse(jsonContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error(`Invalid JSON in file ${inputFile}: ${error.message}`);
      }
      throw error;
    }

    // Validate report data
    const reportData = validateReportData(jsonData);

    // Render report
    const renderOptions: RenderOptions = {
      includeTotals: cliOptions.includeTotals,
    };

    let output: string;
    switch (cliOptions.format) {
      case 'markdown':
        output = renderMarkdown.render(reportData, renderOptions);
        break;
      case 'text':
        output = renderText.render(reportData, renderOptions);
        break;
      default:
        throw new Error(`Unsupported format: ${cliOptions.format}`);
    }

    // Write output
    if (cliOptions.output) {
      writeFileSync(cliOptions.output, output, 'utf-8');
    } else {
      console.log(output);
    }

  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}