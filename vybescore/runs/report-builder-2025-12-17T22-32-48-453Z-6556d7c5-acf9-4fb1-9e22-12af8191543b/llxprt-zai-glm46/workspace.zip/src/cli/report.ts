#!/usr/bin/env node

import fs from 'node:fs';
import { formatters } from '../formatters.js';
import type { ReportData, RenderOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const result: CliArgs = {
    dataFile: args[2],
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  // Parse command line arguments
  for (let i = 3; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        result.format = args[i + 1];
        i++; // Skip next argument
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        result.outputPath = args[i + 1];
        i++; // Skip next argument
        break;
      case '--includeTotals':
        result.includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument ${args[i]}`);
        process.exit(1);
    }
  }

  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const dataObj = data as Record<string, unknown>;

  if (typeof dataObj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }

  if (typeof dataObj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }

  for (const entry of dataObj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid JSON: entry must be an object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid JSON: entry must have a "label" field (expected string)');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid JSON: entry must have an "amount" field (expected number)');
    }
  }

  if (typeof dataObj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }

  for (const entry of dataObj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid JSON: entry must be an object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid JSON: entry must have a "label" field (expected string)');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid JSON: entry must have an "amount" field (expected number)');
    }
  }

  return dataObj as unknown as ReportData;
}

function main(): void {
  try {
    const args = parseArguments(process.argv);

    // Validate format
    if (!(args.format in formatters)) {
      console.error(`Error: Unsupported format "${args.format}"`);
      process.exit(1);
    }

    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = fs.readFileSync(args.dataFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file ${args.dataFile}: ${error.message}`);
      } else if (error instanceof Error) {
        console.error(`Error: Unable to read file ${args.dataFile}: ${error.message}`);
      } else {
        console.error(`Error: Unable to read file ${args.dataFile}`);
      }
      process.exit(1);
    }

    // Validate report data
    const reportData = validateReportData(jsonData);

    // Render the report
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const formatter = formatters[args.format];
    const output = formatter(reportData, options);

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }

    process.exit(0);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
