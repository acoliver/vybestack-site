import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';
import type { RenderFunction } from './types.js';

export const formatters: Record<string, RenderFunction> = {
  markdown: renderMarkdown,
  text: renderText,
};