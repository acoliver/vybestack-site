/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern for the prefix
  // Use word boundaries to match whole words only
  const escapedPrefix = escapeRegex(prefix);
  const pattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  const filteredMatches = matches.filter(word => {
    const wordLower = word.toLowerCase();
    const prefixLower = prefix.toLowerCase();
    
    // Check if this word is an exception
    return !exceptions.some(exception => {
      const exceptionLower = exception.toLowerCase();
      return wordLower.startsWith(prefixLower) && 
             wordLower === exceptionLower;
    });
  });
  
  return filteredMatches;
}
function escapeRegex(string: string): string {
  return string.replace(/[.*+?^${}()|[]\]/g, '\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find the token when it's preceded by a digit and not at the beginning
  const escapedToken = escapeRegex(token);
  
  // Create pattern to find token after a digit but not at start
  const matches: string[] = [];
  const tokenRegex = new RegExp(escapedToken, 'gi');
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    const index = match.index;
    
    // Skip if token is at the beginning
    if (index === 0) continue;
    
    // Check if there's a digit before this position
    const beforeToken = text.substring(0, index);
    if (/\d/.test(beforeToken.slice(-1))) {
      // Return the token with its preceding digit
      const resultIndex = index - 1; // Include the digit
      matches.push(text.substring(resultIndex, index + token.length));
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must have uppercase, lowercase, digit, and symbol
  if (!/[A-Z]/.test(value)) return false; // No uppercase
  if (!/[a-z]/.test(value)) return false; // No lowercase  
  if (!/\d/.test(value)) return false; // No digit
  if (!/[!@#$%^&*()_+\-={};:'"|,.<>?]/.test(value)) return false; // No symbol
  
  // Check for immediate repeated sequences (like abab)
  for (let i = 0; i < value.length - 2; i++) {
    const sequence = value.substring(i, i + 2);
    const rest = value.substring(i + 2);
    if (rest.includes(sequence + sequence)) {
      return false; // Found immediate repeated sequence
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that handles shorthand notation with ::
  // This pattern detects IPv6 addresses while excluding IPv4
  const ipv6Pattern = /\b(?:[a-fA-F0-9]{1,4}:){1,7}[a-fA-F0-9]{1,4}\b|\b(?:[a-fA-F0-9]{1,4}:)*(?:[a-fA-F0-9]{1,4}:)?[a-fA-F0-9]{1,4}\b|\b(?:[a-fA-F0-9]{1,4}:){1,7}:\b|\b:[a-fA-F0-9]{1,4}:[a-fA-F0-9]{1,4}\b/;
  
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // First check if it's an IPv4 address - if so, return false
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Check for IPv6 addresses
  if (ipv6Pattern.test(value)) {
    return true;
  }
  
  // Also check for the shorthand :: notation
  if (value.includes('::')) {
    // Make sure it's not an IPv4-mapped IPv6 address
    const ipv4MappedPattern = /\b::ffff:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
    if (ipv4MappedPattern.test(value)) {
      return false;
    }
    
    // Count colons - IPv6 should have fewer than 8 groups (handled by ::)
    const colonCount = (value.match(/:/g) || []).length;
    if (colonCount >= 2) { // At least the :: shorthand
      return true;
    }
  }
  
  return false;
}
