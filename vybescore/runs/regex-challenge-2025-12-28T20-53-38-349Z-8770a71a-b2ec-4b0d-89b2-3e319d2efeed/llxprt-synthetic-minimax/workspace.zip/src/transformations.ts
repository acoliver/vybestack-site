/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces - collapse multiple spaces but preserve sentence boundaries
  let result = text.trim();
  
  // Capitalize first character of the string if it's a letter
  result = result.replace(/^(\s*)([a-z])/, (match, spaces, letter) => {
    return spaces + letter.toUpperCase();
  });
  
  // Find sentence boundaries (.?! followed by space and lowercase letter)
  // This regex finds sentence endings and the following lowercase letter
  const sentenceRegex = /([.!?]+)(\s+)([a-z])/g;
  
  result = result.replace(sentenceRegex, (match, punctuation, spaces, letter) => {
    return punctuation + spaces + letter.toUpperCase();
  });
  
  // Clean up spaces - ensure exactly one space after sentence endings
  result = result.replace(/([.!?]+)(\s*)/g, (match, punctuation) => {
    return punctuation + ' ';
  });
  
  // Trim final result to remove trailing space
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"'()]+|\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s<>"'()]*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs - remove trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[.,!?;:]+\s*$/g, '').replace(/[),.!?;:]+\s*$/g, '');
  });
  
  // Filter out any empty strings and duplicates
  const uniqueUrls = [...new Set(cleanedUrls)].filter(url => url.length > 0);
  
  return uniqueUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  // Use word boundaries to avoid replacing http in other contexts
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // URL regex to capture http:// URLs with their components
  const httpUrlRegex = /\bhttp:\/\/([a-zA-Z0-9.-]+)([^\s]*)/gi;
  
  return text.replace(httpUrlRegex, (match, domain, path) => {
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /[?&]/.test(path) || /cgi-bin/.test(path);
    const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)\b/i.test(path);
    
    // Always upgrade scheme to https://
    let resultUrl = `https://${domain}`;
    
    // Only rewrite host for docs paths that don't have dynamic hints or legacy extensions
    if (path.startsWith('/docs/') && !hasDynamicHints && !hasLegacyExtensions) {
      // Extract the docs path
      const docsPath = path;
      // Rewrite host to docs.domain.com
      const newDomain = `docs.${domain}`;
      resultUrl = `https://${newDomain}${docsPath}`;
    } else {
      // Preserve the original path for non-docs URLs or ones with dynamic hints
      resultUrl = `https://${domain}${path}`;
    }
    
    return resultUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy pattern
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, accounting for different months)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 29 for February to handle leap years
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // If we get here, the format is valid
  return year;
}
