import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('pagination manual tests', () => {
  it('Test 1: Default request returns page 1 with limit 5', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('Test 2: Page 2 returns items 6-10', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.page).toBe(2);
    expect(response.body.items[0].id).toBe(6);
  });

  it('Test 3: Page 3 returns last items', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.page).toBe(3);
    expect(response.body.hasNext).toBe(false);
  });

  it('Test 4: Invalid page (zero) returns 400', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('Test 5: Negative limit returns 400', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('Test 6: Limit > 100 returns 400', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('must not exceed 100');
  });

  it('Test 7: Non-numeric page returns 400', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('Test 8: Page beyond data returns empty result', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=4&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(0);
    expect(response.body.hasNext).toBe(false);
  });

  it('Test 9: Custom limit works', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=10');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(10);
    expect(response.body.hasNext).toBe(true);
  });

  it('Test 10: Pagination works correctly with limit 3', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const page1 = await request(app).get('/inventory?page=1&limit=3');
    expect(page1.body.items).toHaveLength(3);
    expect(page1.body.items[0].id).toBe(1);
    expect(page1.body.hasNext).toBe(true);
    
    const page2 = await request(app).get('/inventory?page=2&limit=3');
    expect(page2.body.items).toHaveLength(3);
    expect(page2.body.items[0].id).toBe(4);
    expect(page2.body.hasNext).toBe(true);
    
    const page3 = await request(app).get('/inventory?page=3&limit=3');
    expect(page3.body.items).toHaveLength(3);
    expect(page3.body.items[0].id).toBe(7);
    expect(page3.body.hasNext).toBe(true);
    
    const page4 = await request(app).get('/inventory?page=4&limit=3');
    expect(page4.body.items).toHaveLength(3);
    expect(page4.body.items[0].id).toBe(10);
    expect(page4.body.hasNext).toBe(true);
    
    const page5 = await request(app).get('/inventory?page=5&limit=3');
    expect(page5.body.items).toHaveLength(3);
    expect(page5.body.items[0].id).toBe(13);
    expect(page5.body.hasNext).toBe(false);
  });
});
