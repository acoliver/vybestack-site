export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with strict rules.
 * Accepts: name+tag@example.co.uk, user@domain.com
 * Rejects: double dots, trailing dots, underscores in domain, etc.
 */
export function isValidEmail(value: string): boolean {
  // Main email pattern: local@domain.tld
  // Local part: alphanumeric, dots, hyphens, plus, underscore (but no consecutive dots or trailing/leading dots)
  // Domain: alphanumeric, hyphens (no underscores), proper TLD
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  const [local, domain] = value.split('@');
  
  // No consecutive dots in local part
  if (local.includes('..')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain must have at least one dot and TLD at least 2 chars
  const domainParts = domain.split('.');
  if (domainParts.length < 2 || domainParts[domainParts.length - 1].length < 2) {
    return false;
  }
  
  // No consecutive dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: area codes starting with 0 or 1, too short numbers
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Extract digits only for validation
  const digitsOnly = cleaned.replace(/\+/g, '');
  
  // Must have at least 10 digits
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  if (cleaned.startsWith('+1') && digitsOnly.length === 11) {
    // Area code is the first 3 digits after country code
    const areaCode = digitsOnly.substring(1, 4);
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') {
      return false;
    }
    return true;
  }
  
  // Without country code, must be exactly 10 digits
  if (digitsOnly.length === 10) {
    const areaCode = digitsOnly.substring(0, 3);
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') {
      return false;
    }
    return true;
  }
  
  return false;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - Without country code, must have trunk prefix 0
 * - Separators: single spaces or hyphens
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces and hyphens)
  const normalized = value.replace(/[\s-]/g, '');
  
  // Must be at least 8 digits (2 digit area code + 6 digit subscriber)
  // Max 15 digits (+54 + 9 + 4 digit area code + 8 digit subscriber)
  if (!/^\+?\d{8,15}$/.test(normalized)) {
    return false;
  }
  
  // Extract the part after country code
  let afterCountryCode = normalized;
  if (normalized.startsWith('+54')) {
    afterCountryCode = normalized.substring(3);
  }
  
  // Check trunk prefix rule
  // If no country code, must start with 0 (trunk prefix)
  if (!normalized.startsWith('+54')) {
    // Must have trunk prefix 0
    if (!afterCountryCode.startsWith('0')) {
      return false;
    }
    afterCountryCode = afterCountryCode.substring(1); // Remove trunk prefix
  } else {
    // With country code, trunk prefix is optional
    if (afterCountryCode.startsWith('0')) {
      afterCountryCode = afterCountryCode.substring(1); // Remove trunk prefix
    }
  }
  
  // Remove mobile indicator if present
  if (afterCountryCode.startsWith('9')) {
    afterCountryCode = afterCountryCode.substring(1);
  }
  
  // Now we should have: area code (2-4 digits, starts with 1-9) + subscriber (6-8 digits)
  // Total should be 8-12 digits
  if (afterCountryCode.length < 8 || afterCountryCode.length > 12) {
    return false;
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  const areaCodeMatch = afterCountryCode.match(/^([1-9]\d{1,3})(\d+)$/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const [, areaCode, subscriber] = areaCodeMatch;
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects: digits, symbols, names like "X Æ A-12" with digits
 */
export function isValidName(value: string): boolean {
  // Pattern: unicode letters (including accents), apostrophes, hyphens, spaces
  // Must have at least one letter
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter (unicode)
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers (Visa, Mastercard, AmEx) with Luhn checksum.
 * Accepts valid prefixes and lengths for each card type.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check card type and length
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaPattern = /^4\d{12}(\d{3})?$/;
  const mastercardPattern = /^(5[1-5]\d{14}|(2[2-7][0-9]{2}|27[0-1][0-9]|2720)\d{12})$/;
  const amexPattern = /^3[47]\d{13}$/;
  
  if (!visaPattern.test(cleaned) && !mastercardPattern.test(cleaned) && !amexPattern.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}
