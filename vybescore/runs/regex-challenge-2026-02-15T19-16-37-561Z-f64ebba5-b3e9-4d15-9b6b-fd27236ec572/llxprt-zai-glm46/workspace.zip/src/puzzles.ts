/**
 * Match words starting with the prefix but excluding banned words.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  // Word boundary ensures we match complete words
  const pattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 * Returns the full match including the digit (e.g., "1foo" when searching for "foo" after "1").
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token, not at start of string
  // Using word boundary to ensure we match complete tokens
  const pattern = new RegExp(`\\b\\d${escapedToken}\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out matches at the start of the string
  return matches.filter(match => {
    const index = text.indexOf(match);
    return index > 0;
  });
}

/**
 * Validate passwords according to security policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol (any non-alphanumeric character that's not whitespace)
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // Look for patterns like "abab", "123123", "aaaa"
  // A sequence is considered repeated if a substring of length 2-4 is immediately repeated
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - (len * 2); i++) {
      const substr = value.substring(i, i + len);
      const nextSubstr = value.substring(i + len, i + (len * 2));
      if (substr === nextSubstr) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 * Returns true if IPv6 address is detected, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (full and shorthand)
  // Can include :: shorthand
  // Groups of 1-4 hex digits separated by colons
  // Can have up to one :: for consecutive zero groups
  const ipv6Pattern = /(?:^|[\s:])(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?::[0-9a-fA-F]{1,4}){1,7}|::)(?:$|[\s:])/;
  
  // IPv4 pattern (to exclude)
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if it matches IPv6 pattern
  const ipv6Match = value.match(ipv6Pattern);
  
  if (!ipv6Match) {
    return false;
  }
  
  // Extract the matched portion and verify it's not IPv4
  const matchedText = ipv6Match[0];
  
  // Check if this is actually an IPv4 address (IPv6 can have embedded IPv4)
  // For example, ::ffff:192.168.1.1 is valid IPv6
  // But plain 192.168.1.1 should not match
  
  // If the match is a plain IPv4, return false
  if (ipv4Pattern.test(matchedText.trim()) && !matchedText.includes(':')) {
    return false;
  }
  
  return true;
}
