/**
 * Capitalize the first character of each sentence.
 * - Sentences end with . ? or !
 * - Insert exactly one space between sentences
 * - Collapse extra spaces sensibly
 * - Try to preserve abbreviations (e.g., "Dr." in middle of sentence)
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Capitalize first character of text
  if (result.length > 0) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  // Split into sentences by . ? or ! followed by optional space
  // We'll use a more sophisticated approach to handle abbreviations
  const sentencePattern = /([.!?])\s*/g;
  
  // Process sentence by sentence
  const sentences: string[] = [];
  let lastIndex = 0;
  let match;
  
  while ((match = sentencePattern.exec(result)) !== null) {
    // Add the sentence up to and including the punctuation
    const endIndex = match.index + match[0].length;
    sentences.push(result.substring(lastIndex, endIndex));
    lastIndex = endIndex;
  }
  
  // Add remaining text
  if (lastIndex < result.length) {
    sentences.push(result.substring(lastIndex));
  }
  
  // Rebuild with proper capitalization
  let final = '';
  for (let i = 0; i < sentences.length; i++) {
    let sentence = sentences[i];
    
    if (i === 0) {
      // First sentence already capitalized above
      final = sentence;
    } else {
      // Capitalize first letter after sentence boundary
      // Find the first alphabetic character and capitalize it
      sentence = sentence.replace(/^\s*([a-z])/, (_, char) => char.toUpperCase());
      final += sentence;
    }
  }
  
  // Ensure exactly one space after sentence endings
  final = final.replace(/([.!?])\s+/g, '$1 ');
  
  return final.trim();
}

/**
 * Find all URLs in the text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: protocol://domain/path...
  // Allow common protocols: http, https, ftp, etc.
  // Domain: alphanumeric, hyphens, dots
  // Path: alphanumeric, hyphens, dots, slashes, query params, anchors
  const urlPattern = /\b(?:https?:\/\/|ftp:\/\/)[^\s<>"{}|\\^`[\]]+?(?=[\s,.!?;:)]*(?:\s|$|<|>|"|'|`|\)|\]|\}))/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[,!?;:.)]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://...
 * - Always upgrade scheme to https
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints: cgi-bin, query strings, legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com/ URLs
  const urlPattern = /(http:\/\/example\.com\/[^\s<>"{}|\\^`[\]]+?)(?=[\s,.!?;:)]*(?:\s|$|<|>|"|'|`|\)|\]|\}))/gi;
  
  return text.replace(urlPattern, (url) => {
    // Remove trailing punctuation
    const cleanUrl = url.replace(/[,!?;:.)]+$/, '');
    
    // Check for dynamic hints that should prevent host rewrite
    const dynamicHints = /(cgi-bin|[?&=]|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i;
    
    // Extract the path portion
    const pathMatch = cleanUrl.match(/http:\/\/example\.com(\/.*)$/i);
    if (!pathMatch) {
      // Can't parse path, just upgrade scheme
      return cleanUrl.replace(/^http:\/\//i, 'https://');
    }
    
    const fullPath = pathMatch[1];
    
    // Check if path starts with /docs/
    if (fullPath.startsWith('/docs/') || fullPath === '/docs') {
      // Check for dynamic hints
      if (dynamicHints.test(fullPath)) {
        // Has dynamic hints, only upgrade scheme
        return cleanUrl.replace(/^http:\/\//i, 'https://');
      }
      // No dynamic hints, rewrite host
      return cleanUrl.replace(/^http:\/\/example\.com/i, 'https://docs.example.com');
    }
    
    // Path doesn't start with /docs/, only upgrade scheme
    return cleanUrl.replace(/^http:\/\//i, 'https://');
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  const isLeapYear = (year: number) => {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  };
  
  const maxDay = month === 2 && isLeapYear(parseInt(year, 10)) 
    ? 29 
    : daysInMonth[month - 1];
  
  if (day < 1 || day > maxDay) {
    return 'N/A';
  }
  
  return year;
}
