import type { ReportRenderer, ReportData, ReportOptions } from '../types.js';
import { calculateTotal, formatAmount } from '../utils.js';

/**
 * Markdown implementation of the report renderer
 */
export class MarkdownRenderer implements ReportRenderer {
  render(data: ReportData, options: ReportOptions): string {
    const lines: string[] = [];
    
    // Add title
    lines.push(`# ${data.title}`);
    lines.push('');
    
    // Add summary
    lines.push(data.summary);
    lines.push('');
    
    // Add entries heading
    lines.push('## Entries');
    
    // Add entries
    for (const entry of data.entries) {
      lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
    }
    
    // Add total if requested
    if (options.includeTotals) {
      const total = calculateTotal(data.entries);
      lines.push('');
      lines.push(`**Total:** ${formatAmount(total)}`);
    }
    
    return lines.join('\n');
  }
}

export const renderMarkdown = (data: ReportData, options: ReportOptions): string => {
  const renderer = new MarkdownRenderer();
  return renderer.render(data, options);
};