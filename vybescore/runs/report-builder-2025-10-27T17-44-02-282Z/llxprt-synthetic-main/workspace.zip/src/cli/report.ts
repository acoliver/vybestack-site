#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { ReportData, ReportFormat, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Parse command line arguments
 */
function parseArguments(args: string[]): {
  dataPath: string;
  format: ReportFormat;
  outputPath?: string;
  options: ReportOptions;
} {
  if (args.length < 4) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[2];
  const formatArg = args[3];
  
  // Validate format argument
  if (formatArg !== '--format') {
    console.error('Error: Expected --format as second argument');
    process.exit(1);
  }

  const format = args[4] as ReportFormat;
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }

  const options: ReportOptions = { includeTotals: false };
  let outputPath: string | undefined;

  // Parse additional arguments
  for (let i = 5; i < args.length; i++) {
    if (args[i] === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip next argument as it's the output path
    } else if (args[i] === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  return { dataPath, format, outputPath, options };
}

/**
 * Load and validate JSON data
 */
function loadData(dataPath: string): ReportData {
  try {
    const content = readFileSync(dataPath, { encoding: 'utf8' });
    const data = JSON.parse(content) as unknown;
    
    // Basic validation
    if (
      typeof data !== 'object' ||
      data === null ||
      !('title' in data) ||
      !('summary' in data) ||
      !('entries' in data)
    ) {
      throw new Error('Invalid data structure');
    }
    
    const reportData = data as ReportData;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Title must be a string');
    }
    
    if (typeof reportData.summary !== 'string') {
      throw new Error('Summary must be a string');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Entries must be an array');
    }
    
    for (const entry of reportData.entries) {
      if (
        typeof entry !== 'object' ||
        entry === null ||
        !('label' in entry) ||
        !('amount' in entry)
      ) {
        throw new Error('Invalid entry structure');
      }
      
      if (typeof entry.label !== 'string') {
        throw new Error('Entry label must be a string');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Entry amount must be a number');
      }
    }
    
    return reportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON format');
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Failed to load data');
    }
    process.exit(1);
  }
}

/**
 * Get the appropriate renderer for the format
 */
function getRenderer(format: ReportFormat) {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      console.error('Error: Unsupported format');
      process.exit(1);
  }
}

/**
 * Main execution function
 */
function main() {
  const { dataPath, format, outputPath, options } = parseArguments(process.argv);
  const data = loadData(dataPath);
  const renderer = getRenderer(format);
  const output = renderer(data, options);
  
  if (outputPath) {
    try {
      writeFileSync(outputPath, output, { encoding: 'utf8' });
      console.log(`Report written to ${outputPath}`);
    } catch {
      console.error('Error: Failed to write output file');
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

// Run the application
main();
