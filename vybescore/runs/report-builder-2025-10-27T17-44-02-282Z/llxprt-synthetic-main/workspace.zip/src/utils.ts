import type { ReportEntry } from './types.js';

/**
 * Utility functions for report processing
 */

/**
 * Calculate the total amount from report entries
 */
export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((total, entry) => total + entry.amount, 0);
}

/**
 * Format an amount as a dollar string with two decimal places
 */
export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}