import express, { Request, Response } from 'express';
import path from 'path';
import http from 'http';
import { validateContactData, hasValidationErrors, ContactData } from './validation.js';
import { initializeDatabase, closeDatabase, insertSubmission } from './database.js';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Set up EJS
app.set('views', path.join(process.cwd(), 'views'));
app.set('view engine', 'ejs');

// GET / - Render the contact form
app.get('/', (_req: Request, res: Response) => {
  res.render('index', {
    errors: {},
    data: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: Partial<ContactData> = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvince: req.body.stateProvince,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phone: req.body.phone
    };

    const errors = validateContactData(formData);

    if (hasValidationErrors(errors)) {
      // Validation failed, re-render form with errors
      res.status(400).render('index', {
        errors,
        data: req.body
      });
      return;
    }

    // Validation passed, save to database
    await insertSubmission(formData as ContactData);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).send('Internal server error');
  }
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you');
});

// Health check endpoint
app.get('/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok' });
});

let server: http.Server | null = null;

async function startServer() {
  try {
    // Initialize database
    await initializeDatabase();
    console.log('Database initialized successfully');

    // Start server
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown handling
function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
    });
  }

  closeDatabase();
  console.log('Graceful shutdown completed');
  process.exit(0);
}

// Handle SIGTERM for container orchestration
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught exception:', error);
  gracefulShutdown('uncaughtException');
});

process.on('unhandledRejection', (reason, _promise) => {
  console.error('Unhandled rejection at:', _promise, 'reason:', reason);
  gracefulShutdown('unhandledRejection');
});

// Start the server
startServer();
