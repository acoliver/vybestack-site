export interface ContactData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationErrors {
  [key: string]: string;
}

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const phoneRegex = /^\+?[\d\s\-()]{7,}$/;

const postalCodeRegex = /^[A-Za-z0-9\s]{3,12}$/;

export function validateContactData(data: Partial<ContactData>): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }

  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/ZIP code is required';
  }

  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  }

  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  }

  // Email format validation
  if (data.email && !emailRegex.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone format validation
  if (data.phone && !phoneRegex.test(data.phone.trim())) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code format validation
  if (data.postalCode && !postalCodeRegex.test(data.postalCode.trim().replace(/\s/g, ''))) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return errors;
}

export function hasValidationErrors(errors: ValidationErrors): boolean {
  return Object.keys(errors).length > 0;
}