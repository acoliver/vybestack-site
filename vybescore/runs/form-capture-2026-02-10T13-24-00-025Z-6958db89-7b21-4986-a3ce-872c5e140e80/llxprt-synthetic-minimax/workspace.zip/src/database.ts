import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';
import type { Database } from 'sql.js';

const SCHEMA_PATH = path.resolve('db', 'schema.sql');
const DB_PATH = path.resolve('data', 'submissions.sqlite');

let sqlInstance: Database | null = null;

export async function initializeDatabase(): Promise<Database> {
  if (sqlInstance) {
    return sqlInstance;
  }

  const SQL = await initSqlJs({
    locateFile: () => {
      // Use default locateFile behavior which should find sql-wasm.wasm in node_modules
      return 'sql-wasm.wasm';
    }
  });

  // Check if database file exists
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    sqlInstance = new SQL.Database(fileBuffer);
  } else {
    // Create new database and load schema
    sqlInstance = new SQL.Database();
    
    // Read and execute schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    sqlInstance.exec(schema);
    
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
  }

  return sqlInstance;
}

export function getDatabase(): Database | null {
  return sqlInstance;
}

export function closeDatabase(): void {
  if (sqlInstance) {
    sqlInstance.close();
    sqlInstance = null;
  }
}

export function persistDatabase(): void {
  if (!sqlInstance) {
    throw new Error('Database not initialized');
  }

  const data = sqlInstance.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export async function insertSubmission(data: {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}): Promise<void> {
  const database = await initializeDatabase();
  
  const stmt = database.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  try {
    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);
  } finally {
    stmt.free();
  }

  // Persist database after insert
  persistDatabase();
}