/**
 * Encode plain text to Base64 using the canonical alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate Base64 format before attempting to decode
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Validate if the input string is valid Base64.
 * Accepts standard Base64 with or without padding characters.
 */
function isValidBase64(input: string): boolean {
  // Empty string is not valid Base64
  if (input.length === 0) return false;
  
  // Remove any whitespace for validation
  const trimmed = input.trim();
  
  // Check if characters are all valid Base64 characters (including padding)
  const base64Regex = /^[A-Za-z0-9+/=]*$/;
  if (!base64Regex.test(trimmed)) return false;
  
  // Check for proper padding (if present)
  // Padding can only be at the end and consists of '=' characters
  const paddingStart = trimmed.indexOf('=');
  if (paddingStart !== -1) {
    // Ensure all characters after first '=' are '='
    if (trimmed.slice(paddingStart).split('').some(c => c !== '=')) return false;
    
    // Padding cannot be more than 3 characters
    const paddingLength = trimmed.length - paddingStart;
    if (paddingLength > 3) return false;
    
    // If padding is present, length must be a multiple of 4
    return trimmed.length % 4 === 0;
  }
  
  // For unpadded input, check if padding would make it valid
  // This accepts inputs like "QQ" (2 chars) which would become "QQ==" when padded
  const paddedLength = trimmed.length + (4 - (trimmed.length % 4));
  return paddedLength % 4 === 0 && trimmed.length > 0;
}
