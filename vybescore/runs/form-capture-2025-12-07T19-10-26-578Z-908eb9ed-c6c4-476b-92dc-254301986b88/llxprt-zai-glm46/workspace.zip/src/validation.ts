import { FormData, FormErrors } from './types';

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length >= 7;
}

export function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

export function validateFormData(data: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};

  if (!data.first_name || data.first_name.trim().length === 0) {
    errors.first_name = 'First name is required';
  }

  if (!data.last_name || data.last_name.trim().length === 0) {
    errors.last_name = 'Last name is required';
  }

  if (!data.street_address || data.street_address.trim().length === 0) {
    errors.street_address = 'Street address is required';
  }

  if (!data.city || data.city.trim().length === 0) {
    errors.city = 'City is required';
  }

  if (!data.state_province || data.state_province.trim().length === 0) {
    errors.state_province = 'State/Province/Region is required';
  }

  if (!data.postal_code || data.postal_code.trim().length === 0) {
    errors.postal_code = 'Postal/Zip code is required';
  } else if (!validatePostalCode(data.postal_code)) {
    errors.postal_code = 'Please enter a valid postal/zip code';
  }

  if (!data.country || data.country.trim().length === 0) {
    errors.country = 'Country is required';
  }

  if (!data.email || data.email.trim().length === 0) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data.phone || data.phone.trim().length === 0) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}