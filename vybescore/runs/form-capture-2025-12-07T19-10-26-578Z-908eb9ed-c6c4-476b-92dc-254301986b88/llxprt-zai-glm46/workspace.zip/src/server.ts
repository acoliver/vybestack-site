import express from 'express';
import path from 'path';
import { initializeDatabase, saveDatabase } from './database';
import { validateFormData } from './validation';
import { FormData } from './types';

const app = express();
const PORT = process.env.PORT || 3535;

app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

app.use(express.static(path.join(process.cwd(), 'public')));
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.render('form', {
    formData: {},
    errors: {}
  });
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

app.post('/submit', async (req, res) => {
  try {
    const formData: FormData = {
      first_name: req.body.first_name || '',
      last_name: req.body.last_name || '',
      street_address: req.body.street_address || '',
      city: req.body.city || '',
      state_province: req.body.state_province || '',
      postal_code: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateFormData(formData);

    if (!validation.isValid) {
      return res.status(400).render('form', {
        formData,
        errors: validation.errors
      });
    }

    const db = await initializeDatabase();
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.first_name,
      formData.last_name,
      formData.street_address,
      formData.city,
      formData.state_province,
      formData.postal_code,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
    saveDatabase();

    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', {
      formData: req.body,
      errors: { general: 'An error occurred while processing your submission. Please try again.' }
    });
  }
});

export function startServer() {
  return initializeDatabase().then(() => {
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    return server;
  }).catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

if (require.main === module) {
  startServer();
}

export { app };