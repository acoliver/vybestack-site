import fs from 'fs';
import path from 'path';

const initSqlJs = require('sql.js');

type Database = any;

let db: Database | null = null;

export async function initializeDatabase(): Promise<Database> {
  if (db) {
    return db;
  }

  const SQL = await initSqlJs({
    locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
  });

  const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  
  try {
    const filebuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(filebuffer);
  } catch (error) {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
    db.exec(schema);
    saveDatabase();
  }

  return db;
}

export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const data = db.export();
  const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  fs.writeFileSync(dbPath, Buffer.from(data));
}

export function getDatabase(): Database {
  if (!db) {
    throw new Error('Database not initialized');
  }
  return db;
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}