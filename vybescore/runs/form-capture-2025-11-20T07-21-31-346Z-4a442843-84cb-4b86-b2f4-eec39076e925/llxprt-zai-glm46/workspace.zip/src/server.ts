import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initialiseDatabase from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

const port = process.env.PORT || 3535;

let db: import('sql.js').Database;

interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const validateForm = (data: Partial<FormSubmission>): ValidationError[] => {
  const errors: ValidationError[] = [];

  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  }

  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push({ field: 'email', message: 'Email is not valid' });
  }

  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^\+?[\d\s\-()]+$/.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number is not valid' });
  }

  return errors;
};

const initializeApp = async () => {
  try {
    db = await initialiseDatabase();

    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));

    app.use('/public', express.static(path.join(__dirname, '../public')));

    app.set('view engine', 'ejs');
    app.set('views', path.join(__dirname, 'templates'));

    app.get('/', (req, res) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    app.post('/submit', (req, res) => {
      const formData: FormSubmission = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        streetAddress: req.body.streetAddress,
        city: req.body.city,
        stateProvince: req.body.stateProvince,
        postalCode: req.body.postalCode,
        country: req.body.country,
        email: req.body.email,
        phone: req.body.phone
      };

      const errors = validateForm(formData);

      if (errors.length > 0) {
        return res.render('form', {
          errors: errors.map(e => e.message),
          values: formData
        });
      }

      try {
        const stmt = db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province, 
            postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run(
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        );

        res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(formData.firstName));
      } catch (error) {
        console.error('Database error:', error);
        res.render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: formData
        });
      }
    });

    app.get('/thank-you', (req, res) => {
      res.render('thank-you', {
        firstName: req.query.firstName || 'Friend'
      });
    });

    return app;
  } catch (error) {
    console.error('Failed to initialize app:', error);
    throw error;
  }
};

const startServer = async (testPort?: number) => {
  try {
    await initializeApp();
    
    // Use provided test port or find available port for testing
    const serverPort = process.env.NODE_ENV === 'test' ? (testPort || 0) : port;
    
    const server = app.listen(serverPort, () => {
      if (process.env.NODE_ENV !== 'test') {
        console.log(`Server running on port ${serverPort}`);
      }
    });

    const gracefulShutdown = () => {
      console.log('Shutting down gracefully...');
      server.close(() => {
        if (db && db.close) {
          db.close();
        }
        process.exit(0);
      });
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);

    return { server, app };
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

export { startServer };
export default startServer;

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

