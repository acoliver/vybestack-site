import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const initialiseDatabase = async (): Promise<import('sql.js').Database> => {
  const SQL = await initSqlJs({
    locateFile: (file: string): string => `node_modules/sql.js/dist/${file}`
  });

  const dbPath = path.join(__dirname, '../../data/submissions.sqlite');
  let db: import('sql.js').Database;

  try {
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
      console.log('Loaded existing database');
    } else {
      db = new SQL.Database();
      console.log('Created new database');
    }
  } catch (error) {
    console.error('Error loading database:', error);
    db = new SQL.Database();
    console.log('Created new database due to error');
  }

  const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  try {
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.exec(schema);
    console.log('Database schema initialized');
  } catch (error) {
    console.error('Error reading schema:', error);
  }

  const saveDatabase = () => {
    try {
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
      console.log('Database saved to disk');
    } catch (error) {
      console.error('Error saving database:', error);
    }
  };

  const originalPrepare = db.prepare.bind(db);
  db.prepare = function(sql: string): import('sql.js').Statement {
    const stmt = originalPrepare(sql) as import('sql.js').Statement;
    if (stmt && stmt.run) {
      const originalRun = stmt.run.bind(stmt);
      stmt.run = function(...args: unknown[]) {
        const result = originalRun(...args);
        saveDatabase();
        return result;
      };
    }
    return stmt;
  };

  return db;
};

export default initialiseDatabase;