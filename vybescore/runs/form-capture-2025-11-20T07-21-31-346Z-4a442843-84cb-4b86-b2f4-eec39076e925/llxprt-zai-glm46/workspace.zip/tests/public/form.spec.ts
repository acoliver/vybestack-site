import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import { startServer } from '../../dist/server.js';

// eslint-disable-next-line @typescript-eslint/no-explicit-any

// eslint-disable-next-line @typescript-eslint/no-explicit-any
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let server: { 
  server: { 
    address(): { port: number } | null; 
    close(callback?: (err?: Error) => void): void; 
  }; 
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  app: any;
};

beforeAll(async () => {
  server = await startServer();
  
  // Wait for server to be ready
  await new Promise((resolve) => {
    if (server.server.address()) {
      resolve(undefined);
      return;
    }
    
    const checkInterval = setInterval(() => {
      if (server.server.address()) {
        clearInterval(checkInterval);
        resolve(undefined);
      }
    }, 100);
  });
}, 30000); // Increase timeout to 30 seconds

afterAll(async () => {
  if (server && typeof server.server.close === 'function') {
    await new Promise<void>((resolve, reject) => {
      server.server.close((err?: Error) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server.app).get('/');
    console.log('Response status:', response.status);
    console.log('Response text length:', response.text?.length);
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('form[method="post"][action="/submit"]').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check that CSS is loaded
    expect($('link[rel="stylesheet"][href="/styles.css"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(server.app)
      .post('/submit')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    expect(fs.existsSync(dbPath)).toBe(true);

    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you');
  });

  it('validates required fields', async () => {
    const response = await request(server.app)
      .post('/submit')
      .send({});

    expect(response.status).toBe(200);
    const $ = cheerio.load(response.text);
    expect($('.error-list').length).toBe(1);
    expect($('.error-list li').length).toBeGreaterThan(0);
  });

  it('validates email format', async () => {
    const response = await request(server.app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'invalid-email',
        phone: '+1 555-123-4567'
      });

    expect(response.status).toBe(200);
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toContain('Email is not valid');
  });

  it('validates phone format', async () => {
    const response = await request(server.app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'john.doe@example.com',
        phone: 'invalid-phone'
      });

    expect(response.status).toBe(200);
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toContain('Phone number is not valid');
  });
});
