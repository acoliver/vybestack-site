export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // - Local part: letters, numbers, +,-,_,.,@ allowed but no consecutive dots or leading/trailing dots
  // - Domain part: letters, numbers, dots, hyphens but no consecutive dots, leading/trailing dots, or underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1
  if (cleanValue.startsWith('+1')) {
    const digits = cleanValue.substring(2);
    return /^[2-9]\d{2}[2-9]\d{6}$/.test(digits);
  }
  
  // Check if it's just 1 + 10 digits
  if (cleanValue.length === 11 && cleanValue.startsWith('1')) {
    const digits = cleanValue.substring(1);
    return /^[2-9]\d{2}[2-9]\d{6}$/.test(digits);
  }
  
  // Check if it's 10 digits (no country code)
  if (cleanValue.length === 10) {
    return /^[2-9]\d{2}[2-9]\d{6}$/.test(cleanValue);
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for easier validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check for +54 prefix (international format)
  if (cleanValue.startsWith('+54')) {
    const afterCountryCode = cleanValue.substring(3); // Remove +54
    
    // Match with mobile indicator (9) - e.g., +5491123412345678
    if (/^9(\d{2,4})(\d{6,8})$/.test(afterCountryCode)) {
      const subscriber = afterCountryCode.match(/^9\d{2,4}(\d{6,8})$/)![1];
      return subscriber.length >= 6 && subscriber.length <= 8;
    }
    
    // Match without mobile indicator - e.g., +541123412345678
    if (/^(\d{2,4})(\d{6,8})$/.test(afterCountryCode)) {
      const areaCode = afterCountryCode.match(/^(\d{2,4})\d{6,8}$/)![1];
      const subscriber = afterCountryCode.match(/^\d{2,4}(\d{6,8})$/)![1];
      
      // Area code must start with 1-9, subscriber must be 6-8 digits
      if (/^[1-9]\d{1,3}$/.test(areaCode) && subscriber.length >= 6 && subscriber.length <= 8) {
        return true;
      }
    }
  }
  
  // Check for local format starting with 0 (no country code)
  if (cleanValue.startsWith('0')) {
    const afterTrunk = cleanValue.substring(1); // Remove leading 0
    if (/^(\d{2,4})(\d{6,8})$/.test(afterTrunk)) {
      const areaCode = afterTrunk.match(/^(\d{2,4})\d{6,8}$/)![1];
      const subscriber = afterTrunk.match(/^\d{2,4}(\d{6,8})$/)![1];
      
      // Area code must start with 1-9, subscriber must be 6-8 digits
      return /^[1-9]\d{1,3}$/.test(areaCode) && subscriber.length >= 6 && subscriber.length <= 8;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for obvious gaming names or special symbols that should be rejected
  if (/[0-9Ææ]/.test(value)) {
    return false;
  }
  
  // Unicode property escapes for letters (including accented letters)
  // Allow spaces, apostrophes, and hyphens
  const nameRegex = /^[\p{L}]+(?:[\s'-][\p{L}]+)*$/u;
  
  // Additional check to reject names starting/ending with special characters
  if (/^[\s'-]|[\s'-]$/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Run Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let alternate = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (alternate) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    alternate = !alternate;
  }
  
  return (sum % 10) === 0;
}

/**
 * TODO: Validate credit cards with proper format checking and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanCard = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (cleanCard.length < 13 || cleanCard.length > 19) {
    return false;
  }
  
  // Check for common card type patterns
  let isValidType = false;
  
  // Visa: starts with 4, 13-19 digits
  if (/^4/.test(cleanCard) && cleanCard.length >= 13 && cleanCard.length <= 19) {
    isValidType = true;
  }
  // MasterCard: starts with 51-55 or 2221-2720, 16 digits
  else if ((/^5[1-5]/.test(cleanCard) || /^2[2-7][2-9]\d/.test(cleanCard)) && cleanCard.length === 16) {
    isValidType = true;
  }
  // American Express: starts with 34 or 37, 15 digits
  else if ((/^34/.test(cleanCard) || /^37/.test(cleanCard)) && cleanCard.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanCard);
}
