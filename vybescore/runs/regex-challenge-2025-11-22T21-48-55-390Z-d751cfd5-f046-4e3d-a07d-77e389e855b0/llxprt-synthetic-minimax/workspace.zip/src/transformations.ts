/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences by finding sentence terminators (.?!)
  // This regex captures the terminator as well to preserve it
  const sentenceRegex = /([.!?])(?:\s*)/g;
  
  let result = '';
  let lastIndex = 0;
  let match;
  
  while ((match = sentenceRegex.exec(text)) !== null) {
    // Get the sentence content up to and including the terminator
    const sentence = text.substring(lastIndex, match.index + match[1].length);
    
    // Capitalize the first letter of the sentence
    const capitalizedSentence = sentence.replace(/^([.!?]*\s*)([a-z])/, (match, prefix, letter) => {
      return prefix + letter.toUpperCase();
    });
    
    result += capitalizedSentence;
    lastIndex = match.index + match[1].length;
  }
  
  // Handle the last sentence (if any)
  if (lastIndex < text.length) {
    const remainingText = text.substring(lastIndex);
    const capitalizedRemaining = remainingText.replace(/^([.!?]*\s*)([a-z])/, (match, prefix, letter) => {
      return prefix + letter.toUpperCase();
    });
    result += capitalizedRemaining;
  }
  
  // Ensure proper spacing after sentence terminators
  result = result.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Clean up multiple spaces
  result = result.replace(/\s+/g, ' ');
  
  return result;
}

/**
 * TODO: Extract all URLs from the given text.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /\bhttps?:\/\/[^\s<>"']+/g;
  return text.match(urlRegex) || [];
}

/**
 * TODO: Replace http:// with https://.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Match http URLs (not https) - we don't want to process existing https URLs
  
  return text.replace(httpUrlRegex, (match, domain, path) => {
    // Check if path contains dynamic hints
    const hasDynamicHints = /(\?|&|=)|(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py|cgi-bin)/i.test(path);
    
    // Check if path begins with /docs/
    const beginsWithDocs = /^\/docs\//.test(path);
    
    if (beginsWithDocs && !hasDynamicHints) {
      // Replace domain with docs.domain and upgrade to https
      const docsDomain = `docs.${domain}`;
      return `https://${docsDomain}${path}`;
    } else {
      // Just upgrade to https
      return `https://${domain}${path}`;
    }
  });
}

/**
 * TODO: Extract year from mm/dd/yyyy format.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}