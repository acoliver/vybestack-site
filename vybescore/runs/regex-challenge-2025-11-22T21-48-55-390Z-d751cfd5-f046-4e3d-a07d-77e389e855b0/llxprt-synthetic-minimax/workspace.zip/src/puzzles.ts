/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with the prefix
  const wordRegex = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  return matches.filter(word => !exceptionsSet.has(word.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences where token is preceded by a digit and not at the start of string
  const regex = new RegExp(`(\\d)${escapedToken}`, 'g');
  const matches = [];
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    matches.push(match[0]); // This includes the digit + token
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check at least one symbol
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, cdcd, 1212, etc.)
  // This matches any 2-character pattern followed immediately by the same pattern
  if (/([A-Za-z0-9]{2})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, ensure there are no IPv4 addresses (basic check)
  if (/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/.test(value)) {
    return false;
  }
  
  // IPv6 addresses can be in various forms:
  // 1. Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // 2. Compressed IPv6 with :: shorthand
  // 3. IPv4-mapped IPv6: ::ffff:192.0.2.1
  
  // Full IPv6 (8 groups)
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand (handles various positions of ::)
  // This regex handles :: as representing 1-7 groups of zeros
  const shorthandIPv6 = /\b[0-9a-fA-F]{0,4}:(?::[0-9a-fA-F]{0,4}){1,7}\b|\b(?::[0-9a-fA-F]{0,4}){1,7}:[0-9a-fA-F]{0,4}\b|\b::\b/;
  
  // IPv6 loopback ::1
  const loopback = /\b::1\b/;
  
  // IPv4-mapped IPv6 addresses
  const ipv4MappedIPv6 = /\b::ffff:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  return fullIPv6.test(value) || 
         shorthandIPv6.test(value) || 
         loopback.test(value) || 
         ipv4MappedIPv6.test(value);
}