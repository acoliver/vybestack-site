import re

with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix the double backslashes in the regex 
pattern = r'const httpUrlRegex = /\\\\\\\\bhttp:\\\\\\\\/\\\\\\\\/([^\\\\\\\\/\\\\\\\\s]+)(\\\\\\\\/[^\\\\\\\\s<>\\\"\\'*)]/gi;'
replacement = r'const httpUrlRegex = /\\bhttp:\/\/([^\/\s]+)(\/[^\s<>"']*)/gi;'

new_content = content.replace('const httpUrlRegex = /\\\\bhttp:\\\\/\\\\/([^\\\\/\\\\s]+)(\\\\/[^\\\\s<>\\\"\\'*)]/gi;', 'const httpUrlRegex = /\\bhttp:\/\/([^\/\s]+)(\/[^\s<>"']*)/gi;')

with open('src/transformations.ts', 'w') as f:
    f.write(new_content)

print("Fixed the regex!")
