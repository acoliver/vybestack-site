with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Replace the problematic line with single backslashes
old_line = 'const httpUrlRegex = /\\\\bhttp:\\\\/\\\\/([^\\\\/\\\\s]+)(\\\\/[^\\\\s<>\\\"\\'*)]/gi;'
new_line = 'const httpUrlRegex = /\\bhttp:\/\/([^\/\s]+)(\/[^\s<>"']*)/gi;'

content = content.replace(old_line, new_line)

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed!")
