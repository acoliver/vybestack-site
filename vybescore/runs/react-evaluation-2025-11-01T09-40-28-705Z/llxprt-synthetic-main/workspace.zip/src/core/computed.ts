/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Track dependencies and ensure we don't compute multiple times
  let computing = false
  
  // Create the computed observer
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T): T => {
      if (computing) {
        // Return the current value to avoid recursion
        return o.value || prevValue || (value as T)
      }
      
      computing = true
      try {
        const result = updateFn(prevValue)
        o.value = result
        return result
      } finally {
        computing = false
      }
    }
  }
  
  // Return getter function
  const getter: GetterFn<T> = () => {
    // If there's an active observer, register this computed as a dependency
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      o.observer = activeObserver
    }
    
    // Only compute if not already computing
    if (!computing) {
      computing = true
      try {
        o.value = updateFn(o.value)
      } finally {
        computing = false
      }
    }
    
    return o.value!
  }
  
  return getter
}