/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // This function capitalizes the first character of each sentence
  // and ensures there's exactly one space between sentences
  
  // Split the text by periods, question marks, and exclamation marks
  // but preserve the punctuation
  const sentences = text.split(/([.?!])/);
  
  let result = '';
  let isStartOfSentence = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    // If this is punctuation, just append it
    if (part === '.' || part === '?' || part === '!') {
      result += part;
      // Next character should be capitalized
      isStartOfSentence = true;
    } 
    // If this is content, handle it
    else if (part.length > 0) {
      // Add space after punctuation if needed
      if (result.length > 0 && !isStartOfSentence) {
        continue; // Skip if we're in the middle of handling punctuation
      }
      
      // Handle the content part
      let content = part;
      
      // If we're at the start of a sentence and there's content
      if (isStartOfSentence && content.trim()) {
        // Find the first letter in the content
        const firstLetter = content.search(/[a-zA-Z]/);
        
        if (firstLetter !== -1) {
          content = content.substring(0, firstLetter) + 
                   content.substring(firstLetter, firstLetter + 1).toUpperCase() + 
                   content.substring(firstLetter + 1);
          isStartOfSentence = false;
        }
      }
      
      // Add the content to the result
      result += content;
      
      // If this is the last part and it doesn't end with punctuation, we're not at the start
      if (i === sentences.length - 1 && content.trim() && !['.', '!', '?'].includes(content[content.length - 1])) {
        isStartOfSentence = false;
      }
    }
  }
  
  // Now, ensure there's exactly one space between sentences
  // while preserving abbreviations when possible
  
  // List of common abbreviations to handle
  const abbreviations = ['Mr.', 'Mrs.', 'Dr.', 'Ms.', 'Prof.', 'St.', 'Ave.', 'Rd.', 'Blvd.', 'etc.', 'e.g.', 'i.e.'];
  
  // For each abbreviation, temporarily replace it to protect it
  let protectedText = result;
  abbreviations.forEach(abbrev => {
    const regex = new RegExp(abbrev.replace('.', '\\.'), 'g');
    protectedText = protectedText.replace(regex, abbrev.replace('.', '##PERIOD##'));
  });
  
  // Replace multiple spaces with a single space
  protectedText = protectedText.replace(/\s+/g, ' ');
  
  // Restore the abbreviations
  protectedText = protectedText.replace(/##PERIOD##/g, '.');
  
  // Fix spacing around punctuation
  protectedText = protectedText.replace(/\s+([.!?])/g, '$1'); // Remove space before punctuation
  protectedText = protectedText.replace(/([.!?])\s*/g, '$1 '); // Add one space after punctuation

  // Clean up any trailing space at the beginning or end
  protectedText = protectedText.replace(/^\s+|\s+$/g, '');
  
  return protectedText;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // This regex pattern matches URLs:
  // - Protocol: http://, https://, ftp://, etc.
  // - Optional www.
  // - Domain name with subdomains
  // - Optional port
  // - Path, query string, and fragment
  
  // Remove trailing punctuation from the URLs
  const urlRegex = /(https?:\/\/|ftp:\/\/)[^\s<>"']+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(\/[^\s<>"']*)?/g;
  
  // Find all potential URLs
  const matches = text.match(urlRegex) || [];
  
  // Clean up each match by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.!?;:,]+$/g, '');
  });
  
  // Filter out false positives (like file extensions without a domain)
  return cleanedUrls.filter(url => {
    // Must have at least one dot in the domain
    if (!url.includes('.')) return false;
    
    // Must not have spaces
    if (url.includes(' ')) return false;
    
    // Must not end with a dot
    if (url.endsWith('.')) return false;
    
    // If it doesn't start with a protocol, check if it looks like a domain
    if (!url.startsWith('http://') && !url.startsWith('https://') && !url.startsWith('ftp://')) {
      // Look for common TLD patterns
      const domainPattern = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}([/][a-zA-Z0-9.-/_?=&#%]*)?$/;
      return domainPattern.test(url);
    }
    
    return true;
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Regex to match URLs with different protocols and patterns
  const urlPattern = /(http:\/\/)[^\s"'>]+|https:\/\/[^\s"'>]+|ftp:\/\/[^\s"'>]+/g;
  
  return text.replace(urlPattern, (match) => {
    // If it's already https, return as is
    if (match.startsWith('https://') || match.startsWith('https://')) {
      return match;
    }
    
    // If it's http, replace with https
    if (match.startsWith('http://')) {
      return match.replace('http://', 'https://');
    }
    
    // For other protocols (like ftp), leave as is
    return match;
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // This function rewrites URLs from http://example.com/... to https://...
  // and moves docs paths to docs.example.com
  
  // Pattern to match URLs with http://example.com
  const urlPattern = /(http:\/\/example\.com\/[^\s"'>]+)/g;
  
  return text.replace(urlPattern, (match) => {
    // Parse the URL to extract the path
    const url = new URL(match);
    const pathname = url.pathname;
    
    // Determine if we should rewrite the host
    let shouldRewriteHost = false;
    let newPathname = pathname;
    
    // Check if the path starts with /docs/
    if (pathname.startsWith('/docs/')) {
      // Check if path contains dynamic hints that would skip host rewrite
      const hasDynamicHints = pathname.includes('cgi-bin') || 
                              pathname.includes('?') || 
                              pathname.includes('&') || 
                              pathname.includes('=') ||
                              pathname.endsWith('.jsp') ||
                              pathname.endsWith('.php') ||
                              pathname.endsWith('.asp') ||
                              pathname.endsWith('.aspx') ||
                              pathname.endsWith('.do') ||
                              pathname.endsWith('.cgi') ||
                              pathname.endsWith('.pl') ||
                              pathname.endsWith('.py');
      
      // Only rewrite the host if no dynamic hints are found
      if (!hasDynamicHints) {
        shouldRewriteHost = true;
        newPathname = pathname.replace('/docs/', '/docs/');
      }
    }
    
    // Always upgrade to https
    const protocol = 'https://';
    
    // Determine the host
    const host = shouldRewriteHost ? 'docs.example.com' : url.host;
    
    // Construct the new URL
    return `${protocol}${host}${newPathname}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Use regex to match the mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/\d{4}$/;
  
  if (!datePattern.test(value)) {
    return 'N/A';
  }
  
  // Extract the year part
  const yearMatch = value.match(/^(?:0[1-9]|1[0-2])\/(?:0[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (yearMatch && yearMatch[1]) {
    return yearMatch[1];
  }
  
  return 'N/A';
}
