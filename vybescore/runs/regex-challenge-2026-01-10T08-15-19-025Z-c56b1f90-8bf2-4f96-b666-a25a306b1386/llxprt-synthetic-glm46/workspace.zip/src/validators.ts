export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // Rules:
  // - Local part can contain letters, digits, +, -, . (but no consecutive dots or leading/trailing dots)
  // - Domain part can contain letters, digits, hyphens (but no underscores)
  // - TLD must be at least 2 characters
  // - Support subdomains and country codes
  const emailRegex = /^[a-zA-Z0-9]+([a-zA-Z0-9+._-]*[a-zA-Z0-9]+)?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Quick check for consecutive dots
  if (/\.\./.test(value)) {
    return false;
  }
  
  // Quick check for leading or trailing dot in local part
  const atIndex = value.indexOf('@');
  if (atIndex > 0 && (value[0] === '.' || value[atIndex - 1] === '.')) {
    return false;
  }
  
  // Check for underscore in domain part
  const domainPart = value.slice(atIndex + 1);
  if (domainPart.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-numeric characters (except +)
  const cleaned = value.replace(/[^0-9+]/g, '');
  
  // Check minimum length (10 digits, with optional +1 prefix)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  const digits = cleaned.startsWith('+1') ? cleaned.slice(2) : cleaned;
  
  // Must be exactly 10 digits after removing country code
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (digits[0] === '0' || digits[0] === '1') {
    return false;
  }
  
  // Optional: Check if extensions are allowed
  if (options?.allowExtensions) {
    // If extensions are allowed, we'll allow the main format but this would need more logic
    // For now, we'll validate the main part only
  }
  
  // Final validation - check if the input matches accepted formats
  // (212) 555-7890, 212-555-7890, 2125557890, +1 (212) 555-7890, etc.
  const phoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)\s?|[2-9]\d{2}[-\s]?)\d{3}[-\s]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens (separators)
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Validation rules:
  // - Optional country code: +54
  // - Optional trunk prefix: 0
  // - Optional mobile indicator: 9
  // - Area code: 2-4 digits, leading digit 1-9
  // - Subscriber number: 6-8 digits
  
  // Handle formats:
  // +54 9 11 1234 5678
  // 011 1234 5678
  // +54 341 123 4567
  // 0341 4234567
  
  // Regex to validate and extract components
  // Fixed to correctly capture area code (2-4 digits) and subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54)?(0?)(9?)(([1-9]\d{1,3}))(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
const countryCode = match[1];
  const trunkPrefix = match[2];
  // Note: mobileIndicator is not used in validation but is captured for completeness
  const areaCode = match[4];
  const subscriberNumber = match[6];
  // When country code is omitted, trunk prefix (0) must be present
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Unicode letters, accents, apostrophes, hyphens, spaces
  // Basic pattern to allow letters (including accented), apostrophes, hyphens, and spaces
  const nameRegex = /^[a-zA-Z\u00C0-\u017F'\-\s]+$/;
  
  // Check for digits (allowed in some Unicode ranges but not in names)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for symbols (excluding apostrophes and hyphens)
  const symbolsRegex = /[!@#$%^&*()+=\\[\]{};:"'<>,.?/|`~0-9]/;
  if (symbolsRegex.test(value)) {
    return false;
  }
  
  // Reject names that are just a single character (unless it's a valid single-letter name)
  if (value.trim().length < 2) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Check if the value contains only digits (after removing spaces and hyphens)
  const digits = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55
  // AmEx: 15 digits, starts with 34 or 37
  
  // Prefix validation
  const visaPrefix = /^4\d{12}(\d{3})?$/;  // 13 or 16 digits
  const mastercardPrefixes = /^5[1-5]\d{14}$/;  // 16 digits
  const amexPrefix = /^3[47]\d{13}$/;  // 15 digits
  
  // Check if the card number matches any of the accepted formats
  return [
    visaPrefix,
    mastercardPrefixes,
    amexPrefix
  ].some(regex => regex.test(digits)) && runLuhnCheck(digits);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(value: string): boolean {
  // Implementation based on standard Luhn algorithm
  // Reverse the digits to start from the rightmost digit
  const digits = value.split('').reverse().map(Number);
  
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let d = digits[i];
    
    // Double every second digit (starting from the second digit from the right)
    if (i % 2 === 1) {
      d = d * 2;
      
      // If doubling makes it two digits, sum the digits (or subtract 9)
      if (d > 9) {
        d = d - 9;
      }
    }
    
    sum += d;
  }
  
  return sum % 10 === 0;
}
