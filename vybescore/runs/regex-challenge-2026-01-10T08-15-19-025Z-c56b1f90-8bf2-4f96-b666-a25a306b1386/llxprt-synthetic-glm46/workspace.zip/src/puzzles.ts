/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  // Negative lookahead to exclude the exceptions
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(exc => exc.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  
  
  
  // Build a negative lookahead pattern from exceptions
  const negativeLookaheadPattern = exceptions.length > 0 
    ? `(?!${escapedExceptions.join('|')})` 
    : '';
  
  // Create the full pattern
  const regexPattern = new RegExp(`\\b${escapedPrefix}${negativeLookaheadPattern}\\w+`, 'g');
  
  // Find all matches
  const textMatches = text.match(regexPattern) || [];
  
  // Return unique matches
  return Array.from(new Set(textMatches));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Include the digit prefix in the result
  const result: string[] = [];
  // Find all full matches including the preceding digits
  const fullMatchPattern = new RegExp(`(?<!^)[0-9]${escapedToken}`, 'g');
  const fullMatches = text.match(fullMatchPattern) || [];
  fullMatches.forEach(fullMatch => {
    if (fullMatch.endsWith(token)) {
      result.push(fullMatch);
    }
  });
  
  return result;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Password strength requirements:
  // - At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // - One uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // - One lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // - One digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // - One symbol
  if (!/[!@#$%^&*()+=\\[\]{};':"'<>,.?/|`~]/.test(value)) {
    return false;
  }
  
  // - No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // - No immediate repeated sequences (e.g., abab should fail)
  // Check for repeated sequences of length 2 or more
  for (let seqLength = 2; seqLength <= value.length / 2; seqLength++) {
    for (let i = 0; i <= value.length - seqLength * 2; i++) {
      const sequence = value.substring(i, i + seqLength);
      const repeatedSequence = value.substring(i + seqLength, i + seqLength * 2);
      
      if (sequence === repeatedSequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if there's an IPv4 address
  const ipv4Pattern = /\b\d{1,3}(?:\.\d{1,3}){3}\b/;
  if (ipv4Pattern.test(value)) {
    // If we find an IPv4 address but also find an IPv6 address, it might be an IPv6 with IPv4 at the end
    // So we'll continue checking for IPv6 before returning false
  }
  
  // IPv6 patterns (including shorthand)
  
  // Full IPv8 pattern with all 8 groups
  const ipv6FullPattern = /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with trailing :: (e.g., 2001:db8::)
  const ipv6TrailingShorthandPattern = /\b([0-9a-fA-F]{1,4}:){1,7}:\b/;
  
  // IPv6 with leading :: (e.g., ::1)
  const ipv6LeadingShorthandPattern = /\b:(?::[0-9a-fA-F]{1,4}){1,7}\b/;
  
  // IPv6 with :: in the middle (e.g., 2001::fffe)
  const ipv6MiddleShorthandPattern = /\b([0-9a-fA-F]{1,4}:){0,6}:[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: (double colon) anywhere
  const ipv6DoubleColonPattern = /\b[0-9a-fA-F]{0,4}::[0-9a-fA-F]{0,4}\b/;
  
  // IPv6 with IPv4 at the end (e.g., ::ffff:192.168.1.1)
  const ipv6WithIPv4Pattern = /\b([0-9a-fA-F]{1,4}:){1,7}:\d{1,3}(?:\.\d{1,3}){3}\b/;
  
  // Check if any IPv6 pattern matches
  const hasIPv6 = [
    ipv6FullPattern,
    ipv6TrailingShorthandPattern,
    ipv6LeadingShorthandPattern,
    ipv6MiddleShorthandPattern,
    ipv6DoubleColonPattern,
    ipv6WithIPv4Pattern
  ].some(pattern => pattern.test(value));
  
  return hasIPv6;
}
