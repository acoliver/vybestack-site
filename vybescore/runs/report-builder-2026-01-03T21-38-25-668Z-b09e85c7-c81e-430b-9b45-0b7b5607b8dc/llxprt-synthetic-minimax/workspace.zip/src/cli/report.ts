import { readFileSync } from 'node:fs';
import { createWriteStream } from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, CliOptions } from '../types.js';

function parseArguments(argv: string[]): CliOptions {
  const args = argv.slice(2); // Skip node and script name
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  let format: CliOptions['format'] | null = null;
  let output: string | undefined;
  let includeTotals = false;
  
  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const formatValue = args[i + 1];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error('Error: Unsupported format');
        process.exit(1);
      }
      format = formatValue;
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      output = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
      i += 1;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return {
    dataPath,
    format,
    output,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }
  
  const report = data as ReportData;
  
  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }
  
  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }
  
  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }
  
  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: "entries[${i}]" must be an object`);
    }
    
    if (typeof entry.label !== 'string') {
      throw new Error(`Invalid JSON: "entries[${i}].label" must be a string`);
    }
    
    if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
      throw new Error(`Invalid JSON: "entries[${i}].amount" must be a number`);
    }
  }
  
  return report;
}

function readAndParseJson(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File not found: ${filePath}`);
      } else if (error.message.includes('JSON')) {
        console.error(error.message);
      } else {
        console.error(`Error reading file: ${error.message}`);
      }
    } else {
      console.error('Error: Unknown error reading file');
    }
    process.exit(1);
  }
}

function renderReport(report: ReportData, format: CliOptions['format'], includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(report, includeTotals);
    case 'text':
      return renderText(report, includeTotals);
    default:
      throw new Error('Unsupported format');
  }
}

function outputResult(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      const stream = createWriteStream(outputPath);
      stream.write(content);
      stream.end();
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error writing output file: ${error.message}`);
      } else {
        console.error('Error: Unknown error writing output file');
      }
      process.exit(1);
    }
  } else {
    process.stdout.write(content);
  }
}

function main(): void {
  const options = parseArguments(process.argv);
  const report = readAndParseJson(options.dataPath);
  
  try {
    const content = renderReport(report, options.format, options.includeTotals);
    outputResult(content, options.output);
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('Error: Unknown error rendering report');
    }
    process.exit(1);
  }
}

main();
