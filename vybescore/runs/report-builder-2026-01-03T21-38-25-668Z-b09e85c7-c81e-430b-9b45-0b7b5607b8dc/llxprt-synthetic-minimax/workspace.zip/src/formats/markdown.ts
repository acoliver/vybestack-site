import { ReportData } from '../types.js';

function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function renderMarkdown(report: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  lines.push(`# ${report.title}`);
  lines.push('');
  
  lines.push(report.summary);
  lines.push('');
  
  lines.push('## Entries');
  
  for (const entry of report.entries) {
    lines.push(`- **${entry.label}** — ${formatCurrency(entry.amount)}`);
  }
  
  if (includeTotals) {
    const total = report.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push('');
    lines.push(`**Total:** ${formatCurrency(total)}`);
  }
  
  return lines.join('\n');
}