export default {
  test: {
    include: ['tests/**/*.spec.ts'],
    environment: 'node',
    globals: true
  }
};