/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, we need to identify sentence boundaries (., ?, !)
  // Then capitalize the first letter after each boundary
  // Insert exactly one space between sentences
  
  return text
    // Convert multiple spaces to single space
    .replace(/\s+/g, ' ')
    // Ensure single space after punctuation
    .replace(/([.?!])(?=[^\s])/g, '$1 ')
    // Capitalize first letter after sentence boundaries
    .replace(/(^|[.?!]\s+)([a-z])/g, (_, p1, p2) => `${p1}${p2.toUpperCase()}`)
    // Capitalize first character of the whole string
    .replace(/^[a-z]/, c => c.toUpperCase())
    .trim(); // Remove leading/trailing whitespace
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs starting with http, https, www
  // Allow domain paths, query strings, fragments, etc.
  // Exclude trailing punctuation
  const urlRegex = /\b(?:https?:\/\/|www\.)(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?\b/g;
  
  const urls = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return urls.map(url => url.replace(/[.,;:!?]+$/g, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all occurrences of "http://" with "https://"
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Match all HTTP URLs with optional paths and query strings
  // Extract host and path components for transformation
  return text.replace(/http:\/\/([a-zA-Z0-9-.]+)(\/[^?\s]*)?/g, (match, host, path = '') => {
    // Always upgrade to HTTPS
    const result = `https://${host}${path}`;
    
    // Only rewrite docs.example.com if:
    // 1. Path starts with /docs/
    // 2. Path does NOT contain cgi-bin
    // 3. Path does NOT contain query strings
    // 4. Path does NOT contain legacy extensions
    
    if (path && path.startsWith('/docs/')) {
      // Check for exclusion patterns
      const hasDynamicHints = path.includes('cgi-bin') || 
                             /[?&=]/.test(path) || 
                             /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com while preserving path
        return `https://docs.${host}${path}`;
      }
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy pattern
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Year is captured as a string
  
  // Validate month and day
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Maximum days for each month
  const maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = month === 2 && leapYear(parseInt(year, 10)) ? 29 : maxDays[month - 1];
  
  if (day < 1 || day > maxDay) {
    return 'N/A';
  }
  
  return year;
}

// Helper function to check for leap year
function leapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}
