export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that accepts typical addresses with plus tags, 
  // rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/i;

  // First check if it matches general email pattern
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for specific requirements
  // Check for double dots in local or domain
  if (value.includes('..')) {
    return false;
  }

  // Check for underscores in domain
  const domainPart = value.split('@')[1];
  if (domainPart?.includes('_')) {
    return false;
  }

  // Check for trailing or leading dots
  if (value.startsWith('.') || value.endsWith('.')) {
    return false;
  }

  // Check for consecutive dots after @
  const afterAt = value.substring(value.indexOf('@'));
  if (afterAt?.includes('..')) {
    return false;
  }

  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove spaces, hyphens, parentheses for validation
  const cleaned = value.replace(/[\s-()]/g, '');
  
  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  }
  
  // 10 digits minimum for US numbers
  if (digits.length !== 10 || !/^\d+$/.test(digits)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Disallow impossible area codes (leading 0 or 1)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Final regex pattern for complete validation
  const usPhonePattern = /^(\+1[\s-]?)?(\([2-9]\d{2}\)[\s-]?|[2-9]\d{2}[\s-]?)\d{3}[\s-]?\d{4}$/;
  
  return usPhonePattern.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex pattern:
  // ^(\+54)? - Optional country code
  // 0? - Optional trunk prefix
  // 9? - Optional mobile indicator
  // [1-9]\d{1,3} - Area code (2-4 digits, starting with 1-9)
  // \d{6,8}$ - Subscriber number (6-8 digits)
  const argentinePhonePattern = /^(\+54)?(0)?(9)?([1-9]\d{1,3})\d{6,8}$/;
  
  if (!argentinePhonePattern.test(cleaned)) {
    return false;
  }
  
  // If no country code, must begin with trunk prefix 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  // Extract groups to validate
  const match = cleaned.match(argentinePhonePattern);
  if (!match) return false;
  
  const countryCode = match[1]; // +54 or undefined
  const trunkPrefix = match[2]; // 0 or undefined
  const mobileIndicator = match[3]; // 9 or undefined
  const areaCode = match[4]; // Area code e.g. 11, 341, etc
  const subscriberNumber = cleaned.substring(areaCode.length + 
    (trunkPrefix?.length || 0) + 
    (mobileIndicator?.length || 0) + 
    (countryCode?.length || 0));
  
  // Area code must be 2-4 digits with leading digit 1-9 (already enforced in regex)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits (already enforced in regex)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name validation regex:
  // ^[\\p{L}\\p{M}]+ - Unicode letters and marks (for accents)
  // (['\\-\\s][\\p{L}\\p{M}]+)*$ - Apostrophes, hyphens, or spaces followed by letters
  const namePattern = /^[\p{L}\p{M}]+(['\-\s][\p{L}\p{M}]+)*$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Ensure no digits are present
  if (/\d/.test(value)) {
    return false;
  }
  
  // Ensure no disallowed symbols like æ, X Æ A-12 style
  const disallowedSymbols = /[&$%*#@<>[\]{}~=+|]/g;
  if (disallowedSymbols.test(value)) {
    return false;
  }
  
  // Ensure no multiple consecutive separators
  if (/['\-]{2,}/.test(value) || /\s{2,}/.test(value)) {
    return false;
  }
  
  // Ensure no leading or trailing separators
  if (/^['\-\s]|['\-\s]$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove any non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check basic length requirements
  if (digits.length < 13 || digits.length > 16) {
    return false;
  }
  
  // Credit card patterns:
  // Visa: 4, 13 or 16 digits
  // Mastercard: 51-55, 2221-2720, 16 digits
  // AmEx: 34 or 37, 15 digits
  const visaPattern = /^4(\d{12}|\d{15})$/;
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check if digits match any valid card pattern
  const matchesPattern = 
    visaPattern.test(digits) ||
    mastercardPattern.test(digits) ||
    amexPattern.test(digits);
  
  if (!matchesPattern) {
    return false;
  }
  
  // Run Luhn checksum.
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}