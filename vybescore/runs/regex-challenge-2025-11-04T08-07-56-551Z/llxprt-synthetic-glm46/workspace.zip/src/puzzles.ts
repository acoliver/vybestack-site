/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to match words with the given prefix
  // \b ensures we match whole words
  const prefixPattern = new RegExp(`\\b${prefix}[a-zA-Z]+`, 'g');
  
  // Find all matches
  const allMatches = text.match(prefixPattern) || [];
  
  // Filter out exceptions
  return allMatches
    .map(word => word.toLowerCase())
    .filter(word => !exceptions.includes(word))
    // Remove duplicates
    .filter((word, index, arr) => arr.indexOf(word) === index);
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find token after digits but not at start of string
  // Use lookahead/lookbehind approach without lookbehind (for compatibility)
  const pattern = new RegExp(`(\\d)(${token})`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Ensure we're not at the start of the string
    if (match.index > 0) {
      matches.push(match[1] + match[2]); // Return the digit + token
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric character)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212, abcabc)
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment = value.substring(i, i + len);
      const nextSegment = value.substring(i + len, i + len * 2);
      if (segment === nextSegment) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns:
  // Standard format: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // With shorthand (:: to replace zeros)
  // With compressed sections
  // With IPv4 embedded: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxx.xxx.xxx.xxx
  
  const ipv4Pattern = /^\d+\.\d+\.\d+\.\d+$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 pattern - simplified but effective for common formats
  // Match 8 hexadecimal groups separated by colons, with shorthand support
  const ipv6Regex = [
    // Standard format
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // Trailing :: and compressed format
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b/,
    // Leading :: and compressed format
    /\b:(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b/,
    // Embedded IPv4
    /\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}\b/
  ];
  
  for (const pattern of ipv6Regex) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}