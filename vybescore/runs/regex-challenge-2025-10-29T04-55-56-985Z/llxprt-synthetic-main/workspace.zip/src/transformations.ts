/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // If empty or no content to capitalize
  if (!text || text.trim() === '') return text;
  
  // Split text at sentence boundaries while keeping the delimiter
  let result = text;
  
  // Step 1: Reduce multiple spaces to a single space
  result = result.replace(/\s+/g, ' ');
  
  // Step 2: Capitalize sentences
  // First, capitalize the very first character
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Then, capitalize after each sentence delimiter
  result = result.replace(/([.!?])\s*([a-z])/g, (match, delimiter, letter) => {
    return delimiter + ' ' + letter.toUpperCase();
  });
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex pattern to match URLs
  // Matches http(s):// plus domain and optional path
  const urlRegex = /\bhttps?:\/\/[^\s/$.?#].[^\s]*\b/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => url.replace(/[.,;:'")\]\}]+$/g, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http to https
  return text.replace(/\bhttp:\/\/(example\.com(?:\/(?:docs\/[^\s]*)?))\b/g, (match, urlPath) => {
    // Check if this is a docs path that should be rewritten
    // Skip if path contains dynamic hints or legacy extensions
    const hasDynamicOrLegacy = /(?:cgi-bin|[\?&=]|(?:\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py))/i;
    
    if (urlPath.includes('/docs/') && !hasDynamicOrLegacy.test(urlPath)) {
      // Replace the host with docs.example.com
      const pathWithoutHost = urlPath.substring('example.com'.length);
      return `https://docs.example.com${pathWithoutHost}`;
    } else {
      // Just upgrade to https
      return `https://${urlPath}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day based on month (basic validation)
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (simplified)
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0);
  const maxDay = month === 2 && isLeapYear ? 29 : daysInMonth[month];
  
  if (day > maxDay) return 'N/A';
  
  return year;
}
