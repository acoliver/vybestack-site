/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex to match words starting with the prefix
  const regex = new RegExp(`\\b${prefix}[a-zA-Z]+\\b`, 'g');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(ex => ex.toLowerCase() === word.toLowerCase())
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use lookbehind to find token preceded by a digit
  // Include the digit in the result
  const regex = new RegExp(`(\\d${token})`, 'g');
  
  return text.match(regex) || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Password must:
  // - Be at least 10 characters
  // - Contain at least one uppercase letter
  // - Contain at least one lowercase letter
  // - Contain at least one digit
  // - Contain at least one symbol
  // - Not contain whitespace
  // - Not contain immediate repeated sequences (e.g., abab)
  
  if (value.length < 10) return false;
  
  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);
  const hasWhitespace = /\s/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol || hasWhitespace) return false;
  
  // Check for repeated sequences like abab
  for (let i = 0; i < value.length - 3; i++) {
    if (value.charAt(i) === value.charAt(i + 2) && 
        value.charAt(i + 1) === value.charAt(i + 3)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern
  // Matches various IPv6 formats including shorthand with ::
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/g;
  
  // IPv4 regex pattern (to exclude)
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
  
  // Check for IPv6 addresses
  const ipv6Matches = value.match(ipv6Regex);
  if (!ipv6Matches) return false;
  
  // Filter out any matches that are actually IPv4 addresses
  for (const match of ipv6Matches) {
    if (!ipv4Regex.test(match)) {
      return true;
    }
  }
  
  return false;
}
