export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for double dots in the email
  if (value.includes('..')) return false;
  
  // Check for leading dot in local part
  if (value.startsWith('.') || value.includes('.@')) return false;
  
  // Standard email validation regex - more permissive
  const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must be at least 10 digits (basic US number)
  if (digitsOnly.length < 10) return false;
  
  // Check for optional +1 country code
  let centralDigits = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    centralDigits = digitsOnly.substring(1);
  } else if (digitsOnly.length > 10) {
    // If longer than 11 digits, it's invalid
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (centralDigits[0] === '0' || centralDigits[0] === '1') return false;
  
  // Check if the original format matches common US phone patterns
  const usPhoneRegex = /^(?:\+1[\s-]?)?(\(?([2-9]\d{2})\)?[\s-]?)([2-9]\d{2})[\s-]?(\d{4})$/;
  return usPhoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex:
  // ^\+?54?      - Optional country code
  // 9?           - Optional mobile indicator
  // 0?           - Optional trunk prefix
  // [1-9]\d{1,3} - Area code (2-4 digits, can't start with 0)
  // \d{6,8}      - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?9?0?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(normalized)) return false;
  
  const match = normalized.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // If no country code, ensure it starts with trunk prefix 0
  if (!normalized.startsWith('+54') && !value.startsWith('0')) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and names like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}’'\-\s]+$/u;
  
  // Check for digits (which would make it invalid)
  if (/\d/.test(value)) return false;
  
  return nameRegex.test(value) && value.trim().length > 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const digitsOnly = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(digitsOnly)) return false;
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  
  const visaRegex = /^4(?:\d{12}|\d{15})$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const validFormat = visaRegex.test(digitsOnly) || mastercardRegex.test(digitsOnly) || amexRegex.test(digitsOnly);
  
  if (!validFormat) return false;
  
  // Luhn algorithm
  let sum = 0;
  let isEven = false;
  
  for (let i = digitsOnly.length - 1; i >= 0; i--) {
    let digit = parseInt(digitsOnly[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
