#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFileSync } from 'node:fs';
import type { ReportData } from '../types.js';
import { renderReport } from '../formats/index.js';

type ParsedArgs = {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
};

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[2];
  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = args[++i];
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a path');
          process.exit(1);
        }
        outputPath = args[++i];
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument ${args[i]}`);
        process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries array');
  }

  const entries = obj.entries.map((entry: unknown, index: number) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${index} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} has invalid label`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} has invalid amount`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

function main(): void {
  try {
    const args = parseArgs(process.argv);

    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(args.inputFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file ${args.inputFile}: ${error.message}`);
      } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error(`Error: File not found: ${args.inputFile}`);
      } else {
        console.error(`Error reading file ${args.inputFile}: ${error}`);
      }
      process.exit(1);
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Render report
    const output = renderReport(reportData, args.format, { includeTotals: args.includeTotals });

    // Write output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error writing to file ${args.outputPath}: ${error}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error}`);
    process.exit(1);
  }
}

main();