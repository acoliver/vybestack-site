import type { ReportData, ReportRenderer, RenderOptions } from '../types.js';
import { markdownRenderer } from './markdown.js';
import { textRenderer } from './text.js';

export type { ReportData, ReportRenderer, RenderOptions } from '../types.js';
export { markdownRenderer, textRenderer };

export const renderers: Record<string, ReportRenderer> = {
  markdown: markdownRenderer,
  text: textRenderer,
};

export function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  const renderer = renderers[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer.render(data, options);
}