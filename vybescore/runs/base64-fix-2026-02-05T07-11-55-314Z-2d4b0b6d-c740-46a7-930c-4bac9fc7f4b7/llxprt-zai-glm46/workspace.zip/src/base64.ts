/**
 * Validate that a string is valid Base64.
 * Uses the canonical Base64 alphabet: A-Z, a-z, 0-9, +, /
 * Accepts optional padding (=) at the end.
 */
function isValidBase64(input: string): boolean {
  if (input.length === 0) {
    return false;
  }

  // Check that the string only contains valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }

  // Check padding is only at the end and correct length
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only be at the end
    const paddingSection = input.slice(paddingIndex);
    if (!/^=+$/.test(paddingSection)) {
      return false;
    }
    // Maximum 2 padding characters
    if (paddingSection.length > 2) {
      return false;
    }
    // Total length including padding must be multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
  } else {
    // Without padding, length must still be valid (can be any length, but when unpadded,
    // we'll let Buffer handle the validation)
  }

  return true;
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding (=) when required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Trim whitespace
  const trimmed = input.trim();

  // Empty string is valid (decodes to empty string)
  if (trimmed.length === 0) {
    return '';
  }

  // Validate the input is valid Base64
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding actually worked (invalid base64 may produce empty buffer)
    // For non-empty input, we should get non-empty output
    if (buffer.length === 0) {
      throw new Error('Failed to decode Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
