#!/bin/bash
# Fix puzzles.ts file lines 71-72

sed -i "71s/.*/  const hasSymbol = \/[!@#\$%\^&\*()_\+=\[\\\] {};':\\\"\\\\|,.<>\\\/\?]\//.test(value);/" src/puzzles.ts
sed -i "72s/.*/  const hasNoWhitespace = !\/\s\/.test(value);/" src/puzzles.ts