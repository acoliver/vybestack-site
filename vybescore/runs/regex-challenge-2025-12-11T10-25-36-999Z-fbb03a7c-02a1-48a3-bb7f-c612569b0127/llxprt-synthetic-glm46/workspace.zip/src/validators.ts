/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // Must include: local part + @ + domain
  // Reject double dots, trailing dots, domains with underscores
  // Accept typical addresses like name+tag@example.co.uk
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
  
  // Must match basic pattern
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check for domain with underscore
  const domainParts = value.split('@');
  if (domainParts.length !== 2) {
    return false;
  }
  
  const domain = domainParts[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Check for consecutive dots in domain
  if (domainParts[1].includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement North American Numbering Plan phone validation.
 */
export function isValidUSPhone(value: string): boolean {
  // Support formats like: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
  // Disallow impossible area codes (leading 0/1) and too short inputs
  
  // Extract digits only
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length
  if (digits.length < 10) {
    return false;
  }
  
  // Standard patterns
  const phonePattern = /^(?:\+?1[\s-]?)?(\(?\d{3}\)?[\s-]?)?\d{3}[\s-]?\d{4}$/;
  
  if (!phonePattern.test(value)) {
    return false;
  }
  
  // Extract area code after removing formatting
  let cleanDigits = digits;
  // Remove leading country code 1 if present
  if (cleanDigits.length > 10 && cleanDigits.startsWith('1')) {
    cleanDigits = cleanDigits.substring(1);
  }
  
  // Check if we have exactly 10 digits now
  if (cleanDigits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = cleanDigits.substring(0, 3);
  
  // Disallow impossible area codes (leading 0 or 1)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Handle Argentine phone formats
  // Examples: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  
  // Remove spaces, hyphens, parentheses for validation
  const clean = value.replace(/[\s\-\(\)]/g, '');
  
  if (!clean) return false;
  
  let workingClean = clean;
  let hasCountryCode = false;
  
  // Check for country code
  if (clean.startsWith('+54')) {
    hasCountryCode = true;
    workingClean = clean.substring(3);
  }
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode) {
    if (!workingClean.startsWith('0')) {
      return false;
    }
  }
  
  // Remove trunk prefix if present
  if (workingClean.startsWith('0')) {
    workingClean = workingClean.substring(1);
  }
  
  // Check for mobile indicator
  if (workingClean.startsWith('9')) {
    workingClean = workingClean.substring(1);
  }
  
  // At this point, workingClean should start with area code
  // Area code must be 2-4 digits, leading digit must be 1-9
  let areaCodeLength = 2;
  
  // Try to find area code length (2-4 digits)
  let areaCodeEndIndex = -1;
  for (let len = 2; len <= 4; len++) {
    if (workingClean.length >= len) {
      const potentialAreaCode = workingClean.substring(0, len);
      if (/^[1-9]\d*$/.test(potentialAreaCode)) {
        areaCodeLength = len;
        areaCodeEndIndex = len;
        break;
      }
    }
  }
  
  if (areaCodeEndIndex === -1) {
    return false;
  }
  
  const areaCode = workingClean.substring(0, areaCodeLength);
  
  // Area code leading digit must be 1-9
  if (!/^[1-9]/.test(areaCode)) {
    return false;
  }
  
  // Extract subscriber number
  const subscriberNumber = workingClean.substring(areaCodeLength);
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement name validation that permits international characters.
 */
export function isValidName(value: string): boolean {
  // Permit unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and X Æ A-12 style names
  
  // Name regex allowing unicode letters, spaces, apostrophes, and hyphens
  const nameRegex = /^[\p{L}\p{M}'\s-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with special symbols (except allowed apostrophes and hyphens)
  const specialSymbolsRegex = /[^\p{L}\p{M}\s'\-.,]/u;
  if (specialSymbolsRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement credit card validation with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Accept Visa/Mastercard/AmEx prefixes and lengths
  // Run a Luhn checksum
  
  // Remove spaces and dashes
  const clean = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(clean)) {
    return false;
  }
  
  // Check Visa (starts with 4, 13 or 16 digits)
  if (clean.length === 13 && clean.startsWith('4')) {
    return runLuhnCheck(clean);
  }
  
  if (clean.length === 16 && clean.startsWith('4')) {
    return runLuhnCheck(clean);
  }
  
  // Check Mastercard (starts with 51-55 or 2221-2720, 16 digits)
  if (clean.length === 16) {
    // 51-55 range
    if (/^5[1-5]/.test(clean)) {
      return runLuhnCheck(clean);
    }
    // 2221-2720 range
    if (/^2[2-7]\d/.test(clean)) {
      return runLuhnCheck(clean);
    }
  }
  
  // Check AmEx (starts with 34 or 37, 15 digits)
  if (clean.length === 15 && (clean.startsWith('34') || clean.startsWith('37'))) {
    return runLuhnCheck(clean);
  }
  
  return false;
}

/**
 * Helper function to run Luhn checksum
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return (sum % 10) === 0;
}