/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  
// Create a set for faster exception lookup
  const exceptionSet = new Set(exceptions);
  
  // Use word boundary pattern to find words with the prefix
  const words = text.match(new RegExp(`\\b${escapeRegex(prefix)}[a-zA-Z]*\\b`, 'g')) || [];
  
  return words.filter(word => !exceptionSet.has(word));
}

// Helper function to escape special regex characters in the prefix
function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]]/g, '\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Return occurrences where the token appears after a digit and not at the start of the string
  // Use lookaheads/lookbehinds  
  
  // Pattern to match token preceded by a digit, capture both digit and token
  const findAfterDigit = new RegExp(String.raw`(\d)(${escapeRegex(token)})`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = findAfterDigit.exec(text)) !== null) {
    // Combine captured digit and token for expected output format
    matches.push(match[1] + match[2]);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol
  // No whitespace, no immediate repeated sequences
  
  // Length check
  if (value.length < 10) {
    return false;
  }
const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  
  // Character type checks
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);
  const hasNoWhitespace = !/\s/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol || !hasNoWhitespace) {
    return false;
  }
  
  // Check for immediate repeated sequences
  const repeatedPattern = /(.{2,})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) excluding IPv4 addresses
  
  // IPv4 pattern to exclude
  const ipv4Pattern = /\bd{1,3}(?:\.d{1,3}){3}\b/;
  
  // IPv6 patterns
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const ipv6FullPattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: abbreviation
  const ipv6WithShorthandPattern = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: at start or end
  const ipv6WithShorthandAtEndsPattern = /\b::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4})*\b|\b(?:[0-9a-fA-F]{1,4}:)*::\b/;
  
  // Check for IPv4 first - if found, this is not IPv6
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Check for IPv6 patterns
  return (
    ipv6FullPattern.test(value) ||
    ipv6WithShorthandPattern.test(value) ||
    ipv6WithShorthandAtEndsPattern.test(value)
  );
}
