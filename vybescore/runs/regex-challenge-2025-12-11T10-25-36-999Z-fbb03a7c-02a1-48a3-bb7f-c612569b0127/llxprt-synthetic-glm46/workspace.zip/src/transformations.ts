/**
 * Sentence capitalization utility
 */
export function capitalizeSentences(text: string): string {
  // Capitalize first character of each sentence, insert exactly one space between sentences
  // Collapse extra spaces while leaving abbreviations intact when possible
  
  // Split by sentence endings
  const sentences = text.split(/([.?!]+)/);
  
  let result = '';
  let isNewSentence = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i].trim();
    
    if (part.match(/[.?!]+/)) {
      // Sentence ending punctuation
      result += part + ' ';
      isNewSentence = true;
    } else if (part.length > 0) {
      // Regular text content
      if (isNewSentence) {
        result += part.charAt(0).toUpperCase() + part.slice(1);
        isNewSentence = false;
      } else {
        result += part;
      }
    }
  }
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Return all URLs detected in the text without trailing punctuation
  
  const urlPattern = /(https?:\/\/[^\s]+)(?=[\s,.!?;:'"]|$)/g;
  
  const matches = [];
  let match;
  
  while ((match = urlPattern.exec(text)) !== null) {
    let url = match[1];
    
    // Remove trailing punctuation characters but keep query parameters and fragments
    url = url.replace(/[.,!?;:'\")+]+$/g, '');
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// schemes with https:// while leaving existing secure URLs untouched
  
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // For URLs http://example.com/...:
  // - Always upgrade the scheme to https://
  // - When the path begins with /docs/, rewrite the host to docs.example.com
  // - Skip the host rewrite when the path contains dynamic hints such as cgi-bin,
  //   query strings (?, &, =), or legacy extensions like .jsp, .php, .asp, .aspx,
  //   .do, .cgi, .pl, .py
  // - Preserve nested paths
  
  return text.replace(/http:\/\/([^/]+)(\/[^\s]*)/g, (match, hostname, path) => {
    // Always upgrade to https
    let newUrl = `https://${hostname}${path}`;
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    if (path.startsWith('/docs/')) {
      const skipHostRewrite = /\/(cgi-bin|.*\?.*=|.*&.*=|.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
      
      if (!skipHostRewrite) {
        // Rewrite host to docs.example.com
        newUrl = `https://docs.${hostname}${path}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract year from mm/dd/yyyy date format.
 */
export function extractYear(value: string): string {
  // Return the four-digit year for mm/dd/yyyy
  // If the string doesn't match that format or month/day are invalid, return N/A
  
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (match) {
    return match[3]; // Return the year
  }
  
  return 'N/A';
}