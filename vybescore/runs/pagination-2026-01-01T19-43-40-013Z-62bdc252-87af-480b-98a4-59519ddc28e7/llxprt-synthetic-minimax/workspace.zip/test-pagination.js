import { createApp } from './src/server/app.js';
import { createDatabase } from './src/server/db.js';

async function testPagination() {
  console.log('Testing pagination implementation...');
  
  try {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const port = 3334;
    const server = app.listen(port, () => {
      console.log(`Test server running on http://localhost:${port}`);
    });

    // Wait for server to start
    await new Promise(resolve => setTimeout(resolve, 1000));

    const test = async (url, description) => {
      console.log(`\nTesting: ${description}`);
      console.log(`GET ${url}`);
      
      try {
        const response = await fetch(url);
        const data = await response.json();
        
        console.log(`Status: ${response.status}`);
        console.log(`Response:`, JSON.stringify(data, null, 2));
        
        if (response.ok) {
          console.log('[OK] Success');
        } else {
          console.log(' Failed');
        }
      } catch (error) {
        console.log(' Error:', error.message);
      }
    };

    // Test valid pagination
    await test('http://localhost:3334/inventory?page=1&limit=2', 'Page 1, limit 2');
    await test('http://localhost:3334/inventory?page=2&limit=2', 'Page 2, limit 2');
    await test('http://localhost:3334/inventory', 'Default page and limit');
    
    // Test validation errors
    await test('http://localhost:3334/inventory?page=0&limit=2', 'Invalid page (0)');
    await test('http://localhost:3334/inventory?page=-1&limit=2', 'Invalid page (-1)');
    await test('http://localhost:3334/inventory?page=abc&limit=2', 'Invalid page (non-numeric)');
    await test('http://localhost:3334/inventory?page=1&limit=0', 'Invalid limit (0)');
    await test('http://localhost:3334/inventory?page=1&limit=-1', 'Invalid limit (-1)');
    await test('http://localhost:3334/inventory?page=1&limit=200', 'Excessive limit (200)');
    await test('http://localhost:3334/inventory?page=1&limit=abc', 'Invalid limit (non-numeric)');

    console.log('\nPagination tests completed!');
    
    server.close();
    
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testPagination();