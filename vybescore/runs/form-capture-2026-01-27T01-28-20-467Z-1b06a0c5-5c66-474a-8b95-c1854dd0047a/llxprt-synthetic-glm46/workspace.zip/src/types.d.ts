declare module 'sql.js' {
  interface Database {
    run(sql: string, ...params: unknown[]): unknown;
    prepare(sql: string): Statement;
    export(): Uint8Array;
  }

  interface Statement {
    run(...params: unknown[]): unknown;
    free(): void;
  }

  interface SqlJsStatic {
    (options?: object): Promise<SqlJsStatic>;
    Database: new (data?: Uint8Array | ArrayBuffer) => Database;
  }

  const sqljs: SqlJsStatic;
  export = sqljs;
}