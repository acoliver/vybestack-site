import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs/promises';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Configure Express
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// SQLite database variables
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    let dbBuffer: Buffer;
    try {
      // Try to load existing database
      dbBuffer = await fs.readFile(dbPath);
    } catch {
      // Database doesn't exist, create new one
      dbBuffer = Buffer.alloc(0);
    }
    
    db = new SQL.Database(dbBuffer);
    
    // Create submissions table if not exists
    const schema = await fs.readFile(
      path.join(__dirname, '../db/schema.sql'),
      'utf8'
    );
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
async function saveDatabase(): Promise<void> {
  try {
    const data = db.export();
    await fs.writeFile(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  saveDatabase()
    .then(() => {
      console.log('Database saved successfully');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Error during shutdown:', error);
      process.exit(1);
    });
}

// Handle termination signals
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Validation functions
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Accept international formats with leading +, spaces, parentheses, and dashes
  const phoneRegex = /^[+]?\d[\d\s\-()]*$/;
  return phoneRegex.test(phone) && phone.length >= 6;
}

function isValidPostalCode(code: string): boolean {
  // Accept alphanumeric with spaces and dashes
  const postalRegex = /^[a-zA-Z0-9\s-]{3,20}$/;
  return postalRegex.test(code);
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    formData: {},
  });
});

app.post('/submit', (req, res) => {
  const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = req.body;
  
  const errors: string[] = [];
  const formData = { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone };
  
  // Validate required fields
  if (!firstName || firstName.trim() === '') errors.push('First name is required');
  if (!lastName || lastName.trim() === '') errors.push('Last name is required');
  if (!streetAddress || streetAddress.trim() === '') errors.push('Street address is required');
  if (!city || city.trim() === '') errors.push('City is required');
  if (!stateProvince || stateProvince.trim() === '') errors.push('State/Province/Region is required');
  if (!postalCode || postalCode.trim() === '') errors.push('Postal/Zip code is required');
  if (!country || country.trim() === '') errors.push('Country is required');
  if (!email || email.trim() === '') errors.push('Email is required');
  if (!phone || phone.trim() === '') errors.push('Phone number is required');
  
  // Validate email format
  if (email && !isValidEmail(email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Validate phone format
  if (phone && !isValidPhone(phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  // Validate postal code format
  if (postalCode && !isValidPostalCode(postalCode)) {
    errors.push('Please enter a valid postal/zip code');
  }
  
  if (errors.length > 0) {
    return res.render('form', { errors, formData });
  }
  
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run([firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone]);
    stmt.free();
    
    // Save database after insertion
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    errors.push('An error occurred while saving your submission. Please try again.');
    res.render('form', { errors, formData });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Start server
async function startServer(): Promise<void> {
  await initDatabase();
  
  // Ensure data directory exists
  await fs.mkdir(path.dirname(dbPath), { recursive: true });
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
