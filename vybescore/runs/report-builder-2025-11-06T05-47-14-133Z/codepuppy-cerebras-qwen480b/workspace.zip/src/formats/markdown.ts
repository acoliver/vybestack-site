import type { ReportData, ReportRenderer } from '../types.js';

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  // Title
  lines.push(`# ${data.title}`);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries heading
  lines.push('## Entries');
  
  // Entries list
  for (const entry of data.entries) {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    lines.push(`- **${entry.label}** — ${formattedAmount}`);
  }
  
  // Total if requested
  if (includeTotals && data.entries.length > 0) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = `$${total.toFixed(2)}`;
    lines.push(`**Total:** ${formattedTotal}`);
  }
  
  return lines.join('\n');
}

export const markdownRenderer: ReportRenderer = {
  render: renderMarkdown,
};