import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (isNaN(pageNum) || !Number.isFinite(pageNum) || pageNum <= 0) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a positive number' });
      }
      if (pageNum > 10000) {
        return res.status(400).json({ error: 'Invalid page parameter: value too large' });
      }
      page = Math.floor(pageNum);
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (isNaN(limitNum) || !Number.isFinite(limitNum) || limitNum <= 0) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a positive number' });
      }
      if (limitNum > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter: maximum allowed value is 100' });
      }
      limit = Math.floor(limitNum);
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
