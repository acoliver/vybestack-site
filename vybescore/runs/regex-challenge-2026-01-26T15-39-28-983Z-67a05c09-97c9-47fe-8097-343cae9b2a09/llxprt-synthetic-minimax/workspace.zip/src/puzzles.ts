/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match whole words starting with the prefix
  // Use word boundaries to match complete words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exception words (case-insensitive)
  const filteredMatches = matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      lowerMatch === exception.toLowerCase()
    );
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token that appears after a digit and not at string start
  // We need to capture the digit + token combination
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Return the full match including the digit
  const fullPattern = new RegExp(`\\d${escapedToken}`, 'gi');
  const fullMatches = text.match(fullPattern) || [];
  
  return fullMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for character requirements
  if (!/[A-Z]/.test(value)) {
    return false; // No uppercase
  }
  
  if (!/[a-z]/.test(value)) {
    return false; // No lowercase
  }
  
  if (!/\d/.test(value)) {
    return false; // No digit
  }
  
  if (!/[!@#$%^&*()_+\-={}[\]|:;,.<>?]/.test(value)) {
    return false; // No symbol
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  if (/(..)\1/.test(value)) {
    return false; // Repeated pattern of 2 characters
  }
  
  if (/(...)\1/.test(value)) {
    return false; // Repeated pattern of 3 characters
  }
  
  // Check for sequential patterns like abcd, 1234 (but be less strict)
  const lowerValue = value.toLowerCase();
  
  // Check for ascending/descending number sequences
  const numberSequences = ['0123', '1234', '2345', '3456', '4567', '5678', '6789', '7890'];
  if (numberSequences.some(seq => lowerValue.includes(seq))) {
    return false;
  }
  
  // Don't check for letter sequences since 'Abc' should be allowed
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Exclude IPv4 addresses first
  const ipv4Pattern = /\b\d{1,3}(\.\d{1,3}){3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 shorthand notation (contains double colon)
  if (value.includes('::')) {
    return true;
  }
  
  // IPv6 with colons and hex digits (look for typical IPv6 pattern)
  const ipv6Pattern = /[a-fA-F0-9]*:[a-fA-F0-9]*:[a-fA-F0-9]*/;
  if (ipv6Pattern.test(value)) {
    // Verify it looks like an IPv6 address and not some other text with colons
    const addressPattern = /\b[a-fA-F0-9]{1,4}:[a-fA-F0-9]{1,4}\b/;
    if (addressPattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
