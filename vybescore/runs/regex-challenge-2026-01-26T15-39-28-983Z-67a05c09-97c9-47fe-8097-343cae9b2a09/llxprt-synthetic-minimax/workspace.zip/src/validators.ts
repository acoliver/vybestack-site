export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern breakdown:
  // ^(?!.*\.\.) - Negative lookahead to reject double dots anywhere
  // (?!.*\.$) - Negative lookahead to reject trailing dot
  // [a-zA-Z0-9._+-]+@ - Local part with allowed characters, ending with @
  // [a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$ - Domain part with TLD
  // Domain rejects underscores and trailing dots through negative lookaheads
  const emailRegex = /^(?!.*\.\.)(?!.*\.$)[a-zA-Z0-9._+-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const cleaned = value.replace(/\D/g, '');
  
  // Check total length (country code + area code + number)
  if (cleaned.length < 10 || cleaned.length > 11) {
    return false;
  }
  
  // Handle country code
  let startIndex = 0;
  if (cleaned.length === 11) {
    // Has country code
    if (!cleaned.startsWith('1')) {
      return false; // Country code must be 1 for US
    }
    startIndex = 1;
  }
  
  // Extract parts
  const areaCode = cleaned.substr(startIndex, 3);
  const exchangeCode = cleaned.substr(startIndex + 3, 3);
  
  // Validate area code (cannot start with 0 or 1)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate exchange code (cannot start with 0 or 1)
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Must have exactly 10 digits after country code check
  const totalDigits = cleaned.length - startIndex;
  return totalDigits === 10;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators but keep the structure for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Main pattern with groups for country, trunk, mobile, area, subscriber
  // ^\+?54?9?0?([1-9]\d{2,3})(\d{6,8})$
  // Optional +54 country code
  // Optional 9 mobile indicator
  // Optional 0 trunk prefix
  // Required 2-4 digit area code (leading 1-9)
  // Required 6-8 digit subscriber number
  const pattern = /^(\+54)?9?0?([1-9]\d{2,3})(\d{6,8})$/;
  
  const match = cleaned.match(pattern);
  if (!match) {
    return false;
  }
  
  const hasCountry = cleaned.startsWith('+54');
  const hasTrunk = cleaned.startsWith('0');
  const areaCode = match[2];
  const subscriber = match[3];
  
  // If no country code, must have trunk prefix 0
  if (!hasCountry && !hasTrunk) {
    return false;
  }
  
  // If country code present, mobile indicator 9 should be present for mobiles
  // But for landlines with country code, trunk prefix can be optional in some cases
  // So we don't strictly enforce this
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits total
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern breakdown:
  // ^[^\d\s] - No digits or symbols at start
  // [\p{L}\p{M}\s'\-]+ - Unicode letters (including accents), spaces, apostrophes, hyphens
  // [^\d\s]*$ - No digits or symbols at end
  // Allow characters like François, O'Neill, Mary-Jane
  // Reject names like "John123", "X Æ A-12", or names with symbols
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}\s'-]*[\p{L}\p{M}]?$/u;
  
  // Also reject obviously fictional names
  const fictionalPattern = /(X\s*Æ\s*A-12|Æ|A-\d+$)/i;
  
  if (fictionalPattern.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Helper function to implement Luhn checksum algorithm
  function runLuhnCheck(cardNumber: string): boolean {
    let sum = 0;
    let shouldDouble = false;
    
    // Process digits from right to left
    for (let i = cardNumber.length - 1; i >= 0; i--) {
      let digit = parseInt(cardNumber.charAt(i));
      
      if (shouldDouble) {
        digit *= 2;
        if (digit > 9) {
          digit -= 9;
        }
      }
      
      sum += digit;
      shouldDouble = !shouldDouble;
    }
    
    return sum % 10 === 0;
  }
  
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check for empty or non-numeric input
  if (cleaned.length === 0 || !/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: Starts with 4, 13-19 digits
  const visaPattern = /^4\d{12}(\d{3})?(\d{3})?$/;
  
  // Mastercard: Starts with 51-55 or 2221-2720, 16 digits
  const mastercardPattern = /^(5[1-5]\d{14}|2(2[2-9]\d{2}|[3-6]\d{3}|7[01]\d{2}|720\d)\d{12})$/;
  
  // AmEx: Starts with 34 or 37, 15 digits
  const amexPattern = /^3[47]\d{13}$/;
  
  let isValidCard = false;
  
  // Check each card type
  if (visaPattern.test(cleaned)) {
    isValidCard = true;
  } else if (mastercardPattern.test(cleaned)) {
    isValidCard = true;
  } else if (amexPattern.test(cleaned)) {
    isValidCard = true;
  }
  
  // If card matches pattern, validate with Luhn checksum
  if (isValidCard) {
    return runLuhnCheck(cleaned);
  }
  
  return false;
}
