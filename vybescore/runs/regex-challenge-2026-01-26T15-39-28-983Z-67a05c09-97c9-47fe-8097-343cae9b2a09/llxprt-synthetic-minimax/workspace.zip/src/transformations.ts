/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces - collapse multiple spaces to single space
  const normalized = text.replace(/\s+/g, ' ');
  
  // Pattern to match sentence endings followed by the next sentence start
  // This captures the punctuation and the first letter of the next sentence
  const result = normalized.replace(/([.!?])\s*([A-Za-z])/g, (match, punctuation, nextChar) => {
    // Capitalize the next character and add single space
    return punctuation + ' ' + nextChar.toUpperCase();
  });
  
  // Handle the first character if it should be capitalized
  if (result.length > 0 && /[a-z]/.test(result[0])) {
    return result[0].toUpperCase() + result.substring(1);
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs including http/https protocols
  // Allow any characters except spaces and sentence ending punctuation (but allow dots)
  const urlPattern = /(https?:\/\/[^\s<>"'!,;?]+)/gi;
  
  const matches = text.match(urlPattern) || [];
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave existing https:// untouched
  // Use negative lookahead to avoid replacing https
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with their components
  const httpUrlPattern = /http:\/\/([^/\s]+)([^\s]*)/gi;
  
  return text.replace(httpUrlPattern, (match, host, path) => {
    // Always upgrade to https
    const result = 'https://' + host;
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(\?|cgi-bin|=|&)/.test(path);
    const hasLegacyExtensions = /(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)$/i.test(path);
    
    // Skip host rewrite for dynamic or legacy paths
    if (hasDynamicHints || hasLegacyExtensions) {
      return result + path;
    }
    
    // For /docs/ paths, rewrite host to docs.example.com but keep the full path
    if (path.startsWith('/docs/')) {
      return 'https://docs.example.com' + path;
    }
    
    return result + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format with valid ranges
  // Month: 01-12, Day: 01-31, Year: any 4 digits
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Additional validation for days in month
  const thirtyDaysMonths = [4, 6, 9, 11];
  const isThirtyDayMonth = thirtyDaysMonths.includes(month);
  
  // Handle February with leap year consideration
  if (month === 2) {
    const isLeapYear = (parseInt(year) % 4 === 0 && parseInt(year) % 100 !== 0) || (parseInt(year) % 400 === 0);
    if (day > 29 || (!isLeapYear && day > 28)) {
      return 'N/A';
    }
  } else if (isThirtyDayMonth && day > 30) {
    return 'N/A';
  }
  
  return year;
}
