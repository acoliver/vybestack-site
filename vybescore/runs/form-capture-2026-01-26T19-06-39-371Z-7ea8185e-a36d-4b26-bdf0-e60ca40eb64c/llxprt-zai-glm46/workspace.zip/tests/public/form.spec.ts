import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { startServer } from '../../src/server.js';

let server: ReturnType<typeof startServer> extends Promise<infer T> ? T : never;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  server = await startServer(0);
});

afterAll(async () => {
  if (server && server.server) {
    await new Promise<void>((resolve) => {
      server.server.close(() => resolve());
    });
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    expect(server.app).toBeDefined();
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});
