import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const app = express();
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));
app.set('view engine', 'ejs');
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

app.use(express.static(path.resolve(process.cwd(), 'public')));
app.use(express.urlencoded({ extended: true }));

let db: Database | null = null;

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow international formats with +, @, digits, spaces, dashes, and parentheses
  const phoneRegex = /^[@+]?\d[\d\s\-()]*$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalCode.trim().length > 0 && postalRegex.test(postalCode);
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!formData.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!formData.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!formData.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!formData.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!formData.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  if (!formData.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code must be alphanumeric' });
  }
  if (!formData.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!formData.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  if (!formData.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Phone number can contain digits, spaces, dashes, parentheses, and a leading + or @' });
  }

  return errors;
}

async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs();

  const dbDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  if (fs.existsSync(DB_PATH)) {
    const dbBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(dbBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (!db) throw new Error('Database not initialized');
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

function getFieldError(errors: ValidationError[], field: string): string | undefined {
  return errors.find((e) => e.field === field)?.message;
}

app.get('/', (req: Request, res: Response) => {
  const errors = req.query.errors ? JSON.parse(req.query.errors as string) : [];
  const formData: FormData = req.query.data ? JSON.parse(req.query.data as string) : {};

  res.render('index', {
    errors,
    formData,
    getFieldError,
  });
});

app.post('/submit', (req: Request, res: Response, next: NextFunction) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    const params = new URLSearchParams();
    params.append('errors', JSON.stringify(errors));
    params.append('data', JSON.stringify(formData));
    return res.redirect(`/?${params.toString()}`);
  }

  try {
    if (!db) throw new Error('Database not initialized');

    db.run(
      `INSERT INTO submissions
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName || '',
        formData.lastName || '',
        formData.streetAddress || '',
        formData.city || '',
        formData.stateProvince || '',
        formData.postalCode || '',
        formData.country || '',
        formData.email || '',
        formData.phone || '',
      ]
    );

    saveDatabase();

    res.redirect('/thank-you');
  } catch (err) {
    next(err);
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

export async function startServer(serverPort?: number): Promise<{ app: express.Application; server: ReturnType<typeof app.listen> }> {
  await initDatabase();

  const actualPort = serverPort || port;
  const server = app.listen(actualPort, () => {
    console.log(`Server running on http://localhost:${actualPort}`);
  });

  return { app, server };
}

function shutdown(): void {
  if (db) {
    db.close();
    db = null;
  }
}

process.on('SIGTERM', () => {
  shutdown();
  process.exit(0);
});

if (import.meta.url === `file://${process.argv[1]}` || import.meta.url === `file://${process.argv[1].replace(/\\/g, '/')}`) {
  startServer(port).catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
