# GitHub Flavored Markdown Compatibility Test

## Code Blocks with ` ``` ` notation

```bash
#!/bin/bash
echo "This is a fenced code block with syntax highlighting"
```

```javascript
// JavaScript code block
function test() {
  console.log("This should work in GFM");
  return true;
}
```

```css
/* CSS code block */
.highlight {
  color: blue;
  background: #f0f0f0;
}
```

## Inline Code Formatting

Inline code should use single backticks: `code`

## Multiple Language Tests

```python
# Python code block
def test_function():
    return "Hello from Python"
```

```html
<!-- HTML code block -->
<div class="test">
  <p>This is HTML in a code block</p>
</div>
```

## Escaping Backticks

Should display as literal backticks: \`not a code block\`

Should display code: `inline code`

Should display backticks in code: `` `backticks` inside code``