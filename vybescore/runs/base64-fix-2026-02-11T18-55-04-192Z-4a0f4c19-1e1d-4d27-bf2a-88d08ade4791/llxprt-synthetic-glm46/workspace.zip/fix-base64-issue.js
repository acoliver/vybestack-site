#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

// Configuration
const BASE64_FIELDS = [
  'profileImageUrl',
  'avatarUrl',
  'favicon',
  'logo',
  'heroImage',
  'bannerImage',
  'image',
  'icon'
];

// Files to process (relative to the script directory)
const FILES_TO_PROCESS = [
  '../src/data/features.json',
  '../src/data/members.json',
  '../src/data/sponsors.json',
  '../src/data/content.json'
];

// Function to check if a string is a valid data URL
function isValidDataUrl(string) {
  if (typeof string !== 'string') return false;
  return string.startsWith('data:image/') && string.includes('base64,');
}

// Function to clean an image URL
function cleanImageUrl(url) {
  if (typeof url !== 'string') return url;
  
  const trimmed = url.trim();
  
  // If it's not a data URL, return as-is
  if (!trimmed.startsWith('data:image/')) {
    return trimmed;
  }
  
  // Check for multiple base64 declarations
  const base64Index = trimmed.indexOf('base64,');
  if (base64Index === -1) {
    return trimmed; // Not a valid base64 data URL
  }
  
  // Find the actual end of the base64 content
  const mimeType = trimmed.substring(5, base64Index);
  const actualBase64Content = trimmed.substring(base64Index + 7);
  
  // Clean up any trailing junk
  const cleanBase64 = actualBase64Content.replace(/[^a-zA-Z0-9+/=]/g, '');
  
  return `data:${mimeType}base64,${cleanBase64}`;
}

// Function to recursively clean an object
function cleanObject(obj, depth = 0) {
  if (depth > 10) {
    console.warn('Max depth reached, stopping to prevent infinite recursion');
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map(item => cleanObject(item, depth + 1));
  }
  
  if (obj !== null && typeof obj === 'object') {
    const cleaned = {};
    for (const [key, value] of Object.entries(obj)) {
      // Clean Base64 image fields
      if (BASE64_FIELDS.includes(key) && typeof value === 'string') {
        if (isValidDataUrl(value)) {
          cleaned[key] = cleanImageUrl(value);
        } else {
          console.warn(`Found non-base64 image URL in ${key}: ${value.substring(0, 50)}...`);
          cleaned[key] = value;
        }
      } else {
        cleaned[key] = cleanObject(value, depth + 1);
      }
    }
    return cleaned;
  }
  
  return obj;
}

// Main processing function
function processFiles() {
  console.log('Starting Base64 cleaning process...');
  
  const scriptDir = __dirname;
  const projectRoot = path.resolve(scriptDir, '..');
  
  for (const file of FILES_TO_PROCESS) {
    const filePath = path.resolve(scriptDir, file);
    
    try {
      if (!fs.existsSync(filePath)) {
        console.warn(`File not found: ${filePath}, skipping...`);
        continue;
      }
      
      console.log(`Processing: ${filePath}`);
      
      // Read the file
      const fileContent = fs.readFileSync(filePath, 'utf8');
      const data = JSON.parse(fileContent);
      
      // Clean the data
      const cleanedData = cleanObject(data);
      
      // Write back to file
      fs.writeFileSync(filePath, JSON.stringify(cleanedData, null, 2));
      console.log(`[OK] Successfully cleaned: ${file}`);
      
    } catch (error) {
      console.error(`Error processing ${file}:`, error.message);
    }
  }
  
  console.log('Base64 cleaning complete!');
}

// Run the process
if (require.main === module) {
  processFiles();
}

module.exports = { cleanObject, processFiles };