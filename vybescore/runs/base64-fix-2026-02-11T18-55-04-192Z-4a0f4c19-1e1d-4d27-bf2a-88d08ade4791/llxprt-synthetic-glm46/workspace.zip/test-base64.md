# Testing Base64 issues

## Test 1: Encoding padding removal
```javascript
const input = "any carnal pleasure.";
const encoded = btoa(input);
console.log("Standard btoa:", encoded); // "YW55IGNhcm5hbCBwbGVhc3VyZS4="

// Current implementation strips padding
// This breaks compatibility
```

## Test 2: Decoding with different alphabets
```javascript
const encodedWithSlash = "YW55IGNhcm5hbCBwbGVhc3VyZS4=";
console.log("decode with /:", atob(encodedWithSlash)); // Works

const encodedWithPlus = "YW55IGNhcm5hbCBwbGVhc3VyZS4=";
console.log("decode with +:", atob(encodedWithPlus)); // Works

const urlEncoded = "YW55IGNhcm5hbCBwbGVhc3VyZS4";
console.log("decode without padding:", atob(urlEncoded)); // Fails
```

## Expected behavior:
1. encode() should preserve padding for compatibility
2. decode() should handle both standard and URL-safe alphabets
3. decode() should handle inputs with and without padding