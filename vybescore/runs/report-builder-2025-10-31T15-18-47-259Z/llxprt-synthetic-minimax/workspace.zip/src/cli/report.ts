import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
const args = process.argv.slice(2);

if (args.length < 2) {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  process.exit(1);
}

const dataFile = args[0];
const formatIndex = args.indexOf('--format');

if (formatIndex === -1) {
  console.error('Error: --format argument is required');
  process.exit(1);
}

const format = args[formatIndex + 1];
const outputIndex = args.indexOf('--output');
const includeTotalsIndex = args.indexOf('--includeTotals');

let outputPath: string | null = null;
let includeTotals = false;

if (outputIndex !== -1 && args[outputIndex + 1]) {
  outputPath = args[outputIndex + 1];
}

if (includeTotalsIndex !== -1) {
  includeTotals = true;
}

// Validate format
if (format !== 'markdown' && format !== 'text') {
  console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
  process.exit(1);
}

// Load and parse JSON data
let reportData: ReportData;

try {
  const rawData = readFileSync(dataFile, 'utf-8');
  reportData = JSON.parse(rawData);
} catch (error) {
  console.error(`Error: Failed to read or parse '${dataFile}': ${error}`);
  process.exit(1);
}

// Validate required fields
if (!reportData.title || !reportData.summary || !reportData.entries) {
  console.error('Error: Invalid data format - missing required fields (title, summary, entries)');
  process.exit(1);
}

// Render report
let output: string;

switch (format) {
  case 'markdown':
    output = renderMarkdown(reportData, { includeTotals });
    break;
  case 'text':
    output = renderText(reportData, { includeTotals });
    break;
  default:
    console.error(`Error: Unsupported format '${format}'`);
    process.exit(1);
}

// Output results
if (outputPath) {
  try {
    writeFileSync(outputPath, output, 'utf-8');
  } catch (error) {
    console.error(`Error: Failed to write to '${outputPath}': ${error}`);
    process.exit(1);
  }
} else {
  console.log(output);
}