import { ReportData, RenderOptions } from '../types.js';

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function renderText(data: ReportData, options: RenderOptions = {}): string {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries heading
  lines.push('Entries:');
  
  // Individual entries
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }
  
  // Total if requested
  if (options.includeTotals) {
    lines.push('');
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
}