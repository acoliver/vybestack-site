#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const renderers = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArgs(): { dataPath: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing format after --format');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing path after --output');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    throw new Error('Missing required --format option');
  }

  if (!renderers[format as keyof typeof renderers]) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid field: title (must be string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid field: summary (must be string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid field: entries (must be array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected object`);
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid label (must be string)`);
    }
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid entry at index ${i}: missing or invalid amount (must be number)`);
    }
  }

  return obj as unknown as ReportData;
}

function main(): void {
  try {
    // Parse command line arguments
    const { dataPath, format, outputPath, includeTotals } = parseArgs();

    // Read and parse JSON data
    let jsonData: unknown;
    try {
      const jsonContent = readFileSync(dataPath, 'utf-8');
      jsonData = JSON.parse(jsonContent);
    } catch (error) {
      throw new Error(`Failed to read or parse JSON file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Render report
    const renderer = renderers[format as keyof typeof renderers];
    const output = renderer(reportData, { includeTotals });

    // Output result
    if (outputPath) {
      writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
