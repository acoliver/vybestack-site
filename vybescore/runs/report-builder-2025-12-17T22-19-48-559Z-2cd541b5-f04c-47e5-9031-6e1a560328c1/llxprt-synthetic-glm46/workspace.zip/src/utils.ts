/**
 * Format amount with two decimal places (no thousands separators)
 */
export function formatAmount(amount: number): string {
  return amount.toFixed(2);
}