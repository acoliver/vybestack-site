import type { ReportData, ReportOptions } from '../types.js';
import { formatAmount } from '../utils.js';

export const renderText = (
  data: ReportData,
  options: ReportOptions
): string => {
  // Validate required fields
  if (!data.title) {
    throw new Error('Missing required field: title');
  }
  if (!data.summary) {
    throw new Error('Missing required field: summary');
  }
  if (!data.entries || !Array.isArray(data.entries)) {
    throw new Error('Missing required field: entries');
  }

  // Calculate total if needed
  const total = options.includeTotals
    ? data.entries.reduce((sum, entry) => sum + entry.amount, 0)
    : null;

  // Build output
  const output: string[] = [];

  output.push(data.title);
  output.push(data.summary);
  output.push('Entries:');
  
  for (const entry of data.entries) {
    output.push(`- ${entry.label}: $${formatAmount(entry.amount)}`);
  }

  if (total !== null) {
    output.push(`Total: $${formatAmount(total)}`);
  }

  return output.join('\n');
};