/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> & { disposed?: boolean } = {
    value,
    updateFn,
    disposed: false,
  }
  
  // Wrap updateFn to check disposal status
  const originalUpdateFn = updateFn
  const wrappedUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    if (observer.disposed) {
      return prevValue as T
    }
    return originalUpdateFn(prevValue)
  }
  
  observer.updateFn = wrappedUpdateFn
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  return () => {
    if (observer.disposed) return
    observer.disposed = true
  }
}
