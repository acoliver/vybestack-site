/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> & { observers?: Set<Observer<unknown>> } = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer && !o.observers!.has(observer as Observer<unknown>)) {
      // Register the current observer as dependent on this computed value
      o.observers!.add(observer as Observer<unknown>)
    }
    return o.value!
  }
  
  return getter
}
