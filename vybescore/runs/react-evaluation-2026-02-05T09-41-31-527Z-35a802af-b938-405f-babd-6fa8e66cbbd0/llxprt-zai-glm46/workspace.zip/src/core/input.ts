/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Default equality function using Object.is.
 */
function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return Object.is(lhs, rhs)
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> = 
    _equal === true ? defaultEqual :
    _equal === false || _equal === undefined ? (() => false) :
    _equal

  const s: Subject<T> & { observers?: Set<Observer<unknown>> } = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      // Register this observer if not already registered
      if (!s.observers!.has(observer as Observer<unknown>)) {
        s.observers!.add(observer as Observer<unknown>)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using the equal function
    if (equalFn(s.value, nextValue)) {
      return s.value
    }

    s.value = nextValue

    // Notify all observers that depend on this subject
    for (const obs of s.observers!) {
      updateObserver(obs)
    }

    return s.value
  }

  return [read, write]
}
