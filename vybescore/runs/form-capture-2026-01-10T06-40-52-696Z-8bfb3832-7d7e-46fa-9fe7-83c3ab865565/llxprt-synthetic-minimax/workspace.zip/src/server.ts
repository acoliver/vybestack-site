import express, { Request, Response } from 'express';
import path from 'path';
import { Database } from './database';

const app = express();
const PORT = process.env.PORT || 3535;

// Database instance
const db = new Database(path.join(__dirname, '../data/submissions.sqlite'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as templating engine
app.set('views', path.join(__dirname, '../views'));
app.set('view engine', 'ejs');

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
  return phoneRegex.test(phone);
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validatePostalCode(code: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
  return postalRegex.test(code);
}

interface ValidationResult {
  isValid: boolean;
  errors: { [key: string]: string };
}

function validateFormData(data: { [key: string]: string }): ValidationResult {
  const errors: { [key: string]: string } = {};
  
  // Required field validation
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city',
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  requiredFields.forEach(field => {
    if (!validateRequired(data[field] || '')) {
      errors[field] = 'This field is required';
    }
  });
  
  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    oldData: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData = req.body;
  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    res.status(400).render('form', {
      errors: validation.errors,
      oldData: formData
    });
    return;
  }
  
  try {
    // Initialize database if not already done
    await db.initialize();
    
    // Insert into database
    await db.saveSubmission({
      firstName: formData.firstName,
      lastName: formData.lastName,
      streetAddress: formData.streetAddress,
      city: formData.city,
      stateProvinceRegion: formData.stateProvince,
      postalCode: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phoneNumber: formData.phone
    });
    
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: { general: 'Server error. Please try again later.' },
      oldData: formData
    });
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you');
});

// Initialize database on startup
db.initialize().catch(error => {
  console.error('Failed to initialize database:', error);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully');
  await db.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully');
  await db.close();
  process.exit(0);
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export { app };
