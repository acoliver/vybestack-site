// Import using tsx to handle TypeScript files
import { createApp } from './src/server/app.ts';
import { createDatabase } from './src/server/db.ts';

async function testAPILoad() {
  try {
    console.log('Creating database...');
    const db = await createDatabase();
    console.log('Creating app...');
    const app = await createApp(db);
    console.log('Testing API endpoints...');
    
    // Test default pagination (page 1, limit 5)
    console.log('\nTesting default pagination...');
    const response1 = await fetch('http://localhost:3333/inventory');
    console.log('Response status:', response1.status);
    const data1 = await response1.json();
    console.log('Response data:', JSON.stringify(data1, null, 2));
    console.log(`Items count: ${data1.items.length}`);
    console.log(`HasNext: ${data1.hasNext}`);
    
    // Test page 2 with limit 3
    console.log('\nTesting page=2, limit=3...');
    const response2 = await fetch('http://localhost:3333/inventory?page=2&limit=3');
    console.log('Response status:', response2.status);
    const data2 = await response2.json();
    console.log('Response data:', JSON.stringify(data2, null, 2));
    console.log(`Items count: ${data2.items.length}`);
    console.log(`HasNext: ${data2.hasNext}`);
    
    // Test first page with limit 2
    console.log('\nTesting page=1, limit=2...');
    const response2a = await fetch('http://localhost:3333/inventory?page=1&limit=2');
    console.log('Response status:', response2a.status);
    const data2a = await response2a.json();
    console.log('Response data:', JSON.stringify(data2a, null, 2));
    console.log(`Items count: ${data2a.items.length}`);
    console.log(`HasNext: ${data2a.hasNext}`);
    
    // Test page 5 with limit 5 (should return empty or last page)
    console.log('\nTesting page=5, limit=5...');
    const response2b = await fetch('http://localhost:3333/inventory?page=5&limit=5');
    console.log('Response status:', response2b.status);
    const data2b = await response2b.json();
    console.log('Response data:', JSON.stringify(data2b, null, 2));
    console.log(`Items count: ${data2b.items.length}`);
    console.log(`HasNext: ${data2b.hasNext}`);
    
    // Test invalid page parameter
    console.log('\nTesting invalid page parameter...');
    const response3 = await fetch('http://localhost:3333/inventory?page=invalid');
    console.log('Response status:', response3.status);
    const data3 = await response3.json();
    console.log('Response data:', JSON.stringify(data3, null, 2));
    console.log(`Error message: ${data3.error}`);
    
    // Test negative page parameter
    console.log('\nTesting negative page parameter...');
    const response4 = await fetch('http://localhost:3333/inventory?page=-1');
    console.log('Response status:', response4.status);
    const data4 = await response4.json();
    console.log('Response data:', JSON.stringify(data4, null, 2));
    console.log(`Error message: ${data4.error}`);
    
    // Test excessive limit parameter
    console.log('\nTesting excessive limit parameter...');
    const response5 = await fetch('http://localhost:3333/inventory?limit=200');
    console.log('Response status:', response5.status);
    const data5 = await response5.json();
    console.log('Response data:', JSON.stringify(data5, null, 2));
    console.log(`Error message: ${data5.error}`);
    
    console.log('\nAll tests completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Test failed:', error);
    process.exit(1);
  }
}

// If this file is being run directly, start the server
import { createServer } from 'node:http';

async function startServer() {
  try {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const server = createServer(app);
    
    server.listen(3333, () => {
      console.log('Test server running on http://localhost:3333');
      // Run tests after server starts
      setTimeout(testAPILoad, 1000);
    });
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();