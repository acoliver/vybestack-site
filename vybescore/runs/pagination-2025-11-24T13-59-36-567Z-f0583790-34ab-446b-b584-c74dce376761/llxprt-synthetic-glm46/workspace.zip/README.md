# Pagination Service Repair

This project contains a small Express API backed by SQLite and a minimal React client with complete pagination functionality.

## Features

- Server-side pagination with proper validation
- React client with pagination controls
- Error handling for invalid query parameters
- Proper page offsets calculation

## API Endpoints

### GET /inventory

Returns paginated inventory data.

Query Parameters:
- `page` (optional): Page number (default: 1, min: 1)
- `limit` (optional): Number of items per page (default: 5, min: 1, max: 100)

Response Format:
```json
{
  "items": [
    {
      "id": 1,
      "name": "Notebook",
      "sku": "NB-001",
      "priceCents": 799,
      "createdAt": "2024-01-01T09:00:00.000Z"
    }
  ],
  "page": 1,
  "limit": 5,
  "total": 20,
  "hasNext": true
}
```

Error Response (400):
```json
{
  "error": "Page parameter must be a positive integer"
}
```

## Usage

### Running the Server

```bash
npm install
npm run dev:server
```

The server will start on `http://localhost:3333`.

### Testing

```bash
# Type check
npm run typecheck

# Lint
npm run lint

# Run tests
npm run test:public
```

### Manual Testing

1. Start the server with `npm run dev:server`
2. Open `test-react.html` in your browser
3. Use the pagination controls to navigate through pages
4. Test validation by calling the API directly with invalid parameters

## API Validation Examples

Valid requests:
- `http://localhost:3333/inventory` (default pagination)
- `http://localhost:3333/inventory?page=2&limit=10` (custom pagination)

Invalid requests:
- `http://localhost:3333/inventory?page=invalid` (400 error)
- `http://localhost:3333/inventory?page=-1` (400 error)
- `http://localhost:3333/inventory?limit=200` (400 error)