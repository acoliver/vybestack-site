const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validates if a string is a valid Base64 string.
 * Returns true if the string contains only valid Base64 characters and has valid padding.
 */
function isValidBase64(input: string): boolean {
  // Check for valid characters only
  if (!BASE64_REGEX.test(input)) {
    return false;
  }

  // Check for valid padding (only at the end, and 0, 1, or 2 characters)
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      return false;
    }
    // Padding can only be 1 or 2 characters, and if present, the total length
    // should be a multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
  }

  // Without padding, length should still be valid (optional for some decoders)
  // but the string must not be empty
  return input.length > 0;
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /).
 * Output includes padding (=) when required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for clearly invalid payloads (non-Base64 characters, invalid padding, etc.).
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    
    // Verify that the decoding produced valid UTF-8
    // If the input was invalid base64, Node might produce garbage or incomplete output
    // We check if re-encoding the result gives us back something equivalent (modulo padding)
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    // Normalize for comparison by stripping padding since it can vary
    const normalizedInput = trimmed.replace(/=+$/, '');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedReencoded) {
      throw new Error('Invalid Base64 input - corrupted data');
    }

    return result;
  } catch (error) {
    if (error instanceof Error && error.message === 'Invalid Base64 input - corrupted data') {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
