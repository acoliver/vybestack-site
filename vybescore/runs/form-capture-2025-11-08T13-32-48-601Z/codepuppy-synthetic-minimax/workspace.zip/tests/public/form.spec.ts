import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase } from '../../src/server.js';

let server: import('http').Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Initialize the database
  await initializeDatabase();
  
  // Start the server on a random port for testing
  server = app.listen(0); // Port 0 means random available port
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Check that all required form fields are present
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check form has correct action and method
    expect($('form[action="/submit"]')).toHaveLength(1);
    expect($('form[method="post"]').length).toBeGreaterThan(0);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing test database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Submit valid form data
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    // Check redirect to thank you page
    expect(response.headers.location).toMatch(/^\/thank-you\?firstName=/);
    expect(response.headers.location).toContain('John');
    
    // Verify database has the submission
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Get the data from thank you page
    const thankYouResponse = await request(app)
      .get(response.headers.location)
      .expect(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('body').text()).toContain('Thank you, John!');
  });
  
  it('handles validation errors correctly', async () => {
    const invalidData = {
      firstName: '', // Required but empty
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'invalid-email', // Invalid format
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(invalidData)
      .expect(400);
    
    const $ = cheerio.load(response.text);
    
    // Should show error messages
    expect($('.error-list').text()).toContain('First name is required');
    expect($('.error-list').text()).toContain('valid email address');
    
    // Should preserve form values
    expect($('input[name="lastName"]').val()).toBe('Doe');
    expect($('input[name="city"]').val()).toBe('Buenos Aires');
  });
  
  it('accepts international phone numbers and postal codes', async () => {
    const internationalData = {
      firstName: 'Maria',
      lastName: 'Garcia',
      streetAddress: 'Calle Falsa 123',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA', // UK postal code
      country: 'United Kingdom',
      email: 'maria@example.co.uk',
      phone: '+44 20 7946 0958' // UK phone number
    };
    
    const response = await request(app)
      .post('/submit')
      .send(internationalData)
      .expect(302);
    
    // Should redirect successfully
    expect(response.headers.location).toContain('Maria');
  });
});