/**
 * Encode plain text to Base64 using the standard alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts both standard and URL-safe variants, validates input, and throws on invalid data.
 */
export function decode(input: string): string {
  // Normalize URL-safe characters to standard Base64
  let normalized = input.replace(/-/g, '+').replace(/_/g, '/');

  // Add missing padding if necessary
  const padding = normalized.length % 4;
  if (padding === 2) {
    normalized += '==';
  } else if (padding === 3) {
    normalized += '=';
  } else if (padding !== 0) {
    throw new Error('Invalid Base64 input: incorrect length');
  }

  // Validate characters and try to decode
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  try {
    const decoded = Buffer.from(normalized, 'base64').toString('utf8');
    
    // Verify round-trip encoding to catch invalid Base64 that passed the regex
    const reEncoded = Buffer.from(decoded, 'utf8').toString('base64');
    if (normalized !== reEncoded && !normalized.endsWith('==')) {
      throw new Error('Invalid Base64 input: decoding failed validation');
    }
    
    return decoded;
  } catch (error) {
    if (error instanceof Error && error.message.includes('decode')) {
      throw new Error('Invalid Base64 input: malformed data');
    }
    throw new Error('Failed to decode Base64 input');
  }
}
