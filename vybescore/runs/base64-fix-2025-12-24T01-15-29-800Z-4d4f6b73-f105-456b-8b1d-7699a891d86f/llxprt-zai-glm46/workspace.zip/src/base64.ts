const BASE64_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const PADDING_CHAR = '=';

/**
 * Validate that a string contains only valid Base64 characters.
 * Throws an error if invalid characters are found.
 */
function validateBase64(input: string): void {
  // Remove padding for validation
  const withoutPadding = input.replace(/=+$/, '');
  
  for (let i = 0; i < withoutPadding.length; i++) {
    const char = withoutPadding[i];
    if (!BASE64_ALPHABET.includes(char)) {
      throw new Error(`Invalid Base64 character '${char}' at position ${i}`);
    }
  }

  // Check padding: can only be 0, 1, or 2 '=' characters at the end
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 padding: too many padding characters');
    }
    // Total length including padding should be a multiple of 4
    if ((input.length % 4) !== 0) {
      throw new Error('Invalid Base64 padding: incorrect length');
    }
  }
}

/**
 * Normalize Base64 input by adding padding if missing.
 * Base64 strings should have a length that is a multiple of 4.
 */
function normalizePadding(input: string): string {
  const paddingNeeded = (4 - (input.length % 4)) % 4;
  return input + PADDING_CHAR.repeat(paddingNeeded);
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding as required by the Base64 specification.
 */
export function encode(input: string): string {
  // Buffer.toString('base64') uses standard Base64 with padding
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Input is empty');
  }

  // Validate characters before attempting to decode
  validateBase64(input);

  // Normalize padding if missing
  const normalized = normalizePadding(input);

  try {
    // Buffer.from with 'base64' encoding handles standard Base64 alphabet
    const buffer = Buffer.from(normalized, 'base64');
    
    // Check if decoding produced valid UTF-8
    // If the input was invalid base64, Buffer might produce empty or unexpected results
    const decoded = buffer.toString('utf8');
    
    // Additional validation: verify the round-trip produces valid base64
    // This catches cases like "====" which would decode to empty but is invalid
    const checkEmpty = input.replace(/=+$/, '');
    if (checkEmpty.length === 0) {
      throw new Error('Invalid Base64: no data characters');
    }
    
    return decoded;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
