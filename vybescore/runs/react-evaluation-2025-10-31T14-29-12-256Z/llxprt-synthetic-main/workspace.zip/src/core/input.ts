/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Simple registry to track observers and notify them
// Using unknown to ensure type safety
const inputSubscriptions = new Map<Subject<unknown>, Set<Observer<unknown>>>()

// Export the registry to allow other modules to access it
export { inputSubscriptions }

function getOrCreateSubscriptions(subject: Subject<unknown>): Set<Observer<unknown>> {
  if (!inputSubscriptions.has(subject)) {
    inputSubscriptions.set(subject, new Set())
  }
  return inputSubscriptions.get(subject)!
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Default equality function
  const defaultEqual: EqualFn<T> = (a: T, b: T) => a === b
  
  // Determine equality function
  const equalFn: EqualFn<T> = equal === true 
    ? defaultEqual 
    : equal === false 
    ? () => false 
    : equal || defaultEqual

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Use type assertion to satisfy the registry's unknown type requirements
      const subscriptions = getOrCreateSubscriptions(s as Subject<unknown>)
      subscriptions.add(observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Notify all subscribed observers
      const subscriptions = getOrCreateSubscriptions(s as Subject<unknown>)
      subscriptions.forEach(observer => {
        updateObserver(observer as Observer<unknown>)
      })
    }
    return s.value
  }

  return [read, write]
}

// Re-export getOrCreateSubscriptions for use in other modules
export { getOrCreateSubscriptions }