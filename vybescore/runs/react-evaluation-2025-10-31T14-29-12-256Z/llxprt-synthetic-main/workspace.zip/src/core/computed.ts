/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  setActiveObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

// Registry to track subscribers for computed values
const computedSubscribers = new Map<Observer<unknown>, Set<Observer<unknown>>>()

function getOrCreateRegistrySet<T>(map: Map<T, Set<T>>, key: T): Set<T> {
  if (!map.has(key)) {
    map.set(key, new Set())
  }
  return map.get(key)!
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Default equality function (not used in this implementation but kept for API compatibility)
  /* eslint-disable @typescript-eslint/no-unused-vars */
  const equalFn: EqualFn<T> = equal === true 
    ? ((a: T, b: T) => a === b)
    : equal === false 
    ? () => false 
    : equal || ((a: T, b: T) => a === b)
  /* eslint-enable @typescript-eslint/no-unused-vars */

  // Initialize observer with default value if provided
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initialize tracking structures - use unknown to ensure type compatibility
  const subscribers = getOrCreateRegistrySet(computedSubscribers, o as Observer<unknown>)
  let isStale = true
  
  // Initialize the computed value
  if (value !== undefined) {
    o.value = value
  }
  
  const computeValue = (): T => {
    if (isStale) {
      // Execute the update function with the previous value
      const prevValue = o.value
      const newValue = updateFn(prevValue)
      o.value = newValue
      isStale = false
    }
    return o.value!
  }
  
  const getter: GetterFn<T> = () => {
    // If this is being accessed by another observer, establish the dependency relationship
    const activeObserver = getActiveObserver()
    
    if (activeObserver && activeObserver !== o) {
      // The current observer depends on this computed value
      const observerSubscribers = getOrCreateRegistrySet(computedSubscribers, o as Observer<unknown>)
      observerSubscribers.add(activeObserver as Observer<unknown>)
    }
    
    // Set this computed as the active observer so its dependencies can register themselves
    const previousActive = activeObserver
    
    // Create a context with this computed as the active observer
    const computedContext: Observer<T> = {
      ...o,
      observer: previousActive,
    }
    
    // Use setActiveObserver to temporarily set this computed as the active observer
    setActiveObserver(computedContext)
    
    try {
      // Execute the compute function to get the value
      // This will access dependencies which will register this computed as their observer
      const result = computeValue()
      return result
    } finally {
      // Restore the previous active observer
      setActiveObserver(previousActive)
    }
  }
  
  // Override update function to propagate changes
  const originalUpdateFn = updateFn
  o.updateFn = (prevValue?: T): T => {
    // Mark as stale and recompute
    isStale = true
    
    // Recompute the value
    const result = originalUpdateFn(prevValue)
    o.value = result
    isStale = false
    
    // Notify all subscribers of this computed value
    subscribers.forEach(subscriber => {
      updateObserver(subscriber as Observer<unknown>)
    })
    
    return result
  }
  
  return getter
}