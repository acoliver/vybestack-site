/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn,
  }
  
  // Store the original updateFn
  const originalUpdateFn = updateFn
  
  // Custom update function to run the side effect
  observer.updateFn = (prevValue?: T): T => {
    // Execute the original side effect
    const result = originalUpdateFn(prevValue)
    observer.value = result
    return result
  }
  
  // Initialize the callback by running it once to establish dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.updateFn = () => value!
    observer.value = undefined
  }
}