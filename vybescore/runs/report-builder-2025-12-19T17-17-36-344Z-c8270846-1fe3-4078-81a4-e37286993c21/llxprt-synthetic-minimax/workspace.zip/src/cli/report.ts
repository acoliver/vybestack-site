#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(argv: string[]): { dataFile: string; options: CliOptions } {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = argv[2];
  
  const options: CliOptions = {
    format: 'markdown',
    includeTotals: false
  };

  // Parse remaining arguments
  const args = argv.slice(3);
  let i = 0;
  
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      options.format = args[i + 1] as 'markdown' | 'text';
      i += 2;
    } else if (arg === '--output' && i + 1 < args.length) {
      options.output = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
      i += 1;
    } else {
      console.error(`Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!options.format || !['markdown', 'text'].includes(options.format)) {
    console.error('Unsupported format. Supported formats: markdown, text');
    process.exit(1);
  }

  return { dataFile, options };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i + 1}: missing or invalid "amount" field`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Invalid JSON in file "${filePath}": ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error reading file "${filePath}": ${error.message}`);
    } else {
      console.error(`Error reading file "${filePath}": Unknown error`);
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, options: CliOptions): string {
  const formatters = {
    markdown: renderMarkdown,
    text: renderText
  };
  
  const formatter = formatters[options.format];
  return formatter.render(data, options.includeTotals);
}

function main(): void {
  const { dataFile, options } = parseArgs(process.argv);
  
  const reportData = loadReportData(dataFile);
  const output = renderReport(reportData, options);
  
  if (options.output) {
    try {
      writeFileSync(options.output, output);
    } catch (error) {
      console.error(`Error writing to file "${options.output}": ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();