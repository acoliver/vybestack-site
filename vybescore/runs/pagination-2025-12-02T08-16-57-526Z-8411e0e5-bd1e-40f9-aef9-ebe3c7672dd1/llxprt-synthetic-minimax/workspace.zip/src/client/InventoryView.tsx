import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';
import { useState } from 'react';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return (
      <div>
        <p role="alert">{error ?? 'Unable to load inventory.'}</p>
        <button onClick={() => setCurrentPage(1)}>Try Again</button>
      </div>
    );
  }

  const hasPrevious = currentPage > 1;
  const hasNext = data.hasNext;

  return (
    <section>
      <h1>Inventory</h1>
      
      {data.items.length === 0 ? (
        <p>No inventory items found.</p>
      ) : (
        <>
          <InventoryList items={data.items} />
          <div>
            <span>Page {data.page} of {Math.ceil(data.total / data.limit)} ({data.total} total items)</span>
          </div>
        </>
      )}
      
      <div>
        <button 
          onClick={() => setCurrentPage(currentPage - 1)}
          disabled={!hasPrevious}
        >
          Previous
        </button>
        <button 
          onClick={() => setCurrentPage(currentPage + 1)}
          disabled={!hasNext}
        >
          Next
        </button>
      </div>
    </section>
  );
}
