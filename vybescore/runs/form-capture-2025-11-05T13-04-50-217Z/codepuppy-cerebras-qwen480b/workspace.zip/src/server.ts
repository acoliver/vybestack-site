import express, { Request, Response } from 'express';
import { promises as fs } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

let db: Database | null = null;
const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function isValidPostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode);
}

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

function validateSubmission(formData: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!formData.firstName?.trim()) {
    errors.push('First name is required');
  }

  if (!formData.lastName?.trim()) {
    errors.push('Last name is required');
  }

  if (!formData.streetAddress?.trim()) {
    errors.push('Street address is required');
  }

  if (!formData.city?.trim()) {
    errors.push('City is required');
  }

  if (!formData.stateProvince?.trim()) {
    errors.push('State / Province / Region is required');
  }

  if (!formData.postalCode?.trim()) {
    errors.push('Postal / Zip code is required');
  } else if (!isValidPostalCode(formData.postalCode)) {
    errors.push('Postal code must contain only letters, numbers, spaces, and dashes');
  }

  if (!formData.country?.trim()) {
    errors.push('Country is required');
  }

  if (!formData.email?.trim()) {
    errors.push('Email is required');
  } else if (!isValidEmail(formData.email)) {
    errors.push('Please enter a valid email address');
  }

  if (!formData.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!isValidPhone(formData.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }

  return { isValid: errors.length === 0, errors };
}

async function initializeDatabase(): Promise<void> {
  try {
    await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
    
    const SQL = await initSqlJs();
    
    let dbData: Uint8Array | null = null;
    try {
      const dbFile = await fs.readFile(DB_PATH);
      dbData = new Uint8Array(dbFile);
    } catch (error) {
      console.log('Database file not found, creating new one');
    }
    
    db = new SQL.Database(dbData);
    
    const schema = await fs.readFile(path.join(process.cwd(), 'db/schema.sql'), 'utf8');
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

async function saveDatabase(): Promise<void> {
  if (!db) return;
  
  try {
    const data = db.export();
    await fs.writeFile(DB_PATH, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  const { isValid, errors } = validateSubmission(req.body);
  
  if (!isValid) {
    return res.status(400).render('form', { errors, values: req.body });
  }
  
  try {
    if (!db) throw new Error('Database not initialized');
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      req.body.firstName,
      req.body.lastName,
      req.body.streetAddress,
      req.body.city,
      req.body.stateProvince,
      req.body.postalCode,
      req.body.country,
      req.body.email,
      req.body.phone
    ]);
    
    stmt.free();
    
    await saveDatabase();
    
    res.redirect(`/thank-you?firstName=${encodeURIComponent(req.body.firstName)}`);
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', { 
      errors: ['Failed to save your submission. Please try again.'], 
      values: req.body 
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

let server: ReturnType<typeof app.listen> | undefined;

async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

async function gracefulShutdown(signal: string): Promise<void> {
  console.log(`\nReceived ${signal}, shutting down gracefully...`);
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
    });
  }
  
  if (db) {
    await saveDatabase();
    db.close();
    console.log('Database connection closed');
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { app, server };