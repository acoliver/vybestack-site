/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, handle the start of the text - capitalize the first letter
  let result = text.replace(/^\s*([a-z])/, (match, letter) => match.replace(letter, letter.toUpperCase()));
  
  // Common abbreviations that don't indicate sentence end
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Mt', 'Jr', 'Sr', 'vs', 'etc', 'i.e', 'e.g'];
  
  // Find sentence endings and capitalize the following letter
  result = result.replace(/([.!?]+)(\s*)([a-z])/g, (match, punctuation, spaces, letter) => {
    // Check if this punctuation is part of an abbreviation
    const prevText = result.substring(0, result.indexOf(match));
    const lastWord = prevText.trim().split(/\s+/).pop() || '';
    
    // If the last word before punctuation is an abbreviation, don't capitalize
    for (const abbr of abbreviations) {
      if (lastWord.toLowerCase().includes(abbr)) {
        return match; // Don't capitalize after abbreviations
      }
    }
    
    // Capitalize the letter and ensure exactly one space
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Collapse multiple spaces into a single space
  result = result.replace(/\s{2,}/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that captures HTTP/HTTPS URLs without trailing punctuation
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g;
  
  // Find all matches
  const matches = text.match(urlRegex) || [] as string[];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?')\\]\}]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch existing https:// URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then process URLs that have docs in the path and don't match exclusion criteria
  result = result.replace(
    /https:\/\/example\.com(\/docs\/(?:[^\s?.]+))/g,
    (match, path) => {
      // Check if path contains any of the exclusion patterns
      const exclusionPatterns = [
        /cgi-bin/i,
        /[?&=]/,  // Query string indicators
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i // Legacy extensions
      ];
      
      // If any exclusion pattern matches, just keep the original https:// URL
      for (const pattern of exclusionPatterns) {
        if (path.match(pattern)) {
          return match;
        }
      }
      
      // Otherwise, rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
  );
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate day range based on month
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (simplified - doesn't account for century rules)
  const year = parseInt(yearStr, 10);
  const isLeapYear = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const febDays = isLeapYear ? 29 : 28;
  
  if (
    (month === 2 && day > febDays) ||
    (month !== 2 && day > daysInMonth[month])
  ) {
    return 'N/A';
  }
  
  return yearStr;
}
