/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix for safe matching
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\\\]\\]/g, '\\\\$&');
  
  // Create word boundary regex to find words starting with the prefix
  const wordRegex = new RegExp('\\b' + escapedPrefix + '[a-zA-Z]*\\b', 'g');
  
  // Find all matches
  let matches = text.match(wordRegex) || [] as string[];
  
  // Filter out the exceptions (case-insensitive)
  if (exceptions.length > 0) {
    const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));
    matches = matches.filter(word => !exceptionsSet.has(word.toLowerCase()));
  }
  
  return [...new Set(matches)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token for safe matching
  const escapedToken = token.replace(/[.*+?^${}()|[\\\]\\]/g, '\\\\$&');
  
  // Find all instances where token is preceded by digit but not at start
  // Match digit+token and then filter to exclude cases at the beginning
  const digitTokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  const digitTokenMatches = text.match(digitTokenRegex) || [];
  
  // Filter out matches at the beginning of the string
  return digitTokenMatches.filter(match => !text.startsWith(match));
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences like "abab", "123123", etc.
  // Check for repeated 2-character patterns abab
  if (/(..)\\1/.test(value)) {
    return false;
  }
  
  // Check for repeated 3-character patterns abcabc
  if (/(.{3})\\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern to exclude (make sure we don't match IPv4 addresses)
  const ipv4Pattern = /^(?:\\d{1,3}\\.){3}\\d{1,3}(?!:)/;
  
  // If this is clearly an IPv4 address without colons, it's not IPv6
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Full IPv6 pattern (8 groups of 1-4 hex digits separated by colons)
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: compression (shorthand)
  // This handles patterns like 2001:db8::1
  const compressedIPv6 = /(?:[0-9a-fA-F]{1,4}:){1,7}:/;
  
  // IPv6 with :: at the beginning
  const leadingCompressed = /::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}/;
  
  // IPv6 with :: at the end
  const trailingCompressed = /(?:[0-9a-fA-F]{1,4}:){1,7}::/;
  
  // IPv6 with IPv4-mapped suffix (like ::ffff:192.168.0.1)
  const ipv4MappedIPv6 = /::ffff:(?:\\d{1,3}\\.){3}\\d{1,3}/;
  
  // Check if the string matches any IPv6 pattern
  const hasIPv6 = fullIPv6.test(value) || 
                  compressedIPv6.test(value) || 
                  leadingCompressed.test(value) ||
                  trailingCompressed.test(value) ||
                  ipv4MappedIPv6.test(value);
  
  return hasIPv6;
}