export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation for credit card numbers
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit % 10 + 1;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex:
  // - Local part: letters, digits, +, ., -, _ (no consecutive dots, no leading/trailing dots)
  // - Domain: letters, digits, hyphens but no underscores
  // - TLD: 2-63 letters
  const emailRegex = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,63}$/;
  
  // Reject emails with double dots in local or domain part
  if (value.includes('..')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone validation with multiple format support.
 * Requirements are described in problem.md.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters to check length
  const digitsOnly = value.replace(/\D/g, '');
  
  // If we have 11 digits, must start with +1 prefix
  if (digitsOnly.length === 11 && digitsOnly.charAt(0) !== '1') {
    return false;
  }
  
  // Must have 10 digits (or 11 with country code)
  if (digitsOnly.length !== 10 && digitsOnly.length !== 11) {
    return false;
  }
  
  // Get the actual phone number without country code
  const phoneNumber = digitsOnly.length === 11 ? digitsOnly.substring(1) : digitsOnly;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.charAt(0) === '0' || areaCode.charAt(0) === '1') {
    return false;
  }
  
  // Validate the format with common US phone patterns
  const phoneRegex = /^(?:\+?1[\s-]?)?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep pattern structure
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex:
  // +54 9 11 1234 5678 (mobile with country code)
  // 011 1234 5678 (landline without country code)
  // +54 341 123 4567 (landline with country code)
  // 0341 4234567 (landline with trunk prefix)
  const argentinePhoneRegex = /^(\+54)?(?:9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Extract country code, area code and subscriber number to validate constraints
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) return false;
  
  const hasCountryCode = match[1] !== undefined;
  const areaCode = match[2];
  const subscriberNumber = match[3];
  
  // Area code must be 2-4 digits (leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // When country code is omitted, area code must start with 0
  if (!hasCountryCode && !areaCode.startsWith('0')) {
    return false;
  }
  
  // The rest (after the leading 0) must start with digit 1-9
  const areaCodeRest = areaCode.startsWith('0') ? areaCode.substring(1) : areaCode;
  if (!/^[1-9]/.test(areaCodeRest)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and strange names like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}]+(?:[\p{L}\p{M}'-]*[\p{L}\p{M}])*(?:\s+[\p{L}\p{M}]+(?:[\p{L}\p{M}'-]*[\p{L}\p{M}])*)*$/u;
  
  // Check if the name passes the regex pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional check to reject obvious invalid names
  // Names with too many special characters relative to letters
  const specialChars = (value.match(/[-']/g) || []).length;
  const letters = (value.match(/[\p{L}\p{M}]/gu) || []).length;
  
  // If there are more special characters than letters, it's probably invalid
  if (specialChars > letters / 2) {
    return false;
  }
  
  // Check for names with digits or obvious symbols
  if (/\d|[^\p{L}'\s-]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers based on format and run Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Visa: 13 or 16 digits, starting with 4
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  
  // Mastercard: 16 digits, starting with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  
  // American Express: 15 digits, starting with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any card type pattern
  const isValidFormat = visaRegex.test(digitsOnly) || 
                       mastercardRegex.test(digitsOnly) || 
                       amexRegex.test(digitsOnly);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}