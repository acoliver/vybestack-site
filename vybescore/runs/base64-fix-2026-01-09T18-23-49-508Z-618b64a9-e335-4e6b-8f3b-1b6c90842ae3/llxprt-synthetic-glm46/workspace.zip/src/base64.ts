/**
 * Encode plain text to Base64 using the canonical alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Basic validation: check for valid Base64 characters
  if (!/^[A-Za-z0-9+/=]*$/.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
