/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a pattern that matches words starting with the prefix
  const pattern = new RegExp(`\\b${escapeRegex(prefix)}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern);
  
  if (!matches) {
    return [];
  }
  
  // Filter out the exceptions (case insensitive)
  const filteredMatches = matches.filter(match => {
    const lowercaseMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      lowercaseMatch === exception.toLowerCase()
    );
  });
  
  // Return the full words (with prefix)
  return filteredMatches;
}

function escapeRegex(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // We need to find the token that appears after a digit, but return the full pattern
  const pattern = new RegExp(`\\d${escapeRegex(token)}`, 'g');
  
  const matches = text.match(pattern);
  
  if (!matches) {
    return [];
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[^A-Za-z0-9\s]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, 123123, etc.)
  // This pattern looks for any 2-character sequence that repeats immediately
  const repeatPattern = /(..+)\1/;
  if (repeatPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns - simplified to avoid regex parsing issues
  const patterns = [
    // Standard IPv6 (8 groups of hex digits)
    /[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}/i,
    // IPv6 with compression (using ::)
    /([a-f0-9]{0,4}:){0,7}::([a-f0-9]{0,4}:){0,7}/i,
    // IPv6 with partial compression
    /[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}::/i,
    /::[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}:[a-f0-9]{1,4}/i
  ];
  
  return patterns.some(pattern => pattern.test(value));
}
