export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for obvious patterns that are invalid
  if (value.includes('@@') || value.endsWith('.') || value.includes('..')) {
    return false;
  }
  
  // Basic email pattern validation
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific patterns
  // No underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // For now, ignore the options parameter (could be used for extensions later)
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  options;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for reasonable length (10-11 digits)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Check if starts with +1 (for 11 digits)
  let normalizedValue = value;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    normalizedValue = value.replace(/^(\+?1?)/, ''); // Remove leading 1 or +1
  } else if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false; // 11 digits but not starting with 1
  }
  
  // Extract area code (first 3 digits after any country code)
  const normalizedDigits = normalizedValue.replace(/\D/g, '');
  if (normalizedDigits.length !== 10) {
    return false;
  }
  
  const areaCode = normalizedDigits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Format validation - check if it matches one of the acceptable patterns
  const phoneRegex = /^(\+?1[\s.-]?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s.-]?[2-9]\d{2}[\s.-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Extract all digits for length validation
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 10 || digitsOnly.length > 13) {
    return false;
  }
  
  // Pattern matching for Argentine phone numbers
  // This regex handles various formats:
  // +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  
  const patterns = [
    // +54 9 area_code subscriber_number (mobile with country code)
    /^\+54\s*9\s*([1-9]\d{1,3})\s*(\d{6,8})$/,
    // area_code subscriber_number (mobile without country code, starts with 9)
    /^9\s*([1-9]\d{1,3})\s*(\d{6,8})$/,
    // 0area_code subscriber_number (landline with trunk prefix)
    /^0\s*([1-9]\d{1,3})\s*(\d{6,8})$/,
    // +54 area_code subscriber_number (landline with country code)
    /^\+54\s*([1-9]\d{1,3})\s*(\d{6,8})$/,
    // 0area_codesubscriber_number (compact landline format)
    /^0\s*([1-9]\d{1,3})(\d{6,8})$/,
    // +54area_codesubscriber_number (compact format with country code)
    /^\+54\s*([1-9]\d{1,3})(\d{6,8})$/,
    // Additional patterns for spaced numbers - handle separate subscriber groups
    /^\+54\s+([1-9]\d{1,3})\s+(\d{3,4})\s+(\d{4})$/,
    /^0\s+([1-9]\d{1,3})\s+(\d{3,4})\s+(\d{4})$/
  ];
  
  for (const pattern of patterns) {
    if (pattern.test(value)) {
      const match = value.match(pattern);
      if (match) {
        let areaCode, subscriberNumber;
        
        if (match.length === 4) {
          // Pattern with separate subscriber groups (123 4567)
          areaCode = match[1];
          subscriberNumber = match[2] + match[3];
        } else {
          // Standard pattern (1234567)
          areaCode = match[1];
          subscriberNumber = match[2];
        }
        
        // Remove all non-digits from subscriber number for length check
        const cleanSubscriber = subscriberNumber.replace(/\D/g, '');
        
        // Validate area code length (2-4 digits) and leading digit
        if (areaCode.length >= 2 && areaCode.length <= 4 && areaCode[0] !== '0') {
          // Validate subscriber number length (6-8 digits total)
          if (cleanSubscriber.length >= 6 && cleanSubscriber.length <= 8) {
            return true;
          }
        }
      }
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with problematic symbols
  if (/[^A-Za-z\s'-]/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  const letterRegex = /[A-Za-z]/;
  if (!letterRegex.test(value)) {
    return false;
  }
  
  // Additional validation to prevent "X Æ A-12" style names
  if (/[A-Z]\s*[Æ]\s*[A-Z]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for Visa, Mastercard, AmEx prefixes and lengths
  let isValidPrefix = false;
  let isValidLength = false;
  
  // Visa: starts with 4, length 13, 16, 19
  if (/^4/.test(digitsOnly) && (digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19)) {
    isValidPrefix = true;
    isValidLength = true;
  }
  // Mastercard: starts with 51-55, length 16
  else if (/^5[1-5]/.test(digitsOnly) && digitsOnly.length === 16) {
    isValidPrefix = true;
    isValidLength = true;
  }
  // AmEx: starts with 34 or 37, length 15
  else if (/^3[47]/.test(digitsOnly) && digitsOnly.length === 15) {
    isValidPrefix = true;
    isValidLength = true;
  }
  
  if (!isValidPrefix || !isValidLength) {
    return false;
  }
  
  // Luhn algorithm check
  return luhnCheck(digitsOnly);
}

function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return (sum % 10) === 0;
}
