/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Handle empty string
  if (!text) return text;
  
  // First, normalize spacing - collapse multiple spaces but preserve sentence boundaries
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  if (normalized.length === 0) return normalized;
  
  // Capitalize first character
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Pattern to match sentence endings (. ? !) followed by any whitespace
  // and capitalize the next character (letter/digit/other)
  const sentencePattern = /([.!?])(?:\s+)(.)/g;
  
  // Replace with punctuation + space + capitalized next char
  return normalized.replace(sentencePattern, (match, punct, nextChar) => {
    return punct + ' ' + nextChar.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that captures standard URLs including domain extensions
  const urlRegex = /\b((?:https?:\/\/|www\.)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s.,!?;]*)?)/gi;
  
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Clean up URLs and remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation
    let cleanUrl = url.replace(/[.,!?;]+$/, '');
    
    // Add http:// prefix for www URLs if missing scheme
    if (cleanUrl.startsWith('www.')) {
      cleanUrl = 'http://' + cleanUrl;
    }
    
    return cleanUrl;
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving https:// untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^\s]+)/gi, (match, url) => {
    // Always upgrade to https
    let newUrl = 'https://';
    
    // Extract host and path components
    const hostMatch = url.match(/^([^/\s]+)/);
    const pathMatch = url.match(/(\/[^\s]*)/);
    
    const host = hostMatch ? hostMatch[1] : '';
    const path = pathMatch ? pathMatch[1] : '';
    
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    const hasDynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
    const isDocsPath = /^\/docs\//.test(path);
    
    if (isDocsPath && !hasDynamicHints) {
      // Rewrite host to docs.example.com
      newUrl += 'docs.' + host;
    } else {
      // Keep original host
      newUrl += host;
    }
    
    newUrl += path;
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for month/day combinations could be added here
  // For simplicity, we'll just return the year if basic validation passes
  return year;
}
