#!/usr/bin/env node

import { readFile } from 'fs/promises';
import { resolve } from 'path';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(): { 
  dataPath: string; 
  format: string; 
  outputPath?: string; 
  includeTotals: boolean 
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  if (args[1] !== '--format') {
    console.error('Expected --format flag');
    process.exit(1);
  }
  
  const format = args[2];
  
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 3; i < args.length; i++) {
    if (args[i] === '--output') {
      if (i + 1 >= args.length) {
        console.error('Missing output path after --output flag');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i++; // Skip the next argument as it's the path
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Unknown argument: ${args[i]}`);
      process.exit(1);
    }
  }
  
  return { dataPath, format, outputPath, includeTotals };
}

async function loadData(filePath: string): Promise<ReportData> {
  try {
    const absolutePath = resolve(filePath);
    const data = await readFile(absolutePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Invalid JSON in file: ${filePath}`);
    } else {
      console.error(`Error reading file: ${filePath}`, error);
    }
    process.exit(1);
  }
}

function validateData(data: ReportData): void {
  if (!data.title || typeof data.title !== 'string') {
    console.error('Missing or invalid title in data');
    process.exit(1);
  }
  
  if (!data.summary || typeof data.summary !== 'string') {
    console.error('Missing or invalid summary in data');
    process.exit(1);
  }
  
  if (!Array.isArray(data.entries)) {
    console.error('Missing or invalid entries array in data');
    process.exit(1);
  }
  
  for (const entry of data.entries) {
    if (!entry.label || typeof entry.label !== 'string') {
      console.error('Missing or invalid label in entry');
      process.exit(1);
    }
    
    if (typeof entry.amount !== 'number') {
      console.error('Missing or invalid amount in entry');
      process.exit(1);
    }
  }
}

async function main() {
  const { dataPath, format, outputPath, includeTotals } = parseArgs();
  
  const data = await loadData(dataPath);
  validateData(data);
  
  let output: string;
  
  switch (format) {
    case 'markdown':
      output = renderMarkdown(data, { includeTotals });
      break;
    case 'text':
      output = renderText(data, { includeTotals });
      break;
    default:
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
  }
  
  if (outputPath) {
    try {
      const { writeFile } = await import('fs/promises');
      await writeFile(outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error writing to output file: ${outputPath}`, error);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();