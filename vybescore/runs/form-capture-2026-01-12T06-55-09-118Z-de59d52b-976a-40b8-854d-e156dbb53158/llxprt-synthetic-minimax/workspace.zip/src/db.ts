import * as fs from 'fs';
import * as path from 'path';

// Import the initSqlJs function that returns a promise
const initSqlJs = require('sql.js');

export interface Submission {
  id?: number;
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
  createdAt?: string;
}

class DatabaseHandler {
  private db: any = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js - it returns a promise that resolves to the SqlJs constructor
      const SqlJs = await initSqlJs();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new SqlJs.Database(dbBuffer);
      } else {
        this.db = new SqlJs.Database();
        await this.createSchema();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf-8');
      this.db.exec(schema);
    } else {
      throw new Error('Schema file not found');
    }
  }

  async insertSubmission(submission: Omit<Submission, 'id' | 'createdAt'>): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    const result = this.db.exec("SELECT last_insert_rowid() as id");
    const id = result[0]?.values[0]?.[0] as number;

    await this.save();
    return id;
  }

  async getAllSubmissions(): Promise<Submission[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      SELECT id, first_name, last_name, street_address, city, state_province, postal_code, country, email, phone, created_at
      FROM submissions
      ORDER BY created_at DESC
    `);

    const submissions: Submission[] = [];
    while (stmt.step()) {
      const row: Record<string, unknown> = stmt.getAsObject();
      submissions.push({
        id: Number(row.id),
        firstName: String(row.first_name),
        lastName: String(row.last_name),
        streetAddress: String(row.street_address),
        city: String(row.city),
        stateProvince: String(row.state_province),
        postalCode: String(row.postal_code),
        country: String(row.country),
        email: String(row.email),
        phone: String(row.phone),
        createdAt: String(row.created_at)
      });
    }

    return submissions;
  }

  async save(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const dbBuffer = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(dbBuffer));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export default DatabaseHandler;