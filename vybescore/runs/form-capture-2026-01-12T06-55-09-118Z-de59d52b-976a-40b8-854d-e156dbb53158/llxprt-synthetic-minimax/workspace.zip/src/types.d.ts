/// <reference types="node" />

declare module 'sql.js' {
  interface SqlJs {
    new (buffer?: Uint8Array): Database;
    Database: typeof Database;
  }

  interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): unknown[];
    prepare(sql: string): Statement;
    close(): void;
    export(): Uint8Array;
  }

  interface Statement {
    bind(params: unknown[]): void;
    getAsObject(params?: unknown[]): unknown;
    step(): boolean;
    getColumnNames(): string[];
    free(): void;
  }

  const initSqlJs: (config?: {
    locateFile?: (file: string) => string;
  }) => Promise<SqlJs>;

  export = initSqlJs;
}