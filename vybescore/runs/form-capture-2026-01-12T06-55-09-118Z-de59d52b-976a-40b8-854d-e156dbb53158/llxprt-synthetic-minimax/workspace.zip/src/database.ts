import initSqlJs from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface ContactSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface SqlJsModule {
  Database: new (buffer?: Uint8Array) => SqlDatabase;
}

interface SqlDatabase {
  run(sql: string, params?: unknown[]): void;
  exec(sql: string): unknown[];
  prepare(sql: string): SqlStatement;
  close(): void;
  export(): Uint8Array;
}

interface SqlStatement {
  bind(params: unknown[]): void;
  getAsObject(params?: unknown[]): unknown;
  step(): boolean;
  getColumnNames(): string[];
  free(): void;
}

class DatabaseManager {
  private sql: SqlJsModule | null = null;
  private db: SqlDatabase | null = null;
  private dbFilePath: string;
  private schemaPath: string;

  constructor() {
    this.dbFilePath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js
      this.sql = await initSqlJs({
        locateFile: () => {
          // Find the sql-wasm.wasm file (note the dash)
          const possiblePaths = [
            path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm'),
            path.join(__dirname, '..', '..', 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm'),
            path.join(__dirname, '..', '..', 'dist', 'sql-wasm.wasm')
          ];
          
          for (const tryPath of possiblePaths) {
            if (fs.existsSync(tryPath)) {
              return tryPath;
            }
          }
          
          // Fallback - return the original path and let it fail gracefully
          return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm');
        }
      });

      // Load existing database or create new one
      if (fs.existsSync(this.dbFilePath)) {
        const dbBuffer = fs.readFileSync(this.dbFilePath);
        this.db = new (this.sql as SqlJsModule).Database(dbBuffer);
      } else {
        this.db = new (this.sql as SqlJsModule).Database();
        await this.createSchema();
      }

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schemaSql = fs.readFileSync(this.schemaPath, 'utf8');
    this.db.run(schemaSql);
  }

  insertSubmission(submission: ContactSubmission): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const insertSql = `
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    this.db.run(insertSql, [
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    this.persistToFile();
  }

  private persistToFile(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const data = this.db.export();
    const dir = path.dirname(this.dbFilePath);
    
    // Ensure data directory exists
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    fs.writeFileSync(this.dbFilePath, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  async shutdown(): Promise<void> {
    try {
      this.close();
      console.log('Database closed successfully');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
}

// Singleton instance
export const dbManager = new DatabaseManager();

// Graceful shutdown handler
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, closing database...');
  await dbManager.shutdown();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, closing database...');
  await dbManager.shutdown();
  process.exit(0);
});