import express, { Request, Response, Application } from 'express';
import * as path from 'path';
import DatabaseHandler from './db';
import { Routes } from './routes';

class Server {
  private app: Application;
  private db: DatabaseHandler;
  private routes: Routes;
  private port: number;

  constructor() {
    this.app = express();
    this.port = parseInt(process.env.PORT || '3535', 10);
    this.db = new DatabaseHandler();
    this.routes = new Routes(this.db);
    
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    // EJS setup
    this.app.set('views', path.join(process.cwd(), 'views'));
    this.app.set('view engine', 'ejs');

    // Static files
    this.app.use('/public', express.static(path.join(process.cwd(), 'public')));

    // Body parsing
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
  }

  private setupRoutes(): void {
    this.app.get('/', (req: Request, res: Response) => {
      this.routes.renderForm(req, res);
    });

    this.app.post('/submit', (req: Request, res: Response) => {
      this.routes.handleSubmission(req, res);
    });

    this.app.get('/thank-you', (req: Request, res: Response) => {
      this.routes.renderThankYou(req, res);
    });
  }

  async start(): Promise<void> {
    try {
      await this.db.initialize();
      console.log('Database initialized successfully');

      this.app.listen(this.port, () => {
        console.log(`Server is running on port ${this.port}`);
      });
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  async stop(): Promise<void> {
    await this.db.close();
    console.log('Server stopped gracefully');
  }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await server.stop();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await server.stop();
  process.exit(0);
});

const server = new Server();

if (require.main === module) {
  server.start().catch(console.error);
}

export default Server;
