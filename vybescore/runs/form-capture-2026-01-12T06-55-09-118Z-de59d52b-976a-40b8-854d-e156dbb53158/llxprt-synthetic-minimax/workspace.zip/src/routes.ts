import { Request, Response } from 'express';
import DatabaseHandler from './db';
import { Validator, FormData } from './validation';

export class Routes {
  private db: DatabaseHandler;

  constructor(db: DatabaseHandler) {
    this.db = db;
  }

  async renderForm(req: Request, res: Response): Promise<void> {
    const body = req.body as Record<string, unknown> || {};
    const errors = (body.errors as Record<string, string>) || {};
    const values = (body.values as Record<string, string>) || {};

    res.render('contact-form', {
      title: 'Contact Form - Definitely Not A Scam',
      errors,
      values
    });
  }

  async handleSubmission(req: Request, res: Response): Promise<void> {
    try {
      const formData: FormData = {
        firstName: req.body['first-name']?.toString().trim() || '',
        lastName: req.body['last-name']?.toString().trim() || '',
        streetAddress: req.body['street-address']?.toString().trim() || '',
        city: req.body['city']?.toString().trim() || '',
        stateProvince: req.body['state-province']?.toString().trim() || '',
        postalCode: req.body['postal-code']?.toString().trim() || '',
        country: req.body['country']?.toString().trim() || '',
        email: req.body['email']?.toString().trim() || '',
        phone: req.body['phone']?.toString().trim() || ''
      };

      const validation = Validator.validateForm(formData);

      if (!validation.isValid) {
        // Re-render form with errors and previous values
        res.status(400).render('contact-form', {
          title: 'Contact Form - Please Fix Errors',
          errors: validation.errors,
          values: formData
        });
        return;
      }

      // Insert into database
      await this.db.insertSubmission(formData);

      // Redirect to thank you page
      res.redirect(302, '/thank-you');
    } catch (error) {
      console.error('Error handling submission:', error);
      res.status(500).render('contact-form', {
        title: 'Contact Form - Error',
        errors: { general: 'An error occurred. Please try again.' },
        values: req.body
      });
    }
  }

  async renderThankYou(req: Request, res: Response): Promise<void> {
    res.render('thank-you', {
      title: 'Thank You! - We\'ll Be In Touch (Forever)',
      message: 'Why did you give your information to a stranger on the internet? You might receive some very persistent marketing emails from us!'
    });
  }
}