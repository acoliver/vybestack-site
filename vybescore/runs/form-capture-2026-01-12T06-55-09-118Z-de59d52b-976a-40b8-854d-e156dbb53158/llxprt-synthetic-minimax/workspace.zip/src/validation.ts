export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export class Validator {
  static validateForm(data: FormData): ValidationResult {
    const errors: Record<string, string> = {};

    // Required field validation
    const requiredFields: Array<keyof FormData> = [
      'firstName',
      'lastName', 
      'streetAddress',
      'city',
      'stateProvince',
      'postalCode',
      'country',
      'email',
      'phone'
    ];

    requiredFields.forEach(field => {
      const value = data[field].trim();
      if (!value) {
        errors[field] = 'This field is required';
      }
    });

    // Email validation
    if (data.email && !this.isValidEmail(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    // Phone validation
    if (data.phone && !this.isValidPhone(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }

    // Postal code validation
    if (data.postalCode && !this.isValidPostalCode(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  private static isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email.trim());
  }

  private static isValidPhone(phone: string): boolean {
    // Remove all non-digit, non-space, non-parenthesis, non-dash, non-plus characters
    const cleaned = phone.trim().replace(/[^\d\s+\-()]/g, '');
    // Basic validation: should have at least 7 digits
    const digitCount = (cleaned.match(/\d/g) || []).length;
    return digitCount >= 7 && digitCount <= 15;
  }

  private static isValidPostalCode(postalCode: string): boolean {
    // Accept alphanumeric strings, letters, digits, spaces, dashes
    const postalRegex = /^[A-Za-z0-9\s\-.]{3,10}$/;
    return postalRegex.test(postalCode.trim());
  }
}