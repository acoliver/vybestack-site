import { ReportData, Formatter } from '../types.js';

export class TextFormatter implements Formatter {
  format(data: ReportData, includeTotals: boolean): string {
    const lines: string[] = [];
    
    // Title (plain text)
    lines.push(data.title);
    lines.push(''); // Blank line
    
    // Summary
    lines.push(data.summary);
    lines.push(''); // Blank line
    
    // Entries heading
    lines.push('Entries:');
    
    // Add each entry as a bullet point with label and dollar amount
    for (const entry of data.entries) {
      const amount = entry.amount.toFixed(2);
      lines.push(`- ${entry.label}: $${amount}`);
    }
    
    // Add totals if requested
    if (includeTotals) {
      lines.push(''); // Blank line before total
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push(`Total: $${total.toFixed(2)}`);
    }
    
    return lines.join('\n');
  }
}