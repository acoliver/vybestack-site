import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';
import { MarkdownFormatter } from '../formats/markdown.js';
import { TextFormatter } from '../formats/text.js';

function parseArguments(args: string[]): CliOptions {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[0];
  const cliOptions: Partial<CliOptions> = { includeTotals: false };

  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          throw new Error('--format requires a value');
        }
        cliOptions.format = args[i + 1] as 'markdown' | 'text';
        i++; // Skip next argument as it's the format value
        break;
      case '--output':
        if (i + 1 >= args.length) {
          throw new Error('--output requires a value');
        }
        cliOptions.outputPath = args[i + 1];
        i++; // Skip next argument
        break;
      case '--includeTotals':
        cliOptions.includeTotals = true;
        break;
      default:
        // Ignore unknown arguments for now
        break;
    }
  }

  // Validate required options
  if (!cliOptions.format) {
    throw new Error('--format is required');
  }

  if (cliOptions.format !== 'markdown' && cliOptions.format !== 'text') {
    throw new Error(`Unsupported format: ${cliOptions.format}`);
  }

  return {
    dataPath,
    format: cliOptions.format,
    outputPath: cliOptions.outputPath,
    includeTotals: cliOptions.includeTotals || false,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing required field "title"');
  }

  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing required field "summary"');
  }

  if (!obj.entries || !Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing required field "entries" (must be an array)');
  }

  // Validate each entry
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i] as Record<string, unknown>;
    
    if (!entry.label || typeof entry.label !== 'string') {
      throw new Error(`Invalid JSON: entry[${i}] missing required field "label"`);
    }
    
    if (typeof entry.amount !== 'number') {
      throw new Error(`Invalid JSON: entry[${i}] missing required field "amount" (must be a number)`);
    }
  }

  return data as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContent);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        throw new Error(`File not found: ${filePath}`);
      }
      if (error.message.includes('JSON')) {
        throw new Error(`Invalid JSON in ${filePath}: ${error.message}`);
      }
      throw new Error(`Error reading ${filePath}: ${error.message}`);
    }
    throw new Error(`Error reading ${filePath}: ${error}`);
  }
}

function getFormatter(format: string) {
  switch (format) {
    case 'markdown':
      return new MarkdownFormatter();
    case 'text':
      return new TextFormatter();
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(args: string[]): void {
  try {
    const options = parseArguments(args);
    const reportData = loadReportData(options.dataPath);
    const formatter = getFormatter(options.format);
    
    const output = formatter.format(reportData, options.includeTotals);
    
    if (options.outputPath) {
      writeFileSync(options.outputPath, output);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : error}`);
    process.exit(1);
  }
}

// Main entry point
if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  main(args);
}

export { parseArguments, validateReportData, loadReportData, getFormatter };
