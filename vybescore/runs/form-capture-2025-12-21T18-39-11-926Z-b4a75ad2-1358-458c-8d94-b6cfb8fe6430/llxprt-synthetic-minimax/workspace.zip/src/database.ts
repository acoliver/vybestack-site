import initSqlJs, { SqlJsStatic, Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_zip_code: string;
  country: string;
  email: string;
  phone_number: string;
  created_at?: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;

  constructor(dbPath: string = 'data/submissions.sqlite') {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    this.sqlJs = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    if (this.sqlJs == null) {
      throw new Error('Failed to initialize SQL.js');
    }

    if (fs.existsSync(this.dbPath)) {
      const fileBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(fileBuffer);
    } else {
      this.db = new this.sqlJs.Database();
      await this.createTables();
    }
  }

  private async createTables(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    this.db.exec(schema);
    this.saveToDisk();
  }

  async insertSubmission(submission: Omit<Submission, 'id' | 'created_at'>): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_zip_code, country, 
        email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province_region,
      submission.postal_zip_code,
      submission.country,
      submission.email,
      submission.phone_number
    ]);

    stmt.free();
    this.saveToDisk();

    // Get the last inserted row ID
    const result = this.db.exec('SELECT last_insert_rowid() as id');
    if (result.length === 0 || result[0].values.length === 0) {
      throw new Error('Failed to get last inserted row ID');
    }
    return result[0].values[0][0] as number;
  }

  private saveToDisk(): void {
    if (!this.db) throw new Error('Database not initialized');

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const databaseManager = new DatabaseManager();