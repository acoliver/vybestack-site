export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

export interface ContactFormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export class ContactFormValidator {
  private static emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  private static phoneRegex = /^\+?[\d\s\-()]+$/;

  static validate(data: ContactFormData): ValidationResult {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: (keyof ContactFormData)[] = [
      'firstName',
      'lastName', 
      'streetAddress',
      'city',
      'stateProvinceRegion',
      'postalZipCode',
      'country',
      'email',
      'phoneNumber'
    ];

    requiredFields.forEach(field => {
      const value = data[field]?.trim();
      if (!value) {
        errors.push({
          field,
          message: `${this.getFieldLabel(field)} is required`
        });
      }
    });

    // Email validation
    if (data.email && data.email.trim()) {
      if (!this.emailRegex.test(data.email.trim())) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation
    if (data.phoneNumber && data.phoneNumber.trim()) {
      const phone = data.phoneNumber.trim();
      // Remove all non-digit characters except +, spaces, parentheses, and dashes
      const cleanPhone = phone.replace(/[^\d\s\-()]+/g, '');
      
      if (!this.phoneRegex.test(cleanPhone)) {
        errors.push({
          field: 'phoneNumber',
          message: 'Please enter a valid phone number (digits, spaces, parentheses, dashes, and + allowed)'
        });
      }
      
      // Check if there's at least 7 digits
      const digitCount = (phone.match(/\d/g) || []).length;
      if (digitCount < 7) {
        errors.push({
          field: 'phoneNumber',
          message: 'Phone number must contain at least 7 digits'
        });
      }
    }

    // Postal code validation - alphanumeric, allows UK format "SW1A 1AA"
    if (data.postalZipCode && data.postalZipCode.trim()) {
      const postalCode = data.postalZipCode.trim();
      const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
      
      if (!postalRegex.test(postalCode)) {
        errors.push({
          field: 'postalZipCode',
          message: 'Please enter a valid postal/zip code (3-10 alphanumeric characters)'
        });
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private static getFieldLabel(field: keyof ContactFormData): string {
    const labels: Record<keyof ContactFormData, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvinceRegion: 'State / Province / Region',
      postalZipCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phoneNumber: 'Phone number'
    };

    return labels[field];
  }
}