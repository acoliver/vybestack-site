import express, { Request, Response } from 'express';
import path from 'path';
import { ContactFormValidator, ContactFormData } from './validation';
import { databaseManager, Submission } from './database';

const app = express();
const PORT = process.env.PORT || 3535;

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'dist', 'views'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'dist', 'public')));

// GET / - Contact form page
app.get('/', (req: Request, res: Response) => {
  res.render('contact', {
    errors: [],
    formData: {},
    title: 'Friendly Contact Form'
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: ContactFormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalZipCode: req.body.postalZipCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phoneNumber: req.body.phoneNumber || ''
    };

    const validationResult = ContactFormValidator.validate(formData);

    if (!validationResult.isValid) {
      // Re-render form with errors and previously entered values
      return res.status(400).render('contact', {
        errors: validationResult.errors,
        formData,
        title: 'Friendly Contact Form'
      });
    }

    // Convert form data to database submission format
    const submission: Omit<Submission, 'id' | 'created_at'> = {
      first_name: formData.firstName.trim(),
      last_name: formData.lastName.trim(),
      street_address: formData.streetAddress.trim(),
      city: formData.city.trim(),
      state_province_region: formData.stateProvinceRegion.trim(),
      postal_zip_code: formData.postalZipCode.trim(),
      country: formData.country.trim(),
      email: formData.email.trim(),
      phone_number: formData.phoneNumber.trim()
    };

    // Insert into database
    await databaseManager.insertSubmission(submission);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Something went wrong. Please try again later.'
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Error handler
app.use((error: Error, req: Request, res: Response) => {
  console.error('Error:', error);
  res.status(500).render('error', {
    title: 'Error',
    message: 'Something went wrong. Please try again later.'
  });
});

// Graceful shutdown handling
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  databaseManager.close();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  databaseManager.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await databaseManager.initialize();
    
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
