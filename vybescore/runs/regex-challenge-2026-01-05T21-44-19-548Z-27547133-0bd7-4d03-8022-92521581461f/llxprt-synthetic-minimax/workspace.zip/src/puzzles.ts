/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Split text into words and check each word
  const words = text.match(/\b\w+\b/g) || [];

  // Find words starting with prefix (case insensitive)
  const prefixedWords = words.filter(word => 
    word.toLowerCase().startsWith(prefix.toLowerCase())
  );

  // Filter out exceptions (case insensitive)
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));

  return prefixedWords.filter(word => {
    return !exceptionsSet.has(word.toLowerCase());
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to match token that appears after a digit and not at the beginning
  const contextPattern = new RegExp(`(\\d)${token}`, 'g');
  const contextMatches = text.match(contextPattern);

  if (!contextMatches) return [];

  // Extract the full occurrences (digit + token)
  return contextMatches.map(match => match);
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=[\]{};':"|,.<>?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // This regex looks for any immediate 2+ character sequence that repeats
  const hasRepeatedSequences = /(.+)\1/.test(value);
  
  if (hasRepeatedSequences) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if the string contains typical IPv4 pattern
  const hasIPv4 = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/.test(value);
  
  // If it contains IPv4 pattern, we should NOT match as IPv6
  if (hasIPv4) {
    // However, IPv6 can contain IPv4 notation in the last part
    // So we need to be more specific - if the string is ONLY IPv4, return false
    const onlyIPv4 = /^[\s]*\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}[\s]*$/.test(value);
    if (onlyIPv4) {
      return false;
    }
  }
  
  // Check for IPv6 specific patterns
  const hasIPv6Specific = /[\s]*[0-9a-fA-F]*:[\s]*[0-9a-fA-F]*/.test(value);
  
  if (hasIPv6Specific) {
    // Check if this looks like IPv6 and not IPv4
    const containsColon = /:/.test(value);
    const hasHexDigits = /[0-9a-fA-F]/.test(value);
    
    if (containsColon && hasHexDigits) {
      // Additional check: IPv6 should not be ONLY IPv4-like pattern
      const specificIPv6Pattern = /(?<![\d.])[\s]*[0-9a-fA-F:]{3,}[\s]*(?![\d.]*\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}[\s]*$)/;
      const looksIPv6 = specificIPv6Pattern.test(value);
      return looksIPv6;
    }
  }
  
  return false;
}
