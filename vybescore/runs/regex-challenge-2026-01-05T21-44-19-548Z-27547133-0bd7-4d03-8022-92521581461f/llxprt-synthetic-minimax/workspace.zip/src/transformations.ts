/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Normalize spacing - replace multiple spaces with single spaces, but preserve sentence boundaries
  let normalized = text.replace(/\s+/g, ' ').trim();

  if (!normalized) return '';

  // First capitalize the very first character if it's lowercase
  normalized = normalized.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());

  // Pattern to match sentence endings followed by the next sentence
  // This captures: end of sentence (., ?, !) followed by (optional spaces) then next word starting with lowercase
  const sentencePattern = /([.!?])(\s*)([a-z])/g;

  return normalized.replace(sentencePattern, (match, punctuation, spacing, letter) => {
    // Capitalize the letter and ensure exactly one space after punctuation
    return punctuation + ' ' + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs (http/https) including dots in domains
  // Stop at trailing punctuation (space, comma, semicolon, colon, exclamation, question mark)
  const urlPattern = /https?:\/\/[^\s,;:!?]+/gi;

  const matches = text.match(urlPattern);
  if (!matches) return [];

  // Remove trailing punctuation only
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Pattern to match http URLs (not https) specifically
  const httpPattern = /http:\/\//gi;

  // Replace http:// with https://, leaving https:// unchanged
  return text.replace(httpPattern, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs and capture host and path
  const httpUrlPattern = /http:\/\/([^/\s]+)([^\s]*)/gi;
  return text.replace(httpUrlPattern, (match, host, path) => {
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /[?&]/.test(path) || /[=&]/.test(path) || /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/i.test(path) || /cgi-bin/i.test(path);

    // Check if path begins with /docs/
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Replace host with docs.example.com and upgrade scheme
      return 'https://docs.example.com' + path;
    } else {
      // Just upgrade scheme to https://
      return 'https://' + host + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[month - 1];

  // Handle leap year for February
  if (month === 2) {
    const isLeapYear = parseInt(year, 10) % 4 === 0 && (parseInt(year, 10) % 100 !== 0 || parseInt(year, 10) % 400 === 0);
    const febMaxDay = isLeapYear ? 29 : 28;
    if (day < 1 || day > febMaxDay) {
      return 'N/A';
    }
  } else {
    if (day < 1 || day > maxDay) {
      return 'N/A';
    }
  }

  return year;
}
