export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  void _options;
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for proper length (10 or 11 digits with +1)
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // Remove country code for area code check
    const localDigits = digitsOnly.substring(1);
    const areaCode = localDigits.substring(0, 3);
    
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') {
      return false;
    }
    return localDigits.length === 10;
  } else if (digitsOnly.length === 10) {
    const areaCode = digitsOnly.substring(0, 3);
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') {
      return false;
    }
    return true;
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators and punctuation, keep only digits and relevant symbols
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern to match Argentine phone numbers
  // Group 1: Optional +54 country code
  // Group 2: Optional 9 (mobile indicator)
  // Group 3: Optional 0 (trunk prefix)
  // Group 4: Area code (2-4 digits, first 1-9)
  // Group 5: Subscriber number (remaining digits, total 6-8)
  const argentinaPhoneRegex = /^(?:\+54)?(?:\d{9})?0?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinaPhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate total subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If no country code, must start with trunk prefix 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, spaces, apostrophes, hyphens
  // Reject digits and special symbols like X Æ A-12
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  // Must have at least one letter
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with digits or obvious special symbols
  if (/[\d]/.test(value)) {
    return false;
  }
  
  // Reject X Æ A-12 style names specifically
  if (/[XÆA-]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  const digits = value.replace(/\s|-/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(digits)) {
    return false;
  }

  // Check card types and their patterns
  let cardValid = false;

  // Visa: starts with 4, length 13, 16, or 19
  if (/^4\d{12,18}$/.test(digits)) {
    cardValid = true;
  }
  // MasterCard: 51-55 or 2221-2720, length 16
  else if ((/^5[1-5]\d{14}$/.test(digits)) || (/^2[2-7][2-7]\d{12}$/.test(digits))) {
    cardValid = true;
  }
  // American Express: 34 or 37, length 15
  else if (/^3[47]\d{13}$/.test(digits)) {
    cardValid = true;
  }

  // Must pass Luhn checksum
  if (cardValid) {
    return runLuhnCheck(digits);
  }

  return false;
}
