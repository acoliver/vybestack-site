# Simple fix for the hasSymbol line in puzzles.ts
with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2026-01-05T21-44-19-548Z-27547133-0bd7-4d03-8022-92521581461f/src/puzzles.ts', 'r') as f:
    content = f.read()

# Replace the exact line that has the problematic escape
content = content.replace(
    "const hasSymbol = /[!@#$%^&*()_+=[\\]{};':\\\"|,.<>\\/?]/.test(value);",
    "const hasSymbol = /[!@#$%^&*()_+=[\]{};':\"|,.<>\/?]/.test(value);"
)

with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2026-01-05T21-44-19-548Z-27547133-0bd7-4d03-8022-92521581461f/src/puzzles.ts', 'w') as f:
    f.write(content)

# Also fix transformations.ts  
with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2026-01-05T21-44-19-548Z-27547133-0bd7-4d03-8022-92521581461f/src/transformations.ts', 'r') as f:
    content = f.read()

# Replace the problematic line
content = content.replace(
    "const httpUrlPattern = /http:\/\/([^\/\s]+)([^\s]*)/gi;",
    "const httpUrlPattern = /http:\/\/([^\/\s]+)([^\s]*)/gi;"
)

with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2026-01-05T21-44-19-548Z-27547133-0bd7-4d03-8022-92521581461f/src/transformations.ts', 'w') as f:
    f.write(content)