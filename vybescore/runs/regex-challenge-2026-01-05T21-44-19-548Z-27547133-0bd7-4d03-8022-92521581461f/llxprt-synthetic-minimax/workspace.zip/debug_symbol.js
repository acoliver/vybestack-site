// Simple debug script to test symbol pattern
console.log('Testing symbol patterns...');

// Different ways to write the pattern
const patterns = [
  '/[!@#$%^&*()_+=[\\]{};':"|,.<>?]/',
  '/[!@#$%^&*()_+\-=\[\]{};':"|,.<>?]/',
  '/[!@#$%^&*()_+=[\\]{};':"|,.<>?]/',
  '/[!@#$%^&*()_+=[\]{};':"|,.<>?]/'
];

const testPassword = 'Abcdef!234';

patterns.forEach((patternStr, i) => {
  console.log(`\nPattern ${i + 1}: ${patternStr}`);
  try {
    const pattern = new RegExp(patternStr.slice(1, -1)); // Remove / delimiters
    console.log('  Compiled successfully');
    console.log('  Source:', pattern.source);
    console.log('  Test result:', pattern.test(testPassword));
  } catch (e) {
    console.log('  Error:', e.message);
  }
});

console.log('\nDirect pattern tests:');
try {
  const directPattern = /[!@#$%^&*()_+=[\\]{};':"|,.<>?]/;
  console.log('Direct pattern test:', directPattern.test('Abcdef!234'));
  console.log('Direct pattern source:', directPattern.source);
} catch (e) {
  console.log('Direct pattern error:', e.message);
}