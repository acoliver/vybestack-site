with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2026-01-05T21-44-19-548Z-27547133-0bd7-4d03-8022-92521581461f/src/puzzles.ts', 'r') as f:
    lines = f.readlines()

# Replace line 53 - remove all unnecessary escapes according to ESLint no-useless-escape
# In character classes: [ ] and / don't need escaping, only - needs escaping when it's a range
lines[52] = "  const hasSymbol = /[!@#\$%^&*()_+=[\]{};:'\"|,.<>\/?]/.test(value);\n"

with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2026-01-05T21-44-19-548Z-27547133-0bd7-4d03-8022-92521581461f/src/puzzles.ts', 'w') as f:
    f.writelines(lines)