# Comprehensive fix for all lint issues
with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2026-01-05T21-44-19-548Z-27547133-0bd7-4d03-8022-92521581461f/src/puzzles.ts', 'r') as f:
    lines = f.readlines()

# Fix line 53 - remove all unnecessary escapes according to ESLint no-useless-escape
# In character classes: $ doesn't need escaping, / doesn't need escaping
# Only ] needs escaping when we want to include it as a literal
lines[52] = "  const hasSymbol = /[!@#$%^&*()_+=[\]{};':\"|,.<>\/?]/.test(value);\n"

with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2026-01-05T21-44-19-548Z-27547133-0bd7-4d03-8022-92521581461f/src/puzzles.ts', 'w') as f:
    f.writelines(lines)

# Fix transformations.ts - remove unnecessary / escape
with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2026-01-05T21-44-19-548Z-27547133-0bd7-4d03-8022-92521581461f/src/transformations.ts', 'r') as f:
    content = f.read()

# Fix line 54 - remove unnecessary / escape  
lines = content.split('\n')
for i, line in enumerate(lines):
    if 'httpUrlPattern =' in line:
        lines[i] = "  const httpUrlPattern = /http:\/\/([^\/\s]+)([^\s]*)/gi;"
        break

with open('/home/runner/work/vybestack-site/vybestack-site/evals/outputs/regex-challenge-2026-01-05T21-44-19-548Z-27547133-0bd7-4d03-8022-92521581461f/src/transformations.ts', 'w') as f:
    f.write('\n'.join(lines))