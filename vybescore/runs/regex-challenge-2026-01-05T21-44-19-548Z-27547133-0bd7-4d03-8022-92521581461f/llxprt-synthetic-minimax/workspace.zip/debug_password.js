// Debug script to test the isStrongPassword function
function runLuhnCheck(cardNumber) {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

// Copy of the isStrongPassword function from puzzles.ts
function isStrongPassword(value) {
  console.log('Testing password:', value);
  
  // Check minimum length (at least 10 characters)
  if (value.length < 10) {
    console.log('Failed: length < 10');
    return false;
  }
  console.log('[OK] Length check passed');

  // Check for whitespace
  if (/\s/.test(value)) {
    console.log('Failed: has whitespace');
    return false;
  }
  console.log('[OK] No whitespace check passed');

  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=[\\]{};':\\"|,.<>?]/.test(value);
  
  console.log('Has uppercase:', hasUppercase);
  console.log('Has lowercase:', hasLowercase);
  console.log('Has digit:', hasDigit);
  console.log('Has symbol:', hasSymbol);

  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    console.log('Failed: missing character types');
    return false;
  }
  console.log('[OK] Character type checks passed');

  // Check for immediate repeated sequences (e.g., abab)
  // This regex looks for any immediate 2+ character sequence that repeats
  const hasRepeatedSequences = /(.+)\\1/.test(value);
  
  console.log('Has repeated sequences:', hasRepeatedSequences);

  if (hasRepeatedSequences) {
    console.log('Failed: has repeated sequences');
    return false;
  }
  
  console.log('[OK] All checks passed - returning true');
  return true;
}

// Test the function
const testPassword = 'Abcdef!234';
console.log('=== Testing isStrongPassword ===');
const result = isStrongPassword(testPassword);
console.log('Final result:', result);
console.log('Expected: true');
console.log('Match:', result === true);