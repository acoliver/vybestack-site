/**
 * Find words starting with the prefix, excluding words in the exceptions list.
 * Words are sequences of word characters (letters, digits, underscores).
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: word boundary, prefix, followed by word characters
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    const word = match[0];
    // Check if this word is in the exceptions list (case-insensitive)
    const isException = exceptions.some(exc => exc.toLowerCase() === word.toLowerCase());
    
    if (!isException) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of a token that appear after a digit.
 * The token must not be at the start of the string.
 * Uses lookahead/lookbehind for context matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token, with word boundaries
  // Match the digit + token together
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validate password strength.
 * Requirements:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., 'abab' should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., 'abab', '123123')
  // Look for patterns where a 2-4 character sequence repeats immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const seq1 = value.slice(i, i + len);
      const seq2 = value.slice(i + len, i + 2 * len);
      
      if (seq1 === seq2) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses, including shorthand notation with ::.
 * Must not detect IPv4 addresses.
 * Supports:
 * - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
 * - Shorthand: 2001:db8::1, ::1, 2001::db8:1
 * - Mixed IPv4 embedded: ::ffff:192.0.2.1 (but not plain IPv4)
 */
export function containsIPv6(value: string): boolean {
  // First, filter out plain IPv4 addresses
  // IPv4 pattern: four groups of 1-3 digits separated by dots
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 patterns - look for IPv6 in the text
  // Full form: 8 groups of 1-4 hex digits separated by colons
  const ipv6FullPattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Shorthand with :: (can replace one or more consecutive groups of zeros)
  // Must have at least one colon, and :: appears at most once
  const ipv6ShorthandPattern = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)[0-9a-fA-F]{0,4}/;
  
  // Special case: starts or ends with ::
  const ipv6EdgePattern = /::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}::/;
  
  // Loopback ::1
  const ipv6Loopback = /::$|::1/;
  
  // Check all patterns - look for match anywhere in the string
  return ipv6FullPattern.test(value) ||
         ipv6ShorthandPattern.test(value) ||
         ipv6EdgePattern.test(value) ||
         ipv6Loopback.test(value);
}
