/**
 * Capitalize the first character of each sentence.
 * Sentences end with .!?, optionally followed by quotes.
 * Insert exactly one space between sentences.
 * Collapse extra spaces while preserving single spaces between words.
 * Preserve abbreviations when possible (single letter followed by period).
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: replace multiple spaces with single space
  let normalized = text.replace(/ +/g, ' ').trim();
  
  // Ensure one space after sentence-ending punctuation
  // Match sentence end (. ! ?) followed by optional closing quote, then not space
  normalized = normalized.replace(/([.!?])(['"]?)(\S)/g, '$1$2 $3');
  
  // Now capitalize first character of each sentence
  // A sentence starts at the beginning of the string or after sentence-ending punctuation
  const sentences: string[] = [];
  let sentenceStart = 0;
  
  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    
    // Check if this is a sentence end
    if (char === '.' || char === '!' || char === '?') {
      // Find the end of this sentence (next sentence start or end of string)
      let j = i + 1;
      // Skip past optional closing quotes
      while (j < normalized.length && /['"]/.test(normalized[j])) {
        j++;
      }
      // Skip past whitespace
      while (j < normalized.length && /\s/.test(normalized[j])) {
        j++;
      }
      
      // Extract the sentence (including the ending punctuation)
      sentences.push(normalized.slice(sentenceStart, j));
      sentenceStart = j;
    }
  }
  
  // Add the last sentence if there's remaining text
  if (sentenceStart < normalized.length) {
    sentences.push(normalized.slice(sentenceStart));
  }
  
  // Capitalize each sentence
  const result = sentences.map((sentence) => {
    if (sentence.length === 0) return sentence;
    
    // Find the first alphabetic character
    let firstAlpha = 0;
    while (firstAlpha < sentence.length && !/[a-zA-Z]/.test(sentence[firstAlpha])) {
      firstAlpha++;
    }
    
    if (firstAlpha < sentence.length && firstAlpha > 0) {
      // Capitalize the first alphabetic character
      return (
        sentence.slice(0, firstAlpha) +
        sentence[firstAlpha].toUpperCase() +
        sentence.slice(firstAlpha + 1)
      );
    } else if (firstAlpha === 0) {
      // First character is already alphabetic
      return sentence[0].toUpperCase() + sentence.slice(1);
    }
    
    return sentence;
  }).join('');
  
  return result;
}

/**
 * Extract all URLs from text, excluding trailing punctuation.
 * Matches http://, https://, and www. patterns.
 */
export function extractUrls(text: string): string[] {
  // URL pattern with optional trailing punctuation exclusion
  // Match: protocol://domain/path or www.domain/path
  // Exclude: trailing punctuation like .,?!;:) but keep valid URL characters
  const urlPattern = /(?:https?:\/\/|www\.)[^\s<>"'`(){}[\]\\]+(?:\/[^\s<>"'`(){}[\]\\]*)?(?<![,.!?;)])/gi;
  
  const matches: string[] = [];
  let match;
  
  // Using exec in a loop to get all matches
  const regex = new RegExp(urlPattern.source, urlPattern.flags);
  while ((match = regex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation that might have been captured
    url = url.replace(/[,.!?;)+]+$/, '');
    
    // Ensure www URLs have http:// prefix for consistency
    if (url.startsWith('www.') && !url.startsWith('http')) {
      url = 'http://' + url;
    }
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * Force all http:// URLs to https://.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for paths with dynamic hints: cgi-bin, query strings, legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern for example.com URLs
  // Match: http://example.com or https://example.com
  // Capture the path for analysis
  const urlPattern = /(https?):\/\/(example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, protocol, domain, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Check if we should skip docs rewrite
    // Skip if path contains: cgi-bin, query strings, or legacy extensions
    const skipRewrite = 
      path.includes('cgi-bin') ||
      path.includes('?') ||
      path.includes('&') ||
      path.includes('=') ||
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/i.test(path);
    
    // Check if path starts with /docs/
    const isDocsPath = path.startsWith('/docs/');
    
    if (isDocsPath && !skipRewrite) {
      // Rewrite to docs.example.com
      return `${newProtocol}://docs.example.com${path}`;
    } else {
      // Just upgrade the protocol
      return `${newProtocol}://${domain}${path}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy format strings.
 * Returns 'N/A' if format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
