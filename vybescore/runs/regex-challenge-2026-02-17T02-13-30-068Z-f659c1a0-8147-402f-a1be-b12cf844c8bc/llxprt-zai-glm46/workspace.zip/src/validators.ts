export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses according to RFC 5322 with additional restrictions.
 * Accepts typical addresses like 'name@tag@example.co.uk' (with @ signs allowed in local part if quoted).
 * Rejects: double dots, trailing dots, domains with underscores, invalid TLDs.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure: local@domain
  // Local part can be quoted or unquoted
  // Domain cannot have underscores, no consecutive dots, no trailing dots
  
  // Quick rejection for obvious invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Check if domain contains underscore
  const atIndex = value.lastIndexOf('@');
  if (atIndex === -1 || atIndex === value.length - 1) {
    return false;
  }
  
  const domain = value.slice(atIndex + 1);
  if (domain.includes('_')) {
    return false;
  }
  
  // Validate domain part structure
  const domainLabels = domain.split('.');
  if (domainLabels.length < 2) {
    return false;
  }
  
  for (const label of domainLabels) {
    if (!label || label.startsWith('-') || label.endsWith('-')) {
      return false;
    }
    if (!/^[a-zA-Z0-9-]+$/.test(label)) {
      return false;
    }
  }
  
  // TLD must be at least 2 chars and only letters
  const tld = domainLabels[domainLabels.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }
  
  // Basic email structure validation (simplified from RFC 5322)
  // Local part: alphanumeric with some special characters
  // Domain: standard domain format
  const emailPattern = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  return emailPattern.test(value);
}

/**
 * Validate US phone numbers supporting common formats.
 * Formats: (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix allowed
 * Area code cannot start with 0 or 1
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  }
  
  // Now remove any leading 1 if we have enough digits
  if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.slice(1);
  }
  
  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * Landlines: +54 341 123 4567, 0341 4234567
 * Mobiles: +54 9 11 1234 5678, 011 1234 5678
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code (required if country code omitted)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, must start with 1-9
 * - Subscriber number: 6-8 digits
 * - Separators: single spaces or hyphens allowed
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces and hyphens) but keep + for country code
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Parse the components
  // Pattern: [+54][0][9][area code][subscriber number]
  // Area code is 2-4 digits starting with 1-9
  // Subscriber is 6-8 digits
  
  let hasCountryCode = false;
  let remaining = cleaned;
  
  // Check for +54 country code
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.slice(3);
  }
  
  // Check for trunk prefix 0 (required if no country code)
  if (remaining.startsWith('0')) {
    remaining = remaining.slice(1);
  } else if (!hasCountryCode) {
    // Without country code, must have trunk prefix
    return false;
  }
  
  // Check for mobile prefix 9 (capture but don't need to use)
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Remaining should be area code + subscriber number
  // Area code: 2-4 digits, starts with 1-9
  // Subscriber: 6-8 digits
  // Total: 8-12 digits
  
  if (!/^\d{8,12}$/.test(remaining)) {
    return false;
  }
  
  // Try to split area code from subscriber number
  // Area code can be 2-4 digits
  let valid = false;
  for (const acLength of [4, 3, 2]) {
    if (remaining.length >= acLength + 6 && remaining.length <= acLength + 8) {
      const potentialAreaCode = remaining.slice(0, acLength);
      const potentialSubscriber = remaining.slice(acLength);
      
      // Area code must start with 1-9
      if (/^[1-9]\d*$/.test(potentialAreaCode)) {
        // Verify subscriber length
        if (potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
          valid = true;
          break;
        }
      }
    }
  }
  
  return valid;
}

/**
 * Validate personal names.
 * Allows: Unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: Digits, symbols, names like 'X Æ A-12'
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Trim and check for valid characters
  const trimmed = value.trim();
  
  // Check for invalid patterns like consecutive spaces or weird spacing
  if (/\s{2,}/.test(trimmed)) {
    return false;
  }
  
  // Check for digits
  if (/\d/.test(trimmed)) {
    return false;
  }
  
  // Reject obviously invalid symbols (anything not letter, apostrophe, hyphen, space)
  if (/[^\p{L}'\s-]/u.test(trimmed)) {
    return false;
  }
  
  // Pattern: must start and end with letter, can have spaces/hyphens/apostrophes in between
  const namePattern = /^[\p{L}]+(?:[\p{L}'\s-]*[\p{L}]+)?$/u;
  
  return namePattern.test(trimmed);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa (starts with 4, 13-16 digits), 
 * Mastercard (starts with 51-55 or 2221-2720, 16 digits),
 * AmEx (starts with 34 or 37, 15 digits).
 * Must pass Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length and prefix
  const isVisa = digits.length >= 13 && digits.length <= 16 && digits.startsWith('4');
  const isMastercard = digits.length === 16 && (
    (/^5[1-5]/.test(digits)) || 
    (/^(222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[0-1][0-9]|2720)/.test(digits))
  );
  const isAmEx = digits.length === 15 && (digits.startsWith('34') || digits.startsWith('37'));
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(digits);
}
