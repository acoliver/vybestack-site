#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { isSupportedFormat, formatters } from '../formatters/index.js';
import type { ReportData, RenderOptions } from '../types.js';

interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  if (!args.includes('--format')) {
    console.error('Missing required --format argument');
    process.exit(1);
  }
  
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Missing format value after --format');
    process.exit(1);
  }
  const format = args[formatIndex + 1];
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataPath,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }
  
  const { title, summary, entries } = data as Record<string, unknown>;
  
  if (typeof title !== 'string' || typeof summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(entries)) {
    return false;
  }
  
  for (const entry of entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }
    
    const { label, amount } = entry as Record<string, unknown>;
    
    if (typeof label !== 'string' || typeof amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

function main(): void {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs();
    
    // Validate format
    if (!isSupportedFormat(format)) {
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
    }
    
    // Read and parse data file
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(dataPath, 'utf8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Invalid JSON in file: ${dataPath}`);
        console.error(error.message);
      } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error(`File not found: ${dataPath}`);
      } else {
        console.error(`Error reading file: ${dataPath}`);
        console.error(error instanceof Error ? error.message : String(error));
      }
      process.exit(1);
    }
    
    // Validate data structure
    if (!validateReportData(jsonData)) {
      console.error('Invalid report data structure. Expected: { title: string, summary: string, entries: Array<{ label: string, amount: number }> }');
      process.exit(1);
    }
    
    const options: RenderOptions = { includeTotals };
    const renderedReport = formatters[format](jsonData, options);
    
    // Output to file or stdout
    if (outputPath) {
      try {
        writeFileSync(outputPath, renderedReport, 'utf8');
        console.log(`Report saved to: ${outputPath}`);
      } catch (error) {
        console.error(`Error writing to file: ${outputPath}`);
        console.error(error instanceof Error ? error.message : String(error));
        process.exit(1);
      }
    } else {
      console.log(renderedReport);
    }
  } catch (error) {
    console.error('Unexpected error:');
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();