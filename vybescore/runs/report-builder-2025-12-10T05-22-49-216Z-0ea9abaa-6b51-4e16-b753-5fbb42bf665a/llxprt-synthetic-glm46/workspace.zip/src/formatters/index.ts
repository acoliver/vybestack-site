import type { FormatType, RenderFunction } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

export const formatters: Record<FormatType, RenderFunction> = {
  markdown: renderMarkdown,
  text: renderText,
};

export const supportedFormats: FormatType[] = ['markdown', 'text'];

export function isSupportedFormat(format: string): format is FormatType {
  return supportedFormats.includes(format as FormatType);
}