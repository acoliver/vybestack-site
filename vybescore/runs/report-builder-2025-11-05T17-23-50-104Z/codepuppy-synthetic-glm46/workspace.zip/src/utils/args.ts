import { ParsedArguments } from '../types.js';

export function parseArguments(argv: string[]): ParsedArguments {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataFilePath = args[0];
  
  const parsed: ParsedArguments = {
    dataFilePath,
    format: '',
    includeTotals: false
  };
  
  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('Missing format argument after --format');
      }
      parsed.format = args[i + 1];
      i++; // Skip the format value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('Missing path argument after --output');
      }
      parsed.outputPath = args[i + 1];
      i++; // Skip the output path value
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  
  if (!parsed.format) {
    throw new Error('--format argument is required');
  }
  
  if (parsed.format !== 'markdown' && parsed.format !== 'text') {
    throw new Error(`Unsupported format: ${parsed.format}`);
  }
  
  return parsed;
}