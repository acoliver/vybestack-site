import { ReportData } from '../types.js';
import { readFileSync } from 'node:fs';

export function validateAndParseData(dataFilePath: string): ReportData {
  try {
    const fileContent = readFileSync(dataFilePath, 'utf8');
    const data = JSON.parse(fileContent);
    
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected an object');
    }
    
    if (typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field (expected string)');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field (expected string)');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field (expected array)');
    }
    
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid entry at index ${i}: expected object`);
      }
      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (expected string)`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${dataFilePath}: ${error.message}`);
    }
    throw error;
  }
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}