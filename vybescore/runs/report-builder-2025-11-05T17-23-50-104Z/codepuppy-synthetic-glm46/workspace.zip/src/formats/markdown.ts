import { Formatter, ReportData, ReportOptions } from '../types.js';
import { formatAmount, calculateTotal } from '../utils/validation.js';

const renderMarkdown: Formatter = {
  render(data: ReportData, options: ReportOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(`# ${data.title}`);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries section
    lines.push('## Entries');
    
    // Entry list
    for (const entry of data.entries) {
      lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
    }
    
    // Total if requested
    if (options.includeTotals) {
      const total = calculateTotal(data);
      lines.push(``);
      lines.push(`**Total:** ${formatAmount(total)}`);
    }
    
    return lines.join('\n');
  }
};

export { renderMarkdown };
export default renderMarkdown;