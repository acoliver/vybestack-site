export interface ReportData {
  title: string;
  summary: string;
  entries: Array<{
    label: string;
    amount: number;
  }>;
}

export interface ReportOptions {
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

export interface Formatter {
  render(data: ReportData, options: ReportOptions): string;
}

export interface ParsedArguments {
  dataFilePath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}
