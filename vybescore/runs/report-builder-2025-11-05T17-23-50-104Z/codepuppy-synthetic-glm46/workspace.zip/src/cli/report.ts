#!/usr/bin/env node

import { writeFileSync } from 'node:fs';
import { parseArguments } from '../utils/args.js';
import { validateAndParseData } from '../utils/validation.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportOptions, Formatter } from '../types.js';

const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText
};

type SupportedFormat = 'markdown' | 'text';

function isValidFormat(format: string): format is SupportedFormat {
  return format === 'markdown' || format === 'text';
}

function main(): void {
  try {
    const args = parseArguments(process.argv);
    
    // Validate format
    if (!isValidFormat(args.format)) {
      console.error(`Unsupported format: ${args.format}`);
      process.exit(1);
    }
    
    // Load and validate data
    const data = validateAndParseData(args.dataFilePath);
    
    // Prepare options - cast to SupportedFormat since we validated it
    const options: ReportOptions = {
      format: args.format as SupportedFormat,
      outputPath: args.outputPath,
      includeTotals: args.includeTotals
    };
    
    // Render report
    const formatter = formatters[args.format];
    const output = formatter.render(data, options);
    
    // Write output
    if (options.outputPath) {
      writeFileSync(options.outputPath, output, 'utf8');
    } else {
      console.log(output);
    }
    
    process.exit(0);
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();