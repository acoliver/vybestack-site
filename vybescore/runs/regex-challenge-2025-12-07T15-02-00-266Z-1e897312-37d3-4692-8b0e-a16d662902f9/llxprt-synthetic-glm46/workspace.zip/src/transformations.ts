/**
 * Capitalizes the first character of each sentence in the text.
 * Ensures exactly one space between sentences, collapses extra spaces,
 * and attempts to preserve abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Normalize spacing: replace multiple spaces with a single space
  const normalizedSpacing = text.replace(/\s+/g, ' ').trim();
  
  // Define common abbreviations to avoid splitting sentences
  const abbreviations = ['Mr.', 'Mrs.', 'Ms.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'St.', 'Mt.', 'etc.', 'e.g.', 'i.e.', 'vs.', 'U.S.', 'U.K.', 'Ph.D.'];
  
  // Build regex pattern to match sentence terminals (.?!) that aren't part of abbreviations
  const abbrevPattern = abbreviations.map(abbr => abbr.replace(/\./g, '\\.')).join('|');
  const sentenceBoundaryRegex = new RegExp(`(?<!(${abbrevPattern}))([.?!])(?!([.?!]))`, 'g');
  
  // Split by sentence boundaries
  const sentences = normalizedSpacing.split(sentenceBoundaryRegex);
  
  // Process sentences to capitalize first letter of each
  const result = [];
  let currentSentence = '';
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    // If this is a sentence boundary punctuation
    if (segment && segment.match(/[.?!]/)) {
      // Add the boundary to current sentence
      currentSentence += segment;
      
      // Capitalize the current sentence and add to result
      const trimmed = currentSentence.trim();
      if (trimmed) {
        const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
        result.push(capitalized);
      }
      
      currentSentence = '';
    } else if (segment) {
      // This is part of a sentence
      currentSentence += segment;
    }
  }
  
  // Handle the last sentence (if it doesn't end with punctuation)
  if (currentSentence.trim()) {
    const trimmed = currentSentence.trim();
    const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
    result.push(capitalized);
  }
  
  return result.join(' ');
}

/**
 * Extracts URLs from the given text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Regular expression for URL matching
  // Includes http/https protocols, domains with subdomains, and various TLDs
  // Captures the entire URL but excludes trailing punctuation
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:\:[0-9]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?(?![\w])/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  const cleanedUrls = matches.map(url => {
    // Remove common trailing punctuation
    return url.replace(/[.,;:!?]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 * Returns the modified text.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace all http:// URLs with https://, but don't double-convert https://
  const httpsRegex = /http:\/\/([^\/:])/gi;

  return text.replace(httpsRegex, 'https://$1');
}

/**
 * Rewrites URLs according to specific rules:
 * - Always upgrade to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com so the final URL becomes https://docs.example.com/...
 * - Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings (?, &, =), or legacy extensions like .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py, but still upgrade the scheme to https://
 * - Preserve nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Regex to match HTTP/HTTPS URLs
  // Captures: 1-protocol, 2-host, 3-path (optional)
  const urlRegex = /(https?):\/\/([^\/\s]+)(\/[^\s]*)?/gi;

  return text.replace(urlRegex, (match, protocol, host, path = '') => {
    // Always upgrade to HTTPS
    const newProtocol = 'https';
    
    // Default to using the original host
    let newHost = host;
    
    // Only consider rewriting if there's a path
    if (path) {
      // Check for dynamic/criteria that should prevent host rewrite
      const hasDynamicElements = /\/cgi-bin\/|\?|&|=|(.jsp|.php|.asp|.aspx|.do|.cgi|.pl|.py)(\?.*|$)/i.test(path);
      
      // If path starts with /docs/ and doesn't have dynamic elements
      if (!hasDynamicElements && /^\/docs\//.test(path)) {
        // Extract the base domain for the original host
        // Handle subdomains by keeping only the main part
        const domainParts = host.split('.');
        if (domainParts.length >= 2) {
          // If it's already a docs subdomain, don't modify
          if (!domainParts[0].includes('docs')) {
            // Reconstruct the domain with docs subdomain
            const tld = domainParts[domainParts.length - 1];
            const baseDomainName = domainParts.length > 2 
              ? domainParts.slice(1).join('.') 
              : domainParts[0] + '.' + tld;
            
            newHost = `docs.${baseDomainName}`;
          }
        } else {
          // Simple domain case, just add docs. prefix
          newHost = `docs.${host}`;
        }
      }
    }
    
    return `${newProtocol}://${newHost}${path}`;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Trim whitespace
  const trimmedValue = value.trim();
  
  // Regular expression to match mm/dd/yyyy format
  // Captures month (mm), day (dd), and year (yyyy)
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = trimmedValue.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Convert to numbers for validation
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate day based on month
  // We'll handle common month-day validations
  const maxDays = {
    1: 31, 3: 31, 5: 31, 7: 31, 8: 31, 10: 31, 12: 31,  // January, March, May, July, August, October, December
    4: 30, 6: 30, 9: 30, 11: 30,                        // April, June, September, November
    2: 29                                                 // February (we'll allow Feb 29 for leap years)
  };
  
  const maxDayForMonth = maxDays[monthNum as keyof typeof maxDays];
  if (dayNum > (maxDayForMonth || 31)) return 'N/A';
  
  // Return the year part if valid
  return year;
}