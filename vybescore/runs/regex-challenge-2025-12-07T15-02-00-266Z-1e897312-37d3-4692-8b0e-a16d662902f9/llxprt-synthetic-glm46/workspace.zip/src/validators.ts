export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Robust email validation supporting common formats.
 * Validates typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for invalid patterns
  if (!emailRegex.test(value)) return false;
  
  // Reject emails with double dots
  if (value.includes('..')) return false;
  
  // Reject emails ending with a dot
  if (value.endsWith('.')) return false;
  
  // Extract local and domain parts for additional validation
  const [localPart, domainPart] = value.split('@');
  
  // Reject domains containing underscores (not valid in hostnames)
  if (domainPart.includes('_')) return false;
  
  // Domain must have at least one dot (except for localhost which we don't allow)
  if (!domainPart.includes('.')) return false;
  
  // Local part must not start or end with a dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  return true;
}

/**
 * US phone number validation supporting common formats.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, and optional +1 prefix
 * Rejects impossible area codes (starting with 0 or 1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Strip all non-digit characters except the leading + for country code
  const digits = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 country code
  const hasCountryCode = digits.startsWith('+1');
  const phoneNumber = hasCountryCode ? digits.substring(2) : (digits.startsWith('+') ? '' : digits);
  
  // Valid US phone numbers should have exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Central office code (next 3 digits) cannot start with 0 or 1 (NPA-NXX format)
  const centralOfficeCode = phoneNumber.substring(3, 6);
  if (centralOfficeCode.startsWith('0') || centralOfficeCode.startsWith('1')) return false;
  
  // Optional: Allow extensions if specified in options
  if (options?.allowExtensions) {
    const extensionRegex = /ext\.?\s*(\d+)$/i;
    const extensionMatch = value.match(extensionRegex);
    if (extensionMatch && extensionMatch[1].length > 0) {
      // Valid extension, continue with phone validation
    }
  }
  
  // Validate the overall format
  const phoneRegex = /^(\+1[-\s]?)?(\([2-9]\d{2}\)[-.\s]?|[2-9]\d{2}[-.\s]?)\d{3}[-.\s]?\d{4}$/;
  if (!phoneRegex.test(value.trim())) return false;
  
  return true;
}

/**
 * Argentine phone number validation covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 *
 * Requirements:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must contain 6-8 digits
 * - Allow single spaces or hyphens as separators
 * - When country code is omitted, number must begin with trunk prefix 0
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for easier processing
  const cleanNumber = value.replace(/[ -]/g, '');
  
  // Argentine phone regex following the requirements
  const argentinePhoneRegex = /^(\+54)?(9?)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  const match = cleanNumber.match(argentinePhoneRegex);
  
  if (!match) return false;
  
  const [, countryCode, , areaCode, subscriberNumber] = match;
  
  // If no country code, must start with trunk prefix (0)
  if (!countryCode && !areaCode.startsWith('0')) return false;
  
  // Area code must be 2-4 digits (after removing optional 0 prefix)
  const areaCodeWithoutTrunk = areaCode.startsWith('0') ? areaCode.substring(1) : areaCode;
  if (areaCodeWithoutTrunk.length < 2 || areaCodeWithoutTrunk.length > 4) return false;
  
  // Area code leading digit must be 1-9 (not 0)
  if (!/^[1-9]/.test(areaCodeWithoutTrunk)) return false;
  
  // Subscriber number must contain 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // For format validation, let's be more flexible with separators and positioning
  // Remove spaces and hyphens for validation since we already validated structure above
  // We don't need a separate format regex as the main validation already covers this
  
  // Let's double-check the format with simpler logic
  const trimmedValue = value.trim();
  if (!trimmedValue) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove leading and trailing whitespace
  const trimmedName = value.trim();
  
  // Empty string is invalid
  if (!trimmedName) return false;
  
  // Name regex allowing unicode letters, accents, apostrophes, hyphens, and spaces
  // Includes letters from various scripts and accented characters
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}'\-\s]*[\p{L}\p{M}]$/u;
  
  if (!nameRegex.test(trimmedName)) return false;
  
  // Reject names containing digits
  if (/\d/.test(trimmedName)) return false;
  
  // Reject names with multiple spaces in a row
  if (/\s{2,}/.test(trimmedName)) return false;
  
  // Reject names with multiple special characters in sequence (like "--" or "''")
  if (/[-']{2,}/.test(trimmedName)) return false;
  
  // Reject names where special characters appear at the beginning or end
  if (/^[-']|[-']$/.test(trimmedName)) return false;
  
  // Reject names with unusual symbols that aren't apostrophes or hyphens
  if (/[^\p{L}\p{M}'\-\s]/u.test(trimmedName)) return false;
  
  return true;
}

/**
 * Validates credit card numbers using supported card prefixes/lengths and Luhn checksum.
 * Supports Visa, Mastercard, and American Express formats.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Determine card type and validate format
  let isValidFormat = false;
  
  // Visa: starts with 4, length 13 or 16
  if (cleanNumber.startsWith('4') && (cleanNumber.length === 13 || cleanNumber.length === 16)) {
    isValidFormat = true;
  }
  // Mastercard: starts with 51-55, length 16
  else if (cleanNumber.startsWith('5') && cleanNumber.length === 16) {
    const secondDigit = cleanNumber.charAt(1);
    if (secondDigit >= '1' && secondDigit <= '5') {
      isValidFormat = true;
    }
  }
  // American Express: starts with 34 or 37, length 15
  else if (cleanNumber.startsWith('34') || cleanNumber.startsWith('37')) {
    if (cleanNumber.length === 15) {
      isValidFormat = true;
    }
  }
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum validation
  return luhnCheck(cleanNumber);
}

/**
 * Performs Luhn checksum validation on a numeric string.
 */
function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  const isEven = cardNumber.length % 2 === 0;
  
  for (let i = 0; i < cardNumber.length; i++) {
    const digit = parseInt(cardNumber[i], 10);
    let digitValue = digit;
    
    // Double every second digit from the right
    if ((i % 2) === 0 === isEven) {
      digitValue = digit * 2;
      
      // If doubling results in a number > 9, sum its digits
      if (digitValue > 9) {
        digitValue = digitValue - 9;
      }
    }
    
    sum += digitValue;
  }
  
  // Valid if sum modulo 10 is 0
  return sum % 10 === 0;
}