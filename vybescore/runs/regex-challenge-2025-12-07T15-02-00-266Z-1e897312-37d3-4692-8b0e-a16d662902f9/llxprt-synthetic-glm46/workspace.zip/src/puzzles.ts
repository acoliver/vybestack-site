/**
 * Finds words beginning with the specified prefix but excludes those listed in exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!prefix || typeof prefix !== 'string') return [];
  if (!exceptions || !Array.isArray(exceptions)) return [];
  
  // Escape the prefix for regex usage
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex to find words starting with the prefix
  // \b ensures we match whole words only
  const prefixedWordsRegex = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  const matches = text.match(prefixedWordsRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  const filteredMatches = matches.filter(word => 
    !exceptionSet.has(word.toLowerCase())
  );
  
  // Remove duplicates
  return [...new Set(filteredMatches)];
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 * Uses lookahead/lookbehind constructs to ensure proper context.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!token || typeof token !== 'string') return [];
  
  // Escape the token for regex usage
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token that appears after a digit
  // We'll use a capturing group to capture the preceding digit and the token
  const tokenRegex = new RegExp(`(\\d)(${escapedToken})(?!\\w)`, 'gi');
  
  // Find matches and extract the digit+token combinations
  const results: string[] = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Combine the captured digit and token
    results.push(match[1] + match[2]);
  }
  
  return results;
}

/**
 * Validates passwords according to security policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Length must be at least 10 characters
  if (value.length < 10) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Must not contain whitespace
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab, 123123, etc.)
  // We'll check for patterns where any sequence of 2+ characters is immediately repeated
  for (let i = 1; i <= value.length / 2; i++) {
    for (let j = 0; j <= value.length - (i * 2); j++) {
      const sequence = value.substring(j, j + i);
      const nextSequence = value.substring(j + i, j + (i * 2));
      
      if (sequence === nextSequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 * Returns true if an IPv6 address is found, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // First, let's create a regex to detect IPv6 addresses in various formats
  // This regex handles standard IPv6, abbreviated IPv6 with ::, and IPv6 with embedded IPv4
  
  // Full IPv6 pattern (8 groups of 1-4 hex digits separated by colons)
  const fullIPv6Regex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: abbreviation (zero compression)
  const abbreviatedIPv6Regex = /(?:[0-9a-fA-F]{1,4}:){0,5}:?(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with subnet notation (e.g., 2001:db8::/32)
  const ipv6WithSubnetRegex = /[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,7}::?\/\d{1,3}/;
  
  // IPv6 embedded IPv4 (e.g., ::ffff:192.0.2.128)
  const ipv6EmbeddedIPv4Regex = /(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Check for any IPv6 patterns
  const hasIPv6 = fullIPv6Regex.test(value) || 
                 abbreviatedIPv6Regex.test(value) || 
                 ipv6WithSubnetRegex.test(value) || 
                 ipv6EmbeddedIPv4Regex.test(value);
  
  // If no IPv6 pattern found, return false
  if (!hasIPv6) return false;
  
  // Make sure the matched pattern is not an IPv4 address
  // IPv4 address pattern (e.g., 192.168.1.1)
  const ipv4Regex = /(?:\d{1,3}\.){3}\d{1,3}/;
  const hasOnlyIPv4 = ipv4Regex.test(value) && !value.includes(':');
  
  // If it contains IPv4 but not IPv6 with colons, return false
  if (hasOnlyIPv4 && !value.includes(':')) return false;
  
  // Otherwise, return true as we have a valid IPv6 address
  return true;
}
