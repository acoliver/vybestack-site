export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

function validateBase64Input(input: string): void {
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check for invalid length - valid base64 strings must have length that's a multiple of 4
  // or be able to be padded to a multiple of 4
  const paddedLength = input.length;
  if (paddedLength % 4 !== 0) {
    // Check if it can be validly padded
    const remainder = paddedLength % 4;
    if (remainder === 1) {
      // Can't be validly padded if remainder is 1
      throw new Error('Invalid Base64 input: incorrect length');
    }
    // If remainder is 2 or 3, we can pad it with '=' to make it valid
  }
}

function validatePadding(input: string): void {
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) {
    return; // No padding
  }
  
  // Validate padding count (max 2)
  const paddingCount = input.length - paddingIndex;
  if (paddingCount > 3) {
    throw new Error('Invalid Base64 input: too much padding');
  }
  
  // Check if padding appears in the middle of the string
  const hasNonPaddingAfterPadding = /[A-Za-z0-9+/]/.test(input.substring(paddingIndex + 1));
  if (hasNonPaddingAfterPadding) {
    throw new Error('Invalid Base64 input: padding not at end');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  validateBase64Input(input);
  validatePadding(input);

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Verify the decoded result makes sense - if result contains null bytes or invalid UTF-8 sequences
    // the input was likely corrupted
    if (result.includes('\u0000') && !input.includes('AA')) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return result;
  } catch (error) {
    // If Buffer throws an error, it means the input was invalid base64
    if (error instanceof Error && error.message.includes('Invalid character')) {
      throw new Error('Invalid Base64 input');
    }
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
