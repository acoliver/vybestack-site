#!/usr/bin/env node

import { readFile } from 'node:fs/promises';
import { writeFile } from 'node:fs/promises';
import type { ReportData, RenderOptions, Format, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters: Record<Format, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

function printUsage(): void {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('Supported formats: markdown, text');
}

function parseArguments(args: string[]): {
  dataFile: string;
  format: Format;
  outputPath: string | undefined;
  includeTotals: boolean;
} {
  if (args.length < 3) {
    console.error('Error: Missing required arguments');
    printUsage();
    process.exit(1);
  }

  const dataFile = args[0];
  let format: Format = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const flag = args[i];
    let value: string | undefined;

    if (flag === '--format' || flag === '--output') {
      i++;
      value = args[i];
      if (!value) {
        console.error(`Error: ${flag} requires a value`);
        printUsage();
        process.exit(1);
      }
    }

    if (flag === '--format') {
      if (value !== 'markdown' && value !== 'text') {
        console.error(`Error: Unsupported format: ${value}`);
        printUsage();
        process.exit(1);
      }
      format = value;
    } else if (flag === '--output') {
      outputPath = value;
    } else if (flag === '--includeTotals') {
      includeTotals = true;
    }
  }

  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid report data: must be an object');
  }

  const potentialData = data as Record<string, unknown>;

  if (!('title' in potentialData) || typeof potentialData.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (must be string)');
  }

  if (!('summary' in potentialData) || typeof potentialData.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (must be string)');
  }

  if (!('entries' in potentialData) || !Array.isArray(potentialData.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (must be array)');
  }

  const entries = potentialData.entries as unknown[];
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: must be an object`);
    }

    const entryRecord = entry as Record<string, unknown>;

    if (!('label' in entryRecord) || typeof entryRecord.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (must be string)`);
    }

    if (!('amount' in entryRecord) || typeof entryRecord.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (must be number)`);
    }
  }

  return potentialData as unknown as ReportData;
}

async function main(): Promise<void> {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArguments(process.argv.slice(2));

    // Read and parse the JSON data
    let data: unknown;
    try {
      const fileContent = await readFile(dataFile, 'utf-8');
      data = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file "${dataFile}": ${error.message}`);
        process.exit(1);
      }
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error(`Error: File not found: "${dataFile}"`);
        process.exit(1);
      }
      throw error;
    }

    // Validate the data structure
    const reportData = validateReportData(data);

    // Render the report
    const options: RenderOptions = { includeTotals };
    const formatter = formatters[format];
    const output = formatter.render(reportData, options);

    // Write output
    if (outputPath) {
      await writeFile(outputPath, output, 'utf-8');
      console.log(`Report written to: ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
