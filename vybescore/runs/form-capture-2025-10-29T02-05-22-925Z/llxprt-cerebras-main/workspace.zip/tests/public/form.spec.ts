import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'url';
import app from '../../src/server.js';
import { Server } from 'http';

let server: Server | null = null;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.resolve(__dirname, '..', '..', 'data', 'submissions.sqlite');

beforeAll(() => {
  server = app.listen(0); // Listen on a random port
});

afterAll(() => {
  if (server && server.close) {
    server.close();
    // Remove database file after tests
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    if (!server) {
      throw new Error('Test server not initialized');
    }

    const response = await request(server).get('/');
    expect(response.status).toBe(200);

    const html = response.text;
    const $ = cheerio.load(html);
    
    // Check all required fields are present
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (!server) {
      throw new Error('Test server not initialized');
    }

    // Clear database file before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'john.doe@example.com',
        phone: '+1 555 123 4567'
      });
    
    expect(response.status).toBe(302); // Redirect status
    expect(response.header.location).toBe('/thank-you');
  });
});