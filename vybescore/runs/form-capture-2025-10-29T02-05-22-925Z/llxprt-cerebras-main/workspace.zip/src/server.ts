import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { DatabaseService } from './database.js';
import { validateForm, FormErrors, FormData } from './validation.js';
import { Server } from 'http';

// Needed to use __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Initialize database service
const dbService = new DatabaseService();

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { 
    errors: {} as FormErrors,
    data: {} as Partial<FormData>
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const data: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const errors = validateForm(data);

  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, data });
  }

  try {
    // Insert into database
    await dbService.insertSubmission({
      firstName: data.firstName!,
      lastName: data.lastName!,
      streetAddress: data.streetAddress!,
      city: data.city!,
      stateProvince: data.stateProvince!,
      postalCode: data.postalCode!,
      country: data.country!,
      email: data.email!,
      phone: data.phone!
    });

    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
let server: Server | null = null;
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  dbService.close();
  console.log('Database closed');
  process.exit(0);
});

// Initialize and start server
(async () => {
  try {
    await dbService.initialize();
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
})();

export default app;