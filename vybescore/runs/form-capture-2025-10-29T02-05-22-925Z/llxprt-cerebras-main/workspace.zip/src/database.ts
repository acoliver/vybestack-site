import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';
import type { Database } from 'sql.js';

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

export class DatabaseService {
  private db: Database | null = null;
  private initialized = false;

  async initialize(): Promise<void> {
    if (this.initialized) return;

    // Initialize SQL.js
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    // Load existing database or create a new one
    let dbData: Uint8Array | null = null;
    if (fs.existsSync(DB_PATH)) {
      dbData = fs.readFileSync(DB_PATH);
    }
    
    this.db = new SQL.Database(dbData || undefined);
    
    // Create table if it doesn't exist
    const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
    this.db.run(schema);
    
    this.initialized = true;
  }

  async insertSubmission(data: {
    firstName: string;
    lastName: string;
    streetAddress: string;
    city: string;
    stateProvince: string;
    postalCode: string;
    country: string;
    email: string;
    phone: string;
  }): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const query = `
      INSERT INTO submissions (
        first_name, last_name, street_address, city,
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    this.db.run(query, [
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);

    // Write database back to file
    const dataBuffer = this.db.export();
    fs.writeFileSync(DB_PATH, dataBuffer);
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    this.initialized = false;
  }
}