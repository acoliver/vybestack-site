export interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateForm(data: Partial<FormData>): FormErrors {
  const errors: FormErrors = {};

  // Required fields validation
  if (!data.firstName || !data.firstName.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName || !data.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress || !data.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city || !data.city.trim()) {
    errors.city = 'City is required';
  }

  if (!data.stateProvince || !data.stateProvince.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!data.postalCode || !data.postalCode.trim()) {
    errors.postalCode = 'Postal code is required';
  }

  if (!data.country || !data.country.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email || !data.email.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Email is invalid';
  }

  if (!data.phone || !data.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!/^\+?[\d\s\-()]+$/.test(data.phone)) {
    errors.phone = 'Phone number format is invalid';
  }

  return errors;
}