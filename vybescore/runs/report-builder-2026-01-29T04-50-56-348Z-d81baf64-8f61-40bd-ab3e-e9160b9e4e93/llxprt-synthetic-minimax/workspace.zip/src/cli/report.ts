#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFileSync } from 'node:fs';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';
import { ReportData } from '../types/index.js';

function parseArgs(args: string[]): { dataPath: string; format: string; outputPath?: string; includeTotals: boolean } {
  if (args.length < 1) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[0];
  
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format option is required');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const format = args[formatIndex + 1];
  
  if (format !== 'markdown' && format !== 'text') {
    console.error(`Unsupported format "${format}". Supported formats: markdown, text`);
    process.exit(1);
  }

  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse remaining arguments after format
  let currentIndex = formatIndex + 2;
  while (currentIndex < args.length) {
    if (args[currentIndex] === '--output') {
      if (currentIndex + 1 < args.length) {
        outputPath = args[currentIndex + 1];
        currentIndex += 2;
      } else {
        console.error('Error: --output option requires a path');
        process.exit(1);
      }
    } else if (args[currentIndex] === '--includeTotals') {
      includeTotals = true;
      currentIndex += 1;
    } else {
      console.error(`Error: Unknown argument "${args[currentIndex]}"`);
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }
  }

  return { dataPath, format, outputPath, includeTotals };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      console.error('Error: Missing or invalid "title" field in JSON data');
      process.exit(1);
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      console.error('Error: Missing or invalid "summary" field in JSON data');
      process.exit(1);
    }
    
    if (!data.entries || !Array.isArray(data.entries) || data.entries.length === 0) {
      console.error('Error: Missing or invalid "entries" field in JSON data');
      process.exit(1);
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        console.error(`Error: Missing or invalid "label" field in entries[${i}]`);
        process.exit(1);
      }
      if (typeof entry.amount !== 'number' || entry.amount < 0) {
        console.error(`Error: Missing or invalid "amount" field in entries[${i}]. Must be a non-negative number`);
        process.exit(1);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File "${filePath}" not found`);
      } else if (error.message.includes('JSON')) {
        console.error(`Error: Invalid JSON in file "${filePath}"`);
      } else {
        console.error(`Error reading file "${filePath}": ${error.message}`);
      }
    } else {
      console.error(`Error reading file "${filePath}": Unknown error`);
    }
    process.exit(1);
  }
}

function main(): void {
  const args = process.argv.slice(2);
  const { dataPath, format, outputPath, includeTotals } = parseArgs(args);
  
  const reportData = loadReportData(dataPath);
  
  const formatter = format === 'markdown' ? markdownFormatter : textFormatter;
  const renderedReport = formatter.format(reportData, includeTotals);
  
  if (outputPath) {
    try {
      writeFileSync(outputPath, renderedReport, 'utf-8');
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error writing to file "${outputPath}": ${error.message}`);
      } else {
        console.error(`Error writing to file "${outputPath}": Unknown error`);
      }
      process.exit(1);
    }
  } else {
    process.stdout.write(renderedReport);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
