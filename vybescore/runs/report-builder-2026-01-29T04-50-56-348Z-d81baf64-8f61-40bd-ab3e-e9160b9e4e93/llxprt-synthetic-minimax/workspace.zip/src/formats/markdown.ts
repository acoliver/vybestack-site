import { ReportData } from '../types/index.js';
import { Formatter } from '../types/index.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((total, entry) => total + entry.amount, 0);
}

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  const total = includeTotals ? calculateTotal(data.entries) : undefined;
  
  let output = `# ${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `## Entries\n`;
  
  data.entries.forEach(entry => {
    output += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
  });
  
  if (includeTotals && total !== undefined) {
    output += `\n**Total:** ${formatAmount(total)}\n`;
  }
  
  return output;
}

export const markdownFormatter: Formatter = {
  format: renderMarkdown
};