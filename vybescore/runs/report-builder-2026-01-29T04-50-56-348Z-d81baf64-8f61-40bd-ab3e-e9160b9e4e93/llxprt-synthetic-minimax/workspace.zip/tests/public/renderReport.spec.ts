import { describe, expect, it } from 'vitest';
import { execSync } from 'node:child_process';
import { readFileSync, writeFileSync, unlinkSync, existsSync } from 'node:fs';
import { join } from 'node:path';

describe('report CLI (public smoke)', () => {
  const distPath = 'dist/cli/report.js';
  const fixturesPath = 'fixtures/data.json';

  it('should render markdown format correctly', () => {
    const result = execSync(
      `node ${distPath} ${fixturesPath} --format markdown`,
      { encoding: 'utf-8' }
    );
    
    expect(result).toContain('# Quarterly Financial Summary');
    expect(result).toContain('Highlights include record revenue across regions');
    expect(result).toContain('## Entries');
    expect(result).toContain('- **North Region** — $12345.67');
    expect(result).toContain('- **South Region** — $23456.78');
    expect(result).toContain('- **West Region** — $34567.89');
  });

  it('should render markdown format with totals', () => {
    const result = execSync(
      `node ${distPath} ${fixturesPath} --format markdown --includeTotals`,
      { encoding: 'utf-8' }
    );
    
    expect(result).toContain('# Quarterly Financial Summary');
    expect(result).toContain('## Entries');
    expect(result).toContain('- **North Region** — $12345.67');
    expect(result).toContain('**Total:** $70370.34');
  });

  it('should render text format correctly', () => {
    const result = execSync(
      `node ${distPath} ${fixturesPath} --format text`,
      { encoding: 'utf-8' }
    );
    
    expect(result).toContain('Quarterly Financial Summary');
    expect(result).toContain('Highlights include record revenue across regions');
    expect(result).toContain('Entries:');
    expect(result).toContain('- North Region: $12345.67');
    expect(result).toContain('- South Region: $23456.78');
    expect(result).toContain('- West Region: $34567.89');
  });

  it('should render text format with totals', () => {
    const result = execSync(
      `node ${distPath} ${fixturesPath} --format text --includeTotals`,
      { encoding: 'utf-8' }
    );
    
    expect(result).toContain('Quarterly Financial Summary');
    expect(result).toContain('Entries:');
    expect(result).toContain('- North Region: $12345.67');
    expect(result).toContain('Total: $70370.34');
  });

  it('should output to file correctly', () => {
    const outputFile = 'test-output.md';
    
    try {
      execSync(
        `node ${distPath} ${fixturesPath} --format markdown --output ${outputFile}`,
        { encoding: 'utf-8' }
      );
      
      expect(existsSync(outputFile)).toBe(true);
      const content = readFileSync(outputFile, 'utf-8');
      expect(content).toContain('# Quarterly Financial Summary');
      expect(content).toContain('## Entries');
      expect(content).toContain('- **North Region** — $12345.67');
    } finally {
      if (existsSync(outputFile)) {
        unlinkSync(outputFile);
      }
    }
  });

  it('should handle malformed JSON', () => {
    const malformedFile = 'test-malformed.json';
    
    try {
      writeFileSync(malformedFile, '{"title": "Test", "summary": "Missing entries');
      
      let stderr = '';
      try {
        execSync(
          `node ${distPath} ${malformedFile} --format markdown`,
          { encoding: 'utf-8', stdio: ['ignore', 'pipe', 'pipe'] }
        );
      } catch (error: any) {
        stderr = error.stderr.toLowerCase();
      }
      
      expect(stderr).toMatch(/invalid|json|malf/);
    } finally {
      if (existsSync(malformedFile)) {
        unlinkSync(malformedFile);
      }
    }
  });

  it('should handle file not found', () => {
    let stderr = '';
    try {
      execSync(
        `node ${distPath} nonexistent.json --format markdown`,
        { encoding: 'utf-8', stdio: ['ignore', 'pipe', 'pipe'] }
      );
    } catch (error: any) {
      stderr = error.stderr.toLowerCase();
    }
    
    expect(stderr).toMatch(/missing|unable|enoent|not found/);
  });

  it('should handle unsupported format', () => {
    let stderr = '';
    try {
      execSync(
        `node ${distPath} ${fixturesPath} --format xml`,
        { encoding: 'utf-8', stdio: ['ignore', 'pipe', 'pipe'] }
      );
    } catch (error: any) {
      stderr = error.stderr;
    }
    
    expect(stderr).toContain('Unsupported format');
  });

  it('should validate missing required fields', () => {
    const missingFile = 'test-missing.json';
    
    try {
      writeFileSync(missingFile, '{"title": "Test"}');
      
      let stderr = '';
      try {
        execSync(
          `node ${distPath} ${missingFile} --format markdown`,
          { encoding: 'utf-8', stdio: ['ignore', 'pipe', 'pipe'] }
        );
      } catch (error: any) {
        stderr = error.stderr.toLowerCase();
      }
      
      expect(stderr).toMatch(/missing|invalid|field/);
    } finally {
      if (existsSync(missingFile)) {
        unlinkSync(missingFile);
      }
    }
  });

  it('should require format argument', () => {
    let stderr = '';
    try {
      execSync(
        `node ${distPath} ${fixturesPath}`,
        { encoding: 'utf-8', stdio: ['ignore', 'pipe', 'pipe'] }
      );
    } catch (error: any) {
      stderr = error.stderr;
    }
    
    expect(stderr).toContain('--format option is required');
  });
});
