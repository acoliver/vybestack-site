#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): CliOptions {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFileIndex = args.findIndex(arg => !arg.startsWith('--'));
  if (dataFileIndex === -1) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }
  
  const options: CliOptions = {
    format: 'markdown',
    includeTotals: false
  };
  
  let formatFound = false;
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const formatArg = args[i + 1];
      if (!formatArg || formatArg.startsWith('--')) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      if (formatArg !== 'markdown' && formatArg !== 'text') {
        console.error('Error: Unsupported format');
        process.exit(1);
      }
      options.format = formatArg as FormatType;
      formatFound = true;
      i++;
    } else if (arg === '--output') {
      const outputArg = args[i + 1];
      if (!outputArg || outputArg.startsWith('--')) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      options.output = outputArg;
      i++;
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }
  
  if (!formatFound) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return options;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const dataObj = data as Record<string, unknown>;
  
  if (typeof dataObj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title (must be string)');
  }
  
  if (typeof dataObj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary (must be string)');
  }
  
  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries (must be array)');
  }
  
  for (let i = 0; i < dataObj.entries.length; i++) {
    const entry = dataObj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid label (must be string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid amount (must be number)`);
    }
  }
  
  return data as ReportData;
}

function main() {
  try {
    const args = process.argv.slice(2);
    const dataFileIndex = args.findIndex(arg => !arg.startsWith('--'));
    
    if (dataFileIndex === -1) {
      console.error('Error: Data file path is required');
      process.exit(1);
    }
    
    const dataFilePath = args[dataFileIndex];
    const options = parseArguments();
    
    // Read and parse JSON data
    let jsonData: unknown;
    try {
      const jsonContent = readFileSync(dataFilePath, 'utf8');
      jsonData = JSON.parse(jsonContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file ${dataFilePath}: ${error.message}`);
      } else {
        console.error(`Error reading file ${dataFilePath}: ${(error as Error).message}`);
      }
      process.exit(1);
    }
    
    // Validate report data
    const reportData = validateReportData(jsonData);
    
    // Render report
    let output: string;
    switch (options.format) {
      case 'markdown':
        output = renderMarkdown(reportData, { includeTotals: options.includeTotals });
        break;
      case 'text':
        output = renderText(reportData, { includeTotals: options.includeTotals });
        break;
      default:
        console.error('Error: Unsupported format');
        process.exit(1);
    }
    
    // Write output
    if (options.output) {
      try {
        writeFileSync(options.output, output, 'utf8');
      } catch (error) {
        console.error(`Error writing to file ${options.output}: ${(error as Error).message}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }
}

main();
