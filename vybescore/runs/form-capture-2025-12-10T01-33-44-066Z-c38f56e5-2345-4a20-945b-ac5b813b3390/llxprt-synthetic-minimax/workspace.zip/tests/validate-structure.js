const fs = require("fs");
const path = require("path");

function validateStructure() {
  const workspaceRoot = process.cwd();
  const requiredFiles = [
    "package.json",
    "tsconfig.json",
    ".eslintrc.json",
    "src/server.ts",
    "db/schema.sql",
    "public/styles.css",
    "views/form.ejs",
    "views/thank-you.ejs",
    "tests/validate-structure.js"
  ];

  const workspacePackage = JSON.parse(fs.readFileSync(path.join(workspaceRoot, "package.json"), "utf8"));
  const baselinePackage = {
    name: "friendly-form-capture",
    main: "dist/server.js",
    scripts: {
      build: "tsc",
      start: "node dist/server.js",
      dev: "ts-node src/server.ts",
      lint: "eslint src/**/*.ts",
      typecheck: "tsc --noEmit",
      "test:public": "node tests/validate-structure.js"
    }
  };

  console.log("Checking package.json structure...");
  if (workspacePackage.main !== baselinePackage.main) {
    throw new Error(`main should be "${baselinePackage.main}"`);
  }
  if (JSON.stringify(workspacePackage.scripts) !== JSON.stringify(baselinePackage.scripts)) {
    throw new Error("scripts do not match expected structure");
  }

  for (const file of requiredFiles) {
    if (!fs.existsSync(path.join(workspaceRoot, file))) {
      throw new Error(`Required file missing: ${file}`);
    }
  }

  console.log("✓ All required files present");
  console.log("✓ Package.json structure correct");
  console.log("✓ Project structure validation passed");
}

try {
  validateStructure();
  process.exit(0);
} catch (error) {
  console.error("❌ Validation failed:", error.message);
  process.exit(1);
}
