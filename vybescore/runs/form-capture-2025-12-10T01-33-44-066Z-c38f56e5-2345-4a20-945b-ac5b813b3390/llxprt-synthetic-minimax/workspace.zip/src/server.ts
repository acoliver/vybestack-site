import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { readFileSync, existsSync, writeFileSync } from 'fs';

// Type definitions
type Database = any;

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database
let db: Database;

// Load database file into memory
async function loadDatabase(): Promise<void> {
  try {
    const initSqlJs = require('sql.js');
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)
    });
    
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    
    if (existsSync(dbPath)) {
      const fileBuffer = readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      
      // Initialize with schema
      const schema = readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
      db.exec(schema);
    }
  } catch (error) {
    console.error('Error loading database:', error);
    process.exit(1);
  }
}

// Save database to file
function saveDatabase(): void {
  try {
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    const data = db.export();
    const buffer = Buffer.from(data);
    writeFileSync(dbPath, buffer);
  } catch (error) {
    console.error('Error saving database:', error);
  }
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Set up EJS
app.set('views', path.join(process.cwd(), 'views'));
app.set('view engine', 'ejs');

// Validation functions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+\d\s()\-]+$/;
  return phoneRegex.test(phone) && phone.replace(/[^\d]/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[a-zA-Z0-9\s\-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};
  
  if (!data.firstName.trim()) errors.firstName = 'First name is required';
  if (!data.lastName.trim()) errors.lastName = 'Last name is required';
  if (!data.streetAddress.trim()) errors.streetAddress = 'Street address is required';
  if (!data.city.trim()) errors.city = 'City is required';
  if (!data.stateProvince.trim()) errors.stateProvince = 'State/Province/Region is required';
  if (!data.postalCode.trim()) errors.postalCode = 'Postal code is required';
  if (!data.country.trim()) errors.country = 'Country is required';
  
  if (!data.email.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!data.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  if (!validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }
  
  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('contact-form', { 
    errors: {}, 
    formData: {} as FormData,
    title: 'Friendly Contact Form'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(formData);
  
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('contact-form', {
      errors,
      formData,
      title: 'Friendly Contact Form'
    });
  }
  
  // Insert into database
  try {
    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );
    
    saveDatabase();
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('contact-form', {
      errors: { general: 'An error occurred. Please try again.' },
      formData,
      title: 'Friendly Contact Form'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { title: 'Thank You!' });
});

// Error handling
app.use((error: Error, req: Request, res: Response, next: NextFunction) => {
  console.error('Unhandled error:', error);
  res.status(500).send('Internal Server Error');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully');
  if (db) {
    db.close();
  }
  process.exit(0);
});

// Initialize database and start server
async function startServer(): Promise<void> {
  await loadDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});