import { Submission } from './database.js';

export interface ValidationError {
  field: keyof Submission;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

export function validateSubmission(data: Partial<Submission>): ValidationResult {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: Array<keyof Submission> = [
    'first_name',
    'last_name', 
    'street_address',
    'city',
    'state_province',
    'postal_code',
    'country',
    'email',
    'phone'
  ];

  for (const field of requiredFields) {
    const value = data[field]?.trim();
    if (!value || value.length === 0) {
      errors.push({
        field,
        message: `${formatFieldName(field)} is required`
      });
    }
  }

  // Email validation
  if (data.email && data.email.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }
  }

  // Phone validation
  if (data.phone && data.phone.trim()) {
    const phoneRegex = /^[+]?[0-9\s\-()]+$/;
    if (!phoneRegex.test(data.phone.trim()) || data.phone.trim().length < 7) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number'
      });
    }
  }

  // Postal code validation (alphanumeric, allow spaces)
  if (data.postal_code && data.postal_code.trim()) {
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalRegex.test(data.postal_code.trim()) || data.postal_code.trim().length < 3) {
      errors.push({
        field: 'postal_code',
        message: 'Please enter a valid postal code'
      });
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

function formatFieldName(field: string): string {
  return field
    .split('_')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');
}

export function getErrorForField(errors: ValidationError[], field: keyof Submission): string | undefined {
  return errors.find(error => error.field === field)?.message;
}