import initSqlJs, { Database } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

export interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    try {
      // Ensure data directory exists
      const dataDir = join(process.cwd(), 'data');
      if (!existsSync(dataDir)) {
        mkdirSync(dataDir, { recursive: true });
      }

      // Initialize SQL.js
      const SQL = await initSqlJs();
      
      if (existsSync(this.dbPath)) {
        // Load existing database
        const fileBuffer = readFileSync(this.dbPath);
        this.db = new SQL.Database(fileBuffer);
      } else {
        // Create new database
        this.db = new SQL.Database();
        await this.createSchema();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw new Error('Database initialization failed');
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schema = readFileSync(this.schemaPath, 'utf-8');
    this.db.exec(schema);
    await this.save();
  }

  async insertSubmission(submission: Submission): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    await this.save();
    
    // Get the last inserted row ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    return result[0].values[0][0] as number;
  }

  async getAllSubmissions(): Promise<Array<Submission & { id: number }>> {
    if (!this.db) throw new Error('Database not initialized');

    const result = this.db.exec('SELECT * FROM submissions ORDER BY created_at DESC');
    if (result.length === 0) return [];

    const [columns, ...rows] = result[0].values;
    return rows.map((row: unknown[]) => {
      const submission: Record<string, string> = {};
      for (let i = 0; i < columns.length; i++) {
        const col = columns[i] as string;
        const value = row[i];
        submission[col] = value !== null ? String(value) : '';
      }
      return submission as unknown as Submission & { id: number };
    });
  }

  async save(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const data = this.db.export();
    writeFileSync(this.dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();