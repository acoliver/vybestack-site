/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate if input contains only valid Base64 characters and has proper structure.
 */
function isValidBase64(input: string): boolean {
  // Remove whitespace for validation
  const trimmed = input.replace(/\s/g, '');
  
  // Check for valid Base64 characters only
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(trimmed)) {
    return false;
  }
  
  // Check if padding is correct
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    if (paddingIndex < trimmed.length - 2) {
      return false;
    }
    // If padding exists, it must be 1 or 2 characters at the end
    const padding = trimmed.slice(paddingIndex);
    if (padding.length > 2 || !padding.match(/^=+$/)) {
      return false;
    }
  }
  
  // Buffer.from will handle length validation automatically
  // We just need to ensure the format is structurally correct
  return trimmed.length > 0;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Remove any whitespace
  const trimmed = input.replace(/\s/g, '');
  
  // Validate input characters and structure
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input: contains illegal characters or incorrect padding');
  }

  try {
    const decoded = Buffer.from(trimmed, 'base64');
    
    // Check if the input was actually valid Base64
    // Node.js Buffer.from will try to decode even malformed inputs
    // We need to verify the result makes sense
    if (decoded.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input: cannot decode to valid data');
    }
    
    // For proper Base64 validation, we need to handle length constraints
    // Valid Base64 strings should have length that's a multiple of 4, OR have padding
    // However, many implementations accept non-multiple-of-4 lengths, so we'll be lenient
    // but still catch obviously malformed inputs like length 3 with valid characters
    
    return decoded.toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message.startsWith('Invalid Base64 input:')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
