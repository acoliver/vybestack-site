import { ReportData, RenderFunction, RenderOptions } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderMarkdown: RenderFunction = (
  data: ReportData,
  options: RenderOptions = {}
): string => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries header
  lines.push('## Entries');
  lines.push('');

  // Entries list
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  // Total if requested
  if (options.includeTotals) {
    lines.push('');
    lines.push(`**Total:** ${formatAmount(calculateTotal(data.entries))}`);
  }

  return lines.join('\n');
};