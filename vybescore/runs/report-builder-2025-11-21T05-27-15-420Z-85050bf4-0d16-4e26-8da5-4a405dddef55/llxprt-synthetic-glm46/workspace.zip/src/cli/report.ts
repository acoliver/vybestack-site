#!/usr/bin/env node

import fs from 'node:fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArguments(): {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
    );
    process.exit(1);
  }

  const dataPath = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  try {
    const formatIndex = args.indexOf('--format');
    if (formatIndex === -1 || formatIndex + 1 >= args.length) {
      throw new Error('--format argument is required');
    }
    format = args[formatIndex + 1];

    const outputIndex = args.indexOf('--output');
    if (outputIndex !== -1 && outputIndex + 1 < args.length) {
      outputPath = args[outputIndex + 1];
    }

    const includeTotalsIndex = args.indexOf('--includeTotals');
    if (includeTotalsIndex !== -1) {
      includeTotals = true;
    }
  } catch (error) {
    console.error(`Error parsing arguments: ${error}`);
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const dataObj = data as Record<string, unknown>;

  if (!dataObj.title || typeof dataObj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }

  if (!dataObj.summary || typeof dataObj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }

  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  for (const entry of dataObj.entries) {
    if (
      !entry ||
      typeof entry !== 'object' ||
      !('label' in entry) ||
      !('amount' in entry)
    ) {
      throw new Error(
        'Invalid report data: entry missing required fields "label" and "amount"'
      );
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid report data: entry missing or invalid "label" field');
    }

    if (
      typeof entryObj.amount !== 'number' ||
      isNaN(entryObj.amount)
    ) {
      throw new Error('Invalid report data: entry missing or invalid "amount" field');
    }
  }

  return {
    title: dataObj.title,
    summary: dataObj.summary,
    entries: dataObj.entries as ReportData['entries'],
  };
}

function main(): void {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArguments();

    if (!formatters[format as keyof typeof formatters]) {
      throw new Error(`Unsupported format: ${format}`);
    }

    const rawData = fs.readFileSync(dataPath, 'utf8');
    let data: unknown;

    try {
      data = JSON.parse(rawData);
    } catch (error) {
      throw new Error(`Invalid JSON in file ${dataPath}: ${error}`);
    }

    const reportData = validateReportData(data);
    const renderOptions: RenderOptions = { includeTotals };
    const output = formatters[format as keyof typeof formatters](
      reportData,
      renderOptions
    );

    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${error}`);
    process.exit(1);
  }
}

main();
