/**
 * Finds words beginning with the specified prefix, excluding words in the exceptions list.
 * Returns an array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to match words starting with the prefix
  // Word boundary ensures we match complete words
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  return matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit.
 * Returns the full match including the digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match a digit followed by the token
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (2+ characters)
  // e.g., abab, abcabc, 1212
  for (let i = 0; i < value.length - 3; i++) {
    // Check for 2-char repeats
    if (i + 3 < value.length) {
      const twoChars = value.substring(i, i + 2);
      const nextTwo = value.substring(i + 2, i + 4);
      if (twoChars === nextTwo) {
        return false;
      }
    }

    // Check for 3-char repeats
    if (i + 5 < value.length) {
      const threeChars = value.substring(i, i + 3);
      const nextThree = value.substring(i + 3, i + 6);
      if (threeChars === nextThree) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand notation ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it looks like an IPv4 address and exclude it
  // IPv4 pattern: 4 groups of 1-3 digits
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // More comprehensive IPv6 patterns including shorthand
  const fullPatterns = [
    // Full form: 8 groups of 1-4 hex digits
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/g,
    // Compressed with ::
    /(?:[0-9a-fA-F]{1,4}:)*:(?::[0-9a-fA-F]{1,4})*/g,
    // Starting with ::
    /::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}/g,
    // Ending with ::
    /(?:[0-9a-fA-F]{1,4}:){1,7}::/g,
  ];

  for (const pattern of fullPatterns) {
    const matches = value.match(pattern);
    if (matches) {
      // Verify it's not just an IPv4 in disguise
      for (const match of matches) {
        if (!ipv4Pattern.test(match.trim())) {
          return true;
        }
      }
    }
  }

  // Check for IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const ipv6WithIPv4 = /(?:[0-9a-fA-F]{1,4}:){1,4}:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  if (ipv6WithIPv4.test(value)) {
    return true;
  }


  return false;
}
