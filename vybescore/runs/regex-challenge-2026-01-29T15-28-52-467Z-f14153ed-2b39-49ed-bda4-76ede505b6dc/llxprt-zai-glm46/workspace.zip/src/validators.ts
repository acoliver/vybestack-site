export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common patterns.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that:
  // - Allows standard email format: local@domain.tld
  // - Rejects consecutive dots (..)
  // - Rejects dots at start or end of local part
  // - Rejects underscores in domain
  // - Allows dots in local part (but not consecutively or at boundaries)
  // - Requires at least 2-char TLD
  // - Allows subdomains and multi-part TLDs (e.g., co.uk)
  // Updated to allow multiple subdomains properly
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;

  // Additional checks for invalid patterns
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for consecutive dots
  if (value.includes('..')) {
    return false;
  }

  // Check for underscore in domain
  const [, domain] = value.split('@');
  if (domain.includes('_')) {
    return false;
  }

  // Check for trailing dot in local part
  const [local] = value.split('@');
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers supporting common formats and optional +1 prefix.
 * Formats: (212) 555-7890, 212-555-7890, 2125557890
 * Disallows impossible area codes (leading 0 or 1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');

  // Check if there's an optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && cleaned.length === 11) {
    digits = digits.substring(1);
  }

  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - Without country code, must start with trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Try matching with country code
  let match = cleaned.match(/^\+?540?9?([1-9]\d{1,3})(\d{6,8})$/);
  if (match) {
    const areaCode = match[1];
    const subscriberNumber = match[2];

    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }

    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }

    return true;
  }

  // Try matching without country code (must start with 0)
  match = cleaned.match(/^0([1-9]\d{1,3})(\d{6,8})$/);
  if (match) {
    const areaCode = match[1];
    const subscriberNumber = match[2];

    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }

    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }

    return true;
  }

  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Must have at least one letter
  // Reject digits and symbols
  const nameRegex = /^[\p{L}'-]+(?:[\s'’][\p{L}'-]+)*$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Must contain at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  // Reject names that contain digits
  if (/\d/.test(value)) {
    return false;
  }

  // Reject names with symbols (excluding allowed apostrophes, hyphens, spaces)
  // Check for characters that are not letters, apostrophes, hyphens, or spaces
  const invalidChars = /[^\p{L}'\s-]/u;
  if (invalidChars.test(value)) {
    return false;
  }

  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);

  let sum = 0;
  let doubleDigit = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    doubleDigit = !doubleDigit;
  }

  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Checks prefix, length, and performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  if (visaRegex.test(cleaned) && (cleaned.length === 13 || cleaned.length === 16)) {
    return runLuhnCheck(cleaned);
  }

  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(?:5[1-5]\d{2}|2[2-7]\d{2}|27[0-1]\d|2720)\d{12}$/;
  if (mastercardRegex.test(cleaned) && cleaned.length === 16) {
    return runLuhnCheck(cleaned);
  }

  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(cleaned) && cleaned.length === 15) {
    return runLuhnCheck(cleaned);
  }

  return false;
}
