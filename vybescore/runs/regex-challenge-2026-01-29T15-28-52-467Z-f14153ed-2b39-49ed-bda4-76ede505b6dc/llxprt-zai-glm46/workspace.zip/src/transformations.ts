/**
 * Capitalizes the first character of each sentence.
 * - Capitalizes first character after sentence-ending punctuation (.?!)
 * - Inserts exactly one space between sentences if needed
 * - Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces into one
  let normalized = text.replace(/\s+/g, ' ').trim();

  // Insert space after sentence endings if missing (before capital letters)
  normalized = normalized.replace(/([.!?])([A-Z])/g, '$1 $2');

  // Split into sentences for processing
  const sentences: string[] = [];
  let currentSentence = '';

  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    currentSentence += char;

    // Check if this ends a sentence (. ! or ?)
    if (char === '.' || char === '!' || char === '?') {
      // Look ahead to see if there's more content
      const nextChar = normalized[i + 1];

      // If next char is whitespace or end of string, or next char is uppercase
      if (!nextChar || nextChar === ' ' || (nextChar === nextChar.toUpperCase() && nextChar !== nextChar.toLowerCase())) {
        sentences.push(currentSentence);
        currentSentence = '';

        // Skip the space if present
        if (nextChar === ' ') {
          i++;
        }
      }
    }
  }

  // Add any remaining content
  if (currentSentence) {
    sentences.push(currentSentence);
  }

  // Capitalize first letter of each sentence
  const result = sentences
    .map(sentence => {
      if (!sentence) return '';

      // Find the first alphabetic character
      const match = sentence.match(/^([^a-zA-Z]*)([a-zA-Z])(.*)$/);
      if (match) {
        const [, prefix, firstChar, rest] = match;
        return prefix + firstChar.toUpperCase() + rest;
      }
      return sentence;
    })
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();

  return result;
}

/**
 * Extracts all URLs from the given text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http://, https://, and www. without protocol
  // Captures the URL but excludes trailing punctuation
  const urlPattern = /(?:https?:\/\/|www\.)[^\s<>"()[\]{}|\\^`[\]]+[^\s<>"()[\]{}|\\^`[\].,!?;:]/g;

  const matches = text.match(urlPattern) || [];

  // Clean up trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Forces all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's not already https
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  const urlPattern = /https?:\/\/example\.com(\/[^\s]*)/gi;

  return text.replace(urlPattern, (match, path) => {
    // Always upgrade to https
    const newProtocol = 'https';

    // Check if path starts with /docs/
    const startsWithDocs = path.startsWith('/docs/');

    // Check for dynamic hints that should prevent host rewrite
    const hasDynamicHints =
      path.includes('cgi-bin') ||
      path.includes('?') ||
      path.includes('&') ||
      path.includes('=') ||
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);

    if (startsWithDocs && !hasDynamicHints) {
      // Rewrite to docs.example.com, keeping the full path
      return `${newProtocol}://docs.example.com${path}`;
    } else {
      // Just upgrade the protocol
      return `${newProtocol}://example.com${path}`;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' if the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Feb has 29 for leap year handling

  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  // Special check for February in non-leap years
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    const isLeapYear =
      (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;

    if (!isLeapYear) {
      return 'N/A';
    }
  }

  return year;
}
