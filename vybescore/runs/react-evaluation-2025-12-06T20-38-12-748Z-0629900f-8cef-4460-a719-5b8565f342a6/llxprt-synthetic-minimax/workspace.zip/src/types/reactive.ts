/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependents?: Set<Observer<unknown>>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
  dependents?: Set<Observer<unknown>>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Simple dependency tracking system
let activeObserver: Observer<unknown> | undefined = undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateObserver(observer: Observer<unknown>): unknown {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    return observer.value
  } finally {
    activeObserver = previous
  }
}

// Dependency tracking maps - subjects that observers depend on
const subjects = new WeakMap<Observer<unknown>, Set<Subject<unknown>>>()

export function addDependency<T>(observer: Observer<unknown>, subject: Subject<T>): void {
  if (!subjects.has(observer)) {
    subjects.set(observer, new Set())
  }
  subjects.get(observer)!.add(subject as Subject<unknown>)
  
  // Also track observer as a dependent of the subject for notification
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(observer)
}

export function notifySubject(subject: Subject<unknown>): void {
  const observerSet = subject.dependents
  if (!observerSet) return
  
  // Create a copy of the observer set to avoid issues if observers are modified during iteration
  const observers = Array.from(observerSet)
  
  for (const observer of observers) {
    if (observer && observer.updateFn !== undefined) {
      try {
        updateObserver(observer)
      } catch (error) {
        console.error('Error updating observer:', error)
      }
    }
  }
}