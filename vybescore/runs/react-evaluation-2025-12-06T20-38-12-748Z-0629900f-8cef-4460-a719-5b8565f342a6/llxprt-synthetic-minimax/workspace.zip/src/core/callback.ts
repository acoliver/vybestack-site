/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer,
  setActiveObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(
  updateFn: (value?: T) => T,
  value?: T
): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Execute the callback to establish dependencies and get initial value
  const executeCallback = () => {
    const previousObserver = getActiveObserver()
    setActiveObserver(observer as Observer<unknown>)
    try {
      observer.value = observer.updateFn(observer.value)
      return observer.value
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  // Execute immediately to establish dependencies
  setActiveObserver(observer as Observer<unknown>)
  try {
    executeCallback()
  } finally {
    setActiveObserver(undefined)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    // Clean up dependencies if needed
  }
}