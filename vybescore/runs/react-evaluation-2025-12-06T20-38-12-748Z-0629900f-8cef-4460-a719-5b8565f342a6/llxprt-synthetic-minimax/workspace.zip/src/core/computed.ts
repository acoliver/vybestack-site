/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  setActiveObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const getValue: GetterFn<T> = () => {
    // Save current observer context
    const previousObserver = getActiveObserver()
    
    // Set this observer as active to track dependencies
    setActiveObserver(observer as Observer<unknown>)
    
    try {
      // Execute the computation which will track dependencies
      const newValue = updateFn()
      observer.value = newValue
      return newValue
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  return getValue
}