/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependents?: Set<ObserverR>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer?: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
  dependents?: Set<ObserverR>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    const newValue = observer.updateFn(observer.value)
    if (newValue !== observer.value) {
      observer.value = newValue
      notifyDependents(observer as unknown as SubjectR)
    }
  } finally {
    activeObserver = previous
  }
}

export function addDependent<T extends SubjectR & { dependents?: Set<ObserverR> }>(
  subject: T,
  observer: ObserverR
): void {
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(observer)
}

export function removeDependent<T extends SubjectR & { dependents?: Set<ObserverR> }>(
  subject: T,
  observer: ObserverR
): void {
  subject.dependents?.delete(observer)
}

export function notifyDependents<T extends SubjectR & { dependents?: Set<ObserverR> }>(
  subject: T
): void {
  if (!subject.dependents) return
  
  for (const dependent of subject.dependents) {
    updateObserver(dependent as Observer<unknown>)
  }
}
