/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  addDependent,
  SubjectR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependents: new Set(),
  }
  
  // Initialize the computed value by running the update function
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && observer !== o) {
      addDependent(o as unknown as SubjectR, observer)
    }
    return o.value!
  }
  
  return getter
}
