

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using the standard Base64 alphabet.
 * Accepts inputs with or without padding, and rejects invalid inputs.
 */
export function decode(input: string): string {
  // Validate the input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Additional validation for clearly invalid payloads
    if (input.length > 0 && result === '' && !/^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(input)) {
      throw new Error('Invalid Base64 input: incorrectly padded or malformed');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error; // Re-throw our custom validation errors
    }
    throw new Error('Failed to decode Base64 input');
  }
}
