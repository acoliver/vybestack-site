import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Debug Test ===')

// Test 1: compute cells fire callbacks
const [input, setInput] = createInput(1)
const output = createComputed(() => {
  console.log('Computing output:', input() + 1)
  return input() + 1
})

let value = 0
console.log('Creating callback...')
const unsubscribe = createCallback(() => {
  console.log('Callback running, output():', output())
  value = output()
  console.log('Callback set value to:', value)
})

console.log('Initial value:', value)
console.log('Initial output:', output())

console.log('Setting input to 3...')
setInput(3)
console.log('Final value:', value)
console.log('Final output:', output())

console.log('Expected value: 4, Actual value:', value)