/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyDependents,
  registerDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = typeof equal === 'function' ? equal : 
                  equal === true ? Object.is : 
                  (() => true)
  
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this subject as a dependency of the active observer
      registerDependency(subject, observer)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = subject.value
    subject.value = nextValue
    
    if (subject.equalFn && !subject.equalFn(oldValue, nextValue)) {
      // Notify all observers that depend on this subject
      notifyDependents(subject)
    }
    return subject.value
  }

  return [read, write]
}
