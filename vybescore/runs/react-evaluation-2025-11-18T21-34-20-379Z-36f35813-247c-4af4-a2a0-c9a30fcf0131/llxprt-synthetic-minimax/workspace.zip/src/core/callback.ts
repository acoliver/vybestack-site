/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver, getActiveObserver, registerDependency } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Make this observer active to establish dependencies
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // Execute the update function to establish dependencies and run side effects
    observer.value = observer.updateFn(observer.value)
  } finally {
    // Restore the previous observer context
    setActiveObserver(previousObserver)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.updateFn = () => observer.value!
  }
}
