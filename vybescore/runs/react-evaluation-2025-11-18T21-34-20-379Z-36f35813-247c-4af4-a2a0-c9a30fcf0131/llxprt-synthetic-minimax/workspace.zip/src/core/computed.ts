/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  registerDependency,
  getActiveObserver,
  setActiveObserver,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const read: GetterFn<T> = () => {
    const previousObserver = getActiveObserver()
    
    // Register dependency if there's an active observer
    if (previousObserver) {
      registerDependency(previousObserver, observer)
    }
    
    // Set this observer as active and compute the value
    setActiveObserver(observer)
    try {
      const newValue = updateFn(observer.value)
      if (newValue !== observer.value) {
        observer.value = newValue
        // Notify dependents that this observer's value has changed
        notifyDependents(observer)
      }
      return observer.value as T
    } finally {
      // Restore the previous observer
      setActiveObserver(previousObserver)
    }
  }
  
  return read
}
