/**
 * Type definitions for the reactive programming system.
 */

/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dirty?: boolean // mark if needs recomputation
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Type for any reactive entity that can have dependents
export type ReactiveNode = ObserverR | Subject<unknown>

let activeObserver: ObserverR | undefined = undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

// Dependency tracking system
type DependentsMap = Map<ObserverR, Set<ObserverR>>
const dependents: DependentsMap = new Map()

export function registerDependency(observer: ObserverR, dependency: ObserverR): void {
  if (!dependents.has(dependency)) {
    dependents.set(dependency, new Set())
  }
  dependents.get(dependency)!.add(observer)
}

export function notifyDependents(observer: ObserverR): void {
  const subs = dependents.get(observer)
  if (subs) {
    subs.forEach(sub => {
      if (sub !== observer) {
        // Mark as dirty and update immediately
        if ('dirty' in sub) {
          sub.dirty = true
        }
        updateObserver(sub as Observer<unknown>)
      }
    })
  }
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (!observer.updateFn) return
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    // Reset dirty flag after successful update
    observer.dirty = false
  } finally {
    activeObserver = previous
  }
}
