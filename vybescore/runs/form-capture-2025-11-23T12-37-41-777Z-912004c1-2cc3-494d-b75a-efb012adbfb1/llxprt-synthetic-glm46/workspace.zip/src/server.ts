import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import createDatabase from './database.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3535;

interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

function validateSubmission(data: Partial<FormSubmission>): ValidationResult {
  const errors: string[] = [];

  // Required fields validation
  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required');
  }
  
  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required');
  }
  
  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  
  if (!data.city || data.city.trim() === '') {
    errors.push('City is required');
  }
  
  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State/Province/Region is required');
  }
  
  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal/Zip code is required');
  }
  
  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required');
  }
  
  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required');
  }
  
  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required');
  }

  // Email validation
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push('Please enter a valid email address');
  }

// Phone validation: digits, spaces, parentheses, dashes, and leading +
  if (data.phone && !/^[+]?[0-9-\s()]+$/.test(data.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }

  // Postal code validation: alphanumeric
  if (data.postalCode && !/^[a-zA-Z0-9\s]+$/.test(data.postalCode)) {
    errors.push('Postal/Zip code can only contain letters and digits');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

async function startServer(): Promise<void> {
  const app = express();
  const server = app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Initialize database
  const db = await createDatabase();

  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.join(__dirname, '..', 'public')));

  // Set up EJS view engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));

  // Routes
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      errors: [], 
      values: {} 
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const formData: FormSubmission = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateSubmission(formData);

    if (!validation.isValid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        values: formData
      });
    }

    // Insert into database
    // eslint-disable-next-line @typescript-eslint/no-unsafe-call
    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );

    // Write database to disk
    const data = db.export();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(dbPath, data);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    // We don't have a direct way to get the first name after redirect
    // In a real app, you might use session data or pass it as a query param
    res.render('thank-you', { 
      firstName: 'Friend' 
    });
  });

  // Handle graceful shutdown
  const gracefulShutdown = () => {
    console.log('Received shutdown signal, closing server...');
    
    if (server) {
      server.close(() => {
        console.log('Server closed');
        db.close();
        process.exit(0);
      });
    } else {
      db.close();
      process.exit(0);
    }
  };

  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});