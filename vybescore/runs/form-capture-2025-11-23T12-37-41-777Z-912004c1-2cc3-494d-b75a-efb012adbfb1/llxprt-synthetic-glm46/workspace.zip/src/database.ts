// eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');

export default async function createDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  
  // Check if the database file exists
  let db: Database;
  
  if (fs.existsSync(dbPath)) {
    // Load existing database
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    // Create new database
    db = new SQL.Database();
    
    // Create tables based on schema
    const schema = fs.readFileSync(
      path.join(__dirname, '..', 'db', 'schema.sql'), 
      'utf8'
    );
    
    // Execute schema
    // eslint-disable-next-line @typescript-eslint/no-unsafe-call
    db.exec(schema);
    
    // Write initial database to disk
    const data = db.export();
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(dbPath, data);
  }
  
  return db;
}