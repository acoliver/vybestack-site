import { defineConfig } from 'vitest/config';
import path from 'node:path';

export default defineConfig({
  resolve: {
    alias: {
      'cheerio': path.resolve(__dirname, 'node_modules/cheerio')
    }
  },
  test: {
    include: ['tests/public/**/*.spec.ts'],
    environment: 'node',
    globals: true
  }
});
