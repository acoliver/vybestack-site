/**
 * Encode plain text to Base64 using canonical RFC 4648 format.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts canonical Base64 input with proper padding.
 * Throws error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate that input contains only valid Base64 characters (including padding)
  if (!/^[A-Za-z0-9+/=]+$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for correct padding if present
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingChars = input.slice(paddingIndex);
    
    // Padding must be 1 or 2 characters and all '='
    if (paddingChars.length > 2 || !paddingChars.split('').every(char => char === '=')) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }

  try {
    const decoded = Buffer.from(input, 'base64').toString('utf8');
    
    // For inputs with special characters or length mismatches, Node's Buffer.from
    // might not throw an error for clearly malformed input.
    // Let's do a basic sanity check by reverse-encoding
    const reencoded = Buffer.from(decoded, 'utf8').toString('base64');
    const normalizedReencoded = reencoded.replace(/=+$/,'');
    const normalizedInput = input.replace(/=+$/,'');
    
    if (normalizedReencoded !== normalizedInput) {
      throw new Error('Invalid Base64 input: malformed');
    }
    
    return decoded;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
