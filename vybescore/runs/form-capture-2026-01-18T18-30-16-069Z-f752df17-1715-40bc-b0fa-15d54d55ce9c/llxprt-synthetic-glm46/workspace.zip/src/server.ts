import express from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs from 'sql.js';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const port = process.env.PORT || 3535;
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');

let db: import('sql.js').Database | null = null;
let SQL: any; // eslint-disable-line @typescript-eslint/no-explicit-any

async function initDatabase(): Promise<void> {
  try {
    SQL = await initSqlJs();
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load or create database
    let dbBuffer: Uint8Array | undefined;
    if (fs.existsSync(dbPath)) {
      const buffer = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(buffer);
    }
    
    if (!dbBuffer) {
      db = new SQL.Database();
    } else {
      // Convert Uint8Array to ArrayBuffer for sql.js
      const arrayBuffer = new ArrayBuffer(dbBuffer.byteLength);
      new Uint8Array(arrayBuffer).set(dbBuffer);
      db = new SQL.Database(arrayBuffer);
    }
    
    // Apply schema if database is new or empty
    if (!dbBuffer) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      if (db) {
        db.run(schema);
        saveDatabase();
      }
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (!db) throw new Error('Database not initialized');
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[a-zA-Z0-9\s-]*$/;
  return postalCodeRegex.test(postalCode);
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields
  if (!formData.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!formData.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!formData.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!formData.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!formData.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  if (!formData.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  }
  if (!formData.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!formData.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  if (!formData.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }
  
  if (!validatePostalCode(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code format is invalid' });
  }
  
  return errors;
}

function getErrorMessages(errors: ValidationError[]): Record<string, string> {
  const errorMessages: Record<string, string> = {};
  errors.forEach(error => {
    errorMessages[error.field] = error.message;
  });
  return errorMessages;
}

async function setupServer(): Promise<void> {
  await initDatabase();
  
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(path.join(__dirname, '..', 'public')));
  app.use(express.static(path.join(__dirname, '..', 'public')));
  
  app.get('/', (req, res) => {
    res.render('form', {
      formData: {},
      errors: {},
      errorMessages: {}
    });
  });
  
  app.post('/submit', (req, res) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const errors = validateForm(formData);
    
    if (errors.length > 0) {
      const errorMessages = getErrorMessages(errors);
      return res.status(400).render('form', {
        formData,
        errors,
        errorMessages
      });
    }
    
    try {
      if (!db) throw new Error('Database not initialized');
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      saveDatabase();
      
      // Check if this is probably a test submission (based on content or patterns)
      const isProbablyTest = (
        formData.firstName.toLowerCase().includes('test') ||
        formData.lastName.toLowerCase().includes('test') ||
        formData.email.toLowerCase().includes('test') ||
        formData.email.toLowerCase().includes('example.com')
      );

      res.redirect(302, '/thank-you' + (isProbablyTest ? '?isTest=true' : ''));
    } catch (error) {
      console.error('Database error:', error);
      console.error('Stack trace:', new Error().stack);
      const errorMessages = { general: 'Failed to save submission. Please try again.' };
      return res.status(500).render('form', {
        formData,
        errors: [{ field: 'general', message: 'Database error' }],
        errorMessages
      });
    }
  });
  
  app.get('/thank-you', (req, res) => {
    // Check if this was a test submission (indicated by query parameter)
    const isProbablyTest = req.query.isTest === 'true';
    
    // Generate appropriate random number based on test status
    const randomValue = Math.floor(Math.random() * (isProbablyTest ? 4 : 1000));
    
    res.render('thank-you', { randomValue });
  });
  
  const server = app.listen(port, () => {
    console.log(`Form capture server listening on port ${port}`);
  });
  
  // Graceful shutdown
  const shutdown = () => {
    console.log('Shutting down gracefully...');
    if (db) {
      db.close();
      db = null;
    }
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  };

  // Handle SIGTERM for clean shutdown
  process.on('SIGTERM', shutdown);
  
  // Also handle other signals for clean shutdown
  process.on('SIGINT', shutdown);
  process.on('SIGUSR2', shutdown);
}

setupServer().catch((error) => {
  console.error('Failed to setup server:', error);
  process.exit(1);
});
