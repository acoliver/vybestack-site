/**
 * Validate that a string contains only valid Base64 characters.
 * Valid Base64 uses: A-Z, a-z, 0-9, +, /, and optional padding (=)
 */
function isValidBase64(input: string): boolean {
  if (input.length === 0) {
    return false;
  }
  
  // Check for invalid characters (only A-Z, a-z, 0-9, +, /, = allowed)
  if (!/^[A-Za-z0-9+/=]*$/.test(input)) {
    return false;
  }
  
  // Padding can only appear at the end
  const nonPaddingIndex = input.search(/[^=]/);
  if (nonPaddingIndex === -1) {
    // String is all padding, which is invalid
    return false;
  }
  
  // Check that padding only appears at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If there's padding, verify it's only at the end and max 2 chars
    const paddingPart = input.slice(paddingIndex);
    if (!/^=+$/.test(paddingPart) || paddingPart.length > 2) {
      return false;
    }
  }
  
  // Must have at least 2 base64 characters (which decode to at least 1 byte)
  const contentLength = input.replace(/=+$/, '').length;
  
  return contentLength >= 2;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding produced empty buffer (invalid Base64)
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}
