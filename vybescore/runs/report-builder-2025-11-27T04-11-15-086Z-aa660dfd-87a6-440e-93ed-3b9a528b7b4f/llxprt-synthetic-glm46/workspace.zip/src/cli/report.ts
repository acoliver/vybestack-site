#!/usr/bin/env node

import fs from 'node:fs';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Map of format names to renderer functions
 */
const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Parse command line arguments
 */
function parseArgs(args: string[]): { dataPath: string; options: ReportOptions } | null {
  if (args.length < 2) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    return null;
  }

  const dataPath = args[0];
  
  // Initialize options with defaults
  const options: ReportOptions = {
    format: 'markdown', // Default format
    includeTotals: false,
  };

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      const format = args[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        console.error(`Unsupported format: ${format}`);
        return null;
      }
      options.format = format;
      i++; // Skip next argument
    } else if (arg === '--output' && i + 1 < args.length) {
      options.outputPath = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }
  
  // Validate format is provided
  if (!options.format) {
    console.error('Error: --format <format> is required');
    return null;
  }
  
  return { dataPath, options };
}

/**
 * Read and parse JSON data file
 */
function readDataFile(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate data structure
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Entry missing or invalid "label" field');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Entry missing or invalid "amount" field');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    if (error instanceof Error) {
      throw new Error(`Data validation error: ${error.message}`);
    }
    throw new Error(`Failed to read file: ${error}`);
  }
}

/**
 * Main execution function
 */
function main() {
  const args = process.argv.slice(2);
  
  const parsedArgs = parseArgs(args);
  if (!parsedArgs) {
    process.exit(1);
  }
  
  const { dataPath, options } = parsedArgs;
  
  try {
    const data = readDataFile(dataPath);
    const formatter = formatters[options.format];
    
    if (!formatter) {
      throw new Error(`Unsupported format: ${options.format}`);
    }
    
    const output = formatter(data, { includeTotals: options.includeTotals });
    
    if (options.outputPath) {
      fs.writeFileSync(options.outputPath, output);
      console.log(`Report written to ${options.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

// Run main function
main();