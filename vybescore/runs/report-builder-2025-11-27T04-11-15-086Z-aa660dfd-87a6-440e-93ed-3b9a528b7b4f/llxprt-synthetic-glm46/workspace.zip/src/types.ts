/**
 * Interface for report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Interface for individual report entries
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for CLI options
 */
export interface ReportOptions {
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals?: boolean;
}

/**
 * Interface for formatter functions
 */
export interface ReportFormatter {
  (data: ReportData, options: Pick<ReportOptions, 'includeTotals'>): string;
}