import type { ReportFormatter } from '../types.js';

/**
 * Formats report data as plain text
 */
export const renderText: ReportFormatter = (data, { includeTotals }) => {
  // Calculate total if needed
  const total = includeTotals
    ? data.entries.reduce((sum, entry) => sum + entry.amount, 0)
    : 0;

  // Format amounts with two decimal places
  const formatAmount = (amount: number) => `$${amount.toFixed(2)}`;

  // Build text output
  let output = `${data.title}\n`;
  output += `${data.summary}\n`;
  output += `Entries:\n`;
  
  for (const entry of data.entries) {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }
  
  if (includeTotals) {
    output += `Total: ${formatAmount(total)}\n`;
  }
  
  return output;
};