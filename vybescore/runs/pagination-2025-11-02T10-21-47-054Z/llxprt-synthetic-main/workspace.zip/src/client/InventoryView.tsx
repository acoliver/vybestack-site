import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';
import { useState } from 'react';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePreviousPage = () => {
    if (data && data.hasPrevious) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (data && data.hasNext) {
      setCurrentPage(currentPage + 1);
    }
  };

  const resetToFirstPage = () => {
    setCurrentPage(1);
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return (
      <section>
        <p role="alert">{error ?? 'Unable to load inventory.'}</p>
        {error && error.includes('Page') && (
          <button onClick={resetToFirstPage} aria-label="Reset to first page">
            Return to first page
          </button>
        )}
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      {data.items.length === 0 && (
        <p>No inventory items available on this page.</p>
      )}
      <nav aria-label="Pagination controls">
        <button
          onClick={handlePreviousPage}
          disabled={!data.hasPrevious}
          aria-label="Previous page"
        >
          Previous
        </button>
        <span aria-label="Current page information" style={{ margin: '0 1rem' }}>
          Page {data.page} of {Math.ceil(data.total / data.limit)} ({data.total} items total)
        </span>
        <button
          onClick={handleNextPage}
          disabled={!data.hasNext}
          aria-label="Next page"
        >
          Next
        </button>
      </nav>
    </section>
  );
}
